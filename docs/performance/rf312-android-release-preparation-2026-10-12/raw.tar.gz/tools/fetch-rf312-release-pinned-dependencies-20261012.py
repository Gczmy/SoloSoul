from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012';P=S/'dependency-fetch-attempt1';P.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=load(S/'input-proof.json');assert all(sha(R/n)==h for n,h in proof['sourceFiles'].items())
pins=['androidx.emoji2:emoji2-views-helper:1.2.0@aar','androidx.emoji2:emoji2:1.2.0@aar',
 'androidx.lifecycle:lifecycle-process:2.4.1@aar','androidx.concurrent:concurrent-futures:1.0.0@jar','androidx.tracing:tracing:1.0.0@aar']
(P/'requested-pins.json').write_text(json.dumps(pins,indent=2)+'\n',encoding='utf-8',newline='\n')
init=P/'fetch-pins.init.gradle'
init.write_text("""gradle.projectsEvaluated {
  def project = gradle.rootProject.project(':tauri-android')
  project.tasks.register('rf312ResolvePinnedReleaseArtifacts') {
    doLast {
      def coordinates = ['androidx.emoji2:emoji2-views-helper:1.2.0@aar','androidx.emoji2:emoji2:1.2.0@aar','androidx.lifecycle:lifecycle-process:2.4.1@aar','androidx.concurrent:concurrent-futures:1.0.0@jar','androidx.tracing:tracing:1.0.0@aar']
      def rows = []
      coordinates.each { coordinate ->
        def configuration = project.configurations.detachedConfiguration(project.dependencies.create(coordinate))
        configuration.transitive = false
        def files = configuration.resolve()
        if (files.size() != 1) throw new GradleException('Expected exactly one fixed artifact: ' + coordinate)
        def file = files.first()
        def hash = java.security.MessageDigest.getInstance('SHA-256').digest(file.bytes).encodeHex().toString()
        rows.add([coordinate:coordinate,path:file.absolutePath,bytes:file.length(),sha256:hash])
      }
      def receipt = new File('D:/SoloSoul/build/android-native-feasibility-20261010/rf312-android-release-build-20261012/dependency-fetch-attempt1/resolved-artifacts.json')
      if (receipt.exists()) throw new GradleException('Refuse existing receipt')
      receipt.text = groovy.json.JsonOutput.prettyPrint(groovy.json.JsonOutput.toJson(rows))
    }
  }
}
""",encoding='utf-8',newline='\n')
jdk=Path('C:/Users/40299571/ss-android/jdk');sdk=B/'sdk';g=R/'tauri/src-tauri/gen/android'
env=os.environ.copy();env.update(JAVA_HOME=str(jdk),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),
 ANDROID_USER_HOME=str(B/'android-user'),GRADLE_USER_HOME=str(B/'gradle-home'),TEMP=str(B/'tmp'),TMP=str(B/'tmp'),
 JAVA_TOOL_OPTIONS=f'-Duser.home={B/"java-home"} -Djava.io.tmpdir={B/"tmp"}')
for key in ['ANDROID_SDK_HOME','SOLOSOUL_RF312_ANDROID_BUILD_OFFLINE','SOLOSOUL_KEYSTORE_PATH','SOLOSOUL_KEYSTORE_PASSWORD','SOLOSOUL_KEY_ALIAS','SOLOSOUL_KEY_PASSWORD']:env.pop(key,None)
env['PATH']=str(jdk/'bin')+';'+env.get('PATH','')
cmd=['cmd.exe','/d','/c',str(g/'gradlew.bat'),':tauri-android:rf312ResolvePinnedReleaseArtifacts',
 '--init-script',str(init),'--no-daemon','--max-workers','2']
start=time.monotonic()
with (P/'fetch.stdout.log').open('xb') as out,(P/'fetch.stderr.log').open('xb') as err:
 p=subprocess.Popen(cmd,cwd=g,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
 (P/'fetch.live.json').write_text(json.dumps({'pid':p.pid,'command':cmd},indent=2),encoding='utf-8',newline='\n')
 print('Five pinned artifact resolution live PID',p.pid,flush=True);code=p.wait()
assert all(sha(R/n)==h for n,h in proof['sourceFiles'].items())
receipt={'exitCode':code,'command':cmd,'elapsedSeconds':time.monotonic()-start,'sourceHashesUnchanged':True,
 'onlyFiveExistingFixedVersionArtifactsRequested':True,'transitiveResolutionDisabled':True,'versionsUpgraded':False,
 'rustBuildPerformed':False,'applicationInstalled':False,'releaseChecksSkipped':False}
(P/'fetch.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
if code==0:
 rows=load(P/'resolved-artifacts.json');assert [x['coordinate'] for x in rows]==pins
 assert all(sha(Path(x['path']))==x['sha256'] for x in rows)
print('Pinned artifacts terminal exit',code,flush=True)
raise SystemExit(code)
