from pathlib import Path
import hashlib,json,os,re,subprocess
B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012'
key=B/'android-user/debug.keystore'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=sha(key)
env=os.environ.copy();env.update(TEMP=str(B/'tmp'),TMP=str(B/'tmp'))
cmd=['C:/Users/40299571/ss-android/jdk/bin/keytool.exe','-list','-v','-keystore',str(key),'-alias','androiddebugkey','-storepass','android']
p=subprocess.run(cmd,env=env,check=False,capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
(S/'internal-test-signer.stdout.log').write_bytes(p.stdout);(S/'internal-test-signer.stderr.log').write_bytes(p.stderr)
assert p.returncode==0
text=p.stdout.decode('utf-8');match=re.findall(r'SHA256:\s*([A-Fa-f0-9:]+)',text);assert len(match)==1
cert=match[0].replace(':','').lower();assert re.fullmatch(r'[0-9a-f]{64}',cert)
existing=(B/'rf1132-card-high-contrast-build-20261012/test-signature.stdout.log').read_text(encoding='utf-8')
expected=re.findall(r'certificate SHA-256 digest: (\S+)',existing);assert expected==[cert]
assert sha(key)==before
(S/'internal-test-signer.json').write_text(json.dumps({'scope':'existing dedicated debug/test key; not production release signing',
 'keyFile':str(key),'keyFileSha256':before,'readOnlyKeyFileUnchanged':True,'observedKeytoolExitCode':p.returncode,
 'certificateSha256':cert,'existingTestApkCertificateMatches':True,'apkSignedByThisCheck':False,'productionKeyAccessed':False},indent=2)+'\n',encoding='utf-8',newline='\n')
print('Existing dedicated test key certificate matches frozen instrumentation APK; key remains unchanged')
