from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,zipfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012';P=S/'gradle-packaging-attempt1';P.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=load(S/'input-proof.json');recovery=load(S/'input-recovery.json')
assert recovery['rustReleaseCompilationFinished'] and recovery['all1839OriginalSourceBytesRestored']
lib=Path(recovery['releaseLibrary']['copy']);assert sha(lib)==recovery['releaseLibrary']['sha256']
jni=P/'jni/x86_64/libsolo_soul.so';jni.parent.mkdir(parents=True);shutil.copyfile(lib,jni);assert sha(jni)==sha(lib)
init=P/'package.init.gradle'
init.write_text("""gradle.beforeProject { project ->
  project.pluginManager.withPlugin('com.android.application') {
    def android = project.extensions.getByName('android')
    android.sourceSets.getByName('main').assets.setSrcDirs([project.file('D:/SoloSoul/build/android-native-feasibility-20261010/current-apks-rf1121-20261011/packaging-assets')])
    android.sourceSets.getByName('main').jniLibs.setSrcDirs([project.file('D:/SoloSoul/build/android-native-feasibility-20261010/rf312-android-release-build-20261012/gradle-packaging-attempt1/jni')])
    // Internal preparation emits an unsigned APK. Production signing and all
    // release optimization/shrinking flags in build.gradle.kts stay untouched.
    android.buildTypes.getByName('release').signingConfig = null
  }
}
""",encoding='utf-8',newline='\n')
def verify():
 assert all(sha(R/n)==h for n,h in proof['sourceFiles'].items())
 assert all(sha(Path(x['copy']))==x['sha256'] for x in proof['debugApkFilesPreserved'])
 assert sha(jni)==recovery['releaseLibrary']['sha256'] and sha(lib)==sha(jni)
 assert all(sha(B/'current-apks-rf1121-20261011/packaging-assets'/n)==h for n,h in proof['mobilePackagingAssets'].items())
verify()
jdk=Path('C:/Users/40299571/ss-android/jdk');sdk=B/'sdk';g=R/'tauri/src-tauri/gen/android'
env=os.environ.copy();env.update(JAVA_HOME=str(jdk),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),
 NDK_HOME=str(sdk/'ndk/27.0.12077973'),ANDROID_NDK_HOME=str(sdk/'ndk/27.0.12077973'),
 ANDROID_USER_HOME=str(B/'android-user'),RUSTUP_HOME=str(B/'rustup'),RUSTUP_TOOLCHAIN='1.96.0',
 CARGO_HOME=str(B/'cargo-home'),CARGO_TARGET_DIR=str(B/'cargo-target'),CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',
 GRADLE_USER_HOME=str(B/'gradle-home'),TEMP=str(B/'tmp'),TMP=str(B/'tmp'),
 JAVA_TOOL_OPTIONS=f'-Duser.home={B/"java-home"} -Djava.io.tmpdir={B/"tmp"}')
for key in ['ANDROID_SDK_HOME','SOLOSOUL_RF312_ANDROID_BUILD_OFFLINE','PDFIUM_LIBRARY_PATH','SOLOSOUL_KEYSTORE_PATH','SOLOSOUL_KEYSTORE_PASSWORD','SOLOSOUL_KEY_ALIAS','SOLOSOUL_KEY_PASSWORD','SOLOSOUL_REGISTRY_PUBKEY','GITHUB_RUN_NUMBER']:env.pop(key,None)
env['PATH']=str(jdk/'bin')+';'+env.get('PATH','')
cmd=['cmd.exe','/d','/c',str(g/'gradlew.bat'),':app:assembleX86_64Release','-x',':app:rustBuildX86_64Release',
 '--init-script',str(init),'--offline','--no-daemon','--max-workers','2']
start=time.time()
with (P/'build.stdout.log').open('xb') as out,(P/'build.stderr.log').open('xb') as err:
 p=subprocess.Popen(cmd,cwd=g,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
 (P/'build.live.json').write_text(json.dumps({'pid':p.pid,'command':cmd,'startedUnixSeconds':start},indent=2),encoding='utf-8',newline='\n')
 print('Release Gradle packaging live PID',p.pid,flush=True);code=p.wait()
verify()
receipt={'command':cmd,'exitCode':code,'elapsedSeconds':time.time()-start,'sourceHashesUnchanged':True,
 'rustCompilationRepeated':False,'completedReleaseElfInputSha256':sha(jni),'noSymbolicLinkRequired':True,
 'unsignedLocalPreparationOnly':True,'originalCliFailurePreserved':True,'deviceInstallPerformed':False}
(P/'build.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Release Gradle packaging terminal exit',code,flush=True)
if code==0:
 apks=[];apkRoot=g/'app/build/outputs/apk/x86_64/release'
 stripped=g/'app/build/intermediates/stripped_native_libs/x86_64Release/stripX86_64ReleaseDebugSymbols/out/lib/x86_64/libsolo_soul.so'
 assert stripped.is_file();strippedSha=sha(stripped)
 for apk in sorted(apkRoot.glob('*.apk')):
  assert apk.stat().st_mtime>=start-2
  copy=S/apk.name;assert not copy.exists();shutil.copyfile(apk,copy)
  with zipfile.ZipFile(copy) as z:
   native=[n for n in z.namelist() if n.startswith('lib/') and n.endswith('.so')]
   assert native and all(n.startswith('lib/x86_64/') for n in native)
   assert hashlib.sha256(z.read('lib/x86_64/libsolo_soul.so')).hexdigest()==strippedSha
  apks.append({'source':str(apk),'copy':str(copy),'sha256':sha(copy),'bytes':copy.stat().st_size,'nativeEntries':native,'packagedLibrarySha256':strippedSha})
 assert len(apks)==1
 result={'originalCliBuildExitCode':1,'originalOuterWrapperExitCode':1,'gradlePackagingExitCode':0,'apks':apks,
  'sourceHashesRestored':True,'oldApkCopiesPreserved':True,'frontendHashesUnchanged':True,'completedReleaseLibrary':recovery['releaseLibrary'],
  'packagedStrippedLibrarySha256':strippedSha,'releaseLibraryRawBytesMayChangeDuringStandardNdkStrip':strippedSha!=sha(lib),
  'rustCompilationRepeated':False,'deviceInstallPerformed':False,'nativeRuntimeAccepted':False,'fullRF312Accepted':False}
 (S/'packaging-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
 print('One Release APK produced from the proven completed Release library; signature/debuggable checks pending',flush=True)
raise SystemExit(code)
