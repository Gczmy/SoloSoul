from pathlib import Path
import datetime,hashlib,json,os,shutil,struct,subprocess,time,tomllib,zipfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012';S.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,obj):
 with (S/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2)
prior=load(R/'build/rf312-current-startup-20261012/input-proof.json')
sources=prior['currentValidationSources'];assert len(sources)==1839
assert all(sha(R/n)==h for n,h in sources.items())
distProof=load(R/'build/rf121-theme-binding-20261010/rf1129-native-build-20261011/dist-build-inputs.json')
dist=R/'tauri/dist'
assert {p.relative_to(dist).as_posix() for p in dist.rglob('*') if p.is_file()}=={x['path'] for x in distProof['files']}
assert all(sha(dist/x['path'])==x['sha256'] for x in distProof['files'])
old=load(B/'rf1132-card-high-contrast-build-20261012/current-apks.json')
assert all(sha(Path(x['copy']))==x['sha256'] for x in old['files'])
mobile=B/'current-apks-rf1121-20261011/packaging-assets'
assets={p.relative_to(mobile).as_posix():sha(p) for p in mobile.rglob('*') if p.is_file()}
assert assets and all(not(p.stat().st_file_attributes&0x400) for p in mobile.rglob('*') if p.is_file())
manifest=R/'tauri/src-tauri/Cargo.toml';original=manifest.read_bytes();(S/'Cargo-before.toml').write_bytes(original)
jni=R/'tauri/src-tauri/gen/android/app/src/main/jniLibs/x86_64/libsolo_soul.so'
oldJni=sha(jni);shutil.copyfile(jni,S/'generated-jni-before.so')
save('input-proof.json',{'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
 'sourceFiles':sources,'existingFrontendBuild':distProof,'mobilePackagingAssets':assets,'debugApkFilesPreserved':old['files'],
 'defaultCargoFeatures':tomllib.loads(original.decode())['features']['default'],
 'previousGeneratedJniSha256':oldJni,'profile':'release opt-level3/lto-thin/strip-symbols/codegen-units1',
 'androidReleaseShrinkingUnchanged':True,'frontendBuildReusedWithVerifiedUnchangedSources':True,
 'deviceInstallRequested':False,'physicalDevicePerformanceAccepted':False,'fullRF312Accepted':False})
config=S/'release-build.conf.json';config.write_text(json.dumps({'build':{'beforeBuildCommand':''}},indent=2),encoding='utf-8',newline='\n')
initDir=B/'gradle-home/init.d';initDir.mkdir(exist_ok=True)
init=initDir/'rf312-android-release-offline-20261012.gradle'
text="""if (System.getenv('SOLOSOUL_RF312_ANDROID_BUILD_OFFLINE') == '1') {
  gradle.startParameter.offline = true
  gradle.startParameter.maxWorkerCount = 2
  gradle.beforeProject { project ->
    project.pluginManager.withPlugin('com.android.application') {
      project.extensions.getByName('android').sourceSets.getByName('main').assets.setSrcDirs([project.file('D:/SoloSoul/build/android-native-feasibility-20261010/current-apks-rf1121-20261011/packaging-assets')])
    }
  }
}
"""
assert not init.exists();init.write_text(text,encoding='utf-8',newline='\n');(S/'offline-build.init.gradle').write_text(text,encoding='utf-8',newline='\n')
initSha=sha(init)
jdk=Path('C:/Users/40299571/ss-android/jdk');sdk=B/'sdk'
env=os.environ.copy();env.update(JAVA_HOME=str(jdk),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),
 NDK_HOME=str(sdk/'ndk/27.0.12077973'),ANDROID_NDK_HOME=str(sdk/'ndk/27.0.12077973'),
 ANDROID_USER_HOME=str(B/'android-user'),ANDROID_AVD_HOME=str(B/'avd'),ANDROID_ADB_SERVER_PORT='5049',
 ADB_SERVER_SOCKET='tcp:localhost:5049',RUSTUP_HOME=str(B/'rustup'),RUSTUP_TOOLCHAIN='1.96.0',
 CARGO_HOME=str(B/'cargo-home'),CARGO_TARGET_DIR=str(B/'cargo-target'),CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',
 GRADLE_USER_HOME=str(B/'gradle-home'),ORT_CACHE_DIR=str(B/'ort-cache'),TEMP=str(B/'tmp'),TMP=str(B/'tmp'),
 JAVA_TOOL_OPTIONS=f'-Duser.home={B/"java-home"} -Djava.io.tmpdir={B/"tmp"}',
 npm_config_cache=str(B/'npm-cache'),SOLOSOUL_RF312_ANDROID_BUILD_OFFLINE='1')
for key in ['ANDROID_SDK_HOME','PDFIUM_LIBRARY_PATH','SOLOSOUL_KEYSTORE_PATH','SOLOSOUL_KEYSTORE_PASSWORD',
 'SOLOSOUL_KEY_ALIAS','SOLOSOUL_KEY_PASSWORD','SOLOSOUL_REGISTRY_PUBKEY','GITHUB_RUN_NUMBER']:env.pop(key,None)
env['PATH']=str(B/'cargo-home/bin')+';'+str(jdk/'bin')+';C:/Program Files/Git/usr/bin;'+env.get('PATH','')
cmd=['npm.cmd','run','tauri','--','android','build','--target','x86_64','--split-per-abi','--apk','--ci','--config',str(config)]
start=time.monotonic();code=None
try:
 with (S/'build.stdout.log').open('xb') as out,(S/'build.stderr.log').open('xb') as err:
  p=subprocess.Popen(cmd,cwd=R/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  save('build.live.json',{'pid':p.pid,'command':cmd,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
  print('Android Release build live PID',p.pid,flush=True);code=p.wait()
 changed=[n for n,h in sources.items() if sha(R/n)!=h]
 save('build.receipt.json',{'pid':p.pid,'command':cmd,'exitCode':code,'elapsedSeconds':time.monotonic()-start,
  'changedSources':changed,'rawSourceUnchanged':not changed,'productionReleaseSigningInherited':False,
  'rustOffline':True,'gradleOffline':True,'cargoBuildJobs':1,'gradleWorkers':2,'deviceAcceptance':False})
 after=manifest.read_bytes();(S/'Cargo-after.toml').write_bytes(after)
 if changed:
  assert changed==['tauri/src-tauri/Cargo.toml'],changed
  assert original.replace(b'\r\n',b'\n')==after.replace(b'\r\n',b'\n')
  assert tomllib.loads(original.decode())==tomllib.loads(after.decode())
  save('manifest-newline-parity.json',{'rawBytesEqual':False,'normalizedBytesEqual':True,'parsedTomlEqual':True,
   'beforeSha256':hashlib.sha256(original).hexdigest(),'afterSha256':hashlib.sha256(after).hexdigest(),'originalBytesRestored':True})
  manifest.write_bytes(original)
 assert all(sha(R/n)==h for n,h in sources.items())
 assert all(sha(Path(x['copy']))==x['sha256'] for x in old['files'])
 assert all(sha(dist/x['path'])==x['sha256'] for x in distProof['files'])
 library=B/'cargo-target/x86_64-linux-android/release/libsolo_soul.so'
 libraryProof=None
 if library.exists():
  data=library.read_bytes();assert data[:4]==b'\x7fELF' and data[4:6]==b'\x02\x01'
  assert struct.unpack_from('<H',data,16)[0]==3 and struct.unpack_from('<H',data,18)[0]==62
  copy=S/'release-libsolo_soul.so';shutil.copyfile(library,copy)
  libraryProof={'source':str(library),'copy':str(copy),'sha256':sha(copy),'bytes':copy.stat().st_size,'elfBits':64,'machine':62,'type':'ET_DYN'}
 apks=[]
 apkRoot=R/'tauri/src-tauri/gen/android/app/build/outputs/apk/x86_64/release'
 if code==0:
  for apk in sorted(apkRoot.glob('*.apk')):
   copy=S/apk.name;shutil.copyfile(apk,copy)
   with zipfile.ZipFile(copy) as z:
    native=[n for n in z.namelist() if n.startswith('lib/') and n.endswith('.so')]
    assert native and all(n.startswith('lib/x86_64/') for n in native)
    assert 'lib/x86_64/libsolo_soul.so' in native
    apks.append({'source':str(apk),'copy':str(copy),'sha256':sha(copy),'bytes':copy.stat().st_size,'nativeEntries':native})
 save('result.json',{'buildExitCode':code,'nativeReleaseLibrary':libraryProof,'apks':apks,'sourceHashesRestored':True,
  'oldApkCopiesPreserved':True,'frontendHashesUnchanged':True,'deviceInstallPerformed':False,'physicalPerformanceAccepted':False,
  'fullRF312Accepted':False,'packageAndSignatureAndDebuggableStillRequireVerification':True})
 print('Android Release terminal exit',code,'library',bool(libraryProof),'apks',len(apks),flush=True)
finally:
 assert init.exists() and sha(init)==initSha;init.unlink()
 save('offline-init-cleanup.json',{'path':str(init),'sha256':initSha,'onlyExactOwnedInitRemoved':True,'absent':not init.exists()})
 # Keep release artifacts in the exclusive stage, restore the generated Debug JNI input.
 if jni.exists() and sha(jni)!=oldJni:
  save('generated-jni-produced.json',{'path':str(jni),'sha256':sha(jni),'originalSha256':oldJni})
  shutil.copyfile(S/'generated-jni-before.so',jni);assert sha(jni)==oldJni
 save('generated-jni-restoration.json',{'path':str(jni),'originalSha256':oldJni,'finalSha256':sha(jni),'originalBytesRestored':sha(jni)==oldJni})
raise SystemExit(code if code is not None else 1)
