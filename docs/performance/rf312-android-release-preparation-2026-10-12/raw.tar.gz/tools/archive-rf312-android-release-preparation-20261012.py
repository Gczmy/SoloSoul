from pathlib import Path
import hashlib,io,json,tarfile,zipfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012'
N='rf312-android-release-preparation-2026-10-12';O=R/'docs/performance'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,o):p.write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8',newline='\n')
proof=load(S/'input-proof.json');recovery=load(S/'input-recovery.json');package=load(S/'package-verification.json')
assert recovery['all1839OriginalSourceBytesRestored'] and package['acceptedPackagePreparation']
assert package['originalCliExitCode']==1 and package['gradlePackagingExitCode']==0
assert sha(Path(package['apk']['path']))==package['apk']['sha256']
assert all(sha(R/n)==h for n,h in proof['sourceFiles'].items())
assert all(sha(Path(r['copy']))==r['sha256'] for r in proof['debugApkFilesPreserved'])
assert load(S/'offline-init-cleanup.json')['absent']
assert sha(R/'tauri/src-tauri/gen/android/app/src/main/jniLibs/x86_64/libsolo_soul.so')==proof['previousGeneratedJniSha256']
rounds=[load(S/f'gradle-packaging-attempt{i}/build.receipt.json') for i in range(1,6)]
assert [r['exitCode'] for r in rounds]==[1,1,1,1,0]
assert all(r['sourceHashesUnchanged'] and not r['rustCompilationRepeated'] for r in rounds)
lint=load(S/'lint-tooling-fetch-attempt1/independent-cache-verification.json');assert lint['allRecordedArtifactsNowReadbackVerified'] and len(lint['artifacts'])==66
graph=load(S/'dependency-fetch-attempt3/resolved-release-artifacts.json');assert graph['before']==graph['after'] and len(graph['artifacts'])==5
outcomes={'originalCliExitCode':1,'rustReleaseCompilerFinished':True,'rustElapsedLog':'48m 07s',
 'cliFailure':'Windows symbolic-link creation not allowed; generated JNI removed before rejection',
 'outerWrapperExitCode':1,'outerErrors':['strict source freeze found Cargo.toml and tauri.properties changes','generated JNI missing during finally'],
 'inputRecoveryFirstExitCode':1,'recoveryFirstReason':'ANSI color codes prevented exact Finished text match; no restore performed before assertion',
 'inputRecoverySecondExitCode':0,'onlyTerminalFormattingNormalizedForRead':True,
 'packagingExitCodes':[1,1,1,1,0],'packagingFailureReasons':['five offline runtime dependencies missing','four AARs absent from actual Release resolution despite explicit artifact fetch','existing lint-gradle31.11.0 tooling not cached','temporary unsigned setting overridden by later project release signing config'],
 'runtimeDependencyFetchInitialExitCode':1,'runtimeDependencyFetchInitialReason':'included buildSrc lacks tauri-android project',
 'explicitFiveFetchGradleExitCode':0,'actualReleaseVariantFiveFetchExitCodes':[0,0],'fullReleaseDependencyGraphUnchanged':True,
 'lintToolingGradleExitCode':0,'lintOuterReadExitCode':1,'ordinaryCacheVerifierExitCodes':[1,1,1],
 'lintPathCause':'272-character ordinary Python path unavailable; same Windows extended path2199bytes andSHA match',
 'extendedPathVerifierExitCode':0,'cacheAndSystemPoliciesModified':False,
 'packageVerifierFirstExitCode':1,'packageVerifierFirstReason':'actual aapt2 minSdkVersion field differs from old sdkVersion expectation',
 'packageVerifierFinalExitCode':0,'originalUnsignedCheckExpectedExitCode':1,'internalSignAndVerifyExitCodes':[0,0],
 'signerScope':'existing debug/test key only; no production release signing',
 'deviceInstallPerformed':False,'nativeRuntimeAccepted':False,'fullRF312Accepted':False}
put(S/'observed-tool-outcomes.json',outcomes)
assert not O.exists();O.mkdir();members={}
for p in S.rglob('*'):
 if p.is_file() and p.suffix in ['.json','.log','.py','.gradle','.toml','.properties']:
  assert not(p.stat().st_file_attributes&0x400);members['preparation/'+p.relative_to(S).as_posix()]=p
names=['build-rf312-android-release-20261012.py','check-rf312-internal-test-signer-20261012.py','verify-rf312-android-release-package-20261012.py','recover-rf312-android-release-inputs-20261012.py','package-rf312-android-release-20261012.py','fetch-rf312-release-pinned-dependencies-20261012.py','prepare-rf312-pinned-fetch-attempt2-20261012.py','fetch-rf312-release-pinned-dependencies-attempt2-20261012.py','prepare-rf312-packaging-attempt2-20261012.py','fetch-rf312-release-variant-artifacts-20261012.py','prepare-rf312-packaging-attempt3-20261012.py','fetch-rf312-release-lint-tooling-20261012.py','verify-rf312-lint-tooling-cache-20261012.py','probe-rf312-lint-artifact-paths-20261012.py','probe-rf312-lint-long-path-20261012.py','prepare-rf312-packaging-attempt4-20261012.py','prepare-rf312-packaging-attempt5-20261012.py','archive-rf312-android-release-preparation-20261012.py']
names += [f'package-rf312-android-release-attempt{i}-20261012.py' for i in range(2,6)]
for name in names:members['tools/'+name]=B/name
rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as a:
 for name,p in sorted(members.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;a.addfile(info,io.BytesIO(data))
  rows.append({'member':name,'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(O/'raw.tar.gz') as a:
 assert len(a.getmembers())==len(rows)
 for row in rows:
  data=a.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',{'task':'RF-312','members':rows,'allMembersReadbackVerified':True,'apkSoJarAarKeystoreAndCacheContentsExcluded':True})
(O/'.gitattributes').write_text('raw.tar.gz -text\n*.json text eol=lf\n',encoding='utf-8',newline='\n')
eligible=[{'path':str(S/'generated-jni-before.so'),'sha256':sha(S/'generated-jni-before.so'),'bytes':(S/'generated-jni-before.so').stat().st_size}]
for i in range(1,6):
 p=S/f'gradle-packaging-attempt{i}/jni/x86_64/libsolo_soul.so';assert sha(p)==recovery['releaseLibrary']['sha256']
 eligible.append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size})
put(B/'rf312-android-release-copy-cleanup-plan.json',{'ownedStage':str(S),'files':eligible,'archiveReadbackVerified':True,'releaseLibraryAndApksMustRemain':True})
summary={'task':'RF-312','sourceHead':'100d10a51','acceptedScope':'Android optimized x86_64 Release package preparation only',
 'accepted':True,'nativeRuntimeAccepted':False,'physicalPerformanceAccepted':False,'fullRF312Accepted':False,'sourcesValidated':1839,
 'allOriginalSourcesAndGeneratedDebugJniRestored':True,'originalCliFailureUnmodified':True,'package':package,
 'nativeReleaseLibrary':recovery['releaseLibrary'],'originalCLI':load(S/'build.receipt.json'),
 'packagingAttempts':[{'exitCode':r['exitCode'],'elapsedSeconds':r['elapsedSeconds'],'sourceHashesUnchanged':r['sourceHashesUnchanged']} for r in rounds],
 'sameReleaseLibraryReusedWithoutRustRebuild':True,'runtimeComponentGraphUnchanged':True,'lintToolClosureFilesVerified':66,
 'r8WarningPendingIndependentReview':'proguard-rules.pro:19 field name <fields> after Serializable type unlikely to match intended source members',
 'outcomes':outcomes,'temporaryBinaryCopiesEligibleForCleanup':6,'archive':{'path':N+'/raw.tar.gz','members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha(O/'raw.tar.gz'),'allMembersReadbackVerified':True}}
put(R/'docs/performance'/(N+'.json'),summary)
print(json.dumps({'acceptedScope':'Release package preparation only','members':len(rows),'apkBytes':package['apk']['bytes'],'cleanupExactCopies':6}))
