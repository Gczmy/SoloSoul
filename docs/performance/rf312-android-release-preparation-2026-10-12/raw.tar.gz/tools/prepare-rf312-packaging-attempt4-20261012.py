from pathlib import Path
import hashlib,json
B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012'
j=json.loads((S/'lint-tooling-fetch-attempt1/independent-cache-verification.json').read_text(encoding='utf-8-sig'))
assert j['allRecordedArtifactsNowReadbackVerified'] and len(j['artifacts'])==66
assert all(hashlib.sha256(Path('\\\\?\\'+r['path']).read_bytes()).hexdigest()==r['sha256'] for r in j['artifacts'])
s=(B/'package-rf312-android-release-attempt3-20261012.py').read_text(encoding='utf-8').replace('gradle-packaging-attempt3','gradle-packaging-attempt4')
p=B/'package-rf312-android-release-attempt4-20261012.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
print('Required lint31.11.0 tool closure verified; original package failures retained')
