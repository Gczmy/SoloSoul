from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012';P=S/'lint-tooling-fetch-attempt1';P.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=load(S/'input-proof.json')
init=P/'lint-tooling.init.gradle'
init.write_text("""gradle.projectsEvaluated {
  def project = gradle.rootProject.findProject(':tauri-plugin-biometric')
  if (project == null) return
  project.tasks.register('rf312ResolveRequiredLintTooling') {
    doLast {
      def cfg = project.configurations.detachedConfiguration(project.dependencies.create('com.android.tools.lint:lint-gradle:31.11.0'))
      def rows = cfg.resolvedConfiguration.resolvedArtifacts.collect { artifact ->
        def file = artifact.file
        [coordinate:artifact.moduleVersion.id.toString(),path:file.absolutePath,bytes:file.length(),sha256:java.security.MessageDigest.getInstance('SHA-256').digest(file.bytes).encodeHex().toString()]
      }
      if (!rows.any { it.coordinate == 'com.android.tools.lint:lint-gradle:31.11.0' }) throw new GradleException('Missing exact required lint root')
      def out = new File('D:/SoloSoul/build/android-native-feasibility-20261010/rf312-android-release-build-20261012/lint-tooling-fetch-attempt1/artifacts.json')
      if (out.exists()) throw new GradleException('Refuse prior result')
      out.text = groovy.json.JsonOutput.prettyPrint(groovy.json.JsonOutput.toJson(rows))
    }
  }
}
""",encoding='utf-8',newline='\n')
jdk=Path('C:/Users/40299571/ss-android/jdk');sdk=B/'sdk';g=R/'tauri/src-tauri/gen/android'
env=os.environ.copy();env.update(JAVA_HOME=str(jdk),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),ANDROID_USER_HOME=str(B/'android-user'),
 GRADLE_USER_HOME=str(B/'gradle-home'),TEMP=str(B/'tmp'),TMP=str(B/'tmp'),JAVA_TOOL_OPTIONS=f'-Duser.home={B/"java-home"} -Djava.io.tmpdir={B/"tmp"}')
for k in ['ANDROID_SDK_HOME','SOLOSOUL_RF312_ANDROID_BUILD_OFFLINE','SOLOSOUL_KEYSTORE_PATH','SOLOSOUL_KEYSTORE_PASSWORD','SOLOSOUL_KEY_ALIAS','SOLOSOUL_KEY_PASSWORD']:env.pop(k,None)
env['PATH']=str(jdk/'bin')+';'+env.get('PATH','')
assert all(sha(R/n)==h for n,h in proof['sourceFiles'].items())
cmd=['cmd.exe','/d','/c',str(g/'gradlew.bat'),':tauri-plugin-biometric:rf312ResolveRequiredLintTooling','--init-script',str(init),'--no-daemon','--max-workers','2']
start=time.monotonic()
with (P/'fetch.stdout.log').open('xb') as out,(P/'fetch.stderr.log').open('xb') as err:
 p=subprocess.Popen(cmd,cwd=g,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
 (P/'fetch.live.json').write_text(json.dumps({'pid':p.pid,'command':cmd},indent=2),encoding='utf-8',newline='\n')
 print('Required lint31.11.0 tooling live PID',p.pid,flush=True);code=p.wait()
assert all(sha(R/n)==h for n,h in proof['sourceFiles'].items())
(P/'fetch.receipt.json').write_text(json.dumps({'exitCode':code,'elapsedSeconds':time.monotonic()-start,'command':cmd,
 'rootCoordinate':'com.android.tools.lint:lint-gradle:31.11.0','purpose':'existing AGP Release annotation/lint checking tooling',
 'sourceHashesUnchanged':True,'rustBuildPerformed':False,'applicationInstalled':False,'checksDisabled':False},indent=2)+'\n',encoding='utf-8',newline='\n')
if code==0:
 rows=load(P/'artifacts.json');assert all(sha(Path(r['path']))==r['sha256'] for r in rows)
 print('Required lint tooling artifacts verified',len(rows),flush=True)
raise SystemExit(code)
