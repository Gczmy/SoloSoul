from pathlib import Path
import hashlib,json,re,shutil,struct,subprocess,tomllib
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=load(S/'input-proof.json');receipt=load(S/'build.receipt.json')
assert receipt['exitCode']==1 and set(receipt['changedSources'])=={'tauri/src-tauri/Cargo.toml','tauri/src-tauri/gen/android/app/tauri.properties'}
stderr=(S/'build.stderr.log').read_text(encoding='utf-8')
stderr=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',stderr)
assert 'Finished `release` profile' in stderr and 'Failed to create a symbolic link' in stderr
manifest=R/'tauri/src-tauri/Cargo.toml';before=(S/'Cargo-before.toml').read_bytes();after=manifest.read_bytes()
assert hashlib.sha256(before).hexdigest()==proof['sourceFiles']['tauri/src-tauri/Cargo.toml']
assert before.replace(b'\r\n',b'\n')==after.replace(b'\r\n',b'\n') and tomllib.loads(before.decode())==tomllib.loads(after.decode())
manifest.write_bytes(before)
name='tauri/src-tauri/gen/android/app/tauri.properties';p=R/name;generated=p.read_bytes();(S/'tauri-properties-after.properties').write_bytes(generated)
git=subprocess.run(['git','show','HEAD:'+name],cwd=R,check=True,capture_output=True).stdout
choices=[git,git.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')]
original=next(x for x in choices if hashlib.sha256(x).hexdigest()==proof['sourceFiles'][name])
assert generated.replace(b'\r\n',b'\n').rstrip(b'\n')==original.replace(b'\r\n',b'\n').rstrip(b'\n')
(S/'tauri-properties-before.properties').write_bytes(original);p.write_bytes(original)
jni=R/'tauri/src-tauri/gen/android/app/src/main/jniLibs/x86_64/libsolo_soul.so'
assert not jni.exists()
for parent in jni.parents:assert not(parent.stat().st_file_attributes&0x400),parent
assert not jni.is_symlink()
backup=S/'generated-jni-before.so';assert sha(backup)==proof['previousGeneratedJniSha256']
shutil.copyfile(backup,jni);assert sha(jni)==proof['previousGeneratedJniSha256']
assert not(B/'gradle-home/init.d/rf312-android-release-offline-20261012.gradle').exists()
assert all(sha(R/n)==h for n,h in proof['sourceFiles'].items())
assert all(sha(Path(x['copy']))==x['sha256'] for x in proof['debugApkFilesPreserved'])
lib=B/'cargo-target/x86_64-linux-android/release/libsolo_soul.so';data=lib.read_bytes()
assert data[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<HH',data,16)==(3,62)
copy=S/'release-libsolo_soul.so';assert not copy.exists();shutil.copyfile(lib,copy)
out={'originalCliBuildExitCode':1,'originalOuterWrapperExitCode':1,'originalFailuresUnmodified':True,
 'rustReleaseCompilationFinished':True,'jniSymbolicLinkCreationRefused':True,
 'all1839OriginalSourceBytesRestored':True,'cargoOnlyNewlineChanged':True,'propertiesOnlyFinalNewlineAndEolChanged':True,
 'generatedDebugJniRestored':True,'debugJniSha256':sha(jni),'offlineInitRemovedByOriginalFinally':True,
 'releaseLibrary':{'source':str(lib),'copy':str(copy),'bytes':len(data),'sha256':sha(copy),'elfBits':64,'machine':62,'elfType':3},
 'mainRustcCompilerFlags':load(S/'compiler-current-observation.json'),'gradlePackagingNotCompleted':True,'deviceAcceptance':False}
(S/'input-recovery.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Original CLI/outer failures retained; all1839 source bytes, Debug JNI and init restored; completed Release ELF saved')
