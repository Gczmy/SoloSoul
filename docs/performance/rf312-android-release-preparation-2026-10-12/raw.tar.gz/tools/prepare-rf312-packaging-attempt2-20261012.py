from pathlib import Path
import hashlib,json
B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012'
rows=json.loads((S/'dependency-fetch-attempt2/resolved-artifacts.json').read_text(encoding='utf-8-sig'))
assert len(rows)==5 and all(hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256'] for r in rows)
old=B/'package-rf312-android-release-20261012.py'
s=old.read_text(encoding='utf-8').replace('gradle-packaging-attempt1','gradle-packaging-attempt2')
new=B/'package-rf312-android-release-attempt2-20261012.py';assert not new.exists();new.write_text(s,encoding='utf-8',newline='\n')
print('Fresh packaging output prepared; original failed attempt retained and all five fixed artifacts verified')
