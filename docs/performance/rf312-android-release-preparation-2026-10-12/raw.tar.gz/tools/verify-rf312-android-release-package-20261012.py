from pathlib import Path
import hashlib,json,os,re,subprocess,time,zipfile
B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012';R=Path('D:/SoloSoul')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result=load(S/'packaging-result.json')
assert result['originalCliBuildExitCode']==1 and result['gradlePackagingExitCode']==0,'Original CLI failure and completed Gradle package must remain distinct'
assert len(result['apks'])==1,'Expected exactly one x86_64 Release APK'
assert result['sourceHashesRestored'] and result['oldApkCopiesPreserved'] and result['frontendHashesUnchanged']
assert load(S/'offline-init-cleanup.json')['absent']
assert load(S/'input-recovery.json')['generatedDebugJniRestored']
proof=load(S/'input-proof.json')
assert all(sha(R/n)==h for n,h in proof['sourceFiles'].items())
apk=Path(result['apks'][0]['copy']);assert apk.resolve().is_relative_to(S.resolve())
assert sha(apk)==result['apks'][0]['sha256'] and not(apk.stat().st_file_attributes&0x400)
compiledLog=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',(S/'build.stderr.log').read_text(encoding='utf-8'))
assert 'Finished `release` profile' in compiledLog
sdk=B/'sdk';jdk=Path('C:/Users/40299571/ss-android/jdk')
env=os.environ.copy();env.update(TEMP=str(B/'tmp'),TMP=str(B/'tmp'))
def run(name,cmd,expected=0):
 assert not(S/(name+'.receipt.json')).exists()
 start=time.monotonic();p=subprocess.run(cmd,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
 (S/(name+'.stdout.log')).write_bytes(p.stdout);(S/(name+'.stderr.log')).write_bytes(p.stderr)
 (S/(name+'.receipt.json')).write_text(json.dumps({'command':cmd,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start},indent=2)+'\n',encoding='utf-8',newline='\n')
 assert p.returncode==expected,(name,p.returncode,p.stderr)
 return p.stdout.decode('utf-8')
badging=run('release-package-badging2',[str(sdk/'build-tools/35.0.0/aapt2.exe'),'dump','badging',str(apk)])
assert "package: name='com.solosoul.app'" in badging
assert "native-code: 'x86_64'" in badging and 'application-debuggable' not in badging
assert "minSdkVersion:'28'" in badging and "targetSdkVersion:'36'" in badging
signer=load(S/'internal-test-signer.json');key=Path(signer['keyFile'])
assert signer['existingTestApkCertificateMatches'] and sha(key)==signer['keyFileSha256']
signed=S/'app-x86_64-release-internal-validation.apk';assert not signed.exists()
tool=[str(jdk/'bin/java.exe'),'-jar',str(sdk/'build-tools/35.0.0/lib/apksigner.jar')]
run('original-release-unsigned-check',tool+['verify','--verbose',str(apk)],expected=1)
run('internal-test-sign',tool+['sign','--ks',str(key),'--ks-key-alias','androiddebugkey','--ks-pass','pass:android','--key-pass','pass:android','--out',str(signed),str(apk)])
verified=run('internal-test-signature',tool+['verify','--verbose','--print-certs',str(signed)])
assert re.findall(r'certificate SHA-256 digest: (\S+)',verified)==[signer['certificateSha256']]
assert sha(key)==signer['keyFileSha256'] and sha(apk)==result['apks'][0]['sha256']
with zipfile.ZipFile(apk) as before,zipfile.ZipFile(signed) as after:
 payloads={n:hashlib.sha256(before.read(n)).hexdigest() for n in before.namelist() if not n.endswith('/')}
 assert all(hashlib.sha256(after.read(n)).hexdigest()==h for n,h in payloads.items())
 extra=set(after.namelist())-set(before.namelist())
 assert all(n.endswith('/') or re.fullmatch(r'META-INF/(?:MANIFEST\.MF|[^/]+\.(?:SF|RSA|DSA|EC))',n) for n in extra)
out={'acceptedPackagePreparation':True,'scope':'optimized non-debuggable x86_64 Release APK signed only for owned internal validation',
 'originalCliExitCode':1,'originalOuterWrapperExitCode':1,'completedReleaseCompilationPreserved':True,'gradlePackagingExitCode':0,
 'apk':{'path':str(signed),'sha256':sha(signed),'bytes':signed.stat().st_size},
 'originalUnsignedArtifactUnchanged':True,'codeAssetsAndNativeBytesUnchangedBySigning':True,
 'signerScope':'existing debug/test key; not production signing','certificateSha256':signer['certificateSha256'],
 'package':'com.solosoul.app','abi':'x86_64','applicationDebuggable':False,'minSdk':28,'targetSdk':36,
 'installedToAnyDevice':False,'nativeRuntimeAccepted':False,'physicalPerformanceAccepted':False,'fullRF312Accepted':False}
(S/'package-verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Release APK package/ABI/non-debuggable and internal test signer verified; no device installation')
