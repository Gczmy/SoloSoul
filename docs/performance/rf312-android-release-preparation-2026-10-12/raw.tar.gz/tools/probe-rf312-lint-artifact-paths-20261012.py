from pathlib import Path
import json,hashlib
B=Path(__file__).parent;P=B/'rf312-android-release-build-20261012/lint-tooling-fetch-attempt1'
rows=json.loads((P/'artifacts.json').read_text(encoding='utf-8-sig'));out=[]
for r in rows:
 p=Path(r['path']);record={'coordinate':r['coordinate'],'path':str(p),'isFile':p.is_file(),'exists':p.exists(),'isSymlink':p.is_symlink()}
 try:
  stat=p.lstat();record.update(attributes=stat.st_file_attributes,bytes=stat.st_size,reparseTag=getattr(stat,'st_reparse_tag',None))
  record['sha256']=hashlib.sha256(p.read_bytes()).hexdigest();record['hashMatches']=record['sha256']==r['sha256']
 except Exception as e:record['actualReadError']=repr(e)
 out.append(record)
(P/'path-diagnostic.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'rows':len(out),'exceptional':[r for r in out if not r.get('isFile') or r.get('attributes',0)&0x400 or not r.get('hashMatches')]}))
