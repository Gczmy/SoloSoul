from pathlib import Path
B=Path(__file__).parent
s=(B/'package-rf312-android-release-attempt4-20261012.py').read_text(encoding='utf-8').replace('gradle-packaging-attempt4','gradle-packaging-attempt5')
before="    android.buildTypes.getByName('release').signingConfig = null"
after="    project.extensions.getByName('androidComponents').finalizeDsl { extension ->\n      extension.buildTypes.getByName('release').signingConfig = null\n    }"
assert s.count(before)==1;s=s.replace(before,after)
p=B/'package-rf312-android-release-attempt5-20261012.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
print('Original missing-release-signer failure kept; unsigned local preparation set at final DSL stage only')
