from pathlib import Path
import hashlib,json
B=Path(__file__).parent;P=B/'rf312-android-release-build-20261012/lint-tooling-fetch-attempt1'
rows=json.loads((P/'artifacts.json').read_text(encoding='utf-8-sig'))
r=next(x for x in rows if x['coordinate'].startswith('com.google.guava:listenablefuture:'))
p=Path(r['path']);assert p.is_absolute() and '..' not in p.parts
extended=Path('\\\\?\\'+str(p));stat=extended.stat();data=extended.read_bytes()
out={'coordinate':r['coordinate'],'ordinaryPath':str(p),'ordinaryPathLength':len(str(p)),'ordinaryPathExists':p.exists(),
 'extendedPathExists':extended.exists(),'extendedPathFileBytes':len(data),'recordedBytes':r['bytes'],
 'sha256':hashlib.sha256(data).hexdigest(),'matchesRecordedHash':hashlib.sha256(data).hexdigest()==r['sha256'],
 'fileAttributes':stat.st_file_attributes,'systemSettingsChanged':False,'cacheModified':False}
assert out['matchesRecordedHash'] and len(data)==r['bytes'] and not(stat.st_file_attributes&0x400)
(P/'long-path-probe.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(out))
