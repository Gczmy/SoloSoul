from pathlib import Path
B=Path(__file__).parent
old=B/'fetch-rf312-release-pinned-dependencies-20261012.py'
s=old.read_text(encoding='utf-8').replace('dependency-fetch-attempt1','dependency-fetch-attempt2')
before="  def project = gradle.rootProject.project(':tauri-android')"
after="  def project = gradle.rootProject.findProject(':tauri-android')\n  if (project == null) return"
assert s.count(before)==1;s=s.replace(before,after)
new=B/'fetch-rf312-release-pinned-dependencies-attempt2-20261012.py';assert not new.exists()
new.write_text(s,encoding='utf-8',newline='\n')
print('Original failed fetch retained; only included-build project selection corrected')
