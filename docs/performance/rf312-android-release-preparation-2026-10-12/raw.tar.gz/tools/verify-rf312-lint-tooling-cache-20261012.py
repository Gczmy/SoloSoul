from pathlib import Path
import hashlib,json
B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012';P=S/'lint-tooling-fetch-attempt1'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
rows=load(P/'artifacts.json');assert load(P/'fetch.receipt.json')['exitCode']==0
assert any(r['coordinate']=='com.android.tools.lint:lint-gradle:31.11.0' for r in rows)
checked=[]
for r in rows:
 original=Path(r['path']);assert original.is_absolute() and '..' not in original.parts and original.is_relative_to(B/'gradle-home/caches')
 p=Path('\\\\?\\'+str(original));assert p.is_file() and not(p.stat().st_file_attributes&0x400)
 assert p.stat().st_size==r['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
 checked.append(r)
out={'allRecordedArtifactsNowReadbackVerified':True,'artifacts':checked,'rootCoordinate':'com.android.tools.lint:lint-gradle:31.11.0',
 'originalGradleExitCode':0,'originalOuterPythonExitCode':1,'originalReadError':'FileNotFoundError for recorded listenablefuture jar',
 'originalReadFailureRetained':True,'jarLaterObservedPresentBeforeIndependentRead':True,'producerRerun':False,
 'ordinaryPathProblem':'272-character cache path fails ordinary Python file APIs; same extended path bytes match recorded SHA',
 'windowsExtendedPathsUsedForReadback':True,'systemLongPathPolicyChanged':False,'cacheModified':False}
(P/'independent-cache-verification.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Independent current cache readback verified',len(rows),'lint tool artifacts; original missing-file read error preserved')
