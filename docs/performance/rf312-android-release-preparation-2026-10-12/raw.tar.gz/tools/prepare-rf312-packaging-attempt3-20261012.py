from pathlib import Path
import hashlib,json
B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012'
data=json.loads((S/'dependency-fetch-attempt3/resolved-release-artifacts.json').read_text(encoding='utf-8-sig'))
assert data['before']==data['after'] and len(data['artifacts'])==5
assert all(hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256'] for r in data['artifacts'])
s=(B/'package-rf312-android-release-attempt2-20261012.py').read_text(encoding='utf-8').replace('gradle-packaging-attempt2','gradle-packaging-attempt3')
p=B/'package-rf312-android-release-attempt3-20261012.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
print('Actual Release graph and five artifacts verified; original failed package rounds remain separate')
