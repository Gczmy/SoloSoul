from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-android-release-build-20261012';P=S/'dependency-fetch-attempt3';P.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=load(S/'input-proof.json')
init=P/'release-variant.init.gradle'
init.write_text("""gradle.projectsEvaluated {
  def project = gradle.rootProject.findProject(':tauri-android')
  if (project == null) return
  def coordinate = { id -> id.group + ':' + id.module + ':' + id.version }
  def graph = { cfg -> cfg.incoming.resolutionResult.allComponents.findAll { it.id instanceof org.gradle.api.artifacts.component.ModuleComponentIdentifier }.collect { coordinate(it.id) }.sort() }
  project.tasks.register('rf312ReleaseGraphSnapshot') {
    doLast {
      def value = graph(project.configurations.getByName('releaseRuntimeClasspath'))
      def out = new File('D:/SoloSoul/build/android-native-feasibility-20261010/rf312-android-release-build-20261012/dependency-fetch-attempt3/graph-before.json')
      if (out.exists()) throw new GradleException('Refuse prior graph')
      out.text = groovy.json.JsonOutput.prettyPrint(groovy.json.JsonOutput.toJson(value))
    }
  }
  project.tasks.register('rf312ResolveReleaseVariantPinnedArtifacts') {
    doLast {
      def cfg = project.configurations.getByName('releaseRuntimeClasspath')
      def before = new groovy.json.JsonSlurper().parse(new File('D:/SoloSoul/build/android-native-feasibility-20261010/rf312-android-release-build-20261012/dependency-fetch-attempt3/graph-before.json'))
      def after = graph(cfg)
      if (before != after) throw new GradleException('Release dependency graph changed')
      def pins = ['androidx.emoji2:emoji2-views-helper:1.2.0','androidx.emoji2:emoji2:1.2.0','androidx.lifecycle:lifecycle-process:2.4.1','androidx.concurrent:concurrent-futures:1.0.0','androidx.tracing:tracing:1.0.0'] as Set
      def view = cfg.incoming.artifactView { componentFilter { id -> id instanceof org.gradle.api.artifacts.component.ModuleComponentIdentifier && pins.contains(coordinate(id)) } }
      def rows = view.artifacts.artifacts.collect { artifact ->
        def file = artifact.file
        [coordinate:coordinate(artifact.id.componentIdentifier),path:file.absolutePath,bytes:file.length(),sha256:java.security.MessageDigest.getInstance('SHA-256').digest(file.bytes).encodeHex().toString()]
      }
      if (rows.size() != 5 || (rows.collect { it.coordinate } as Set) != pins) throw new GradleException('Expected exactly five original components')
      def out = new File('D:/SoloSoul/build/android-native-feasibility-20261010/rf312-android-release-build-20261012/dependency-fetch-attempt3/resolved-release-artifacts.json')
      if (out.exists()) throw new GradleException('Refuse prior artifacts')
      out.text = groovy.json.JsonOutput.prettyPrint(groovy.json.JsonOutput.toJson([before:before,after:after,artifacts:rows]))
    }
  }
}
""",encoding='utf-8',newline='\n')
jdk=Path('C:/Users/40299571/ss-android/jdk');sdk=B/'sdk';g=R/'tauri/src-tauri/gen/android'
env=os.environ.copy();env.update(JAVA_HOME=str(jdk),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),ANDROID_USER_HOME=str(B/'android-user'),
 GRADLE_USER_HOME=str(B/'gradle-home'),TEMP=str(B/'tmp'),TMP=str(B/'tmp'),JAVA_TOOL_OPTIONS=f'-Duser.home={B/"java-home"} -Djava.io.tmpdir={B/"tmp"}')
for k in ['ANDROID_SDK_HOME','SOLOSOUL_RF312_ANDROID_BUILD_OFFLINE','SOLOSOUL_KEYSTORE_PATH','SOLOSOUL_KEYSTORE_PASSWORD','SOLOSOUL_KEY_ALIAS','SOLOSOUL_KEY_PASSWORD']:env.pop(k,None)
env['PATH']=str(jdk/'bin')+';'+env.get('PATH','')
def run(label,task,offline):
 assert all(sha(R/n)==h for n,h in proof['sourceFiles'].items())
 cmd=['cmd.exe','/d','/c',str(g/'gradlew.bat'),':tauri-android:'+task,'--init-script',str(init),'--no-daemon','--max-workers','2']+(['--offline'] if offline else [])
 start=time.monotonic()
 with (P/(label+'.stdout.log')).open('xb') as out,(P/(label+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,cwd=g,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  (P/(label+'.live.json')).write_text(json.dumps({'pid':p.pid,'command':cmd},indent=2),encoding='utf-8',newline='\n')
  print(label,'live PID',p.pid,flush=True);code=p.wait()
 assert all(sha(R/n)==h for n,h in proof['sourceFiles'].items())
 (P/(label+'.receipt.json')).write_text(json.dumps({'command':cmd,'exitCode':code,'elapsedSeconds':time.monotonic()-start,'sourceHashesUnchanged':True,'rustRecompiled':False},indent=2)+'\n',encoding='utf-8',newline='\n')
 print(label,'terminal exit',code,flush=True);return code
code=run('graph-before','rf312ReleaseGraphSnapshot',True)
if code==0:code=run('resolve-five','rf312ResolveReleaseVariantPinnedArtifacts',False)
if code==0:
 data=load(P/'resolved-release-artifacts.json');assert data['before']==data['after'] and len(data['artifacts'])==5
 assert all(sha(Path(a['path']))==a['sha256'] for a in data['artifacts'])
 print('Exactly five Release-variant artifacts verified; full resolved dependency graph unchanged',flush=True)
raise SystemExit(code)
