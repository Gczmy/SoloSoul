from pathlib import Path
import json
B=Path(__file__).parent;old=B/'rf312-text-visual-probe-20261012';S=B/'rf312-text-visual-probe-round2-20261012'
assert json.loads((old/'first-100-diagnostic.receipt.json').read_text())['restored']
S.mkdir(exist_ok=False)
for name in ['AndroidMediaPerfInstrumentedTest.kt','current-runtime-sources.json','inputs.json','media-native-driver.py','run-first-100-diagnostic.py','run-first-5000-diagnostic.py']:
    text=(old/name).read_text(encoding='utf-8').replace(old.name,S.name)
    if name.endswith('.kt'):
        text=text.replace('''        captureScreenshot(scenario,name)
        val bitmap=requireNotNull(BitmapFactory.decodeFile''','''        val bitmap=requireNotNull(BitmapFactory.decodeFile''')
        text=text.replace('''                val before=textPixels(scenario,"diagnostic-text-before-commit",js(scenario,textPage))''','''                // Match the previous immediate capture point: no extra style or
                // geometry query before PixelCopy. Analyze that saved PNG later.
                captureScreenshot(scenario,"diagnostic-text-before-commit")
                val before=textPixels(scenario,"diagnostic-text-before-commit",js(scenario,textPage))''')
        text=text.replace('''                val after=textPixels(scenario,"diagnostic-text-after-commit",js(scenario,textPage))''','''                captureScreenshot(scenario,"diagnostic-text-after-commit")
                val after=textPixels(scenario,"diagnostic-text-after-commit",js(scenario,textPage))''')
    (S/name).write_text(text,encoding='utf-8',newline='\n')
text=(B/'build-rf312-text-visual-probe.py').read_text(encoding='utf-8').replace(old.name,S.name)
(B/'build-rf312-text-visual-probe-round2.py').write_text(text,encoding='utf-8',newline='\n')
print(S)
