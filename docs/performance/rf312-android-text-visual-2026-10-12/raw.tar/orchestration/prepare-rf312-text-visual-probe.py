from pathlib import Path
import json,hashlib
R=Path('D:/SoloSoul');B=Path(__file__).parent;old=B/'rf1136-android-nonblank-media-20261012';S=B/'rf312-text-visual-probe-20261012'
S.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=(old/'AndroidMediaPerfInstrumentedTest.kt').read_text(encoding='utf-8')
source=source.replace('import android.graphics.Bitmap','import android.graphics.Bitmap\nimport android.graphics.BitmapFactory')
needle='    @Test fun fixedMediaUiDiagnostic() {'
assert source.count(needle)==1
insert='''    private val textPage = """(() => {
      const e=document.querySelector('[data-testid="attachment-preview-content"] pre');
      const s=e?getComputedStyle(e):null;const r=e?.getBoundingClientRect();
      return JSON.stringify({knownText:e?.textContent==='RF-312 public synthetic attachment preview.\\nHello SoloSoul 1234567890.\\n',
        foreground:s?.color,fontSize:s?.fontSize,opacity:s?.opacity,visibility:s?.visibility,
        viewportWidth:innerWidth,rect:r?{x:r.x,y:r.y,width:r.width,height:r.height}:null});})()"""

    private fun textPixels(scenario:ActivityScenario<MainActivity>,name:String,state:JSONObject):JSONObject {
        assertTrue(state.getBoolean("knownText"))
        val color=Regex("[0-9.]+").findAll(state.getString("foreground")).map { it.value.toDouble().toInt() }.toList()
        check(color.size>=3 && color.take(3).all { it in 0..255 })
        val rect=state.getJSONObject("rect")
        var scale=0.0;val position=IntArray(2)
        scenario.onActivity { activity ->
            val view=requireNotNull(webView(activity.window.decorView));check(view.isShown && view.hasWindowFocus())
            view.getLocationInWindow(position);scale=view.width/state.getDouble("viewportWidth")
        }
        captureScreenshot(scenario,name)
        val bitmap=requireNotNull(BitmapFactory.decodeFile(File(evidence,"$name.png").path))
        try {
            val left=(position[0]+rect.getDouble("x")*scale).toInt().coerceIn(0,bitmap.width)
            val top=(position[1]+rect.getDouble("y")*scale).toInt().coerceIn(0,bitmap.height)
            val right=(position[0]+(rect.getDouble("x")+rect.getDouble("width"))*scale).toInt().coerceIn(0,bitmap.width)
            val bottom=(position[1]+(rect.getDouble("y")+rect.getDouble("height"))*scale).toInt().coerceIn(0,bitmap.height)
            check(right>left && bottom>top)
            var near=0
            for(y in top until bottom)for(x in left until right) {
                val p=bitmap.getPixel(x,y)
                if(Color.alpha(p)>=200 && kotlin.math.abs(Color.red(p)-color[0])<=32 &&
                    kotlin.math.abs(Color.green(p)-color[1])<=32 && kotlin.math.abs(Color.blue(p)-color[2])<=32)near++
            }
            return JSONObject().put("screenshot",name+".png").put("knownText",true).put("nearForegroundPixels",near)
                .put("left",left).put("top",top).put("right",right).put("bottom",bottom).put("style",state)
        } finally { bitmap.recycle() }
    }

'''
source=source.replace(needle,insert+needle)
start=source.index('            measure("text-preview") {')
end=source.index('            measure("pdf-text-native-diagnostic")',start)
source=source[:start]+'''            measure("text-preview") {
                val beganText=SystemClock.elapsedRealtimeNanos()
                preview("preview.txt")
                waitFor(scenario,mediaPage,beganText) { it.optBoolean("knownText") && !it.optBoolean("previewError") }
                report.put("textPreview",js(scenario,mediaPage))
                val before=textPixels(scenario,"diagnostic-text-before-commit",js(scenario,textPage))
                report.put("textBeforeCommit",before);writeReport()
                painted(scenario,beganText)
                val after=textPixels(scenario,"diagnostic-text-after-commit",js(scenario,textPage))
                report.put("textAfterCommit",after).put("textVisualCommitDefinition","actual WebView postVisualStateCallback plus two native frames within original45s budget")
                writeReport()
                assertTrue("Actual committed text region must contain visible foreground pixels: $after",after.getInt("nearForegroundPixels")>100)
                closePreview()
            }
'''+source[end:]
(S/'AndroidMediaPerfInstrumentedTest.kt').write_text(source,encoding='utf-8',newline='\n')
inputs=load(old/'inputs.json');current={n:sha(R/n) for n in inputs['runtimeSourceFiles']}
assert current==inputs['runtimeSourceFiles']
(S/'current-runtime-sources.json').write_text(json.dumps(current,indent=2)+'\n',encoding='utf-8')
inputs['sourceParentHead']='b587ecdff';inputs.pop('sourceHasPendingRf1135Changes',None);inputs.pop('sourceHasPendingRf1136FixtureChanges',None)
(S/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
for name in ['media-native-driver.py','run-first-100-diagnostic.py','run-first-5000-diagnostic.py']:
    raw=(old/name).read_text(encoding='utf-8').replace(old.name,S.name)
    if name=='media-native-driver.py':
        guard="    phases=evidence.get('phases',[])"
        assert raw.count(guard)==1
        raw=raw.replace(guard,"    if evidence.get('textAfterCommit',{}).get('nearForegroundPixels',0)<=100 or evidence.get('textAfterCommit',{}).get('knownText') is not True:raise RuntimeError('Actual committed text window pixels required')\n"+guard)
    (S/name).write_text(raw,encoding='utf-8',newline='\n')
builder=(B/'build-rf1135-pages-probe-round3.py').read_text(encoding='utf-8').replace('rf1135-android-native-pages-round3-20261012',S.name)
(B/'build-rf312-text-visual-probe.py').write_text(builder,encoding='utf-8',newline='\n')
print(S)
