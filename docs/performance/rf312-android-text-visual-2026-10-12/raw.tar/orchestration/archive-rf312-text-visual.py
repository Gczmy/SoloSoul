from pathlib import Path
import json,hashlib,tarfile,io,importlib.util
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-text-visual-probe-round2-20261012';old=B/'rf312-text-visual-probe-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
helper=R/'tauri/scripts/android-home-native-regression.py';spec=importlib.util.spec_from_file_location('text_restore_audit',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rows=[];restores=[]
for root,count in [(old,100),(S,100),(S,5000)]:
    receipt=load(root/f'first-{count}-diagnostic.receipt.json');assert receipt['exitCode']==0 and all(receipt[k] for k in ['passed','restored','originalApksRestored','ownedProbeRemoved','blurRestored','sourceInputsUnchanged'])
    d=root/f'first-{count}-diagnostic';native=load(d/'device-files/report.json');before=native['textBeforeCommit'];after=native['textAfterCommit']
    assert after['knownText'] and after['nearForegroundPixels']>100 and native['success']
    rows.append({'run':root.name,'objectCount':count,'nativeActualExitCode':0,'sameMainApkSha256':load(root/'inputs.json')['release']['apk']['sha256'],'before':before,'after':after,'phaseDurationsDiagnosticOnly':[{k:p[k] for k in ['name','success','durationMs','transportAttempts']} for p in native['phases']],'pdfDiagnosticAndAll10PhasesPassed':True,'fullPerformanceAccepted':False})
    a=d/'private-data-before.tar';z=d/'private-data-restored.tar';x=m.inventory(a,require_empty=True);y=m.inventory(z);assert x==y
    restores.append({'run':root.name,'objectCount':count,'entries':len(x),'allContentsLinksModesMatch':True,'beforeTarSha256':sha(a.read_bytes()),'afterTarSha256':sha(z.read_bytes())})
(S/'complete-restoration-audit.json').write_text(json.dumps(restores,indent=2)+'\n',encoding='utf-8')
target=R/'docs/performance/rf312-android-text-visual-2026-10-12';target.mkdir(exist_ok=False)
members={}
for root in [old,S]:
    for p in root.rglob('*'):
        rel=p.relative_to(root)
        if 'project' in rel.parts or not p.is_file() or p.suffix.lower() not in {'.json','.log','.py','.kt','.png'}:continue
        assert not p.is_symlink();members[root.name+'/'+rel.as_posix()]=p.read_bytes()
for n in ['prepare-rf312-text-visual-probe.py','prepare-rf312-text-visual-probe-round2.py','build-rf312-text-visual-probe.py','build-rf312-text-visual-probe-round2.py','archive-rf312-text-visual.py']:
    members['orchestration/'+n]=(B/n).read_bytes()
archive=target/'raw.tar'
with tarfile.open(archive,'w') as out:
    for name,raw in sorted(members.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;out.addfile(info,io.BytesIO(raw))
index={'task':'RF-312','scope':'Android fixed public text window visibility diagnostic','archiveSha256':sha(archive.read_bytes()),'members':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())},'privateDataProgramsKeysAndDatabasesExcluded':True}
with tarfile.open(archive) as inp:
    assert {m.name for m in inp}==set(members)
    for n,v in index['members'].items():
        b=inp.extractfile(n).read();assert len(b)==v['bytes'] and sha(b)==v['sha256']
(target/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
summary={'task':'RF-312','status':'partial-verification','scope':'actual committed WebView text visibility; not a product style repair','productSourceAndMainApkUnchanged':True,'runs':rows,'restorationAudit':restores,'historicalInspection':load(S/'historical-text-capture-inspection.json'),'historicalBlankSpecificCauseProven':False,'firstRunAddsStyleQueriesBeforeImmediateCapture':True,'secondProbePreservesPriorImmediatePointAndAnalyzesSavedPngAfterCapture':True,'postCommitGate':'actual postVisualStateCallback and two native frames within original45s budget; exact public DOM text plus window foreground pixels and manual review','wholeRF312Accepted':False,'remaining':['first OCR','search plus all media in repeated full cohorts','renderer/full process memory','process cold launch','hardware and other platforms'],'rawIndex':target.name+'/index.json'}
(R/'docs/performance/rf312-android-text-visual-2026-10-12.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print({'rawMembers':len(members),'restorationPairs':len(restores),'committedTextPixels':[(r['objectCount'],r['after']['nearForegroundPixels']) for r in rows]})
