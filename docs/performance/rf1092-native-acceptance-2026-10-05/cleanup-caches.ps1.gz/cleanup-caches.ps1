﻿$ErrorActionPreference='Stop'
$stageRoot='C:\Users\40299571\AppData\Local\Temp\ss-rf1092-native-accept-20261005'
$proof=Get-Content -Raw -LiteralPath (Join-Path $stageRoot 'final-process-check.json') | ConvertFrom-Json
if (!$proof.noneOwnedLive) {throw 'Owned live-process check did not pass'}
function NormalPath([string]$value) {
  if ($value.StartsWith('\\?\')) {$value=$value.Substring(4)}
  return [IO.Path]::GetFullPath($value).TrimEnd('\')
}
$expectedLocal='C:\Users\40299571\AppData\Local\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache\Local'
$expectedRoaming='C:\Users\40299571\AppData\Local\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache\Roaming'
$plans=@()
foreach ($runName in @('sdk-5000')) {
  foreach ($entry in Get-ChildItem -LiteralPath (Join-Path $stageRoot $runName) -Filter 'sample-*' -Directory) {
    $owned=Get-Content -Raw -LiteralPath (Join-Path $entry.FullName 'native-perf-owned.json') | ConvertFrom-Json
    $root=NormalPath $owned.root
    if ($owned.scope -ne 'windows-native-perf-owned' -or $owned.runId -notmatch '^[a-f0-9]{32}$' -or
      $owned.identifier -cne ('com.solosoul.rf312perf.'+$owned.runId) -or $root -ine $entry.FullName -or
      !$root.StartsWith($stageRoot+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Owned root boundary invalid'}
    $local=NormalPath $owned.local; $roaming=NormalPath $owned.roaming
    if ($local -ine (Join-Path $expectedLocal $owned.identifier) -or $roaming -ine (Join-Path $expectedRoaming $owned.identifier)) {throw 'Known folder boundary invalid'}
    foreach ($name in @('app-data','models','plugins','profile','temp','webview')) {
      $target=NormalPath (Join-Path $root $name)
      if (!$target.StartsWith($root+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Cache target escaped root'}
      $plans+=@([ordered]@{root=$root;target=$target;kind='private-root-cache'})
    }
    $plans+=@([ordered]@{root=$root;target=$local;kind='owned-known-local'},[ordered]@{root=$root;target=$roaming;kind='owned-known-roaming'})
  }
}
$plans | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 -LiteralPath (Join-Path $stageRoot 'cleanup-plan.json')
$script:links=@();$results=@()
function UnlinkBelow([string]$directory,[string]$boundary) {
  $item=Get-Item -LiteralPath $directory -Force
  $path=NormalPath $item.FullName
  if ($path -ine $boundary -and !$path.StartsWith($boundary+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Unlink target escaped verified cache'}
  if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) {
    $linkTarget=@($item.Target)[0]
    if ($item.PSIsContainer) {[IO.Directory]::Delete($path,$false)} else {[IO.File]::Delete($path)}
    $script:links+=@([ordered]@{path=$path;target=$linkTarget;operation='unlink-only';targetTraversed=$false})
    return
  }
  if ($item.PSIsContainer) {foreach ($child in Get-ChildItem -LiteralPath $path -Force) {
    if ($child.PSIsContainer -or ($child.Attributes -band [IO.FileAttributes]::ReparsePoint)) {UnlinkBelow $child.FullName $boundary}
  }}
}
foreach ($plan in $plans) {
  if (Test-Path -LiteralPath $plan.target) {
    $parent=Get-Item -LiteralPath (Split-Path -Parent $plan.target) -Force
    if ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint) {throw 'Cache parent is a reparse point'}
    UnlinkBelow $plan.target $plan.target
    if (Test-Path -LiteralPath $plan.target) {[IO.Directory]::Delete($plan.target,$true)}
  }
  $results+=@([ordered]@{target=$plan.target;removed=!(Test-Path -LiteralPath $plan.target)})
}
[ordered]@{at=(Get-Date).ToUniversalTime().ToString('o');targets=$results;unlinked=$script:links;preserved=@('vault','native markers','raw sample reports','public fixtures','reusable binary/resources')} | ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 -LiteralPath (Join-Path $stageRoot 'cleanup-result.json')
Write-Output ('Removed '+$results.Count+' checked private caches; unlinked '+$script:links.Count+' links without traversing targets')
