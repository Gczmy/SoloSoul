import collections, hashlib, json
from pathlib import Path
from datetime import datetime, timezone
stage=Path(__file__).parent
repo=Path(r'C:\Users\40299571\SoloSoul')
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data): (stage/name).write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
report=read(stage/'sdk-timeout-100/native-perf-sdk-journey-results.json')
assert report['samplesRequested']==5
assert len(report['samples'])==5 and not report['interrupted']
assert report['sourceUnchanged']
assert all(s.get('cleanupIntegrity',{}).get('complete') for s in report['samples'])
assert report['exeSha256']==sha(stage/'bin/solo_soul.exe')
identities={}
def visit(x):
 if isinstance(x,dict):
  pid=x.get('pid'); creation=x.get('creationMs'); name=x.get('executableName')
  if isinstance(pid,int) and pid>0 and isinstance(creation,(int,float)) and creation>0 and isinstance(name,str) and name:
   key=(pid,creation,name.lower()); identities[key]={'pid':pid,'creationMs':creation,'executableName':name}
  for y in x.values(): visit(y)
 elif isinstance(x,list):
  for y in x: visit(y)
visit(report['samples'])
assert identities
write('owned-identities.json',list(identities.values()))
rows=[]
for s in report['samples']:
 proof=s.get('nativeProof') or {}; diag=proof.get('timeoutDiagnostic') or {}; probe=diag.get('probe') or {}
 commands=probe.get('observer',{}).get('commands',[])
 rows.append({'index':s['index'],'success':s['success'],'uiSuccess':s.get('uiSuccess'),'reason':proof.get('reason'),'failedStep':proof.get('failedStep'),'phaseCount':len(proof.get('phases',[])),'memoryComplete':s.get('memorySeries',{}).get('complete'),'memoryPoints':s.get('memorySeries',{}).get('sampleCount'),'diagnosticPresent':bool(diag),'frameVerified':diag.get('frameVerified'),'href':probe.get('href'),'state':diag.get('state'),'inputTrust':probe.get('inputTrust'),'lastSuccessfulInputTrust':proof.get('lastProbe',{}).get('inputTrust'),'commandCounts':dict(collections.Counter(c['command'] for c in commands)),'lastCommands':commands[-10:]})
write('runtime-summary.json',{'at':datetime.now(timezone.utc).isoformat(),'success':report['success'],'sourceUnchanged':True,'samples':rows,'memorySummary':report.get('memorySummary'),'definitions':report.get('definitions')})
frozen=read(stage/'source-freeze-build.json')
for row in frozen['files']: assert sha(repo/row['path'])==row['sha256'],row['path']
baseline=read(stage/'baseline.json')
for row in baseline['fixtures']+[baseline['previousExe']]: assert sha(Path(row['path']))==row['sha256'],row['path']
for row in read(stage/'resource-inventory.json'):
 assert sha(Path(row['source']))==row['sha256']
 assert sha(Path(row['target']))==row['sha256']
write('measurement-preservation.json',{'sourceFreezeUnchanged':True,'publicFixturesUnchanged':14,'publicResourcesUnchanged':94,'previousExeUnchanged':True,'newExeSha256':report['exeSha256']})
print(json.dumps({'success':report['success'],'identities':len(identities),'samples':rows},ensure_ascii=False))
