import gzip, hashlib, json
from pathlib import Path
from datetime import datetime, timezone
stage=Path(__file__).parent
repo=Path(r'C:\Users\40299571\SoloSoul')
label='rf312-windows-timeout-diagnostics-2026-10-05'
dest=repo/'docs/performance'/label
assert not dest.exists(), 'Archive destination already exists; refuse overwrite'
files=sorted(p for p in stage.iterdir() if p.is_file() and p.suffix in {'.json','.log','.ps1','.py'})
for groupName in ['sdk-timeout-100','sdk-timeout-100-fast']:
 group=stage/groupName
 files+=sorted(group.glob('*.json'))
 samples=sorted(p for p in group.glob('sample-*') if p.is_dir())
 assert len(samples)==5
 for sample in samples:
  assert not sample.is_symlink() and not sample.is_junction()
  files+=sorted(sample.glob('native-perf-*.json'))
assert all(p.is_file() and not p.is_symlink() for p in files)
dest.mkdir()
rows=[]
for p in files:
 relative=p.relative_to(stage).as_posix()
 target=dest/(relative+'.gz'); target.parent.mkdir(parents=True,exist_ok=True)
 raw=p.read_bytes(); packed=gzip.compress(raw,compresslevel=9,mtime=0)
 with target.open('xb') as f: f.write(packed)
 assert gzip.decompress(target.read_bytes())==raw
 rows.append({'source':str(p),'relativePath':relative,'archivePath':relative+'.gz','rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'gzipBytes':len(packed),'gzipSha256':hashlib.sha256(packed).hexdigest()})
index={'schemaVersion':1,'task':'RF-312','at':datetime.now(timezone.utc).isoformat(),'scope':'Windows SDK timeout diagnostic stage; all raw failure and success samples retained','stageRoot':str(stage),'count':len(rows),'entries':rows}
(dest/'index.json').write_bytes((json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
(dest/'.gitattributes').write_bytes(b'* -text\n')
print(json.dumps({'archives':len(rows),'index':str(dest/'index.json')}))
