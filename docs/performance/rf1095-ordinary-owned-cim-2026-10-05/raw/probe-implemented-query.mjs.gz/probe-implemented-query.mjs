import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {readFile,writeFile} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {performance} from 'node:perf_hooks';
const repo='C:/Users/40299571/SoloSoul', stage='C:/Users/40299571/AppData/Local/Temp/ss-rf312-cim-stages-20261005';
const api=await import(pathToFileURL(path.join(repo,'tauri/scripts/native-perf-run.mjs')));
const sdk=await import(pathToFileURL(path.join(repo,'tauri/scripts/native-perf-sdk-journey.mjs')));
const old='C:/Users/40299571/AppData/Local/Temp/ss-rf312-ocr-20261005';
const build=JSON.parse(await readFile(path.join(old,'build-checkpoint-final.json'),'utf8'));
if(await api.sha256(build.exe)!==build.sha256)throw Error('Frozen EXE replaced');
const options=await api.validateInputs({exe:build.exe,fixture:'C:/Users/40299571/AppData/Local/Temp/ss-rf312-media-20261005/vault5000',output:path.join(stage,'probe-002'),samples:3},{media:true});
const root=options.output,env={...process.env};delete env.SOLOSOUL_REGISTRY_PUBKEY;
const save=async(n,v)=>writeFile(path.join(stage,'implemented-'+n),JSON.stringify(v,null,2)+'\n',{flag:'wx'});
const prefix=`$taskProbeClock=[Diagnostics.Stopwatch]::StartNew()
$script:taskProbeIndex=0
function ProbeEvent($kind,$meta){$meta.kind=$kind;$meta.scriptElapsedMs=$taskProbeClock.Elapsed.TotalMilliseconds;[Console]::Error.WriteLine('RF312-STAGE '+($meta|ConvertTo-Json -Depth 5 -Compress))}
ProbeEvent 'script-start' @{}
function Invoke-ProbeCim {param($ClassName,$Filter,$Property)
 $script:taskProbeIndex++;$taskIndex=$script:taskProbeIndex;$taskClock=[Diagnostics.Stopwatch]::StartNew()
 $taskMeta=@{index=$taskIndex;commandLineQuery=($Property -contains 'CommandLine');filtered=!!$Filter;requestedPidCount=([regex]::Matches([string]$Filter,'ProcessId\\s*=\\s*[0-9]+')).Count}
 ProbeEvent 'cim-start' $taskMeta
 if($Filter){$taskRows=@(Get-CimInstance -ClassName $ClassName -Filter $Filter -Property $Property)}else{$taskRows=@(Get-CimInstance -ClassName $ClassName -Property $Property)}
 $taskMeta=@{index=$taskIndex;commandLineQuery=($Property -contains 'CommandLine');filtered=!!$Filter;requestedPidCount=([regex]::Matches([string]$Filter,'ProcessId\\s*=\\s*[0-9]+')).Count;returnedRows=$taskRows.Count;elapsedMs=$taskClock.Elapsed.TotalMilliseconds}
 ProbeEvent 'cim-end' $taskMeta
 $taskRows
}
`;
function instrument(){
 const source=api.PROCESS_SCRIPT.replaceAll('Get-CimInstance','Invoke-ProbeCim');
 return prefix+source.replace('$result | ConvertTo-Json -Depth 5 -Compress',"ProbeEvent 'serialization-start' @{}\n$result | ConvertTo-Json -Depth 5 -Compress\nProbeEvent 'serialization-end' @{}");
}
async function trial(kind,index,owner){
 const script=instrument(kind==='candidate'),started=performance.now(),events=[];let spawnedMs=null,firstStageMs=null;
 await writeFile(path.join(stage,`trial-${index}-${kind}.ps1`),'\ufeff'+script,{flag:'wx'});
 const child=spawn('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{windowsHide:true,env:{...env,SOLOSOUL_NATIVE_PERF_PID:String(owner.child.pid),SOLOSOUL_NATIVE_PERF_EXE:options.exe,SOLOSOUL_NATIVE_PERF_STARTED:String(owner.expected.startedAt),SOLOSOUL_NATIVE_PERF_ACTION:'sample',SOLOSOUL_NATIVE_PERF_WEBVIEW_ROOT:api.normalizeWindowsPath(owner.expected.webview),SOLOSOUL_NATIVE_PERF_BROWSER_DATA_DIRECTORY:api.normalizeWindowsPath(path.join(owner.expected.webview,'EBWebView'))}});
 const stdout=[],stderr=[];let buffered='',timedOut=false,bytes=0;
 child.once('spawn',()=>spawnedMs=performance.now()-started);
 child.stdout.on('data',d=>{stdout.push(d);bytes+=d.length;if(bytes>1048576)child.kill();});
 child.stderr.on('data',d=>{stderr.push(d);bytes+=d.length;if(bytes>1048576)child.kill();buffered+=d.toString();for(;;){const at=buffered.indexOf('\n');if(at<0)break;const line=buffered.slice(0,at).trim();buffered=buffered.slice(at+1);if(line.startsWith('RF312-STAGE ')){firstStageMs??=performance.now()-started;events.push(JSON.parse(line.slice(12)));}}});
 const timer=setTimeout(()=>{timedOut=true;child.kill();},15000);
 const exit=await new Promise(resolve=>{child.once('error',e=>resolve({error:api.safeError(e)}));child.once('close',(code,signal)=>resolve({exitCode:code,signal}));});clearTimeout(timer);
 const output=Buffer.concat(stdout),errors=Buffer.concat(stderr);await writeFile(path.join(stage,`trial-${index}-${kind}.stdout.log`),output,{flag:'wx'});await writeFile(path.join(stage,`trial-${index}-${kind}.stderr.log`),errors,{flag:'wx'});
 let raw=null;if(exit.exitCode===0)raw=JSON.parse(output.toString().replace(/^\uFEFF/,'').trim());
 const record={kind,index,pid:child.pid,timeoutMs:15000,timedOut,...exit,elapsedMs:performance.now()-started,spawnedMs,firstStageMs,events,rootVerified:raw?.rootVerified??false,userDataDirectoryMatches:raw?.userDataDirectoryMatches??false,ownedProcessCount:raw?.processes?.length??null};
 if(raw){for(const row of api.verifiedOwnedRows(raw,owner.expected))owner.known.set(row.pid+':'+row.creationMs,row);if(raw.unverifiedDescendants)owner.unverifiedDescendants=true;}
 await save(`trial-${index}-${kind}.json`,record);return record;
}
let owner,completion,report={scope:'implemented-default-batched-query-regression-no-login-no-scan',exeSha256:build.sha256,trials:[]};
try{
 const prep=api.startChild(options.exe,['--native-perf-media-prepare',root,'--fixture',options.fixture],env);report.prepare=await api.deadline(prep.completion,120000,'Read-only attribution preparation');if(report.prepare.exitCode!==0)throw Error('Prepare failed');
 const owned=api.preparedManifest(JSON.parse(await readFile(path.join(root,'native-perf-owned.json'),'utf8')),root,options.manifest,options.fixture);report.owned=owned;
 const port=await api.unusedPort(),at=Date.now(),launch=api.startChild(options.exe,['--native-perf-root',root,'--native-perf-port',String(port),'--native-perf-journey','sdk-ocr'],env);completion=launch.completion;owner=new api.OwnedProcess(launch.child,options.exe,at,owned.webview);report.pid=launch.child.pid;
 let bound=null;const begin=Date.now();while(Date.now()-begin<65000){if(launch.child.exitCode!==null)throw Error('Root exited before SDK binding');try{bound=JSON.parse(await readFile(path.join(root,'native-perf-sdk-journey-bound.json'),'utf8'));break;}catch(e){if(e.code!=='ENOENT')throw e;}await new Promise(r=>setTimeout(r,100));}
 report.bound=sdk.checkBound(bound,owned,launch.child.pid,port);
 report.seed=await owner.sample({confirmExitedDescendants:true});await save('initial-owned-seed.json',report.seed);if(report.seed.reason!==null||!report.seed.userDataDirectoryMatches)throw Error('Initial batched ownership seed rejected');
 report.defaultSamples=[];for(let index=1;index<=2;index++){const at=performance.now();const snapshot=await owner.sample();report.defaultSamples.push({index,elapsedMs:performance.now()-at,snapshot});await save('default-sample-'+index+'.json',report.defaultSamples.at(-1));if(snapshot.reason!==null||!snapshot.userDataDirectoryMatches)throw Error('Actual strict default sample rejected');}
 for(const kind of ['implemented','implemented']){const value=await trial(kind,report.trials.length+1,owner);report.trials.push(value);process.stdout.write(JSON.stringify(value)+'\n');}
}catch(e){report.error=api.safeError(e);}
finally{if(owner){report.cleanup=await owner.cleanup();report.exit=await api.deadline(completion,15000,'Owned attribution root exit').catch(e=>({exitCode:null,error:api.safeError(e)}));report.cleanupIntegrity=api.cleanupOutcome(report.cleanup,report.exit);}await save('actual-query-attribution.json',report);}
if(report.error||!report.cleanupIntegrity?.complete)process.exitCode=1;
