﻿$taskProbeClock=[Diagnostics.Stopwatch]::StartNew()
$script:taskProbeIndex=0
function ProbeEvent($kind,$meta){$meta.kind=$kind;$meta.scriptElapsedMs=$taskProbeClock.Elapsed.TotalMilliseconds;[Console]::Error.WriteLine('RF312-STAGE '+($meta|ConvertTo-Json -Depth 5 -Compress))}
ProbeEvent 'script-start' @{}
function Invoke-ProbeCim {param($ClassName,$Filter,$Property)
 $script:taskProbeIndex++;$taskIndex=$script:taskProbeIndex;$taskClock=[Diagnostics.Stopwatch]::StartNew()
 $taskMeta=@{index=$taskIndex;commandLineQuery=($Property -contains 'CommandLine');filtered=!!$Filter;requestedPidCount=([regex]::Matches([string]$Filter,'ProcessId\s*=\s*[0-9]+')).Count}
 ProbeEvent 'cim-start' $taskMeta
 if($Filter){$taskRows=@(Get-CimInstance -ClassName $ClassName -Filter $Filter -Property $Property)}else{$taskRows=@(Get-CimInstance -ClassName $ClassName -Property $Property)}
 $taskMeta=@{index=$taskIndex;commandLineQuery=($Property -contains 'CommandLine');filtered=!!$Filter;requestedPidCount=([regex]::Matches([string]$Filter,'ProcessId\s*=\s*[0-9]+')).Count;returnedRows=$taskRows.Count;elapsedMs=$taskClock.Elapsed.TotalMilliseconds}
 ProbeEvent 'cim-end' $taskMeta
 $taskRows
}

$ErrorActionPreference = 'Stop'
$expectedPid = [int][Environment]::GetEnvironmentVariable('SOLOSOUL_NATIVE_PERF_PID')
$expectedExe = [Environment]::GetEnvironmentVariable('SOLOSOUL_NATIVE_PERF_EXE')
$expectedStarted = [long][Environment]::GetEnvironmentVariable('SOLOSOUL_NATIVE_PERF_STARTED')
$action = [Environment]::GetEnvironmentVariable('SOLOSOUL_NATIVE_PERF_ACTION')
$all = @(Invoke-ProbeCim Win32_Process -Property ProcessId,ParentProcessId,CreationDate,ExecutablePath,Name)
function Identity($row) {
  if (!$row.CreationDate -or !$row.ExecutablePath) { return $null }
  $created = ([DateTimeOffset]$row.CreationDate.ToUniversalTime()).ToUnixTimeMilliseconds()
  return @{pid=[int]$row.ProcessId; parentPid=[int]$row.ParentProcessId; creationMs=$created; executablePath=[string]$row.ExecutablePath; name=[string]$row.Name}
}
if ($action -eq 'cleanup') {
  # PowerShell 5.1 ConvertFrom-Json在管道中返回一个JSON数组对象；直接@(...)会嵌套。
  $parsedKnown = [Environment]::GetEnvironmentVariable('SOLOSOUL_NATIVE_PERF_KNOWN') | ConvertFrom-Json
  $known = @($parsedKnown)
  $results = @()
  $waits = @()
  $cleanupDeadline = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() + 5000
  foreach ($owned in $known) {
    $row = $all | Where-Object { [int]$_.ProcessId -eq [int]$owned.pid } | Select-Object -First 1
    $identity = if ($row) { Identity $row } else { $null }
    if (!$row) { $results += @{pid=$owned.pid; status='already-exited'}; continue }
    if (!$identity) { $results += @{pid=$owned.pid; status='unverifiable-not-terminated'}; continue }
    if ($identity.creationMs -ne [long]$owned.creationMs -or $identity.executablePath -ine [string]$owned.executablePath) {
      $results += @{pid=$owned.pid; status='identity-changed-not-terminated'}; continue
    }
    try {
      $process = [Diagnostics.Process]::GetProcessById([int]$owned.pid)
      $actualStarted = ([DateTimeOffset]$process.StartTime.ToUniversalTime()).ToUnixTimeMilliseconds()
      if ($actualStarted -ne [long]$owned.creationMs) { throw 'Process identity changed' }
      $process.Kill()
      $results += @{pid=$owned.pid; status='termination-pending'}
      $waits += @{process=$process; resultIndex=$results.Count-1}
    } catch { $results += @{pid=$owned.pid; status='termination-failed'} }
  }
  # 所有已验证进程共享5秒退出预算，避免N个进程串行等待5*N秒。
  foreach ($pending in $waits) {
    try {
      $remaining = [int][Math]::Max(0, $cleanupDeadline - [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds())
      $pending.process.WaitForExit($remaining) | Out-Null
      if ($pending.process.HasExited) { $results[$pending.resultIndex].status = 'terminated' }
    } catch { $results[$pending.resultIndex].status = 'termination-failed' }
    finally { $pending.process.Dispose() }
  }
  @{cleanup=$results} | ConvertTo-Json -Depth 5 -Compress
  exit 0
}
$root = $all | Where-Object { [int]$_.ProcessId -eq $expectedPid } | Select-Object -First 1
$identity = if ($root) { Identity $root } else { $null }
if (!$identity -or $identity.executablePath -ine $expectedExe -or [Math]::Abs($identity.creationMs-$expectedStarted) -gt 10000) {
  @{rootVerified=$false; reason='Root process exited or identity cannot be verified'; processes=@()} | ConvertTo-Json -Depth 5 -Compress
  exit 0
}
$owned = @{$expectedPid=$identity}
$unverifiedDescendants = $false
$ownershipRefreshes = @()
$refreshedMissing = @{}
$confirmedAbsent = @{}
do {
  $added = $false
  foreach ($row in $all) {
    $parent = [int]$row.ParentProcessId
    $pidValue = [int]$row.ProcessId
    if ($owned.ContainsKey($pidValue) -or !$owned.ContainsKey($parent)) { continue }
    if ($confirmedAbsent.ContainsKey($pidValue)) { continue }
    $child = Identity $row
    if (!$child -and $action -eq 'memory-series') {
      # startup CIM 行可能先出现 PID，随后才有路径。每个缺字段候选至多复核一次，绝不读取未核验进程内存。
      if (!$refreshedMissing.ContainsKey($pidValue)) {
        $refreshedMissing[$pidValue] = $null
        try {
          $freshRows = @(Invoke-ProbeCim Win32_Process -Filter ("ProcessId = " + $pidValue) -Property ProcessId,ParentProcessId,CreationDate,ExecutablePath,Name)
          if ($freshRows.Count -eq 0) {
            $confirmedAbsent[$pidValue] = $true
            $ownershipRefreshes += @{pid=$pidValue;parentPid=$parent;status='candidate-confirmed-absent';creationMs=$null}
          } elseif ($freshRows.Count -eq 1) {
            $freshChild = Identity $freshRows[0]
            if ($freshChild -and $freshChild.parentPid -eq $parent -and $freshChild.creationMs -ge $owned[$parent].creationMs) {
              $refreshedMissing[$pidValue] = $freshChild
              $ownershipRefreshes += @{pid=$pidValue;parentPid=$parent;status='candidate-fresh-identity-verified';creationMs=$freshChild.creationMs}
            }
          }
        } catch { }
      }
      if ($confirmedAbsent.ContainsKey($pidValue)) { continue }
      $child = $refreshedMissing[$pidValue]
    }
    if (!$child) { $unverifiedDescendants = $true; continue }
    if ($child -and $child.creationMs -ge $owned[$parent].creationMs) { $owned[$pidValue]=$child; $added=$true }
  }
} while ($added)
# 身份未完整记录就消失的候选不能承接活后代归属；沿原发现树有界核对，活孤儿继续拒绝。
if ($action -eq 'memory-series') {
  do {
    $absentAdded = $false
    foreach ($row in $all) {
      $pidValue = [int]$row.ProcessId
      $parent = [int]$row.ParentProcessId
      if (!$confirmedAbsent.ContainsKey($parent) -or $confirmedAbsent.ContainsKey($pidValue)) { continue }
      try {
        $remaining = @(Invoke-ProbeCim Win32_Process -Filter ("ProcessId = " + $pidValue) -Property ProcessId,CreationDate,ExecutablePath)
        if ($remaining.Count -eq 0) {
          $confirmedAbsent[$pidValue] = $true
          $ownershipRefreshes += @{pid=$pidValue;parentPid=$parent;status='candidate-confirmed-absent';creationMs=$null}
          $absentAdded = $true
        } else { $unverifiedDescendants = $true }
      } catch { $unverifiedDescendants = $true }
    }
  } while ($absentAdded)
}
$browserChecks = @()
$expectedWebview = [Environment]::GetEnvironmentVariable('SOLOSOUL_NATIVE_PERF_WEBVIEW_ROOT')
$expectedBrowserData = [Environment]::GetEnvironmentVariable('SOLOSOUL_NATIVE_PERF_BROWSER_DATA_DIRECTORY')
function NormalizePath($value) {
  $value = [string]$value
  if ($value.StartsWith('\\?\UNC\')) { $value = '\\' + $value.Substring(8) }
  elseif ($value.StartsWith('\\?\')) { $value = $value.Substring(4) }
  return [IO.Path]::GetFullPath($value).TrimEnd('\').ToLowerInvariant()
}
if ($expectedWebview -and $expectedBrowserData) {
  $ownedBrowsers = @($owned.Values | Where-Object { $_.name -ieq 'msedgewebview2.exe' })
  $browserDetails = @()
  if ($action -eq 'memory-series' -and $ownedBrowsers.Count -gt 0) {
    # 仅对已核验的PID集合读取命令行；不在全进程查询中增加CommandLine，不缓存归属。
    $ownedFilter = ($ownedBrowsers | ForEach-Object { "ProcessId = " + [int]$_.pid }) -join ' OR '
    $browserDetails = @(Invoke-ProbeCim Win32_Process -Filter $ownedFilter -Property ProcessId,CreationDate,ExecutablePath,CommandLine)
  }
  foreach ($ownedBrowser in $ownedBrowsers) {
    # 仅已验证的自有WebView2后代才读取CommandLine，且不输出原始内容或非受控路径。
    if ($action -eq 'memory-series') {
      $matchingDetails = @($browserDetails | Where-Object { [int]$_.ProcessId -eq $ownedBrowser.pid })
      if ($matchingDetails.Count -ne 1) { continue }
      $details = $matchingDetails[0]
    } else {
      $details = Invoke-ProbeCim Win32_Process -Filter ("ProcessId = " + $ownedBrowser.pid) -Property ProcessId,CreationDate,ExecutablePath,CommandLine
    }
    $detailsIdentity = Identity $details
    if (!$detailsIdentity -or $detailsIdentity.creationMs -ne $ownedBrowser.creationMs -or $detailsIdentity.executablePath -ine $ownedBrowser.executablePath) { continue }
    $command = [string]$details.CommandLine
    if ($command -match '(?:^|\s)--type(?:=|\s)') { continue }
    $match = [regex]::Match($command, '(?:^|\s)--user-data-dir(?:=|\s+)(?:"(?<quoted>[^"]+)"|(?<bare>[^\s]+))')
    $matchesExpected = $false
    if ($match.Success) {
      $candidate = if ($match.Groups['quoted'].Success) { $match.Groups['quoted'].Value } else { $match.Groups['bare'].Value }
      try { $matchesExpected = (NormalizePath $candidate) -eq (NormalizePath $expectedBrowserData) } catch {}
    }
    $browserChecks += @{pid=$ownedBrowser.pid; apiUserDataFolder=$expectedWebview; expectedBrowserDataDirectory=$expectedBrowserData; matchesExpected=$matchesExpected; observedDirectory=if($matchesExpected){$candidate}else{$null}; reason=if($matchesExpected){$null}else{'Browser user-data-dir missing or not the exact prepared UDF/EBWebView directory; unexpected path redacted'}}
  }
}
$browserDataMatched = !$unverifiedDescendants -and $browserChecks.Count -eq 1 -and $browserChecks[0].matchesExpected
$processes = @()
foreach ($row in $owned.Values) {
  $workingSet = $null; $privateBytes = $null; $cpuMs = $null; $reason = $null
  $memoryStatus = $null; $exitConfirmedAtMs = $null
  try {
    $process = [Diagnostics.Process]::GetProcessById($row.pid)
    $created = ([DateTimeOffset]$process.StartTime.ToUniversalTime()).ToUnixTimeMilliseconds()
    if ($created -ne $row.creationMs) { throw 'Process identity changed' }
    $workingSet = $process.WorkingSet64; $privateBytes=$process.PrivateMemorySize64; $cpuMs=$process.TotalProcessorTime.TotalMilliseconds
  } catch {
    $reason = 'Process memory or identity unavailable'
  }
  # 短命进程的内存属性可能为空但不抛异常；仅连续采样将此情况纳入同一次退出核验。
  if ($action -eq 'memory-series' -and ($reason -or $null -eq $workingSet -or $null -eq $privateBytes)) {
    if (!$reason) { $reason = 'Process memory reading incomplete' }
    # 一次固定 fresh CIM 核验仍有 PID 时拒绝；根进程和默认采样不走后代退出确认。
    if ($row.pid -ne $expectedPid) {
      try {
        $remaining = @(Invoke-ProbeCim Win32_Process -Filter ("ProcessId = " + $row.pid) -Property ProcessId,CreationDate,ExecutablePath)
        if ($remaining.Count -eq 0) {
          $workingSet = $null; $privateBytes = $null; $cpuMs = $null
          $memoryStatus = 'confirmed-exited'
          $exitConfirmedAtMs = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
          $reason = 'Process exited before memory collection; absence confirmed by fresh CIM'
        }
      } catch { }
    }
  }
  $values = @{workingSetBytes=$workingSet; privateBytes=$privateBytes; cpuMs=$cpuMs; reason=$reason}
  if ($memoryStatus) { $values.memoryStatus=$memoryStatus; $values.exitConfirmedAtMs=$exitConfirmedAtMs }
  $processes += $row + $values
}
$result = @{rootVerified=$true; reason=$null; processes=$processes; browserDataChecks=$browserChecks; userDataDirectoryMatches=$browserDataMatched; unverifiedDescendants=$unverifiedDescendants}
if ($action -eq 'memory-series') { $result.ownershipRefreshes=$ownershipRefreshes }
ProbeEvent 'serialization-start' @{}
$result | ConvertTo-Json -Depth 5 -Compress
ProbeEvent 'serialization-end' @{}
