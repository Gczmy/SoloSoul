import sys,json,os,subprocess,time,hashlib,shutil,datetime
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
repo=Path('C:/Users/40299571/SoloSoul')
ta=repo/'tauri'
stage=Path('C:/Users/40299571/AppData/Local/Temp/ss-rf312-media-20261005')
receipt=json.loads((stage/'media-release-build.json').read_text(encoding='utf-8'))
assert receipt['exitCode']==0
freeze=json.loads((stage/'frozen-inputs.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((ta/p).read_bytes()).hexdigest()==h for p,h in freeze.items())
target=Path(json.loads((stage/'cargo-target.json').read_text(encoding='utf-8'))['targetDirectory'])
bin_dir=stage/'bin';bin_dir.mkdir(exist_ok=False)
exe=bin_dir/'perf_baseline.exe';shutil.copyfile(target/'release/examples/perf_baseline.exe',exe)
exe_sha=hashlib.sha256(exe.read_bytes()).hexdigest()
(stage/'release-executable.json').write_text(json.dumps({'path':str(exe),'sha256':exe_sha,'bytes':exe.stat().st_size,'inputs':freeze,'build':receipt},indent=2),encoding='utf-8')
def snapshot(base):return {p.relative_to(base).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in base.rglob('*') if p.is_file()}
protected=Path('C:/Users/40299571/AppData/Local/Temp/solosoul-rf312-native-fixtures-20260930')
protected_before=snapshot(protected)
assert len(protected_before)==14
results=[]
def run(name,args,expected=0,secure='1'):
 env=os.environ.copy();env['SOLOSOUL_SECURE']=secure
 command=[str(exe),*map(str,args)];started=time.monotonic()
 with (stage/(name+'.stdout.log')).open('wb') as out,(stage/(name+'.stderr.log')).open('wb') as err:
  result=subprocess.run(command,cwd=ta,env=env,stdout=out,stderr=err)
 record={'name':name,'command':command,'environment':{'SOLOSOUL_SECURE':secure},'exitCode':result.returncode,'expectedExitCode':expected,'durationSeconds':time.monotonic()-started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout':name+'.stdout.log','stderr':name+'.stderr.log'}
 if result.returncode==0:
  lines=(stage/(name+'.stdout.log')).read_text(encoding='utf-8-sig').splitlines()
  parsed=json.loads([l for l in lines if l.startswith('{')][-1]);assert parsed['success']
  record['result']=parsed
 (stage/(name+'.json')).write_text(json.dumps(record,indent=2),encoding='utf-8')
 results.append(record);print(json.dumps({'name':name,'exitCode':result.returncode,'expected':expected,'seconds':record['durationSeconds']}),flush=True)
 assert result.returncode==expected,record
 return record
for count in [100,5000]:run('generate-'+str(count),['--media-fixture-output',stage/('vault'+str(count)),'--objects',count])
source_before={n:snapshot(stage/('vault'+str(n))) for n in [100,5000]}
for count in [100,5000]:run('verify-'+str(count),['--verify-media-fixture',stage/('vault'+str(count))])
for count in [100,5000]:run('copy-'+str(count),['--copy-media-fixture',stage/('vault'+str(count)),'--media-fixture-output',stage/('copy'+str(count))])
for count in [100,5000]:run('verify-copy-'+str(count),['--verify-media-fixture',stage/('copy'+str(count))])
copy_before=snapshot(stage/'copy100')
run('reject-existing-output',['--copy-media-fixture',stage/'vault100','--media-fixture-output',stage/'copy100'],1)
run('reject-relative-output',['--media-fixture-output','relative-output','--objects','100'],1)
run('reject-mixed-mode',['--verify-media-fixture',stage/'vault100','--objects','100'],1)
run('reject-development-release-kdf',['--media-fixture-output',stage/'must-not-exist-dev','--objects','100'],1,'0')
assert not (stage/'must-not-exist-dev').exists()
assert not (ta/'relative-output').exists()
assert snapshot(stage/'copy100')==copy_before
run('legacy-control-generate',['--fixture-output',stage/'legacy100-control','--objects','100'])
run('legacy-control-verify',['--verify-fixture',stage/'legacy100-control'])
assert json.loads((stage/'legacy100-control/rf312-fixture.json').read_text(encoding='utf-8'))==json.loads((protected/'vault100/rf312-fixture.json').read_text(encoding='utf-8'))
for n,original in source_before.items():assert snapshot(stage/('vault'+str(n)))==original
assert snapshot(protected)==protected_before
assert hashlib.sha256(exe.read_bytes()).hexdigest()==exe_sha
assert all(hashlib.sha256((ta/p).read_bytes()).hexdigest()==h for p,h in freeze.items())
summary={'scope':'public-media-fixture-real-release-generation-and-read-only-reopen','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'executableSha256':exe_sha,'positiveCases':10,'expectedRejections':4,'objects':[100,5000],'attachmentsEach':4,'allSourceFilesUnchanged':True,'legacy14FilesUnchanged':True,'legacyContractEqualToFrozenV1':True,'existingOutputUnchangedOnRejection':True,'developmentKdfRejectedBeforeOutputCreation':True,'nativeUiMeasured':False,'performanceMeasured':False,'results':results,'preservedPaths':[str(stage/p) for p in ['vault100','vault5000','copy100','copy5000','legacy100-control','bin']]}
(stage/'release-fixture-acceptance.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['results','preservedPaths']}),flush=True)
