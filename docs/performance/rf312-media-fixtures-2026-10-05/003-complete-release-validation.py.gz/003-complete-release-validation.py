import sys,json,os,subprocess,time,hashlib,shutil,datetime
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
repo=Path('C:/Users/40299571/SoloSoul');ta=repo/'tauri'
stage=Path('C:/Users/40299571/AppData/Local/Temp/ss-rf312-media-20261005')
assert json.loads((stage/'media-debug-build.json').read_text(encoding='utf-8'))['exitCode']==0
freeze=json.loads((stage/'frozen-inputs.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((ta/p).read_bytes()).hexdigest()==h for p,h in freeze.items())
release=stage/'bin/perf_baseline.exe'
release_receipt=json.loads((stage/'release-executable.json').read_text(encoding='utf-8'))
assert hashlib.sha256(release.read_bytes()).hexdigest()==release_receipt['sha256']
debug=stage/'bin/perf_baseline_debug.exe'
assert not debug.exists();shutil.copyfile(ta/'target/debug/examples/perf_baseline.exe',debug)
(stage/'debug-executable.json').write_text(json.dumps({'path':str(debug),'sha256':hashlib.sha256(debug.read_bytes()).hexdigest(),'bytes':debug.stat().st_size},indent=2),encoding='utf-8')
def snapshot(base):return {p.relative_to(base).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in base.rglob('*') if p.is_file()}
results=[]
for name in ['generate-100','generate-5000','verify-100','verify-5000','copy-100','copy-5000','verify-copy-100','verify-copy-5000','reject-existing-output','reject-relative-output','reject-mixed-mode']:
 rec=json.loads((stage/(name+'.json')).read_text(encoding='utf-8'))
 assert rec['exitCode']==rec['expectedExitCode']
 if rec['exitCode']==0:assert rec['result']['success']
 results.append(rec)
source_before={}
for n,prefix in [(100,'verify-'),(5000,'verify-'),(100,'verify-copy-'),(5000,'verify-copy-')]:
 rec=json.loads((stage/(prefix+str(n)+'.json')).read_text(encoding='utf-8'))
 directory=stage/(('copy' if 'copy' in prefix else 'vault')+str(n))
 expected={f['relativePath']:f['sha256'] for f in rec['result']['verification']['sourceFileProofs']}
 assert snapshot(directory)==expected
 source_before[str(directory)]=expected
protected=Path('C:/Users/40299571/AppData/Local/Temp/solosoul-rf312-native-fixtures-20260930')
baseline=json.loads((stage/'baseline.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in baseline['oldFixtures'].items())
def run(name,args,exe=release,expected=0,secure='1'):
 env=os.environ.copy()
 if secure is None:env.pop('SOLOSOUL_SECURE',None)
 else:env['SOLOSOUL_SECURE']=secure
 command=[str(exe),*map(str,args)];started=time.monotonic()
 with (stage/(name+'.stdout.log')).open('wb') as out,(stage/(name+'.stderr.log')).open('wb') as err:r=subprocess.run(command,cwd=ta,env=env,stdout=out,stderr=err)
 record={'name':name,'command':command,'environment':{'SOLOSOUL_SECURE':secure},'exitCode':r.returncode,'expectedExitCode':expected,'durationSeconds':time.monotonic()-started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout':name+'.stdout.log','stderr':name+'.stderr.log'}
 if r.returncode==0:
  lines=(stage/(name+'.stdout.log')).read_text(encoding='utf-8-sig').splitlines()
  record['result']=json.loads([l for l in lines if l.startswith('{')][-1]);assert record['result']['success']
 (stage/(name+'.json')).write_text(json.dumps(record,indent=2),encoding='utf-8')
 results.append(record);print(json.dumps({'name':name,'exitCode':r.returncode,'expected':expected,'seconds':record['durationSeconds']}),flush=True)
 assert r.returncode==expected
 return record
run('legacy-control-generate',['--fixture-output',stage/'legacy100-control','--objects','100'])
run('legacy-control-verify',['--verify-fixture',stage/'legacy100-control'])
assert json.loads((stage/'legacy100-control/rf312-fixture.json').read_text(encoding='utf-8'))==json.loads((protected/'vault100/rf312-fixture.json').read_text(encoding='utf-8'))
unset=run('release-default-production',['--media-fixture-output',stage/'release-default-100','--objects','100'],secure=None)
assert unset['result']['manifest']['baseFixture']['kdf']=={'memoryKiB':65536,'iterations':3,'parallelism':4}
production_zero=json.loads((stage/'reject-development-release-kdf.json').read_text(encoding='utf-8'))
assert production_zero['exitCode']==0 and production_zero['result']['manifest']['baseFixture']['kdf']=={'memoryKiB':65536,'iterations':3,'parallelism':4}
dev=run('debug-development-generate',['--media-fixture-output',stage/'debug-development-100','--objects','100'],exe=debug,secure='0')
assert dev['result']['manifest']['baseFixture']['kdf']=={'memoryKiB':8192,'iterations':2,'parallelism':4}
dev_before=snapshot(stage/'debug-development-100')
run('release-reject-real-development-verify',['--verify-media-fixture',stage/'debug-development-100'],expected=1)
run('release-reject-real-development-copy',['--copy-media-fixture',stage/'debug-development-100','--media-fixture-output',stage/'must-not-exist-rejected-copy'],expected=1)
assert not (stage/'must-not-exist-rejected-copy').exists()
assert snapshot(stage/'debug-development-100')==dev_before
for p,expected in source_before.items():assert snapshot(Path(p))==expected
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in baseline['oldFixtures'].items())
assert all(hashlib.sha256((ta/p).read_bytes()).hexdigest()==h for p,h in freeze.items())
summary={'scope':'public-media-fixture-real-release-generation-and-read-only-reopen','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'executableSha256':release_receipt['sha256'],'positiveReleaseCases':11,'positiveDebugPrerequisiteCases':1,'expectedRejections':5,'objects':[100,5000],'attachmentsEach':4,'allSourceFilesUnchanged':True,'legacy14FilesUnchanged':True,'legacyContractEqualToFrozenV1':True,'existingOutputUnchangedOnRejection':True,'developmentFixtureRejectedBeforeOutputCreation':True,'releaseDefaultAndSecureZeroBothProduction':True,'historicalFailures':['release-driver-first-failure.json'],'nativeUiMeasured':False,'performanceMeasured':False,'results':results,'preservedPaths':[str(stage/p) for p in ['vault100','vault5000','copy100','copy5000','legacy100-control','release-default-100','must-not-exist-dev','debug-development-100','bin']]}
(stage/'release-fixture-acceptance.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['results','preservedPaths']}),flush=True)
