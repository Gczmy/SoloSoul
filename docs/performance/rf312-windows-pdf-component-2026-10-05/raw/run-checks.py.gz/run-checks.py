import subprocess,pathlib,time,json,datetime,sys,os
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-component-20261005')
env=os.environ.copy();env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','')
def run(name,args,cwd=None):
 started=time.time()
 with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
  c=subprocess.Popen(args,cwd=cwd or r/'tauri',env=env,stdout=out,stderr=err)
  (s/(name+'.live.json')).write_text(json.dumps({'pid':c.pid,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}),encoding='utf-8')
  print('Started '+name+' PID '+str(c.pid),flush=True);rc=c.wait()
 receipt={'command':args,'pid':c.pid,'exitCode':rc,'elapsedSeconds':time.time()-started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (s/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt),flush=True)
 if rc: raise SystemExit(rc)
js=['scripts/native-perf-sdk-journey.mjs','scripts/native-perf-pdf-contract.mjs','scripts/native-perf-pdf-diagnostic.mjs','scripts/native-perf-pdf.test.mjs','scripts/run-node-tests.mjs','src-tauri/src/native_perf/sdk_pdf_dom.js','src-tauri/src/native_perf/sdk_pdf_viewer.js']
run('component-fmt-write',['cargo','+1.99.0','fmt','--all'])
run('component-js-format-write',['node','node_modules/prettier/bin/prettier.cjs','--write',*js])
run('component-native-tests',['cargo','test','--locked','-p','solo_soul','--features','native-perf','--lib','native_perf','--','--test-threads=1'])
run('component-native-clippy',['cargo','clippy','--locked','-p','solo_soul','--features','native-perf','--all-targets','--','-D','warnings'])
run('component-fmt-check',['cargo','+1.99.0','fmt','--all','--','--check'])
run('component-node-tests',['node','scripts/run-node-tests.mjs'])
run('component-js-format-check',['node','node_modules/prettier/bin/prettier.cjs','--check',*js])
run('component-diff-check',['git','-c','safe.directory='+r.as_posix(),'-c','core.safecrlf=false','diff','--check'],r)
