from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');T=R/'build';B=Path(__file__).parent
old='rf312-current-windows-pdf-diagnostic-retry1-20261014'
new='rf1149-current-windows-pdf-preview-20261014';S=T/new
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for phase in ['fmt','native-clippy','native-tests','native-release','node-format','node-full']:
    receipt=load(B/(phase+'.receipt.json'))
    assert receipt['exitCode']==0 and receipt['sourceUnchanged']
package=load(B/'runtime-package.json');sources=load(B/'sources.json')
assert len(sources)==1984 and all(sha(R/n)==h for n,h in sources.items())
assert sha(Path(package['exe']))==package['sha256']
assert len(package['resources'])==94
assert all(sha(Path(r['source']))==sha(Path(r['copy']))==r['sha256'] for r in package['resources'])
prior=load(T/old/'input-proof.json');fixtures=prior['fixtures']
for fixture in fixtures:
    p=Path(fixture['path'])
    assert {f.relative_to(p).as_posix():sha(f) for f in p.rglob('*') if f.is_file()}==fixture['files']
proof=dict(task='RF-1149',mode='pdf-preview',samplesPerDataset=3,memoryIntervalMs=None,
    validationHead='58f585a68',sourceHasUncommittedRf1149Fix=True,sources=sources,runtime=package,
    fixtures=fixtures,publicMediaFixtureSource=prior['publicMediaFixtureSource'],
    currentSchemaVersion=3,currentFixedViewport=[1200,831],currentFixedRoi=[266,221,430,36],
    historicalSchemaVersion=2,historicalFixedViewport=[1028,749],historicalFixedRoi=[180,225,430,36],
    originalReferenceAndMaskUnchanged=True,fullRF312Accepted=False,goal='active',
    originalGuardsAndBudgetsPreserved=True,diagnosticPngsNotPerformanceSamples=True,
    userConfirmedConnectedUnlockedAndCodexMinimized=True)
text=(T/('run-'+old+'.py')).read_text(encoding='utf-8')
assert text.count("['pdf-diagnostic']")==1
text=text.replace("['pdf-diagnostic']","['pdf-preview']")
text=text.replace(old,new)
assert 'rf312-current-windows-pdf-diagnostic-retry1-session-' in text
text=text.replace('rf312-current-windows-pdf-diagnostic-retry1-session-','rf1149-current-windows-pdf-preview-session-')
target=T/('run-'+new+'.py');compile(text,str(target),'exec')
assert not S.exists() and not target.exists()
S.mkdir(exist_ok=False)
with (S/'input-proof.json').open('x',encoding='utf-8',newline='\n') as out:
    json.dump(proof,out,indent=2);out.write('\n')
with target.open('x',encoding='utf-8',newline='\n') as out:out.write(text)
print('RF1149 current PDF first-page original CLI prepared; new actual cohorts still required')
