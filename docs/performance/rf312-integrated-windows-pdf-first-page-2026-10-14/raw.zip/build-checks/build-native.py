from pathlib import Path
import datetime, hashlib, json, os, re, shutil, struct, subprocess, time
R = Path('D:/SoloSoul'); S = Path(__file__).parent
B = R/'build/rf1147-ocr-picker-settlement-20261014'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def save(n, v):
    with (S/n).open('x', encoding='utf-8', newline='\n') as out:
        json.dump(v, out, indent=2); out.write('\n')
base = load(B/'sources.json'); sources = {n: sha(R/n) for n in base}
diff = {n: dict(compiled=h, current=sources[n]) for n,h in base.items() if h != sources[n]}
assert set(diff) == {
    'tauri/scripts/native-perf-auth-contract.mjs',
    'tauri/scripts/native-perf-auth-attribution.test.mjs',
    'tauri/scripts/native-perf-pdf-pixels.mjs',
    'tauri/scripts/native-perf-pdf-preview-contract.mjs',
    'tauri/scripts/native-perf-pdf-preview.test.mjs',
    'tauri/scripts/native-perf-sdk-journey.mjs',
    'tauri/src-tauri/src/native_perf/sdk_pdf_pixels.rs',
}
fixture = 'tauri/src-tauri/src/native_perf/fixtures/pdf-first-page-integrated.png'
assert fixture not in base
assert sha(R/fixture) == 'f85d1cb4076535fbaec6825675e0f2e26aad2167b15729230919530700283609'
sources[fixture] = sha(R/fixture)
save('sources.json', sources); save('compiled-source-differences.json', diff)
frontend = load(B/'frontend.json')
assert all(sha(R/'tauri/dist'/n) == v['sha256'] for n,v in frontend['files'].items())
save('frontend.json', frontend)
cache = R/'build/rf312-maintenance-20261009'; env = os.environ.copy()
config = dict(identifier='com.solosoul.rf312perf', bundle=dict(active=False))
save('native-build-config.json', config)
env.update(TEMP=str(cache/'tmp'), TMP=str(cache/'tmp'), CARGO_HOME=str(cache/'cargo-home'),
    CARGO_TARGET_DIR=str(cache/'cargo-target'), CARGO_BUILD_JOBS='1', ORT_CACHE_DIR=str(cache/'ort-cache'),
    PDFIUM_LIBRARY_PATH=str(R/'tauri/src-tauri/resources/pdfium/pdfium.dll'),
    PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1', TAURI_CONFIG=json.dumps(config))
env['PATH'] = 'C:/Program Files/Git/usr/bin;' + env.get('PATH','')
for key in ['TAURI_ANDROID_PROJECT_PATH','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS','SOLOSOUL_REGISTRY_PUBKEY']:
    env.pop(key, None)
cargo = 'C:/Users/40299571/.cargo/bin/cargo.exe'
def frozen():
    assert all(sha(R/n) == h for n,h in sources.items())
    assert all(sha(R/'tauri/dist'/n) == v['sha256'] for n,v in frontend['files'].items())
for name,cmd in [
    ('fmt',[cargo,'fmt','--all','--','--check']),
    ('native-clippy',[cargo,'clippy','--locked','-p','solo_soul','--all-targets','--features','native-perf','--','-D','warnings']),
    ('native-tests',[cargo,'test','--locked','-p','solo_soul','--lib','--features','native-perf','native_perf::','--','--nocapture']),
    ('native-release',[cargo,'build','--locked','--release','-p','solo_soul','--bin','solo_soul','--features','native-perf']),
]:
    frozen(); began = time.monotonic()
    with (S/(name+'.stdout.log')).open('xb') as out, (S/(name+'.stderr.log')).open('xb') as err:
        p = subprocess.Popen(cmd, cwd=R/'tauri', env=env, stdin=subprocess.DEVNULL,
            stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        print(name, 'live PID',p.pid,flush=True); code=p.wait()
    changed = [n for n,h in sources.items() if sha(R/n) != h]
    save(name+'.receipt.json',dict(exitCode=code,elapsedSeconds=time.monotonic()-began,
        changedSources=changed,sourceUnchanged=not changed,command=cmd))
    print(name, 'exit',code,flush=True)
    if code or changed: raise SystemExit(code or 1)
runtime = S/'runtime/bin'; runtime.mkdir(parents=True,exist_ok=False)
exe = runtime/'solo_soul.exe'; shutil.copyfile(cache/'cargo-target/release/solo_soul.exe',exe)
data=exe.read_bytes(); offset=struct.unpack_from('<I',data,0x3c)[0]
assert struct.unpack_from('<H',data,offset+24+68)[0] == 2
old = load(B/'runtime-package.json'); resources=[]
for row in old['resources']:
    source=Path(row['source']); dest=runtime/Path(row['copy']).relative_to(Path(old['exe']).parent)
    assert dest.resolve().is_relative_to(runtime.resolve())
    dest.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(source,dest)
    assert sha(source) == sha(dest) == row['sha256']
    resources.append(dict(source=str(source),copy=str(dest),sha256=row['sha256']))
counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
    (S/'native-tests.stdout.log').read_text(encoding='utf-8'))
assert len(counts)==1 and counts[0][1:] == ('0','0')
save('runtime-package.json',dict(exe=str(exe),sha256=sha(exe),bytes=exe.stat().st_size,
    resources=resources,sourceCount=len(sources),gitHead='58f585a68',sourceHasUncommittedRf1149Fix=True,
    sourceManifestSha256=sha(S/'sources.json'),frontendManifestSha256=sha(S/'frontend.json'),
    nativeTests=int(counts[0][0]),windowsGuiSubsystem=2,sharedFormalSetupAppUsed=True,
    guiExecuted=False,fullRF312Accepted=False,goal='active'))
frozen(); print('RF1149 native package prepared; original full PDF preview cohorts still required',flush=True)
