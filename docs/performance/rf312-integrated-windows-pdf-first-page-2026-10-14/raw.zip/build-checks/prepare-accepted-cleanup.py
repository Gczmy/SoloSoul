"""Derive the existing exact owned cleanup after independent native acceptance."""
from pathlib import Path
import json
R=Path('D:/SoloSoul');S=R/'build/rf1149-current-windows-pdf-preview-20261014'
prior=R/'build/rf312-current-windows-pdf-diagnostic-retry1-20261014'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert load(S/'terminal.json')['accepted']
verified=load(S/'independent-verification.json')
assert verified['accepted'] and verified['pdfFirstPagePerformanceAccepted']
assert verified['distinctRuns']==6 and verified['negativeControlsPerRun']==12
assert verified['allPngLengthsSha256CrcAndIndependentPixelsVerified']
proof=load(S/'input-proof.json');groups=[]
for size in [100,5000]:
    report=load(S/f'samples{size}/native-perf-sdk-journey-results.json')
    assert report['success'] and len(report['samples'])==3 and report['sourceUnchanged']
    samples=[]
    for sample in report['samples']:
        assert sample['success'] and sample['cleanupIntegrity']['complete']
        ids={(p['pid'],p['creationMs']) for n in ['beforeSnapshot','afterSnapshot'] for p in sample[n]['processes']}
        assert len(ids)>=9
        samples.append(dict(index=sample['index'],runId=sample['owned']['runId'],pid=sample['processId'],
            recordedIdentities=[dict(pid=p,creationMs=t) for p,t in sorted(ids)]))
    groups.append(dict(objects=size,terminal=True,samples=samples))
text=(prior/'cleanup-accepted-owned.ps1').read_text(encoding='utf-8')
old=str(prior);assert old in text;text=text.replace(old,str(S))
old='pdfCapabilityDiagnosticVerified';assert text.count(old)==1
text=text.replace(old,'pdfFirstPagePerformanceVerified')
old_exe='D:\\SoloSoul\\build\\rf1147-ocr-picker-settlement-20261014\\runtime\\bin\\solo_soul.exe'
assert text.count(old_exe)==1;text=text.replace(old_exe,str(Path(proof['runtime']['exe'])))
assert text.count("task='RF-312'")==1;text=text.replace("task='RF-312'","task='RF-1149'")
with (S/'accepted-cleanup-plan.json').open('x',encoding='utf-8',newline='\n') as out:
    json.dump(dict(pdfFirstPagePerformanceVerified=True,groups=groups),out,indent=2);out.write('\n')
with (S/'cleanup-accepted-owned.ps1').open('x',encoding='utf-8',newline='\n') as out:out.write(text)
print('Six independently accepted native first-page runs; original exact identity/reparse/Vault preservation cleanup prepared')
