"""Publish only independently accepted current fixed PDF first-page evidence."""
from pathlib import Path
import hashlib,json,zipfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=R/'build/rf1149-current-windows-pdf-preview-20261014'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as out:json.dump(v,out,indent=2);out.write('\n')
verified=load(S/'independent-verification.json');clean=load(S/'accepted-cache-cleanup.json')
package=load(B/'runtime-package.json');proof=load(S/'input-proof.json')
assert verified['accepted'] and verified['pdfFirstPagePerformanceAccepted']
assert not verified['fullRF312Accepted'] and verified['sourceCount']==1984
assert clean['matchingOwnedIdentitiesLive']==clean['processesTerminatedByThisTool']==0
assert clean['preservedBytesVerified'] and len(clean['removedCachePaths'])==48
assert not clean['linksUnlinked']
assert all(not Path(n).exists() for n in clean['removedCachePaths'])
assert all(sha(Path(r['path']))==r['sha256'] for r in clean['preservedVaultAndRootFiles'])
assert all(sha(Path(r['copy']))==r['sha256'] for r in clean['applicationLogs'])
assert sha(Path(package['exe']))==package['sha256']
assert len(load(B/'frontend.json')['files'])==38 and len(package['resources'])==94
assert all(sha(R/n)==h for n,h in proof['sources'].items())
assert all(sha(Path(r['source']))==sha(Path(r['copy']))==r['sha256'] for r in package['resources'])
for phase in ['fmt','native-clippy','native-tests','native-release','node-format','node-full']:
    receipt=load(B/(phase+'.receipt.json'));assert receipt['exitCode']==0 and receipt['sourceUnchanged']
assert load(B/'boundary-audit.json')['accepted']
name='rf312-integrated-windows-pdf-first-page-2026-10-14';O=R/'docs/performance'/name
assert not O.exists() and not O.with_suffix('.json').exists()
members={}
def add(n,p):
    assert n not in members and p.is_file() and not p.is_symlink() and not p.stat().st_file_attributes&0x400
    members[n]=p
for directory,prefix in [(B,'build-checks'),(S,'native-preview')]:
    for p in directory.iterdir():
        if p.is_file():add(prefix+'/'+p.name,p)
for size in [100,5000]:
    group=S/f'samples{size}';report=load(group/'native-perf-sdk-journey-results.json')
    assert report['success'] and len(report['samples'])==3
    add(f'native-preview/samples{size}/native-perf-sdk-journey-results.json',group/'native-perf-sdk-journey-results.json')
    for sample in report['samples']:
        assert sample['success'] and sample['cleanupIntegrity']['complete']
        root=group/f"sample-{sample['index']:03}"
        for p in root.iterdir():
            if p.is_file():add('native-preview/'+p.relative_to(S).as_posix(),p)
for p in (S/'application-logs').rglob('*'):
    if p.is_file():add('native-preview/'+p.relative_to(S).as_posix(),p)
for n in ['tauri/src-tauri/src/native_perf/sdk_pdf_pixels.rs','tauri/scripts/native-perf-pdf-pixels.mjs',
    'tauri/scripts/native-perf-pdf-preview-contract.mjs','tauri/scripts/native-perf-pdf-preview.test.mjs',
    'tauri/scripts/native-perf-sdk-journey.mjs','tauri/src-tauri/src/native_perf/fixtures/pdf-first-page.png',
    'tauri/src-tauri/src/native_perf/fixtures/pdf-first-page-integrated.png']:
    add('sources/'+n,R/n)
add('helpers/run-rf1149-current-windows-pdf-preview-20261014.py',R/'build/run-rf1149-current-windows-pdf-preview-20261014.py')
for size in [100,5000]:
    add(f'helpers/session-{size}.py',R/f'build/rf1149-current-windows-pdf-preview-session-{size}-20261014.py')
O.mkdir(exist_ok=False);rows=[]
with zipfile.ZipFile(O/'raw.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for n,p in sorted(members.items()):
        data=p.read_bytes();z.writestr(n,data)
        rows.append(dict(member=n,source=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(O/'raw.zip') as z:
    assert z.testzip() is None
    assert set(z.namelist())==set(members)
    for row in rows:
        data=z.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',dict(task='RF-1149',members=rows,allLengthsSha256AndCrcVerified=True,
    programsVaultsResourcesAndCachesExcluded=True,publicReferenceAndActualFirstPagePngsIncluded=True))
(O/'.gitattributes').write_text('raw.zip -text\n',encoding='utf-8',newline='\n')
artifact=dict(task='RF-1149',relatedTask='RF-312',accepted=True,fullRF312Accepted=False,goal='active',
    sourceHead='58f585a68',nativeRuntimeSha256=package['sha256'],sourceCount=1984,
    resourceCount=len(package['resources']),frontendFileCount=len(load(B/'frontend.json')['files']),
    currentFixedSchemaVersion=3,currentViewport=[1200,831],currentRoi=[266,221,430,36],
    historicalFixedSchemaVersion=2,historicalViewport=[1028,749],historicalRoi=[180,225,430,36],
    originalReferenceAndMaskUnchanged=True,unknownVersionsAndVersionGeometryMixingRejected=True,
    originalResourceTreeDocumentInputCryptoClockProtocolBudgetsPreserved=True,
    nativeTests=142,nodeTests=dict(total=266,passed=265,failed=0,existingFileSymlinkPrivilegeSkipped=1),
    independentVerification=verified,cleanup=dict(identitiesChecked=clean['identitiesChecked'],
        removedCaches=48,links=0,preservedFiles=len(clean['preservedVaultAndRootFiles']),bytesVerified=True,
        unrelatedProcessesTerminated=0),
    originalDiagnosticAndDesktopRefusalPreservedInPriorCommit='58f585a68',
    diagnosticPngsNotCountedAsPerformanceSamples=True,
    scope='fixed public PDF first-page text ROI; includes SDK/decode/poll overhead; not arbitrary PDF/all pages/DWM/default uninstrumented application/multiplatform',
    archive=dict(path=name+'/raw.zip',members=len(rows),bytes=(O/'raw.zip').stat().st_size,
        sha256=sha(O/'raw.zip'),allLengthsSha256AndCrcVerified=True))
put(O.with_suffix('.json'),artifact)
p=R/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';t=p.read_text(encoding='utf-8')
a='- 已关闭：**327 / 339**；实际修复（已关闭）：327；';assert t.count(a)==1
t=t.replace(a,'- 已关闭：**328 / 339**；实际修复（已关闭）：328；',1)
a='；暂缓：0；进行中：1；待执行：6。';assert t.count(a)==1
t=t.replace(a,'；暂缓：0；进行中：0；待执行：6。',1)
a='| 339 | [RF-1149](#rf-1149) | P2 | 固定PDF首屏测量与当前正式setup窗口几何一致 | 当前六次schema4诊断及原像素门禁拒绝 | [-] 进行中 |'
assert t.count(a)==1;t=t.replace(a,a.replace('[-] 进行中','[x] 完成'),1)
start=t.index('- 当前处理：');end=t.index('\n',start)
t=t[:start]+'- 当前处理：RF-1149双版本固定PDF几何已完成新GUI两档各三次真实首屏、独立逐图/72变造门禁及清理验收，准备独立提交。RF-121当前Windows完整矩阵和RF-312其他本地范围继续，goal active。'+t[end:]
t+='\n\n### RF-1149 验收记录（2026-10-14）\n\n'
t+='- 仅非默认Windows native-perf发布固定schema3：1200×831/ROI(266,221,430,36)；历史schema2的1028×749/ROI(180,225,430,36)及原参考SHA保持。两者使用原530像素/掩码SHA，证明版本显式决定固定解码合同，未知版本/尺寸/ROI或混用拒绝，不自动按图片选择参考。新参考为此前真实公开诊断PNG的原字节复制，诊断样本不计作性能样本。\n'
t+='- 新三个Node回归在旧入口8通过/3失败，修复后PDF定向27通过；完整Node265通过、0失败、1既有文件symlink权限跳过，原生142回归、严格Clippy和格式/Release检查均exit0。边界复核确认原生检查循环仅变化固定解码调用，原资源/稳定/计时、Node身份/输入/树/调用顺序/预算守卫保持。1984输入（显式新增原截图）、38前端产物及94资源冻结，未改默认客户端/依赖/系统权限。\n'
t+=f'- 新冻结GUI`{package["sha256"][:12]}`在100/5000各三次完整原入口均通过；6个唯一runId、实际PNG路径/长度/SHA/CRC及Node像素复核，真实关闭/认证/维护和72份实际证明变造全部按原合同核验。每档独立整组统计，不混入旧诊断或选择子集；仅固定公开正文可见的观测上界，包括SDK/解码/轮询，不宣称净渲染或任意PDF。\n'
t+=f'- fresh CIM核验{clean["identitiesChecked"]}个实际PID/birth身份退出，仅清理48个精确自有缓存、无链接，{len(clean["preservedVaultAndRootFiles"])}份公开Vault/截图/证明/日志字节保持，未停止其他进程。[结构化验收](performance/{name}.json)及[{len(rows)}成员索引](performance/{name}/index.json)长度/SHA/ZIP CRC回读通过，排除程序、资源实体、Vault及缓存。旧首次桌面拒绝/六次schema4诊断及像素拒绝在58f585a68中保持。只关闭RF-1149，累计328/339；原5待验证/6前置任务保持，goal active，继续RF-121当前矩阵和RF-312本地范围。单项独立提交。\n'
p.write_text(t,encoding='utf-8',newline='\n')
p=R/'docs/performance/RF-312-native-pdf-first-page.md';t=p.read_text(encoding='utf-8')
t+='\n\n## 2026-10-14 当前一体顶栏与RF-1149\n\n'
t+=f'当前GUI`{package["sha256"]}`使用显式schema3固定几何；100/5000各三次完整原生首屏通过，所有实际PNG由Node复核路径、长度、SHA、CRC和同一正文掩码，真实关闭、认证/维护与72个变造检查通过。原参考和历史schema2消费保留；此前六次能力诊断与旧尺寸拒绝保留且不计入本组性能样本。\n\n'
t+='每档n=3，中位/P95（ms）；P95为三次最大值，包含观测开销。\n\n| 指标 | 100对象 | 5000对象 |\n| --- | ---: | ---: |\n'
g={r['objects']:{s['name']:s for s in r['summary']} for r in verified['groupSummaries']}
for metric in ['firstMatchObservedMs','stableReadyObservedMs','captureOverheadMs','decodeOverheadMs','pollWaitMs']:
    a,b=g[100][metric],g[5000][metric]
    t+=f'| `{metric}` | {a["medianMs"]:.2f} / {a["p95Ms"]:.2f} | {b["medianMs"]:.2f} / {b["p95Ms"]:.2f} |\n'
t+=f'\n[完整验收与原始记录]({name}.json)包含1984冻结输入、38前端产物、94资源、142原生回归和完整Node检查。此项只关闭固定几何缺口及该GUI的公开首屏范围；原首页偶发超时、默认无观测程序、其他平台及RF-312整体验收保持待验证。\n'
p.write_text(t,encoding='utf-8',newline='\n')
print(json.dumps(dict(task='RF-1149',accepted=True,members=len(rows),closed='328/339',fullRF312Accepted=False)))
