from pathlib import Path
import hashlib,json,subprocess,zipfile
R=Path('D:/SoloSoul');S=Path(__file__).parent
Z=zipfile.ZipFile(R/'docs/performance/rf312-integrated-windows-pdf-diagnostic-2026-10-14/raw.zip')
def original(n):return Z.read('sources/'+n).decode().replace('\r\n','\n')
def current(n):return (R/n).read_text(encoding='utf-8')
def replace(t,a,b):
    assert t.count(a)==1,(a,t.count(a));return t.replace(a,b,1)
rust='tauri/src-tauri/src/native_perf/sdk_pdf_pixels.rs'
old=original(rust);new=current(rust)
section=lambda t,a,b:t[t.index(a):t.index(b)]
assert section(old,'fn resource_identity','async fn inspect')==section(new,'fn resource_identity','async fn inspect')
assert section(old,'async fn inspect','pub(super) async fn run').replace(
    'pixels(&bytes)?','pixels(&bytes, Geometry::Integrated)?')==section(new,'async fn inspect','pub(super) async fn run')
node='tauri/scripts/native-perf-pdf-preview-contract.mjs';t=original(node)
t=replace(t,'PDF_ASSET_SHA, PDF_MASK_SHA, PDF_VIEWPORT, PDF_ROI','PDF_ASSET_SHA, PDF_MASK_SHA, PDF_GEOMETRIES')
t=replace(t,'function dom(v, phase)','function dom(v, phase, viewport)')
t=replace(t,'v.target.x >= 1028','v.target.x >= viewport.width')
t=replace(t,'v.target.y >= 749','v.target.y >= viewport.height')
t=replace(t,'  const d = v.pdfPreview;','  const d = v.pdfPreview;\n  const geometry = PDF_GEOMETRIES[d?.schemaVersion];')
t=replace(t,'d.schemaVersion !== 2','![2, 3].includes(d.schemaVersion)')
t=replace(t,'same(d.viewport, PDF_VIEWPORT)','same(d.viewport, geometry.viewport)')
t=replace(t,'same(d.roi, PDF_ROI)','same(d.roi, geometry.roi)')
t=replace(t,'s.width !== 1028','s.width !== geometry.viewport.width')
t=replace(t,'s.height !== 749','s.height !== geometry.viewport.height')
for a,b in [("dom(s.domBefore, 'opened')","dom(s.domBefore, 'opened', geometry.viewport)"),
    ("dom(s.domAfter, 'opened')","dom(s.domAfter, 'opened', geometry.viewport)"),
    ("dom(d.closedDom, 'closed')","dom(d.closedDom, 'closed', geometry.viewport)")]:t=replace(t,a,b)
assert t==current(node)
sdk='tauri/scripts/native-perf-sdk-journey.mjs'
p=subprocess.run(['git','show','HEAD:'+sdk],cwd=R,capture_output=True,check=True)
t=p.stdout.decode().replace('\r\n','\n')
t=replace(t,'inspectPdfPixels(await readFile(file))','inspectPdfPixels(await readFile(file), proof.pdfPreview.schemaVersion)')
assert t==current(sdk)
reference=R/'tauri/src-tauri/src/native_perf/fixtures/pdf-first-page.png'
assert hashlib.sha256(reference.read_bytes()).hexdigest()=='5ffffdfc3c9f4a9db05a3170f5df71d07da13ce35a6528ffb011a435ff54b4c9'
v=dict(task='RF-1149',originalResourceStableMetricsGuardsByteEqual=True,
    originalNativeInspectionByteEqualExceptExplicitIntegratedDecoderCall=True,
    originalNodeIdentityInputTreeBudgetClockCryptoProtocolGuardsByteEqualExceptVersionGeometry=True,
    originalDriverByteEqualExceptExplicitProofVersionArgument=True,originalReferenceUnchanged=True,
    fixedMaskSha256='6f307e964c1dba0a23593241d6d193823cdf8feebb3946ca80b5af9a4a165044',
    darkPixelCount=530,maxCaptures=16,intervalMs=250,requiredConsecutiveMatches=2,
    maxSdkCalls=128,previewBudgetMs=25000,wholeJourneyBudgetMs=310000,accepted=True)
with (S/'boundary-audit.json').open('x',encoding='utf-8') as out:json.dump(v,out,indent=2);out.write('\n')
print(json.dumps(v))
