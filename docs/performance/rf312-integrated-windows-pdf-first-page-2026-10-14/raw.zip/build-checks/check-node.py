from pathlib import Path
import datetime, hashlib, json, os, subprocess, time
R=Path('D:/SoloSoul'); S=Path(__file__).parent
sources=json.loads((S/'sources.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy(); tmp=S/'node-temp'; tmp.mkdir(exist_ok=False)
env.update(TEMP=str(tmp),TMP=str(tmp),PYTHONUTF8='1')
def save(n,v):
    with (S/n).open('x',encoding='utf-8',newline='\n') as out:
        json.dump(v,out,indent=2);out.write('\n')
for name,cmd in [
    ('node-format',['node','node_modules/prettier/bin/prettier.cjs','--check',
        'scripts/native-perf-pdf-pixels.mjs','scripts/native-perf-pdf-preview-contract.mjs',
        'scripts/native-perf-pdf-preview.test.mjs','scripts/native-perf-sdk-journey.mjs']),
    ('node-full',['node','scripts/run-node-tests.mjs']),
]:
    assert all(sha(R/n)==h for n,h in sources.items()); began=time.monotonic()
    with (S/(name+'.stdout.log')).open('xb') as out,(S/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=R/'tauri',env=env,stdin=subprocess.DEVNULL,
            stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        print(name,'live',p.pid,flush=True);code=p.wait()
    changed=[n for n,h in sources.items() if sha(R/n)!=h]
    save(name+'.receipt.json',dict(exitCode=code,elapsedSeconds=time.monotonic()-began,
        changedSources=changed,sourceUnchanged=not changed,command=cmd))
    print(name,'exit',code,flush=True)
    if code or changed:raise SystemExit(code or 1)
