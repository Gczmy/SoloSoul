import assert from 'node:assert/strict';
import { readFile, writeFile, lstat, realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { checkBound } from '../../tauri/scripts/native-perf-sdk-journey.mjs';
import { checkPdfFirstPage, summarizePdfFirstPage } from '../../tauri/scripts/native-perf-pdf-preview-contract.mjs';
import { inspectPdfPixels } from '../../tauri/scripts/native-perf-pdf-pixels.mjs';
import { describeAuthAttribution } from '../../tauri/scripts/native-perf-auth-contract.mjs';
import { checkMaintenanceAdmission } from '../../tauri/scripts/native-perf-maintenance-contract.mjs';
import { normalizeWindowsPath } from '../../tauri/scripts/native-perf-run.mjs';
import { verifyRetainedMedia } from '../rf1147-ocr-picker-settlement-20261014/verify-retained-media.mjs';
const repo='D:/SoloSoul',stage=path.join(repo,'build/rf1149-current-windows-pdf-preview-20261014');
const load=async file=>JSON.parse((await readFile(file,'utf8')).replace(/^\uFEFF/,''));
const sha=async file=>createHash('sha256').update(await readFile(file)).digest('hex');
const proof=await load(path.join(stage,'input-proof.json'));
assert.equal((await load(path.join(stage,'terminal.json'))).accepted,true);
assert.equal(Object.keys(proof.sources).length,1984);
assert.equal(await sha(proof.runtime.exe),proof.runtime.sha256);
for(const [name,hash] of Object.entries(proof.sources))assert.equal(await sha(path.join(repo,name)),hash,name);
for(const row of proof.runtime.resources){assert.equal(await sha(row.source),row.sha256);assert.equal(await sha(row.copy),row.sha256);}
assert.equal(await sha(path.join(repo,'tauri/src-tauri/src/native_perf/fixtures/pdf-first-page.png')),
  '5ffffdfc3c9f4a9db05a3170f5df71d07da13ce35a6528ffb011a435ff54b4c9');
const ids=new Set(),records=[],groups=[];
for(const size of [100,5000]){
  const group=path.join(stage,`samples${size}`),report=await load(path.join(group,'native-perf-sdk-journey-results.json'));
  assert.equal(report.success,true);assert.equal(report.samples.length,3);assert.equal(report.samplesRequested,3);
  assert.equal(report.fixture.objectCount,size);assert.equal(report.sourceUnchanged,true);assert.equal(report.interrupted,false);
  assert.deepEqual(report.sourceBefore,report.sourceAfter);assert.equal(report.exeSha256,proof.runtime.sha256);
  assert.deepEqual(report.summary,summarizePdfFirstPage(report.samples,3,true));
  assert.ok(report.summary.every(s=>s.successfulSamples===3&&Number.isFinite(s.medianMs)&&Number.isFinite(s.p95Ms)));
  groups.push({objects:size,summary:report.summary});
  for(const sample of report.samples){
    assert.equal(sample.success,true);assert.equal(sample.cleanupIntegrity.complete,true);
    const root=path.join(group,`sample-${String(sample.index).padStart(3,'0')}`);
    const owned=await load(path.join(root,'native-perf-owned.json'));assert.deepEqual(owned,sample.owned);
    assert.equal(ids.has(owned.runId),false);ids.add(owned.runId);
    const bound=checkBound(await load(path.join(root,'native-perf-sdk-journey-bound.json')),owned,sample.processId,sample.port);
    assert.deepEqual(bound,sample.bound);
    const native=await load(path.join(root,'native-perf-sdk-journey.json'));assert.deepEqual(native,sample.nativeProof);
    checkPdfFirstPage(native,owned,bound,report.fixture);assert.equal(native.pdfPreview.schemaVersion,3);
    const mediaHashes=await verifyRetainedMedia(owned,report.mediaFixture,root);
    const auth=await load(path.join(root,'native-perf-auth-attribution.json'));
    const attribution=describeAuthAttribution(auth,owned,bound);
    const admission=await load(path.join(root,'native-perf-maintenance-admission.json'));
    checkMaintenanceAdmission(admission,auth,owned,bound);
    const screenshots=[];
    for(const info of native.pdfPreview.samples){
      const file=path.join(root,info.fileName),stat=await lstat(file);
      assert.ok(stat.isFile()&&!stat.isSymbolicLink());assert.equal(stat.size,info.bytes);
      assert.equal(normalizeWindowsPath(await realpath(file)),normalizeWindowsPath(file));assert.equal(await sha(file),info.sha256);
      const bytes=await readFile(file),pixels=inspectPdfPixels(bytes,3);
      assert.ok(Object.keys(pixels).every(k=>pixels[k]===info[k]));
      assert.throws(()=>inspectPdfPixels(bytes,2),/fixed viewport/);
      screenshots.push({fileName:info.fileName,bytes:info.bytes,sha256:info.sha256,pixels,
        frameStable:info.frameStable,allChunkCrcVerified:true,legacyVersionRefused:true});
    }
    const controls=[
      v=>v.pdfPreview.schemaVersion=2,
      v=>v.pdfPreview.schemaVersion=4,
      v=>v.pdfPreview.roi.x++,
      v=>v.pdfPreview.viewport.width++,
      v=>v.binding.loaderId='REPLACED',
      v=>v.pdfPreview.samples[0].domAfter.inputTrust.untrusted=1,
      v=>v.pdfPreview.samples[0].frameAfter.mainVerified=false,
      v=>v.pdfPreview.intervalMs=249,
      v=>v.pdfPreview.maxCaptures=17,
      v=>v.pdfPreview.requiredConsecutiveMatches=1,
      v=>v.pdfPreview.resourceBinding.sha256='0'.repeat(64),
      v=>v.pdfPreview.performanceMetrics.stableReadyObservedMs=0,
    ];
    for(const edit of controls){const bad=structuredClone(native);edit(bad);assert.throws(()=>checkPdfFirstPage(bad,owned,bound,report.fixture));}
    records.push({objects:size,index:sample.index,runId:owned.runId,pid:sample.processId,
      currentFixedSchema3ContractAccepted:true,authFlows:attribution.frontend.flows.length,
      authSource:auth.binding.source,maintenanceFailures:admission.failures.length,mediaHashes,screenshots,
      negativeControlsRejected:controls.length,performanceMetrics:native.pdfPreview.performanceMetrics});
  }
}
assert.equal(ids.size,6);
await writeFile(path.join(stage,'independent-verification.json'),JSON.stringify({task:'RF-1149',accepted:true,
  groups:[100,5000],samplesPerGroup:3,distinctRuns:6,allPdfAuthMaintenanceContractsReplayed:true,
  sourceAndRuntimeAndResourcesUnchanged:true,sourceCount:1984,currentFixedSchemaVersion:3,
  historicalFixedSchemaVersion:2,originalPixelReferenceAndMaskUnchanged:true,
  allPngLengthsSha256CrcAndIndependentPixelsVerified:true,negativeControlsPerRun:12,
  pdfFirstPagePerformanceAccepted:true,fullRF312Accepted:false,groupSummaries:groups,records},null,2)+'\n',{flag:'wx'});
process.stdout.write('Six complete current PDF first-page native journeys independently verified; all PNG bytes/CRC/pixels and 72 actual-proof negative controls passed\n');
