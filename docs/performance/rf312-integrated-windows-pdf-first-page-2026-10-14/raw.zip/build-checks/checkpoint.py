from pathlib import Path
import datetime,json
R=Path('D:/SoloSoul');S=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
receipts={p.stem:load(p) for p in S.glob('*.receipt.json')}
v=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),goal='active',task='RF-1149',
    branch='codex/rf312-android-process-memory',latestPushedHead='58f585a68',
    additionalPdfDiagnosticPushExplicitlyAuthorizedAndCompleted=True,pendingPushApproval=False,
    desktopConnectedUnlockedAndCodexMinimizedConfirmed=True,pendingDesktopPreparationQuestion=False,
    totalTasks=339,closedTasks=327,waitingTasks=5,queuedTasks=6,inProgressTasks=1,
    nativeBuildUnifiedExecSession=38345,nativeBuildStillLive=True,
    receipts=receipts,nodeTests=dict(total=266,passed=265,failed=0,skipped=1),
    expectedNativeTests=142,nativeTestsNotYetAccepted='native-tests.receipt' not in receipts,
    nativeBuildCurrentPhase='native-release' if (S/'native-release.live.json').exists() else 'native-tests',
    sourceCount=1984,
    nativePdfFirstPagePerformanceNotYetAccepted=True,rf1149NotYetCommitted=True,
    next=[
        'Resume unified exec session 38345; do not restart build-native.py. It continues fmt/clippy/native tests/Release sequentially and stops on failure.',
        'After its actual successful terminal exit and runtime-package.json, run build/rf1149-pdf-geometry-20261014/prepare-native-preview.py.',
        'Run build/run-rf1149-current-windows-pdf-preview-20261014.py pdf-preview in authorized native context. Its actual current session preflight remains required. Preserve failures and new exclusive namespaces.',
        'Run build/rf1149-pdf-geometry-20261014/verify-native-preview.mjs; preserve all PNGs and actual schema3 proof. Never count old diagnostic PNGs as performance runs.',
        'Derive original accepted cleanup only after actual success; verify exact PID/birth identities and caches, preserved Vault/log/proof bytes. Archive without program/resources/Vault/cache entities.',
        'Close RF1149 only after actual checks, full 100/5000 groups each3, independent verification and cleanup. One issue one commit; new metadata push requires its own concrete approval if automatic review rejects it.',
        'RF121 prepared retry2 is stale to current native source. Reconcile frozen inputs/runtime; old owned caption helper rejects any WindowFromPoint child before WM_NCHITTEST. Audit actual refusal and a bounded owned-child guard separately, not a blanket root bypass.',
        'RF312 current home50sec failure and default uninstrumented startup/IME/local hardware scopes remain open; do not redo already accepted checks without reason.',
    ])
(S/'checkpoint.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
target=R/'build/goal-progress-20261014-current.json';prior=load(target)
prior['currentRF1149']=v;prior['currentExecutionOverridesOlderQueueFields']=True
prior['currentExecutionCheckpoint']=str(S/'checkpoint.json')
target.write_text(json.dumps(prior,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(task=v['task'],goal=v['goal'],nativeBuildSession=v['nativeBuildUnifiedExecSession'],
    latestPushedHead=v['latestPushedHead'],currentClosed='327/339',nativePerformanceAccepted=False)))
