from pathlib import Path
import json
R=Path('D:/SoloSoul');S=R/'build/rf1149-current-windows-pdf-preview-20261014'
a=(R/'build/rf312-current-windows-pdf-diagnostic-retry1-20261014/cleanup-accepted-owned.ps1').read_text(encoding='utf-8')
b=(S/'cleanup-accepted-owned.ps1').read_text(encoding='utf-8')
a=a.replace('rf312-current-windows-pdf-diagnostic-retry1-20261014','rf1149-current-windows-pdf-preview-20261014')
a=a.replace('pdfCapabilityDiagnosticVerified','pdfFirstPagePerformanceVerified')
a=a.replace('rf1147-ocr-picker-settlement-20261014','rf1149-pdf-geometry-20261014')
a=a.replace("task='RF-312'","task='RF-1149'")
assert a==b
v=dict(accepted=True,originalCleanupByteEqualExceptExactOwnedStageExeAcceptanceFlagAndTask=True,
    originalIdentityReparseVaultLogHashAndExactKnownFolderGuardsPreserved=True,
    cacheTargets=48,executionPerformedByThisAudit=False)
with (S/'accepted-cleanup-boundary.json').open('x',encoding='utf-8') as out:json.dump(v,out,indent=2);out.write('\n')
print('Cleanup byte-equal except exact owned stage/EXE, verified acceptance flag and task label')
