from pathlib import Path
import datetime,hashlib,json,os,re,shutil,struct,subprocess,time,tomllib,zipfile
R=Path('D:/SoloSoul');B=Path(__file__).parent
S=B/'rf312-fixed-vault-proposal-round3-20261012';P=S/'project';P.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
sources=load(R/'build/rf121-theme-binding-20261010/rf1133-surface-readiness-20261012/sources.json')
inputs=load(B/'rf312-early-observer-implementation-20261012/positive-native-round2/inputs.json')
old=inputs['runtimeSourceFiles'];changed=[n for n,h in old.items() if sources[n]!=h]
assert set(changed)=={'tauri/src-tauri/src/native_perf/sdk_surface.js','tauri/src-tauri/src/native_perf/sdk_surface.rs','tauri/scripts/native-perf-surface.node.test.mjs'}
recipe=B/'rf312-release-probe-build-round2-20261012/project';copied={}
for n in ['build.gradle.kts','gradle.properties','settings.gradle.kts','original-main-compile-only.jar',
          'original-tauri-compile-only.jar','src/main/AndroidManifest.xml']:
 t=P/n;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(recipe/n,t);copied[n]=sha(t)
src=S/'AndroidFixedVaultPerfInstrumentedTest.kt'
target=P/'src/main/java/com/solosoul/app'/src.name;target.parent.mkdir(parents=True);shutil.copyfile(src,target)
test_sha=sha(src)
original_manifest=(R/'build/rf121-theme-binding-20261010/rf1133-current-gui-build-20261012/Cargo.before.toml').read_bytes()
def frozen():
 for n,h in sources.items():
  if n=='tauri/src-tauri/Cargo.toml':
   raw=(R/n).read_bytes()
   assert raw.replace(b'\r\n',b'\n')==original_manifest.replace(b'\r\n',b'\n')
   assert tomllib.loads(raw.decode())==tomllib.loads(original_manifest.decode())
  else:assert sha(R/n)==h,n
 for row in [inputs['release']['apk'],inputs['originalDebug'],inputs['originalTest']]:
  assert sha(Path(row.get('path',row.get('copy'))))==row['sha256']
 assert sha(src)==sha(target)==test_sha
 for n,h in copied.items():assert sha(P/n)==h
frozen()
save(S/'input-proof.json',{'task':'RF-312','sources':sources,'testSource':{'source':str(src),'copy':str(target),'sha256':test_sha},
 'sameExistingRecipe':copied,'mainRelease':inputs['release']['apk'],
 'changesFromAndroidReleaseSourceManifest':changed,'changedFilesNotCompiledIntoAndroidMain':True,
 'manifestEolToleranceOnlyDuringIndependentWindowsGuiBuild':True,
 'productionMainApkRebuilt':False,'nativePerformanceAccepted':False,
 'scope':'independent signed test APK preparation for fixed 100/5000 UI + early transport metadata; media/OCR/full-process memory remain pending'})
producer=(B/'build-rf312-release-probe-20261012.py').read_text(encoding='utf-8')
tail=producer[producer.index("jdk=Path('C:/Users/40299571/ss-android/jdk')"):]
tail=tail.replace("str(G/'gradlew.bat')","str(R/'tauri/src-tauri/gen/android/gradlew.bat')")
tail=tail.replace('all1839SourceAndOriginalApkHashesUnchanged','all1843SourceAndOriginalApkHashesUnchangedExceptVerifiedManifestEol')
tail=tail.replace("copy=S/'solosoul-releaseprobe.apk'","copy=S/'solosoul-fixed-vault-releaseprobe.apk'")
tail=tail.replace('Lcom/solosoul/app/AndroidHomeInstrumentedTest;','Lcom/solosoul/app/AndroidFixedVaultPerfInstrumentedTest;')
(S/'actual-build-tail.py').write_text(tail,encoding='utf-8',newline='\n')
exec(compile(tail,str(S/'actual-build-tail.py'),'exec'))
classes=load(S/'dex-defined-classes.json')
assert 'Lcom/solosoul/app/AndroidFixedVaultPerfInstrumentedTest;' in classes
assert not any(c.startswith(('Landroidx/startup/','Landroidx/profileinstaller/')) for c in classes)
save(S/'complete.json',{'testClassCompiled':True,'nativeRuntimeAccepted':False,'fullRF312Accepted':False,
 'defaultProductionMainApkBytesUnchanged':True,'dependenciesAndSigningRecipeUnchanged':True,
 'targetMainActivityAndTauriClassesNotPackaged':True,'duplicateStartupInitializersAbsent':True})
print('Fixed public Vault test APK prepared; no native performance samples executed',flush=True)
