from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-fixed-vault-proposal-round7-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=B/'rf312-early-observer-implementation-20261012/positive-native-round2'
inputs=load(old/'inputs.json');sources=load(R/'docs/verification/rf1133-surface-readiness-2026-10-12.json')['currentSourceFiles']
assert len(sources)==1843 and all(sha(R/n)==h for n,h in sources.items())
apk=load(S/'current-test-apk.json');assert sha(Path(apk['path']))==apk['sha256']
inputs['runtimeSourceFiles']=sources;inputs['runtimeTest']=apk
fixtures={}
for count in [100,5000]:
 root=R/f'build/rf312-maintenance-20261009/fixtures/vault{count}'
 marker=load(root/'rf312-fixture.json');assert marker['objectCount']==count and marker['buildProfile']=='release'
 files={p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
 assert len(files)==8 and marker['kdf']=={'memoryKiB':65536,'iterations':3,'parallelism':4}
 fixtures[str(count)]={'root':str(root),'files':files,'marker':marker}
inputs['fixedFixtures']=fixtures
with (S/'inputs.json').open('x',encoding='utf-8') as f:json.dump(inputs,f,indent=2);f.write('\n')
original=(old/'early-observer-native-driver.py').read_text(encoding='utf-8');text=original
text=text.replace('import argparse\n','import argparse\nimport io\n',1)
text=text.replace('METHOD = "productionHomeWithEarlyIpcTransportObserver"','METHOD = "fixedVaultUiTransportBaseline"',1)
a='    args = parser.parse_args()'
b='''    parser.add_argument('--object-count',type=int,choices=(100,5000),required=True)
    parser.add_argument('--fixture',required=True)
    args = parser.parse_args()
    if args.scenario != 'baseline' or args.motion_preferences or args.font_scale is not None:
        parser.error('Fixed-Vault driver accepts baseline only; original restoration guards stay unchanged')'''
assert text.count(a)==1;text=text.replace(a,b)
a="    if args.motion_preferences and args.scenario != \"cold\":"
b="""    fixture_spec=frozen_inputs['fixedFixtures'][str(args.object_count)]
    if Path(args.fixture).resolve()!=Path(fixture_spec['root']).resolve():
        parser.error('Only the exact frozen public fixture is allowed')
    if args.motion_preferences and args.scenario != "cold":"""
assert text.count(a)==1;text=text.replace(a,b)
a='        backup_valid = True'
b=a+'''
        fixture=Path(fixture_spec['root'])
        actual_files={p.relative_to(fixture).as_posix():digest(p) for p in fixture.rglob('*') if p.is_file()}
        if actual_files!=fixture_spec['files']:
            raise RuntimeError('Public fixed fixture source changed')
        fixture_tar=output/'public-fixed-fixture.tar'
        with tarfile.open(fixture_tar,'w') as packed:
            for relative,expected in sorted(actual_files.items()):
                path=fixture/relative
                if path.is_symlink() or path.stat().st_file_attributes&0x400:
                    raise RuntimeError('Public fixture must be ordinary')
                data=path.read_bytes()
                if hashlib.sha256(data).hexdigest()!=expected:raise RuntimeError('Fixture bytes changed')
                member=tarfile.TarInfo(relative);member.size=len(data);member.mode=0o600
                packed.addfile(member,io.BytesIO(data))
        remote_fixture=f'/data/local/tmp/rf312-fixed-fixture-{uuid.uuid4().hex}.tar'
        mutation_started=True
        try:
            adb('push',str(fixture_tar),remote_fixture,stdout=subprocess.PIPE)
            adb('shell','chmod','644',remote_fixture,stdout=subprocess.PIPE)
            adb('shell','run-as',APP,'tar','-xf',remote_fixture,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            device_hashes=read('shell','run-as',APP,'sha256sum',*sorted(actual_files))
            observed={}
            for line in device_hashes.splitlines():
                match=re.fullmatch(r'([a-f0-9]{64})  (.+)',line)
                if not match:raise RuntimeError('Unrecognized transferred public file checksum')
                observed[match[2]]=match[1]
            if observed!=actual_files:raise RuntimeError('Transferred public fixture bytes differ')
            report['fixedFixture']={'objectCount':args.object_count,'all8TransferredFileHashesVerified':True,'source':fixture_spec}
        finally:
            adb('shell','rm','-f','--',remote_fixture,stdout=subprocess.PIPE)
        if {p.relative_to(fixture).as_posix():digest(p) for p in fixture.rglob('*') if p.is_file()}!=actual_files:
            raise RuntimeError('Source fixed fixture was modified')'''
assert text.count(a)==1;text=text.replace(a,b)
text=text.replace('tag = f"fe2-home-{uuid.uuid4().hex}"','tag = f"rf312-perf-{uuid.uuid4().hex}"',1)
text=text.replace('tag.removeprefix("fe2-home-")','tag.removeprefix("rf312-perf-")')
a='                     "-e", "observerRunId", tag.removeprefix("rf312-perf-"),'
b=a+'''\n                     "-e", "objectCount", str(args.object_count),'''
assert text.count(a)==1;text=text.replace(a,b)
text=text.replace('com.solosoul.app.AndroidEarlyIpcObserverInstrumentedTest#{METHOD}','com.solosoul.app.AndroidFixedVaultPerfInstrumentedTest#{METHOD}',1)
start=text.index('        stages = verify_evidence(evidence,');end=text.index("        if args.scenario == 'cold':",start)
text=text[:start]+'''        verify_fixed_evidence(evidence,args.object_count,tag.removeprefix('rf312-perf-'),original_packages['main']['uid'])
        report['stages']=[p['name'] for p in evidence['phases']]
        report['fixedVaultEvidence']=evidence
'''+text[end:]
helper='''
def verify_fixed_evidence(evidence,count,run_id,uid):
    names=['activity-startup','password-unlock','workspace','search-needle','application-lock','password-reunlock']
    if (evidence.get('scope')!='android-native-fixed-vault-ui-transport-baseline' or evidence.get('success') is not True
            or evidence.get('objectCount')!=count or evidence.get('runId')!=run_id or evidence.get('uid')!=uid
            or not isinstance(evidence.get('processId'),int) or evidence['processId']<=0
            or evidence.get('memorySamplerExited') is not True or evidence.get('memoryError')):
        raise RuntimeError('Fixed native process/fixture/measurement outcome rejected')
    phases=evidence.get('phases',[])
    if [p.get('name') for p in phases]!=names:raise RuntimeError('Complete six-phase UI sequence required')
    previous=[];origin=None
    for row in phases:
        start,end=row.get('nativeStartedAtNs'),row.get('nativeFinishedAtNs')
        if (row.get('success') is not True or type(start) is not int or type(end) is not int or end<start
                or not math.isclose(row.get('durationMs',-1),(end-start)/1e6,rel_tol=0,abs_tol=0.000001)):
            raise RuntimeError('Native phase clock/duration rejected')
        obs=row.get('observer',{});events=obs.get('commands',[])
        if (obs.get('scope')!='android-native-ipc-transport-observer' or obs.get('valid') is not True
                or obs.get('runId')!=run_id or obs.get('invalidReasons')!=[]
                or obs.get('observedCount')!=len(events) or len(events)>obs.get('maxEvents',0)
                or events[:len(previous)]!=previous):raise RuntimeError('Early observer immutable prefix rejected')
        if origin is None:origin=obs.get('timeOriginMs')
        if obs.get('timeOriginMs')!=origin:raise RuntimeError('Document clock changed')
        at=obs.get('installedAtMs')
        for event in events:
            when=event.get('atMs')
            if (set(event)!={'command','transport','atMs'} or not re.fullmatch(r'[A-Za-z0-9_.:|/-]{1,128}',event.get('command',''))
                    or event.get('transport') not in ['android-java-bridge','android-channel-fetch']
                    or not isinstance(when,(int,float)) or isinstance(when,bool) or not math.isfinite(when)
                    or not at<=when<=obs.get('atMs',-1)):raise RuntimeError('Transport metadata/order rejected')
            at=when
        lo,hi=row.get('ipcStart'),row.get('ipcEnd')
        if (type(lo) is not int or type(hi) is not int or not 0<=lo<=hi==len(events)
                or row.get('transportAttempts')!=hi-lo):raise RuntimeError('Phase transport count rejected')
        previous=events
    if sum(e['command']=='login' for e in previous)!=2:raise RuntimeError('Exactly two real public-password unlocks required')
    samples=evidence.get('memorySamples',[])
    if not samples:raise RuntimeError('Main-process PSS samples missing')
    prior=0
    for sample in samples:
        a,b=sample.get('startedAtNs'),sample.get('finishedAtNs');value=sample.get('pssBytes')
        if type(a) is not int or type(b) is not int or not prior<=a<=b or type(value) is not int or value<=0:
            raise RuntimeError('Nonoverlapping actual main-process PSS sample rejected')
        prior=b

'''
assert text.count('\ndef main():')==1;text=text.replace('\ndef main():','\n'+helper+'def main():',1)
compile(text,str(S/'fixed-vault-native-driver.py'),'exec')
with (S/'fixed-vault-native-driver.py').open('x',encoding='utf-8') as f:f.write(text)
with (S/'driver-derivation.json').open('x',encoding='utf-8') as f:json.dump({'source':str(old/'early-observer-native-driver.py'),'beforeSha256':sha(old/'early-observer-native-driver.py'),'afterSha256':sha(S/'fixed-vault-native-driver.py'),'changes':'fixed fixture staging after complete backup, exact new method/args, dedicated metadata verifier; original package/private/system restore body unchanged','restorationBodyByteTextEqual':original[original.index('    finally:\n        if selected:'):]==text[text.index('    finally:\n        if selected:'):]},f,indent=2)
print('Exact new test APK and frozen public100/5000 fixtures prepared; original restoration tail retained')
