from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,tarfile
S=Path(__file__).parent;B=S.parent;H=B/'api31-software-rf312-fixed-vault-20261012';O=S/'preflight-package-read-failure-audit';O.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
inputs=load(S/'inputs.json');previous=load(S/'cohort-5000-03/report.json');failure=load(S/'cohort-100-04/report.json')
commands=load(S/'cohort-100-04/commands.json')
assert not any(c['command'][0] in ['install','uninstall','push'] for c in commands)
assert not any(c['command'][:3]==['shell','settings','put'] for c in commands)
assert not (S/'cohort-100-04/private-data-before.tar').exists() and not (S/'cohort-100-04/native.log').exists()
owned=next(p for p in load(H/'owned-processes-after-launch.json') if p['ProcessId']==load(H/'boot.receipt.json')['pid'])
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
current=json.loads(subprocess.check_output([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {owned['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json"],text=True))
for key in ['Name','ProcessId','ExecutablePath','CommandLine']:assert current[key]==owned[key]
assert datetime.datetime.fromisoformat(current['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
env=os.environ.copy();env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',PYTHONUTF8='1');ledger=[]
def read(label,*args):
 p=subprocess.run([str(B/'sdk/platform-tools/adb.exe'),'-H','localhost','-P','5049','-s','emulator-5586',*args],capture_output=True,timeout=45,env=env)
 (O/(label+'.stderr.log')).write_bytes(p.stderr)
 ledger.append({'command':list(args),'exitCode':p.returncode,'stdoutSha256':sha(p.stdout),'stderrSha256':sha(p.stderr)})
 p.check_returncode();return p.stdout
assert read('state','get-state').strip()==b'device'
assert read('avd','emu','avd','name').decode().splitlines()[0]=='SoloSoul_RF121_API31_20261010'
packages={}
for package,key,label in [('com.solosoul.app','originalDebug','main'),('com.solosoul.app.test','originalTest','test')]:
 path=read(label+'-path','shell','pm','path',package).decode().strip()
 assert re.fullmatch(r'package:/data/app/(?:[A-Za-z0-9_~+=.-]+/){1,2}base\.apk',path)
 data=read(label+'-apk','exec-out','cat',path.removeprefix('package:'));assert sha(data)==inputs[key]['sha256']
 dump=read(label+'-dump','shell','dumpsys','package',package).decode();(O/(label+'-package.log')).write_text(dump)
 uid=re.findall(r'^\s*userId=(\d+)\s*$',dump,re.M);flags=re.findall(r'^\s*pkgFlags=\[([^\]]*)\]',dump,re.M)
 assert len(uid)==len(flags)==1
 packages[label]={'sha256':sha(data),'bytes':len(data),'uid':int(uid[0]),'debuggable':'DEBUGGABLE' in flags[0].split()}
assert packages==previous['restoredInstalledPackages']
assert not read('probe','shell','pm','list','packages','com.solosoul.app.releaseprobe').strip()
archive=O/'current-private-data.tar';archive.write_bytes(read('private','exec-out','run-as','com.solosoul.app','tar','-cf','-','.'))
def inventory(p):
 with tarfile.open(p) as t:
  out={}
  for m in t:
   assert m.name not in out
   data=t.extractfile(m).read() if m.isfile() else b''
   out[m.name]=(m.type,m.mode,m.linkname,m.size,sha(data))
  return out
before=inventory(S/'cohort-5000-03/private-data-restored.tar');after=inventory(archive);assert before==after
oldcommands=load(S/'cohort-5000-03/commands.json')
for label,args in [('root-mode',['shell','run-as','com.solosoul.app','stat','-c','%a','.']),('blur',['shell','settings','get','global','disable_window_blurs'])]:
 previousRead=next(c for c in reversed(oldcommands) if c['command']==args and c['exitCode']==0)
 assert sha(read(label,*args))==previousRead['stdoutSha256']
assert all(sha((Path('D:/SoloSoul')/n).read_bytes())==h for n,h in inputs['runtimeSourceFiles'].items())
result={'failureRetained':'cohort-100-04/report.json','nativeSampleExecuted':False,'apkFixtureAndSystemMutationCommandsAbsent':True,'driverFinallyForceStoppedOnlyTargetApp':True,
 'ownedEmulatorIdentityUnchanged':current,'currentOriginalPackages':packages,'currentPackagesAndPrivateDataEqualLastSuccessfulRestoration':True,
 'tarEntriesIncludingRoot':len(after),'probeAbsent':True,'rootModeAndBlurEqualLastSuccessfulRestoration':True,'sourcesUnchanged':True,'readOnlyCommands':ledger,
 'failureCause':'one dumpsys package read returned exit1; no byte/identity/config drift observed in independent readback; original stderr only hashed by prior driver, so transport/root cause remains undetermined',
 'readyForFreshCompleteCohort':True,'fullRF312Accepted':False}
(O/'audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'readOnlyAuditPassed':True,'nativeSampleExecutedInFailedAttempt':False,'privateEntriesIncludingRoot':len(after),'originalPackagesAndPrivateDataUnchanged':True}),flush=True)
