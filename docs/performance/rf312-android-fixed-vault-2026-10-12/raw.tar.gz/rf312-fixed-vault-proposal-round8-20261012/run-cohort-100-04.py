from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent.parent;S=B/'rf312-fixed-vault-proposal-round8-20261012'
H=B/'api31-software-rf312-fixed-vault-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=load(S/'inputs.json');boot=load(H/'boot.receipt.json')
assert boot['booted'] and boot['avdConfigUnchanged']
assert all(sha(R/n)==h for n,h in inputs['runtimeSourceFiles'].items())
owned=next(p for p in load(H/'owned-processes-after-launch.json') if p['ProcessId']==boot['pid'])
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
q=subprocess.check_output([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {owned['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json"],text=True)
current=json.loads(q)
for n in ['Name','ProcessId','ExecutablePath','CommandLine']:assert current[n]==owned[n]
assert datetime.datetime.fromisoformat(current['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
assert '-gpu swiftshader ' in current['CommandLine']
env=os.environ.copy();env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',TEMP=str(B/'tmp'),TMP=str(B/'tmp'),PYTHONUTF8='1')
command=['C:/Python314/python.exe',str(S/'fixed-vault-native-driver.py'),'--adb',str(B/'sdk/platform-tools/adb.exe'),
 '--serial','emulator-5586','--avd','SoloSoul_RF121_API31_20261010','--apk',inputs['release']['apk']['path'],
 '--test-apk',inputs['runtimeTest']['path'],'--restore-apk',inputs['originalDebug']['copy'],
 '--output',str(S/'cohort-100-04'),'--mode','supported','--scenario','baseline','--object-count','100','--fixture',inputs['fixedFixtures']['100']['root']]
began=time.monotonic()
with (S/'cohort-100-04.stdout.log').open('xb') as out,(S/'cohort-100-04.stderr.log').open('xb') as err:
 p=subprocess.Popen(command,cwd=R,env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
 (S/'cohort-100-04.live.json').write_text(json.dumps({'pid':p.pid,'command':command,'ownedEmulator':current})+'\n',encoding='utf-8')
 print('First complete fixed-100 native journey PID',p.pid,flush=True);code=p.wait()
report=load(S/'cohort-100-04/report.json') if (S/'cohort-100-04/report.json').exists() else {}
result={'exitCode':code,'elapsedSeconds':time.monotonic()-began,'passed':report.get('passed',False),'restored':report.get('restored',False),
 'originalApksRestored':report.get('originalApksRestored',False),'ownedProbeRemoved':report.get('ownedProbeRemoved',False),
 'blurRestored':report.get('blurRestored',False),'fullRF312Accepted':False,'samplesRequested':1,'sourceInputsUnchanged':all(sha(R/n)==h for n,h in inputs['runtimeSourceFiles'].items())}
with (S/'cohort-100-04.receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result),flush=True)
raise SystemExit(code)
