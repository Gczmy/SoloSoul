rootProject.name = "SoloSoulReleaseNativeProbe"
