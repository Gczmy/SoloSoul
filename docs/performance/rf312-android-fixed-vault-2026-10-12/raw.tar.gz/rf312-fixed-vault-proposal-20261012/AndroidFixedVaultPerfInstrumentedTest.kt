package com.solosoul.app

import android.content.pm.ApplicationInfo
import android.os.Debug
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/** Fixed encrypted public datasets only. This proposal is not a native result.
 * Startup is Activity launch to usable password form and two committed frames:
 * it excludes runner/process launch and includes instrumentation overhead.
 * Memory is serial sampled main-process PSS, including this test runner.
 * Media/OCR, renderer memory, physical devices and other platforms stay pending.
 */
@RunWith(AndroidJUnit4::class)
class AndroidFixedVaultPerfInstrumentedTest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val phases = JSONArray()
    private val memory = JSONArray()
    private val sampling = AtomicBoolean(false)
    private val memoryFailure = AtomicReference<Throwable?>()
    private lateinit var evidence: File
    private lateinit var runId: String
    private lateinit var report: JSONObject
    private var clockOrigin: Double? = null

    private fun webView(view: View): WebView? {
        if (view is WebView) return view
        if (view is ViewGroup) for (i in 0 until view.childCount) webView(view.getChildAt(i))?.let { return it }
        return null
    }

    private fun js(scenario: ActivityScenario<MainActivity>, expression: String): JSONObject {
        val done = CountDownLatch(1)
        var raw: String? = null
        scenario.onActivity { activity ->
            requireNotNull(webView(activity.window.decorView)).evaluateJavascript(expression) {
                raw = it; done.countDown()
            }
        }
        assertTrue("Actual target WebView must respond", done.await(3, TimeUnit.SECONDS))
        val parsed = JSONArray("[${raw ?: "null"}]").opt(0)
        return if (parsed is String && parsed.startsWith("{")) JSONObject(parsed) else JSONObject()
    }

    private fun waitFor(scenario: ActivityScenario<MainActivity>, expression: String,
                        predicate: (JSONObject) -> Boolean): JSONObject {
        val began = SystemClock.elapsedRealtimeNanos()
        var last = JSONObject()
        while (SystemClock.elapsedRealtimeNanos() - began < TimeUnit.SECONDS.toNanos(45)) {
            last = js(scenario, expression)
            if (predicate(last)) return last
            Thread.sleep(50)
        }
        throw AssertionError("Fixed public UI checkpoint unavailable: $last")
    }

    private fun painted(scenario: ActivityScenario<MainActivity>) {
        val committed = CountDownLatch(1)
        scenario.onActivity { activity ->
            val view = requireNotNull(webView(activity.window.decorView))
            assertTrue(view.isAttachedToWindow && view.isShown && view.hasWindowFocus())
            view.postVisualStateCallback(SystemClock.elapsedRealtimeNanos(), object : WebView.VisualStateCallback() {
                override fun onComplete(requestId: Long) {
                    view.postOnAnimation { view.postOnAnimation { committed.countDown() } }
                }
            })
        }
        assertTrue("Target view must commit and draw two frames", committed.await(10, TimeUnit.SECONDS))
    }

    private fun touch(scenario: ActivityScenario<MainActivity>, selector: String) {
        val target = js(scenario, """(() => {
          const nodes=[...document.querySelectorAll(${JSONObject.quote(selector)})];
          const node=nodes.length===1?nodes[0]:null,r=node?.getBoundingClientRect();
          return JSON.stringify({valid:!!node&&!node.disabled&&r.width>0&&r.height>0,
            x:r?r.x+r.width/2:null,y:r?r.y+r.height/2:null,viewportWidth:innerWidth,
            frame:window.top===window,focused:document.hasFocus()});})()""")
        assertTrue(target.getBoolean("valid") && target.getBoolean("frame") && target.getBoolean("focused"))
        scenario.onActivity { activity ->
            val view = requireNotNull(webView(activity.window.decorView))
            assertTrue(view.hasWindowFocus())
            val scale=view.width/target.getDouble("viewportWidth")
            val x=(target.getDouble("x")*scale).toFloat()
            val y=(target.getDouble("y")*scale).toFloat()
            assertTrue(x>0 && y>0 && x<view.width && y<view.height)
            val down=SystemClock.uptimeMillis()
            for (action in listOf(MotionEvent.ACTION_DOWN,MotionEvent.ACTION_UP)) {
                val event=MotionEvent.obtain(down,SystemClock.uptimeMillis(),action,x,y,0)
                try { assertTrue(view.dispatchTouchEvent(event)) } finally { event.recycle() }
            }
        }
    }

    private fun typePublic(scenario: ActivityScenario<MainActivity>, selector: String, text: String) {
        require(text=="perf-baseline-only-password" || text=="needle")
        touch(scenario,selector)
        val focus=js(scenario,"""JSON.stringify({focused:document.activeElement===document.querySelector(${JSONObject.quote(selector)}),
          empty:document.querySelector(${JSONObject.quote(selector)})?.value===''})""")
        assertTrue(focus.getBoolean("focused") && focus.getBoolean("empty"))
        instrumentation.sendStringSync(text)
        waitFor(scenario,"JSON.stringify({filled:document.querySelector(${JSONObject.quote(selector)})?.value===${JSONObject.quote(text)}})") { it.optBoolean("filled") }
    }

    private val page = """JSON.stringify({path:location.pathname,search:location.search,
      mounted:!!document.querySelector('#root>*'),startupGone:!document.querySelector('#startup-screen'),
      platform:document.documentElement.dataset.platform,
      home:!!document.querySelector('[data-testid="android-home"]'),
      count:document.querySelector('.android-overview-copy strong')?.textContent,
      password:!!document.querySelector('[data-login-method-region="password"] input'),
      enabled:!!document.querySelector('[data-login-password-submit]')&&!document.querySelector('[data-login-password-submit]').disabled,
      accountCount:document.querySelector('[data-login-card] select')?.options.length,
      selected:document.querySelector('[data-login-card] select')?.value,
      cards:document.querySelectorAll('[data-testid="workspace-object-card"]').length,
      firstPublicObject:[...document.querySelectorAll('[data-testid="workspace-object-card"]')].some(e=>e.textContent.includes('Record 00000000')),
      searchResults:document.querySelectorAll('[data-ui-card][role="button"]').length,
      publicSearch:document.querySelector('input')?.value==='needle',
      errors:document.querySelectorAll('[role="alert"]').length})"""

    private fun observer(scenario: ActivityScenario<MainActivity>, bind: Boolean = false): JSONObject {
        val root = js(scenario,"""(() => {
          const o=window.__SOLOSOUL_ANDROID_NATIVE_PERF__;
          const d=Object.getOwnPropertyDescriptor(window.__TAURI_INTERNALS__,'invoke');
          return JSON.stringify({mainFrame:window.top===window,frames:document.querySelectorAll('iframe,frame').length,
            invokeReadonly:d?.writable===false&&d?.configurable===false,
            snapshot:o?o.${if(bind) "bind('$runId')" else "snapshot()"}:null});})()""")
        assertTrue(root.getBoolean("mainFrame") && root.getBoolean("invokeReadonly"))
        assertEquals(0,root.getInt("frames"))
        val observed=root.getJSONObject("snapshot")
        assertEquals("android-native-ipc-transport-observer",observed.getString("scope"))
        assertEquals(runId,observed.getString("runId")); assertTrue(observed.getBoolean("valid"))
        assertEquals(0,observed.getJSONArray("invalidReasons").length())
        val origin=observed.getDouble("timeOriginMs")
        if(clockOrigin==null)clockOrigin=origin else assertEquals(clockOrigin!!,origin,0.0)
        assertEquals(observed.getInt("observedCount"),observed.getJSONArray("commands").length())
        val commands=observed.getJSONArray("commands")
        for(i in 0 until commands.length()) {
            val command=commands.getJSONObject(i)
            assertEquals(setOf("command","transport","atMs"),command.keys().asSequence().toSet())
            assertTrue(Regex("[A-Za-z0-9_.:|/-]{1,128}").matches(command.getString("command")))
            assertTrue(command.getString("transport") in setOf("android-java-bridge","android-channel-fetch"))
            assertTrue(command.getDouble("atMs")>=observed.getDouble("installedAtMs") && command.getDouble("atMs")<=observed.getDouble("atMs"))
        }
        return observed
    }

    private fun phase(scenario: ActivityScenario<MainActivity>, name: String, began: Long,
                      before: JSONObject?, action: () -> Unit) {
        val row=JSONObject().put("name",name).put("nativeStartedAtNs",began).put("success",false)
        phases.put(row)
        try {
            action();painted(scenario)
            val after=observer(scenario, before==null)
            val commands=after.getJSONArray("commands")
            val prefix=before?.getJSONArray("commands")
            if(prefix!=null) {
                assertTrue(commands.length()>=prefix.length())
                for(i in 0 until prefix.length()) assertEquals(prefix.getJSONObject(i).toString(),commands.getJSONObject(i).toString())
            }
            row.put("ipcStart",prefix?.length() ?: 0).put("ipcEnd",commands.length())
                .put("documentFromAtMs",before?.getDouble("atMs") ?: after.getDouble("installedAtMs"))
                .put("documentToAtMs",after.getDouble("atMs"))
                .put("transportAttempts",commands.length()-(prefix?.length() ?: 0))
                .put("observer",after).put("ui",js(scenario,page)).put("success",true)
        } catch(error: Throwable) {
            row.put("errorClass",error.javaClass.name)
            throw error
        } finally {
            val end=SystemClock.elapsedRealtimeNanos()
            row.put("nativeFinishedAtNs",end).put("durationMs",(end-began)/1_000_000.0)
            writeReport()
        }
    }

    private fun writeReport() {
        report.put("phases",phases)
        synchronized(memory) { report.put("memorySamples",JSONArray(memory.toString())) }
        File(evidence,"report.json").writeText(report.toString(2))
    }

    @Test fun fixedVaultUiTransportBaseline() {
        val args=InstrumentationRegistry.getArguments()
        assertEquals("true",args.getString("privateDataBackedUp"))
        runId=requireNotNull(args.getString("observerRunId"));require(Regex("[a-f0-9]{32}").matches(runId))
        val count=requireNotNull(args.getString("objectCount")).toInt();require(count==100 || count==5000)
        val tag=requireNotNull(args.getString("evidenceTag"));require(tag=="rf312-perf-$runId")
        val context=instrumentation.targetContext
        assertEquals("com.solosoul.app",context.packageName)
        assertFalse("Main app must be optimized non-debuggable Release",context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE!=0)
        val root=File(context.applicationInfo.dataDir)
        val config=File(root,"app_config.json")
        if(config.exists()) assertTrue("Fixed private fixture must not redirect to a SAF root",JSONObject(config.readText()).optString("saf_tree_uri").isBlank())
        val marker=JSONObject(File(root,"rf312-fixture.json").readText())
        assertEquals("synthetic-native-vault-fixture",marker.getString("scope"))
        assertEquals(count,marker.getInt("objectCount"));assertEquals("release",marker.getString("buildProfile"))
        val kdf=marker.getJSONObject("kdf")
        assertEquals(65536,kdf.getInt("memoryKiB"));assertEquals(3,kdf.getInt("iterations"));assertEquals(4,kdf.getInt("parallelism"))
        val account="acc_rf312_$count"
        val accounts=JSONArray(File(root,"accounts.json").readText())
        assertEquals(1,accounts.length());assertEquals(account,accounts.getJSONObject(0).getString("id"))
        assertEquals("Performance Fixture",accounts.getJSONObject(0).getString("name"))
        assertTrue(File(root,"$account/vault.db").isFile)
        for(file in root.walkTopDown()) if(file.name.startsWith("acc_")) assertEquals(account,file.name)
        evidence=File(requireNotNull(context.getExternalFilesDir(null)),tag).also { check(it.mkdir()) }
        report=JSONObject().put("schemaVersion",1).put("scope","android-native-fixed-vault-ui-transport-baseline")
            .put("runId",runId).put("processId",android.os.Process.myPid()).put("uid",android.os.Process.myUid())
            .put("objectCount",count).put("success",false)
            .put("fixtureSearchMatches",count/20).put("displayedSearchResults",minOf(count/20,50)).put("productionSearchResultLimit",50)
            .put("nativeClock","Android elapsedRealtimeNanos; not converted to document clock")
            .put("startupDefinition","Activity launch to usable production password form and two frames; excludes runner/process launch")
            .put("inputMethod","target WebView native touch dispatch and Instrumentation.sendStringSync; includes instrumentation/polling/drawing overhead")
            .put("memoryDefinition","serial main-process PSS sampling including runner, not renderer memory or continuous peak")
            .put("ipcDefinition","actual transport sends from early observer, including startup/retries/channels; no request arguments or bodies")
            .put("unmeasured",JSONArray(listOf("OCR","attachment-preview","PDF-preview","renderer-memory","process-cold-start","physical-device","other-platforms")))
        sampling.set(true)
        val worker=Thread {
            try {
                while(sampling.get()) {
                    val started=SystemClock.elapsedRealtimeNanos();val info=Debug.MemoryInfo();Debug.getMemoryInfo(info)
                    assertTrue("Actual main-process PSS must be available",info.totalPss>0)
                    synchronized(memory) {
                        check(memory.length()<1024)
                        memory.put(JSONObject().put("startedAtNs",started).put("finishedAtNs",SystemClock.elapsedRealtimeNanos()).put("pssBytes",info.totalPss.toLong()*1024))
                    }
                    Thread.sleep(1000)
                }
            } catch(error:Throwable) { memoryFailure.set(error) }
        }.also { it.start() }
        try {
            val began=SystemClock.elapsedRealtimeNanos()
            val scenario=ActivityScenario.launch(MainActivity::class.java)
            phase(scenario,"activity-startup",began,null) {
                waitFor(scenario,page) { it.optBoolean("mounted") && it.optBoolean("startupGone") && it.optString("platform")=="android" &&
                    it.optString("path")=="/login" && it.optBoolean("password") && it.optBoolean("enabled") &&
                    it.optInt("accountCount")==1 && it.optString("selected")==account }
            }
            fun measure(name:String,action:()->Unit) {
                val before=observer(scenario);phase(scenario,name,SystemClock.elapsedRealtimeNanos(),before,action)
            }
            fun unlock() {
                typePublic(scenario,"[data-login-method-region='password'] input","perf-baseline-only-password")
                touch(scenario,"[data-login-password-submit]")
                waitFor(scenario,page) { it.optBoolean("home") && it.optString("count")==count.toString() && it.optInt("errors")==0 }
            }
            measure("password-unlock") { unlock() }
            measure("workspace") {
                touch(scenario,".android-category:first-child > button:first-child")
                waitFor(scenario,page) { it.optString("path")=="/workspace" && it.optString("search").contains("section=identity") && it.optInt("cards")>0 && it.optBoolean("firstPublicObject") }
            }
            touch(scenario,".android-navigation a[href='/tools']")
            waitFor(scenario,page) { it.optString("path")=="/tools" }
            val search=js(scenario,"""(() => {const nodes=[...document.querySelectorAll('.android-tool')];
              return JSON.stringify({index:nodes.findIndex(e=>e.querySelector('strong')?.textContent==='Search')});})()""")
            assertTrue(search.getInt("index")>=0)
            touch(scenario,".android-tool:nth-child(${search.getInt("index")+1})")
            waitFor(scenario,page) { it.optString("path")=="/search" }
            measure("search-needle") {
                typePublic(scenario,"input","needle")
                waitFor(scenario,page) { it.optString("path")=="/search" && it.optBoolean("publicSearch") && it.optInt("searchResults")==minOf(count/20,50) && it.optInt("errors")==0 }
                var keyboardVisible=false
                scenario.onActivity { activity ->
                    keyboardVisible=requireNotNull(ViewCompat.getRootWindowInsets(activity.window.decorView)).isVisible(WindowInsetsCompat.Type.ime())
                }
                if(keyboardVisible)instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK)
                waitFor(scenario,page) { it.optString("path")=="/search" && it.optBoolean("publicSearch") && it.optInt("searchResults")==minOf(count/20,50) }
            }
            measure("application-lock") {
                touch(scenario,"button[aria-label='Lock Vault']")
                waitFor(scenario,page) { it.optString("path")=="/login" && !it.optBoolean("home") && it.optBoolean("password") && it.optBoolean("enabled") }
            }
            measure("password-reunlock") { unlock() }
            assertEquals(6,phases.length());assertNull(memoryFailure.get())
            report.put("success",true)
        } catch(error:Throwable) {
            report.put("errorClass",error.javaClass.name);throw error
        } finally {
            sampling.set(false);worker.join(2000)
            if(worker.isAlive || memoryFailure.get()!=null) report.put("success",false).put("memoryError",true)
            report.put("memorySamplerExited",!worker.isAlive);writeReport()
            // Keep the owned activity alive until the external driver stops and
            // restores the target; ActivityScenario.close may stop the runner.
            assertFalse("Memory sampler must stop",worker.isAlive);assertNull(memoryFailure.get())
        }
    }
}
