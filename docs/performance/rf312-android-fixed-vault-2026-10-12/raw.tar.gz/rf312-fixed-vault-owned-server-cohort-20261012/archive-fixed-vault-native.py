from pathlib import Path
import hashlib,io,json,re,tarfile
R=Path('D:/SoloSoul');B=Path(__file__).parent.parent;S=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
result=load(S/'cohorts.receipt.json');stats=load(S/'statistics.json');inputs=load(S/'inputs.json')
assert result['passed'] and len(result['rows'])==10 and len(stats['rows'])==10
assert all(sha((R/n).read_bytes())==h for n,h in inputs['runtimeSourceFiles'].items())
src=S/'AndroidFixedVaultPerfInstrumentedTest.kt';published=R/'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidFixedVaultPerfInstrumentedTest.kt'
assert src.read_bytes()==published.read_bytes()
assert sha(src.read_bytes())==inputs['runtimeTest']['homeTestSourceSha256']
assert sha(Path(inputs['runtimeTest']['path']).read_bytes())==inputs['runtimeTest']['sha256']
assert sha(Path(inputs['release']['apk']['path']).read_bytes())==inputs['release']['apk']['sha256']
members={};restores=[];roots=sorted(B.glob('rf312-fixed-vault-proposal*'))+[B/'rf312-fixed-vault-final-cohort-20261012',B/'rf312-fixed-vault-stable-cohort-20261012',S]
def add(name,p):
 assert p.is_file() and not p.stat().st_file_attributes&0x400
 assert p.suffix.lower() not in ['.tar','.apk','.jar','.so','.dll','.exe','.jks','.keystore']
 assert name not in members;members[name]=(p,p.read_bytes())
def inventory(p):
 with tarfile.open(p) as t:
  out={}
  for m in t:
   assert m.name not in out
   data=t.extractfile(m).read() if m.isfile() else b''
   out[m.name]=[m.type.hex(),m.mode,m.linkname,m.size,sha(data)]
  return out
for root in roots:
 label=root.name
 for p in root.iterdir():
  if p.is_file() and p.suffix in ['.json','.log','.py','.kt']:add(label+'/'+p.name,p)
  elif p.is_dir() and ((p/'report.json').exists() or p.name in ['preflight-package-read-failure-audit','owned-recovery-after-adb-daemon-failure']):
   for q in p.rglob('*'):
    if q.is_file() and q.suffix in ['.json','.log','.xml','.png']:add(label+'/'+q.relative_to(root).as_posix(),q)
   before=p/'private-data-before.tar';after=p/'private-data-restored.tar'
   if before.exists():
    if not after.exists():
     assert root.name=='rf312-fixed-vault-stable-cohort-20261012' and p.name=='cohort-5000-01'
     recovery=load(root/'owned-recovery-after-adb-daemon-failure/recovery.json');assert recovery['recoveryComplete']
     after=root/'owned-recovery-after-adb-daemon-failure/private-data-restored.tar'
    left=inventory(before);assert left==inventory(after)
    r=load(p/'report.json');assert sha(before.read_bytes())==r['backup']['sha256']
    restores.append({'round':label,'name':p.name,'entriesIncludingRoot':len(left),'exactContentsLinksAndModesEqual':True,'inventorySha256':sha(json.dumps(left,sort_keys=True,separators=(',',':')).encode()),'originalAutomatedRestoreSucceeded':r['restored']})
 project=root/'project'
 for rel in ['build.gradle.kts','gradle.properties','settings.gradle.kts','src/main/AndroidManifest.xml','src/main/java/com/solosoul/app/AndroidFixedVaultPerfInstrumentedTest.kt']:
  p=project/rel
  if p.is_file():add(label+'/project/'+rel,p)
for p in B.glob('*rf312-fixed-vault*.py'):add('tools/'+p.name,p)
for name in ['build-rf312-release-probe-20261012.py']:
 add('tools/'+name,B/name)
for root in [B/'api31-host-rf312-fixed-vault-20261012',B/'api31-software-rf312-fixed-vault-20261012']:
 for p in root.iterdir():
  if p.is_file() and p.suffix in ['.json','.log','.py','.ps1']:add('environment/'+root.name+'/'+p.name,p)
server=B/'owned-adb-nodaemon-20261012';snap=S/'service-log-snapshots';snap.mkdir(exist_ok=False)
for p in server.iterdir():
 if p.is_file() and p.suffix in ['.json','.log']:
  copy=snap/p.name;copy.write_bytes(p.read_bytes());add('service/'+p.name,copy)
assert not (server/'terminal.json').exists()
name='rf312-android-fixed-vault-2026-10-12';O=R/'docs/performance'/name;assert not O.exists();O.mkdir();index=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as t:
 for member,(p,data) in sorted(members.items()):
  info=tarfile.TarInfo(member);info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data))
  index.append({'member':member,'source':str(p),'bytes':len(data),'sha256':sha(data)})
with tarfile.open(O/'raw.tar.gz') as t:
 assert len(t.getmembers())==len(index)
 for row in index:
  data=t.extractfile(row['member']).read();assert len(data)==row['bytes'] and sha(data)==row['sha256']
def put(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
put(O/'index.json',{'task':'RF-312','allMembersReadbackVerified':True,'privateTarApkHeadersJarsKeysCachesExcluded':True,'members':index})
(O/'.gitattributes').write_text('raw.tar.gz -text\n',encoding='utf-8',newline='\n')
put(R/'docs/performance'/(name+'.json'),{'task':'RF-312','acceptedScope':'API31 x86_64 optimized early-observer Release fixed100/5000 six-stage native UI readiness and transport metadata; five complete new samples each','taskClosed':False,'fullRF312Accepted':False,
 'sourceHeadBeforeWork':'8b6d810c5','androidMainSourceHeadFromOriginalPreparation':inputs['sourceHead'],'currentFrozenRuntimeInputs':inputs['runtimeSourceFiles'],'newNativeTestSourceSha256':sha(src.read_bytes()),'publishedNativeSourceMatchesCompiledTest':True,
 'mainApk':inputs['release']['apk'],'testApk':inputs['runtimeTest'],'legacyHomeTestSourceSha256ActuallyNamesNewFixedVaultSource':True,'defaultProductionMainAndDependenciesUnchanged':True,'statistics':stats,'independentExactRestorations':restores,
 'failureGroupsRetained':['proposal rounds1/2/3/4/6/7','round8 partial6pass+preflight fail; whole group rejected','final cohort5pass5fail; whole group rejected','stable cohort2native pass with1restore failure; exact manual recovery and whole rejection','preparation path/encoding/outcome aggregation failures preserved'],
 'diagnosticOnlyRoundsExcluded':['round9 first/second5000'],'developmentCasesExcluded':['round8 first100','round10 first100/5000'],'managedPrivateServer':load(server/'live.json'),'oldServerBirthUnchangedDoesNotProveCrash':True,
 'serviceLogsCapturedAtArchiveTimeServerRetainedForFollowingOwnedWork':True,'archive':{'path':name+'/raw.tar.gz','members':len(index),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha((O/'raw.tar.gz').read_bytes()),'allMembersReadbackVerified':True},
 'countsUnchanged':'312/323 closed;5 awaiting verification;6 pending','remainingFullScope':stats['unmeasured']})
print(json.dumps({'archiveMembers':len(index),'exactRestorations':len(restores),'newNativeSamples':10,'sizes':[100,5000],'fullRF312Accepted':False}),flush=True)
