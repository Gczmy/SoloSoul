from pathlib import Path
import hashlib,json,math,statistics,tarfile
S=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def metrics(values):
 assert values and all(type(x) in (int,float) and math.isfinite(x) and x>=0 for x in values)
 v=sorted(values)
 return {'samples':len(v),'median':statistics.median(v),'p95NearestRank':v[max(0,math.ceil(len(v)*.95)-1)],'min':v[0],'max':v[-1]}
cohorts=load(S/'cohorts.receipt.json');assert len(cohorts['rows'])==10
names=['activity-startup','password-unlock','workspace','search-needle','application-lock','password-reunlock']
rows=[]
for row in cohorts['rows']:
 folder=S/row['name'];r=load(folder/'report.json');e=load(folder/'device-files/report.json');count=row['objectCount']
 assert e==r['fixedVaultEvidence']
 assert e['measurementDiagnosticOnly'] is False
 assert len(e['touches'])==10 and all(t['before']['hitIsTarget'] and t['before']['stableFrames']>=3 for t in e['touches'])
 assert all(r.get(k) is True for k in ['passed','nativePassed','restored','originalApksRestored','ownedProbeRemoved','blurRestored','frozenInputsUnchanged'])
 assert r['restoreVerification']=={'entries':216,'allFileContentsLinksAndModesMatch':True}
 assert r['originalInstalledPackages']==r['restoredInstalledPackages']
 assert e['objectCount']==count and e['displayedSearchResults']==min(count//20,50) and e['fixtureSearchMatches']==count//20
 assert [p['name'] for p in e['phases']]==names
 assert len({e['processId']})==1 and e['uid']==r['releaseInstalledPackage']['uid']
 before=folder/'private-data-before.tar';after=folder/'private-data-restored.tar'
 # The driver comparison covers content, directory/link identity and mode;
 # independently recompute the exact backup digest and content inventories here.
 assert sha(before)==r['backup']['sha256']
 def inventory(p):
  out={}
  with tarfile.open(p) as t:
   for m in t:
    assert m.name not in out
    data=t.extractfile(m).read() if m.isfile() else b''
    out[m.name]=(m.type,m.mode,m.linkname,m.size,hashlib.sha256(data).hexdigest())
  return out
 assert after.is_file(), 'Independent restored TAR required'
 assert inventory(before)==inventory(after)
 original=load(S/'inputs.json')
 for label,key in [('main','originalDebug'),('test','originalTest')]:
  assert r['restoredInstalledPackages'][label]['sha256']==original[key]['sha256']
 for phase in e['phases']:
  assert phase['success'] is True and phase['nativeStartedAtNs']<=phase['nativeFinishedAtNs']
  assert math.isclose(phase['durationMs'],(phase['nativeFinishedAtNs']-phase['nativeStartedAtNs'])/1e6,abs_tol=.000001,rel_tol=0)
  obs=phase['observer'];assert obs['valid'] and obs['invalidReasons']==[] and obs['runId']==e['runId']
  assert obs['observedCount']==len(obs['commands']) and phase['transportAttempts']==phase['ipcEnd']-phase['ipcStart']
  for command in obs['commands']:assert set(command)=={'command','transport','atMs'}
 assert sum(c['command']=='login' for c in e['phases'][-1]['observer']['commands'])==2
 assert len(e['memorySamples'])>0 and e['memorySamplerExited'] and not e.get('memoryError')
 rows.append({'name':row['name'],'objectCount':count,'runId':e['runId'],'processId':e['processId'],'nativeReportSha256':sha(folder/'device-files/report.json'),
 'phases':[{**{k:p[k] for k in ['name','durationMs','transportAttempts','ipcStart','ipcEnd']},'nativeTargetReadinessMs':sum(t['before']['readinessMs'] for t in e['touches'] if p['nativeStartedAtNs']<=t['nativeBeforeAtNs']<=p['nativeFinishedAtNs']),'nativeTouches':sum(p['nativeStartedAtNs']<=t['nativeBeforeAtNs']<=p['nativeFinishedAtNs'] for t in e['touches'])} for p in e['phases']],
 'sampledMainPssMaxBytes':max(m['pssBytes'] for m in e['memorySamples']),'memorySamples':len(e['memorySamples']),'restoreEntries':216,'fullRestoration':True,
 'privateInventoryIndependentlyCompared':after.exists()})
assert len({r['runId'] for r in rows})==10
summary={}
for count in [100,5000]:
 subset=[r for r in rows if r['objectCount']==count];assert len(subset)==5
 summary[str(count)]={'durationMs':{name:metrics([next(p['durationMs'] for p in r['phases'] if p['name']==name) for r in subset]) for name in names},
 'transportAttempts':{name:metrics([next(p['transportAttempts'] for p in r['phases'] if p['name']==name) for r in subset]) for name in names},
 'nativeTargetReadinessMs':{name:metrics([next(p['nativeTargetReadinessMs'] for p in r['phases'] if p['name']==name) for r in subset]) for name in names},
 'sampledMainPssMaxBytes':metrics([r['sampledMainPssMaxBytes'] for r in subset])}
result={'scope':'android-API31-x86_64-optimized-release-software-AVD-six-phase-baseline','developmentSamplesExcluded':True,
 'sampleOrder':'interleaved100/5000','nativeClock':'elapsedRealtimeNanos','sampleCountPerSize':5,'p95Definition':'nearest-rank; n=5 tail is maximum, not a stable population p95',
 'startupDefinition':'Activity launch to production password form and focused target with two frames; excludes runner/process launch',
 'memoryDefinition':'serial main-process PSS including instrumentation runner, not renderer or continuous peak',
 'nativeTargetReadinessDefinition':'sum of reported touch-ready waits inside each native phase; startup has no native taps so zero here does not mean startup had no readiness; phase duration retains all waiting, no inferred latency subtraction',
 'uiWorkspaceDefinition':'enter identity then All; exactly initial50 rows; frozen type=note/section=identity',
 'timingIncludes':'instrumentation, polling, drawing and native-target readiness; natural notifications and keyboard layout can delay a usable target; not isolated business/IPC latency',
 'searchDefinition':'production limit50; fixture full matches5/250, rendered5/50','fullRF312Accepted':False,
 'unmeasured':['OCR','attachment-preview','PDF-preview','renderer-memory','process-cold-start','physical-device','other-platforms'],'rows':rows,'statistics':summary}
with (S/'statistics.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'samples':len(rows),'sizes':list(summary),'allFullRestorations':True,'fullRF312Accepted':False}),flush=True)
