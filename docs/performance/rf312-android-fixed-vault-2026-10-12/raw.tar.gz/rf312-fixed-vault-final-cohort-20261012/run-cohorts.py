from pathlib import Path
import json,subprocess,time,hashlib
B=Path(__file__).parent;rows=[];began=time.monotonic()
for sample in range(1,6):
 for count in [100,5000]:
  name=f'cohort-{count}-{sample:02}'
  print('Starting '+name,flush=True)
  code=subprocess.call(['C:/Python314/python.exe',str(B/f'run-{name}.py')],cwd='D:/SoloSoul')
  receipt=json.loads((B/f'{name}.receipt.json').read_text())
  rows.append({'name':name,'objectCount':count,'sample':sample,'exitCode':code,'receipt':receipt})
  (B/'cohorts.progress.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
  if not all(receipt.get(k) is True for k in ['restored','originalApksRestored','ownedProbeRemoved','blurRestored','sourceInputsUnchanged']):
   raise RuntimeError('Full restoration required before the next native mutation: '+name)
result={'rows':rows,'elapsedSeconds':time.monotonic()-began,'passed':all(r['exitCode']==0 and r['receipt']['passed'] for r in rows),'sampleOrder':'interleaved100/5000 five each; first passing development sample excluded','fullRF312Accepted':False}
with (B/'cohorts.receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'samples':len(rows),'passed':result['passed'],'elapsedSeconds':result['elapsedSeconds']}),flush=True)
raise SystemExit(0 if result['passed'] else 1)
