from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,tarfile
S=Path(__file__).parent;B=S.parent;H=B/'api31-software-rf312-fixed-vault-20261012';O=S/'owned-recovery-after-adb-daemon-failure';O.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
r=load(S/'cohort-5000-01/report.json');inputs=load(S/'inputs.json');oldcommands=load(S/'cohort-5000-01/commands.json')
assert r['originalApksRestored'] and r['ownedProbeRemoved'] and r['blurRestored'] and not r['restored']
backup=Path(r['backup']['path']);assert backup.resolve()==(S/'cohort-5000-01/private-data-before.tar').resolve() and sha(backup.read_bytes())==r['backup']['sha256']
remote=[x['command'][2] for x in oldcommands if x['command'][:2]==['push',str(backup)]][-1]
assert re.fullmatch(r'/data/local/tmp/fe2-private-backup-[a-f0-9]{32}\.tar',remote)
owned=next(p for p in load(H/'owned-processes-after-launch.json') if p['ProcessId']==load(H/'boot.receipt.json')['pid'])
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
current=json.loads(subprocess.check_output([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {owned['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json"],text=True))
for k in ['Name','ProcessId','ExecutablePath','CommandLine']:assert current[k]==owned[k]
assert datetime.datetime.fromisoformat(current['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
env=os.environ.copy();env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',PYTHONUTF8='1');ledger=[]
def adb(label,*args):
 p=subprocess.run([str(B/'sdk/platform-tools/adb.exe'),'-H','localhost','-P','5049','-s','emulator-5586',*args],capture_output=True,timeout=45,env=env)
 (O/(label+'.stderr.log')).write_bytes(p.stderr);ledger.append({'label':label,'command':list(args),'exitCode':p.returncode,'stdoutSha256':sha(p.stdout),'stderrSha256':sha(p.stderr)})
 (O/'commands.json').write_text(json.dumps(ledger,indent=2)+'\n',encoding='utf-8')
 p.check_returncode();return p.stdout
assert adb('state','get-state').strip()==b'device'
assert adb('avd','emu','avd','name').decode().splitlines()[0]=='SoloSoul_RF121_API31_20261010'
packages={}
for package,key,label in [('com.solosoul.app','originalDebug','main'),('com.solosoul.app.test','originalTest','test')]:
 path=adb(label+'-path','shell','pm','path',package).decode().strip();assert re.fullmatch(r'package:/data/app/(?:[A-Za-z0-9_~+=.-]+/){1,2}base\.apk',path)
 data=adb(label+'-apk','exec-out','cat',path.removeprefix('package:'));assert sha(data)==inputs[key]['sha256']
 dump=adb(label+'-dump','shell','dumpsys','package',package).decode();(O/(label+'-package.log')).write_text(dump,encoding='utf-8')
 uid=re.findall(r'^\s*userId=(\d+)\s*$',dump,re.M);flags=re.findall(r'^\s*pkgFlags=\[([^\]]*)\]',dump,re.M);assert len(uid)==len(flags)==1
 packages[label]={'sha256':sha(data),'bytes':len(data),'uid':int(uid[0]),'debuggable':'DEBUGGABLE' in flags[0].split()}
assert packages==r['originalInstalledPackages']
assert not adb('probe','shell','pm','list','packages','com.solosoul.app.releaseprobe').strip()
adb('force-stop','shell','am','force-stop','com.solosoul.app')
processes=adb('stopped','shell','ps','-A','-o','PID,NAME').decode().splitlines()
assert not any(line.split() and (line.split()[-1]=='com.solosoul.app' or line.split()[-1].startswith('com.solosoul.app:')) for line in processes)
# Current app-private root was cleared by the original driver. Refuse overwriting
# any unexpected member instead of doing a second deletion.
assert not adb('private-root','shell','run-as','com.solosoul.app','ls','-A').strip()
assert adb('remote-sha','shell','sha256sum',remote).decode().split()[0]==r['backup']['sha256']
def inventory(path):
 with tarfile.open(path) as t:
  out={};rootModes=[]
  for m in t:
   assert m.name not in out
   if m.name.rstrip('/')=='.':assert m.isdir();rootModes.append(m.mode)
   assert not m.name.startswith('/') and '..' not in Path(m.name).parts
   data=t.extractfile(m).read() if m.isfile() else b''
   out[m.name]=[m.type.hex(),m.mode,m.linkname,m.size,sha(data)]
  assert len(rootModes)==1
  return out,rootModes[0]
before,rootmode=inventory(backup);assert len(before)==217
adb('backup-readable','shell','chmod','644',remote)
adb('extract','shell','run-as','com.solosoul.app','tar','-xpf',remote)
adb('root-mode','shell','run-as','com.solosoul.app','chmod',format(rootmode,'o'),'.')
restored=O/'private-data-restored.tar';restored.write_bytes(adb('restored-tar','exec-out','run-as','com.solosoul.app','tar','-cf','-','.'))
after,afterRootMode=inventory(restored);assert before==after and rootmode==afterRootMode
assert adb('root-mode-check','shell','run-as','com.solosoul.app','stat','-c','%a','.').decode().strip()==format(rootmode,'o')
assert adb('remote-final-sha','shell','sha256sum',remote).decode().split()[0]==r['backup']['sha256']
adb('remove-owned-remote-backup','shell','rm','--',remote)
previous=load(S/'cohort-100-01/commands.json');command=['shell','settings','get','global','disable_window_blurs'];value=next(x for x in reversed(previous) if x['command']==command and x['exitCode']==0)
assert sha(adb('blur',*command))==value['stdoutSha256']
assert all(sha((Path('D:/SoloSoul')/n).read_bytes())==h for n,h in inputs['runtimeSourceFiles'].items())
result={'recoveryComplete':True,'originalDriverFailureRetained':True,'ownedEmulatorIdentityUnchanged':current,'originalPackages':packages,'privateEntriesExcludingRoot':216,
 'allOriginalPrivateContentsLinksAndModesExactlyRestored':True,'originalRootModeRestored':True,'blurRestored':True,'probeAbsent':True,'ownedRemoteBackupRemovedAfterDigestVerification':True,
 'nativeMeasurementAccepted':False,'wholePartialCohortRejected':True,'noSecondPrivateRootDeletion':True,'sourcesUnchanged':True,'privateInventorySha256':sha(json.dumps(before,sort_keys=True,separators=(',',':')).encode())}
(O/'recovery.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'recoveryComplete':True,'originalPackagesAnd216PrivateEntriesRestored':True,'ownedRemoteBackupRemoved':True,'wholeCohortAccepted':False}),flush=True)
