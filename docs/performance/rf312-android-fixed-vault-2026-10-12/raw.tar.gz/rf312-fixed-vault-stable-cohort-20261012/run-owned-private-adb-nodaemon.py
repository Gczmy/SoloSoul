from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
B=Path(__file__).parent.parent;O=B/'owned-adb-nodaemon-20261012';O.mkdir(exist_ok=False)
adb=B/'sdk/platform-tools/adb.exe';pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
env=os.environ.copy();env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',PYTHONUTF8='1')
command="$listeners=Get-NetTCPConnection -LocalPort 5049 -State Listen; if(@($listeners).Count -ne 1){throw 'Private listener identity ambiguous'}; Get-CimInstance Win32_Process -Filter ('ProcessId = '+$listeners.OwningProcess) | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json"
before=json.loads(subprocess.check_output([pwsh,'-NoProfile','-Command',command],text=True))
assert before['ProcessId']==9092 and before['Name']=='adb.exe' and Path(before['ExecutablePath']).resolve()==adb.resolve()
assert before['CommandLine']=='adb -L tcp:localhost:5049 fork-server server --reply-fd 736'
assert datetime.datetime.fromisoformat(before['CreationDate'])==datetime.datetime.fromisoformat('2026-10-12T14:08:07.252602+01:00')
listing=subprocess.check_output([str(adb),'-H','localhost','-P','5049','devices','-l'],env=env,text=True)
rows=[line.split() for line in listing.splitlines() if line.strip() and not line.startswith('List of devices')]
assert len(rows)==1 and rows[0][:2]==['emulator-5586','device']
assert subprocess.check_output([str(adb),'-H','localhost','-P','5049','-s','emulator-5586','emu','avd','name'],env=env,text=True).splitlines()[0]=='SoloSoul_RF121_API31_20261010'
(O/'before.json').write_text(json.dumps({'server':before,'soleDevice':listing,'oldServerBirthUnchangedDespiteClientFailure':True,'causeNotAssumedProcessCrash':True},indent=2)+'\n',encoding='utf-8')
subprocess.run([str(adb),'-H','localhost','-P','5049','kill-server'],env=env,check=True,capture_output=True,timeout=30)
remaining=subprocess.check_output([pwsh,'-NoProfile','-Command',"@(Get-CimInstance Win32_Process -Filter 'ProcessId = 9092').Count"],text=True).strip();assert remaining=='0'
assert subprocess.check_output([pwsh,'-NoProfile','-Command',"@(Get-NetTCPConnection -LocalPort 5049 -State Listen -ErrorAction SilentlyContinue).Count"],text=True).strip()=='0'
cmd=[str(adb),'-L','tcp:localhost:5049','server','nodaemon']
with (O/'server.stdout.log').open('xb') as out,(O/'server.stderr.log').open('xb') as err:
 p=subprocess.Popen(cmd,env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
 current=json.loads(subprocess.check_output([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {p.pid}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json"],text=True))
 assert current['ProcessId']==p.pid and Path(current['ExecutablePath']).resolve()==adb.resolve() and 'server nodaemon' in current['CommandLine']
 (O/'live.json').write_text(json.dumps({'pid':p.pid,'command':cmd,'identity':current,'adbSha256':hashlib.sha256(adb.read_bytes()).hexdigest(),'oldPrivateServerStoppedNormally':True,'default5037Untouched':True,'emulatorAndAppDataUntouched':True,'noGlobalSettingsChanged':True})+'\n',encoding='utf-8')
 print('Owned private5049 ADB nodaemon server live PID',p.pid,flush=True)
 code=p.wait()
 (O/'terminal.json').write_text(json.dumps({'exitCode':code,'identity':current,'observedActualTerminal':True})+'\n',encoding='utf-8')
 print('Owned private5049 server actual terminal exit',code,flush=True)
 raise SystemExit(code)
