import pathlib,json,hashlib,datetime,sys
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-ocr-20261005');r=pathlib.Path(r'C:\Users\40299571\SoloSoul')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda n:json.loads((s/n).read_text(encoding='utf-8-sig'))
assert len(sys.argv)==2 and sys.argv[1] in ['100','5000'];group='samples'+sys.argv[1]+'-final'
cleanup=load(group+'-cache-cleanup.json');freeze=load(group+'-pre-cache-vault-freeze.json')
assert cleanup['complete'] and cleanup['processesTerminated']==0 and len(cleanup['removedCachePaths'])==24 and len(cleanup['roots'])==3
assert all(not pathlib.Path(p).exists() for p in cleanup['removedCachePaths'])
assert all(sha(pathlib.Path(x['copy']))==x['sha256'] for x in cleanup['preservedLogs'])
roots=[]
for x in freeze['roots']:
 root=pathlib.Path(x['root']);assert root in [s/group/('sample-%03d'%i) for i in [1,2,3]]
 vault=root/'vault'
 paths=sorted(p for p in vault.rglob('*') if p.is_file());assert len(paths)==len(x['files'])
 expected={x['relativePath']:x for x in x['files']}
 for p in paths:
  relative=str(p.relative_to(vault)).replace('\\','/');v=expected[relative]
  assert not p.is_symlink() and p.resolve().is_relative_to(vault.resolve()) and p.stat().st_size==v['bytes'] and sha(p)==v['sha256']
 assert sha(root/'native-perf-ocr-input.png')=='56a9d54d9b70a3ee1b22e0b08b755b6cfc15ee125df4b11d52f8523583dcacaa'
 roots.append({'root':str(root),'vaultFilesUnchanged':len(paths),'publicInputUnchanged':True})
source=load('source-freeze-final.json')['files'];assert all(sha(r/p)==h for p,h in source.items())
public=load('public-source-freeze-final.json')['files'];assert all(sha(pathlib.Path(p))==h for p,h in public.items())
res=load('resource-freeze-final.json')['records'];assert all(sha(pathlib.Path(v['source']))==v['sha256']==sha(pathlib.Path(v['copy'])) for v in res)
build=load('build-checkpoint-final.json');assert sha(pathlib.Path(build['exe']))==build['sha256']
base=load('baseline-after-rf1094.json');assert all(sha(pathlib.Path(p))==h for p,h in base['oldPdfBuilds'].items());assert sha(pathlib.Path(base['priorOcrBuild']['exe']))==base['priorOcrBuild']['sha256']
v={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'group':group,'complete':True,'verifiedIdentities':len(cleanup['verifiedIdentities']),'removedCachePaths':len(cleanup['removedCachePaths']),'unlinkedEntries':len(cleanup['unlinkedCacheEntries']),'preservedLogs':len(cleanup['preservedLogs']),'roots':roots,'inputsUnchanged':len(source),'publicFilesUnchanged':len(public),'resourcesUnchanged':len(res),'previousExesPreserved':len(base['oldPdfBuilds'])+1,'processesTerminated':0}
(s/(group+'-post-cache-review.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(v,ensure_ascii=False))
