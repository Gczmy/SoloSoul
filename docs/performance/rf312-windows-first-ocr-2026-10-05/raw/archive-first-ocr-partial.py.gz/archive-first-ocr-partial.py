import pathlib,json,hashlib,datetime,gzip,sys
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-ocr-20261005')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda n:json.loads((s/n).read_text(encoding='utf-8-sig'));now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
build=load('build-checkpoint-final.json');assert load('release-build-final.receipt.json')['exitCode']==0 and sha(pathlib.Path(build['exe']))==build['sha256']
receipts={n:load(n+'.receipt.json') for n in ['ocr-corrected-native-tests','ocr-corrected-native-clippy','ocr-corrected-fmt-check','ocr-first-node-tests','ocr-first-js-format-check','ocr-first-diff-check']};assert all(v['exitCode']==0 for v in receipts.values())
assert '96 passed; 0 failed' in (s/'ocr-corrected-native-tests.stdout.log').read_text(encoding='utf-8-sig')
node=(s/'ocr-first-node-tests.stdout.log').read_text(encoding='utf-8-sig');assert all(x in node for x in ['tests 205','pass 204','skipped 1','fail 0'])
source=load('source-freeze-final.json');assert len(source['files'])==459 and all(sha(r/p)==h for p,h in source['files'].items())
accepted=load('samples100-final/native-perf-sdk-journey-results.json');summary=accepted['summary']
assert accepted['success'] and accepted['sourceUnchanged'] and len(accepted['samples'])==3 and len(summary)==4 and all(x['successfulSamples']==3 and x['medianMs'] is not None and x['p95Ms'] is not None for x in summary)
actual=load('samples100-final-actual-ocr-review.json');assert actual['success']
groups=['samples100-final','samples5000-final','samples5000-final-repeat'];post={g:load(g+'-post-cache-review.json') for g in groups}
assert all(v['complete'] and v['removedCachePaths']==24 and v['previousExesPreserved']==9 and v['processesTerminated']==0 for v in post.values())
failed={}
for group in groups[1:]:
 v=load(group+'/native-perf-sdk-journey-results.json');review=load(group+'-failure-review.json')
 assert not v['success'] and v['sourceUnchanged'] and len(v['samples'])==3 and sum(bool(x['success']) for x in v['samples'])==2
 assert all(x['medianMs'] is None and x['p95Ms'] is None for x in v['summary']) and review['acceptedPerformanceMetrics'] is None
 assert len([x for x in review['samples'] if x['scanAttempts']==0])==1
 failed[group]={'requested':3,'nativeOcrSuccesses':2,'acceptedMetrics':None,'summary':v['summary'],'failureReview':review,'postCacheReview':post[group]}
known=sum(len(load(g+'-identity-scope.json')['identities']) for g in groups);extra=sum(len(load(g+'-identity-scope.json')['additionalCleanupPids']) for g in groups)
assert known==63 and extra==15
old=load('samples100-failure-review.json');assert old['completed']==3 and not old['fullFirstOcrAcceptance']
archive=r/'docs/performance/rf312-windows-first-ocr-2026-10-05';assert not archive.exists();archive.mkdir(parents=True);(archive/'.gitattributes').write_text('*.gz -text\n',encoding='utf-8',newline='\n')
selected=[]
for p in sorted(s.iterdir()):
 if p.is_file() and p.suffix.lower() in ['.json','.py','.ps1','.log','.md']:selected.append(('raw/'+p.name,p))
for group in ['samples100']+groups:
 root=s/group
 for p in sorted(root.iterdir()):
  if p.is_file() and p.suffix.lower() in ['.json','.log']:selected.append(('raw/'+group+'/'+p.name,p))
 for i in [1,2,3]:
  root=s/group/('sample-%03d'%i)
  for p in sorted(root.glob('native-perf-*')):
   if p.is_file() and p.suffix.lower() in ['.json','.png']:selected.append(('raw/'+str(p.relative_to(s)).replace('\\','/'),p))
  logs=root/'preserved-app-logs'
  if logs.exists():
   for p in sorted(logs.rglob('*')):
    if p.is_file():selected.append(('raw/'+str(p.relative_to(s)).replace('\\','/'),p))
paths=['tauri/scripts/native-perf-sdk-journey.mjs','tauri/scripts/run-node-tests.mjs','tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs','tauri/src-tauri/src/native_perf/sdk_cdp.rs','tauri/src-tauri/src/native_perf/sdk_journey.js','tauri/src-tauri/src/native_perf/sdk_journey.rs','tauri/src-tauri/src/native_perf/startup.rs','tauri/src-tauri/src/native_perf/sdk_ocr.rs','tauri/src-tauri/src/native_perf/sdk_ocr_picker.rs','tauri/scripts/native-perf-ocr-contract.mjs','tauri/scripts/native-perf-ocr.mjs','tauri/scripts/native-perf-ocr.test.mjs']
for name in paths:assert sha(r/name)==source['files'][name];selected.append(('source/'+name,r/name))
assert len(set(n for n,p in selected))==len(selected);entries=[]
for name,p in selected:
 data=p.read_bytes();copy=archive/(name+'.gz');copy.parent.mkdir(parents=True,exist_ok=True);compressed=gzip.compress(data,mtime=0);assert not copy.exists();copy.write_bytes(compressed);assert gzip.decompress(copy.read_bytes())==data
 entries.append({'original':str(p),'archive':name+'.gz','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'archiveBytes':len(compressed),'archiveSha256':sha(copy)})
write(archive/'index.json',{'schemaVersion':1,'task':'RF-312','scope':'Byte-exact initial OCR failures, corrected 100 success and both failed 5000 whole groups; EXEs/resources/Vault referenced by immutable hashes','files':entries})
v={'schemaVersion':1,'task':'RF-312','at':now(),'baselineHead':source['head'],'build':build,'checks':{'nativeTestsPassed':96,'nativeTestsFilteredOut':779,'nodeTests':205,'nodePassed':204,'nodeFailed':0,'nodeSkipped':1,'nodeSkipReason':'existing Windows symlink permission case','receipts':receipts},'scope':'Windows fixed public PNG/default small/first per process; DOM + two rAF + viewport hit; no screenshot pixel acceptance','accepted100':{'requested':3,'successful':3,'summary':summary,'actualReview':actual,'postCacheReview':post['samples100-final']},'failed5000Groups':failed,'oldOriginalFailure':{'requested':3,'failed':3,'acceptedMetrics':None,'independentProductFix':'RF-1094 / 6baee574','priorRawEvidence':'../verification/rf1094-general-ocr-2026-10-05/index.json','cacheReview':load('samples100-post-cache-review.json')},'freshCleanup':{'pidBirthIdentities':known,'additionalCleanupPidsWithoutStoredBirth':extra,'removedCachePaths':72,'unlinkedEntries':9,'newGroups':3,'vaultInventoriesPreserved':True,'attachmentCiphertextsUnchanged':36,'noAdditionalProcessesTerminated':True},'unmeasured':['5000 whole-group accepted OCR performance','PowerShell startup/query/serialization timeout root cause','OCR-general-images','OCR-PDF','OCR-engine-stage-attribution','system-sleep','other-platforms','original-home-timeout-root-cause'],'rawArchiveCount':len(entries),'rf312Complete':False,'remotePushPerformed':False}
write(r/'docs/performance/rf312-windows-first-ocr-2026-10-05.json',v)
text=(s/'first-ocr-document-draft.md').read_text(encoding='utf-8-sig').replace('新构建实际结果将在验收后追加。','修复后结果和未通过范围如下。')
text=text.replace('每次新进程采用默认 small 档；','本口径不清空操作系统文件缓存，不能称为系统冷启动。每次新进程采用默认 small 档；')
text+='\n## 修复后实际验收及失败保留\n\n'
text+=f"冻结 Release SHA-256 `{build['sha256']}`，459 项输入、94 份资源、171 个公开源文件和九个旧构建保持。100 对象组三次完整原生行程通过，每次仅扫描一次，完整三行结果通过两帧及视口命中探针。5000 对象两轮各请求三次，均只有两次完整成功，四项整组统计全部为空；不跨组拼接成功样本。\n\n"
text+='设备：Intel Core i7-9700，8 逻辑核心、系统物理内存约 15.79GiB；Windows 11 Enterprise LTSC 10.0.26100 x64。rustc 1.96.0，驱动 Node v24.16.0。以下只报告 100 对象 n=3 的中位 / P95，单位 ms；P95 为这三次最大值，含模型加载、识别、界面与采样开销。\n\n| 指标 | 100 对象 | 5000 对象 |\n| --- | ---: | --- |\n'
for x in summary:text+=f"| `{x['name']}` | {x['medianMs']:.2f} / {x['p95Ms']:.2f} | 未验收，整组统计为空 |\n"
text+='\n第一轮 5000 的 sample-003、第二轮的 sample-001 均在前置进程快照超过既有 15000ms 预算后被驱动拒绝，未写入输入授权；原始原生证明只有 startup 阶段、扫描零次，最终原因分别为 input-authorization-timeout 和 document-invalidated。不能把退出后的原生最终原因直接认作独立产品根因。其他四个实际 OCR 样本的完整结果仍保留，但不用它们输出 5000 分布。停止继续无依据复跑，下一步归因 PowerShell 启动、查询、序列化和驱动等待阶段，预算未加长、身份门禁未弱化。\n\n'
text+='96 项原生回归、严格 Clippy 和格式检查通过；Node 204 passed / 0 failed / 1 既有 symlink 权限 skip。默认前端无改动，不将旧 F/WEB 结果冒充本次新运行；RF-1094 的 446 项 core 检查已有独立证据。\n\n'
text+=f"新构建三组 fresh CIM 核验 {known} 条 PID/birth 身份退出，另确认 {extra} 个缺少存量 birth 的清理 PID 已不存在；后者不冒充完整身份。只清理 72 个精确缓存路径、解除 9 个核验链接；清理前后完整 Vault 清单、36 份附件密文、公开输入/源和旧构建保持，日志副本保留，没有终止额外进程。旧首次失败组另外保留三份日志、12 份附件密文及全部证明；83 份 RF-1094 原件仍逐字节一致。\n\n"
text+='[结构化验收](rf312-windows-first-ocr-2026-10-05.json)和[逐字节原件索引](rf312-windows-first-ocr-2026-10-05/index.json)保存全部失败/成功、源码、冻结、检查和清理。RF-312 保持待验证；下一步先定位进程采样超时，再补 5000 整组首次 OCR、原首页超时及阶段耗时归因，随后继续 Windows RF-121 完整窗口材质。RF-112/121 和 RF-122～127 前置不解除。独立本地提交，不推送。\n'
p=r/'docs/performance/RF-312-native-first-ocr.md';assert not p.exists();p.write_text(text,encoding='utf-8',newline='\n')
p=r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';oldtext=p.read_text(encoding='utf-8-sig');new=oldtext
header='> 最后更新：2026-10-05（RF-1094通用OCR字符修复；RF-312待新构建回验首次识别）';assert new.count(header)==1;new=new.replace(header,'> 最后更新：2026-10-05（RF-312首次OCR：100对象通过；5000两轮进程采样超时，继续归因）')
oldline=next(l for l in new.splitlines() if l.startswith('- 当前处理：'));new=new.replace(oldline,'- 当前处理：**RF-312：100对象首次OCR三次通过，5000两轮各一次前置进程采样超时，统计为空；下一步定位PowerShell/进程快照耗时，再补5000、首页超时和阶段归因**。')
row=next(l for l in new.splitlines() if l.startswith('|') and '[RF-312](#rf-312)' in l and l.count('|')==7);parts=row.split('|');parts[-2]=' [!] Windows100首次OCR已验；5000采样超时/多端待验 ';new=new.replace(row,'|'.join(parts))
new+='\n\n### RF-312 Windows 首次 OCR 原生回验（2026-10-05）\n\n'
new+=f"- RF-1094已独立提交`6baee574`；本阶段扩展非默认Windows native-perf与Node驱动，不改默认前端/登录/依赖。固定公开6274字节PNG通过owned原生选择器进入通用OCR，默认small、每进程一次扫描，完整三行结果通过两帧/视口命中；不是截图像素、系统冷态或任意图片准确率验收。\n- 96项原生回归、严格Clippy/格式/diff通过；Node204 passed/0 failed/1既有权限skip。冻结459输入、94资源，Release exit0、SHA`{build['sha256']}`；九个旧EXE和171公开源保持。100对象3/3完整行程通过，四项时间按原生Instant边界独立复算；n=3的P95为最大观测值，包含加载/识别/渲染/SDK开销。\n- 5000两轮各2/3；分别sample-003/sample-001在前置PowerShell进程快照超过15000ms后被拒绝，未获输入授权、扫描零次。原生最终原因分别为input-authorization-timeout/document-invalidated，不据此另断产品根因。两整组四项统计均null，保留四次实际OCR成功及完整失败，不跨组拼样本，不继续盲目复跑或增加预算。\n- 旧100三次结果超时的源码/EXE/证明保持，四项统计仍null；通用字符破坏由RF-1094确定性/真实图片红绿复现并独立修复。新构建三组fresh CIM核验63条PID/birth身份和15额外清理PID缺失，只清理72缓存/9链接；36附件密文、清理前后完整Vault清单、公开输入/源、资源和旧构建保持，日志副本保留，没有终止额外进程。旧失败组三份日志/12密文和83份RF-1094原件仍保持。\n- [口径与复跑](performance/RF-312-native-first-ocr.md)、[结构化验收](performance/rf312-windows-first-ocr-2026-10-05.json)与[原件索引](performance/rf312-windows-first-ocr-2026-10-05/index.json)归档。按RF-312独立本地提交、不推送；275/284、3待验证、6待执行不变，RF-312仍[!]。下一本地项进程采样超时/首页偶发超时和阶段耗时归因，再补5000整组与Windows RF-121完整合成；RF-112/121及RF-122～127前置不解除，goal保持active。\n"
p.write_text(new,encoding='utf-8',newline='\n');write(s/'documentation-scope-review.json',{'at':now(),'originalReportSha256':hashlib.sha256(oldtext.encode('utf-8')).hexdigest(),'updatedReportSha256':sha(p),'changedExistingReportLines':3,'rawArchiveCount':len(entries),'sourceUnchanged':True,'closed':275,'total':284,'rf312Complete':False})
print(json.dumps({'rawArchiveCount':len(entries),'buildSha':build['sha256'],'accepted100':True,'accepted5000':False,'knownIdentities':known,'extraCleanupPids':extra},ensure_ascii=False))
