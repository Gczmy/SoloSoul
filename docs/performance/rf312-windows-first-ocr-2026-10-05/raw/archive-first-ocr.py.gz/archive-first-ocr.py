import pathlib,json,hashlib,datetime,gzip,sys,re
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-ocr-20261005')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda n:json.loads((s/n).read_text(encoding='utf-8-sig'))
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
build=load('build-checkpoint-final.json');assert load('release-build-final.receipt.json')['exitCode']==0 and sha(pathlib.Path(build['exe']))==build['sha256']
receipts={name:load(name+'.receipt.json') for name in ['ocr-corrected-native-tests','ocr-corrected-native-clippy','ocr-corrected-fmt-check','ocr-first-node-tests','ocr-first-js-format-check','ocr-first-diff-check']}
assert all(v['exitCode']==0 for v in receipts.values())
assert '96 passed; 0 failed' in (s/'ocr-corrected-native-tests.stdout.log').read_text(encoding='utf-8-sig')
node=(s/'ocr-first-node-tests.stdout.log').read_text(encoding='utf-8-sig');assert 'tests 205' in node and 'pass 204' in node and 'skipped 1' in node and 'fail 0' in node
source=load('source-freeze-final.json');assert all(sha(r/p)==h for p,h in source['files'].items())
groups={};post={};reviews={};summaries={}
for size in ['100','5000']:
 group='samples'+size+'-final';v=load(group+'/native-perf-sdk-journey-results.json')
 assert v['success'] and v['sourceUnchanged'] and len(v['samples'])==3 and v['samplesRequested']==3
 assert len(v['summary'])==4 and all(x['successfulSamples']==3 and x['medianMs'] is not None and x['p95Ms'] is not None for x in v['summary'])
 assert all(x['success'] and x['cleanupIntegrity']['complete'] for x in v['samples'])
 post[size]=load(group+'-post-cache-review.json');assert post[size]['complete'] and post[size]['removedCachePaths']==24 and post[size]['processesTerminated']==0
 groups[size]=v;reviews[size]=load(group+'-actual-ocr-review.json');assert reviews[size]['success'];summaries[size]=v['summary']
old=load('samples100-failure-review.json');assert old['completed']==3 and not old['fullFirstOcrAcceptance']
archive=r/'docs/performance/rf312-windows-first-ocr-2026-10-05';assert not archive.exists()
archive.mkdir(parents=True);(archive/'.gitattributes').write_text('*.gz -text\n',encoding='utf-8',newline='\n')
selected=[]
for p in sorted(s.iterdir()):
 if p.is_file() and p.suffix.lower() in ['.json','.py','.ps1','.log','.md']:selected.append(('raw/'+p.name,p))
for group in ['samples100','samples100-final','samples5000-final']:
 root=s/group
 for p in sorted(root.iterdir()):
  if p.is_file() and p.suffix.lower() in ['.json','.log']:selected.append(('raw/'+group+'/'+p.name,p))
 for sample in [1,2,3]:
  root=s/group/('sample-%03d'%sample)
  for p in sorted(root.glob('native-perf-*')):
   if p.is_file() and p.suffix.lower() in ['.json','.png']:selected.append(('raw/'+str(p.relative_to(s)).replace('\\','/'),p))
  logs=root/'preserved-app-logs'
  if logs.exists():
   for p in sorted(logs.rglob('*')):
    if p.is_file():selected.append(('raw/'+str(p.relative_to(s)).replace('\\','/'),p))
paths=['tauri/scripts/native-perf-sdk-journey.mjs','tauri/scripts/run-node-tests.mjs','tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs','tauri/src-tauri/src/native_perf/sdk_cdp.rs','tauri/src-tauri/src/native_perf/sdk_journey.js','tauri/src-tauri/src/native_perf/sdk_journey.rs','tauri/src-tauri/src/native_perf/startup.rs','tauri/src-tauri/src/native_perf/sdk_ocr.rs','tauri/src-tauri/src/native_perf/sdk_ocr_picker.rs','tauri/scripts/native-perf-ocr-contract.mjs','tauri/scripts/native-perf-ocr.mjs','tauri/scripts/native-perf-ocr.test.mjs']
for name in paths:assert sha(r/name)==source['files'][name];selected.append(('source/'+name,r/name))
assert len(set(name for name,p in selected))==len(selected)
entries=[]
for name,p in selected:
 data=p.read_bytes();copy=archive/(name+'.gz');copy.parent.mkdir(parents=True,exist_ok=True)
 compressed=gzip.compress(data,mtime=0);assert not copy.exists();copy.write_bytes(compressed);assert gzip.decompress(copy.read_bytes())==data
 entries.append({'original':str(p),'archive':name+'.gz','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'archiveBytes':len(compressed),'archiveSha256':sha(copy)})
write(archive/'index.json',{'schemaVersion':1,'task':'RF-312','scope':'Byte-exact original failed and corrected Windows first OCR observations; excludes EXEs/resources/Vault databases referenced by immutable hashes','files':entries})
v={'schemaVersion':1,'task':'RF-312','at':now(),'baselineHead':source['head'],'build':build,'checks':{'nativeTestsPassed':96,'nativeTestsFilteredOut':779,'nodeTests':205,'nodePassed':204,'nodeFailed':0,'nodeSkipped':1,'nodeSkipReason':'existing Windows symlink permission case','receipts':receipts},'scope':'Windows fixed public PNG/default small/first per process; DOM + two rAF + viewport hit; not screenshot pixel acceptance or general OCR benchmark','metricSummary':summaries,'groups':{k:{'requested':3,'successful':3,'sourceUnchanged':True,'rawReport':'rf312-windows-first-ocr-2026-10-05/raw/samples'+k+'-final/native-perf-sdk-journey-results.json.gz','actualReview':reviews[k],'postCacheReview':post[k]} for k in groups},'failedOriginalGroup':{'requested':3,'failed':3,'acceptedMetrics':None,'oldExeSha256':'68f15acc614f8e5e0b75622078d4841de30e8d844c031af6b1247ce378b2b204','failure':'probe-timeout at ocrResultText; first actual scan each','independentProductFix':'RF-1094 / 6baee574','priorRawEvidence':'../verification/rf1094-general-ocr-2026-10-05/index.json','cacheReview':load('samples100-post-cache-review.json')},'unmeasured':['OCR-general-images','OCR-PDF','OCR-engine-stage-attribution','system-sleep','other-platforms','original-home-timeout-root-cause'],'performanceLimit':'n=3 each; P95=max observed sample; timings include model load, SDK, polling and UI overhead','rawArchiveCount':len(entries),'rf312Complete':False,'remotePushPerformed':False}
write(r/'docs/performance/rf312-windows-first-ocr-2026-10-05.json',v)
text=(s/'first-ocr-document-draft.md').read_text(encoding='utf-8-sig')
text=text.replace('新构建实际结果将在验收后追加。','新构建回验结果如下。')
text+='\n## 修复后两档实际验收\n\n'
text+=f"冻结 Release SHA-256 `{build['sha256']}`，{build['frozenInputsUnchanged']} 项输入与 {build['resourcesUnchanged']} 份资源前后保持，九个旧 PDF/OCR EXE 保留。100/5000 对象各三次完整原生行程均通过，六次仅扫描一次、默认 small 档，完整三行结果通过两帧和视口命中探针。\n\n"
text+='设备：Intel Core i7-9700，8 逻辑核心、系统物理内存约 15.79GiB；Windows 11 Enterprise LTSC 10.0.26100 x64。rustc 1.96.0，驱动 Node v24.16.0。以下为各 n=3 的中位 / P95，单位 ms，P95 为该组三次最大值。\n\n| 指标 | 100 对象 | 5000 对象 |\n| --- | ---: | ---: |\n'
for i,x in enumerate(summaries['100']):
 y=summaries['5000'][i];assert x['name']==y['name'];text+=f"| `{x['name']}` | {x['medianMs']:.2f} / {x['p95Ms']:.2f} | {y['medianMs']:.2f} / {y['p95Ms']:.2f} |\n"
count=sum(p['verifiedIdentities'] for p in post.values());links=sum(p['unlinkedEntries'] for p in post.values())
text+=f"\n96 项原生回归、严格 Clippy、格式检查通过；Node 204 passed / 0 failed / 1 既有 symlink 权限 skip，未将跳过算通过。GUI 默认前端无改动，不将旧 F/WEB 结果冒充本次新运行。RF-1094 的 446 项 core 检查已有独立记录。fresh CIM 核验最终两组共 {count} 条记录身份退出，清理 48 个精确缓存路径、解除 {links} 个已核验链接；清理前后完整 Vault 清单、24 份附件密文、公开源 171 文件和公开输入保持，日志独立保留，没有终止额外进程。\n\n"
text+='[结构化验收](rf312-windows-first-ocr-2026-10-05.json)和[逐字节原件索引](rf312-windows-first-ocr-2026-10-05/index.json)保存失败/成功、源码、冻结、检查和清理。通用 OCR 精度、OCR PDF、引擎阶段耗时、原首页偶发超时、睡眠及多端仍未验收。下一步做登录/首页完成状态与阶段耗时归因，再补 Windows RF-121 完整窗口材质；RF-312 保持待验证，RF-112/121 和 RF-122～127 前置不解除。独立本地提交，不推送。\n'
p=r/'docs/performance/RF-312-native-first-ocr.md';assert not p.exists();p.write_text(text,encoding='utf-8',newline='\n')
p=r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';oldtext=p.read_text(encoding='utf-8-sig');newtext=oldtext
header='> 最后更新：2026-10-05（RF-1094通用OCR字符修复；RF-312待新构建回验首次识别）'
assert newtext.count(header)==1;newtext=newtext.replace(header,'> 最后更新：2026-10-05（RF-312两档首次OCR原生回验完成；继续首页超时和性能归因）')
oldline=next(l for l in newtext.splitlines() if l.startswith('- 当前处理：'))
newtext=newtext.replace(oldline,'- 当前处理：**RF-312：100/5000对象各三次首次OCR原生回验通过，失败历史保留；下一步登录/首页完成状态和阶段耗时归因，再补Windows RF-121完整窗口材质**。')
row=next(l for l in newtext.splitlines() if l.startswith('|') and '[RF-312](#rf-312)' in l and l.count('|')==7)
parts=row.split('|');parts[-2]=' [!] Windows两档首次OCR已验；待性能归因/多端 ';newtext=newtext.replace(row,'|'.join(parts))
newtext+='\n\n### RF-312 Windows 首次 OCR 原生回验（2026-10-05）\n\n'
newtext+=f"- RF-1094已独立提交`6baee574`；本阶段只扩展非默认Windows native-perf和Node驱动，不改默认前端/登录/依赖。固定公开6274字节PNG经owned原生选择器进入实际通用OCR，默认small、每进程一次扫描，完整三行结果通过两帧和视口命中；不是截图像素或任意图片准确率验收。\n- 96项原生回归、严格Clippy/格式/diff通过；Node204 passed/0 failed/1既有权限skip。冻结459输入、94资源，Release exit0、SHA`{build['sha256']}`；九个旧EXE与171公开源保持。100/5000对象各3/3完整实际行程通过，四项时间按原生Instant边界独立复算；n=3的P95为最大观测值，含加载/推理/渲染/SDK观测开销，不能作为纯引擎耗时。\n- 旧100对象三次因结果探针超时的原组/源码/EXE/证明均保留，四项整组统计保持null；不选择成功子集。原始故障由RF-1094真实图片和确定性CTC红/绿复现，修复后新构建整组回验，未追加扫描或放宽文字判定。\n- 最终fresh CIM核验{count}条记录身份退出，精确清理48缓存及{links}链接；24附件密文、清理前后完整Vault清单、公开输入/源、资源和旧构建保持，日志副本保留，没有终止其他进程。旧失败组另外核验27身份、24缓存和三份日志，83份RF-1094原件仍逐字节一致。\n- [口径与复跑](performance/RF-312-native-first-ocr.md)、[结构化验收](performance/rf312-windows-first-ocr-2026-10-05.json)和[原件索引](performance/rf312-windows-first-ocr-2026-10-05/index.json)同步归档。按RF-312独立本地提交、不推送；275/284、3待验证、6待执行不变，RF-312仍[!]。下一本地项首页偶发超时/阶段耗时归因，再补Windows RF-121完整合成；RF-112/121和RF-122～127前置不解除，goal保持active。\n"
p.write_text(newtext,encoding='utf-8',newline='\n')
write(s/'documentation-scope-review.json',{'at':now(),'originalReportSha256':hashlib.sha256(oldtext.encode('utf-8')).hexdigest(),'updatedReportSha256':sha(p),'priorLines':len(oldtext.splitlines()),'newLines':len(newtext.splitlines()),'changedExistingReportLines':3,'rawArchiveCount':len(entries),'sourceInputsUnchanged':True,'closed':275,'total':284,'rf312Complete':False})
print(json.dumps({'rawArchiveCount':len(entries),'buildSha':build['sha256'],'sourceUnchanged':True,'metricSummary':summaries},ensure_ascii=False))
