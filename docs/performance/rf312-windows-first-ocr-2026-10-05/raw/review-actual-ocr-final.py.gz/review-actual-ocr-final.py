import pathlib,json,hashlib,datetime,sys
sys.stdout.reconfigure(encoding='utf-8')
assert len(sys.argv)==2 and sys.argv[1] in ['100','5000']
group='samples'+sys.argv[1]+'-final'
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-ocr-20261005')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda n:json.loads((s/n).read_text(encoding='utf-8-sig'))
report=load(group+'/native-perf-sdk-journey-results.json');build=load('build-checkpoint-final.json')
assert report['success'] and report['sourceUnchanged'] and len(report['samples'])==3 and report['scope']=='windows-native-sdk-public-first-ocr-performance'
assert len(report['summary'])==4 and all(x['successfulSamples']==3 and x['medianMs'] is not None for x in report['summary'])
identities={};cleanup_pids=set();attachments=[];samples=[]
for x in report['samples']:
 assert x['success'] and x['cleanupIntegrity']['complete'],x['index']
 root=pathlib.Path(x['root']);assert root==s/group/('sample-%03d'%x['index'])
 for name in ['beforeSnapshot','afterSnapshot']:
  for p in (x.get(name) or {}).get('processes',[]):
   key=(p['pid'],p['creationMs']);assert p['creationMs']>0
   value={k:p[k] for k in ['pid','creationMs','executableName']}
   assert key not in identities or identities[key]==value;identities[key]=value
 for p in x['cleanup']['cleanup']:cleanup_pids.add(p['pid'])
 owned=json.loads((root/'native-perf-owned.json').read_text(encoding='utf-8-sig'))
 proof=json.loads((root/'native-perf-sdk-journey.json').read_text(encoding='utf-8-sig'))
 assert proof==x['nativeProof'] and proof['success'] and proof['scope']=='windows-native-sdk-first-ocr'
 assert [p['name'] for p in proof['phases']]==['startup','password-unlock','workspace','ocr-page','first-ocr']
 d=proof['ocr'];assert d['firstPerProcess'] and d['closedPickerVerified'] and d['resource']['tier']=='small' and d['resource']['preferencesAbsent']
 actual=d['result']['text'];assert actual.isascii() and ''.join(c.lower() for c in actual if c.isalnum())=='helloppocrv6solosoulocr1234567890'
 assert d['result']==proof['lastProbe']['ocr']==proof['phases'][-1]['ocrEndState'] and d['result']['paintedFrames']==2 and d['result']['visible']
 assert proof['ipcAll']['commands']['ocr_scan_image']==1 and sum(1 for e in proof['lastProbe']['observer']['commands'] if e['command']=='ocr_scan_image')==1
 p=d['picker'];assert p['pid']==proof['pid'] and p['directOwnerVerified'] and p['foregroundVerified'] and p['closedVerified']
 assert p['inputPathVerified'] and p['inputMethod']=='WM_SETTEXT+readback+BM_CLICK'
 expected={'pickerOpenedObservedMs':p['openedObservedAtMs']-p['actionStartedAtMs'],'pickerSelectionClosedMs':p['closedObservedAtMs']-p['openedObservedAtMs'],'firstOcrResultObservedMs':d['resultObservedAtMs']-p['selectionSubmittedAtMs'],'totalOcrObservedMs':d['resultObservedAtMs']-p['actionStartedAtMs']}
 assert all(v>=0 and abs(d['performanceMetrics'][k]-v)<1e-6 for k,v in expected.items())
 input=root/'native-perf-ocr-input.png';assert input.is_file() and input.stat().st_size==6274 and sha(input)=='56a9d54d9b70a3ee1b22e0b08b755b6cfc15ee125df4b11d52f8523583dcacaa'
 assert x['ocrInputBefore']==x['ocrInputAfter'] and x['ocrInputBefore']['sha256']==sha(input)
 ciphertexts=[f for f in owned['fixture']['files'] if f['relativePath'].startswith('attachments/')];assert len(ciphertexts)==4
 for f in ciphertexts:
  path=root/'vault'/f['relativePath'];assert path.resolve().is_relative_to((root/'vault').resolve()) and sha(path)==f['sha256']
 attachments.append({'index':x['index'],'ciphertextsUnchanged':ciphertexts})
 assert not (root/'native-perf-ready.json').exists()
 samples.append({'index':x['index'],'inputSha256':sha(input),'result':d['result'],'ocrMetrics':d['performanceMetrics'],'controls':len(p['controls']),'sdkCalls':len(proof['calls'])})
public=load('public-source-freeze-final.json')['files'];assert all(sha(pathlib.Path(p))==h for p,h in public.items())
freeze=load('source-freeze-final.json')['files'];assert all(sha(r/p)==h for p,h in freeze.items())
resources=load('resource-freeze-final.json')['records'];assert all(sha(pathlib.Path(v['source']))==v['sha256']==sha(pathlib.Path(v['copy'])) for v in resources)
assert sha(pathlib.Path(build['exe']))==build['sha256']
base=load('baseline-after-rf1094.json');assert all(sha(pathlib.Path(p))==h for p,h in base['oldPdfBuilds'].items())
assert sha(pathlib.Path(base['priorOcrBuild']['exe']))==base['priorOcrBuild']['sha256']
write=lambda n,v:(s/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
write(group+'-identity-scope.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exe':build['exe'],'identities':list(identities.values()),'additionalCleanupPids':sorted(cleanup_pids-set(p for p,c in identities))})
vault_inventory=[]
for x in report['samples']:
 root=pathlib.Path(x['root']);vault=root/'vault'
 rows=[]
 for p in sorted(vault.rglob('*')):
  assert not p.is_symlink(), 'Unexpected vault link'
  if p.is_file():
   assert p.resolve().is_relative_to(vault.resolve())
   rows.append({'relativePath':str(p.relative_to(vault)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)})
 vault_inventory.append({'root':str(root),'files':rows})
write(group+'-pre-cache-vault-freeze.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'roots':vault_inventory})
write(group+'-actual-ocr-review.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'publicFilesUnchanged':len(public),'frozenInputsUnchanged':len(freeze),'resourcesUnchanged':len(resources),'previousBuildsPreserved':len(base['oldPdfBuilds'])+1,'ownedAttachmentCiphertextsUnchanged':attachments,'scope':'fixed public PNG/default small/first per process','summary':report['summary'],'samples':samples})
print(json.dumps({'reportSuccess':True,'identities':len(identities),'extraCleanupPids':len(cleanup_pids-set(p for p,c in identities)),'publicFiles':len(public),'inputs':len(freeze)}),flush=True)
