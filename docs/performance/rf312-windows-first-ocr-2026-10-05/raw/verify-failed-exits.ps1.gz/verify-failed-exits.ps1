$ErrorActionPreference='Stop'
$taskStage='C:\Users\40299571\AppData\Local\Temp\ss-rf312-ocr-20261005'
$scope=Get-Content -LiteralPath (Join-Path $taskStage 'samples100-identity-scope.json') -Raw -Encoding utf8 | ConvertFrom-Json
$verified=@()
$ids=@($scope.identities);$pids=@($ids|ForEach-Object{[uint32]$_.pid}|Sort-Object -Unique)
for($offset=0;$offset -lt $pids.Count;$offset+=32){
 $last=[Math]::Min($offset+31,$pids.Count-1);$batch=@($pids[$offset..$last]);$filter=($batch|ForEach-Object{'ProcessId='+$_}) -join ' OR '
 $rows=@(Get-CimInstance Win32_Process -Filter $filter -Property ProcessId,CreationDate,Name)
 foreach($id in @($ids|Where-Object{$batch -contains [uint32]$_.pid})){
  $current=@($rows|Where-Object{$_.ProcessId -eq $id.pid});if($current.Count -gt 1){throw 'Ambiguous process metadata'};$state='absent'
  if($current.Count -eq 1){
   if($null -eq $current[0].CreationDate -or [string]::IsNullOrEmpty($current[0].Name)){throw 'Incomplete process identity'}
   $birth=([DateTimeOffset]$current[0].CreationDate.ToUniversalTime()).ToUnixTimeMilliseconds()
   if($birth -eq [long]$id.creationMs){throw 'Recorded OCR test process still live'};$state='pid-reused-with-different-creation'
  }
  $verified+=[ordered]@{pid=$id.pid;creationMs=$id.creationMs;executableName=$id.executableName;status=$state}
 }
}
foreach($extraPid in @($scope.additionalCleanupPids)){
 if(@(Get-CimInstance Win32_Process -Filter ('ProcessId='+[uint32]$extraPid)).Count -ne 0){throw 'Additional cleanup PID requires identification'}
}
$exeRows=@(Get-CimInstance Win32_Process -Filter "Name='solo_soul.exe'" -Property ProcessId,ExecutablePath)
if(@($exeRows|Where-Object{[string]::IsNullOrEmpty($_.ExecutablePath) -or [string]::Equals($_.ExecutablePath,$scope.exe,[StringComparison]::OrdinalIgnoreCase)}).Count -ne 0){throw 'Owned or ambiguous EXE remains alive'}
$receipt=[ordered]@{at=[DateTime]::UtcNow.ToString('o');scope='RF-312 initial OCR failed group';identities=$verified;complete=$true;processesTerminated=0;cacheRemovalPerformed=$false}
[IO.File]::WriteAllText((Join-Path $taskStage 'samples100-fresh-exit-verification.json'),($receipt|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
Write-Output ('Fresh exited identities verified: '+$verified.Count)
