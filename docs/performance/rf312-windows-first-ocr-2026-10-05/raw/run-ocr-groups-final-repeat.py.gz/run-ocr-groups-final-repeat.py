import pathlib,json,hashlib,subprocess,time,datetime,sys
sys.stdout.reconfigure(encoding='utf-8')
assert len(sys.argv)==2 and sys.argv[1] in ['100','5000']
size=sys.argv[1]
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-ocr-20261005')
source=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-media-20261005\vault'+size)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((s/'release-build-final.receipt.json').read_text(encoding='utf-8-sig'))['exitCode']==0
build=json.loads((s/'build-checkpoint-final.json').read_text(encoding='utf-8-sig'));assert sha(pathlib.Path(build['exe']))==build['sha256']
freeze=json.loads((s/'source-freeze-final.json').read_text(encoding='utf-8-sig'));assert all(sha(r/p)==h for p,h in freeze['files'].items())
output=s/('samples'+size+'-final-repeat');assert not output.exists()
args=['node','scripts/native-perf-ocr.mjs','--exe',build['exe'],'--fixture',str(source),'--output',str(output),'--samples','3'];started=time.time()
with (s/('ocr'+size+'-final-repeat.stdout.log')).open('xb') as out,(s/('ocr'+size+'-final-repeat.stderr.log')).open('xb') as err:
 c=subprocess.Popen(args,cwd=r/'tauri',stdout=out,stderr=err)
 (s/('ocr'+size+'-final-repeat.live.json')).write_text(json.dumps({'command':args,'pid':c.pid,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}),encoding='utf-8')
 print('Started real owned first OCR PID '+str(c.pid),flush=True);rc=c.wait()
receipt={'command':args,'pid':c.pid,'exitCode':rc,'elapsedSeconds':time.time()-started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(s/('ocr'+size+'-final-repeat.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt),flush=True)
report=json.loads((output/'native-perf-sdk-journey-results.json').read_text(encoding='utf-8-sig'))
print(json.dumps({'success':report['success'],'sourceUnchanged':report['sourceUnchanged'],'diagnosticOnly':report.get('diagnosticOnly'),'performanceMetrics':report.get('performanceMetrics'),'summary':report['summary'],'samples':[{'index':x['index'],'success':x['success'],'reason':(x.get('nativeProof') or {}).get('reason'),'failedStep':(x.get('nativeProof') or {}).get('failedStep'),'sdkCalls':len((x.get('nativeProof') or {}).get('calls',[])), 'ocrMetrics':((x.get('nativeProof') or {}).get('ocr') or {}).get('performanceMetrics'),'cleanup':x.get('cleanupIntegrity')} for x in report['samples']]},ensure_ascii=False),flush=True)
raise SystemExit(rc)
