import pathlib,json,hashlib,subprocess,time,datetime,shutil,sys,os
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-ocr-20261005');old=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-pixels-20261005')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
write=lambda n,v:(s/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['ocr-final-native-tests','ocr-final-native-clippy','ocr-final-fmt-check','ocr-first-node-tests','ocr-first-js-format-check','ocr-first-diff-check']:
 assert json.loads((s/(name+'.receipt.json')).read_text(encoding='utf-8-sig'))['exitCode']==0,name
base=json.loads((s/'baseline.json').read_text(encoding='utf-8-sig'))
allowed=set(['tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs','tauri/src-tauri/src/native_perf/sdk_cdp.rs','tauri/src-tauri/src/native_perf/sdk_journey.rs','tauri/src-tauri/src/native_perf/sdk_journey.js','tauri/src-tauri/src/native_perf/startup.rs','tauri/scripts/native-perf-sdk-journey.mjs','tauri/scripts/run-node-tests.mjs'])
files={p:sha(r/p) for p in base['sourceBefore']}
changed=[p for p,h in base['sourceBefore'].items() if files[p]!=h]
assert set(changed)<=allowed,changed
for p in ['tauri/src-tauri/src/native_perf/sdk_ocr.rs','tauri/src-tauri/src/native_perf/sdk_ocr_picker.rs','tauri/scripts/native-perf-ocr-contract.mjs','tauri/scripts/native-perf-ocr.mjs','tauri/scripts/native-perf-ocr.test.mjs']:files[p]=sha(r/p)
assert files['tauri/crates/solosoul-core/tests/fixtures/ocr_test.png']=='56a9d54d9b70a3ee1b22e0b08b755b6cfc15ee125df4b11d52f8523583dcacaa'
write('source-freeze.json',{'at':now(),'head':base['head'],'files':files,'changedExistingInputs':changed,'unchangedExistingInputs':len(base['sourceBefore'])-len(changed)})
public=json.loads((old/'public-source-freeze-frame.json').read_text(encoding='utf-8-sig'))['files']
assert all(sha(pathlib.Path(p))==h for p,h in public.items())
write('public-source-freeze.json',{'at':now(),'files':public})
bin=s/'bin';bin.mkdir(exist_ok=False);records=[]
resources=json.loads((old/'resource-freeze-frame.json').read_text(encoding='utf-8-sig'))
for v in resources['records']:
 source=pathlib.Path(v['copy']);assert sha(source)==v['sha256'];copy=bin/v['relativePath'];assert copy.resolve().is_relative_to(bin.resolve());copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,copy);assert sha(copy)==v['sha256'];records.append({**v,'source':str(source),'copy':str(copy)})
write('resource-freeze.json',{'at':now(),'records':records,'oldExeSha256':resources['oldExeSha256']})
assert all(sha(pathlib.Path(p))==h for p,h in base['oldPdfBuilds'].items())
print(json.dumps({'inputs':len(files),'resources':len(records),'publicFiles':len(public),'previousBuilds':len(base['oldPdfBuilds'])}),flush=True)
args=['cargo','build','--locked','--release','-p','solo_soul','--features','native-perf','--bin','solo_soul'];started=time.time()
env=os.environ.copy();env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','')
with (s/'release-build.stdout.log').open('xb') as out,(s/'release-build.stderr.log').open('xb') as err:
 c=subprocess.Popen(args,cwd=r/'tauri',env=env,stdout=out,stderr=err);write('release-build.live.json',{'command':args,'pid':c.pid,'startedAt':now()});print('Started Release PID '+str(c.pid),flush=True);rc=c.wait()
write('release-build.receipt.json',{'command':args,'pid':c.pid,'exitCode':rc,'elapsedSeconds':time.time()-started,'finishedAt':now()});print('Release exit '+str(rc),flush=True)
if rc:raise SystemExit(rc)
assert all(sha(r/p)==h for p,h in files.items())
assert all(sha(pathlib.Path(v['source']))==v['sha256']==sha(pathlib.Path(v['copy'])) for v in records)
exe=bin/'solo_soul.exe';assert not exe.exists();shutil.copy2(r/'tauri/target/release/solo_soul.exe',exe)
markers=['--native-perf-media-prepare','windows-native-sdk-media-journey-requested','windows-native-sdk-ocr-journey-requested','windows-native-sdk-startup-requested','windows-native-sdk-pdf-first-page-requested','windows-native-sdk-pdf-cipher-binding-requested','windows-native-sdk-pdf-frame-stability-requested'];data=exe.read_bytes();assert all(x.encode() in data for x in markers)
assert all(sha(pathlib.Path(p))==h for p,h in base['oldPdfBuilds'].items())
assert all(sha(pathlib.Path(p))==h for p,h in public.items())
write('build-checkpoint.json',{'at':now(),'exe':str(exe),'bytes':len(data),'sha256':sha(exe),'frozenInputsUnchanged':len(files),'resourcesUnchanged':len(records),'markers':markers,'previousPdfBuildsPreserved':len(base['oldPdfBuilds']),'publicSourcesUnchanged':len(public)});print('Frozen Release copied and verified',flush=True)
