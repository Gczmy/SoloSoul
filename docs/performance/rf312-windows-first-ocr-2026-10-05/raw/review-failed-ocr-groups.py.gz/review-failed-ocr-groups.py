import pathlib,json,hashlib,datetime,sys
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-ocr-20261005');group=sys.argv[1];assert len(sys.argv)==2 and group in ['samples5000-final','samples5000-final-repeat'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((s/group/'native-perf-sdk-journey-results.json').read_text(encoding='utf-8-sig'))
assert not report['success'] and report['sourceUnchanged'] and len(report['samples'])==3 and [x['success'] for x in report['samples']]==([True,True,False] if group=='samples5000-final' else [False,True,True])
assert len(report['summary'])==4 and all(x['medianMs'] is None and x['p95Ms'] is None for x in report['summary'])
ids={};cleanup=set();samples=[];inventory=[];copied=[]
for x in report['samples']:
 root=pathlib.Path(x['root']);assert root==s/group/('sample-%03d'%x['index']) and x['cleanupIntegrity']['complete']
 for name in ['beforeSnapshot','afterSnapshot']:
  for p in ((x.get(name) or {}).get('processes') or []):
   key=(p['pid'],p['creationMs']);value={k:p[k] for k in ['pid','creationMs','executableName']};assert key not in ids or ids[key]==value;ids[key]=value
 cleanup.update(p['pid'] for p in x['cleanup']['cleanup'])
 proof=json.loads((root/'native-perf-sdk-journey.json').read_text(encoding='utf-8-sig'))
 if x['success']:
  assert proof==x['nativeProof'] and proof['success'] and proof['ocr']['result']['normalizedText']=='helloppocrv6solosoulocr1234567890' and proof['ipcAll']['commands']['ocr_scan_image']==1
 else:
  assert x['error']=='No exact verified owned browser directory; process diagnostics refused' and (x['beforeSnapshot']['reason'] or '').startswith('PowerShell sample timed out after 15000ms;')
  assert not proof['success'] and proof['reason']==('input-authorization-timeout' if group=='samples5000-final' else 'document-invalidated') and proof['ipcAll']['commands'].get('ocr_scan_image',0)==0
 image=root/'native-perf-ocr-input.png'
 if not image.exists():
  source=root/'profile/Documents/ocr_test.png';assert source.stat().st_size==6274 and sha(source)=='56a9d54d9b70a3ee1b22e0b08b755b6cfc15ee125df4b11d52f8523583dcacaa'
  data=source.read_bytes()
  with image.open('xb') as out:out.write(data)
  copied.append({'source':str(source),'copy':str(image),'sha256':sha(image)})
 assert sha(image)=='56a9d54d9b70a3ee1b22e0b08b755b6cfc15ee125df4b11d52f8523583dcacaa'
 owned=json.loads((root/'native-perf-owned.json').read_text(encoding='utf-8-sig'));attachments=[f for f in owned['fixture']['files'] if f['relativePath'].startswith('attachments/')];assert len(attachments)==4
 for f in attachments:assert sha(root/'vault'/f['relativePath'])==f['sha256']
 rows=[]
 for p in sorted((root/'vault').rglob('*')):
  assert not p.is_symlink()
  if p.is_file():rows.append({'relativePath':str(p.relative_to(root/'vault')).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)})
 inventory.append({'root':str(root),'files':rows});samples.append({'index':x['index'],'nativeSuccess':proof['success'],'rawReason':proof.get('reason'),'scanAttempts':proof['ipcAll']['commands'].get('ocr_scan_image',0),'driverError':x.get('error'),'processSnapshotReason':(x.get('beforeSnapshot') or {}).get('reason'),'inputSha256':sha(image)})
write=lambda n,v:(s/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
write(group+'-identity-scope.json',{'exe':json.loads((s/'build-checkpoint-final.json').read_text(encoding='utf-8-sig'))['exe'],'identities':list(ids.values()),'additionalCleanupPids':sorted(cleanup-set(p for p,c in ids))})
write(group+'-pre-cache-vault-freeze.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'roots':inventory})
write(group+'-failure-review.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'requested':3,'acceptedPerformanceMetrics':None,'summary':report['summary'],'sourceUnchanged':True,'samples':samples,'publicInputCopies':copied,'rootCauseResolved':False})
print(json.dumps({'identities':len(ids),'extraCleanupPids':len(cleanup-set(p for p,c in ids)),'samples':samples},ensure_ascii=False))
