from pathlib import Path
import json,hashlib,subprocess,time,datetime,sys,os
sys.stdout.reconfigure(encoding='utf-8')
r=Path(r'C:\Users\40299571\SoloSoul');s=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-ocr-after-rf1095-20261005')
baseline=json.loads((s/'baseline.json').read_text(encoding='utf-8-sig'));freeze=json.loads((s/'source-freeze.json').read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(r/p)==h for p,h in freeze['files'].items());assert sha(baseline['exe']['exe'])==baseline['exe']['sha256']
source=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-media-20261005\vault5000');output=s/'samples5000';assert not output.exists()
cmd=['node','scripts/native-perf-ocr.mjs','--exe',baseline['exe']['exe'],'--fixture',str(source),'--output',str(output),'--samples','3'];t=time.time()
with (s/'ocr5000.stdout.log').open('xb') as out,(s/'ocr5000.stderr.log').open('xb') as err:
 proc=subprocess.Popen(cmd,cwd=r/'tauri',stdout=out,stderr=err);(s/'ocr5000.live.json').write_text(json.dumps({'command':cmd,'pid':proc.pid,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n',encoding='utf-8');print('Started 5000 whole OCR group PID',proc.pid,flush=True);code=proc.wait()
receipt={'command':cmd,'pid':proc.pid,'exitCode':code,'elapsedSeconds':time.time()-t,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};(s/'ocr5000.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt),flush=True)
report=json.loads((output/'native-perf-sdk-journey-results.json').read_text(encoding='utf-8-sig'));print(json.dumps({'success':report['success'],'sourceUnchanged':report['sourceUnchanged'],'summary':report['summary'],'samples':[{'index':x['index'],'success':x['success'],'error':x.get('error'),'beforeSnapshotReason':(x.get('beforeSnapshot') or {}).get('reason'),'failedStep':(x.get('nativeProof') or {}).get('failedStep'),'nativeReason':(x.get('nativeProof') or {}).get('reason'),'sdkCalls':len((x.get('nativeProof') or {}).get('calls',[])),'cleanup':x.get('cleanupIntegrity')} for x in report['samples']]},ensure_ascii=False),flush=True);sys.exit(code)
