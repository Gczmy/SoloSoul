from pathlib import Path
import hashlib,io,json,statistics,tarfile
R=Path('D:/SoloSoul');S=R/'build/rf312-current-startup-20261012'
N='rf312-current-windows-paired-startup-2026-10-12';O=R/'docs/performance'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
proof=load(S/'input-proof.json');validation=load(S/'independent-validation.json');cleanup=load(S/'cache-cleanup.json')
assert validation['accepted'] and validation['pairs']==10 and validation['nativeLaunches']==20
assert validation['memorySnapshotsValid']==39 and len(validation['memorySnapshots'])==40
assert cleanup['matchingOwnedIdentitiesLive']==0 and cleanup['identitiesChecked']==180
assert len(cleanup['removedCachePaths'])==80 and len(cleanup['linksUnlinked'])==10 and cleanup['preservedBytesVerified']
assert all(sha(Path(x['path']))==x['sha256'] for x in cleanup['preservedVaultAndRootFiles'])
assert all(not Path(x).exists() for x in cleanup['removedCachePaths'])
assert all(sha(R/n)==h for n,h in proof['currentValidationSources'].items())
summary=[]
for group in validation['groups']:
    rows=[x for x in validation['results'] if x['dataset']==group['label']]
    assert len(rows)==5
    metrics={}
    for column,key in [('freshMs','freshProfile'),('reusedMs','reusedProfile')]:
        values=[x[column] for x in rows];metric={'medianMs':statistics.median(values),'p95Ms':sorted(values)[-1],'successfulSamples':5,'requestedSamples':5}
        original=group['summary']['metrics'][key]
        assert all(metric[n]==original[n] for n in metric)
        metrics[key]=metric
    summary.append({'dataset':group['label'],'metrics':metrics})
outcomes={'sourceHead':'d05636dcc','nativeDatasetDriverExitCodes':[0,0],'independentVerifierExitCodes':[1,1,1,0],
          'firstVerifierError':'profileAfterPrime field missing; corrected to original profileAfterFirst',
          'secondVerifierError':'original live checkTicket correctly rejected archived ticket older than 300000ms',
          'historicalClockValidation':'original gate replayed at recorded warm.beforeSnapshot.observedAt; no live authority or budget change',
          'thirdVerifierError':'extra requirement for all memory snapshots rejected one original null memory reading',
          'memoryScope':'startup contract unchanged; one missing memory snapshot retained, complete memory baseline not accepted',
          'nativeTestReruns':0,'oldFailuresModified':False,'cleanupObservedExitCode':0}
put(S/'observed-tool-outcomes.json',outcomes)
assert not O.exists();O.mkdir();members={}
for p in S.rglob('*'):
 if p.is_file() and p.suffix in ['.json','.log','.py','.ps1','.mjs']:
  assert not(p.stat().st_file_attributes&0x400);members['validation/'+p.relative_to(S).as_posix()]=p
for fixture in proof['fixtures']:
    P=R/'build'/('ss-rf312-current-startup-'+fixture['label']+'-20261012')
    # Only JSON proof/report files; preserve synthetic Vault bytes on D without publishing them.
    for p in P.glob('*.json'):members['native/'+fixture['label']+'/'+p.name]=p
    for sample in sorted(P.glob('sample-*')):
        if not sample.is_dir():continue
        for p in sample.glob('*.json'):members['native/'+fixture['label']+'/'+sample.name+'/'+p.name]=p
        for generation in ['startup-01','startup-02']:
            for p in (sample/generation).rglob('*'):
                if p.is_file() and p.suffix in ['.json','.log']:
                    assert not(p.stat().st_file_attributes&0x400)
                    members['native/'+fixture['label']+'/'+sample.name+'/'+generation+'/'+p.relative_to(sample/generation).as_posix()]=p
for name in ['prepare-rf312-current-startup-20261012.py','run-rf312-current-startup-20261012.py','verify-rf312-current-startup-20261012.mjs','prepare-rf312-current-startup-cleanup-20261012.py','archive-rf312-current-startup-20261012.py']:
    members['tools/'+name]=R/'build'/name
for name in ['native-perf-startup.mjs','native-perf-startup.test.mjs']:
    members['sources/'+name]=R/'tauri/scripts'/name
rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as a:
    for name,p in sorted(members.items()):
        b=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;a.addfile(info,io.BytesIO(b))
        rows.append({'member':name,'source':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(O/'raw.tar.gz') as a:
    assert len(a.getmembers())==len(rows)
    for row in rows:
        b=a.extractfile(row['member']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
put(O/'index.json',{'task':'RF-312','members':rows,'allMembersReadbackVerified':True,'privateVaultsAndProfilesAndExecutableResourcesExcluded':True})
(O/'.gitattributes').write_text('raw.tar.gz -text\n*.json text eol=lf\n',encoding='utf-8',newline='\n')
result={'task':'RF-312','sourceHead':'d05636dcc','acceptedScope':'current frozen Windows Release paired read-only startup only',
        'accepted':True,'fullRF312Accepted':False,'fullRF121Accepted':False,'releaseSha256':proof['releasePackage']['sha256'],
        'releaseBuildNotRerun':True,'sourcesValidated':1839,'releaseBuildSourcesDifferAt':list(proof['sourceDifferences']),
        'startupEngineAndProductionSourcesUnchanged':True,'pairs':10,'nativeLaunches':20,'samplesPerDataset':5,'datasets':summary,
        'memorySnapshotsCollected':40,'memorySnapshotsValid':39,'memorySnapshotsMissing':1,
        'originalNullMemoryReadingRetained':True,'completeMemoryBaselineAccepted':False,'inputEventsSent':0,'pixelsCaptured':0,
        'definitions':'Native runtime configuration to visible usable password form/two frames/SDK binding; excludes OS spawn and prepare, includes SDK overhead; fresh private profile then same profile after owned exit; no OS cache eviction.',
        'unmeasured':['password-unlock','workspace','search-needle','application-lock','password-reunlock','OCR','attachment-preview','system-sleep','other-platforms'],
        'toolOutcomes':outcomes,'cleanup':{'identitiesChecked':180,'recordedIdentitiesLive':0,'exactCachePathsRemoved':80,'linksUnlinked':10,'vaultAndProofFilesPreserved':260,'processesTerminatedByCleanupTool':0},
        'archive':{'path':N+'/raw.tar.gz','members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha(O/'raw.tar.gz'),'allMembersReadbackVerified':True}}
put(R/'docs/performance'/(N+'.json'),result)
print(json.dumps({'acceptedScope':'paired startup only','pairs':10,'launches':20,'members':len(rows),'datasets':summary}))
