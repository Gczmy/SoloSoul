from pathlib import Path
R=Path('D:/SoloSoul');S=R/'build/rf312-current-startup-20261012'
p=R/'build/rf121-theme-binding-20261010/rf1129-cleanup-owned.ps1'
s=p.read_text(encoding='utf-8')
changes=[
("$stageRoot = 'D:\\SoloSoul\\build\\rf121-theme-binding-20261010'","$stageRoot = 'D:\\SoloSoul\\build\\rf312-current-startup-20261012'"),
('rf1129-native-cache-cleanup-plan.json','cache-cleanup-plan.json'),('rf1129-native-cache-cleanup.json','cache-cleanup.json'),('rf1129-native-cache-cleanup-preflight.json','cache-cleanup-preflight.json'),
('groups.Count -ne 1','groups.Count -ne 2'),('One terminal owned group required; failed matrix remains rejected','Two complete terminal startup groups required'),
('samples.Count -ne 3','samples.Count -ne 5'),
("PlainAncestors $group.captureRoot; RequireBelow $group.captureRoot $stageRoot","PlainAncestors $group.captureRoot; if ((NormalPath $group.captureRoot) -notin @('D:\\SoloSoul\\build\\ss-rf312-current-startup-vault100-20261012','D:\\SoloSoul\\build\\ss-rf312-current-startup-vault5000-20261012')) { throw 'Unexpected startup output' }"),
("Join-Path (Join-Path $group.captureRoot 'actual100')","Join-Path $group.captureRoot"),
('RequireBelow $sampleRoot $stageRoot','RequireBelow $sampleRoot $group.captureRoot'),
('application-logs-rf1129-diagnostic','application-logs'),
('Count -ne 24','Count -ne 80'),('Exact 24 owned cache paths required','Exact 80 owned cache paths required'),
("task='RF-1127'","task='RF-312'"),
]
for before,after in changes:
 assert before in s,before;s=s.replace(before,after)
start=s.index('$taskHelperExecutables =')
end=s.index('$packageBase =',start)
s=s[:start]+s[end:]
# Preserve both startup generations in addition to the existing Vault/root proof list.
old="foreach ($file in @(RegularTreeFiles (Join-Path $sampleRoot 'vault')) + @(Get-ChildItem -LiteralPath $sampleRoot -File -Force)) {"
new="foreach ($file in @(RegularTreeFiles (Join-Path $sampleRoot 'vault')) + @(RegularTreeFiles (Join-Path $sampleRoot 'startup-01')) + @(RegularTreeFiles (Join-Path $sampleRoot 'startup-02')) + @(Get-ChildItem -LiteralPath $sampleRoot -File -Force)) {"
assert old in s;s=s.replace(old,new)
(S/'cleanup-owned.ps1').write_text(s,encoding='utf-8',newline='\n')
print('Exact80 startup cache paths prepared; current identity/path/reparse/preservation guards retained')
