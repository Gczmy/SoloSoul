import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {checkStartup,checkPair,checkTicket,checkStartupPreferences,summarizePairs,inventory} from '../tauri/scripts/native-perf-startup.mjs';
const R='D:/SoloSoul', S=path.join(R,'build/rf312-current-startup-20261012');
const load=async p=>JSON.parse((await fs.readFile(p,'utf8')).replace(/^\uFEFF/,''));
const sha=async p=>crypto.createHash('sha256').update(await fs.readFile(p)).digest('hex');
const put=async (n,o)=>fs.writeFile(path.join(S,n),JSON.stringify(o,null,2)+'\n',{encoding:'utf8',flag:'wx'});
const proof=await load(path.join(S,'input-proof.json'));
const verification=await load(path.join(S,'verification.json'));assert(verification.accepted);
const groups=[], results=[];
for(const fixture of proof.fixtures){
 const receipt=await load(path.join(S,fixture.label+'.receipt.json'));assert.equal(receipt.exitCode,0);
 const report=await load(path.join(receipt.output,'report.json'));assert.equal(report.samples.length,5);
 assert(report.sourceUnchanged&&!report.interrupted);assert.equal(report.exeSha256,proof.releasePackage.sha256);
 assert.deepEqual(await inventory(fixture.path),report.sourceBefore);assert.deepEqual(report.sourceBefore,report.sourceAfter);
 const cleanupSamples=[];
 for(const sample of report.samples){
  assert(sample.success&&!sample.cleanupIncomplete&&sample.originalEvidenceUnchanged);
  assert.deepEqual(sample.profileBefore,sample.profileAfterFirst);assert.deepEqual(sample.profileBefore,sample.profileAfterWarm);
  const root=path.join(receipt.output,'sample-'+String(sample.index).padStart(3,'0'));
  assert.deepEqual(await load(path.join(receipt.output,'sample-'+String(sample.index).padStart(3,'0')+'.json')),sample);
  const owned=await load(path.join(root,'native-perf-owned.json'));assert.deepEqual(owned,sample.owned);
  const consumed=await load(path.join(root,'native-perf-consumed.json'));
  assert.equal(consumed.runId,owned.runId);assert.equal(consumed.pid,sample.first.pid);
  const ticket=await load(path.join(root,'native-perf-startup-restart-ticket.json'));
  assert.deepEqual(ticket,sample.ticket);
  const stopped=await load(path.join(root,'native-perf-startup-stopped.json'));
  const hashes={ownedSha256:await sha(path.join(root,'native-perf-owned.json')),
   consumedSha256:await sha(path.join(root,'native-perf-consumed.json')),
   proofSha256:await sha(path.join(root,'startup-01/native-perf-sdk-journey.json')),
   stoppedSha256:await sha(path.join(root,'native-perf-startup-stopped.json')),
   exeSha256:await sha(proof.releasePackage.exe),uiPreferencesSha256:sample.firstUiPreferencesSha256};
  const historicalWallTime=Date.parse(sample.warm.beforeSnapshot.observedAt);
  assert(Number.isSafeInteger(historicalWallTime)&&historicalWallTime>=ticket.exitCheck.checkedAtUnixMs);
  assert(historicalWallTime<=Date.parse(sample.finishedAt));
  // Archive validation replays the original unchanged five-minute live gate at
  // a recorded driver wall-clock observation; it grants no live ticket authority.
  const liveClock=Date.now;
  try{Date.now=()=>historicalWallTime;checkTicket(ticket,owned,sample.first.nativeProof,hashes,stopped.identities.length);}
  finally{Date.now=liveClock;}
  const identities=[];
  for(const [name,generation] of [['first',1],['warm',2]]){
   const phase=sample[name], evidence=path.join(root,'startup-0'+generation);
   const bound=await load(path.join(evidence,'native-perf-sdk-journey-bound.json'));
   const native=await load(path.join(evidence,'native-perf-sdk-journey.json'));
   assert.deepEqual(bound,phase.bound);assert.deepEqual(native,phase.nativeProof);
   checkStartup(native,owned,bound,generation,phase.launchId);
   assert(phase.success&&phase.cleanupIntegrity.complete);
   assert(native.calls.every(x=>!x.startsWith('Input.')));
   assert(phase.beforeSnapshot.reason===null&&phase.afterSnapshot.reason===null);
   assert(phase.beforeSnapshot.userDataDirectoryMatches&&phase.afterSnapshot.userDataDirectoryMatches);
   for(const id of phase.identities){assert(Number.isSafeInteger(id.pid)&&id.pid>0&&Number.isFinite(id.creationMs));identities.push(id);}
  }
  checkPair(sample.first.nativeProof,sample.warm.nativeProof);
  const restartConsumed=await load(path.join(root,'native-perf-startup-restart-consumed.json'));
  assert.equal(restartConsumed.runId,ticket.runId);assert.equal(restartConsumed.ownerRunId,owned.runId);
  const preferences=await load(path.join(owned.vault,'ui_preferences.json'));
  checkStartupPreferences(preferences,ticket.updateSourceCandidates);
  assert(sample.fixtureAfterWarm.immutableFilesUnchanged);
  for(const entry of sample.fixtureAfterWarm.files)assert.equal(await sha(path.join(owned.vault,entry.path)),entry.sha256);
  cleanupSamples.push({index:sample.index,runId:owned.runId,recordedIdentities:identities});
  results.push({dataset:fixture.label,index:sample.index,freshMs:sample.first.nativeProof.phases[0].durationMs,
   reusedMs:sample.warm.nativeProof.phases[0].durationMs,firstPid:sample.first.pid,warmPid:sample.warm.pid,
   runIdsDistinct:true,frameLoaderClockDistinct:true,exactProfileReused:true,immutableFixtureVerified:true,
   allInputsReadOnly:true,bothLaunchesCleanupComplete:true,recordedIdentityCount:identities.length});
 }
 assert.deepEqual(summarizePairs(report.samples,5,true),report.summary);
 groups.push({label:fixture.label,captureRoot:receipt.output,terminal:true,samples:cleanupSamples,summary:report.summary});
}
assert.equal(results.length,10);
for(const [n,h] of Object.entries(proof.currentValidationSources))assert.equal(await sha(path.join(R,n)),h);
for(const resource of proof.releasePackage.resources){assert.equal(await sha(resource.copy),resource.sha256);assert.equal(await sha(resource.source),resource.sha256);}
await put('independent-validation.json',{accepted:true,pairs:10,nativeLaunches:20,results,groups:groups.map(g=>({label:g.label,summary:g.summary})),
 sourceFiles:1839,releaseAndStartupEngineStable:true,fullRF312Accepted:false,inputEventsSent:0,pixelsCaptured:0,
 ticketClockMode:'archived recorded warm.beforeSnapshot.observedAt; original 300000ms gate unchanged; no live ticket invocation',
 liveHistoricalTicketAgeRejectionPreserved:true});
await put('cache-cleanup-plan.json',{cacheCleanupEligible:true,failedSamplesAccepted:false,groups,plannedExactCacheTargets:80,freshCimRequired:true});
console.log('Independent startup validation passed: 10 pairs/20 read-only launches, unchanged identities/profiles/fixtures and exact summaries');
