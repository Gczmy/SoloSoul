from pathlib import Path
import json,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-early-observer-implementation-20261012'
J=R/'tauri/src-tauri/src/android_native_perf/observer.js'
T=R/'tauri/src-tauri/src/android_native_perf/observer.node.test.mjs'
text=J.read_text(encoding='utf-8')
assert text.count('const originalInvoke = window.__TAURI_INTERNALS__?.invoke;')==1
text=text.replace('const originalInvoke = window.__TAURI_INTERNALS__?.invoke;',
    'const originalInternals = window.__TAURI_INTERNALS__;')
old="if (window.__TAURI_INTERNALS__?.invoke !== originalInvoke) invalidate('internal-invoke-changed');"
assert text.count(old)==1
new="""const invokeDescriptor = originalInternals && Object.getOwnPropertyDescriptor(originalInternals, 'invoke');
    if (window.__TAURI_INTERNALS__ !== originalInternals || typeof invokeDescriptor?.value !== 'function'
        || invokeDescriptor.writable !== false || invokeDescriptor.configurable !== false) {
      invalidate('internal-invoke-unprotected');
    }"""
text=text.replace(old,new)
(S/'observer-order-corrected-proposed.js').write_text(text,encoding='utf-8',newline='\n')
test=T.read_text(encoding='utf-8')
test=test.replace("./observer.js","./observer-order-corrected-proposed.js")
assert test.count('readonlyBridge = false,')==1
test=test.replace('readonlyBridge = false,','readonlyBridge = false, lateInvoke = false,')
old="Object.defineProperty(internals, 'invoke', { value: invoke });"
assert test.count(old)==1;test=test.replace(old,"if (!lateInvoke) "+old)
test+="""
test('accepts actual Tauri order: observer precedes the readonly core invoke definition', () => {
  const s=setup({lateInvoke:true});
  Object.defineProperty(s.window.__TAURI_INTERNALS__,'invoke',{value:s.invoke});
  s.window.ipc.postMessage('{"cmd":"get_ui_preferences","payload":{}}');
  const proof=json(s.observer.bind(id));assert.equal(proof.valid,true);
  assert.equal(proof.observedCount,1);assert.equal(s.window.__TAURI_INTERNALS__.invoke,s.invoke);
  assert.equal(Object.getOwnPropertyDescriptor(s.window.__TAURI_INTERNALS__,'invoke').configurable,false);
});
"""
(S/'observer-order-corrected-proposed.node.test.mjs').write_text(test,encoding='utf-8',newline='\n')
start=time.monotonic()
with (S/'order-correction-proposed-tests.stdout.log').open('xb') as out,(S/'order-correction-proposed-tests.stderr.log').open('xb') as err:
    p=subprocess.run(['node','--test',str(S/'observer-order-corrected-proposed.node.test.mjs')],stdout=out,stderr=err,
        creationflags=subprocess.CREATE_NO_WINDOW,timeout=60)
(S/'order-correction-proposed-tests.receipt.json').write_text(json.dumps({'exitCode':p.returncode,
    'elapsedSeconds':time.monotonic()-start,'scope':'proposed correction only; frozen production source not modified',
    'nativeNewObserverAccepted':False},indent=2)+'\n',encoding='utf-8')
assert p.returncode==0
print('Proposed actual-order correction passes 8 meaningful Node gates; frozen source unchanged while Windows queue completes',flush=True)
