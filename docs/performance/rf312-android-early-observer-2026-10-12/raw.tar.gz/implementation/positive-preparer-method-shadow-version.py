from pathlib import Path
import hashlib,json,shutil
R=Path('D:/SoloSoul');B=Path(__file__).parent;I=B/'rf312-early-observer-implementation-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
package=load(I/'android-release-package/package-verification.json')
assert package['acceptedPackagePreparation'] and package['observerMarkersPresent']
assert load(I/'negative-control/verification.json')['acceptedAbsenceControl']
S=I/'positive-native';S.mkdir(exist_ok=False)
inputs=load(I/'negative-control/inputs.json')
inputs['runtimeSourceFiles']=load(I/'sources.json')
inputs['release']=package
inputs['scope']='actual optional Android early transport observer Release: complete production-home supported/fallback gates'
assert sha(Path(inputs['release']['apk']['path']))==inputs['release']['apk']['sha256']
assert inputs['release']['apk']['sha256']!=load(I/'negative-control/inputs.json')['release']['apk']['sha256']
for name in ['early-observer-native-driver.py','original-driver.py']:
    shutil.copyfile(I/'native-driver-preparation'/name,S/name)
(S/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
(S/'preparation.json').write_text(json.dumps({'derivedDriverSha256':sha(S/'early-observer-native-driver.py'),
    'scope':inputs['scope'],'originalHomeUnchanged':True},indent=2)+'\n',encoding='utf-8')
shutil.copyfile(I/'negative-control/original-system.json',S/'original-system.json')
template=(B/'run-rf312-release-home-20261012.py').read_text(encoding='utf-8')
replacements={"S=B/'rf312-android-release-native-20261012'":"S=B/'rf312-early-observer-implementation-20261012/positive-native'",
    "H=B/'api31-host-rf312-release-20261012'":"H=B/'api31-host-rf312-observer-20261012'",
    "assert len(inputs['runtimeSourceFiles'])==1839":"assert len(inputs['runtimeSourceFiles'])==1843",
    "S/'release-home-native-driver.py'":"S/'early-observer-native-driver.py'",
    "label='baseline-'+mode+'-probe-aligned-round4'":"label='observer-'+mode",
    'actual non-debuggable optimized x86_64 Release baseline production home in API31 AVD':
        'actual non-default non-debuggable optimized x86_64 Release early IPC transport observer plus whole production home in API31 AVD'}
for old,new in replacements.items():
    expected=2 if old=="S/'release-home-native-driver.py'" else 1
    assert template.count(old)==expected,(old,template.count(old));template=template.replace(old,new)
target=B/'run-rf312-positive-observer-native-20261012.py';assert not target.exists()
compile(template,str(target),'exec');target.write_text(template,encoding='utf-8',newline='\n')
print('Prepared exact new observer Release/native source bindings and two complete home gates; no runtime pass claimed',flush=True)
