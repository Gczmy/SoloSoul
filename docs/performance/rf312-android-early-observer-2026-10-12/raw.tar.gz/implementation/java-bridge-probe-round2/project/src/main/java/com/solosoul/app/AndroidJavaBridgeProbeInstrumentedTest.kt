package com.solosoul.app

import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

@RunWith(AndroidJUnit4::class)
class AndroidJavaBridgeProbeInstrumentedTest {
    private fun webView(view: View): WebView? {
        if (view is WebView) return view
        if (view is ViewGroup) for (i in 0 until view.childCount) webView(view.getChildAt(i))?.let { return it }
        return null
    }
    @Test fun productionHomeWithLateJavaBridgeProbe() {
        val instrumentation=InstrumentationRegistry.getInstrumentation()
        val args=InstrumentationRegistry.getArguments()
        assertEquals("true",args.getString("privateDataBackedUp"))
        val tag=requireNotNull(args.getString("evidenceTag"));require(Regex("fe2-home-[a-f0-9]{32}").matches(tag))
        val monitor=instrumentation.addMonitor(MainActivity::class.java.name,null,false)
        val proof=JSONObject().put("acceptedLateBridgeDiagnostic",false)
            .put("scope","late Java bridge mutability/forwarding only; not early or complete IPC measurement")
            .put("processId",android.os.Process.myPid()).put("uid",android.os.Process.myUid())
        fun js(activity: MainActivity, expression: String): JSONObject {
            val done=CountDownLatch(1);var raw:String?=null
            instrumentation.runOnMainSync {
                requireNotNull(webView(activity.window.decorView)).evaluateJavascript(expression) { value -> raw=value;done.countDown() }
            }
            assertTrue(done.await(3,TimeUnit.SECONDS))
            val parsed=JSONArray("[${raw?:"null"}]").opt(0)
            return if(parsed is String && parsed.startsWith("{")) JSONObject(parsed) else JSONObject()
        }
        try {
            AndroidHomeInstrumentedTest().realHomePreservesGlassAndCopyAcrossLockUnlock()
            val activity=requireNotNull(monitor.lastActivity) as MainActivity
            js(activity,"""(() => {
              const key='__RF312_LATE_BRIDGE_DIAGNOSTIC__';
              if(window[key]) throw new Error('Owned diagnostic already exists');
              const result={pending:true};window[key]=result;
              (async()=>{
                const bridge=window.ipc,post=bridge.postMessage,invoke=window.__TAURI_INTERNALS__.invoke;
                const globalDescriptor=Object.getOwnPropertyDescriptor(window,'ipc');
                const descriptor=Object.getOwnPropertyDescriptor(bridge,'postMessage');
                const flags=d=>d?{writable:d.writable===true,configurable:d.configurable===true,
                  hasGetter:typeof d.get==='function',valueType:typeof d.value}:null;
                result.global=flags(globalDescriptor);result.method=flags(descriptor);
                result.methodIdentityStable=bridge.postMessage===bridge.postMessage;
                let directCalls=0,facadeCalls=0;
                const direct=function(...args){directCalls++;return Reflect.apply(post,this,args);};
                try {
                  if(descriptor && 'value' in descriptor) {
                    Object.defineProperty(bridge,'postMessage',{...descriptor,value:direct});
                    result.directIdentityInstalled=bridge.postMessage===direct;
                    await invoke('ui_get_preferences');result.directResolved=true;
                  }
                } catch {result.directError=true;}
                finally {if(descriptor)Object.defineProperty(bridge,'postMessage',descriptor);}
                result.directCalls=directCalls;
                const facade=Object.create(bridge);
                Object.defineProperty(facade,'postMessage',{value:function(...args){
                  facadeCalls++;return Reflect.apply(post,this===facade?bridge:this,args);
                }});
                try {
                  Object.defineProperty(window,'ipc',{...globalDescriptor,value:facade});
                  result.facadeIdentityInstalled=window.ipc===facade;
                  await invoke('ui_get_preferences');result.facadeResolved=true;
                } catch {result.facadeError=true;}
                finally {Object.defineProperty(window,'ipc',globalDescriptor);}
                result.facadeCalls=facadeCalls;result.globalRestored=window.ipc===bridge;
                const protectedInvoke=Object.getOwnPropertyDescriptor(window.__TAURI_INTERNALS__,'invoke');
                result.invokeIdentityUnchanged=window.__TAURI_INTERNALS__.invoke===invoke;
                result.invokeReadonly=protectedInvoke.writable===false&&protectedInvoke.configurable===false;
                result.pending=false;result.done=true;
              })().catch(()=>{result.error=true;result.pending=false;});
              return JSON.stringify({started:true});})()""")
            val deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(10)
            var state=JSONObject()
            do {
                state=js(activity,"JSON.stringify(window.__RF312_LATE_BRIDGE_DIAGNOSTIC__||{})")
                if(state.optBoolean("done")||state.optBoolean("error"))break
                Thread.sleep(100)
            } while(System.nanoTime()<deadline)
            proof.put("diagnostic",state)
            assertTrue(state.toString(),state.optBoolean("done"));assertFalse(state.optBoolean("error"))
            assertTrue(state.getBoolean("globalRestored"));assertTrue(state.getBoolean("invokeIdentityUnchanged"))
            assertTrue(state.getBoolean("invokeReadonly"));assertTrue(state.getBoolean("facadeResolved"))
            assertTrue(state.getBoolean("facadeIdentityInstalled"));assertEquals(1,state.getInt("facadeCalls"))
            proof.put("acceptedLateBridgeDiagnostic",true)
        } finally {
            instrumentation.removeMonitor(monitor)
            val out=File(instrumentation.targetContext.getExternalFilesDir(null),tag)
            if(out.isDirectory)File(out,"bridge-diagnostic.json").writeText(proof.toString(2))
        }
    }
}
