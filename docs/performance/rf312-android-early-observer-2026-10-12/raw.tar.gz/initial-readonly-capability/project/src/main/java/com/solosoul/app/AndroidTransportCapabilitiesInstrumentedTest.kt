package com.solosoul.app

import android.webkit.WebView
import android.view.View
import android.view.ViewGroup
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Read-only transport metadata in the actual unchanged production document.
 * No invoke, bridge call, property mutation, function source or payload read.
 */
@RunWith(AndroidJUnit4::class)
class AndroidTransportCapabilitiesInstrumentedTest {
    private fun webView(view: View): WebView? {
        if (view is WebView) return view
        if (view is ViewGroup) for (i in 0 until view.childCount) webView(view.getChildAt(i))?.let { return it }
        return null
    }
    @Test fun actualProductionAndroidIpcBridgeCapabilities() {
        val instrumentation=InstrumentationRegistry.getInstrumentation()
        val args=InstrumentationRegistry.getArguments()
        assertEquals("true",args.getString("privateDataBackedUp"))
        val tag=requireNotNull(args.getString("evidenceTag"))
        require(Regex("rf312-bridge-[a-f0-9]{32}").matches(tag))
        val context=instrumentation.targetContext
        val data=File(context.applicationInfo.dataDir)
        data.walkTopDown().forEach {
            check(!it.name.startsWith("acc_"))
            if(it.name=="accounts.json") check(JSONArray(it.readText()).length()==0)
        }
        val out=File(context.getExternalFilesDir(null),tag).also { check(it.mkdir()) }
        val report=JSONObject().put("acceptedCapabilityObservation",false)
            .put("processId",android.os.Process.myPid()).put("uid",android.os.Process.myUid())
            .put("targetPackage",context.packageName)
            .put("scope","readonly actual production WebView IPC property descriptors; not performance")
        try {
            File(data,"ui_preferences.json").writeText(JSONObject().put("theme","light")
                .put("accentColor","ocean").put("language","en-US").put("androidGlass","local")
                .put("hasSeenOnboarding",false).put("notificationPermissionRequested",true).toString())
            val scenario=ActivityScenario.launch(MainActivity::class.java)
            val deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(45)
            var state=JSONObject()
            do {
                val done=CountDownLatch(1)
                var raw:String?=null
                scenario.onActivity { activity ->
                    val view=webView(activity.window.decorView)
                    report.put("documentStartScriptSupported",androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.DOCUMENT_START_SCRIPT))
                    if(view==null) done.countDown() else view.evaluateJavascript("""(() => {
                        const flags=(owner,name)=>{const d=owner&&Object.getOwnPropertyDescriptor(owner,name);
                          return d?{writable:d.writable===true,configurable:d.configurable===true,
                            hasGetter:typeof d.get==='function',hasSetter:typeof d.set==='function'}:null;};
                        return JSON.stringify({platform:document.documentElement.dataset.platform,
                          mounted:!!document.querySelector('#root>*'),startupGone:!document.querySelector('#startup-screen'),
                          timeOriginMs:performance.timeOrigin,atMs:performance.now(),mainFrame:window.top===window,
                          frames:document.querySelectorAll('iframe,frame').length,protocol:location.protocol,hostname:location.hostname,
                          internalInvokeType:typeof window.__TAURI_INTERNALS__?.invoke,
                          internalInvoke:flags(window.__TAURI_INTERNALS__,'invoke'),
                          internalPostMessage:flags(window.__TAURI_INTERNALS__,'postMessage'),
                          bridgeType:typeof window.ipc,bridge:flags(window,'ipc'),
                          bridgePostMessageType:typeof window.ipc?.postMessage,
                          bridgePostMessage:flags(window.ipc,'postMessage'),fetch:flags(window,'fetch')});
                      })()""") { value -> raw=value;done.countDown() }
                }
                assertTrue(done.await(3,TimeUnit.SECONDS))
                val parsed=JSONArray("[${raw?:"null"}]").opt(0)
                state=if(parsed is String&&parsed.startsWith("{")) JSONObject(parsed) else JSONObject()
                if(state.optBoolean("mounted")&&state.optBoolean("startupGone")&&state.optString("platform")=="android") break
                Thread.sleep(100)
            } while(System.nanoTime()<deadline)
            report.put("document",state)
            assertTrue(state.toString(),state.optBoolean("mounted")&&state.optBoolean("startupGone"))
            assertEquals("android",state.getString("platform"))
            assertTrue(state.getBoolean("mainFrame"));assertEquals(0,state.getInt("frames"))
            assertEquals("function",state.getString("bridgePostMessageType"))
            assertEquals("function",state.getString("internalInvokeType"))
            report.put("acceptedCapabilityObservation",true)
        } catch(error:Throwable) {
            report.put("error",error.javaClass.name+": "+error.message)
            throw error
        } finally {
            File(out,"bridge.json").writeText(report.toString(2))
        }
    }
}
