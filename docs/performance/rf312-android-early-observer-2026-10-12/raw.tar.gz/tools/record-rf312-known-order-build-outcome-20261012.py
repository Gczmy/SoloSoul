from pathlib import Path
import json,subprocess,time
B=Path(__file__).parent;S=B/'rf312-early-observer-implementation-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
plan=load(S/'known-order-build-stop-plan.json');receipt=load(S/'android-release-build-round2/receipt.json')
assert receipt['exitCode']==4294967295 and receipt['sourceUnchanged'] and receipt['generatedDebugJniUnchanged']
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
for row in plan:
    command=f"Get-CimInstance Win32_Process -Filter 'ProcessId = {row['ProcessId']}' | Select-Object ProcessId,CreationDate,ExecutablePath | ConvertTo-Json -Depth 3"
    p=subprocess.run([pwsh,'-NoProfile','-Command',command],check=True,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    assert not p.stdout.strip(),row['ProcessId']
(S/'known-order-build-stop-outcome.json').write_text(json.dumps({'cancelledForVerifiedSourceOrderBug':True,
    'observedStopScriptExitCode':1,'observedRootCargoExitCode':4294967295,'observedOuterBuilderExitCode':1,
    'stopScriptRace':'root Cargo stopped; the already-verified child exited between CIM query and Stop-Process, which reported process not found',
    'allPlannedCargoAndCompilerPidsConfirmedAbsent':True,'plan':plan,
    'noRestartDueToObservationTimeout':True,'generatedDebugJniUnchanged':True,'originalSourceUnchangedDuringCancelledBuild':True,
    'windowsQueueNotStopped':True,'newObserverNativeAccepted':False},indent=2)+'\n',encoding='utf-8')
began=time.monotonic()
cmd=['node',str(B/'reproduce-rf312-early-invoke-order-20261012.mjs')]
with (S/'source-order-regression-red.stdout.log').open('xb') as out,(S/'source-order-regression-red.stderr.log').open('xb') as err:
    p=subprocess.run(cmd,stdout=out,stderr=err,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
assert p.returncode==1
(S/'source-order-regression-red.receipt.json').write_text(json.dumps({'command':cmd,'exitCode':p.returncode,
    'elapsedSeconds':time.monotonic()-began,'source':'actual local Tauri2.11.2 manager sequence; internals then invoke script then core.js',
    'observedFailure':'valid false/internal-invoke-changed when legitimate later readonly invoke is defined'},indent=2)+'\n',encoding='utf-8')
print('Exact build cancellation and exited-child race recorded; source-order red regression preserved, no native success inferred',flush=True)
