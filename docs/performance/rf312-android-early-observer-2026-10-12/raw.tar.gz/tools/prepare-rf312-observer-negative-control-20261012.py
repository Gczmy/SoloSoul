from pathlib import Path
import hashlib,json,shutil
R=Path('D:/SoloSoul');B=Path(__file__).parent;I=B/'rf312-early-observer-implementation-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
S=I/'negative-control';S.mkdir(exist_ok=False)
original=load(B/'rf312-android-release-native-20261012/inputs.json')
sources=load(I/'sources.json');assert all(sha(R/n)==h for n,h in sources.items())
probe=load(I/'early-observer-test-apk/current-test-apk.json')
assert load(I/'early-observer-test-apk/complete.json')['testClassCompiled']
for name in ['early-observer-native-driver.py','original-driver.py']:
    shutil.copyfile(I/'native-driver-preparation'/name,S/name)
original.update(runtimeSourceFiles=sources,runtimeTest=probe,
    scope='expected failing absence control: unchanged default Release APK must not expose optional early observer')
(S/'inputs.json').write_text(json.dumps(original,indent=2)+'\n',encoding='utf-8')
source=B/'boot-rf312-bridge-api31-20261012.py';target=B/'boot-rf312-observer-api31-20261012.py'
assert not target.exists();text=source.read_text(encoding='utf-8')
assert text.count("'api31-host-rf312-bridge-20261012'")==1
text=text.replace("'api31-host-rf312-bridge-20261012'","'api31-host-rf312-observer-20261012'")
compile(text,str(target),'exec');target.write_text(text,encoding='utf-8',newline='\n')
(S/'preparation.json').write_text(json.dumps({'expectedNativeFailure':'Early observer requires its non-default Android build',
    'defaultReleaseSha256':original['release']['apk']['sha256'],'probeSha256':probe['sha256'],
    'driverSha256':sha(S/'early-observer-native-driver.py'),'newSources':sources,
    'fullPrivateAndOriginalPackageRestoreRequired':True,'negativeControlExecuted':False},indent=2)+'\n',encoding='utf-8')
print('Prepared default-Release negative control and guarded dedicated AVD boot; no native test run yet',flush=True)
