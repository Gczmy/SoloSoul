from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-early-observer-implementation-20261012'
D=R/'build/rf312-maintenance-20261009';W=S/'windows-checks-round2';W.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sources=load(S/'sources.json');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy();env.update(CARGO_HOME=str(D/'cargo-home'),CARGO_TARGET_DIR=str(D/'cargo-target'),
    CARGO_BUILD_JOBS='1',TEMP=str(D/'tmp'),TMP=str(D/'tmp'),ORT_CACHE_DIR=str(D/'ort-cache'),
    PDFIUM_LIBRARY_PATH=str(R/'tauri/src-tauri/resources/pdfium/pdfium.dll'))
env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','')
for key in ['TAURI_CONFIG','TAURI_ANDROID_PROJECT_PATH','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS','SOLOSOUL_REGISTRY_PUBKEY']:
    env.pop(key,None)
def save(p,value):p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(label,command):
    assert all(sha(R/n)==h for n,h in sources.items())
    began=time.monotonic()
    with (W/(label+'.stdout.log')).open('xb') as out,(W/(label+'.stderr.log')).open('xb') as err:
        proc=subprocess.Popen(command,cwd=R/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,
            creationflags=subprocess.CREATE_NO_WINDOW)
        save(W/(label+'.live.json'),{'pid':proc.pid,'command':command,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
        print(label,'live PID',proc.pid,flush=True);code=proc.wait()
    changed=[n for n,h in sources.items() if sha(R/n)!=h]
    save(W/(label+'.receipt.json'),{'exitCode':code,'command':command,'elapsedSeconds':time.monotonic()-began,
        'sourceUnchanged':not changed,'changedSources':changed})
    print(label,'exit',code,flush=True);assert not changed and code==0,label
run('observer-node',['node','--test','src-tauri/src/android_native_perf/observer.node.test.mjs'])
run('workspace-fmt',['cargo','fmt','--all','--','--check'])
run('workspace-clippy',['cargo','clippy','--locked','--offline','--','-D','warnings'])
run('workspace-tests',['cargo','test','--locked','--offline','--verbose'])
save(W/'complete.json',{'acceptedDefaultWindowsChecks':True,'androidNewObserverNativeAccepted':False})
print('Windows public check queue complete; new Android native scope still unaccepted',flush=True)
