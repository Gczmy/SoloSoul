from pathlib import Path
import hashlib,json
B=Path(__file__).parent;I=B/'rf312-early-observer-implementation-20261012'
S=I/'native-driver-preparation';S.mkdir(exist_ok=False)
source=B/'rf312-android-release-native-20261012/release-home-native-driver.py'
original=source.read_bytes();(S/'original-release-driver.py').write_bytes(original)
text=original.decode('utf-8')
def replace(a,b):
    global text
    assert text.count(a)==1,(a,text.count(a));text=text.replace(a,b)
replace('METHOD = "realHomePreservesGlassAndCopyAcrossLockUnlock"',
        'METHOD = "productionHomeWithEarlyIpcTransportObserver"')
replace('"-e", "privateDataBackedUp", "true", "-e", "evidenceTag", tag,',
        '"-e", "privateDataBackedUp", "true", "-e", "evidenceTag", tag,\n                     "-e", "observerRunId", tag.removeprefix("fe2-home-"),')
replace('f"com.solosoul.app.AndroidHomeInstrumentedTest#{METHOD}"',
        'f"com.solosoul.app.AndroidEarlyIpcObserverInstrumentedTest#{METHOD}"')
validation='''        report["stages"] = stages
        transport = json.loads((output / 'device-files/observer.json').read_text(encoding='utf-8'))
        document = transport.get('document', {})
        observer = document.get('observer', {})
        if (transport.get('acceptedEarlyTransportObservation') is not True
                or transport.get('targetPackage') != APP
                or transport.get('uid') != original_packages['main']['uid']
                or transport.get('processId') != evidence.get('processId')
                or transport.get('targetDebuggable') is not False
                or document.get('platform') != 'android' or document.get('mainFrame') is not True
                or document.get('frames') != 0 or document.get('invokeReadonly') is not True
                or observer.get('scope') != 'android-native-ipc-transport-observer'
                or observer.get('runId') != tag.removeprefix('fe2-home-')
                or observer.get('valid') is not True or observer.get('invalidReasons') != []):
            raise RuntimeError('Missing exact early IPC observer/native process/document identity')
        events=observer.get('commands', [])
        times=[observer.get('installedAtMs'),observer.get('timeOriginMs'),observer.get('atMs')]
        if (not events or observer.get('observedCount') != len(events)
                or len(events)>observer.get('maxEvents',0)
                or any(isinstance(t,bool) or not isinstance(t,(int,float)) or not math.isfinite(t) for t in times)):
            raise RuntimeError('Missing complete finite transport-send observation')
        previous=observer['installedAtMs']
        for event in events:
            at=event.get('atMs')
            if (set(event) != {'command','transport','atMs'}
                    or not isinstance(event.get('command'),str)
                    or not re.fullmatch(r'[A-Za-z0-9_.:|/-]{1,128}',event['command'])
                    or event.get('transport') not in ['android-java-bridge','android-channel-fetch']
                    or isinstance(at,bool) or not isinstance(at,(int,float)) or not math.isfinite(at)
                    or not previous<=at<=observer['atMs']):
                raise RuntimeError('Invalid transport-send metadata/order/privacy contract')
            previous=at
        if not any(e['command']=='login' for e in events):
            raise RuntimeError('Actual production password unlock was not observed')
        report['earlyTransportObservation']=transport'''
replace('        report["stages"] = stages',validation)
text=text.replace('classname="AndroidHomeInstrumentedTest"','classname="AndroidEarlyIpcObserverInstrumentedTest"')
driver=S/'early-observer-native-driver.py';compile(text,str(driver),'exec')
driver.write_text(text,encoding='utf-8',newline='\n')
(S/'original-driver.py').write_bytes((Path('D:/SoloSoul')/'tauri/scripts/android-home-native-regression.py').read_bytes())
(S/'preparation.json').write_text(json.dumps({'derivedDriverSha256':hashlib.sha256(driver.read_bytes()).hexdigest(),
    'scope':'complete production-home baseline plus early IPC transport sends; fixed-Vault performance unaccepted',
    'allOriginalPackagePrivateBackupRestorationAndSystemGuardsPreserved':True,
    'nativeMethodExactSuccessRequired':True,'homeEvidenceValidationUnchanged':True,
    'boundNonceAndSameNativeProcessAndReadonlyInvokeRequired':True},indent=2)+'\n',encoding='utf-8')
print('Prepared whole-home early observer driver with unchanged APK/private/system restoration guards',flush=True)
