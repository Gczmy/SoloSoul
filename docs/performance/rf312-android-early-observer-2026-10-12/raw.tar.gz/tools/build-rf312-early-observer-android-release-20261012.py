from pathlib import Path
import datetime,hashlib,json,os,shutil,struct,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-early-observer-implementation-20261012'
A=S/'android-release-build-round2';A.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sources=load(S/'sources.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tool=B/'rustup/toolchains/1.96.0-x86_64-pc-windows-msvc/bin'
ndk=B/'sdk/ndk/27.0.12077973/toolchains/llvm/prebuilt/windows-x86_64/bin'
env=os.environ.copy();env.update(TEMP=str(B/'tmp'),TMP=str(B/'tmp'),CARGO_HOME=str(B/'cargo-home'),
    CARGO_TARGET_DIR=str(B/'cargo-target'),CARGO_BUILD_JOBS='1',RUSTUP_HOME=str(B/'rustup'),RUSTUP_TOOLCHAIN='1.96.0',
    RUSTC=str(tool/'rustc.exe'),CARGO_TARGET_X86_64_LINUX_ANDROID_LINKER=str(ndk/'x86_64-linux-android28-clang.cmd'),
    CC_x86_64_linux_android=str(ndk/'x86_64-linux-android28-clang.cmd'),AR_x86_64_linux_android=str(ndk/'llvm-ar.exe'),
    ANDROID_HOME=str(B/'sdk'),ANDROID_SDK_ROOT=str(B/'sdk'),NDK_HOME=str(B/'sdk/ndk/27.0.12077973'),
    ANDROID_NDK_HOME=str(B/'sdk/ndk/27.0.12077973'),ORT_CACHE_DIR=str(B/'ort-cache'),
    RUSTFLAGS='-Clink-arg=-landroid -Clink-arg=-llog -Clink-arg=-lOpenSLES')
env['PATH']=str(tool)+';'+env.get('PATH','')
for key in ['PDFIUM_LIBRARY_PATH','TAURI_ANDROID_PROJECT_PATH','TAURI_CONFIG','CARGO_ENCODED_RUSTFLAGS','SOLOSOUL_REGISTRY_PUBKEY']:
    env.pop(key,None)
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
assert all(sha(R/n)==h for n,h in sources.items())
jni=R/'tauri/src-tauri/gen/android/app/src/main/jniLibs/x86_64/libsolo_soul.so'
originalJni=sha(jni)
command=[str(tool/'cargo.exe'),'build','--locked','--offline','-p','solo_soul','--lib',
    '--release','--target','x86_64-linux-android','--features','android-native-perf']
save(A/'input-proof.json',{'sources':sources,'command':command,'rustcSha256':sha(tool/'rustc.exe'),
    'cargoSha256':sha(tool/'cargo.exe'),'linkerSha256':sha(ndk/'x86_64-linux-android28-clang.cmd'),
    'rustflags':env['RUSTFLAGS'],'defaultFeatures':['custom-protocol'],'extraFeature':['android-native-perf'],
    'generatedDebugJniBeforeSha256':originalJni,'tauriCliAndSymlinkCopyNotInvoked':True,
    'productionSigningInherited':False,'nativeRuntimeAccepted':False})
began=time.monotonic()
with (A/'stdout.log').open('xb') as out,(A/'stderr.log').open('xb') as err:
    proc=subprocess.Popen(command,cwd=R/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,
        creationflags=subprocess.CREATE_NO_WINDOW)
    save(A/'live.json',{'pid':proc.pid,'command':command,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    print('Android non-default Release library build live PID',proc.pid,flush=True);code=proc.wait()
changed=[n for n,h in sources.items() if sha(R/n)!=h]
save(A/'receipt.json',{'command':command,'exitCode':code,'elapsedSeconds':time.monotonic()-began,
    'sourceUnchanged':not changed,'changedSources':changed,'generatedDebugJniUnchanged':sha(jni)==originalJni})
print('Android non-default Release library build exit',code,flush=True)
assert not changed and sha(jni)==originalJni and code==0
library=B/'cargo-target/x86_64-linux-android/release/libsolo_soul.so'
data=library.read_bytes();assert data[:6]==b'\x7fELF\x02\x01'
assert struct.unpack_from('<H',data,16)[0]==3 and struct.unpack_from('<H',data,18)[0]==62
assert b'android-native-ipc-transport-observer' in data and b'__SOLOSOUL_ANDROID_NATIVE_PERF__' in data
copy=A/'release-libsolo_soul.so';shutil.copyfile(library,copy)
save(A/'library.json',{'source':str(library),'copy':str(copy),'sha256':sha(copy),'bytes':copy.stat().st_size,
    'elfBits':64,'machine':62,'type':'ET_DYN','earlyObserverMarkersPresent':True,
    'generatedDebugJniUnchanged':True,'actualCargoReleaseBuilt':True,'nativeRuntimeAccepted':False})
print('New optional Android Release library built and ELF/observer markers verified; package/native tests still required',flush=True)
