from pathlib import Path
import hashlib,json,shutil
B=Path(__file__).parent;I=B/'rf312-early-observer-implementation-20261012';S=I/'java-bridge-probe-round2'
original=(B/'rf312-android-release-native-20261012/release-home-native-driver.py').read_bytes()
(S/'original-release-driver.py').write_bytes(original)
text=original.decode('utf-8')
def replace(old,new):
    global text
    assert text.count(old)==1,(old,text.count(old));text=text.replace(old,new)
replace('METHOD = "realHomePreservesGlassAndCopyAcrossLockUnlock"','METHOD = "productionHomeWithLateJavaBridgeProbe"')
replace('f"com.solosoul.app.AndroidHomeInstrumentedTest#{METHOD}"',
        'f"com.solosoul.app.AndroidJavaBridgeProbeInstrumentedTest#{METHOD}"')
replace('        report["stages"] = stages','''        report["stages"] = stages
        diagnostic=json.loads((output/'device-files/bridge-diagnostic.json').read_text(encoding='utf-8'))
        state=diagnostic.get('diagnostic',{})
        if (diagnostic.get('acceptedLateBridgeDiagnostic') is not True
                or diagnostic.get('processId')!=evidence.get('processId')
                or diagnostic.get('uid')!=original_packages['main']['uid']
                or state.get('globalRestored') is not True or state.get('invokeIdentityUnchanged') is not True
                or state.get('invokeReadonly') is not True or state.get('facadeResolved') is not True
                or state.get('facadeCalls')!=1):
            raise RuntimeError('Missing exact late Java bridge/real invoke/restored descriptor diagnostic')
        report['lateBridgeDiagnostic']=diagnostic''')
text=text.replace('classname="AndroidHomeInstrumentedTest"','classname="AndroidJavaBridgeProbeInstrumentedTest"')
target=S/'java-bridge-native-driver.py';compile(text,str(target),'exec');target.write_text(text,encoding='utf-8',newline='\n')
shutil.copyfile(B/'rf312-android-release-native-20261012/original-driver.py',S/'original-driver.py')
(S/'preparation.json').write_text(json.dumps({'derivedDriverSha256':hashlib.sha256(target.read_bytes()).hexdigest(),
    'wholeHomeAndAllPackagePrivateSystemGuardsPreserved':True,'lateOnlyNoCompleteEarlyCountingAccepted':True},indent=2)+'\n',encoding='utf-8')
print('Prepared whole-home late diagnostic driver; package/source bindings and actual native run remain gated on completed probe build',flush=True)
