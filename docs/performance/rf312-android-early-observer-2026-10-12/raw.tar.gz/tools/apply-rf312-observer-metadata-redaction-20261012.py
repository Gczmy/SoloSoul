from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
R=Path('D:/SoloSoul');B=Path(__file__).parent;I=B/'rf312-early-observer-implementation-20261012'
P=I/'metadata-redaction-proposal/forwarding-recheck'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
assert load(I/'android-release-build-round3/receipt.json')['exitCode']==0
assert load(I/'android-release-build-round3/library.json')['actualCargoReleaseBuilt']
assert load(P/'red.receipt.json')['exitCode']==1 and load(P/'corrected.receipt.json')['exitCode']==0
old=load(I/'sources.json');assert all(sha(R/n)==h for n,h in old.items())
backup=I/'before-metadata-redaction';backup.mkdir(exist_ok=False)
for name in ['sources.json','source-proof.json']:shutil.copyfile(I/name,backup/name)
names=['tauri/src-tauri/src/android_native_perf/observer.js','tauri/src-tauri/src/android_native_perf/observer.node.test.mjs']
for name in names:
    out=backup/name;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/name,out)
(R/names[0]).write_bytes((P/'corrected.js').read_bytes())
tests=(P/'corrected.node.test.mjs').read_text(encoding='utf-8')
assert tests.count('./corrected.js')==1
(R/names[1]).write_text(tests.replace('./corrected.js','./observer.js'),encoding='utf-8',newline='\n')
for label,command in [
    ('metadata-redacted-prettier',['node',str(R/'tauri/node_modules/prettier/bin/prettier.cjs'),'--write',*[str(R/n) for n in names]]),
    ('metadata-redacted-node',['node','--test',str(R/names[1])]),
    ('metadata-redacted-source-order',['node',str(B/'reproduce-rf312-early-invoke-order-20261012.mjs')])]:
    with (I/(label+'.stdout.log')).open('xb') as out,(I/(label+'.stderr.log')).open('xb') as err:
        p=subprocess.run(command,cwd=R/'tauri',stdout=out,stderr=err,timeout=90,creationflags=subprocess.CREATE_NO_WINDOW)
    save(I/(label+'.receipt.json'),{'exitCode':p.returncode,'command':command})
    assert p.returncode==0,label
new={n:sha(R/n) for n in old}
changed={n:{'beforeSha256':old[n],'afterSha256':new[n]} for n in old if old[n]!=new[n]}
assert set(changed)==set(names)
save(I/'sources.json',new)
proof=load(I/'source-proof.json');proof.update(currentSourceFiles=new,metadataRedactionChanges=changed,
    defaultWindowsRustCargoKotlinInputsUnchanged=True,newObserverNativeAccepted=False)
save(I/'source-proof.json',proof)
for n in names:shutil.copyfile(R/n,I/'executed-sources'/n)
save(I/'metadata-redaction.json',{'applied':True,'nodeTests':11,'failedPrivacyCasesBefore':2,'failedForwardingCasesBefore':1,
    'invalidFetchCommandRedactedToNull':True,'externalInvalidationOnlyFixedDiagnostic':True,
    'originalSourceOrderStillPasses':True,'fetchMethodGetterSemanticsPreserved':True,'compiledDefaultRustInputsUnchanged':True,
    'changes':changed,'newLibraryAndNativeAccepted':False,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
build=(B/'build-rf312-corrected-android-release-20261012.py').read_text(encoding='utf-8')
assert build.count("A=S/'android-release-build-round3'")==1
build=build.replace("A=S/'android-release-build-round3'","A=S/'android-release-build-round4'")
marker="assert load(S/'order-correction.json')['correctedActualTauriInitializationOrder'] is True"
assert build.count(marker)==1
build=build.replace(marker,marker+"\nassert load(S/'metadata-redaction.json')['applied'] is True")
target=B/'build-rf312-redacted-android-release-20261012.py';assert not target.exists()
compile(build,str(target),'exec');target.write_text(build,encoding='utf-8',newline='\n')
package=B/'package-rf312-early-observer-release-20261012.py'
text=package.read_text(encoding='utf-8');assert text.count('android-release-build-round3')==2
text=text.replace('android-release-build-round3','android-release-build-round4')
package.write_text(text,encoding='utf-8',newline='\n')
positive=B/'prepare-rf312-positive-observer-native-20261012.py'
text=positive.read_text(encoding='utf-8');marker="inputs=load(I/'negative-control/inputs.json')"
assert text.count(marker)==1
text=text.replace(marker,marker+"\ninputs['runtimeSourceFiles']=load(I/'sources.json')")
positive.write_text(text,encoding='utf-8',newline='\n')
print('Applied fixed-metadata and forwarding correction; 11 Node gates and actual source order pass. Preserved round3; final library/native gates require round4.',flush=True)
