from pathlib import Path
import json,subprocess
B=Path(__file__).parent;I=B/'rf312-early-observer-implementation-20261012';P=I/'metadata-redaction-proposal'
S=P/'forwarding-recheck';S.mkdir(exist_ok=False)
red=(P/'red.node.test.mjs').read_text(encoding='utf-8')
red=red.replace('./before.js','../before.js')
red=red.replace('readonlyBridge = false,','fetchMethodRead = false, readonlyBridge = false,')
old='fetchCalls.push({ receiver: this, args });'
assert red.count(old)==1
red=red.replace(old,"const observedMethod = fetchMethodRead ? args[1]?.method : undefined;\n      fetchCalls.push({ receiver: this, args, observedMethod });")
red+='''
test('preserves method getter semantics on unrelated fetch and refuses unobservable IPC methods', () => {
  const ordinary=setup({fetchMethodRead:true});let reads=0;
  const options={get method(){reads++;return 'POST';}};
  ordinary.window.fetch('https://public.invalid/resource',options);
  assert.equal(reads,1);assert.equal(ordinary.observer.bind(id).valid,true);
  const ipc=setup({fetchMethodRead:true}),error=new Error('original-fetch-method-failure');let ipcReads=0;
  const ipcOptions={get method(){ipcReads++;throw error;}};
  assert.throws(()=>ipc.window.fetch('http://ipc.localhost/plugin:__TAURI_CHANNEL__|fetch',ipcOptions),e=>e===error);
  assert.equal(ipcReads,1);assert.equal(ipc.observer.bind(id).valid,false);
});
'''
corrected=(P/'corrected.js').read_text(encoding='utf-8')
old="      const method = String(options?.method ?? input?.method ?? 'GET').toUpperCase();\n      if (url.hostname === 'ipc.localhost' && method === 'POST') {"
assert corrected.count(old)==1
new="""      if (url.hostname !== 'ipc.localhost') return Reflect.apply(originalFetch, this, args);
      const methodDescriptor = options == null ? undefined : Object.getOwnPropertyDescriptor(options, 'method');
      let method = 'GET';
      if (methodDescriptor && ('get' in methodDescriptor || typeof methodDescriptor.value !== 'string')) {
        invalidate('unobservable-fetch-method');
        return Reflect.apply(originalFetch, this, args);
      }
      if (methodDescriptor) method = methodDescriptor.value.toUpperCase();
      if (method === 'POST') {"""
corrected=corrected.replace(old,new)
# Never invoke the original fetch inside the observation try/catch: its thrown
# error must propagate directly and its method getter must execute exactly once.
corrected=corrected.replace("      if (url.hostname !== 'ipc.localhost') return Reflect.apply(originalFetch, this, args);",
    "      if (url.hostname === 'ipc.localhost') {")
corrected=corrected.replace("        return Reflect.apply(originalFetch, this, args);\n      }\n      if (methodDescriptor)",
    "      } else {\n      if (methodDescriptor)")
marker="        record(decodeURIComponent(url.pathname.slice(1)), 'android-channel-fetch');\n      }"
assert corrected.count(marker)==1
corrected=corrected.replace(marker,marker+'\n      }\n      }')
(S/'corrected.js').write_text(corrected,encoding='utf-8',newline='\n')
(S/'red.node.test.mjs').write_text(red,encoding='utf-8',newline='\n')
(S/'corrected.node.test.mjs').write_text(red.replace('../before.js','./corrected.js'),encoding='utf-8',newline='\n')
for label,expected in [('red',1),('corrected',0)]:
    with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
        p=subprocess.run(['node','--test',str(S/(label+'.node.test.mjs'))],stdout=out,stderr=err,
            timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
    (S/(label+'.receipt.json')).write_text(json.dumps({'exitCode':p.returncode,'scope':'proposal only; frozen production untouched'},indent=2)+'\n',encoding='utf-8')
    assert p.returncode==expected,(label,p.returncode)
    print(label,'actual exit',p.returncode,flush=True)
print('Forwarding getter regression reproduced; complete privacy/forwarding proposal passes 11 tests',flush=True)
