import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
const script=await readFile('D:/SoloSoul/tauri/src-tauri/src/android_native_perf/observer.js','utf8');
let clock=0;
const internals={},window={ipc:{postMessage(){}},__TAURI_INTERNALS__:internals,
  fetch(){return Promise.resolve();},location:{href:'http://tauri.localhost/'}};
window.top=window;
const context=vm.createContext({window,performance:{timeOrigin:10000,now:()=>++clock},
  document:{querySelectorAll:()=>[]},URL,console});
// Exact Tauri 2.11.2 order: internals object, invoke initialization script,
// metadata, then core.js defines the readonly invoke function.
vm.runInContext(script,context);
Object.defineProperty(internals,'invoke',{value:()=>{}});
window.ipc.postMessage('{"cmd":"get_ui_preferences","payload":{}}');
const proof=window.__SOLOSOUL_ANDROID_NATIVE_PERF__.bind('a'.repeat(32));
console.log(JSON.stringify({valid:proof.valid,invalidReasons:proof.invalidReasons,
  observedCount:proof.observedCount,readonlyInvokeDefinedAfterObserver:true}));
assert.equal(proof.valid,true,'Legitimate later Tauri readonly invoke definition must not invalidate transport observation');
