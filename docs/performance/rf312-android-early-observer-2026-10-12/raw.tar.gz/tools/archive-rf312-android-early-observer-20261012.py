from pathlib import Path
import hashlib,io,json,os,tarfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;I=B/'rf312-early-observer-implementation-20261012'
S=I/'positive-native-round2';H=B/'api31-host-rf312-observer-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
v=load(S/'independent-verification.json');assert v['acceptedNewObserverNative'] and v['nativeTests']==2
assert load(H/'stop.receipt.json')['ownedProcessExited']
assert load(I/'java-facade-node.receipt.json')['exitCode']==0
assert load(I/'negative-control/verification.json')['acceptedAbsenceControl']
assert load(I/'java-bridge-probe-round2/independent-verification.json')['acceptedLateDiagnostic']
sources=load(I/'sources.json');assert all(sha((R/n).read_bytes())==h for n,h in sources.items())
O=R/'docs/performance/rf312-android-early-observer-2026-10-12';O.mkdir(exist_ok=False)
files={}
allowed={'.json','.log','.py','.png','.xml','.js','.mjs','.kt','.rs','.toml','.kts','.properties','.gradle','.ps1','.txt'}
blocked={'.tar','.apk','.so','.jar','.aar','.class','.zip','.keystore','.idsig','.exe','.dll','.db','.bak'}
def add(p,name):
    assert p.is_file() and not p.is_symlink()
    assert not (p.stat().st_file_attributes & 0x400)
    assert p.suffix.lower() not in blocked and name not in files
    assert not name.startswith('/') and '..' not in Path(name).parts
    files[name]=p.read_bytes()
def collect(base,prefix):
    for directory,dirs,names in os.walk(base):
        dirs[:]=sorted(d for d in dirs if d not in {'build','.gradle','jni','node_modules','__pycache__'})
        for name in sorted(names):
            p=Path(directory)/name
            if p.suffix.lower() in allowed:add(p,prefix+'/'+p.relative_to(base).as_posix())
    for p in sorted(base.glob('*/project/build/outputs/apk/debug/output-metadata.json')):
        add(p,prefix+'/'+p.relative_to(base).as_posix())
    for p in sorted(base.glob('*/project/build/intermediates/merged_manifests/debug/processDebugManifest/AndroidManifest.xml')):
        add(p,prefix+'/'+p.relative_to(base).as_posix())
collect(I,'implementation')
for base,prefix in [(H,'emulator'),(B/'rf312-android-bridge-capabilities-20261012','initial-readonly-capability'),
    (B/'api31-host-rf312-bridge-20261012','initial-capability-emulator')]:collect(base,prefix)
media=B/'rf312-media-fixtures-d-20261012'
for p in sorted(media.iterdir()):
    if p.is_file() and p.suffix.lower() in {'.json','.log'}:add(p,'media-preparation/'+p.name)
for base in [R/'build/console-computer-use-recheck-20261012-tscon',
             R/'build/console-computer-use-recheck-20261012-kernel-reset']:
    for p in sorted(base.glob('*.json')):add(p,'computer-use/'+base.name+'/'+p.name)
toolNames=[
    'prepare-rf312-early-observer-checks-20261012.py','run-rf312-early-observer-windows-checks-20261012.py',
    'build-rf312-early-observer-android-release-20261012.py','build-rf312-corrected-android-release-20261012.py',
    'build-rf312-redacted-android-release-20261012.py','build-rf312-java-facade-android-release-20261012.py',
    'propose-rf312-invoke-order-correction-20261012.py','reproduce-rf312-early-invoke-order-20261012.mjs',
    'propose-rf312-observer-metadata-redaction-20261012.py','propose-rf312-observer-fetch-forwarding-20261012.py',
    'propose-rf312-java-facade-20261012.py','apply-rf312-observer-order-correction-20261012.py',
    'apply-rf312-observer-metadata-redaction-20261012.py','apply-rf312-java-facade-20261012.py',
    'stop-rf312-known-invoke-order-build-20261012.ps1','record-rf312-known-order-build-outcome-20261012.py',
    'build-rf312-early-observer-probe-20261012.py','prepare-rf312-early-observer-native-driver-20261012.py',
    'prepare-rf312-observer-negative-control-20261012.py','boot-rf312-observer-api31-20261012.py',
    'run-rf312-observer-negative-control-20261012.py','package-rf312-early-observer-release-20261012.py',
    'prepare-rf312-positive-observer-native-20261012.py','run-rf312-positive-observer-native-20261012.py',
    'run-rf312-positive-observer-native-round2-20261012.py','finish-rf312-positive-observer-native-round2-20261012.py',
    'build-rf312-java-bridge-probe-20261012.py','build-rf312-java-bridge-probe-round2-20261012.py',
    'prepare-rf312-java-bridge-driver-20261012.py','prepare-rf312-java-bridge-driver-round2-20261012.py',
    'run-rf312-java-bridge-diagnostic-20261012.py','run-rf312-java-bridge-diagnostic-round2-20261012.py',
    'prepare-rf312-media-fixtures-d-20261012.py','finalize-rf312-early-observer-docs-20261012.py',
    'check-staged-rf312-early-observer-20261012.py']
for n in toolNames:add(B/n,'tools/'+n)
add(Path(__file__),'tools/'+Path(__file__).name)
with tarfile.open(O/'raw.tar.gz','w:gz') as archive:
    for name,data in sorted(files.items()):
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
        archive.addfile(member,io.BytesIO(data))
index={'members':[{'path':n,'bytes':len(d),'sha256':sha(d)} for n,d in sorted(files.items())],
    'memberCount':len(files),'rawSha256':sha((O/'raw.tar.gz').read_bytes()),'rawBytes':(O/'raw.tar.gz').stat().st_size,
    'privateTarApkJarNativeLibrariesAndKeysExcluded':True,'allMembersReadBackVerified':False}
with tarfile.open(O/'raw.tar.gz') as archive:
    assert len(archive.getmembers())==len(files)
    for member in archive:
        assert member.isfile() and archive.extractfile(member).read()==files[member.name]
index['allMembersReadBackVerified']=True
(O/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
(O/'.gitattributes').write_text('raw.tar.gz -text\n*.json text eol=lf\n',encoding='utf-8')
summary={'acceptedEarlyTransportObserver':True,'nativePositive':v,
    'negativeControl':load(I/'negative-control/verification.json'),
    'failedMethodShadowNative':load(I/'positive-native/failed-counter-independent-verification.json'),
    'lateDiagnosticWrongCommand':load(I/'java-bridge-probe/wrong-command-classification.json'),
    'lateDiagnosticCorrected':load(I/'java-bridge-probe-round2/independent-verification.json'),
    'windowsChecks':load(I/'windows-checks-summary.json'),'nodeTests':12,
    'sourceProof':load(I/'source-proof.json'),'acceptedPackage':load(I/'android-release-package-round2/package-verification.json'),
    'originalHomeSourceUnchanged':True,'originalInvokeReadonlyKept':True,'newDependencies':0,
    'defaultFeatures':['custom-protocol'],'onlyAdditionalFeature':'android-native-perf',
    'emulatorNormalStop':load(H/'stop.receipt.json'),'archive':index,
    'fixedVault1005000NativePerformanceAccepted':False,'physicalArmPerformanceAccepted':False,
    'fullRF121Accepted':False,'fullRF312Accepted':False,'taskClosed':False,'commitCreated':False,
    'scopeAtArchiveCreation':True}
(R/'docs/performance/rf312-android-early-observer-2026-10-12.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print('Early observer sources/success/failure archive verified:',len(files),'members; task and full performance remain unclosed',flush=True)
