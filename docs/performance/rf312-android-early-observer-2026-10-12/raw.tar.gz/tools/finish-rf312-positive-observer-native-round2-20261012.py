from pathlib import Path
import datetime,hashlib,importlib.util,json,socket,subprocess,time
from PIL import Image
R=Path('D:/SoloSoul');B=Path(__file__).parent;I=B/'rf312-early-observer-implementation-20261012'
S=I/'positive-native-round2';H=B/'api31-host-rf312-observer-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
spec=importlib.util.spec_from_file_location('observer_restore',R/'tauri/scripts/android-home-native-regression.py')
home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
result=load(S/'verification.json');assert result['accepted'] and len(result['results'])==2
negative=load(I/'negative-control/verification.json');assert negative['acceptedAbsenceControl'] and negative['restored']
cases=[];images=[]
for mode in ['supported','fallback']:
    P=S/f'observer-{mode}';report=load(P/'report.json')
    home.verify_native((P/'native.log').read_text(encoding='utf-8'),'productionHomeWithEarlyIpcTransportObserver')
    assert report['passed'] and report['nativePassed'] and report['restored']
    assert report['originalApksRestored'] and report['ownedProbeRemoved']
    assert report['originalInstalledPackages']==report['restoredInstalledPackages']
    before=home.inventory(P/'private-data-before.tar',True)
    after=home.inventory(P/'private-data-restored.tar',True)
    assert before==after and before
    observer=load(P/'device-files/observer.json')
    assert observer['acceptedEarlyTransportObservation'] and observer['targetDebuggable'] is False
    assert observer['processId']==load(P/'device-files/report.json')['processId']
    document=observer['document'];assert document['invokeReadonly'] and document['mainFrame']
    transport=document['observer'];assert transport['valid'] and not transport['invalidReasons']
    assert transport['runId'] and len(transport['commands'])==transport['observedCount']>0
    rows=[]
    for f in sorted((P/'device-files').glob('*.png')):
        with Image.open(f) as image:
            image.load();assert image.format=='PNG' and image.width>=300 and image.height>=500
            assert any(lo!=hi for lo,hi in image.convert('RGB').getextrema())
            rows.append({'name':f.name,'width':image.width,'height':image.height,'sha256':sha(f),'decoded':True})
    assert len(rows)==11
    cases.append({'mode':mode,'nativeTests':1,'failures':0,'skipped':0,
        'privateEntriesExactlyRestored':len(before),'originalPackageBytesAndUidRestored':True,
        'processId':observer['processId'],'uid':observer['uid'],
        'transportCount':transport['observedCount'],'runId':transport['runId'],'invokeReadonly':True,
        'completeHomeStages':report['stages'],'pngs':rows})
assert len({r['processId'] for r in cases})==2
save(S/'independent-verification.json',{'acceptedNewObserverNative':True,'cases':cases,
    'nativeTests':2,'failures':0,'skipped':0,'completeOriginalHomeAndRestoreForBothModes':True,
    'wholeTransportMetadataScope':'send attempts including channel fetch/retries; not invoke completions',
    'fixedVaultPerformanceAccepted':False,'physicalArmAccepted':False,'fullRF312Accepted':False})
boot=load(H/'boot.receipt.json')
owned=next(x for x in load(H/'owned-processes-after-launch.json') if x['ProcessId']==boot['pid'])
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
def identity():
    p=subprocess.run([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {owned['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3"],
        check=True,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    return json.loads(p.stdout) if p.stdout.strip() else None
live=identity();assert live
for key in ['Name','ProcessId','ExecutablePath','CommandLine']:assert live[key]==owned[key]
assert datetime.datetime.fromisoformat(live['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
def read(*args):
    return subprocess.run([str(B/'sdk/platform-tools/adb.exe'),'-H','localhost','-P','5049','-s','emulator-5586',*args],
        check=True,capture_output=True,text=True,timeout=40,creationflags=subprocess.CREATE_NO_WINDOW).stdout.strip()
assert read('emu','avd','name').splitlines()[0]=='SoloSoul_RF121_API31_20261010'
assert not read('shell','pm','list','packages','com.solosoul.app.releaseprobe')
actual={'night':read('shell','cmd','uimode','night'),'blur':read('shell','settings','get','global','disable_window_blurs'),
    'font':read('shell','settings','get','system','font_scale'),
    'effectiveFont':home.activity_font_scale(read('shell','dumpsys','activity','processes')),
    'contrast':read('shell','settings','get','secure','high_text_contrast_enabled'),
    'animation':read('shell','settings','get','global','animator_duration_scale')}
assert actual==load(S/'original-system.json')
stop={'identity':live,'settingsExact':True,'probeAbsent':True,'response':read('emu','kill'),'forced':False}
deadline=time.monotonic()+40
while identity() is not None:assert time.monotonic()<deadline;time.sleep(1)
for port in [5586,5587]:
    with socket.socket() as sock:sock.bind(('127.0.0.1',port))
stop.update(ownedProcessExited=True,dedicatedPortsFree=True,at=datetime.datetime.now(datetime.timezone.utc).isoformat())
save(H/'stop.receipt.json',stop)
print('Two exact observer Release/home/restore gates independently verified; owned emulator normally exited',flush=True)
