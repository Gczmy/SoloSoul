from pathlib import Path
import json,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;I=B/'rf312-early-observer-implementation-20261012'
S=I/'metadata-redaction-proposal';S.mkdir(exist_ok=False)
source=R/'tauri/src-tauri/src/android_native_perf/observer.js'
testSource=R/'tauri/src-tauri/src/android_native_perf/observer.node.test.mjs'
original=source.read_text(encoding='utf-8');(S/'before.js').write_text(original,encoding='utf-8',newline='\n')
tests=testSource.read_text(encoding='utf-8')
tests+='''
test('invalid channel command is redacted without reading bodies or changing forwarding', () => {
  const s=setup();
  const options={method:'POST',get body(){throw new Error('body must not be read');}};
  s.window.fetch('http://ipc.localhost/private%20unrecognized%20value',options);
  const proof=json(s.observer.bind(id));
  assert.equal(proof.valid,false);assert.equal(s.fetchCalls.length,1);
  assert.equal(proof.commands[0].command,null);
  assert.ok(!JSON.stringify(proof).includes('private unrecognized value'));
});
test('public invalidation never echoes supplied private values into diagnostics', () => {
  const s=setup();
  s.observer.invalidate({private:'never-record-external-value'});
  const proof=json(s.observer.bind(id));
  assert.equal(proof.valid,false);
  assert.ok(proof.invalidReasons.every(reason=>typeof reason==='string'));
  assert.ok(!JSON.stringify(proof).includes('never-record-external-value'));
});
'''
red=tests.replace('./observer.js','./before.js')
(S/'red.node.test.mjs').write_text(red,encoding='utf-8',newline='\n')
corrected=original
old="if (!publicCommand(command)) invalidate('unobservable-command');\n    if (commands.length < maxEvents) commands.push({ command, transport, atMs });"
assert corrected.count(old)==1
corrected=corrected.replace(old,"const safeCommand = publicCommand(command) ? command : null;\n    if (safeCommand === null) invalidate('unobservable-command');\n    if (commands.length < maxEvents) commands.push({ command: safeCommand, transport, atMs });")
old='Object.freeze({ bind, snapshot, invalidate })'
assert corrected.count(old)==1
corrected=corrected.replace(old,"Object.freeze({ bind, snapshot, invalidate: () => invalidate('duplicate-installation') })")
(S/'corrected.js').write_text(corrected,encoding='utf-8',newline='\n')
(S/'corrected.node.test.mjs').write_text(tests.replace('./observer.js','./corrected.js'),encoding='utf-8',newline='\n')
for label,expected in [('red',1),('corrected',0)]:
    start=time.monotonic()
    with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
        p=subprocess.run(['node','--test',str(S/(label+'.node.test.mjs'))],stdout=out,stderr=err,
            timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
    (S/(label+'.receipt.json')).write_text(json.dumps({'exitCode':p.returncode,
        'elapsedSeconds':time.monotonic()-start,'scope':'proposal only; production source unchanged'},indent=2)+'\n',encoding='utf-8')
    assert p.returncode==expected,(label,p.returncode)
    print(label,'actual exit',p.returncode,flush=True)
assert source.read_text(encoding='utf-8')==original
print('Two actual metadata privacy failures reproduced; proposed correction passes all 10 Node gates; source remains frozen',flush=True)
