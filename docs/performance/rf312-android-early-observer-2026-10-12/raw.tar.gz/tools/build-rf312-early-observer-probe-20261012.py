from pathlib import Path
import datetime,hashlib,json,os,re,shutil,struct,subprocess,time,zipfile
R=Path('D:/SoloSoul');B=Path(__file__).parent
I=B/'rf312-early-observer-implementation-20261012'
S=I/'early-observer-test-apk';S.mkdir(exist_ok=False)
P=S/'project';P.mkdir();(P/'src/main/java/com/solosoul/app').mkdir(parents=True)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
sources=load(I/'sources.json')
inputs=load(B/'rf312-android-release-native-20261012/inputs.json')
recipe=B/'rf312-release-probe-build-round2-20261012/project'
copied={}
for name in ['build.gradle.kts','gradle.properties','settings.gradle.kts',
             'original-main-compile-only.jar','original-tauri-compile-only.jar','src/main/AndroidManifest.xml']:
    target=P/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(recipe/name,target)
    assert sha(recipe/name)==sha(target);copied[name]=sha(target)
tests=[]
for name in ['AndroidHomeInstrumentedTest.kt','AndroidEarlyIpcObserverInstrumentedTest.kt']:
    source=R/'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app'/name
    target=P/'src/main/java/com/solosoul/app'/name;shutil.copyfile(source,target)
    tests.append({'source':str(source),'copy':str(target),'sha256':sha(source)})
src=Path(tests[0]['source'])
assert sha(src)==inputs['runtimeSourceFiles'][src.relative_to(R).as_posix()]
def frozen():
    assert all(sha(R/n)==h for n,h in sources.items())
    for row in [inputs['release']['apk'],inputs['originalDebug'],inputs['originalTest']]:
        assert sha(Path(row.get('path',row.get('copy'))))==row['sha256']
    for row in tests:assert sha(Path(row['source']))==sha(Path(row['copy']))==row['sha256']
    for name,value in copied.items():assert sha(P/name)==value
frozen()
save(S/'input-proof.json',{'sources':sources,'testSources':tests,'copiedProvenAlignedRecipe':copied,
    'originalHomeTestUnchanged':True,'releaseReference':inputs['release']['apk'],
    'mainActivityHeadersCompileOnly':True,'nativeRuntimeAccepted':False,
    'note':'Test APK compilation only; current observer initialization correction is pending.'})
producer=(B/'build-rf312-release-probe-20261012.py').read_text(encoding='utf-8')
tail=producer[producer.index("jdk=Path('C:/Users/40299571/ss-android/jdk')"):]
tail=tail.replace("str(G/'gradlew.bat')","str(R/'tauri/src-tauri/gen/android/gradlew.bat')")
tail=tail.replace('all1839SourceAndOriginalApkHashesUnchanged','all1843SourceAndOriginalApkHashesUnchanged')
tail=tail.replace("copy=S/'solosoul-releaseprobe.apk'","copy=S/'solosoul-releaseprobe-early-observer.apk'")
(S/'actual-build-tail.py').write_text(tail,encoding='utf-8',newline='\n')
exec(compile(tail,str(S/'actual-build-tail.py'),'exec'))
classes=load(S/'dex-defined-classes.json')
assert 'Lcom/solosoul/app/AndroidEarlyIpcObserverInstrumentedTest;' in classes
assert not any(c.startswith(('Landroidx/startup/','Landroidx/profileinstaller/')) for c in classes)
save(S/'complete.json',{'testClassCompiled':True,'originalHomeSourceUnchanged':True,
    'mainActivityAndTauriClassesNotPackaged':True,'duplicateStartupInitializersAbsent':True,
    'nativeRuntimeAccepted':False})
print('Early observer test APK compiled and signed; native runtime not yet accepted',flush=True)
