from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-early-observer-implementation-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
assert load(S/'windows-checks-round2/complete.json')['acceptedDefaultWindowsChecks'] is True
assert load(S/'windows-checks-round2/workspace-tests.receipt.json')['exitCode']==0
assert load(S/'early-observer-test-apk/complete.json')['testClassCompiled'] is True
old=load(S/'sources.json');assert all(sha(R/n)==h for n,h in old.items())
backup=S/'before-order-correction';backup.mkdir(exist_ok=False)
for name in ['sources.json','source-proof.json']:shutil.copyfile(S/name,backup/name)
names=['tauri/src-tauri/src/android_native_perf/observer.js',
       'tauri/src-tauri/src/android_native_perf/observer.node.test.mjs']
for name in names:
    p=backup/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/name,p)
(R/names[0]).write_bytes((S/'observer-order-corrected-proposed.js').read_bytes())
test=(S/'observer-order-corrected-proposed.node.test.mjs').read_text(encoding='utf-8')
assert test.count('./observer-order-corrected-proposed.js')==1
(R/names[1]).write_text(test.replace('./observer-order-corrected-proposed.js','./observer.js'),encoding='utf-8',newline='\n')
def run(label,command):
    began=time.monotonic()
    with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
        p=subprocess.run(command,cwd=R/'tauri',stdout=out,stderr=err,timeout=90,creationflags=subprocess.CREATE_NO_WINDOW)
    save(S/(label+'.receipt.json'),{'exitCode':p.returncode,'command':command,'elapsedSeconds':time.monotonic()-began})
    assert p.returncode==0,label
run('corrected-prettier',['node',str(R/'tauri/node_modules/prettier/bin/prettier.cjs'),'--write',*[str(R/n) for n in names]])
run('corrected-observer-node',['node','--test',str(R/names[1])])
run('source-order-regression-green',['node',str(B/'reproduce-rf312-early-invoke-order-20261012.mjs')])
new={n:sha(R/n) for n in old}
changed={n:{'beforeSha256':old[n],'afterSha256':new[n]} for n in old if old[n]!=new[n]}
assert set(changed)==set(names),changed
save(S/'sources.json',new)
proof=load(S/'source-proof.json');proof.update(currentSourceFiles=new,
    sourceOrderCorrection=changed,defaultWindowsCheckedManifest='before-order-correction/sources.json',
    defaultWindowsRustCargoKotlinInputsUnchanged=True,newObserverNativeAccepted=False)
save(S/'source-proof.json',proof)
for name in names:shutil.copyfile(R/name,S/'executed-sources'/name)
save(S/'order-correction.json',{'correctedActualTauriInitializationOrder':True,
    'changedSources':changed,'compiledDefaultWindowsInputsUnchanged':True,
    'defaultWindowsFullChecksAcceptedForIdenticalCompiledInputs':True,
    'nodeTests':8,'originalRegressionFailedBeforeAndPassedAfter':True,
    'nativeAndroidAccepted':False,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print('Applied actual-order correction; 8 Node gates and original red-to-green pass. New Android build/native gate still required.',flush=True)
