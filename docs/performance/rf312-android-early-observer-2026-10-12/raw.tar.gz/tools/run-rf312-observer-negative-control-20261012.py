from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;I=B/'rf312-early-observer-implementation-20261012'
S=I/'negative-control';H=B/'api31-host-rf312-observer-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
inputs=load(S/'inputs.json');prep=load(S/'preparation.json')
env=os.environ.copy();env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',
    TEMP=str(B/'tmp'),TMP=str(B/'tmp'),PYTHONUTF8='1')
adb=B/'sdk/platform-tools/adb.exe';serial='emulator-5586';avd='SoloSoul_RF121_API31_20261010'
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
spec=importlib.util.spec_from_file_location('observer_home',S/'original-driver.py')
home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
def read(*args):
    return subprocess.run([str(adb),'-H','localhost','-P','5049','-s',serial,*args],env=env,
        check=True,capture_output=True,text=True,timeout=40,creationflags=subprocess.CREATE_NO_WINDOW).stdout.strip()
def frozen():
    assert all(sha(R/n)==h for n,h in inputs['runtimeSourceFiles'].items())
    assert sha(S/'early-observer-native-driver.py')==prep['driverSha256']
    for row in [inputs['release']['apk'],inputs['originalDebug'],inputs['originalTest'],inputs['runtimeTest']]:
        assert sha(Path(row.get('path',row.get('copy'))))==row['sha256']
def system():
    return {'night':read('shell','cmd','uimode','night'),
        'blur':read('shell','settings','get','global','disable_window_blurs'),
        'font':read('shell','settings','get','system','font_scale'),
        'effectiveFont':home.activity_font_scale(read('shell','dumpsys','activity','processes')),
        'contrast':read('shell','settings','get','secure','high_text_contrast_enabled'),
        'animation':read('shell','settings','get','global','animator_duration_scale')}
frozen();boot=load(H/'boot.receipt.json');assert boot['booted'] and boot['avdConfigUnchanged']
owned=next(x for x in load(H/'owned-processes-after-launch.json') if x['ProcessId']==boot['pid'])
p=subprocess.run([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {owned['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3"],
    check=True,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
live=json.loads(p.stdout)
for key in ['Name','ProcessId','ExecutablePath','CommandLine']:assert live[key]==owned[key],key
assert datetime.datetime.fromisoformat(live['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
assert read('emu','avd','name').splitlines()[0]==avd
assert read('shell','getprop','sys.boot_completed')=='1'
assert read('shell','getprop','ro.build.version.sdk')=='31'
assert read('shell','getprop','ro.product.cpu.abi')=='x86_64'
save(S/'owned-emulator-preflight.json',{'identity':live,'allIdentityFieldsVerified':True})
before=system();save(S/'original-system.json',before)
output=S/'baseline-supported-default-release'
command=['C:/Python314/python.exe',str(S/'early-observer-native-driver.py'),'--adb',str(adb),
    '--serial',serial,'--avd',avd,'--apk',inputs['release']['apk']['path'],
    '--test-apk',inputs['runtimeTest']['path'],'--restore-apk',inputs['originalDebug']['copy'],
    '--output',str(output),'--mode','supported','--scenario','baseline']
start=time.monotonic()
with (S/'negative-control.stdout.log').open('xb') as out,(S/'negative-control.stderr.log').open('xb') as err:
    p=subprocess.Popen(command,cwd=R/'tauri',env=env,stdin=subprocess.DEVNULL,
        stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    save(S/'negative-control.live.json',{'pid':p.pid,'command':command})
    print('Default Release negative control live PID',p.pid,flush=True);code=p.wait()
frozen();after=system();report=load(output/'report.json')
restored=bool(report.get('restored') and report.get('originalApksRestored') and report.get('ownedProbeRemoved')
    and report.get('blurRestored') and report.get('frozenInputsUnchanged') and before==after
    and not any(report.get(k) for k in ['restoreError','blurRestoreError','sourceRestoreError']))
receipt={'exitCode':code,'elapsedSeconds':time.monotonic()-start,'restored':restored,
    'systemBefore':before,'systemAfter':after,'nativePassed':report.get('nativePassed'),
    'nativeFailureIsActualFailNotSkip':False,'acceptedAbsenceControl':False}
save(S/'negative-control.receipt.json',receipt)
assert restored,'Stop for incomplete restoration'
text=(output/'native.log').read_text(encoding='utf-8')
evidence=load(output/'device-files/report.json');transport=load(output/'device-files/observer.json')
stages=home.verify_evidence(evidence,'baseline',False)
expected=prep['expectedNativeFailure']
accepted=bool(code==1 and not report.get('passed') and not report.get('nativePassed')
    and expected in text and 'FAILURES!!!' in text and 'Tests run: 1,  Failures: 1' in text
    and transport.get('acceptedEarlyTransportObservation') is False
    and transport.get('document',{}).get('present') is False and len(stages)==12)
receipt.update(nativeFailureIsActualFailNotSkip=True,acceptedAbsenceControl=accepted,
    expectedFailure=expected,completeHomeStages=stages,observerProof=transport,
    originalDebugAndTestApksRestored=True,defaultReleaseApkUnchanged=True)
save(S/'negative-control.receipt.json',receipt)
save(S/'verification.json',{'acceptedAbsenceControl':accepted,'restored':restored,
    'positiveOptionalObserverNativeAccepted':False,'fixedVaultPerformanceAccepted':False,
    'scope':'default Release absence is an expected genuine one-test failure after complete original home behavior',
    'result':receipt,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
assert accepted,'Unexpected negative-control outcome'
print('Default Release correctly fails only optional-observer absence; whole home and restoration independently verified',flush=True)
