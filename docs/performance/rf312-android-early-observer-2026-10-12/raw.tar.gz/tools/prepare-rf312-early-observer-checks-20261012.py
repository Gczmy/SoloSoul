from pathlib import Path
import hashlib,json,subprocess,tomllib
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-early-observer-implementation-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=load(B/'rf312-android-release-native-20261012/inputs.json')['runtimeSourceFiles']
new=['tauri/src-tauri/src/android_native_perf.rs','tauri/src-tauri/src/android_native_perf/observer.js',
    'tauri/src-tauri/src/android_native_perf/observer.node.test.mjs',
    'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidEarlyIpcObserverInstrumentedTest.kt']
sources={name:sha(R/name) for name in [*old,*new]}
assert len(sources)==1843
changed={name:{'beforeSha256':value,'afterSha256':sources[name]} for name,value in old.items() if value!=sources[name]}
assert set(changed)=={'tauri/src-tauri/Cargo.toml','tauri/src-tauri/src/lib.rs'},changed
manifest=tomllib.loads((R/'tauri/src-tauri/Cargo.toml').read_text(encoding='utf-8'))
assert manifest['features']['default']==['custom-protocol'] and manifest['features']['android-native-perf']==[]
(S/'sources.json').write_text(json.dumps(sources,indent=2)+'\n',encoding='utf-8')
(S/'source-proof.json').write_text(json.dumps({'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    'currentSourceFiles':sources,'existingSourceDifferences':changed,'newFiles':new,
    'defaultFeatures':manifest['features']['default'],'optionalFeatureDependencies':[],'newDependencies':0,
    'originalHomeTestSha256':sources['tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidHomeInstrumentedTest.kt'],
    'originalHomeTestByteUnchanged':True,'newObserverNativeAccepted':False,'fixedVaultPerformanceAccepted':False},indent=2)+'\n',encoding='utf-8')
for name in ['tauri/src-tauri/Cargo.toml','tauri/src-tauri/src/lib.rs',*new]:
    target=S/'executed-sources'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/name).read_bytes())
print('Frozen 1843 sources; exactly Cargo/lib additions plus four non-default/test files, original home source unchanged',flush=True)
