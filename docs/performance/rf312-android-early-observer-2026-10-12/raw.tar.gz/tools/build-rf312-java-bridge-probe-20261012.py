from pathlib import Path
import datetime,hashlib,json,os,re,shutil,struct,subprocess,time,zipfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;I=B/'rf312-early-observer-implementation-20261012'
S=I/'java-bridge-probe';S.mkdir(exist_ok=False);P=S/'project';P.mkdir()
(P/'src/main/java/com/solosoul/app').mkdir(parents=True)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
inputs=load(I/'positive-native/inputs.json');sources=inputs['runtimeSourceFiles']
recipe=B/'rf312-release-probe-build-round2-20261012/project';copied={}
for name in ['build.gradle.kts','gradle.properties','settings.gradle.kts',
    'original-main-compile-only.jar','original-tauri-compile-only.jar','src/main/AndroidManifest.xml']:
    target=P/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(recipe/name,target)
    copied[name]=sha(target);assert copied[name]==sha(recipe/name)
src=R/'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidHomeInstrumentedTest.kt'
shutil.copyfile(src,P/'src/main/java/com/solosoul/app'/src.name)
diagnostic=P/'src/main/java/com/solosoul/app/AndroidJavaBridgeProbeInstrumentedTest.kt'
diagnostic.write_text('''package com.solosoul.app

import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

@RunWith(AndroidJUnit4::class)
class AndroidJavaBridgeProbeInstrumentedTest {
    private fun webView(view: View): WebView? {
        if (view is WebView) return view
        if (view is ViewGroup) for (i in 0 until view.childCount) webView(view.getChildAt(i))?.let { return it }
        return null
    }
    @Test fun productionHomeWithLateJavaBridgeProbe() {
        val instrumentation=InstrumentationRegistry.getInstrumentation()
        val args=InstrumentationRegistry.getArguments()
        assertEquals("true",args.getString("privateDataBackedUp"))
        val tag=requireNotNull(args.getString("evidenceTag"));require(Regex("fe2-home-[a-f0-9]{32}").matches(tag))
        val monitor=instrumentation.addMonitor(MainActivity::class.java.name,null,false)
        val proof=JSONObject().put("acceptedLateBridgeDiagnostic",false)
            .put("scope","late Java bridge mutability/forwarding only; not early or complete IPC measurement")
            .put("processId",android.os.Process.myPid()).put("uid",android.os.Process.myUid())
        fun js(activity: MainActivity, expression: String): JSONObject {
            val done=CountDownLatch(1);var raw:String?=null
            instrumentation.runOnMainSync {
                requireNotNull(webView(activity.window.decorView)).evaluateJavascript(expression) { value -> raw=value;done.countDown() }
            }
            assertTrue(done.await(3,TimeUnit.SECONDS))
            val parsed=JSONArray("[${raw?:"null"}]").opt(0)
            return if(parsed is String && parsed.startsWith("{")) JSONObject(parsed) else JSONObject()
        }
        try {
            AndroidHomeInstrumentedTest().realHomePreservesGlassAndCopyAcrossLockUnlock()
            val activity=requireNotNull(monitor.lastActivity) as MainActivity
            js(activity,"""(() => {
              const key='__RF312_LATE_BRIDGE_DIAGNOSTIC__';
              if(window[key]) throw new Error('Owned diagnostic already exists');
              const result={pending:true};window[key]=result;
              (async()=>{
                const bridge=window.ipc,post=bridge.postMessage,invoke=window.__TAURI_INTERNALS__.invoke;
                const globalDescriptor=Object.getOwnPropertyDescriptor(window,'ipc');
                const descriptor=Object.getOwnPropertyDescriptor(bridge,'postMessage');
                const flags=d=>d?{writable:d.writable===true,configurable:d.configurable===true,
                  hasGetter:typeof d.get==='function',valueType:typeof d.value}:null;
                result.global=flags(globalDescriptor);result.method=flags(descriptor);
                result.methodIdentityStable=bridge.postMessage===bridge.postMessage;
                let directCalls=0,facadeCalls=0;
                const direct=function(...args){directCalls++;return Reflect.apply(post,this,args);};
                try {
                  if(descriptor && 'value' in descriptor) {
                    Object.defineProperty(bridge,'postMessage',{...descriptor,value:direct});
                    result.directIdentityInstalled=bridge.postMessage===direct;
                    await invoke('get_ui_preferences');result.directResolved=true;
                  }
                } catch {result.directError=true;}
                finally {if(descriptor)Object.defineProperty(bridge,'postMessage',descriptor);}
                result.directCalls=directCalls;
                const facade=Object.create(bridge);
                Object.defineProperty(facade,'postMessage',{value:function(...args){
                  facadeCalls++;return Reflect.apply(post,this===facade?bridge:this,args);
                }});
                try {
                  Object.defineProperty(window,'ipc',{...globalDescriptor,value:facade});
                  result.facadeIdentityInstalled=window.ipc===facade;
                  await invoke('get_ui_preferences');result.facadeResolved=true;
                } catch {result.facadeError=true;}
                finally {Object.defineProperty(window,'ipc',globalDescriptor);}
                result.facadeCalls=facadeCalls;result.globalRestored=window.ipc===bridge;
                const protectedInvoke=Object.getOwnPropertyDescriptor(window.__TAURI_INTERNALS__,'invoke');
                result.invokeIdentityUnchanged=window.__TAURI_INTERNALS__.invoke===invoke;
                result.invokeReadonly=protectedInvoke.writable===false&&protectedInvoke.configurable===false;
                result.pending=false;result.done=true;
              })().catch(()=>{result.error=true;result.pending=false;});
              return JSON.stringify({started:true});})()""")
            val deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(10)
            var state=JSONObject()
            do {
                state=js(activity,"JSON.stringify(window.__RF312_LATE_BRIDGE_DIAGNOSTIC__||{})")
                if(state.optBoolean("done")||state.optBoolean("error"))break
                Thread.sleep(100)
            } while(System.nanoTime()<deadline)
            proof.put("diagnostic",state)
            assertTrue(state.toString(),state.optBoolean("done"));assertFalse(state.optBoolean("error"))
            assertTrue(state.getBoolean("globalRestored"));assertTrue(state.getBoolean("invokeIdentityUnchanged"))
            assertTrue(state.getBoolean("invokeReadonly"));assertTrue(state.getBoolean("facadeResolved"))
            assertTrue(state.getBoolean("facadeIdentityInstalled"));assertEquals(1,state.getInt("facadeCalls"))
            proof.put("acceptedLateBridgeDiagnostic",true)
        } finally {
            instrumentation.removeMonitor(monitor)
            val out=File(instrumentation.targetContext.getExternalFilesDir(null),tag)
            if(out.isDirectory)File(out,"bridge-diagnostic.json").writeText(proof.toString(2))
        }
    }
}
''',encoding='utf-8',newline='\n')
def frozen():
    assert all(sha(R/n)==h for n,h in sources.items())
    assert sha(src)==sha(P/'src/main/java/com/solosoul/app'/src.name)
    for name,value in copied.items():assert sha(P/name)==value
    for row in [inputs['release']['apk'],inputs['originalDebug'],inputs['originalTest']]:
        assert sha(Path(row.get('path',row.get('copy'))))==row['sha256']
frozen();save(S/'input-proof.json',{'sources':sources,'diagnosticSourceSha256':sha(diagnostic),
    'originalHomeSourceUnchanged':True,'packageInputs':copied,'targetRelease':inputs['release']['apk'],
    'lateOnlyNoEarlyPerformanceAccepted':True})
producer=(B/'build-rf312-release-probe-20261012.py').read_text(encoding='utf-8')
tail=producer[producer.index("jdk=Path('C:/Users/40299571/ss-android/jdk')"):]
tail=tail.replace("str(G/'gradlew.bat')","str(R/'tauri/src-tauri/gen/android/gradlew.bat')")
tail=tail.replace('all1839SourceAndOriginalApkHashesUnchanged','all1843SourceAndOriginalApkHashesUnchanged')
tail=tail.replace("copy=S/'solosoul-releaseprobe.apk'","copy=S/'solosoul-releaseprobe-java-bridge-diagnostic.apk'")
(S/'actual-build-tail.py').write_text(tail,encoding='utf-8',newline='\n')
exec(compile(tail,str(S/'actual-build-tail.py'),'exec'))
assert 'Lcom/solosoul/app/AndroidJavaBridgeProbeInstrumentedTest;' in load(S/'dex-defined-classes.json')
save(S/'complete.json',{'diagnosticTestCompiled':True,'wholeHomeSourceUnchanged':True,
    'earlyMeasurementAccepted':False,'nativeDiagnosticAccepted':False})
print('Independent late Java bridge mutation/forwarding probe compiled; native diagnostic not yet accepted',flush=True)
