$ErrorActionPreference = 'Stop'
$taskBase = 'D:\SoloSoul\build\android-native-feasibility-20261010'
$taskStage = Join-Path $taskBase 'rf312-early-observer-implementation-20261012'
$taskExpected = Join-Path $taskBase 'rustup\toolchains\1.96.0-x86_64-pc-windows-msvc\bin\cargo.exe'
$taskRoot = Get-CimInstance Win32_Process -Filter 'ProcessId = 13204'
if ($null -eq $taskRoot) { throw 'Build handle no longer live; poll original terminal instead' }
if ($taskRoot.ExecutablePath -ne $taskExpected -or $taskRoot.CommandLine -notmatch 'build --locked --offline -p solo_soul --lib --release --target x86_64-linux-android --features android-native-perf') { throw 'Build root identity mismatch' }
if ([Math]::Abs(($taskRoot.CreationDate - [DateTime]::Parse('2026-10-12T07:42:08.959629+01:00')).TotalMilliseconds) -gt 1) { throw 'Build root birth differs' }
$taskSnapshot = @(Get-CimInstance Win32_Process)
$taskOwned = @($taskRoot)
$taskIds = @($taskRoot.ProcessId)
do {
    $taskNew = @($taskSnapshot | Where-Object { $_.ParentProcessId -in $taskIds -and $_.ProcessId -notin $taskIds })
    foreach ($taskChild in $taskNew) {
        if ($taskChild.CreationDate -lt $taskRoot.CreationDate) { throw 'Invalid descendant birth' }
        $taskIds += $taskChild.ProcessId; $taskOwned += $taskChild
    }
} while ($taskNew.Count -gt 0)
foreach ($taskChild in $taskOwned) {
    if ($taskChild.Name -eq 'conhost.exe') { continue }
    if (-not $taskChild.ExecutablePath.StartsWith($taskBase + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected descendant executable; no process stopped' }
}
$taskPlan = @($taskOwned | Where-Object { $_.Name -ne 'conhost.exe' } | Select-Object Name,ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine)
$taskPlan | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $taskStage 'known-order-build-stop-plan.json') -Encoding UTF8
Stop-Process -Id $taskRoot.ProcessId -ErrorAction Stop
foreach ($taskChild in @($taskPlan | Where-Object { $_.ProcessId -ne $taskRoot.ProcessId })) {
    $taskLive = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $taskChild.ProcessId)
    if ($null -eq $taskLive) { continue }
    if ($taskLive.ExecutablePath -ne $taskChild.ExecutablePath -or $taskLive.CreationDate -ne $taskChild.CreationDate) { throw 'Descendant identity changed; refusing stop' }
    Stop-Process -Id $taskChild.ProcessId -ErrorAction Stop
}
$taskResult = [ordered]@{ reason='Verified source-order bug: append invoke script precedes core.js readonly invoke definition'; redRegressionObservedExitCode=1; observationTimeoutWasNotReason=$true; stoppedOnlyOwnedBuild=$true; windowsDefaultQueueNotStopped=$true; root=$taskPlan; at=[DateTime]::UtcNow.ToString('o') }
$taskResult | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskStage 'known-order-build-stop-result.json') -Encoding UTF8
Write-Output 'Stopped exact owned Android Cargo/rustc build for verified source-order correction; Windows check queue preserved'
