from pathlib import Path
import json,subprocess
R=Path('D:/SoloSoul');B=Path(__file__).parent;I=B/'rf312-early-observer-implementation-20261012'
S=I/'java-facade-proposal';S.mkdir(exist_ok=False)
old=(R/'tauri/src-tauri/src/android_native_perf/observer.js').read_text(encoding='utf-8')
tests=(R/'tauri/src-tauri/src/android_native_perf/observer.node.test.mjs').read_text(encoding='utf-8')
assert tests.count('readonlyBridge = false,')==1
tests=tests.replace('readonlyBridge = false,','stickyBridge = false, readonlyIpcGlobal = false, readonlyBridge = false,')
needle='  const window = {\n    ipc: bridge,';assert tests.count(needle)==1
tests=tests.replace(needle,"""  const originalBridge = stickyBridge ? new Proxy(bridge, {
    defineProperty(target, key, descriptor) {
      if (key === 'postMessage') return true; // Android host reports flags but ignores shadowing.
      return Reflect.defineProperty(target, key, descriptor);
    }
  }) : bridge;
  const window = {
    ipc: originalBridge,""")
needle="  Object.defineProperty(window, 'fetch', {";assert tests.count(needle)==1
tests=tests.replace(needle,"  if (readonlyIpcGlobal) Object.defineProperty(window, 'ipc', {value:originalBridge,writable:false,configurable:false});\n"+needle)
needle='    window,\n    context,';assert tests.count(needle)==1
tests=tests.replace(needle,'    window,\n    originalBridge,\n    context,')
tests=tests.replace('setup({ readonlyBridge: true, readonlyFetch: true })','setup({ readonlyIpcGlobal: true, readonlyBridge: true, readonlyFetch: true })')
tests+='''
test('captures sticky Java host sends without mutating the original host method or native receiver', () => {
  const s=setup({stickyBridge:true}),post=s.originalBridge.postMessage;
  s.window.ipc.postMessage('{"cmd":"ui_get_preferences","payload":{}}');
  const proof=json(s.observer.bind(id));assert.equal(proof.valid,true);
  assert.equal(proof.observedCount,1);assert.equal(s.bridgeCalls.length,1);
  assert.equal(s.bridgeCalls[0].receiver,s.originalBridge);
  assert.equal(s.originalBridge.postMessage,post);
});
'''
(S/'before.js').write_text(old,encoding='utf-8',newline='\n')
(S/'red.node.test.mjs').write_text(tests.replace('./observer.js','./before.js'),encoding='utf-8',newline='\n')
new=old
needle="  const originalPost = originalBridge?.postMessage;";assert new.count(needle)==1
new=new.replace(needle,needle+"\n  const bridgeDescriptor = Object.getOwnPropertyDescriptor(window, 'ipc');\n  let bridgeFacade = null;")
needle='    return Reflect.apply(originalPost, this, args);';assert new.count(needle)==1
new=new.replace(needle,'    return Reflect.apply(originalPost, this === bridgeFacade ? originalBridge : this, args);')
start=new.index('  // Preserve every descriptor flag and original receiver/arguments/return value.')
end=new.index("  if (!bridgeInstalled) invalidate('bridge-wrapper-unavailable');",start)
new=new[:start]+'''  // Android Java host methods can ignore JS property replacement despite
  // writable/configurable descriptors. Keep that host untouched and place a
  // delegating object in its mutable window alias. Native calls retain the
  // original Java receiver, arguments, return value and thrown error.
  if (typeof originalPost === 'function' && bridgeDescriptor && 'value' in bridgeDescriptor
      && (bridgeDescriptor.writable || bridgeDescriptor.configurable)) {
    try {
      bridgeFacade = Object.create(originalBridge);
      Object.defineProperty(bridgeFacade, 'postMessage', {
        ...(postDescriptor || {}), value: observedPost,
      });
      Object.defineProperty(window, 'ipc', {...bridgeDescriptor, value: bridgeFacade});
      bridgeInstalled = window.ipc === bridgeFacade && bridgeFacade.postMessage === observedPost;
    } catch {
      invalidate('bridge-wrapper-installation-failed');
    }
  }
'''+new[end:]
needle='window.ipc !== originalBridge || originalBridge?.postMessage !== observedPost'
assert new.count(needle)==1
new=new.replace(needle,'window.ipc !== bridgeFacade || bridgeFacade?.postMessage !== observedPost')
(S/'corrected.js').write_text(new,encoding='utf-8',newline='\n')
(S/'corrected.node.test.mjs').write_text(tests.replace('./observer.js','./corrected.js'),encoding='utf-8',newline='\n')
for label,expected in [('red',1),('corrected',0)]:
    with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
        p=subprocess.run(['node','--test',str(S/(label+'.node.test.mjs'))],stdout=out,stderr=err,
            timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
    (S/(label+'.receipt.json')).write_text(json.dumps({'exitCode':p.returncode,'scope':'proposal only; actual full early native gate unaccepted'},indent=2)+'\n',encoding='utf-8')
    assert p.returncode==expected,(label,p.returncode)
    print(label,'actual exit',p.returncode,flush=True)
print('Sticky Java host failure reproduced; proposed non-mutating native-receiver facade passes 12 Node gates',flush=True)
