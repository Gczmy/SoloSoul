from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;D=R/'build/rf312-maintenance-20261009'
S=B/'rf312-media-fixtures-d-20261012';S.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
old=load(D/'build-inputs-dtemp.json');freeze=load(D/'fresh-fixtures-freeze.json')
assert load(D/'ordinary-fixture-build.receipt.json')['exitCode']==0
sourceExe=D/'cargo-target/release/examples/perf_baseline.exe'
assert sha(sourceExe)==freeze['generatorSha256']
contracts={n:h for n,h in old['sourceFiles'].items() if
    n.startswith('tauri/crates/solosoul-core/examples/perf_baseline') or
    n in ['tauri/crates/solosoul-core/tests/fixtures/ocr_test.png',
           'tauri/crates/solosoul-core/tests/fixtures/text_only.pdf',
           'tauri/crates/solosoul-core/tests/fixtures/scanned.pdf']}
assert len(contracts)>=7 and all(sha(R/n)==h for n,h in contracts.items())
exe=S/'historical-verified-fixture-generator.exe';shutil.copyfile(sourceExe,exe)
compiledDifferences={n:{'compiledSha256':h,'currentSha256':sha(R/n)}
    for n,h in old['sourceFiles'].items() if n.startswith('tauri/crates/') and sha(R/n)!=h}
save(S/'input-proof.json',{'generator':str(exe),'generatorSha256':sha(exe),
    'compiledSourceHead':old['baseHead'],'compiledSourceFiles':old['sourceFiles'],
    'currentFixtureContractInputsUnchanged':contracts,
    'compiledCrateSourcesDifferentFromCurrent':compiledDifferences,
    'generatorIsCurrentFullSourceBuild':False,
    'scope':'public synthetic media fixtures produced by the frozen historical verified generator; not GUI/performance acceptance',
    'historicalBuildReceipt':load(D/'ordinary-fixture-build.receipt.json'),
    'physicalOrAndroidPerformanceAccepted':False})
env=os.environ.copy();env.update(SOLOSOUL_SECURE='1',TEMP=str(B/'tmp'),TMP=str(B/'tmp'))
def unchanged():
    assert sha(exe)==sha(sourceExe)==freeze['generatorSha256']
    assert all(sha(R/n)==h for n,h in contracts.items())
def run(label,args):
    unchanged();command=[str(exe),*args];began=time.monotonic()
    with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(command,cwd=R/'tauri',env=env,stdin=subprocess.DEVNULL,
            stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(S/(label+'.live.json'),{'pid':p.pid,'command':command})
        print(label,'live PID',p.pid,flush=True);code=p.wait()
    unchanged();save(S/(label+'.receipt.json'),{'exitCode':code,'command':command,
        'elapsedSeconds':time.monotonic()-began,'generatorAndContractInputsUnchanged':True})
    assert code==0,label
    print(label,'exit',code,flush=True)
rows=[]
for count in [100,5000]:
    output=S/f'vault{count}';assert not output.exists()
    run(f'media-{count}-generate',['--media-fixture-output',str(output),'--objects',str(count)])
    before={p.relative_to(output).as_posix():sha(p) for p in sorted(output.rglob('*')) if p.is_file()}
    run(f'media-{count}-verify',['--verify-media-fixture',str(output)])
    after={p.relative_to(output).as_posix():sha(p) for p in sorted(output.rglob('*')) if p.is_file()}
    assert before==after
    marker=load(output/'rf312-media-fixture.json')
    assert marker['schemaVersion']==2 and marker['includesAttachments'] and marker['includesOcrFixture']
    assert marker['baseFixture']['objectCount']==count and len(marker['attachments'])==4
    rows.append({'objects':count,'path':str(output),'sourceUnchangedByIndependentVerify':True,
        'files':before,'marker':marker,'acceptedNativePerformance':False})
save(S/'fixture-verification.json',{'acceptedFixturePreparation':True,'fixtures':rows,
    'historicalGeneratorProvenancePreserved':True,'currentFullSourceGeneratorClaimed':False,
    'nativeOrPhysicalPerformanceAccepted':False,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print('D-drive public 100/5000 media fixtures generated and independently reopened; native performance remains unaccepted',flush=True)
