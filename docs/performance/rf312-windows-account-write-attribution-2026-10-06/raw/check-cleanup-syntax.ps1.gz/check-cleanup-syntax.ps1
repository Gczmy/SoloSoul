#Requires -Version 7.0
$ErrorActionPreference = 'Stop'
$taskParserTokens = $null
$taskParserErrors = $null
$taskParserPath = Join-Path $PSScriptRoot 'cleanup-account-caches.ps1'
$null = [System.Management.Automation.Language.Parser]::ParseFile($taskParserPath, [ref]$taskParserTokens, [ref]$taskParserErrors)
if ($taskParserErrors.Count -ne 0) { throw 'Prepared cleanup script has syntax errors' }
Write-Output ('PowerShell ' + $PSVersionTable.PSVersion.ToString() + '; cleanup syntax valid; no cleanup invoked')
