from verify_auth_freezes import verify_sources
import pathlib,json,hashlib,subprocess,sys,datetime
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul');stem='rf312-windows-account-write-attribution-2026-10-06';d=r/'docs/performance'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,text=True,cwd=r):return subprocess.check_output(['git','-c','safe.directory='+str(cwd).replace(chr(92),'/'),'-c','core.safecrlf=false','-c','core.autocrlf=false',*args],cwd=cwd,text=text)
base=load(s/'git-preservation-before-account-stage.json');proof=load(d/(stem+'.json'));assert proof['documentationVerification']['success'] and load(s/'documentation-verification.json')['success']
assert git('rev-parse','HEAD').strip()==base['head'] and git('stash','list','--format=%H').strip()==base['stashes'] and not git('diff','--cached','--name-only').strip()
verify_sources(s,r);codes=sorted(load(s/'before-sources.json')['files']);modified=['docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md','docs/performance/RF-312-native-auth-attribution.md','docs/performance/RF-312-windows-native-app-baseline.md']
assert set(git('diff','--name-only').splitlines())==set(codes+modified)
new=['docs/performance/RF-312-native-account-write-attribution.md','docs/performance/'+stem+'.json'];folder=d/stem;index=load(folder/'index.json');raw=['docs/performance/'+stem+'/'+q['archive'] for q in index['files']]+['docs/performance/'+stem+'/index.json'];expected=set(codes+modified+new+raw)
assert all((r/p).is_file() and not (r/p).is_symlink() for p in expected)
assert set(git('ls-files','--others','--exclude-standard').splitlines())==set(new+raw)
for q in index['files']:assert sha((folder/q['archive']).read_bytes())==q['archiveSha256']
git('add','--',*codes,*modified,*new,'docs/performance/'+stem)
assert set(git('diff','--cached','--name-only').splitlines())==expected
git('diff','--cached','--check')
for rel in expected:assert sha(git('show',':'+rel,text=False))==sha((r/rel).read_bytes()),rel
sub=r/'SoloSoul_plugin_market';assert git('rev-parse','HEAD',cwd=sub).strip()==base['submoduleHead'] and not git('status','--short',cwd=sub).strip()
assert git('ls-tree','HEAD','SoloSoul_plugin_market').strip()==base['submoduleTree']
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'parent':base['head'],'stagedFiles':len(expected),'paths':sorted(expected),'allStagedBytesMatchWorkingFiles':True,'stashAndSubmodulePreserved':True,'pushRequested':False}
p=s/'staging-verification.json';assert not p.exists();p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({'stagedFiles':len(expected),'sourceFiles':len(codes),'allStagedBytesMatch':True,'taskClosed':False},ensure_ascii=False),flush=True)
