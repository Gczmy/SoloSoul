from verify_auth_freezes import verify_sources
import pathlib,json,hashlib,subprocess,sys
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
 checkpoint=json.loads((s/'build-checkpoint.json').read_text(encoding='utf-8-sig'))
 assert checkpoint['sha256']==sha(pathlib.Path(checkpoint['exe']))
 verify_sources(s,r)
 for name in ['frontend-freeze.json']:
  rows=json.loads((s/name).read_text(encoding='utf-8-sig'))['files']
  assert all(sha(r/p)==h for p,h in rows.items()),name
 for name in ['public-source-freeze.json','previous-build-freeze.json']:
  rows=json.loads((s/name).read_text(encoding='utf-8-sig'))['files']
  assert all(sha(pathlib.Path(p))==h for p,h in rows.items()),name
 for row in json.loads((s/'resource-freeze.json').read_text(encoding='utf-8-sig'))['records']:
  assert sha(pathlib.Path(row['source']))==row['sha256']==sha(pathlib.Path(row['copy']))
 return checkpoint
for count in [100,5000]:
 checkpoint=verify()
 output=s/('account'+str(count));assert not output.exists()
 args=['node','scripts/native-perf-auth-attribution.mjs','--exe',checkpoint['exe'],'--fixture',str(pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\solosoul-rf312-native-fixtures-20260930')/('vault'+str(count))),'--output',str(output),'--samples','3']
 rc=subprocess.call([sys.executable,str(s/'run-check.py'),'account-native'+str(count),*args])
 verify()
 if rc:raise SystemExit(rc)
print('Both whole native authentication diagnostic groups complete',flush=True)
