from pathlib import Path
import json,hashlib,subprocess,sys,datetime
s=Path(__file__).parent;r=Path(r"C:\Users\40299571\SoloSoul");fix=Path(r"C:\Users\40299571\AppData\Local\Temp\ss-rf1096-fixture-kdf-20261006")
load=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
evidence=r/"docs/verification/rf1096-fixture-kdf-2026-10-06.json";e=load(evidence);assert e["success"]
args=["git","-c","safe.directory=C:/Users/40299571/SoloSoul"]
commit=subprocess.check_output(args+["rev-parse","HEAD"],cwd=r,text=True).strip()
subject=subprocess.check_output(args+["log","-1","--format=%s"],cwd=r,text=True).strip();assert "RF-1096" in subject,subject
freeze=load(fix/"check-source-freeze.json");assert all(sha(r/p)==h for p,h in freeze["sourceFiles"].items())
assert all(sha(r/p)==h for p,h in load(fix/"baseline.json")["preservedAccountWork"].items())
commands=[
 ("account-cli-fmt",["cargo","+1.99.0","fmt","--manifest-path","../solosoul_cli/Cargo.toml","--","--check"]),
 ("account-cli-clippy",["cargo","clippy","--locked","--manifest-path","../solosoul_cli/Cargo.toml","--all-targets","--","-D","warnings"]),
 ("account-cli-tests",["cargo","test","--locked","--manifest-path","../solosoul_cli/Cargo.toml","--verbose","--no-fail-fast"]),
]
for name,command in commands:
 rc=subprocess.call([sys.executable,"-X","utf8",str(s/"run-check.py"),name,*command])
 if rc:raise SystemExit(rc)
checks={name:load(s/(name+".receipt.json")) for name in ("account-pdfium-pe","account-js-format","account-core-feature","account-node-target","account-node-full")}
for name,_ in commands:checks[name]=load(s/(name+".receipt.json"))
reuse={"account-rust-fmt":"fixture-rust-fmt","account-native-tests":"fixture-native-tests","account-native-clippy":"fixture-native-clippy","account-default-tests":"fixture-default-tests","account-default-clippy":"fixture-default-clippy"}
for name,source in reuse.items():checks[name]={**load(fix/(source+".receipt.json")),"reusedFromRF1096":str(fix/(source+".receipt.json"))}
assert all(q["exitCode"]==0 for q in checks.values())
assert not (s/"required-checks.json").exists()
(s/"required-checks.json").write_text(json.dumps({"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"success":True,"checks":checks,"independentFixtureFix":{"commit":commit,"evidence":str(evidence),"sha256":sha(evidence),"sourceFiles":e["fixedSourceHashes"]},"sourceReuseVerified":True,"frontendChanged":False,"frontendChecksReferencedFromPriorAcceptedStage":True,"priorFailuresPreserved":["account-node-red","account-core-red","account-native-tests"],"originalBudgetsPreserved":True},indent=2)+"\n",encoding="utf-8",newline="\n")
print("Account-write required checks complete; identical-input RF-1096 Rust checks reused truthfully",flush=True)
