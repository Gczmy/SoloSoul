from verify_auth_freezes import verify_sources
import pathlib,json,hashlib,gzip,sys,datetime,subprocess
sys.stdout.reconfigure(encoding="utf-8")
s=pathlib.Path(__file__).parent;r=pathlib.Path(r"C:\Users\40299571\SoloSoul")
dest=r/"docs/performance/rf312-windows-account-write-attribution-2026-10-06"
load=lambda p:json.loads(p.read_text(encoding="utf-8-sig"));sha=lambda b:hashlib.sha256(b).hexdigest()
assert load(s/"release-build.receipt.json")["exitCode"]==0
checks=load(s/"required-checks.json");assert checks["success"] and all(q["exitCode"]==0 for q in checks["checks"].values())
build=load(s/"build-checkpoint.json");assert sha(pathlib.Path(build["exe"]).read_bytes())==build["sha256"]
verify_sources(s,r)
for group in ["account100","account5000"]:
 assert load(s/group/"native-perf-auth-attribution-results.json")["success"]
 assert load(s/(group+"-actual-auth-review.json"))["success"] and load(s/(group+"-post-cache-review.json"))["success"]
assert not dest.exists();(dest/"raw").mkdir(parents=True)
# 保存本次五个输入的基线和实际采样源码；依赖修复已独立提交，不混入本次代码。
original=load(s/"before-sources.json")["files"];frozen=load(s/"source-freeze.json")["files"]
for rel,expected in original.items():
 current=(r/rel).read_bytes();assert sha(current)==frozen[rel]
 prior=subprocess.check_output(["git","-c","safe.directory=C:/Users/40299571/SoloSoul","show","HEAD:"+rel],cwd=r)
 assert sha(prior)==expected,(rel,sha(prior),expected)
 for folder,data in [("current-sources",current),("baseline-sources",prior)]:
  p=s/folder/rel;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
files=[p for p in s.iterdir() if p.is_file() and p.suffix in [".py",".ps1",".json",".md",".log",".mjs",".js"]]
for group in ["account100","account5000"]:
 g=s/group;assert g.is_dir() and not g.is_symlink()
 report=load(g/"native-perf-sdk-journey-results.json");expected_json={"sample-%03d.json"%q["index"] for q in report["samples"]}
 files.extend(p for p in g.iterdir() if p.is_file() and p.suffix in [".json",".log"])
 for sample in sorted(g.glob("sample-*")):
  assert not sample.is_symlink()
  if sample.is_file():assert sample.name in expected_json;continue
  assert sample.is_dir()
  files.extend(p for p in sample.iterdir() if p.is_file() and p.suffix in [".json",".log",".png"])
  logs=sample/"preserved-app-logs"
  if logs.exists():files.extend(p for p in logs.rglob("*") if p.is_file())
for folder in ["current-sources","baseline-sources"]:files.extend(p for p in (s/folder).rglob("*") if p.is_file())
rows=[]
for p in sorted(set(files)):
 assert not p.is_symlink() and p.resolve().is_relative_to(s.resolve())
 body=p.read_bytes();rel=pathlib.PurePosixPath("raw")/pathlib.PurePosixPath(str(p.relative_to(s)).replace(chr(92),"/")+".gz")
 copy=dest/pathlib.Path(str(rel));assert not copy.exists();copy.parent.mkdir(parents=True,exist_ok=True)
 data=gzip.compress(body,compresslevel=9,mtime=0);copy.write_bytes(data);assert gzip.decompress(copy.read_bytes())==body
 rows.append({"original":str(p),"archive":str(rel),"bytes":len(body),"sha256":sha(body),"archiveBytes":len(data),"archiveSha256":sha(data)})
index={"schemaVersion":1,"task":"RF-312","scope":"windows-native-account-write-raw-synthetic-only","files":rows}
(dest/"index.json").write_text(json.dumps(index,ensure_ascii=False,indent=2)+chr(10),encoding="utf-8",newline=chr(10))
for q in rows:
 data=(dest/q["archive"]).read_bytes();body=gzip.decompress(data)
 assert len(data)==q["archiveBytes"] and sha(data)==q["archiveSha256"] and len(body)==q["bytes"] and sha(body)==q["sha256"]
receipt={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"success":True,"archives":len(rows),"originalBytes":sum(q["bytes"] for q in rows),"archiveBytes":sum(q["archiveBytes"] for q in rows),"excluded":["EXEs","model/DLL binaries","Vault physical files","cache trees"],"allDecompressedBytesVerified":True,"index":str(dest/"index.json")}
p=s/"raw-archive-review.json";assert not p.exists();p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+chr(10),encoding="utf-8",newline=chr(10));print(json.dumps(receipt,ensure_ascii=False),flush=True)
