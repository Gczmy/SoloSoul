import pathlib,subprocess,sys,json,datetime
s=pathlib.Path(__file__).parent
commands=[
 ('account-pdfium-pe',['node','../scripts/verify-windows-pdfium.mjs','src-tauri/resources/pdfium/pdfium.dll']),
 ('account-js-format',['node','node_modules/prettier/bin/prettier.cjs','--check','scripts/native-perf-auth-contract.mjs','scripts/native-perf-auth-attribution.test.mjs']),
 ('account-rust-fmt',['cargo','+1.99.0','fmt','--all','--','--check']),
 ('account-core-feature',['cargo','test','--locked','-p','solosoul-core','--features','native-perf','--lib','native_perf_unlock']),
 ('account-native-tests',['cargo','test','--locked','-p','solo_soul','--features','native-perf','--lib','native_perf']),
 ('account-native-clippy',['cargo','clippy','--locked','--workspace','--all-targets','--features','native-perf','--','-D','warnings']),
 ('account-default-tests',['cargo','test','--locked','--workspace','--verbose','--no-fail-fast']),
 ('account-default-clippy',['cargo','clippy','--locked','--workspace','--all-targets','--','-D','warnings']),
 ('account-cli-fmt',['cargo','+1.99.0','fmt','--manifest-path','../solosoul_cli/Cargo.toml','--','--check']),
 ('account-cli-clippy',['cargo','clippy','--locked','--manifest-path','../solosoul_cli/Cargo.toml','--all-targets','--','-D','warnings']),
 ('account-cli-tests',['cargo','test','--locked','--manifest-path','../solosoul_cli/Cargo.toml','--verbose','--no-fail-fast']),
]
for name,args in commands:
 rc=subprocess.call([sys.executable,'-X','utf8',str(s/'run-check.py'),name,*args])
 if rc:raise SystemExit(rc)
checks={name:json.loads((s/(name+'.receipt.json')).read_text(encoding='utf-8-sig')) for name,args in commands}
for name in ['account-node-target','account-node-full']:checks[name]=json.loads((s/(name+'.receipt.json')).read_text(encoding='utf-8-sig'))
assert all(q['exitCode']==0 for q in checks.values())
(s/'required-checks.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'checks':checks,'frontendChanged':False,'frontendChecksReferencedFromPriorAcceptedStage':True,'priorFailuresPreserved':['account-node-red','account-core-red'],'originalBudgetsPreserved':True},indent=2)+'\n',encoding='utf-8',newline='\n')
print('All required affected Rust, Node and CLI checks complete; prior unchanged frontend evidence remains applicable',flush=True)
