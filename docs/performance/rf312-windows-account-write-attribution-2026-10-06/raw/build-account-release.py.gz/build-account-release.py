import pathlib,json,hashlib,subprocess,time,datetime,shutil,sys,os
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(__file__).parent;old=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-auth-attribution-20261005')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(name,value):
 p=s/name;assert not p.exists(),str(p);p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
checks=load(s/'required-checks.json');assert checks['success'] and all(q['exitCode']==0 for q in checks['checks'].values())
assert load(s/'unaffected-default-and-frontend.json')['success']
prior=load(old/'measurement-source-freeze.json')['files'];files={p:sha(r/p) for p in prior}
fixture_fix=checks['independentFixtureFix'];assert sha(pathlib.Path(fixture_fix['evidence']))==fixture_fix['sha256']
assert all(sha(r/p)==h for p,h in fixture_fix['sourceFiles'].items())
assert subprocess.check_output(['git','-c','safe.directory=C:/Users/40299571/SoloSoul','rev-parse','HEAD'],cwd=r,text=True).strip()==fixture_fix['commit']
expected=set(load(s/'before-sources.json')['files'])|set(fixture_fix['sourceFiles'])
changed=sorted(p for p,h in prior.items() if files[p]!=h);assert changed==sorted(expected),changed
write('source-freeze.json',{'at':now(),'baseCommit':fixture_fix['commit'],'independentFixtureFix':fixture_fix,'files':files,'changedPriorAcceptedInputs':changed,'priorFreezeSha256':sha(old/'measurement-source-freeze.json')})
frontend=load(old/'frontend-freeze.json')['files'];assert all(sha(r/p)==h for p,h in frontend.items());write('frontend-freeze.json',{'at':now(),'files':frontend,'rebuilt':False,'priorEvidence':'RF-312-native-auth-attribution'})
public=load(old/'public-source-freeze.json')['files'];assert all(sha(pathlib.Path(p))==h for p,h in public.items());write('public-source-freeze.json',{'at':now(),'files':public})
bin=s/'bin';bin.mkdir(exist_ok=False);resources=[]
for v in load(old/'resource-freeze.json')['records']:
 source=pathlib.Path(v['copy']);assert sha(source)==v['sha256'];copy=bin/v['relativePath'];assert copy.resolve().is_relative_to(bin.resolve());copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,copy);assert sha(copy)==v['sha256'];resources.append({**v,'source':str(source),'copy':str(copy)})
write('resource-freeze.json',{'at':now(),'records':resources})
previous=dict(load(old/'previous-build-freeze.json')['files']);build=load(old/'build-checkpoint.json');previous[build['exe']]=build['sha256'];assert all(sha(pathlib.Path(p))==h for p,h in previous.items());write('previous-build-freeze.json',{'at':now(),'files':previous})
print(json.dumps({'sources':len(files),'changed':changed,'frontendUnchanged':len(frontend),'resources':len(resources),'publicInputs':len(public),'previousEXEs':len(previous)}),flush=True)
args=['cargo','build','--locked','--release','-p','solo_soul','--features','native-perf','--bin','solo_soul'];env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','');env.pop('PDFIUM_LIBRARY_PATH',None);started=time.time()
with (s/'release-build.stdout.log').open('xb') as out,(s/'release-build.stderr.log').open('xb') as err:
 p=subprocess.Popen(args,cwd=r/'tauri',env=env,stdout=out,stderr=err);write('release-build.live.json',{'command':args,'pid':p.pid,'at':now()});print('Started account-write Release PID '+str(p.pid),flush=True);rc=p.wait()
write('release-build.receipt.json',{'command':args,'pid':p.pid,'exitCode':rc,'elapsedSeconds':time.time()-started,'at':now()});print('Release exit '+str(rc),flush=True)
if rc:raise SystemExit(rc)
assert all(sha(r/p)==h for p,h in files.items()) and all(sha(r/p)==h for p,h in frontend.items())
assert all(sha(pathlib.Path(p))==h for p,h in public.items()) and all(sha(pathlib.Path(p))==h for p,h in previous.items())
assert all(sha(pathlib.Path(v['source']))==v['sha256']==sha(pathlib.Path(v['copy'])) for v in resources)
exe=bin/'solo_soul.exe';assert not exe.exists();shutil.copy2(r/'tauri/target/release/solo_soul.exe',exe);data=exe.read_bytes();markers=['windows-native-auth-attribution','account-manifest-serialize','account-directory-create','account-directory-permission','account-manifest-atomic-write','account-manifest-permission'];assert all(m.encode() in data for m in markers)
write('build-checkpoint.json',{'at':now(),'exe':str(exe),'bytes':len(data),'sha256':sha(exe),'sourceInputsUnchanged':len(files),'frontendFilesUnchanged':len(frontend),'resourcesUnchanged':len(resources),'publicFilesUnchanged':len(public),'previousBuildsPreserved':len(previous),'markers':markers});print('New frozen account-write Release verified',flush=True)
