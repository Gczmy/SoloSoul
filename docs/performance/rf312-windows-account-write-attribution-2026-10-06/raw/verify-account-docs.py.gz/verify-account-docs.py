from verify_auth_freezes import verify_sources
import pathlib,json,gzip,hashlib,re,sys,subprocess,datetime,urllib.parse
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul');d=r/'docs/performance';stem='rf312-windows-account-write-attribution-2026-10-06'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
proof=load(d/(stem+'.json'));index=load(d/stem/'index.json');assert proof['stageAccepted'] and not proof['taskClosed'] and proof['performanceMetrics'] is None
assert proof['oldHomeTimeoutReproduced'] is False and proof['oldHomeTimeoutRootCauseEstablished'] is False
assert proof['instrumentation']['backendDefaultFeatureEnabled'] is False and not proof['instrumentation']['frontBackendClocksSubtracted'] and not proof['instrumentation']['nestedDurationsAdded']
archives=set();original_bytes=0
for q in index['files']:
 assert q['archive'] not in archives;archives.add(q['archive']);p=d/stem/q['archive'];assert p.resolve().is_relative_to((d/stem).resolve())
 compressed=p.read_bytes();body=gzip.decompress(compressed)
 assert len(compressed)==q['archiveBytes'] and sha(compressed)==q['archiveSha256'] and len(body)==q['bytes'] and sha(body)==q['sha256'];original_bytes+=len(body)
 actual=pathlib.Path(q['original']);assert actual.is_file() and actual.read_bytes()==body
assert proof['rawArchive']['files']==len(index['files']) and len(proof['groups'])==2
assert sha((s/'source-freeze.json').read_bytes())==proof['sourceFreeze']['sha256'];verify_sources(s,r)
for p,h in proof['sourceFreeze']['thisStageFiles'].items():assert sha((r/p).read_bytes())==h
assert load(s/'unaffected-default-and-frontend.json')==proof['unaffectedDefaultAndFrontend']
assert load(s/'required-checks.json')==proof['checks']
assert sha(pathlib.Path(proof['frozenBuild']['exe']).read_bytes())==proof['frozenBuild']['sha256']
rows=[];total={key:0 for key in proof['preservationTotals']};whole=0
for group,count in zip(proof['groups'],[100,5000]):
 g='account'+str(count);review=load(s/(g+'-actual-auth-review.json'));post=load(s/(g+'-post-cache-review.json'))
 assert group['objectCount']==count and group['wholeSamplesAccepted']==3 and group['samples']==review['samples'] and group['summary']==review['summary'] and group['cleanup']==post
 assert review['success'] and post['success'];whole+=3
 for key in total:total[key]+=post[key]
 for sample in review['samples']:
  raw=load(s/g/('sample-%03d'%sample['index'])/'native-perf-auth-attribution.json')
  attempts=[a for a in raw['backend']['attempts'] if a['kind']=='login'];assert len(attempts)==2
  for flow,attempt in zip(sample['flows'],attempts):
   parent=next(q for q in attempt['stages'] if q['name']=='account-write-call');sub=flow['accountWriteSubsteps']
   assert abs(sub['parentDurationMs']-(parent['endedAtMs']-parent['startedAtMs']))<1e-8
   for q in sub['children']:
    original=next(v for v in attempt['stages'] if v['name']==q['name']);assert abs(q['durationMs']-(original['endedAtMs']-original['startedAtMs']))<1e-8
   permissions=sum(q['durationMs'] for q in sub['children'] if q['name'] in ['account-directory-permission','account-manifest-permission'])
   rows.append({'objectCount':count,'sampleIndex':sample['index'],'flowId':flow['flowId'],'parentMs':sub['parentDurationMs'],'permissionCallsMs':permissions,'permissionCallsRatio':permissions/sub['parentDurationMs'],'unattributedGapMs':sub['unattributedGapMs']})
 assert all(q['n']==3 and q['medianMs'] is not None and q['p95Ms']==max(q['samplesMs']) for q in review['summary'])
assert whole==6 and len(rows)==12 and rows==proof['attribution']['accountWriteAttempts'] and total==proof['preservationTotals']
assert proof['attribution']['permissionCallsFractionRange']==[min(q['permissionCallsRatio'] for q in rows),max(q['permissionCallsRatio'] for q in rows)]
assert not proof['attribution']['permissionSpawnRootCauseEstablished'] and not proof['attribution']['controlledOptimizationComparisonComplete']
report=(r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md').read_text(encoding='utf-8-sig')
block=report.split('## 4. 修复进度与执行索引',1)[1].split('## 5.',1)[0]
tasks=re.findall(r'^\|\s*\d+\s*\|\s*\[RF-(\d+)\].*$',block,re.M);assert len(tasks)==len(set(tasks))==286
lines=re.findall(r'^\|\s*\d+\s*\|\s*\[RF-\d+\].*$',block,re.M)
states={'closed':sum('[x]' in q for q in lines),'waiting':sum('[!]' in q for q in lines),'pending':sum('[ ]' in q for q in lines)}
assert states=={'closed':277,'waiting':3,'pending':6},states
for id in ['112','121','312']:assert '[!]' in next(q for q in lines if '[RF-'+id+']' in q)
for id in ['122','123','124','125','126','127']:assert '[ ]' in next(q for q in lines if '[RF-'+id+']' in q)
links=0
for p in [r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md',d/'RF-312-native-auth-attribution.md',d/'RF-312-windows-native-app-baseline.md',d/'RF-312-native-account-write-attribution.md']:
 for ref in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8-sig')):
  ref=ref.strip().strip('<>');path=urllib.parse.unquote(ref.split('#',1)[0])
  if not path or re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',path):continue
  assert (p.parent/path).exists(),(str(p),ref);links+=1
base=load(s/'git-preservation-before-account-stage.json')
def git(*args,cwd=r):return subprocess.check_output(['git','-c','safe.directory='+str(cwd).replace(chr(92),'/'),'-c','core.safecrlf=false',*args],cwd=cwd,text=True).strip()
assert git('rev-parse','HEAD')==base['head'] and git('stash','list','--format=%H')==base['stashes']
sub=r/'SoloSoul_plugin_market';assert git('rev-parse','HEAD',cwd=sub)==base['submoduleHead'] and not git('status','--short',cwd=sub)
subtree=git('ls-tree','HEAD','SoloSoul_plugin_market');assert subtree==base['submoduleTree']
subprocess.run(['git','-c','safe.directory=C:/Users/40299571/SoloSoul','-c','core.safecrlf=false','diff','--check'],cwd=r,check=True)
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'rawArchivesVerified':len(index['files']),'rawBytesVerified':original_bytes,'wholeNativeSamples':whole,'accountWriteAttemptsIndependentlyRecomputed':12,'states':states,'relativeLinksChecked':links,'taskStillOpen':True,'sixDependencyGatesRetained':True,'sourceFreezeVerified':True,'stashAndSubmodulePreserved':True,'diffCheckPassed':True}
proof['documentationVerification']=receipt;(d/(stem+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=s/'documentation-verification.json';assert not p.exists();p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(receipt,ensure_ascii=False),flush=True)
