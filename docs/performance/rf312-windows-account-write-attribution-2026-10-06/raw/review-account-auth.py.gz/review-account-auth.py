from verify_auth_freezes import verify_sources
import pathlib,json,hashlib,datetime,sys,math,statistics
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(name,value):
 p=s/name;assert not p.exists(),str(p)
 p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def finite(v):return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and v>=0
build=load(s/'build-checkpoint.json');assert sha(pathlib.Path(build['exe']))==build['sha256']
for group in sys.argv[1:]:
 assert group in ['account100','account5000'];root=s/group
 report=load(root/'native-perf-sdk-journey-results.json');diagnostics=load(root/'native-perf-auth-attribution-results.json')
 assert report['success'] and report['sourceUnchanged'] and report['samplesRequested']==3 and len(report['samples'])==3
 assert report['scope']=='windows-native-sdk-input-performance' and report['exeSha256']==build['sha256']
 names=['startup','password-unlock','workspace','search-needle','application-lock','password-reunlock']
 assert [p['name'] for p in report['summary']]==names and all(p['successfulSamples']==3 for p in report['summary'])
 assert diagnostics['success'] and diagnostics['diagnosticOnly'] and diagnostics['performanceMetrics'] is None and diagnostics['samplesRequested']==3 and len(diagnostics['samples'])==3
 identities={};cleanup_pids=set();samples=[];distributions={};vault_inventory=[]
 for sample,item in zip(report['samples'],diagnostics['samples']):
  index=sample['index'];assert index==item['index']
  sample_root=pathlib.Path(sample['root']);assert sample_root==root/('sample-%03d'%index)
  assert sample['success'] and sample['cleanupIntegrity']['complete'] and item['success'] and item['journeySuccess']
  proof=load(sample_root/'native-perf-sdk-journey.json');assert proof==sample['nativeProof'] and proof['success'] and proof['scope']=='windows-native-sdk-ui-journey'
  assert [p['name'] for p in sample['phases']]==names and sample['phases']==proof['phases'] and all(p['success'] and p['inputTrust']['untrusted']==0 for p in proof['phases'])
  assert len(proof['calls'])<=128 and proof['lastProbe']['observer']['valid']
  raw=load(sample_root/'native-perf-auth-attribution.json');front=raw['frontend'];back=raw['backend'];derived=item['diagnostic']
  assert raw['runId']==proof['runId']==sample['owned']['runId']==sample['bound']['runId']
  assert raw['pid']==proof['pid']==sample['bound']['pid'] and raw['timeOriginMs']==proof['timeOriginMs']==sample['bound']['timeOriginMs']
  assert raw['binding']['mainFrameId']==proof['binding']['mainFrameId'] and raw['binding']['loaderId']==proof['binding']['loaderId']
  assert raw['binding']['source']=='http://tauri.localhost/' and raw['binding']['navigationEvents']==0 and raw['binding']['frameCreatedEvents']==0
  assert front['valid'] and back['valid'] and not front['invalidReasons'] and not back['invalidReasons']
  prior=proof['lastProbe']['observer'];assert prior['total']==proof['ipcAll']['attempts'] and front['invokeCount']>=prior['total']
  # 认证快照稍晚于最终 UI probe；只对仍在该 probe 前缀内的请求核对完整 IPC 序列。
  for reply in front['replies']:
   if reply['invokeSeq']<=len(prior['commands']):
    event=prior['commands'][reply['invokeSeq']-1];assert event['command']==reply['command'] and reply['startedAtMs']<=event['atMs']
  assert len(front['flows'])==2 and len(derived['frontend']['flows'])==2
  assert len([a for a in back['attempts'] if a['kind']=='login'])==2
  used=set();flow_rows=[]
  for flow,derived_flow in zip(front['flows'],derived['frontend']['flows']):
   events=flow['events'];sequence=[e['stage'] for e in events]
   assert sequence[:4]==['started','login-await-start','login-await-ok','accounts-await-start'] and sequence[4] in ['accounts-await-ok','accounts-await-error'] and sequence[5:]==['state-set-start','state-set-done','finished']
   assert all(finite(e['atMs']) and e['atMs']<=front['atMs'] for e in events)
   stages={e['stage']:e['atMs'] for e in events};row={'flowId':flow['id']}
   assert derived_flow['outcome']=='finished'
   for prefix,command in [('login','login'),('accounts','vault_list_accounts')]:
    start=stages[prefix+'-await-start'];end=next(v for k,v in stages.items() if k in [prefix+'-await-ok',prefix+'-await-error'])
    candidates=[q for q in front['replies'] if q['command']==command and start<=q['startedAtMs']<=end]
    assert len(candidates)==1;reply=candidates[0];assert reply['invokeSeq'] not in used;used.add(reply['invokeSeq'])
    assert reply['status'] in ['tauri-ok','tauri-error','transport-error','sync-throw'] and start<=reply['startedAtMs']<=reply['headersAtMs']<=end
    if prefix+'-await-ok' in stages:assert reply['status']=='tauri-ok'
    values={'headersDelayMs':reply['headersAtMs']-reply['startedAtMs'],'promiseWaitMs':end-start,'afterHeadersToAwaitMs':end-reply['headersAtMs']}
    actual=next(q for q in derived_flow['awaits'] if q['command']==command)
    assert actual['invokeSeq']==reply['invokeSeq'] and all(abs(actual[k]-v)<1e-8 for k,v in values.items())
    row[prefix]=dict(values,invokeSeq=reply['invokeSeq'])
   state=stages['state-set-done']-stages['state-set-start'];assert abs(state-derived_flow['stateWriteMs'])<1e-8;row['stateWriteMs']=state
   flow_rows.append(row)
  for attempt,actual in zip(back['attempts'],derived['backend']['attempts']):
   assert actual['id']==attempt['id'] and actual['outcome']==attempt['outcome'] and attempt['rootVerified']
   expected=None if attempt['endedAtMs'] is None else attempt['endedAtMs']-attempt['startedAtMs']
   assert actual['durationMs'] is None if expected is None else abs(actual['durationMs']-expected)<1e-8
   for stage,value in zip(attempt['stages'],actual['stages']):
    expected=None if stage['endedAtMs'] is None else stage['endedAtMs']-stage['startedAtMs']
    assert stage['outcome']==value['outcome']
    assert value['durationMs'] is None if expected is None else abs(value['durationMs']-expected)<1e-8
  logins=[a for a in derived['backend']['attempts'] if a['kind']=='login'];login_pair=next(p for p in derived['serialCommandPairing'] if p['command']=='login')
  assert login_pair['paired'] and len(login_pair['pairs'])==2
  for row,attempt,pair in zip(flow_rows,logins,login_pair['pairs']):
   assert row['login']['invokeSeq']==pair['invokeSeq'] and attempt['id']==pair['attemptId'] and attempt['outcome']=='completed'
   assert len([st for st in attempt['stages'] if st['name']=='kdf'])==1
   raw_attempt=next(a for a in back['attempts'] if a['id']==attempt['id'])
   parent=[q for q in raw_attempt['stages'] if q['name']=='account-write-call'];assert len(parent)==1;parent=parent[0]
   required=['account-manifest-serialize','account-directory-create','account-directory-permission','account-manifest-atomic-write','account-manifest-permission']
   children=[q for q in raw_attempt['stages'] if q['name'] in required]
   assert [q['name'] for q in children]==required and parent['outcome']=='completed'
   previous=parent['startedAtMs'];child_total=0;substeps=[]
   for child in children:
    assert child['outcome']=='completed' and previous<=child['startedAtMs']<=child['endedAtMs']<=parent['endedAtMs']
    duration=child['endedAtMs']-child['startedAtMs'];child_total+=duration;previous=child['endedAtMs']
    value=next(q for q in attempt['stages'] if q['name']==child['name']);assert abs(value['durationMs']-duration)<1e-8
    substeps.append({'name':child['name'],'durationMs':duration})
   parent_duration=parent['endedAtMs']-parent['startedAtMs'];gap=parent_duration-child_total;assert gap>=-1e-8
   row['accountWriteSubsteps']={'parentDurationMs':parent_duration,'children':substeps,'sumOfDisjointChildrenMs':child_total,'unattributedGapMs':max(0,gap),'sameBackendClock':True,'nestedStageDurationsAdded':False}
   row['backendAttemptMs']=attempt['durationMs'];row['backendStages']=[{'name':st['name'],'durationMs':st['durationMs']} for st in attempt['stages']]
   for name,value in [('login-await',row['login']['promiseWaitMs']),('login-after-headers',row['login']['afterHeadersToAwaitMs']),('accounts-await',row['accounts']['promiseWaitMs']),('state-write',row['stateWriteMs']),('backend-attempt',row['backendAttemptMs']),*[(st['name'],st['durationMs']) for st in row['backendStages']]]:
    distributions.setdefault('flow'+str(row['flowId'])+':'+name,[]).append(value)
  for name in ['beforeSnapshot','afterSnapshot']:
   for process in (sample.get(name) or {}).get('processes',[]):
    value={key:process[key] for key in ['pid','creationMs','executableName']};key=(value['pid'],value['creationMs']);assert finite(value['creationMs']) and value['creationMs']>0 and value['executableName']
    assert key not in identities or identities[key]==value;identities[key]=value
  for process in sample['cleanup']['cleanup']:cleanup_pids.add(process['pid'])
  vault=sample_root/'vault';files=[]
  for p in sorted(vault.rglob('*')):
   assert not p.is_symlink()
   if p.is_file():
    assert p.resolve().is_relative_to(vault.resolve());files.append({'relativePath':str(p.relative_to(vault)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)})
  artifacts=[{'relativePath':q.name,'bytes':q.stat().st_size,'sha256':sha(q)} for q in sorted(sample_root.iterdir()) if q.is_file() and not q.is_symlink()]
  vault_inventory.append({'root':str(sample_root),'files':files,'topLevelArtifacts':artifacts})
  samples.append({'index':index,'runId':raw['runId'],'pid':raw['pid'],'sdkCalls':len(proof['calls']),'finalUiProbeInvokeCount':prior['total'],'authSnapshotInvokeCount':front['invokeCount'],'flows':flow_rows,'accountsBackendPairing':next(p for p in derived['serialCommandPairing'] if p['command']=='vault_list_accounts')})
 verify_sources(s,r)
 for name in ['frontend-freeze.json']:
  records=load(s/name)['files'];assert all(sha(r/p)==h for p,h in records.items()),name
 for name in ['public-source-freeze.json','previous-build-freeze.json']:
  records=load(s/name)['files'];assert all(sha(pathlib.Path(p))==h for p,h in records.items()),name
 for v in load(s/'resource-freeze.json')['records']:assert sha(pathlib.Path(v['source']))==v['sha256']==sha(pathlib.Path(v['copy']))
 summary=[{'name':k,'n':len(v),'medianMs':statistics.median(v),'p95Ms':sorted(v)[math.ceil(.95*len(v))-1],'samplesMs':v} for k,v in distributions.items()];assert all(q['n']==3 for q in summary)
 write(group+'-identity-scope.json',{'at':now(),'exe':build['exe'],'identities':list(identities.values()),'additionalCleanupPids':sorted(cleanup_pids-set(pid for pid,birth in identities))})
 write(group+'-pre-cache-vault-freeze.json',{'at':now(),'roots':vault_inventory,'groupFiles':[{'path':str(root/name),'sha256':sha(root/name)} for name in ['native-perf-sdk-journey-results.json','native-perf-auth-attribution-results.json']]})
 write(group+'-actual-auth-review.json',{'at':now(),'success':True,'diagnosticOnly':True,'performanceMetrics':None,'samples':samples,'summary':summary,'nestedStageDurationsAdded':False,'frontBackendClocksSubtracted':False,'wholeSamples':3,'oldTimeoutRootCauseEstablished':False})
 print(group+': verified complete six-phase group and independent fixed-clock arithmetic; '+str(len(identities))+' recorded identities',flush=True)
