from verify_auth_freezes import verify_sources
import pathlib,json,hashlib,sys,re
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul');d=r/'docs/performance';stem='rf312-windows-account-write-attribution-2026-10-06'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=load(s/'required-checks.json');build=load(s/'build-checkpoint.json');index=load(d/stem/'index.json')
assert checks['success'] and all(q['exitCode']==0 for q in checks['checks'].values())
assert load(s/'release-build.receipt.json')['exitCode']==0 and sha(pathlib.Path(build['exe']))==build['sha256'];verify_sources(s,r)
assert load(s/'raw-archive-review.json')['success']
for name in ['account-node-red.stdout.log','account-core-red.stdout.log','account-native-tests.stdout.log','cleanup-helper-authoring-failure.json','required-checks.json','source-freeze.json']:
 assert 'raw/'+name+'.gz' in {q['archive'] for q in index['files']},name

def rust_count(label):
 q=checks['checks'][label]
 p=pathlib.Path(q['reusedFromRF1096']).with_name(pathlib.Path(q['reusedFromRF1096']).name.replace('.receipt.json','.stdout.log')) if q.get('reusedFromRF1096') else s/(label+'.stdout.log')
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',p.read_text(encoding='utf-8-sig'));assert rows,(label,p)
 return dict(zip(['passed','failed','ignored'],[sum(int(q[i]) for q in rows) for i in range(3)]))
counts={label:rust_count(label) for label in ['account-default-tests','account-native-tests','account-cli-tests','account-core-feature']}
for label,expected in [('account-default-tests',(1861,0,3)),('account-native-tests',(100,0,0)),('account-cli-tests',(336,0,2)),('account-core-feature',(2,0,0))]:assert tuple(counts[label].values())==expected,(label,counts[label])
node=(s/'account-node-full.stdout.log').read_text(encoding='utf-8-sig');assert re.search(r'pass 215\b',node) and re.search(r'fail 0\b',node) and re.search(r'skipped 1\b',node)
counts['node']={'passed':215,'failed':0,'skipped':1}
groups=[];tables=[];rows=[];ambiguous=0;callcounts=[]
for count in [100,5000]:
 g='account'+str(count);actual=load(s/(g+'-actual-auth-review.json'));post=load(s/(g+'-post-cache-review.json'));report=load(s/g/'native-perf-sdk-journey-results.json')
 assert actual['success'] and post['success'] and report['success'] and len(actual['samples'])==3
 assert not actual['oldTimeoutRootCauseEstablished'] and not actual['nestedStageDurationsAdded'] and not actual['frontBackendClocksSubtracted']
 ambiguous+=sum(not q['accountsBackendPairing']['paired'] for q in actual['samples']);callcounts += [q['sdkCalls'] for q in actual['samples']]
 for sample in actual['samples']:
  for flow in sample['flows']:
   sub=flow['accountWriteSubsteps'];children=sub['children'];assert len(children)==5
   permissions=sum(q['durationMs'] for q in children if q['name'] in ['account-directory-permission','account-manifest-permission']);assert sub['parentDurationMs']>0
   rows.append({'objectCount':count,'sampleIndex':sample['index'],'flowId':flow['flowId'],'parentMs':sub['parentDurationMs'],'permissionCallsMs':permissions,'permissionCallsRatio':permissions/sub['parentDurationMs'],'unattributedGapMs':sub['unattributedGapMs']})
 groups.append({'objectCount':count,'samplesRequested':3,'wholeSamplesAccepted':3,'diagnosticOnly':True,'performanceMetrics':None,'samples':actual['samples'],'summary':actual['summary'],'cleanup':post})
 tables.append({q['name']:q for q in actual['summary']})
assert len(rows)==12 and len(callcounts)==6
permission_range=[min(q['permissionCallsRatio'] for q in rows),max(q['permissionCallsRatio'] for q in rows)]
preservation={key:sum(g['cleanup'][key] for g in groups) for key in ['vaultFilesUnchanged','topLevelArtifactsUnchanged','preservedLogs','recordedIdentitiesChecked','removedPrivateCachePaths','unlinkedPrivateCacheEntries']}
current=load(s/'source-freeze.json');original=load(s/'before-sources.json')['files'];unaffected=load(s/'unaffected-default-and-frontend.json')
result={'schemaVersion':1,'task':'RF-312','scope':'windows-native-account-write-attribution-acceptance','date':'2026-10-06','stageAccepted':True,'taskClosed':False,'diagnosticOnly':True,'performanceMetrics':None,'oldHomeTimeoutReproduced':False,'oldHomeTimeoutRootCauseEstablished':False,'instrumentation':{'fixedStageTokens':['account-manifest-serialize','account-directory-create','account-directory-permission','account-manifest-atomic-write','account-manifest-permission'],'backendDefaultFeatureEnabled':False,'defaultAccountSaveTokensUnchanged':True,'defaultPermissionArgumentsOrFlagsChanged':False,'frontendChangedFromPriorAcceptedStage':False,'requestResponseBodyOrPrivatePathRecorded':False,'frontBackendClocksSubtracted':False,'nestedDurationsAdded':False,'onlyDisjointSiblingsSummed':True,'concurrentAccountsSamplesUnpaired':ambiguous,'completedMeans':'call returned; ACL command status and filesystem durability not independently established'},'frozenBuild':build,'sourceFreeze':{'file':stem+'/raw/source-freeze.json.gz','sha256':sha(s/'source-freeze.json'),'baseCommit':current['baseCommit'],'inputs':len(current['files']),'changedPriorAcceptedInputs':current['changedPriorAcceptedInputs'],'thisStageFiles':{p:current['files'][p] for p in original}},'unaffectedDefaultAndFrontend':unaffected,'checks':checks,'testCounts':counts,'frontendChecksReusedFrom':{'evidence':'rf312-windows-auth-attribution-2026-10-06.json','sha256':sha(d/'rf312-windows-auth-attribution-2026-10-06.json'),'sourceInputsUnchanged':884,'distInputsUnchanged':35,'rerunClaimed':False},'groups':groups,'attribution':{'accountWriteAttempts':rows,'permissionCallsFractionRange':permission_range,'permissionSpawnRootCauseEstablished':False,'controlledOptimizationComparisonComplete':False},'preservationTotals':preservation,'failuresPreserved':{'nodeContractRed':load(s/'account-node-red.receipt.json'),'coreMissingSubstepsRed':load(s/'account-core-red.receipt.json'),'originalNativeMediaFailure':load(s/'account-native-tests.receipt.json'),'independentFixtureFix':checks['independentFixtureFix'],'cleanupHelperAuthoringFailure':load(s/'cleanup-helper-authoring-failure.json'),'documentHelperAuthoringFailure':load(s/'document-helper-authoring-failure.json')},'rawArchive':{'index':stem+'/index.json','files':len(index['files']),'allDecompressedBytesVerified':True},'remaining':['controlled evidence before any permission-command optimization','old intermittent home timeout','system sleep coverage','same-scope multiplatform distributions','RF-112 isolated macOS restoration','RF-121 full native material matrix','RF-122 to RF-127 dependencies'],'localCommitOnly':True,'pushed':False}

def save(p,text):
 assert not p.exists(),str(p);p.write_text(text,encoding='utf-8',newline='\n')
save(d/(stem+'.json'),json.dumps(result,ensure_ascii=False,indent=2)+'\n')
text=f'''# RF-312 Windows 账户清单写入阶段归因

本阶段只扩展非默认 `native-perf` 的五个固定子阶段，保持账户清单读锁、序列化、原子写、权限参数、错误传播和调用顺序。默认保存函数去除观测代码后的 token 摘要与基线一致；884 项 React 源码和 35 份 dist 保持，本阶段不声称重新运行前端检查。

100/5000 对象各三个 fresh root/profile 完整执行启动、主密码登录、工作区、搜索、应用锁定和再次解锁。每个样本两条 finished 认证流、两次 completed 后端登录均已独立复核。五个子阶段必须按序、互不重叠且位于唯一账户写入父阶段内部，原预算、真实输入和进程身份检查保持。

前端与后端时钟不相减，父子时长不相加；仅对同一后端时钟的五个互不重叠子阶段求和并保留间隙。completed 表示原调用返回，不独立证明权限命令退出状态或文件系统持久性。记录不包含主密码、请求响应正文、账户名称或自选路径。并发账户列表不强行配对，同步状态写入不表示 React 绘制完成。

本阶段 `diagnosticOnly=true`、`performanceMetrics=null`，用于归因，不能替代无观测器性能基线。两次权限调用的合计占账户写入父阶段 {100*permission_range[0]:.2f}%～{100*permission_range[1]:.2f}%；这尚未证明控制台创建成本或旧首页超时根因，产品优化需要独立受控对照。

## 实际分布

以下单位 ms，每格 n=3，P95 为这三次最大观测值，包含观测成本。首次登录与再次解锁分开。

| 阶段 | 100 首次登录 | 5000 首次登录 | 100 再次解锁 | 5000 再次解锁 |
| --- | ---: | ---: | ---: | ---: |
'''
for key,label in [('login-await','前端 login await'),('backend-attempt','后端 login 调用'),('account-write-call','账户清单写入父阶段'),('account-manifest-serialize','序列化'),('account-directory-create','创建目录'),('account-directory-permission','目录权限调用'),('account-manifest-atomic-write','清单原子写入'),('account-manifest-permission','清单权限调用'),('kdf','KDF')]:
 values=[]
 for flow in [1,2]:
  for table in tables:
   q=table['flow'+str(flow)+':'+key];values.append(f"{q['medianMs']:.2f} / {q['p95Ms']:.2f}")
 text+='| '+label+' | '+' | '.join(values)+' |\n'
text+=f'''
## 构建、检查与保全

冻结 Release SHA-256 `{build['sha256']}`，{build['bytes']} 字节；1314 项源码/配置、35 项前端 dist、94 份资源、185 份公开源和 11 个旧 EXE 保持。RF-1096 的夹具 KDF 修复已独立提交 `1f5aca64`，本阶段复用的 R 检查明确绑定该提交及相同源码，不重复冒充新运行。

最终默认 Rust 1861 passed / 3 既有 ignored；非默认原生 100 passed；Core 观察器 2 passed；CLI 336 passed / 2 既有 ignored；Node 215 passed / 1 既有权限 skip。严格 Clippy、Rust/JS 格式和清理脚本语法检查通过。首次原生媒体 94 passed / 5 failed 的退出码及日志保留，独立夹具修复后整组通过；Node/Core 红测、清理脚本路径错误和文档辅助脚本首次语法错误也保留，后两者均未执行产品或缓存修改。

fresh CIM 核验 {preservation['recordedIdentitiesChecked']} 条退出记录，仅清理 {preservation['removedPrivateCachePaths']} 个核验缓存目录、解除 {preservation['unlinkedPrivateCacheEntries']} 个私有链接；保留 {preservation['preservedLogs']} 份日志和 {preservation['vaultFilesUnchanged']} 个完整 Vault 文件。缓存工具未终止进程，清理前后所有证明、报告、源码、公开输入、资源和旧构建保持。

## 复跑与未完成范围

先按[合成 Vault 合同](RF-312-native-vault-baseline.md)准备生产 KDF 64MiB/3 iter/4 parallelism 数据。构建 `cargo build --locked --release -p solo_soul --features native-perf --bin solo_soul` 并冻结源码、dist、资源和 EXE。GUI 子进程不能继承 `PDFIUM_LIBRARY_PATH` 覆盖；输出使用全新目录，采样期间避免并发重型构建。

```powershell
node scripts/native-perf-auth-attribution.mjs --exe C:\\rf312\\bin\\solo_soul.exe --fixture C:\\rf312\\vault100 --output C:\\rf312\\new-account100 --samples 3
node scripts/native-perf-auth-attribution.mjs --exe C:\\rf312\\bin\\solo_soul.exe --fixture C:\\rf312\\vault5000 --output C:\\rf312\\new-account5000 --samples 3
```

[结构化验收]({stem}.json)与[{len(index['files'])} 份逐字节原件]({stem}/index.json)保存检查、所有失败与成功、冻结、独立复核及清理。原件不包括 EXE/模型/DLL、Vault 物理文件和缓存树。

RF-312 仍 `[!]`：旧首页超时、睡眠恢复及多端同口径验收尚未完成。下一步基于该归因进行受控优化验证，再补 Windows RF-121 完整窗口合成；RF-112/121 及 RF-122～127 前置保持未完成。按本阶段独立本地提交，不推送。
'''
save(d/'RF-312-native-account-write-attribution.md',text)
main=r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';old=main.read_text(encoding='utf-8-sig');assert '已关闭：**277 / 286**' in old
lines=old.splitlines();assert lines[2].startswith('> 最后更新：');lines[2]='> 最后更新：2026-10-06（RF-312账户写入归因两档已验；首页超时/多端继续）'
positions=[i for i,q in enumerate(lines) if q.startswith('- 当前处理：')];assert len(positions)==1
lines[positions[0]]='- 当前处理：**RF-312：账户写入五个子阶段100/5000各三次完整行程已验；下一步依据归因进行受控优化验证与RF-121完整窗口合成。旧首页超时、睡眠、多端及材质前置保持未完成**。'
text='\n'.join(lines)+'\n';tag='[!] Windows认证观测已验；首页超时/多端待验';assert text.count(tag)==1;text=text.replace(tag,'[!] Windows账户写入归因已验；首页超时/多端待验')
text+=f'''
### RF-312 Windows 账户清单写入五阶段原生归因验收（2026-10-06）

- 仅非默认 native-perf 增加序列化、目录创建、目录权限、原子写和文件权限固定 token；读锁/调用顺序/错误传播/权限参数保持。默认保存函数去除观测语句后 token SHA 与基线一致，884 前端源和 35 dist 保持。
- 冻结 Release `{build['sha256']}`；1314 源码/配置、94 资源、185 公开源和 11 旧 EXE 保持。100/5000 各三个完整六阶段样本，两条 finished 前端流及 completed 后端登录逐样本独立复核；五个子阶段有序、互不重叠且位于父阶段内，嵌套/跨时钟不相加。
- 两次权限调用占账户写入父阶段 {100*permission_range[0]:.2f}%～{100*permission_range[1]:.2f}%；当前只确认调用耗时，未证明控制台创建成本、具体优化效果或旧首页超时根因。diagnosticOnly=true、performanceMetrics=null。
- 默认 Rust 1861/非默认 100/Core 2/CLI 336/Node 215 全部通过；既有 ignored/skip 保持，严格 Clippy/格式通过。RF-1096 独立修复并提交后复用同源码 R 检查，前端引用此前检查而不冒充重跑；原 94/5 媒体失败、Node/Core 红测和辅助脚本编写错误保留。
- fresh CIM 核验 {preservation['recordedIdentitiesChecked']} 条退出记录，只清理 {preservation['removedPrivateCachePaths']} 个 owned 缓存和 {preservation['unlinkedPrivateCacheEntries']} 个链接；{preservation['vaultFilesUnchanged']} 个 Vault 文件、{preservation['preservedLogs']} 份日志、全部证明和冻结输入保持，缓存工具未终止进程。
- [口径与复跑](performance/RF-312-native-account-write-attribution.md)、[结构化验收](performance/{stem}.json)和[{len(index['files'])} 份原件](performance/{stem}/index.json)归档。按本阶段独立本地提交，不推送；277/286、3 待验证、6 待执行不变。RF-312 仍 [!]，下一本地项为受控优化验证及 Windows RF-121 完整窗口合成；首页超时/睡眠/多端及 RF-112/121/122～127 前置保持，goal active。
'''
main.write_text(text,encoding='utf-8',newline='\n')
for name in ['RF-312-native-auth-attribution.md','RF-312-windows-native-app-baseline.md']:
 p=d/name;text=p.read_text(encoding='utf-8-sig');text+='\n\n## 2026-10-06 · 账户清单写入内部归因补证\n\n五个固定子阶段的两档完整样本、独立时钟复算及失败/检查/保全原件已归档，见[当前归因记录](RF-312-native-account-write-attribution.md)。该记录补充本阶段，不覆盖旧失败或替代无观测器基线；首页超时根因、受控优化效果、睡眠、多端与材质前置仍未关闭。\n';p.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps({'acceptedGroups':2,'wholeSamples':6,'permissionFractionRange':permission_range,'preservation':preservation,'rawArchives':len(index['files']),'taskStillOpen':True},ensure_ascii=False),flush=True)
