run('probe-aligned-badging',[str(sdk/'build-tools/35.0.0/aapt2.exe'),'dump','badging',str(copy)])
run('probe-aligned-signature',[str(jdk/'bin/java.exe'),'-jar',str(sdk/'build-tools/35.0.0/lib/apksigner.jar'),
    'verify','--verbose','--print-certs',str(copy)])
cert=re.findall(r'certificate SHA-256 digest: (\S+)',(S/'probe-aligned-signature.stdout.log').read_text(encoding='utf-8'))
assert cert==[inputs['release']['certificateSha256']]
def dex_classes(data):
    assert data[:4]==b'dex\n'
    u32=lambda off:struct.unpack_from('<I',data,off)[0]
    strings_offset=u32(60);types_offset=u32(68);count=u32(96);offset=u32(100)
    classes=[]
    for i in range(count):
        type_index=u32(offset+32*i);string_index=u32(types_offset+4*type_index)
        start=u32(strings_offset+4*string_index)
        while data[start]&0x80:start+=1
        start+=1;end=data.index(b'\0',start);classes.append(data[start:end].decode('ascii'))
    return classes
classes=[]
with zipfile.ZipFile(copy) as z:
    assert not any(n.startswith('lib/') for n in z.namelist())
    for name in z.namelist():
        if re.fullmatch(r'classes\d*\.dex',name):classes+=dex_classes(z.read(name))
assert 'Landroidx/tracing/Trace;' in classes
assert 'Lcom/solosoul/app/AndroidHomeInstrumentedTest;' in classes
assert 'Lcom/solosoul/app/MainActivity;' not in classes
assert not any(c.startswith('Lapp/tauri/') for c in classes)
save(S/'dex-defined-classes.json',classes)
save(S/'current-test-apk.json',{'acceptedPackagePreparation':True,'path':str(copy),'sha256':sha(copy),
    'bytes':copy.stat().st_size,'certificateSha256':cert[0],'package':'com.solosoul.app.releaseprobe',
    'targetPackage':'com.solosoul.app','testClassDefined':True,'traceRuntimeDefined':True,
    'targetMainActivityAndTauriClassesNotPackaged':True,'nativeLibrariesNotPackaged':True,
    'homeTestSourceSha256':sha(src),'mainReleaseBytesUnchanged':True,
    'nativeRuntimeAccepted':False,'fullRF312Accepted':False,
    'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print('Independent signed test APK prepared, with original test source and complete runner dependencies',flush=True)
