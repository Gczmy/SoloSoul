from pathlib import Path
import datetime,hashlib,json,os,re,shutil,struct,subprocess,time,zipfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;N=B/'rf312-android-release-native-20261012'
S=B/'rf312-release-probe-build-20261012';S.mkdir(exist_ok=False)
P=S/'project';P.mkdir();(P/'src/main/java/com/solosoul/app').mkdir(parents=True)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
inputs=load(N/'inputs.json')
def frozen():
    assert all(sha(R/n)==h for n,h in inputs['runtimeSourceFiles'].items())
    for row in [inputs['release']['apk'],inputs['originalDebug'],inputs['originalTest']]:
        assert sha(Path(row.get('path',row.get('copy'))))==row['sha256']
frozen()
old=load(B/'rf1126-legacy-theme-build-20261011/current-apks.json')
main='tauri/src-tauri/gen/android/app/src/main/java/com/solosoul/app/MainActivity.kt'
assert old['sourceFiles'][main]==inputs['runtimeSourceFiles'][main]==sha(R/main)
src=R/'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidHomeInstrumentedTest.kt'
target=P/'src/main/java/com/solosoul/app'/src.name;shutil.copyfile(src,target)
assert sha(src)==sha(target)
G=R/'tauri/src-tauri/gen/android'
compiled=G/'app/build/tmp/kotlin-classes/x86_64Debug'
assert (compiled/'com/solosoul/app/MainActivity.class').is_file()
class_inventory={}
with zipfile.ZipFile(P/'original-main-compile-only.jar','x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(compiled.rglob('*')):
        if p.is_file() and p.suffix in ('.class','.kotlin_module'):
            data=p.read_bytes();name=p.relative_to(compiled).as_posix();z.writestr(name,data)
            class_inventory[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
tauri=B/'cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f/tauri-2.11.2/mobile/android/build/intermediates/compile_library_classes_jar/debug/bundleLibCompileToJarDebug/classes.jar'
assert tauri.is_file();shutil.copyfile(tauri,P/'original-tauri-compile-only.jar')
assert sha(tauri)==sha(P/'original-tauri-compile-only.jar')
save(S/'input-proof.json',{'sourceFiles':inputs['runtimeSourceFiles'],'releaseApk':inputs['release']['apk'],
    'homeTestSourceSha256':sha(src),'homeTestSourceUnchanged':True,
    'mainActivitySourceSameAsOriginalDebugAndCurrentRelease':True,'compileOnlyMainClasses':class_inventory,
    'compileOnlyMainJarSha256':sha(P/'original-main-compile-only.jar'),
    'compileOnlyTauriJarSource':str(tauri),'compileOnlyTauriJarSha256':sha(tauri),
    'productionSourcesChanged':False,'mainApkRebuilt':False,'testPackage':'com.solosoul.app.releaseprobe'})
(P/'settings.gradle.kts').write_text('rootProject.name = "SoloSoulReleaseNativeProbe"\n',encoding='utf-8')
(P/'build.gradle.kts').write_text('''buildscript {
    repositories { google(); mavenCentral() }
    dependencies {
        classpath("com.android.tools.build:gradle:8.11.0")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.25")
    }
}
apply(plugin = "com.android.application")
apply(plugin = "org.jetbrains.kotlin.android")
repositories { google(); mavenCentral() }
configure<com.android.build.gradle.AppExtension> {
    namespace = "com.solosoul.app.releaseprobe"
    compileSdkVersion(36)
    buildToolsVersion = "35.0.0"
    defaultConfig {
        applicationId = "com.solosoul.app.releaseprobe"
        minSdk = 28
        targetSdk = 36
        versionCode = 1
        versionName = "RF312-internal"
    }
    signingConfigs.getByName("debug") {
        storeFile = file("'''+(B/'android-user/debug.keystore').as_posix()+'''")
        storePassword = "android"
        keyAlias = "androiddebugkey"
        keyPassword = "android"
    }
    buildTypes.getByName("debug") {
        isDebuggable = true
        isMinifyEnabled = false
        signingConfig = signingConfigs.getByName("debug")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}
tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    kotlinOptions.jvmTarget = "1.8"
}
dependencies {
    // Actual existing app class headers are used only for compilation.
    // No target app classes or Rust library are packaged in this probe.
    add("compileOnly", files("original-main-compile-only.jar", "original-tauri-compile-only.jar"))
    add("compileOnly", "androidx.appcompat:appcompat:1.7.1")
    add("implementation", "androidx.core:core-ktx:1.16.0")
    add("implementation", "androidx.test.ext:junit:1.1.4")
    add("implementation", "androidx.test.espresso:espresso-core:3.5.0")
    add("implementation", "androidx.tracing:tracing:1.0.0")
}
''',encoding='utf-8',newline='\n')
(P/'src/main/AndroidManifest.xml').write_text('''<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.REORDER_TASKS" />
    <application android:label="SoloSoul internal Release probe" android:allowBackup="false" />
    <instrumentation android:name="androidx.test.runner.AndroidJUnitRunner"
        android:targetPackage="com.solosoul.app" android:functionalTest="true" />
</manifest>
''',encoding='utf-8')
jdk=Path('C:/Users/40299571/ss-android/jdk');sdk=B/'sdk'
env=os.environ.copy();env.update(JAVA_HOME=str(jdk),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),
    ANDROID_USER_HOME=str(B/'android-user'),GRADLE_USER_HOME=str(B/'gradle-home'),
    TEMP=str(B/'tmp'),TMP=str(B/'tmp'),JAVA_TOOL_OPTIONS=f'-Duser.home={B/"java-home"} -Djava.io.tmpdir={B/"tmp"}')
env['PATH']=str(jdk/'bin')+';'+env.get('PATH','')
for key in ['SOLOSOUL_KEYSTORE_PATH','SOLOSOUL_KEYSTORE_PASSWORD','SOLOSOUL_KEY_ALIAS','SOLOSOUL_KEY_PASSWORD']:
    env.pop(key,None)
def run(label,command):
    frozen();began=time.monotonic()
    with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
        proc=subprocess.Popen(command,cwd=P,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,
            creationflags=subprocess.CREATE_NO_WINDOW)
        save(S/(label+'.live.json'),{'pid':proc.pid,'command':command})
        print(label,'live PID',proc.pid,flush=True);code=proc.wait()
    frozen();save(S/(label+'.receipt.json'),{'command':command,'exitCode':code,
        'elapsedSeconds':time.monotonic()-began,'all1839SourceAndOriginalApkHashesUnchanged':True})
    print(label,'exit',code,flush=True);assert code==0,label
run('probe-build',['cmd.exe','/d','/c',str(G/'gradlew.bat'),'-p',str(P),'assembleDebug',
    '--offline','--no-daemon','--max-workers','2'])
apk=P/'build/outputs/apk/debug/project-debug.apk'
assert apk.is_file();copy=S/'solosoul-releaseprobe.apk';shutil.copyfile(apk,copy)
run('probe-badging',[str(sdk/'build-tools/35.0.0/aapt2.exe'),'dump','badging',str(copy)])
run('probe-signature',[str(jdk/'bin/java.exe'),'-jar',str(sdk/'build-tools/35.0.0/lib/apksigner.jar'),
    'verify','--verbose','--print-certs',str(copy)])
cert=re.findall(r'certificate SHA-256 digest: (\S+)',(S/'probe-signature.stdout.log').read_text(encoding='utf-8'))
assert cert==[inputs['release']['certificateSha256']]
def dex_classes(data):
    assert data[:4]==b'dex\n'
    u32=lambda off:struct.unpack_from('<I',data,off)[0]
    strings_offset=u32(60);types_offset=u32(68);count=u32(96);offset=u32(100)
    classes=[]
    for i in range(count):
        type_index=u32(offset+32*i);string_index=u32(types_offset+4*type_index)
        start=u32(strings_offset+4*string_index)
        while data[start]&0x80:start+=1
        start+=1;end=data.index(b'\0',start);classes.append(data[start:end].decode('ascii'))
    return classes
classes=[]
with zipfile.ZipFile(copy) as z:
    assert not any(n.startswith('lib/') for n in z.namelist())
    for name in z.namelist():
        if re.fullmatch(r'classes\d*\.dex',name):classes+=dex_classes(z.read(name))
assert 'Landroidx/tracing/Trace;' in classes
assert 'Lcom/solosoul/app/AndroidHomeInstrumentedTest;' in classes
assert 'Lcom/solosoul/app/MainActivity;' not in classes
assert not any(c.startswith('Lapp/tauri/') for c in classes)
save(S/'dex-defined-classes.json',classes)
save(S/'current-test-apk.json',{'acceptedPackagePreparation':True,'path':str(copy),'sha256':sha(copy),
    'bytes':copy.stat().st_size,'certificateSha256':cert[0],'package':'com.solosoul.app.releaseprobe',
    'targetPackage':'com.solosoul.app','testClassDefined':True,'traceRuntimeDefined':True,
    'targetMainActivityAndTauriClassesNotPackaged':True,'nativeLibrariesNotPackaged':True,
    'homeTestSourceSha256':sha(src),'mainReleaseBytesUnchanged':True,
    'nativeRuntimeAccepted':False,'fullRF312Accepted':False,
    'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print('Independent signed test APK prepared, with original test source and complete runner dependencies',flush=True)
