buildscript {
    repositories { google(); mavenCentral() }
    dependencies {
        classpath("com.android.tools.build:gradle:8.11.0")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.25")
    }
}
apply(plugin = "com.android.application")
apply(plugin = "org.jetbrains.kotlin.android")
repositories { google(); mavenCentral() }
configure<com.android.build.gradle.AppExtension> {
    namespace = "com.solosoul.app.releaseprobe"
    compileSdkVersion(36)
    buildToolsVersion = "35.0.0"
    defaultConfig {
        applicationId = "com.solosoul.app.releaseprobe"
        minSdk = 28
        targetSdk = 36
        versionCode = 1
        versionName = "RF312-internal"
    }
    signingConfigs.getByName("debug") {
        storeFile = file("D:/SoloSoul/build/android-native-feasibility-20261010/android-user/debug.keystore")
        storePassword = "android"
        keyAlias = "androiddebugkey"
        keyPassword = "android"
    }
    buildTypes.getByName("debug") {
        isDebuggable = true
        isMinifyEnabled = false
        signingConfig = signingConfigs.getByName("debug")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}
tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    kotlinOptions.jvmTarget = "1.8"
}
dependencies {
    // Actual existing app class headers are used only for compilation.
    // No target app classes or Rust library are packaged in this probe.
    add("compileOnly", files("original-main-compile-only.jar", "original-tauri-compile-only.jar"))
    add("compileOnly", "androidx.appcompat:appcompat:1.7.1")
    add("implementation", "androidx.core:core-ktx:1.16.0")
    add("implementation", "androidx.test.ext:junit:1.1.4")
    add("implementation", "androidx.test.espresso:espresso-core:3.5.0")
    add("implementation", "androidx.tracing:tracing:1.0.0")
}
