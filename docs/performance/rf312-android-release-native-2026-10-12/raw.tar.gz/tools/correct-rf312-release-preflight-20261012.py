from pathlib import Path
import hashlib,json
B=Path(__file__).parent;S=B/'rf312-android-release-native-20261012'
driver=S/'release-home-native-driver.py'
before=driver.read_bytes();(S/'release-home-native-driver-first-rejected.py').write_bytes(before)
prep=S/'preparation.json';(S/'preparation-first-rejected.json').write_bytes(prep.read_bytes())
text=before.decode('utf-8')
old="if len(paths) != 1 or not re.fullmatch(r'package:/data/app/[A-Za-z0-9_=/+.-]+/base\\.apk', paths[0]):"
new="if (len(paths) != 1 or not re.fullmatch(r'package:/data/app/(?:[A-Za-z0-9_~+=.-]+/){1,2}base\\.apk', paths[0])\n                or any(part in ('.', '..') for part in paths[0].split('/'))):"
assert text.count(old)==1;text=text.replace(old,new)
old="r'^\\s*(?:pkgFlags|flags)=\\[([^\\]]*)\\]'";new="r'^\\s*pkgFlags=\\[([^\\]]*)\\]'"
assert text.count(old)==1;text=text.replace(old,new)
compile(text,str(driver),'exec');driver.write_text(text,encoding='utf-8',newline='\n')
p=json.loads(prep.read_text(encoding='utf-8'));p['derivedDriverSha256']=hashlib.sha256(driver.read_bytes()).hexdigest()
p['initialPreflightRejectedBeforeBackupOrInstall']=True
p['preflightCorrection']='Recognize Android randomized ~~ path prefix and read unique canonical pkgFlags instead of matching its duplicate flags alias'
prep.write_text(json.dumps(p,indent=2)+'\n',encoding='utf-8')
wrapper=B/'run-rf312-release-home-20261012.py'
(S/'run-first-rejected.py').write_bytes(wrapper.read_bytes())
text=wrapper.read_text(encoding='utf-8');assert text.count("label='baseline-'+mode")==1
text=text.replace("label='baseline-'+mode","label='baseline-'+mode+'-round2'")
assert text.count("original=system();save(S/'original-system.json',original)")==1
text=text.replace("original=system();save(S/'original-system.json',original)","original=system();assert original==load(S/'original-system.json')")
wrapper.write_text(text,encoding='utf-8',newline='\n')
for name in ['baseline-supported.receipt.json','progress.json','verification.json']:
    path=S/name
    if path.exists():(S/('first-rejected-'+name)).write_bytes(path.read_bytes())
print('Preserved the pre-install rejection; corrected Android base-APK path and canonical flags reader',flush=True)
