from pathlib import Path
B=Path(__file__).parent;S=B/'rf312-release-probe-build-round2-20261012';P=S/'project'
gradle=P/'build.gradle.kts';(S/'build-before-webkit.gradle.kts').write_bytes(gradle.read_bytes())
text=gradle.read_text(encoding='utf-8')
needle='    add("implementation", "androidx.core:core-ktx:1.16.0")'
assert text.count(needle)==1
text=text.replace(needle,needle+'\n    add("implementation", "androidx.webkit:webkit:1.14.0")')
gradle.write_text(text,encoding='utf-8',newline='\n')
source=B/'continue-rf312-release-probe-20261012.py'
(S/'continue-round4-producer.py').write_bytes(source.read_bytes())
for name in ['continuation-input.json','continuation-build-tail.py']:
    p=S/name;(S/('round4-'+name)).write_bytes(p.read_bytes())
text=source.read_text(encoding='utf-8');assert text.count("run('probe-build-round4',")==1
text=text.replace("run('probe-build-round4',","run('probe-build-round5',")
source.write_text(text,encoding='utf-8',newline='\n')
print('Preserved missing WebKit compile reference; added the exact existing production WebKit version to probe only',flush=True)
