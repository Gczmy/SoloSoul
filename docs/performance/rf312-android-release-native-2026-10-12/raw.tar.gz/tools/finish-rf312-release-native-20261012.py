from pathlib import Path
import datetime,hashlib,importlib.util,json,os,socket,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-android-release-native-20261012'
C=B/'rf312-probe-debug-control-20261012';H=B/'api31-host-rf312-release-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
v=load(S/'independent-verification.json');assert v['acceptedReleaseFunctionalBaseline']
reviews=['baseline-supported-probe-aligned-round4/device-files/enhanced-light.png',
         'baseline-fallback-probe-aligned-round4/device-files/enhanced-dark-after-unlock.png']
save(S/'visual-review.json',{'reviewed':[{'path':p,'sha256':sha(S/p)} for p in reviews],
    'observations':'Both screenshots show the public account home with visible copy/count, glass illustration, toolbar and navigation; light/dark schemes differ as expected',
    'all33PngsVisuallyReviewed':False,'fullAccessibilityOrFullThemeMatrixAccepted':False})
spec=importlib.util.spec_from_file_location('home',S/'original-driver.py')
home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
pairs=[]
for base in [S,C]:
    for path in sorted(base.glob('baseline-*')):
        if not path.is_dir() or not (path/'private-data-before.tar').is_file():continue
        before=path/'private-data-before.tar';after=path/'private-data-restored.tar'
        a=home.inventory(before,True);b=home.inventory(after,True)
        report=load(path/'report.json');assert len(a)==216 and a==b and report['restored'] and report['originalApksRestored']
        commands=load(path/'commands.json')
        stats=[x for x in commands if x['command']==['shell','run-as','com.solosoul.app','stat','-c','%a','.']]
        assert len(stats)==2 and stats[0]['stdoutSha256']==stats[1]['stdoutSha256']
        pairs.append({'case':str(path),'entries':len(a),'allContentsLinksModesMatch':True,
            'rootModeOutputSha256':stats[0]['stdoutSha256'],
            'inventorySha256':hashlib.sha256(json.dumps(a,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
            'files':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in [before,after]]})
assert len(pairs)==8
save(S/'private-pairs-verification.json',{'accepted':True,'pairs':pairs,'privateTarCount':16,
    'privateContentNotPublished':True})
owned=next(x for x in load(H/'owned-processes-after-launch.json') if x['ProcessId']==15768)
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
def identity():
    p=subprocess.run([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {owned['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3"],
        check=True,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    return json.loads(p.stdout) if p.stdout.strip() else None
live=identity();assert live
for key in ['Name','ProcessId','ExecutablePath','CommandLine']:assert live[key]==owned[key],key
assert datetime.datetime.fromisoformat(live['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
env=os.environ.copy();env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049')
def read(*args):
    return subprocess.run([str(B/'sdk/platform-tools/adb.exe'),'-H','localhost','-P','5049','-s','emulator-5586',*args],
        env=env,check=True,capture_output=True,text=True,timeout=40,creationflags=subprocess.CREATE_NO_WINDOW).stdout.strip()
assert read('emu','avd','name').splitlines()[0]=='SoloSoul_RF121_API31_20261010'
assert not read('shell','pm','list','packages','com.solosoul.app.releaseprobe')
current={'night':read('shell','cmd','uimode','night'),'blur':read('shell','settings','get','global','disable_window_blurs'),
    'font':read('shell','settings','get','system','font_scale'),
    'effectiveFont':home.activity_font_scale(read('shell','dumpsys','activity','processes')),
    'contrast':read('shell','settings','get','secure','high_text_contrast_enabled'),
    'animation':read('shell','settings','get','global','animator_duration_scale')}
assert current==load(S/'original-system.json')
stop={'identity':live,'originalSystemStillExact':True,'ownedProbeStillAbsent':True,
      'settings':current,'response':read('emu','kill'),'forceTerminationUsed':False}
deadline=time.monotonic()+40
while identity() is not None:
    assert time.monotonic()<deadline;time.sleep(1)
for port in [5586,5587]:
    with socket.socket() as sock:sock.bind(('127.0.0.1',port))
stop.update(ownedProcessExited=True,dedicatedPortsFree=True,at=datetime.datetime.now(datetime.timezone.utc).isoformat())
save(H/'stop.receipt.json',stop)
print('Eight backup/restore pairs verified; exact owned emulator exited normally, original system and packages preserved',flush=True)
