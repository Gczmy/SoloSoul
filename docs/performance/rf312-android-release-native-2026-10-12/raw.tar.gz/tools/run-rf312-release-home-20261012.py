from pathlib import Path
import datetime, hashlib, importlib.util, json, os, subprocess, time

R=Path('D:/SoloSoul'); B=Path(__file__).parent; S=B/'rf312-android-release-native-20261012'
H=B/'api31-host-rf312-release-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
inputs=load(S/'inputs.json');prep=load(S/'preparation.json')
env=os.environ.copy();env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',
    TEMP=str(B/'tmp'),TMP=str(B/'tmp'),PYTHONUTF8='1')
ADB=B/'sdk/platform-tools/adb.exe';SERIAL='emulator-5586';AVD='SoloSoul_RF121_API31_20261010'
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
spec=importlib.util.spec_from_file_location('home',S/'original-driver.py')
home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
def read(*args):
    return subprocess.run([str(ADB),'-H','localhost','-P','5049','-s',SERIAL,*args],env=env,
        check=True,capture_output=True,text=True,timeout=40,creationflags=subprocess.CREATE_NO_WINDOW).stdout.strip()
def frozen():
    assert len(inputs['runtimeSourceFiles'])==1839
    assert all(sha(R/n)==h for n,h in inputs['runtimeSourceFiles'].items())
    assert sha(S/'release-home-native-driver.py')==prep['derivedDriverSha256']
    for row in [inputs['release']['apk'],inputs['originalDebug'],inputs['originalTest'],inputs['runtimeTest']]:
        assert sha(Path(row.get('path',row.get('copy'))))==row['sha256']
def system():
    return {'night':read('shell','cmd','uimode','night'),
            'blur':read('shell','settings','get','global','disable_window_blurs'),
            'font':read('shell','settings','get','system','font_scale'),
            'effectiveFont':home.activity_font_scale(read('shell','dumpsys','activity','processes')),
            'contrast':read('shell','settings','get','secure','high_text_contrast_enabled'),
            'animation':read('shell','settings','get','global','animator_duration_scale')}
frozen()
boot=load(H/'boot.receipt.json');assert boot['booted'] and boot['avdConfigUnchanged']
owned=next(x for x in load(H/'owned-processes-after-launch.json') if x['ProcessId']==boot['pid'])
p=subprocess.run([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {owned['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3"],
    check=True,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
live=json.loads(p.stdout)
for key in ['Name','ProcessId','ExecutablePath','CommandLine']:assert live[key]==owned[key],key
assert datetime.datetime.fromisoformat(live['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
assert read('emu','avd','name').splitlines()[0]==AVD
assert read('shell','getprop','sys.boot_completed')=='1'
assert read('shell','getprop','ro.build.version.sdk')=='31'
assert read('shell','getprop','ro.product.cpu.abi')=='x86_64'
save(S/'owned-emulator-preflight.json',{'identity':live,'allIdentityFieldsVerified':True})
rows=[]
original=system();assert original==load(S/'original-system.json')
for mode in ['supported','fallback']:
    frozen();label='baseline-'+mode+'-probe-aligned-round4'
    before=system();assert before==original
    command=['C:/Python314/python.exe',str(S/'release-home-native-driver.py'),'--adb',str(ADB),
        '--serial',SERIAL,'--avd',AVD,'--apk',inputs['release']['apk']['path'],
        '--test-apk',inputs['runtimeTest']['path'],'--restore-apk',inputs['originalDebug']['copy'],
        '--output',str(S/label),'--mode',mode,'--scenario','baseline']
    began=time.monotonic()
    with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
        proc=subprocess.Popen(command,cwd=R/'tauri',env=env,stdin=subprocess.DEVNULL,
            stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(S/(label+'.live.json'),{'pid':proc.pid,'command':command})
        print(label,'live PID',proc.pid,flush=True)
        code=proc.wait()
    frozen()
    report=load(S/label/'report.json') if (S/label/'report.json').is_file() else {}
    after=system()
    restored=bool(report.get('restored') and report.get('originalApksRestored') and report.get('ownedProbeRemoved')
        and report.get('blurRestored') and report.get('frozenInputsUnchanged') and before==after
        and not any(report.get(k) for k in ['restoreError','blurRestoreError','sourceRestoreError']))
    accepted=bool(code==0 and report.get('passed') and report.get('nativePassed') and restored)
    row={'mode':mode,'scenario':'baseline','exitCode':code,'accepted':accepted,'restored':restored,
        'elapsedSeconds':time.monotonic()-began,'systemBefore':before,'systemAfter':after,
        'reportSha256':sha(S/label/'report.json') if report else None,
        'nativeError':report.get('error'),'restoreError':report.get('restoreError')}
    save(S/(label+'.receipt.json'),row);rows.append(row)
    print(label,'terminal exit',code,'accepted',accepted,'restored',restored,flush=True)
    save(S/'progress.json',{'results':rows})
    if not restored:
        save(S/'verification.json',{'accepted':False,'results':rows,'stoppedForIncompleteRestoration':True,
            'fullRF312Accepted':False});raise SystemExit(1)
accepted=len(rows)==2 and all(x['accepted'] for x in rows)
save(S/'verification.json',{'accepted':accepted,'results':rows,
    'scope':'actual non-debuggable optimized x86_64 Release baseline production home in API31 AVD',
    'allSourcesAndApksUnchanged':True,'physicalPerformanceAccepted':False,
    'fullRF121Accepted':False,'fullRF312Accepted':False,
    'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
raise SystemExit(0 if accepted else 1)
