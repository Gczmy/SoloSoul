from pathlib import Path
import hashlib,json,os,subprocess,time
B=Path(__file__).parent;R=Path('D:/SoloSoul');S=B/'rf312-release-probe-build-round2-20261012';P=S/'project'
F=S/'dependency-fetch';F.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
inputs=load(B/'rf312-android-release-native-20261012/inputs.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def frozen():
    assert all(sha(R/n)==h for n,h in inputs['runtimeSourceFiles'].items())
    assert sha(Path(inputs['release']['apk']['path']))==inputs['release']['apk']['sha256']
frozen()
init=F/'resolve-runtime.gradle'
init.write_text('''import groovy.json.JsonOutput
gradle.projectsEvaluated {
    rootProject.tasks.register('rf312ResolveProbeRuntime') {
        doLast {
            def c = rootProject.configurations.getByName('debugRuntimeClasspath')
            def rows = c.resolvedConfiguration.resolvedArtifacts.collect { a ->
                def f=a.file
                [module:a.moduleVersion.id.toString(),path:f.absolutePath,bytes:f.length(),
                 sha256:java.security.MessageDigest.getInstance('SHA-256').digest(f.bytes).encodeHex().toString()]
            }.sort { it.module + it.path }
            def result=[rootDependencies:c.allDependencies.collect { [group:it.group,name:it.name,version:it.version] },
                components:c.incoming.resolutionResult.allComponents.collect { it.id.displayName }.sort(),artifacts:rows]
            new File('''+json.dumps(str(F/'resolved-runtime.json').replace('\\','/'))+''').text=JsonOutput.prettyPrint(JsonOutput.toJson(result))
        }
    }
}
''',encoding='utf-8')
jdk=Path('C:/Users/40299571/ss-android/jdk');sdk=B/'sdk'
env=os.environ.copy();env.update(JAVA_HOME=str(jdk),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),
    ANDROID_USER_HOME=str(B/'android-user'),GRADLE_USER_HOME=str(B/'gradle-home'),
    TEMP=str(B/'tmp'),TMP=str(B/'tmp'),JAVA_TOOL_OPTIONS=f'-Duser.home={B/"java-home"} -Djava.io.tmpdir={B/"tmp"}')
env['PATH']=str(jdk/'bin')+';'+env.get('PATH','')
cmd=['cmd.exe','/d','/c',str(R/'tauri/src-tauri/gen/android/gradlew.bat'),'-p',str(P),
     'rf312ResolveProbeRuntime','--init-script',str(init),'--no-daemon','--max-workers','2']
began=time.monotonic()
with (F/'stdout.log').open('xb') as out,(F/'stderr.log').open('xb') as err:
    p=subprocess.Popen(cmd,cwd=P,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    (F/'live.json').write_text(json.dumps({'pid':p.pid,'command':cmd},indent=2),encoding='utf-8')
    print('Pinned standalone probe runtime dependency resolution PID',p.pid,flush=True);code=p.wait()
frozen()
(F/'receipt.json').write_text(json.dumps({'command':cmd,'exitCode':code,'elapsedSeconds':time.monotonic()-began,
    'productionSourcesAndReleaseApkUnchanged':True,'externalProjectDependencyDeclarationsUnchanged':True,
    'normalConfiguredRepositoriesOnly':True,'allNativeResultsStillUnaccepted':True},indent=2),encoding='utf-8')
assert code==0
rows=load(F/'resolved-runtime.json')['artifacts']
for row in rows:
    path=Path(row['path']);data=path.read_bytes();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print('Probe runtime resolved through normal Gradle repositories; independently verified',len(rows),'existing-version artifacts',flush=True)
