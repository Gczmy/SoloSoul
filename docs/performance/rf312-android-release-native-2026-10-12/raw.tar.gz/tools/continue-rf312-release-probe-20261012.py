from pathlib import Path
import datetime,hashlib,json,os,re,shutil,struct,subprocess,time,zipfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;N=B/'rf312-android-release-native-20261012'
S=B/'rf312-release-probe-build-round2-20261012';P=S/'project'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
inputs=load(N/'inputs.json');src=R/'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidHomeInstrumentedTest.kt'
proof=load(S/'input-proof.json');G=R/'tauri/src-tauri/gen/android'
def frozen():
    assert all(sha(R/n)==h for n,h in inputs['runtimeSourceFiles'].items())
    for row in [inputs['release']['apk'],inputs['originalDebug'],inputs['originalTest']]:
        assert sha(Path(row.get('path',row.get('copy'))))==row['sha256']
    assert sha(P/'original-main-compile-only.jar')==proof['compileOnlyMainJarSha256']
    assert sha(P/'original-tauri-compile-only.jar')==proof['compileOnlyTauriJarSha256']
    assert sha(src)==sha(P/'src/main/java/com/solosoul/app'/src.name)==proof['homeTestSourceSha256']
frozen()
producer=(B/'build-rf312-release-probe-20261012.py').read_bytes()
save(S/'continuation-input.json',{'originalProducerSha256':hashlib.sha256(producer).hexdigest(),
    'previousBuildExitCode':load(S/'probe-build.receipt.json')['exitCode'],
    'dependencyFetchExitCode':load(S/'dependency-fetch/receipt.json')['exitCode'],
    'continuationScope':'same independent project; fixed-version cache now resolved; offline compile/package retry',
    'productionSourcesAndReleaseApkUnchanged':True})
tail=producer.decode('utf-8');tail=tail[tail.index("jdk=Path('C:/Users/40299571/ss-android/jdk')"):]
assert tail.count("run('probe-build',")==1
tail=tail.replace("run('probe-build',","run('probe-build-round6',")
tail=tail.replace("copy=S/'solosoul-releaseprobe.apk'","copy=S/'solosoul-releaseprobe-manifest-aligned.apk'")
(S/'continuation-build-tail.py').write_text(tail,encoding='utf-8',newline='\n')
exec(compile(tail,str(S/'continuation-build-tail.py'),'exec'))
