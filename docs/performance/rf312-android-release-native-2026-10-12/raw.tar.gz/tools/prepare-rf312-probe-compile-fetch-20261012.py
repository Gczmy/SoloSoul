from pathlib import Path
B=Path(__file__).parent
source=B/'fetch-rf312-probe-dependencies-20261012.py'
text=source.read_text(encoding='utf-8')
assert text.count("F=S/'dependency-fetch'")==1
text=text.replace("F=S/'dependency-fetch'","F=S/'dependency-fetch-compile'")
text=text.replace('debugRuntimeClasspath','debugCompileClasspath').replace('resolved-runtime.json','resolved-compile.json')
text=text.replace('rf312ResolveProbeRuntime','rf312ResolveProbeCompile')
text=text.replace('runtime dependency','compile dependency').replace('Probe runtime resolved','Probe compile classpath resolved')
target=B/'fetch-rf312-probe-compile-dependencies-20261012.py'
compile(text,str(target),'exec');target.write_text(text,encoding='utf-8',newline='\n')
print('Prepared normal fixed-version compile-classpath resolution; no dependency declarations changed',flush=True)
