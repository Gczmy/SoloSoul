from pathlib import Path
B=Path(__file__).parent;S=B/'rf312-release-probe-build-round2-20261012';P=S/'project'
for name in ['current-test-apk.json','dex-defined-classes.json','probe-badging.stdout.log','probe-badging.stderr.log',
             'probe-badging.receipt.json','probe-signature.stdout.log','probe-signature.stderr.log','probe-signature.receipt.json']:
    path=S/name;(S/('first-probe-'+name)).write_bytes(path.read_bytes())
source=B/'continue-rf312-release-probe-20261012.py'
(S/'continue-round5-producer.py').write_bytes(source.read_bytes())
for name in ['continuation-input.json','continuation-build-tail.py']:
    p=S/name;(S/('round5-'+name)).write_bytes(p.read_bytes())
manifest=P/'src/main/AndroidManifest.xml';(S/'manifest-before-alignment.xml').write_bytes(manifest.read_bytes())
manifest.write_text('''<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android" xmlns:tools="http://schemas.android.com/tools">
    <uses-permission android:name="android.permission.REORDER_TASKS" />
    <application android:label="SoloSoul internal Release probe" android:allowBackup="false" tools:remove="android:appComponentFactory">
        <uses-library android:name="android.test.runner" />
        <provider android:name="androidx.startup.InitializationProvider" tools:node="remove" />
        <receiver android:name="androidx.profileinstaller.ProfileInstallReceiver" tools:node="remove" />
    </application>
    <instrumentation android:name="androidx.test.runner.AndroidJUnitRunner"
        android:targetPackage="com.solosoul.app" android:functionalTest="false" android:handleProfiling="false" />
</manifest>
''',encoding='utf-8',newline='\n')
gradle=P/'build.gradle.kts';(S/'build-before-runtime-alignment.gradle.kts').write_bytes(gradle.read_bytes())
text=gradle.read_text(encoding='utf-8')
text+='''
// A test runner must not override the target application's eager lifecycle
// initializer with a second independent AppInitializer/Provider instance.
configurations.configureEach {
    exclude(mapOf("group" to "androidx.startup", "module" to "startup-runtime"))
    exclude(mapOf("group" to "androidx.profileinstaller", "module" to "profileinstaller"))
}
'''
gradle.write_text(text,encoding='utf-8',newline='\n')
text=source.read_text(encoding='utf-8')
assert text.count("run('probe-build-round5',")==1
text=text.replace("run('probe-build-round5',","run('probe-build-round6',")
needle="tail=tail.replace(\"run('probe-build',\",\"run('probe-build-round6',\")"
assert text.count(needle)==1
text=text.replace(needle,needle+"\ntail=tail.replace(\"copy=S/'solosoul-releaseprobe.apk'\",\"copy=S/'solosoul-releaseprobe-manifest-aligned.apk'\")")
source.write_text(text,encoding='utf-8',newline='\n')
print('Preserved failing probe; aligned instrumentation manifest and removed only probe-side eager initializer dependencies',flush=True)
