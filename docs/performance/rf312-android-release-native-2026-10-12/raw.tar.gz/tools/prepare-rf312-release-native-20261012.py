from pathlib import Path
import hashlib, json

R = Path('D:/SoloSoul')
B = Path(__file__).parent
S = B/'rf312-android-release-native-20261012'
S.mkdir(exist_ok=False)
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
proof = load(B/'rf312-android-release-build-20261012/input-proof.json')
assert len(proof['sourceFiles']) == 1839
assert all(sha(R/n) == h for n,h in proof['sourceFiles'].items())
release = load(B/'rf312-android-release-build-20261012/package-verification.json')
debug = load(B/'rf1132-card-high-contrast-build-20261012/current-apks.json')
files = {x['kind']: x for x in debug['files']}
assert sha(Path(release['apk']['path'])) == release['apk']['sha256']
assert all(sha(Path(x['copy'])) == x['sha256'] for x in files.values())
inputs = {'sourceHead': proof['sourceHead'], 'runtimeSourceFiles': proof['sourceFiles'],
          'release': release, 'originalDebug': files['main'], 'originalTest': files['test'],
          'releaseBuildInputSha256': sha(B/'rf312-android-release-build-20261012/input-proof.json'),
          'testBuildInputSha256': sha(B/'rf1132-card-high-contrast-build-20261012/current-apks.json')}
(S/'inputs.json').write_text(json.dumps(inputs, indent=2)+'\n', encoding='utf-8')
original = (R/'tauri/scripts/android-home-native-regression.py').read_bytes()
(S/'original-driver.py').write_bytes(original)
text = original.decode('utf-8').replace('\r\n','\n')
def replace(old, new):
    global text
    assert text.count(old) == 1, (old, text.count(old))
    text = text.replace(old,new)

replace('    args = parser.parse_args()', '''    parser.add_argument('--restore-apk', required=True)
    args = parser.parse_args()
    frozen_inputs = json.loads((Path(__file__).parent/'inputs.json').read_text(encoding='utf-8'))
    if (Path(args.apk).resolve() != Path(frozen_inputs['release']['apk']['path']).resolve()
            or Path(args.restore_apk).resolve() != Path(frozen_inputs['originalDebug']['copy']).resolve()
            or Path(args.test_apk).resolve() != Path(frozen_inputs['originalTest']['copy']).resolve()):
        parser.error('Release validation requires the exact frozen Release/restore/test APKs')''')
replace('    root_mode = None\n', '    root_mode = None\n    original_packages = None\n    commands = []\n')
replace('''        return subprocess.run([args.adb, "-s", args.serial, *command], check=True,
                              timeout=kwargs.pop('timeout', 240), **kwargs)''', '''        began = time.monotonic()
        result = subprocess.run([args.adb, '-H', 'localhost', '-P', '5049', '-s', args.serial, *command],
                                check=False, timeout=kwargs.pop('timeout', 240), **kwargs)
        row = {'command': list(command), 'exitCode': result.returncode,
               'elapsedSeconds': time.monotonic()-began}
        for name in ('stdout', 'stderr'):
            value = getattr(result, name)
            if isinstance(value, bytes): row[name+'Sha256'] = hashlib.sha256(value).hexdigest()
        commands.append(row)
        (output/'commands.json').write_text(json.dumps(commands, indent=2)+'\\n', encoding='utf-8')
        result.check_returncode()
        return result''')
replace('    try:\n        devices = read("devices", "-l").splitlines()', '''    def frozen():
        root = Path('D:/SoloSoul')
        if any(digest(root/name) != value for name,value in frozen_inputs['runtimeSourceFiles'].items()):
            raise RuntimeError('Frozen Release runtime source changed')
        for row in (frozen_inputs['release']['apk'], frozen_inputs['originalDebug'], frozen_inputs['originalTest']):
            if digest(Path(row.get('path', row.get('copy')))) != row['sha256']:
                raise RuntimeError('Frozen APK changed')

    def installed(package, label):
        paths = read('shell', 'pm', 'path', package).splitlines()
        if (len(paths) != 1 or not re.fullmatch(r'package:/data/app/(?:[A-Za-z0-9_~+=.-]+/){1,2}base\\.apk', paths[0])
                or any(part in ('.', '..') for part in paths[0].split('/'))):
            raise RuntimeError('Expected a single installed base APK')
        payload = adb('exec-out', 'cat', paths[0].removeprefix('package:'),
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout
        dump = read('shell', 'dumpsys', 'package', package)
        (output/(label+'-package.log')).write_text(dump, encoding='utf-8')
        uid = re.findall(r'^\\s*userId=(\\d+)\\s*$', dump, re.M)
        flags = re.findall(r'^\\s*pkgFlags=\\[([^\\]]*)\\]', dump, re.M)
        if len(uid) != 1 or len(flags) != 1:
            raise RuntimeError('Missing unambiguous package UID/debug flags')
        return {'sha256': hashlib.sha256(payload).hexdigest(), 'bytes': len(payload),
                'uid': int(uid[0]), 'debuggable': 'DEBUGGABLE' in flags[0].split()}

    try:
        frozen()
        devices = read("devices", "-l").splitlines()''')
replace('        selected = True\n', '''        selected = True
        original_packages = {'main': installed(APP, 'original-main'),
                             'test': installed(APP+'.test', 'original-test')}
        report['originalInstalledPackages'] = original_packages
        if (original_packages['main']['sha256'] != frozen_inputs['originalDebug']['sha256']
                or original_packages['test']['sha256'] != frozen_inputs['originalTest']['sha256']
                or not original_packages['main']['debuggable']):
            raise RuntimeError('Installed original packages differ; refusing Release replacement')
''')
replace('        adb("install", "-r", str(Path(args.test_apk).resolve()), stdout=subprocess.PIPE)\n', '''        adb("install", "-r", str(Path(args.test_apk).resolve()), stdout=subprocess.PIPE)
        current = installed(APP, 'release-main')
        report['releaseInstalledPackage'] = current
        if (current['sha256'] != frozen_inputs['release']['apk']['sha256'] or current['debuggable']
                or current['uid'] != original_packages['main']['uid']):
            raise RuntimeError('Exact non-debuggable Release package/UID verification failed')
        frozen()
''')
replace('                if backup_valid and mutation_started:\n', '''                if backup_valid and mutation_started:
                    # Release run-as is unavailable. Restore the original APK first,
                    # without clearing data; only then restore the full original TAR.
                    adb('install', '-r', str(Path(args.restore_apk).resolve()), stdout=subprocess.PIPE)
                    adb('shell', 'am', 'force-stop', APP, stdout=subprocess.PIPE)
                    restored_packages = {'main': installed(APP, 'restored-main'),
                                         'test': installed(APP+'.test', 'restored-test')}
                    report['restoredInstalledPackages'] = restored_packages
                    if restored_packages != original_packages:
                        raise RuntimeError('Original APK bytes, UID or debug flags were not restored')
                    report['originalApksRestored'] = True
''')
replace('        report["passed"] = verification_passed(report, old_notification is not None)', '''        try:
            frozen()
            report['frozenInputsUnchanged'] = True
        except Exception as error:
            report['sourceRestoreError'] = str(error)
        report['passed'] = bool(verification_passed(report, old_notification is not None)
                                and report.get('originalApksRestored')
                                and report.get('frozenInputsUnchanged')
                                and not report.get('sourceRestoreError'))''')
(S/'release-home-native-driver.py').write_text(text, encoding='utf-8', newline='\n')
compile(text, str(S/'release-home-native-driver.py'), 'exec')
boot = (B/'boot-rf1132-api31-host.py').read_text(encoding='utf-8')
assert boot.count("'api31-host-rf1132-20261012'") == 1
boot = boot.replace("'api31-host-rf1132-20261012'", "'api31-host-rf312-release-20261012'")
(B/'boot-rf312-release-api31.py').write_text(boot, encoding='utf-8', newline='\n')
(S/'preparation.json').write_text(json.dumps({'sourceCount': len(proof['sourceFiles']),
    'sourceAndApkHashesVerified': True, 'productionSourcesChanged': False,
    'originalDriverSha256': hashlib.sha256(original).hexdigest(),
    'derivedDriverSha256': sha(S/'release-home-native-driver.py'),
    'originalValidationAndRestorationPreserved': True,
    'additionalRestoreScope': 'exact original main/test APK bytes, UID, debuggable flag before private TAR restoration',
    'fullRF312Accepted': False}, indent=2)+'\n', encoding='utf-8')
print('Prepared Release-native driver with strict original-APK restore guard; 1839 sources unchanged', flush=True)
