from pathlib import Path
import hashlib,json
B=Path(__file__).parent;S=B/'rf312-android-release-native-20261012';D=B/'rf312-release-probe-build-round2-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
runtime=load(D/'current-test-apk.json');assert runtime['acceptedPackagePreparation']
assert sha(Path(runtime['path']))==runtime['sha256']
assert runtime['targetMainActivityAndTauriClassesNotPackaged'] and runtime['traceRuntimeDefined']
inputs=S/'inputs.json';(S/'inputs-debug-test-original.json').write_bytes(inputs.read_bytes())
value=load(inputs);assert runtime['certificateSha256']==value['release']['certificateSha256']
value['runtimeTest']=runtime;inputs.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
driver=S/'release-home-native-driver.py';before=driver.read_bytes()
(S/'release-home-native-driver-debug-test-rejected.py').write_bytes(before)
text=before.decode('utf-8')
def replace(old,new):
    global text
    assert text.count(old)==1,(old,text.count(old));text=text.replace(old,new)
replace("Path(args.test_apk).resolve() != Path(frozen_inputs['originalTest']['copy']).resolve()",
        "Path(args.test_apk).resolve() != Path(frozen_inputs['runtimeTest']['path']).resolve()")
replace("frozen_inputs['originalDebug'], frozen_inputs['originalTest']):",
        "frozen_inputs['originalDebug'], frozen_inputs['originalTest'], frozen_inputs['runtimeTest']):")
replace("        original_packages = {'main': installed(APP, 'original-main'),",
        "        if read('shell','pm','list','packages','com.solosoul.app.releaseprobe'):\n            raise RuntimeError('Dedicated Release probe package already exists; refusing replacement')\n        original_packages = {'main': installed(APP, 'original-main'),")
replace('        current = installed(APP, \'release-main\')', '''        probe = installed('com.solosoul.app.releaseprobe', 'runtime-probe')
        report['probeInstalledPackage'] = probe
        if probe['sha256'] != frozen_inputs['runtimeTest']['sha256']:
            raise RuntimeError('Installed probe APK differs from the frozen build')
        current = installed(APP, 'release-main')''')
assert text.count('"com.solosoul.app.test/androidx.test.runner.AndroidJUnitRunner"')==1
text=text.replace('"com.solosoul.app.test/androidx.test.runner.AndroidJUnitRunner"',
                  '"com.solosoul.app.releaseprobe/androidx.test.runner.AndroidJUnitRunner"')
assert text.count("'com.solosoul.app.test/androidx.test.runner.AndroidJUnitRunner'")==1
text=text.replace("'com.solosoul.app.test/androidx.test.runner.AndroidJUnitRunner'",
                  "'com.solosoul.app.releaseprobe/androidx.test.runner.AndroidJUnitRunner'")
replace("                    report['originalApksRestored'] = True", '''                    report['originalApksRestored'] = True
                    probe_list = read('shell','pm','list','packages','com.solosoul.app.releaseprobe')
                    if probe_list:
                        if probe_list != 'package:com.solosoul.app.releaseprobe':
                            raise RuntimeError('Unexpected probe package identity; refusing uninstall')
                        probe = installed('com.solosoul.app.releaseprobe', 'probe-before-uninstall')
                        if probe['sha256'] != frozen_inputs['runtimeTest']['sha256']:
                            raise RuntimeError('Probe package bytes changed; refusing uninstall')
                        adb('uninstall','com.solosoul.app.releaseprobe',stdout=subprocess.PIPE)
                    if read('shell','pm','list','packages','com.solosoul.app.releaseprobe'):
                        raise RuntimeError('Dedicated probe package was not removed')
                    report['ownedProbeRemoved'] = True''')
replace("and report.get('originalApksRestored')", "and report.get('originalApksRestored')\n                                and report.get('ownedProbeRemoved')")
compile(text,str(driver),'exec');driver.write_text(text,encoding='utf-8',newline='\n')
prep=S/'preparation.json';(S/'preparation-debug-test-rejected.json').write_bytes(prep.read_bytes())
p=load(prep);p.update(derivedDriverSha256=sha(driver),runtimeProbeSha256=runtime['sha256'],
    independentProbeMustBeAbsentBeforeEachCase=True,ownedProbeMustBeRemovedAfterEachCase=True,
    originalTestApkUntouched=True)
prep.write_text(json.dumps(p,indent=2)+'\n',encoding='utf-8')
wrapper=B/'run-rf312-release-home-20261012.py';(S/'run-debug-test-rejected.py').write_bytes(wrapper.read_bytes())
text=wrapper.read_text(encoding='utf-8')
assert text.count("label='baseline-'+mode+'-round2'")==1
text=text.replace("label='baseline-'+mode+'-round2'","label='baseline-'+mode+'-probe-round3'")
assert text.count("inputs['originalTest']['copy'],'--restore-apk'")==1
text=text.replace("inputs['originalTest']['copy'],'--restore-apk'","inputs['runtimeTest']['path'],'--restore-apk'")
assert text.count("inputs['originalDebug'],inputs['originalTest']]:")==1
text=text.replace("inputs['originalDebug'],inputs['originalTest']]:",
                  "inputs['originalDebug'],inputs['originalTest'],inputs['runtimeTest']]:")
assert text.count("report.get('restored') and report.get('originalApksRestored')")==1
text=text.replace("report.get('restored') and report.get('originalApksRestored')",
                  "report.get('restored') and report.get('originalApksRestored') and report.get('ownedProbeRemoved')")
compile(text,str(wrapper),'exec');wrapper.write_text(text,encoding='utf-8',newline='\n')
for name in ['progress.json','verification.json','owned-emulator-preflight.json']:
    path=S/name
    (S/('debug-test-rejected-'+name)).write_bytes(path.read_bytes())
print('Prepared original home test in separate signed probe APK; production Release frozen and original test APK untouched',flush=True)
