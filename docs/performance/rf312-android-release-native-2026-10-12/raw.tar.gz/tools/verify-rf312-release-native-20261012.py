from pathlib import Path
import ast,hashlib,importlib.util,json,re,struct,zipfile
from PIL import Image
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-android-release-native-20261012'
C=B/'rf312-probe-debug-control-20261012';D=B/'rf312-release-probe-build-round2-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
inputs=load(S/'inputs.json');assert len(inputs['runtimeSourceFiles'])==1839
assert all(sha(R/n)==h for n,h in inputs['runtimeSourceFiles'].items())
for row in [inputs['release']['apk'],inputs['originalDebug'],inputs['originalTest'],inputs['runtimeTest']]:
    assert sha(Path(row.get('path',row.get('copy'))))==row['sha256']
spec=importlib.util.spec_from_file_location('home',S/'original-driver.py')
home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
assert (S/'original-driver.py').read_bytes()==(R/'tauri/scripts/android-home-native-regression.py').read_bytes()
result=load(S/'verification.json');control=load(C/'verification.json')
assert result['accepted'] and len(result['results'])==2
assert control['accepted'] and len(control['results'])==1
assert not result['fullRF312Accepted'] and not result['physicalPerformanceAccepted']
rows=[];pngs=[]
for base,modes,release in [(S,['supported','fallback'],True),(C,['supported'],False)]:
    for mode in modes:
        label='baseline-'+mode+'-probe-aligned-round4';P=base/label
        receipt=load(base/(label+'.receipt.json'));report=load(P/'report.json')
        assert receipt['exitCode']==0 and receipt['accepted'] and receipt['restored']
        assert report['passed'] and report['nativePassed'] and report['originalApksRestored']
        assert report['ownedProbeRemoved'] and report['restored'] and report['blurRestored']
        assert report['frozenInputsUnchanged'] and report['api']==31 and report['abi']=='x86_64'
        assert not any(report.get(k) for k in ['error','restoreError','blurRestoreError','sourceRestoreError'])
        assert report['originalInstalledPackages']==report['restoredInstalledPackages']
        target=report['releaseInstalledPackage' if release else 'debugControlInstalledPackage']
        expected=inputs['release']['apk'] if release else inputs['originalDebug']
        assert target['sha256']==expected['sha256'] and target['debuggable'] is (not release)
        assert target['uid']==report['originalInstalledPackages']['main']['uid']
        assert report['probeInstalledPackage']['sha256']==inputs['runtimeTest']['sha256']
        before=home.inventory(P/'private-data-before.tar',require_empty=True)
        after=home.inventory(P/'private-data-restored.tar',require_empty=True)
        assert len(before)==216 and before==after
        commands=load(P/'commands.json');assert all(x['exitCode']==0 for x in commands)
        root_stats=[x for x in commands if x['command']==['shell','run-as','com.solosoul.app','stat','-c','%a','.']]
        assert len(root_stats)==2 and root_stats[0]['stdoutSha256']==root_stats[1]['stdoutSha256']
        assert receipt['systemBefore']==receipt['systemAfter']==load(base/'original-system.json')
        raw=(P/'native.log').read_text(encoding='utf-8');home.verify_native(raw)
        evidence=load(P/'device-files/report.json');stages=home.verify_evidence(evidence,'baseline')
        assert len(stages)==12 and report['stages']==stages and evidence['directoryAttempts']>=1
        for path in sorted((P/'device-files').glob('*.png')):
            with Image.open(path) as im:
                im.load();assert im.format=='PNG' and im.width>0 and im.height>0
                extrema=im.convert('RGB').getextrema();assert any(lo!=hi for lo,hi in extrema)
                pngs.append({'lane':'release' if release else 'debug-control','mode':mode,
                    'path':str(path),'sha256':sha(path),'bytes':path.stat().st_size,'width':im.width,'height':im.height,
                    'nonUniformComposedImage':True})
        rows.append({'lane':'release' if release else 'debug-control','mode':mode,'nativeTests':1,
            'failures':0,'skipped':0,'stages':stages,'nativeProcessId':evidence['processId'],
            'runtime':evidence['runtime'],'targetPackage':target,'all216PrivateEntriesAndRootModeExact':True,
            'originalPackagesExact':True,'systemExact':True,'ownedProbeRemoved':True})
# Failures stay part of the evidence; they do not become successful samples.
failed=[]
for base,labels in [(S,['baseline-supported','baseline-supported-round2','baseline-fallback-round2',
                     'baseline-supported-probe-round3','baseline-fallback-probe-round3']),
                   (C,['baseline-supported-probe-round3'])]:
    for label in labels:
        P=base/label;report=load(P/'report.json');assert report['passed'] is False
        if 'backup' in report:
            assert report['restored'] and report['originalApksRestored'] and report['blurRestored']
            assert report['originalInstalledPackages']==report['restoredInstalledPackages']
            assert home.inventory(P/'private-data-before.tar',True)==home.inventory(P/'private-data-restored.tar',True)
        actual_tests=0
        if (P/'native.log').exists():
            raw=(P/'native.log').read_text(encoding='utf-8')
            assert 'Tests run: 1,  Failures: 1' in raw and '引导就绪: {}' in raw
            actual_tests=1
        failed.append({'lane':'release' if base==S else 'debug-control','case':label,
            'error':report['error'],'actualDeviceTestsExecuted':actual_tests,
            'restored':report.get('restored',False),'rejectedBeforeInstall':label=='baseline-supported'})
assert [x['actualDeviceTestsExecuted'] for x in failed]==[0,0,0,1,1,1]
# Cross-check actual DEX class definitions, rather than references or strings.
producer=(B/'build-rf312-release-probe-20261012.py').read_text(encoding='utf-8')
fn=next(x for x in ast.parse(producer).body if isinstance(x,ast.FunctionDef) and x.name=='dex_classes')
ns={'struct':struct};exec(compile(ast.get_source_segment(producer,fn),'<dex-class-reader>','exec'),ns)
class_rows=[]
for name,row in [('original-debug',inputs['originalDebug']),('release',inputs['release']['apk']),
                 ('original-test',inputs['originalTest']),('aligned-probe',inputs['runtimeTest'])]:
    classes=[]
    with zipfile.ZipFile(Path(row.get('path',row.get('copy')))) as z:
        for entry in z.namelist():
            if re.fullmatch(r'classes\d*\.dex',entry):classes+=ns['dex_classes'](z.read(entry))
    has='Landroidx/tracing/Trace;' in classes
    if name=='aligned-probe':
        assert has and 'Lcom/solosoul/app/AndroidHomeInstrumentedTest;' in classes
        assert 'Lcom/solosoul/app/MainActivity;' not in classes
        assert not any(c.startswith(('Lapp/tauri/','Landroidx/startup/','Landroidx/profileinstaller/')) for c in classes)
    if name in ['release','original-test']:assert not has
    if name=='original-debug':assert has
    class_rows.append({'artifact':name,'definedClassCount':len(classes),'traceOriginalNameDefined':has})
builds=[load(B/'rf312-release-probe-build-20261012/probe-build.receipt.json')['exitCode'],
        load(D/'probe-build.receipt.json')['exitCode']]
builds += [load(D/f'probe-build-round{i}.receipt.json')['exitCode'] for i in [3,4,5,6]]
assert builds==[1,1,1,1,0,0]
save(S/'independent-verification.json',{'acceptedReleaseFunctionalBaseline':True,
    'scope':'same unchanged optimized non-debuggable x86_64 APK; API31 emulator baseline home in both material modes',
    'releaseNativeTests':2,'debugControlNativeTests':1,'successfulNativeTests':3,'skipped':0,
    'earlierExecutedDeviceTestsFailed':3,'earlierRunnerFailuresBeforeTestExecution':2,'preInstallRejections':1,
    'failedCasesRetained':failed,'acceptedCases':rows,'pngReadback':pngs,
    'allPngsVisuallyReviewed':False,'fullPerformanceBaselineAccepted':False,'physicalPerformanceAccepted':False,
    'fullRF121Accepted':False,'fullRF312Accepted':False,'sourceCount':1839,
    'productionSourcesAndReleaseBytesUnchanged':True,'probeGradleExitCodes':builds,
    'probeRound6OuterVerifierFilenameCollisionPreserved':True,'definedClasses':class_rows,
    'sourceHomeMethodByteIdenticalToCanonical':True,'allOriginalBudgetsAndAssertionsPreserved':True})
print('Independently accepted 2 Release native tests + 1 Debug control, all prior failures retained, complete APK/private/system restores',flush=True)
