from pathlib import Path
import hashlib,json
B=Path(__file__).parent;S=B/'rf312-android-release-native-20261012';C=B/'rf312-probe-debug-control-20261012'
C.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
inputs=load(S/'inputs.json');(C/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
before=(S/'release-home-native-driver.py').read_bytes();(C/'release-driver-before.py').write_bytes(before)
text=before.decode('utf-8')
old="Path(args.apk).resolve() != Path(frozen_inputs['release']['apk']['path']).resolve()"
new="Path(args.apk).resolve() != Path(frozen_inputs['originalDebug']['copy']).resolve()"
assert text.count(old)==1;text=text.replace(old,new)
old="current['sha256'] != frozen_inputs['release']['apk']['sha256'] or current['debuggable']"
new="current['sha256'] != frozen_inputs['originalDebug']['sha256'] or not current['debuggable']"
assert text.count(old)==1;text=text.replace(old,new)
text=text.replace("installed(APP, 'release-main')","installed(APP, 'debug-control-main')")
text=text.replace("report['releaseInstalledPackage']","report['debugControlInstalledPackage']")
text=text.replace('Exact non-debuggable Release package/UID verification failed','Exact original Debug control package/UID verification failed')
driver=C/'release-home-native-driver.py';compile(text,str(driver),'exec');driver.write_text(text,encoding='utf-8',newline='\n')
prep=load(S/'preparation.json');prep['derivedDriverSha256']=hashlib.sha256(driver.read_bytes()).hexdigest()
prep['scope']='Same independent test APK and unchanged home method against original Debug app; not Release acceptance'
(C/'preparation.json').write_text(json.dumps(prep,indent=2)+'\n',encoding='utf-8')
(C/'original-driver.py').write_bytes((S/'original-driver.py').read_bytes())
(C/'original-system.json').write_bytes((S/'original-system.json').read_bytes())
wrapper=(B/'run-rf312-release-home-20261012.py').read_text(encoding='utf-8')
assert wrapper.count("S=B/'rf312-android-release-native-20261012'")==1
wrapper=wrapper.replace("S=B/'rf312-android-release-native-20261012'","S=B/'rf312-probe-debug-control-20261012'")
assert wrapper.count("for mode in ['supported','fallback']:")==1
wrapper=wrapper.replace("for mode in ['supported','fallback']:","for mode in ['supported']:")
wrapper=wrapper.replace("inputs['release']['apk']['path'],\n        '--test-apk'","inputs['originalDebug']['copy'],\n        '--test-apk'")
wrapper=wrapper.replace("accepted=len(rows)==2","accepted=len(rows)==1")
wrapper=wrapper.replace('actual non-debuggable optimized x86_64 Release baseline production home in API31 AVD',
    'original Debug target control for identical standalone test APK and home method; no Release acceptance')
target=B/'run-rf312-probe-debug-control-20261012.py';compile(wrapper,str(target),'exec')
target.write_text(wrapper,encoding='utf-8',newline='\n')
print('Prepared one honest Debug control with unchanged standalone probe, same native method/budgets and full restore guards',flush=True)
