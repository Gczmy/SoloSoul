from pathlib import Path
B=Path(__file__).parent;S=B/'rf312-release-probe-build-round2-20261012'
source=B/'continue-rf312-release-probe-20261012.py'
(S/'continue-round3-producer.py').write_bytes(source.read_bytes())
for name in ['continuation-input.json','continuation-build-tail.py']:
    p=S/name;(S/('round3-'+name)).write_bytes(p.read_bytes())
text=source.read_text(encoding='utf-8')
assert text.count("run('probe-build-round3',")==1
text=text.replace("run('probe-build-round3',","run('probe-build-round4',")
source.write_text(text,encoding='utf-8',newline='\n')
print('Preserved round3 failure and actual compile dependency resolution; prepared offline round4',flush=True)
