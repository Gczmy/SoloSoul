from pathlib import Path
import datetime,hashlib,json,os,re,shutil,struct,subprocess,time,zipfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;N=B/'rf312-android-release-native-20261012'
S=B/'rf312-release-probe-build-round2-20261012';P=S/'project'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
inputs=load(N/'inputs.json');src=R/'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidHomeInstrumentedTest.kt'
def frozen():
    assert all(sha(R/n)==h for n,h in inputs['runtimeSourceFiles'].items())
    for row in [inputs['release']['apk'],inputs['originalDebug'],inputs['originalTest']]:
        assert sha(Path(row.get('path',row.get('copy'))))==row['sha256']
    assert sha(src)==sha(P/'src/main/java/com/solosoul/app'/src.name)
frozen();assert load(S/'probe-build-round6.receipt.json')['exitCode']==0
copy=S/'solosoul-releaseprobe-manifest-aligned.apk';assert copy.is_file()
metadata=load(P/'build/outputs/apk/debug/output-metadata.json')
assert len(metadata['elements'])==1
assert sha(copy)==sha(P/'build/outputs/apk/debug'/metadata['elements'][0]['outputFile'])
jdk=Path('C:/Users/40299571/ss-android/jdk');sdk=B/'sdk'
def run(label,command):
    began=time.monotonic()
    with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
        result=subprocess.run(command,cwd=P,stdout=out,stderr=err,timeout=90,creationflags=subprocess.CREATE_NO_WINDOW)
    frozen();save(S/(label+'.receipt.json'),{'command':command,'exitCode':result.returncode,
        'elapsedSeconds':time.monotonic()-began,'allSourcesAndOriginalApksUnchanged':True})
    assert result.returncode==0;print(label,'exit',result.returncode,flush=True)
tail=(S/'continuation-build-tail.py').read_text(encoding='utf-8')
(S/'round6-verifier-prefix-rejected.py').write_text(tail,encoding='utf-8')
tail=tail[tail.index("run('probe-badging'"):]
tail=tail.replace('probe-badging','probe-aligned-badging').replace('probe-signature','probe-aligned-signature')
(S/'aligned-probe-final-verifier-tail.py').write_text(tail,encoding='utf-8')
exec(compile(tail,str(S/'aligned-probe-final-verifier-tail.py'),'exec'))
classes=load(S/'dex-defined-classes.json')
assert not any(c.startswith(('Landroidx/startup/','Landroidx/profileinstaller/')) for c in classes)
manifest=P/'build/intermediates/merged_manifests/debug/processDebugManifest/AndroidManifest.xml'
text=manifest.read_text(encoding='utf-8')
assert '<provider' not in text and '<receiver' not in text and 'appComponentFactory' not in text
assert 'android:functionalTest="false"' in text
save(S/'alignment-verification.json',{'acceptedPackageAlignment':True,'manifestSha256':sha(manifest),
    'extraStartupProfileInstallerClassDefinitions':0,'extraProviders':0,'extraReceivers':0,
    'functionalTestFalseMatchesOriginalInstrumentation':True,'targetReleaseApkUnchanged':True,
    'nativeRuntimeAccepted':False})
print('Aligned test APK package/certificate/DEX/manifest independently verified; Gradle success retained, verifier filename collision preserved',flush=True)
