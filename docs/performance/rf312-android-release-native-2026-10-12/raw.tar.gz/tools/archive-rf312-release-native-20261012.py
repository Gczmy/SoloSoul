from pathlib import Path
import hashlib,io,json,tarfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf312-android-release-native-20261012'
C=B/'rf312-probe-debug-control-20261012';H=B/'api31-host-rf312-release-20261012'
D=B/'rf312-release-probe-build-round2-20261012';F=B/'rf312-release-probe-build-20261012'
O=R/'docs/performance/rf312-android-release-native-2026-10-12';O.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
v=load(S/'independent-verification.json');assert v['acceptedReleaseFunctionalBaseline']
assert load(H/'stop.receipt.json')['ownedProcessExited']
files={}
def add(p,name):
    assert p.is_file() and not p.is_symlink()
    assert p.suffix.lower() not in ['.tar','.apk','.so','.jar','.aar','.class','.zip','.keystore','.idsig']
    assert name not in files;files[name]=p.read_bytes()
for base,prefix in [(S,'native'),(C,'debug-control'),(H,'emulator')]:
    for p in sorted(base.rglob('*')):
        if p.is_file() and p.suffix.lower() in ['.json','.log','.py','.png','.xml']:
            add(p,prefix+'/'+p.relative_to(base).as_posix())
for base,prefix in [(F,'probe-build-first'),(D,'probe-build')]:
    for p in sorted(base.iterdir()):
        if p.is_file() and p.suffix.lower() in ['.json','.log','.py','.kts','.xml']:
            add(p,prefix+'/'+p.name)
    for folder in ['dependency-fetch','dependency-fetch-compile']:
        if (base/folder).exists():
            for p in sorted((base/folder).iterdir()):
                if p.is_file() and p.suffix.lower() in ['.json','.log','.gradle']:
                    add(p,prefix+'/'+folder+'/'+p.name)
    for rel in ['project/build.gradle.kts','project/gradle.properties','project/settings.gradle.kts',
                'project/src/main/AndroidManifest.xml',
                'project/src/main/java/com/solosoul/app/AndroidHomeInstrumentedTest.kt',
                'project/build/intermediates/merged_manifests/debug/processDebugManifest/AndroidManifest.xml',
                'project/build/outputs/apk/debug/output-metadata.json']:
        p=base/rel
        if p.exists():add(p,prefix+'/'+rel)
names=['prepare-rf312-release-native-20261012.py','boot-rf312-release-api31.py',
    'run-rf312-release-home-20261012.py','correct-rf312-release-preflight-20261012.py',
    'build-rf312-release-probe-20261012.py','retry-rf312-release-probe-20261012.py',
    'fetch-rf312-probe-dependencies-20261012.py','prepare-rf312-probe-compile-fetch-20261012.py',
    'fetch-rf312-probe-compile-dependencies-20261012.py','continue-rf312-release-probe-20261012.py',
    'prepare-rf312-probe-round4-20261012.py','prepare-rf312-probe-round5-20261012.py',
    'prepare-rf312-probe-native-20261012.py','prepare-rf312-probe-debug-control-20261012.py',
    'run-rf312-probe-debug-control-20261012.py','prepare-rf312-probe-manifest-alignment-20261012.py',
    'finalize-rf312-aligned-probe-20261012.py','prepare-rf312-aligned-native-20261012.py',
    'verify-rf312-release-native-20261012.py','finish-rf312-release-native-20261012.py']
for n in names:add(B/n,'tools/'+n)
add(Path(__file__),'tools/'+Path(__file__).name)
with tarfile.open(O/'raw.tar.gz','w:gz') as tar:
    for name,data in sorted(files.items()):
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
        tar.addfile(member,io.BytesIO(data))
index={'members':[{'path':n,'bytes':len(d),'sha256':sha(d)} for n,d in sorted(files.items())],
    'memberCount':len(files),'rawSha256':sha((O/'raw.tar.gz').read_bytes()),
    'rawBytes':(O/'raw.tar.gz').stat().st_size,'privateTarApkJarNativeLibrariesKeystoreExcluded':True,
    'allMembersReadBackVerified':False}
with tarfile.open(O/'raw.tar.gz') as tar:
    assert len(tar.getmembers())==len(files)
    for member in tar:
        data=tar.extractfile(member).read();assert data==files[member.name]
index['allMembersReadBackVerified']=True
(O/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
(O/'.gitattributes').write_text('raw.tar.gz -text\n*.json text eol=lf\n',encoding='utf-8')
summary={k:value for k,value in v.items() if k not in ['pngReadback','acceptedCases','failedCasesRetained']}
summary.update(acceptedCases=v['acceptedCases'],failedCasesRetained=v['failedCasesRetained'],
    readBackPngCount=len(v['pngReadback']),visualReview=load(S/'visual-review.json'),
    signedReleaseApk=load(S/'inputs.json')['release']['apk'],signedProbe=load(D/'current-test-apk.json'),
    allEightBackupPairsVerified=load(S/'private-pairs-verification.json'),
    ownedEmulatorStop=load(H/'stop.receipt.json'),archive=index,
    taskClosed=False,commitCreated=False,scopeAtArchiveCreation=True)
(R/'docs/performance/rf312-android-release-native-2026-10-12.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print('Archived and read-back verified',len(files),'members;',index['rawBytes'],'bytes; private data and binaries excluded',flush=True)
