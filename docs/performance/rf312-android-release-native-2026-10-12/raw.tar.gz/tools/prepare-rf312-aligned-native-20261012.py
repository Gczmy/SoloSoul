from pathlib import Path
import json,hashlib
B=Path(__file__).parent;D=B/'rf312-release-probe-build-round2-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
probe=load(D/'current-test-apk.json')
assert probe['path'].endswith('solosoul-releaseprobe-manifest-aligned.apk') and probe['acceptedPackagePreparation']
assert hashlib.sha256(Path(probe['path']).read_bytes()).hexdigest()==probe['sha256']
for name,script in [('rf312-android-release-native-20261012','run-rf312-release-home-20261012.py'),
                    ('rf312-probe-debug-control-20261012','run-rf312-probe-debug-control-20261012.py')]:
    S=B/name
    for file in ['inputs.json','preparation.json','verification.json','progress.json','owned-emulator-preflight.json']:
        p=S/file;(S/('pre-alignment-'+file)).write_bytes(p.read_bytes())
    p=S/'inputs.json';inputs=load(p);inputs['runtimeTest']=probe
    p.write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
    p=S/'preparation.json';value=load(p);value['runtimeProbeSha256']=probe['sha256']
    value['probeManifestAlignedWithOriginalInstrumentation']=True
    value['extraProbeStartupAndProfileInstallerRuntimeRemoved']=True
    p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
    source=B/script;(S/'run-pre-alignment.py').write_bytes(source.read_bytes())
    text=source.read_text(encoding='utf-8');assert text.count("label='baseline-'+mode+'-probe-round3'")==1
    text=text.replace("label='baseline-'+mode+'-probe-round3'","label='baseline-'+mode+'-probe-aligned-round4'")
    source.write_text(text,encoding='utf-8',newline='\n')
print('Prepared new named Debug/Release cases with aligned probe; prior runner failures preserved',flush=True)
