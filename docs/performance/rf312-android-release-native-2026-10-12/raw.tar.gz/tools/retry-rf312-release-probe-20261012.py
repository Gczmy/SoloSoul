from pathlib import Path
B=Path(__file__).parent
source=B/'build-rf312-release-probe-20261012.py'
old=source.read_bytes()
(B/'rf312-release-probe-build-20261012/producer-first-rejected.py').write_bytes(old)
text=old.decode('utf-8')
old_name="S=B/'rf312-release-probe-build-20261012';S.mkdir(exist_ok=False)"
assert text.count(old_name)==1
text=text.replace(old_name,"S=B/'rf312-release-probe-build-round2-20261012';S.mkdir(exist_ok=False)")
needle="(P/'settings.gradle.kts').write_text('rootProject.name = \"SoloSoulReleaseNativeProbe\"\\n',encoding='utf-8')"
assert text.count(needle)==1
text=text.replace(needle,needle+"\n(P/'gradle.properties').write_text('android.useAndroidX=true\\norg.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\\nkotlin.daemon.jvmargs=-Xmx768m\\n',encoding='utf-8')")
needle="apk=P/'build/outputs/apk/debug/project-debug.apk'\nassert apk.is_file();copy=S/'solosoul-releaseprobe.apk';shutil.copyfile(apk,copy)"
replacement="metadata=load(P/'build/outputs/apk/debug/output-metadata.json')\nassert len(metadata['elements'])==1\napk=P/'build/outputs/apk/debug'/metadata['elements'][0]['outputFile']\nassert apk.is_file();copy=S/'solosoul-releaseprobe.apk';shutil.copyfile(apk,copy)"
assert text.count(needle)==1;text=text.replace(needle,replacement)
compile(text,str(source),'exec');source.write_text(text,encoding='utf-8',newline='\n')
print('Preserved independent project build failure; enabled the required AndroidX property in a new project',flush=True)
