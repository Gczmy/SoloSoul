from pathlib import Path
import datetime, hashlib, json, os, subprocess, threading, time

R = Path('D:/SoloSoul')
S = Path(__file__).parent/'memory-100-capability'
B = R/'build/android-native-feasibility-20261010'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
inputs = load(S/'inputs.json')
adb = str(B/'sdk/platform-tools/adb.exe')
prefix = [adb, '-H', 'localhost', '-P', '5049', '-s', 'emulator-5586']
assert subprocess.check_output(prefix+['emu','avd','name'], text=True).splitlines()[0] == 'SoloSoul_RF121_API31_20261010'
raw = S/'memory-raw'
raw.mkdir(exist_ok=False)
stop = threading.Event()
rows = []
def sampler():
    n = 0
    while not stop.is_set():
        n += 1
        folder = raw/f'{n:03d}'
        folder.mkdir()
        row = {'ordinal': n, 'hostStartedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commands': []}
        began = time.monotonic()
        try:
            for label, command in [
                ('processes', ['shell','dumpsys','activity','processes']),
                ('services', ['shell','dumpsys','activity','services','com.android.webview']),
                ('meminfo-package', ['shell','dumpsys','meminfo','com.solosoul.app']),
                ('ps', ['shell','ps','-A','-o','UID,PID,PPID,NAME,ARGS']),
            ]:
                at = time.monotonic()
                result = subprocess.run(prefix+command, stdin=subprocess.DEVNULL, capture_output=True, timeout=8)
                (folder/(label+'.stdout.txt')).write_bytes(result.stdout)
                (folder/(label+'.stderr.txt')).write_bytes(result.stderr)
                row['commands'].append({'label': label, 'command': command, 'exitCode': result.returncode,
                                        'elapsedMs': (time.monotonic()-at)*1000})
                if result.returncode:
                    raise RuntimeError('read-only-memory-command-failed:'+label)
        except Exception as error:
            row['error'] = str(error)
        row['elapsedMs'] = (time.monotonic()-began)*1000
        (folder/'receipt.json').write_text(json.dumps(row, indent=2)+'\n', encoding='utf-8')
        rows.append(row)
        stop.wait(5)
env = os.environ.copy()
env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',TEMP=str(B/'tmp'),TMP=str(B/'tmp'),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
command = ['C:/Python314/python.exe', str(S/'media-native-driver.py'), '--adb', adb,
    '--serial','emulator-5586','--avd','SoloSoul_RF121_API31_20261010','--apk',inputs['release']['apk']['path'],
    '--test-apk',inputs['runtimeTest']['path'],'--restore-apk',inputs['originalDebug']['copy'],
    '--output',str(S/'journey'),'--mode','supported','--scenario','baseline','--object-count','100','--fixture',inputs['fixedFixtures']['100']['root']]
thread = threading.Thread(target=sampler)
thread.start()
code = None
try:
    with (S/'journey.stdout.log').open('xb') as out, (S/'journey.stderr.log').open('xb') as err:
        p = subprocess.Popen(command, cwd=R, env=env, stdin=subprocess.DEVNULL, stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
        (S/'live.json').write_text(json.dumps({'pid':p.pid,'command':command})+'\n', encoding='utf-8')
        print('Memory capability journey started PID',p.pid, flush=True)
        code = p.wait()
finally:
    stop.set()
    thread.join()
    receipt = {'driverExitCode': code, 'readOnlyMemorySnapshots': len(rows), 'snapshotErrors': [r for r in rows if 'error' in r],
               'currentMainPerformanceAccepted': False, 'wholeRF312Accepted': False,
               'samplingDefinition': 'serial read-only dumpsys, with five seconds between query groups; exploratory ownership capability only'}
    (S/'terminal.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(receipt), flush=True)
raise SystemExit(code if code is not None else 1)
