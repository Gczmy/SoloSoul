from pathlib import Path
import json

B = Path(__file__).parent.resolve()
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
analysis = load(B/'analysis.json')
assert len(analysis['restorationAudit']) == 3
removed = []
for audit in analysis['restorationAudit']:
    assert audit['allContentsLinksModesMatch'] and audit['entries'] == 216
    root = B/audit['name']/'journey'
    for name in ['private-data-before.tar','private-data-restored.tar']:
        target = root/name
        assert target.resolve().is_relative_to(B) and target.parent.parent.name == audit['name']
        assert target.is_file() and not target.is_symlink()
        target.unlink()
        removed.append(str(target.relative_to(B)))
(B/'private-backup-cleanup.json').write_text(json.dumps(dict(removed=removed,independentlyVerifiedPairs=3,privateArchivesExcludedFromGit=True),indent=2)+'\n',encoding='utf-8')
print('Removed six exact private TAR files after independent 216-entry restoration verification for all three attempts')
