from pathlib import Path
import importlib.util, json, os, subprocess, sys, threading, time

R = Path('D:/SoloSoul')
count = int(sys.argv[1])
assert count in [100,5000]
S = Path(__file__).parent/f'memory-{count}-local'
B = R/'build/android-native-feasibility-20261010'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
inputs = load(S/'inputs.json')
adb = str(B/'sdk/platform-tools/adb.exe')
spec = importlib.util.spec_from_file_location('memory', R/'tauri/scripts/android-process-memory.py')
memory = importlib.util.module_from_spec(spec)
spec.loader.exec_module(memory)
raw = S/'memory-raw'
raw.mkdir(exist_ok=False)
stop = threading.Event()
rows = []
def sampler():
    ordinal = 0
    while not stop.is_set():
        ordinal += 1
        folder = raw/f'{ordinal:03d}'
        began = time.monotonic()
        try:
            run = memory.AdbRunner(adb,'emulator-5586','SoloSoul_RF121_API31_20261010',folder)
            row = memory.collect_snapshot(run,'com.solosoul.app',10105,'com.android.webview')
        except Exception as error:
            row = {'fullProcessScopeAccepted':False,'error':str(error)}
        row['ordinal'] = ordinal
        row['hostStartedAtMonotonic'] = began
        row['samplerElapsedMs'] = (time.monotonic()-began)*1000
        (folder/'result.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
        rows.append(row)
        stop.wait(5)
env = os.environ.copy()
env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',TEMP=str(B/'tmp'),TMP=str(B/'tmp'),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
command = ['C:/Python314/python.exe',str(S/'media-native-driver.py'),'--adb',adb,
    '--serial','emulator-5586','--avd','SoloSoul_RF121_API31_20261010','--apk',inputs['release']['apk']['path'],
    '--test-apk',inputs['runtimeTest']['path'],'--restore-apk',inputs['originalDebug']['copy'],
    '--output',str(S/'journey'),'--mode','supported','--scenario','baseline','--object-count',str(count),'--fixture',inputs['fixedFixtures'][str(count)]['root']]
thread = threading.Thread(target=sampler)
thread.start()
code = None
try:
    with (S/'journey.stdout.log').open('xb') as out,(S/'journey.stderr.log').open('xb') as err:
        p = subprocess.Popen(command,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        (S/'live.json').write_text(json.dumps({'pid':p.pid,'command':command})+'\n',encoding='utf-8')
        print('Local-only memory journey started',count,'PID',p.pid,flush=True)
        code = p.wait()
finally:
    stop.set()
    thread.join()
    complete = [row for row in rows if row.get('fullProcessScopeAccepted')]
    terminal = dict(objectCount=count,driverExitCode=code,totalSnapshots=len(rows),completeOwnedSnapshots=len(complete),
        incompleteSnapshots=[row for row in rows if not row.get('fullProcessScopeAccepted')],
        currentMainPerformanceAccepted=False,wholeRF312Accepted=False,
        samplingDefinition='--local -s per actual owned PID, serial samples with five seconds between groups; same frozen prior APK')
    (S/'terminal.json').write_text(json.dumps(terminal,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in terminal.items() if k!='incompleteSnapshots'}),flush=True)
raise SystemExit(code if code is not None else 1)
