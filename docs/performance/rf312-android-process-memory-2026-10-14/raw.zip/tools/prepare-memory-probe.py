from pathlib import Path
import hashlib, json

R = Path('D:/SoloSoul')
B = R/'build/android-native-feasibility-20261010'
SOURCE = B/'rf312-merged-repeat-100-001-20261012'
S = R/'build/goal-resume-20261014/memory-100-capability'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
old = load(SOURCE/'inputs.json')
for row in [old['release']['apk'], old['runtimeTest'], old['originalDebug'], old['originalTest']]:
    assert sha(Path(row.get('path', row.get('copy')))) == row['sha256']
S.mkdir(exist_ok=False)
changes = []
now = {}
for name, digest in old['runtimeSourceFiles'].items():
    now[name] = sha(R/name)
    if now[name] != digest:
        changes.append({'path': name, 'originalRuntimeGuardSha256': digest, 'currentGuardSha256': now[name]})
for name in ['media-native-driver.py', 'AndroidMediaPerfInstrumentedTest.kt', 'verify-finger-readiness.py']:
    (S/name).write_bytes((SOURCE/name).read_bytes())
inputs = dict(old)
inputs['runtimeSourceFiles'] = now
inputs['memoryDiagnosticProvenance'] = {'mainApkRebuilt': False, 'currentMainPerformanceAccepted': False,
    'runtimeGuardSourceDifferences': changes, 'originalInputsSha256': sha(SOURCE/'inputs.json'),
    'scope': 'same frozen prior APK, exact current repository tool guards; capability diagnostic only'}
(S/'inputs.json').write_text(json.dumps(inputs, indent=2)+'\n', encoding='utf-8')
(S/'original-inputs.json').write_bytes((SOURCE/'inputs.json').read_bytes())
(S/'source-provenance.json').write_text(json.dumps(inputs['memoryDiagnosticProvenance'], indent=2)+'\n', encoding='utf-8')
print(json.dumps({'prepared': str(S), 'sourceGuardDifferences': len(changes), 'currentMainPerformanceAccepted': False}))
