from pathlib import Path
import hashlib, json, sys

R = Path('D:/SoloSoul')
SOURCE = R/'build/goal-resume-20261014/memory-100-capability'
count = int(sys.argv[1])
assert count in [100,5000]
S = SOURCE.parent/f'memory-{count}-local'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
old = load(SOURCE/'original-inputs.json')
S.mkdir(exist_ok=False)
inputs = dict(old)
inputs['runtimeSourceFiles'] = {name: sha(R/name) for name in old['runtimeSourceFiles']}
for name in ['tauri/scripts/android-process-memory.py','tauri/scripts/test_android_process_memory.py']:
    inputs['runtimeSourceFiles'][name] = sha(R/name)
inputs['memoryDiagnosticProvenance'] = load(SOURCE/'source-provenance.json')
inputs['memoryDiagnosticProvenance']['sameFrozenPriorApk'] = True
inputs['memoryDiagnosticProvenance']['memoryToolSourceHashes'] = {name: inputs['runtimeSourceFiles'][name] for name in inputs['runtimeSourceFiles'] if 'android_process_memory' in name or 'android-process-memory' in name}
for name in ['media-native-driver.py','AndroidMediaPerfInstrumentedTest.kt','verify-finger-readiness.py','original-inputs.json']:
    (S/name).write_bytes((SOURCE/name).read_bytes())
(S/'inputs.json').write_text(json.dumps(inputs, indent=2)+'\n', encoding='utf-8')
print('Prepared same frozen APK and current tool guards for', count, flush=True)
