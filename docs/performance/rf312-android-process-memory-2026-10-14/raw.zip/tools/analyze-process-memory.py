from pathlib import Path
import hashlib, importlib.util, json, re

R = Path('D:/SoloSoul')
B = Path(__file__).parent.resolve()
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('memory', R/'tauri/scripts/android-process-memory.py')
memory = importlib.util.module_from_spec(spec)
spec.loader.exec_module(memory)
restore_spec = importlib.util.spec_from_file_location('restore', R/'tauri/scripts/android-home-native-regression.py')
restore = importlib.util.module_from_spec(restore_spec)
restore_spec.loader.exec_module(restore)
expected_phases = ['activity-startup','password-unlock','first-ocr-user-flow','workspace','search-needle','attachments-open',
    'image-preview','text-preview','pdf-text-native-diagnostic','pdf-scanned-native-diagnostic','application-lock','password-reunlock']
groups = []
restorations = []
for name in ['memory-100-capability','memory-100-local','memory-5000-local']:
    root = B/name
    terminal = load(root/'terminal.json')
    driver = load(root/'journey/report.json')
    assert all(driver.get(key) is True for key in ['restored','originalApksRestored','ownedProbeRemoved','blurRestored','ownedPublicOcrInputRemoved','frozenInputsUnchanged'])
    before = root/'journey/private-data-before.tar'
    after = root/'journey/private-data-restored.tar'
    if before.exists():
        entries = restore.inventory(before, require_empty=True)
        assert entries == restore.inventory(after, require_empty=True)
        audit = dict(name=name,entries=len(entries),allContentsLinksModesMatch=True,beforeSha256=sha(before),afterSha256=sha(after))
        (root/'independent-restoration-audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
    else:
        audit = load(root/'independent-restoration-audit.json')
    restorations.append(audit)
    if name.endswith('capability'):
        assert terminal['driverExitCode'] == 1 and not driver['passed']
        continue
    assert terminal['driverExitCode'] == 0 and driver['passed']
    inputs = load(root/'inputs.json')
    for filename,digest in inputs['memoryDiagnosticProvenance']['memoryToolSourceHashes'].items():
        assert sha(R/filename) == digest
    evidence = load(root/'journey/device-files/report.json')
    assert evidence['success'] and [p['name'] for p in evidence['phases']] == expected_phases
    assert all(p['success'] for p in evidence['phases']) and evidence['uid'] == 10105
    assert evidence['nativeClock'] == 'Android elapsedRealtimeNanos; not converted to document clock'
    start = evidence['phases'][0]['nativeStartedAtNs']/1e6
    finish = evidence['phases'][-1]['nativeFinishedAtNs']/1e6
    rows = []
    incomplete = []
    complete_outside = []
    for folder in sorted((root/'memory-raw').iterdir()):
        result = load(folder/'result.json')
        commands = load(folder/'commands.json')
        first = commands[0]['command']
        assert first == ['emu','avd','name'] and commands[0]['exitCode'] == 0
        assert (folder/'001.stdout.txt').read_text(encoding='utf-8').splitlines()[0] == 'SoloSoul_RF121_API31_20261010'
        if not result.get('fullProcessScopeAccepted'):
            incomplete.append(dict(ordinal=result['ordinal'],state=result.get('state'),error=result.get('error')))
            continue
        pending = list(enumerate(commands[1:],start=2))
        mem_headers = []
        def replay(*command):
            ordinal,row = pending.pop(0)
            assert row['command'] == list(command) and row['exitCode'] == 0
            raw = (folder/f'{ordinal:03d}.stdout.txt').read_text(encoding='utf-8')
            if 'meminfo' in command:
                assert command[:5] == ('shell','dumpsys','meminfo','--local','-s')
                header = re.search(r'^Uptime: (\d+) Realtime: (\d+)$',raw,re.M)
                assert header
                mem_headers.append(int(header.group(2)))
            return raw
        replayed = memory.collect_snapshot(replay,'com.solosoul.app',10105,'com.android.webview')
        assert not pending and replayed['fullProcessScopeAccepted']
        for key in ['state','scope','pssBytes','fullProcessScopeAccepted']:
            assert replayed[key] == result[key]
        strip = lambda values: [{k:v for k,v in row.items() if k!='collectionMs'} for row in values]
        assert strip(replayed['processes']) == strip(result['processes'])
        app = [row for row in result['processes'] if row['role']=='app']
        assert len(app) == 1 and app[0]['pid'] == evidence['processId']
        sample = dict(ordinal=result['ordinal'],pssBytes=result['pssBytes'],mainPssBytes=app[0]['pssBytes'],
                      rendererPssBytes=sum(row['pssBytes'] for row in result['processes'] if row['role']=='renderer'),
                      rendererCount=sum(row['role']=='renderer' for row in result['processes']),
                      collectionMs=result['collectionMs'],samplerElapsedMs=result['samplerElapsedMs'],
                      dumpHeaderRealtimeMs=mem_headers)
        if not all(start <= stamp <= finish for stamp in mem_headers):
            complete_outside.append(sample)
        else:
            rows.append(sample)
    assert rows and len(rows)+len(complete_outside) == terminal['completeOwnedSnapshots']
    groups.append(dict(objectCount=terminal['objectCount'],actualExitCode=terminal['driverExitCode'],full12NativePhasesPassed=True,
        requestedJourneySamples=1,totalSnapshotAttempts=terminal['totalSnapshots'],validNativeJourneySnapshots=len(rows),
        samples=rows,acceptedIdentitySnapshotsOutsideNativeJourney=complete_outside,incompleteSnapshots=incomplete,
        maximumSampledCombinedPssBytes=max(row['pssBytes'] for row in rows),
        maximumSnapshotCollectionMs=max(row['collectionMs'] for row in rows),
        maximumOuterSamplerMs=max(row['samplerElapsedMs'] for row in rows),
        mainApkSha256=inputs['release']['apk']['sha256'],testApkSha256=inputs['runtimeTest']['sha256'],
        memoryToolSourceHashes=inputs['memoryDiagnosticProvenance']['memoryToolSourceHashes']))
assert len(groups)==2 and groups[0]['mainApkSha256']==groups[1]['mainApkSha256']
summary=dict(task='RF-312',acceptedScope='API31 frozen prior optimized APK: safe local-only owned app/renderer sampler capability',
    wholeRF312Accepted=False,currentMainPerformanceAccepted=False,initialRemoteDumpDiagnosticFailed=True,
    oldFailuresRetained=True,groups=groups,restorationAudit=restorations,
    limits=['one complete native journey each, not a repeated distribution','same prior APK, not current main',
            'serial process reads, not an atomic snapshot or continuous peak','app includes test runner; query/instrument overhead remains',
            'shared provider service and zygote/system processes excluded','software emulator, no physical hardware claim'],
    remaining=['current source Android build and repeated full-process memory','event/owner attribution of listen/unlisten',
               'instrumentation overhead and process cold start','physical hardware and other platforms','stable IME exit capture'])
(B/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'groups':[dict(objectCount=g['objectCount'],validSnapshots=g['validNativeJourneySnapshots'],maxPssBytes=g['maximumSampledCombinedPssBytes']) for g in groups],
                  'restorationPairs':len(restorations),'wholeRF312Accepted':False}))
