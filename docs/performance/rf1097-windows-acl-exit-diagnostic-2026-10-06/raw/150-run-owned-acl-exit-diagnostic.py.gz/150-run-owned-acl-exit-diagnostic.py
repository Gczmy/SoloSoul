from pathlib import Path
import json,hashlib,subprocess,sys,os,time,datetime
from verify_auth_freezes import verify_sources
sys.stdout.reconfigure(encoding='utf-8')
s=Path(__file__).parent;r=Path(r'C:\Users\40299571\SoloSoul')
pwsh=r'C:\Users\40299571\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def new(name,value):
 p=s/name;assert not p.exists(),name
 with p.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def freezes():
 verify_sources(s,r)
 for name in ['cli-source-freeze.json','frontend-freeze.json']:assert all(sha(r/p)==h for p,h in load(s/name)['files'].items()),name
 for name in ['public-source-freeze.json','previous-build-freeze.json']:assert all(sha(Path(p))==h for p,h in load(s/name)['files'].items()),name
 for row in load(s/'resource-freeze.json')['records']:assert sha(Path(row['source']))==row['sha256']==sha(Path(row['copy']))
 for name in ['baseline-build-checkpoint.json','build-checkpoint.json']:
  b=load(s/name);assert sha(Path(b['exe']))==b['sha256']
def preserved():
 files={}
 for group in ['legacy100','windowless100','windowless5000','legacy5000']:
  root=s/group
  for p in root.glob('*.json'):files[str(p.relative_to(s))]=sha(p)
  for rootSample in root.glob('sample-???'):
   for p in rootSample.glob('*.json'):files[str(p.relative_to(s))]=sha(p)
   p=rootSample/'app-data/logs/app.log'
   if p.is_file():files[str(p.relative_to(s))]=sha(p)
 for name in ['interrupted-legacy5000-review-diagnostic.json','interrupted-legacy5000-acl-diagnostic.json','permissions-before-rf1097.rs']:
  files[name]=sha(s/name)
 return files
def spawn(name,args,env):
 out=(s/(name+'.stdout.log')).open('xb');err=(s/(name+'.stderr.log')).open('xb')
 p=subprocess.Popen(args,cwd=r/'tauri',env=env,stdout=out,stderr=err)
 new(name+'.live.json',dict(command=args,pid=p.pid,at=now()))
 print('Started '+name+' PID '+str(p.pid),flush=True)
 return p,out,err,time.monotonic(),args
def receipt(name,run):
 p,out,err,start,args=run;rc=p.wait();out.close();err.close()
 new(name+'.receipt.json',dict(command=args,pid=p.pid,exitCode=rc,elapsedSeconds=time.monotonic()-start,at=now()))
 print(name+' exit '+str(rc),flush=True);return rc
assert load(s/'required-checks.json')['success']
assert load(s/'interrupted-legacy5000-review-diagnostic.json')['stageAccepted'] is False
assert not (s/'legacy5000-exit-diagnostic-01').exists()
freezes();before=preserved();new('owned-acl-exit-original-records-freeze.json',dict(at=now(),files=before,failedGroupPreserved=True))
helperHashes={name:sha(s/name) for name in ['owned-acl-exit-observer.cs','owned-acl-exit-observer.ps1','run-owned-acl-exit-diagnostic.py']}
new('owned-acl-exit-helper-freeze.json',dict(at=now(),files=helperHashes,purpose='Bounded exact old GUI child exit diagnostic',originalFailureAccepted=False,performanceAccepted=False))
env=os.environ.copy();env.pop('PDFIUM_LIBRARY_PATH',None);env['CARGO_BUILD_JOBS']='2';env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','')
probe=spawn('owned-acl-exit-capability-probe',[pwsh,'-NoProfile','-NonInteractive','-File',str(s/'owned-acl-exit-observer.ps1'),'-Mode','probe'],env)
if receipt('owned-acl-exit-capability-probe',probe):raise SystemExit('Read-only capability probe failed; no GUI launch')
assert load(s/'owned-acl-exit-capability.json')['success']
observer=spawn('owned-acl-exit-observer-run',[pwsh,'-NoProfile','-NonInteractive','-File',str(s/'owned-acl-exit-observer.ps1'),'-Mode','observe'],env)
ready=s/'owned-acl-exit-observer.ready.json';deadline=time.monotonic()+30
while not ready.exists():
 if observer[0].poll() is not None:receipt('owned-acl-exit-observer-run',observer);raise SystemExit('Observer failed before ready; no GUI launch')
 if time.monotonic()>deadline:raise SystemExit('Observer readiness timed out; live handle must be inspected; no GUI launch')
 time.sleep(.05)
assert load(ready)['pid']==observer[0].pid and load(ready)['group']=='legacy5000-exit-diagnostic-01'
assert all(sha(s/name)==h for name,h in helperHashes.items())
build=load(s/'baseline-build-checkpoint.json');fixture=Path(r'C:\Users\40299571\AppData\Local\Temp\solosoul-rf312-native-fixtures-20260930\vault5000')
args=['node','scripts/native-perf-auth-attribution.mjs','--exe',build['exe'],'--fixture',str(fixture),'--output',str(s/'legacy5000-exit-diagnostic-01'),'--samples','3']
driver=spawn('legacy-exit-diagnostic5000',args,env);driverCode=receipt('legacy-exit-diagnostic5000',driver)
new('owned-acl-exit-driver.done.json',dict(at=now(),driverPid=driver[0].pid,driverExitCode=driverCode,diagnosticOnly=True,performanceAccepted=False))
observerCode=receipt('owned-acl-exit-observer-run',observer)
freezes();assert preserved()==before;assert all(sha(s/name)==h for name,h in helperHashes.items())
new('owned-acl-exit-diagnostic-freeze-result.json',dict(at=now(),sourceAndResourcesPreserved=True,originalProofsAndFailurePreserved=True,originalProofCount=len(before),driverExitCode=driverCode,observerExitCode=observerCode,helperHashesPreserved=True,originalFailedGroupAccepted=False,applicationPerformanceAccepted=False,groupRerunForGreen=False,newGroupPurpose='actual owned child exit status diagnosis only'))
if driverCode or observerCode:raise SystemExit(1)
d=load(s/'owned-acl-exit-observer.result.json');print(json.dumps({'diagnosticComplete':d['success'],'ownedParents':len(d['parentRecords']),'childExitCodes':[x['exitCodeHex'] for x in d['childRecords']],'originalFailureAccepted':False,'applicationPerformanceAccepted':False}),flush=True)
