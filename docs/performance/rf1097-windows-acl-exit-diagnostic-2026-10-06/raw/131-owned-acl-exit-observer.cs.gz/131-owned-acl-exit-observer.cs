using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
public static class RF1097ReadOnlyProcess {
 [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
 public struct Entry { public uint size, usage, pid; public UIntPtr heap; public uint module, threads, parent; public int priority; public uint flags; [MarshalAs(UnmanagedType.ByValTStr, SizeConst=260)] public string name; }
 public sealed class Row { public int pid, parent; }
 public sealed class ProcessHandle : IDisposable {
  internal IntPtr handle;
  public int pid;
  public long birth;
  public string executable;
  public uint? ExitStatus() { uint wait=WaitForSingleObject(handle,0); if(wait==258)return null; if(wait!=0)throw new Win32Exception(Marshal.GetLastWin32Error(),"Process wait failed"); uint code; if(!GetExitCodeProcess(handle,out code))throw new Win32Exception(Marshal.GetLastWin32Error(),"Process exit query failed"); return code; }
  public long ExitFileTime() { long c,e,k,u; if(!GetProcessTimes(handle,out c,out e,out k,out u))throw new Win32Exception(Marshal.GetLastWin32Error(),"Process times query failed"); if(c!=birth)throw new InvalidOperationException("Handle identity changed"); return e; }
  public void Dispose() { if(handle!=IntPtr.Zero){CloseHandle(handle);handle=IntPtr.Zero;} }
 }
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr OpenProcess(uint rights,bool inherit,int pid);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool CloseHandle(IntPtr handle);
 [DllImport("kernel32.dll",SetLastError=true)] static extern uint WaitForSingleObject(IntPtr handle,uint timeout);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetExitCodeProcess(IntPtr handle,out uint code);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool GetProcessTimes(IntPtr handle,out long creation,out long exit,out long kernel,out long user);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool QueryFullProcessImageNameW(IntPtr handle,uint flags,StringBuilder name,ref uint size);
 [DllImport("kernel32.dll",SetLastError=true)] static extern IntPtr CreateToolhelp32Snapshot(uint flags,uint pid);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool Process32FirstW(IntPtr snapshot,ref Entry entry);
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool Process32NextW(IntPtr snapshot,ref Entry entry);
 public static ProcessHandle OpenVerified(int pid,string executable,long minimumBirth) {
  IntPtr h=OpenProcess(0x00101000,false,pid); // QUERY_LIMITED_INFORMATION | SYNCHRONIZE only.
  if(h==IntPtr.Zero)throw new Win32Exception(Marshal.GetLastWin32Error(),"Read-only process open failed");
  try { uint size=32768; var path=new StringBuilder((int)size); if(!QueryFullProcessImageNameW(h,0,path,ref size))throw new Win32Exception(Marshal.GetLastWin32Error(),"Executable query failed");
   if(!String.Equals(path.ToString(),executable,StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Executable identity rejected");
   long c,e,k,u;if(!GetProcessTimes(h,out c,out e,out k,out u))throw new Win32Exception(Marshal.GetLastWin32Error(),"Birth query failed");
   if(c<minimumBirth || c>DateTime.UtcNow.ToFileTimeUtc())throw new InvalidOperationException("Birth identity rejected");
   var result=new ProcessHandle{handle=h,pid=pid,birth=c,executable=path.ToString()};h=IntPtr.Zero;return result;
  } finally { if(h!=IntPtr.Zero)CloseHandle(h); }
 }
 public static Row[] Children(int[] parents,string executableName) {
  var result=new List<Row>();if(parents.Length==0)return result.ToArray();var allowed=new HashSet<int>(parents);
  IntPtr snapshot=CreateToolhelp32Snapshot(2,0);if(snapshot==new IntPtr(-1))throw new Win32Exception(Marshal.GetLastWin32Error(),"Process snapshot failed");
  try { var e=new Entry{size=(uint)Marshal.SizeOf(typeof(Entry))};if(!Process32FirstW(snapshot,ref e))throw new Win32Exception(Marshal.GetLastWin32Error(),"First process snapshot failed");
   do { if(allowed.Contains((int)e.parent) && String.Equals(e.name,executableName,StringComparison.OrdinalIgnoreCase))result.Add(new Row{pid=(int)e.pid,parent=(int)e.parent}); } while(Process32NextW(snapshot,ref e));
   int error=Marshal.GetLastWin32Error();if(error!=18)throw new Win32Exception(error,"Next process snapshot failed");return result.ToArray();
  } finally { CloseHandle(snapshot); }
 }
}
