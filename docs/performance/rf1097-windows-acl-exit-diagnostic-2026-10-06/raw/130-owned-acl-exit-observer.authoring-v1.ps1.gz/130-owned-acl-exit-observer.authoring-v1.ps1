param([ValidateSet('probe','observe')][string]$Mode='probe')
$ErrorActionPreference='Stop'
$stagePath=Split-Path -LiteralPath $PSCommandPath
$expectedStage='C:\Users\40299571\AppData\Local\Temp\ss-rf1097-acl-windowless-20261006'
if ($stagePath -ne $expectedStage) { throw 'Unexpected diagnostic stage' }
$groupName='legacy5000-exit-diagnostic-01'
$groupPath=Join-Path $stagePath $groupName
$icaclsPath='C:\Windows\System32\icacls.exe'
$expectedIcaclsHash='CB9E55D4C02F4E55100724D2DA9A1267F49E196BD39FCDF36CEC6EA6314FAD2A'
if ((Get-FileHash -LiteralPath $icaclsPath -Algorithm SHA256).Hash -ne $expectedIcaclsHash) { throw 'icacls image changed' }
Add-Type -TypeDefinition (Get-Content -LiteralPath (Join-Path $stagePath 'owned-acl-exit-observer.cs') -Raw)
function Write-NewJson([string]$name,$value) {
 $target=Join-Path $stagePath $name
 $bytes=[Text.UTF8Encoding]::new($false).GetBytes((($value | ConvertTo-Json -Depth 12)+[char]10))
 $stream=[IO.FileStream]::new($target,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
 try { $stream.Write($bytes,0,$bytes.Length);$stream.Flush($true) } finally { $stream.Dispose() }
}
function Normalize-Path([string]$value) { if($value.StartsWith('\\?\')){$value=$value.Substring(4)}; return [IO.Path]::GetFullPath($value).TrimEnd('\').ToLowerInvariant() }
if($Mode -eq 'probe') {
 $probeStart=[DateTime]::UtcNow.ToFileTimeUtc();$self=$null;$child=$null;$childHandle=$null
 try {
  $pwshPath=[Environment]::ProcessPath
  $self=[RF1097ReadOnlyProcess]::OpenVerified($PID,$pwshPath,0)
  if($null -ne $self.ExitStatus()){throw 'Observer self identity is not live'}
  $info=[Diagnostics.ProcessStartInfo]::new();$info.FileName=$pwshPath;$info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden
  foreach($arg in @('-NoProfile','-NonInteractive','-Command','Start-Sleep -Milliseconds 500; exit 37')) { $info.ArgumentList.Add($arg) }
  $child=[Diagnostics.Process]::Start($info)
  $childHandle=[RF1097ReadOnlyProcess]::OpenVerified($child.Id,$pwshPath,$probeStart)
  $rows=@([RF1097ReadOnlyProcess]::Children([int[]]@($PID),[IO.Path]::GetFileName($pwshPath)))
  if(@($rows | Where-Object { $_.pid -eq $child.Id -and $_.parent -eq $PID }).Count -ne 1){throw 'Real Toolhelp child relation absent'}
  $wrongParentRows=@([RF1097ReadOnlyProcess]::Children([int[]]@($child.Id),[IO.Path]::GetFileName($pwshPath)))
  if(@($wrongParentRows | Where-Object { $_.pid -eq $child.Id }).Count){throw 'Wrong parent accepted'}
  $wrongExecutableRejected=$false;try { $bad=[RF1097ReadOnlyProcess]::OpenVerified($PID,$icaclsPath,0);$bad.Dispose() } catch [InvalidOperationException] { $wrongExecutableRejected=$true }
  if(-not $wrongExecutableRejected){throw 'Wrong executable accepted'}
  if(-not $child.WaitForExit(5000)){throw 'Probe child did not exit'}
  $actualCode=$childHandle.ExitStatus();$actualExit=$childHandle.ExitFileTime()
  if($actualCode -ne 37 -or $child.ExitCode -ne 37 -or $actualExit -lt $childHandle.birth){throw 'Real process exit status mismatch'}
  Write-NewJson 'owned-acl-exit-capability.json' ([ordered]@{at=[DateTime]::UtcNow.ToString('o');success=$true;realChildExitCode=$actualCode;dotnetIndependentExitCode=$child.ExitCode;toolhelpParentVerified=$true;wrongParentRejected=$true;wrongExecutableRejected=$true;retainedBirth=$childHandle.birth;retainedHandleAvoidsPidReuse=$true;accessRights='QUERY_LIMITED_INFORMATION|SYNCHRONIZE';requiresAdministrator=$false;processKilled=$false;systemSettingsChanged=$false;commandBodyRecorded=$false})
  Write-Output 'Read-only process handle capability passed: actual exit 37; parent and executable rejection passed'
 } finally { if($childHandle){$childHandle.Dispose()};if($self){$self.Dispose()};if($child){$child.Dispose()} }
 exit 0
}
$capability=Get-Content -LiteralPath (Join-Path $stagePath 'owned-acl-exit-capability.json') -Raw | ConvertFrom-Json
if(-not $capability.success){throw 'Capability was not accepted'}
$build=Get-Content -LiteralPath (Join-Path $stagePath 'baseline-build-checkpoint.json') -Raw | ConvertFrom-Json
$expectedExe=[string]$build.exe
if((Get-FileHash -LiteralPath $expectedExe -Algorithm SHA256).Hash.ToLowerInvariant() -ne $build.sha256){throw 'Old GUI image changed'}
$started=[DateTime]::UtcNow;$minimumBirth=$started.ToFileTimeUtc();$watch=[Diagnostics.Stopwatch]::StartNew()
$parents=@{};$children=@{};$seen=[Collections.Generic.HashSet[string]]::new();$records=[Collections.Generic.List[object]]::new();$parentRecords=[Collections.Generic.List[object]]::new();$failures=[Collections.Generic.List[object]]::new()
$polls=0;$snapshotMilliseconds=0.0;$snapshotMaximumMilliseconds=0.0;$finished=$false;$drainUntil=$null
try {
 Write-NewJson 'owned-acl-exit-observer.ready.json' ([ordered]@{at=$started.ToString('o');pid=$PID;birthFileTime=([RF1097ReadOnlyProcess]::OpenVerified($PID,[Environment]::ProcessPath,0)).birth;group=$groupName;scope='owned-read-only-icacls-exit-diagnostic';diagnosticOnly=$true;performanceAccepted=$false;driverInputsUnchanged=$true;pollIntervalMs=10;outerObserverLimitSeconds=1440})
 while($watch.Elapsed.TotalSeconds -lt 1440) {
  for($index=1;$index -le 3;$index++) {
   if($parents.ContainsKey($index)){continue}
   $samplePath=Join-Path $groupPath ('sample-{0:d3}' -f $index)
   $requestPath=Join-Path $samplePath 'native-perf-sdk-journey-requested.json'
   $ownedPath=Join-Path $samplePath 'native-perf-owned.json'
   if(-not [IO.File]::Exists($requestPath) -or -not [IO.File]::Exists($ownedPath)){continue}
   try { $request=[IO.File]::ReadAllText($requestPath) | ConvertFrom-Json;$owned=[IO.File]::ReadAllText($ownedPath) | ConvertFrom-Json } catch [ArgumentException] { continue }
   foreach($proofPath in @($requestPath,$ownedPath)) { if(([IO.File]::GetAttributes($proofPath) -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Proof is a link'} }
   if($request.schemaVersion -ne 1 -or $request.scope -ne 'windows-native-sdk-ui-journey-requested' -or $request.inputMethod -ne 'SDK-CDP-Input' -or $request.defaultBuild -ne $false -or $request.objectCount -ne 5000 -or $owned.scope -ne 'windows-native-perf-owned' -or $owned.preparationStatus -ne 'ready' -or $owned.nativePerfFeature -ne $true -or $request.runId -ne $owned.runId -or $request.runId -notmatch '^[0-9a-f]{32}$' -or $owned.identifier -ne ('com.solosoul.rf312perf.'+$owned.runId) -or (Normalize-Path $request.root) -ne (Normalize-Path $samplePath) -or (Normalize-Path $owned.root) -ne (Normalize-Path $samplePath)){throw 'Owned root proof rejected'}
   $parent=[RF1097ReadOnlyProcess]::OpenVerified([int]$request.pid,$expectedExe,$minimumBirth)
   if($null -ne $parent.ExitStatus()){$parent.Dispose();throw 'Owned GUI parent exited before observer binding'}
   $parents[$index]=$parent
   $parentRecords.Add([ordered]@{sample=$index;pid=$parent.pid;birthFileTime=$parent.birth;exeSha256=$build.sha256;runId=$owned.runId;requestSha256=(Get-FileHash -LiteralPath $requestPath -Algorithm SHA256).Hash.ToLowerInvariant();ownedSha256=(Get-FileHash -LiteralPath $ownedPath -Algorithm SHA256).Hash.ToLowerInvariant()})
  }
  $alive=@($parents.Values | Where-Object { $null -eq $_.ExitStatus() })
  if($alive.Count) {
   $snapshotWatch=[Diagnostics.Stopwatch]::StartNew()
   $found=@([RF1097ReadOnlyProcess]::Children([int[]]@($alive | ForEach-Object {$_.pid}),'icacls.exe'))
   $snapshotWatch.Stop();$polls++;$snapshotMilliseconds+=$snapshotWatch.Elapsed.TotalMilliseconds;$snapshotMaximumMilliseconds=[Math]::Max($snapshotMaximumMilliseconds,$snapshotWatch.Elapsed.TotalMilliseconds)
   foreach($row in $found) {
    $parentIndex=@($parents.Keys | Where-Object {$parents[$_].pid -eq $row.parent})
    if($parentIndex.Count -ne 1){throw 'Ambiguous GUI parent'}
    $parent=$parents[$parentIndex[0]]
    if($null -ne $parent.ExitStatus()){continue}
    $childHandle=$null
    try { $childHandle=[RF1097ReadOnlyProcess]::OpenVerified($row.pid,$icaclsPath,$parent.birth) } catch [ComponentModel.Win32Exception] { $failures.Add([ordered]@{kind='child-open-race-or-failure';sample=$parentIndex[0];pid=$row.pid;parentPid=$row.parent;errorCode=$_.Exception.NativeErrorCode});continue }
    $key=[string]$row.pid+':'+[string]$childHandle.birth
    if(-not $seen.Add($key)){$childHandle.Dispose();continue}
    if($seen.Count -gt 64){$childHandle.Dispose();throw 'Child identity limit exceeded'}
    $children[$key]=[ordered]@{handle=$childHandle;sample=$parentIndex[0];parentPid=$row.parent;parentBirth=$parent.birth;observedAt=[DateTime]::UtcNow.ToString('o')}
   }
  }
  foreach($key in @($children.Keys)) {
   $child=$children[$key];$code=$child.handle.ExitStatus()
   if($null -eq $code){continue}
   $exitTime=$child.handle.ExitFileTime()
   if($exitTime -lt $child.handle.birth){throw 'Invalid retained handle exit time'}
   $records.Add([ordered]@{sample=$child.sample;pid=$child.handle.pid;parentPid=$child.parentPid;parentBirthFileTime=$child.parentBirth;birthFileTime=$child.handle.birth;exitFileTime=$exitTime;exitCode=[uint32]$code;exitCodeHex=('0x{0:X8}' -f [uint32]$code);icaclsSha256=$expectedIcaclsHash.ToLowerInvariant();firstObservedAt=$child.observedAt;capturedAt=[DateTime]::UtcNow.ToString('o');sameRetainedHandle=$true;commandBodyRecorded=$false})
   $child.handle.Dispose();$children.Remove($key)
  }
  if([IO.File]::Exists((Join-Path $stagePath 'owned-acl-exit-driver.done.json'))) {
   if($null -eq $drainUntil){$drainUntil=$watch.Elapsed.TotalMilliseconds+500}
   if($watch.Elapsed.TotalMilliseconds -ge $drainUntil){if($children.Count){throw 'Child handles still live after driver completion'};$finished=$true;break}
  }
  Start-Sleep -Milliseconds 10
 }
 if(-not $finished){throw 'Read-only observer outer deadline reached'}
 if($parents.Count -ne 3){throw 'Not all three GUI parents verified'}
 if($failures.Count){throw 'At least one owned child identity could not be retained'}
 if((Get-FileHash -LiteralPath $icaclsPath -Algorithm SHA256).Hash -ne $expectedIcaclsHash){throw 'icacls image changed after diagnostic'}
 Write-NewJson 'owned-acl-exit-observer.result.json' ([ordered]@{at=[DateTime]::UtcNow.ToString('o');success=$true;scope='owned-read-only-icacls-exit-diagnostic';group=$groupName;diagnosticOnly=$true;performanceAccepted=$false;originalFailedGroupAccepted=$false;parentRecords=@($parentRecords);childRecords=@($records);identityFailures=@($failures);snapshotPolls=$polls;snapshotTotalMilliseconds=$snapshotMilliseconds;snapshotMaximumMilliseconds=$snapshotMaximumMilliseconds;elapsedSeconds=$watch.Elapsed.TotalSeconds;liveChildHandles=0;commandsOrBodiesCollected=$false;processKilled=$false;systemSettingsChanged=$false;productionSourceChanged=$false;readOnlyRights='QUERY_LIMITED_INFORMATION|SYNCHRONIZE'})
 Write-Output ('Owned icacls diagnostic complete: {0} parents, {1} retained exit codes, {2} nonzero' -f $parents.Count,$records.Count,@($records | Where-Object {$_.exitCode -ne 0}).Count)
} catch {
 Write-NewJson 'owned-acl-exit-observer.failure.json' ([ordered]@{at=[DateTime]::UtcNow.ToString('o');success=$false;errorType=$_.Exception.GetType().FullName;errorMessage=$_.Exception.Message;parentRecords=@($parentRecords);childRecords=@($records);identityFailures=@($failures);liveChildren=$children.Count;performanceAccepted=$false;originalFailedGroupAccepted=$false})
 throw
} finally { foreach($child in $children.Values){$child.handle.Dispose()};foreach($parent in $parents.Values){$parent.Dispose()} }
