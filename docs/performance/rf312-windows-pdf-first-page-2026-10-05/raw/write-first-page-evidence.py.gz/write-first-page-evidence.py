import pathlib,json,hashlib,datetime,sys
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-pixels-20261005')
load=lambda n:json.loads((s/n).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks={name:load(name+'.receipt.json') for name in ['frame-ready-native-tests','frame-ready-native-clippy','frame-ready-fmt-check','frame2-js-targeted-tests','frame2-node-tests','frame2-js-format-check','frame2-diff-check']}
assert all(v['exitCode']==0 for v in checks.values())
assert '90 passed; 0 failed' in (s/'frame-ready-native-tests.stdout.log').read_text(encoding='utf-8-sig')
node=(s/'frame2-node-tests.stdout.log').read_text(encoding='utf-8-sig');assert 'pass 198' in node and 'fail 0' in node and 'skipped 1' in node
build=load('build-checkpoint-frame.json');assert sha(pathlib.Path(build['exe']))==build['sha256']
assert load('release-build-final.receipt.json')['exitCode']==0
initial=load('samples100/native-perf-sdk-journey-results.json')
assert initial['success']==False and len(initial['samples'])==3 and all(x['nativeProof']['reason']=='pdf-public-asset-replaced' and x['cleanupIntegrity']['complete'] for x in initial['samples'])
assert all(v['medianMs'] is None and v['p95Ms'] is None for v in initial['summary'])
failed=load('build-checkpoint-initial.json');assert sha(pathlib.Path(failed['exe']))==failed['sha256']
results={};images=0;identities=0;caches=0;links=0
for size in ['100','5000']:
 group='samples'+size+'-frame';report=load(group+'/native-perf-sdk-journey-results.json')
 assert report['success'] and report['sourceUnchanged'] and len(report['samples'])==3 and len(report['summary'])==5 and all(x['successfulSamples']==3 and x['medianMs'] is not None and x['p95Ms'] is not None for x in report['summary'])
 review=load(group+'-actual-pdf-review.json');proof=load(group+'-native-proof-review.json');cleanup=load(group+'-cache-cleanup.json')
 assert proof['strictProofs']==3 and proof['summary']==report['summary'] and cleanup['complete'] and cleanup['processesTerminated']==0
 images+=proof['independentImages'];identities+=len(cleanup['verifiedIdentities']);caches+=len(cleanup['removedCachePaths']);links+=len(cleanup['unlinkedCacheEntries'])
 samples=[]
 for sample in report['samples']:
  p=sample['nativeProof'];d=p['pdfPreview'];assert p['success'] and d['renderVerified'] and d['mainVerifiedAfterClose'] and sample['cleanupIntegrity']['complete']
  samples.append({'index':sample['index'],'sdkCalls':len(p['calls']),'openingStartedAtMs':d['openingStartedAtMs'],'wholeJourneyElapsedMs':p['elapsedMs'],'resourceBinding':d['resourceBinding'],'metrics':d['performanceMetrics'],'captures':d['samples'],'closedDom':d['closedDom'],'frameCreatedEvents':d['frameCreatedEvents'],'mainVerifiedAfterClose':d['mainVerifiedAfterClose'],'cleanupIntegrity':sample['cleanupIntegrity']})
 results[size]={'nodeVersion':report['nodeVersion'],'osRelease':report['osRelease'],'run':load('pdf'+size+'-frame.receipt.json'),'summary':report['summary'],'sourceUnchanged':True,'actualReview':review,'strictProofReview':proof,'samples':samples,'cleanup':cleanup}
 assert results[size]['run']['exitCode']==0
freeze=load('source-freeze-frame.json')['files'];assert all(sha(r/p)==h for p,h in freeze.items())
public=load('public-source-freeze-frame.json')['files'];assert all(sha(pathlib.Path(p))==h for p,h in public.items())
resources=load('resource-freeze-frame.json')['records'];assert all(sha(pathlib.Path(f['source']))==f['sha256']==sha(pathlib.Path(f['copy'])) for f in resources)
record={'schemaVersion':1,'task':'RF-312','phase':'Windows fixed public PDF first-page text visibility','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baselineHead':load('baseline.json')['head'],'device':load('current-device.json'),'stageAccepted':True,'wholeTaskComplete':False,'renderVerified':True,'measurementScope':'fixed public text_only.pdf first-page text ROI, not whole-page/all-pages/arbitrary documents/DWM','clockBoundary':'native Instant before first SDK Preview press to identity-verified repeated matching pixels; SDK/capture/decode/poll and earlier PNG I/O included; final PNG publication/close/Node replay excluded','build':build,'release':load('release-build-final.receipt.json'),'checks':checks,'checkTotals':{'nativePassed':90,'nativeFailed':0,'nodeTotal':199,'nodePassed':198,'nodeFailed':0,'nodeExistingSymlinkPermissionSkip':1},'groups':results,'initialFailedGroup':{'run':load('pdf100.receipt.json'),'build':failed,'success':False,'metricsSuppressed':True,'reason':'Plaintext asset digest was incorrectly compared against the actual SOLC attachment ciphertext; repaired by binding the unique prechecked ciphertext FileProof','actualReview':load('initial-failed-native-review.json'),'cleanup':load('samples100-cache-cleanup.json'),'sampleReasons':[x['nativeProof']['reason'] for x in initial['samples']]},'secondFailedGroup':{'run':load('pdf100-final.receipt.json'),'build':load('build-checkpoint-final.json'),'actualReview':load('second-failed-native-review.json'),'cleanup':load('samples100-final-cache-cleanup.json'),'metricsSuppressed':True,'nativeHomeTimeoutReproduced':True,'driverPowerShellSampleTimeout':True,'pdfChildTreeChangedDuringCapture':True,'imageAvailability':load('second-failed-image-availability.json')},'preservation':{'frozenInputs':len(freeze),'publicFiles':len(public),'resources':len(resources),'oldPdfBuilds':load('baseline.json')['oldPdfBuilds'],'initialFailedExePreserved':True,'finalImagesIndependentlyDecoded':images,'finalExitedIdentityRecords':identities,'finalRemovedCachePaths':caches,'finalUnlinkedEntries':links,'ownedAttachmentCiphertextsPerGroup':12},'rawArchive':'rf312-windows-pdf-first-page-2026-10-05/index.json','remaining':['actual OCR native picker and first inference','intermittent home timeout','KDF/storage/React/SDK attribution','system sleep','other-platform native performance','RF-121 Windows composition/recovery'],'taskCounts':{'total':283,'closed':274,'waiting':3,'pending':6},'pushPerformed':False}
file=r/'docs/performance/rf312-windows-pdf-first-page-2026-10-05.json';assert not file.exists();file.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
rows=[]
for metric in ['firstMatchObservedMs','stableReadyObservedMs','captureOverheadMs','decodeOverheadMs','pollWaitMs']:
 a=next(x for x in results['100']['summary'] if x['name']==metric);b=next(x for x in results['5000']['summary'] if x['name']==metric)
 rows.append(f"| `{metric}` | {a['medianMs']:.2f} / {a['p95Ms']:.2f} | {b['medianMs']:.2f} / {b['p95Ms']:.2f} |")
for name in ['RF-312-native-pdf-first-page.md','RF-312-native-pdf-diagnostic.md','RF-312-windows-native-app-baseline.md']:
 p=r/'docs/performance'/name;t=p.read_text(encoding='utf-8-sig')
 if name=='RF-312-native-pdf-first-page.md':
  a='当前阶段正在执行最终检查和实际采样，尚未验收。';assert a in t;t=t.replace(a,'固定公开首屏正文区域在 Windows 两档各三次实际采样中通过验收；RF-312 整体仍未完成。')
 text='\n\n## 2026-10-05 固定公开 PDF 首屏文字可见验收\n\n'
 text+=f"修复后的独立 Release SHA-256 `{build['sha256']}`，冻结 {len(freeze)} 项输入和 {len(resources)} 份资源。90 项原生回归、严格 Clippy、格式与 diff 检查通过；Node 198 passed / 0 failed / 1 既有 Windows 文件 symlink 权限跳过。100/5000 对象各三次真实 owned 行程均通过，{images} 份实际 PNG 经 Node 独立解码复核，真实关闭及清理完成。\n\n"
 hardware=load('current-device.json');cpu=hardware['processors'][0];os=hardware['operatingSystem'][0];ram=hardware['totalPhysicalMemory'][0]/(1024**3)
 text+=f"设备：{cpu['Name']}，{cpu['NumberOfLogicalProcessors']}逻辑核心；系统报告物理内存{ram:.2f}GiB；{os['Caption']} {os['Version']} {os['OSArchitecture']}。构建{hardware['rustc']}，驱动Node {hardware['node']}。公开素材、固定视口与当前EXE限定了本次口径。\n\n"
 text+='以下为每档 n=3 的观测中位 / P95，单位 ms；P95 为这三次的最大值，包含采样开销。不能据此声称产品瓶颈或任意 PDF 加载速度。\n\n| 指标 | 100 对象 | 5000 对象 |\n|---|---:|---:|\n'+'\n'.join(rows)+'\n\n'
 text+='第二轮三次分别在首页探针、驱动 PowerShell 进程采样和 PDF 子树变化门禁失败，整组指标为空，原件及第二版 EXE 保留。其中第三次调用过一次截图，但旧schema1在子树门禁失败后未发布PNG，原响应不可恢复；保留证明/调用列表/源码与EXE，不借用旧参考PNG补造原件。新 v2 合同保留子树不稳定截图、记录 frameStable=false 并计入开销，只有两次后续树稳定且文字匹配才接受；主 frame/loader 门禁、16次/25秒及128协议调用上限保持。首页超时原因仍未确定，驱动采样超时仍判失败。\n\n'
 text+='首轮100对象三次均因明文/密文资源边界错误拒绝，未输出统计数值；原组、EXE 和最初测试失败完整保留。修复仅在非默认采样器中绑定准备阶段已解密核验的公开素材及唯一物理密文摘要，未改变生产附件协议。\n\n'
 text+=f"fresh CIM 核验最终两组 {identities} 条进程身份已退出，仅删除 {caches} 个精确 owned 缓存目录并解除 {links} 个私有链接，没有终止额外进程。24份最终副本附件密文、公开源171文件、旧构建及 Vault 保持；首轮失败清理另有独立回执。\n\n"
 text+='[结构化验收](rf312-windows-pdf-first-page-2026-10-05.json)和[逐字节原件索引](rf312-windows-pdf-first-page-2026-10-05/index.json)保存完整失败与成功。只验收指定首屏正文区域；整页、其他页、任意 PDF、OCR、睡眠和多端不包含在该结果中。下一本地阶段为实际 OCR 和性能归因，原首页偶发超时继续待查。独立本地提交，不推送。\n'
 assert '## 2026-10-05 固定公开 PDF 首屏文字可见验收' not in t;p.write_text(t+text,encoding='utf-8',newline='\n')
p=r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';t=p.read_text(encoding='utf-8-sig')
a='> 最后更新：2026-10-05（RF-312 Windows PDF实际结构诊断已验收；继续公开首屏像素就绪验证、OCR及归因）';assert a in t;t=t.replace(a,'> 最后更新：2026-10-05（RF-312 Windows固定公开PDF首屏正文区域两档验收；继续实际OCR及性能归因）',1)
a='RF-312：Windows原生PDF固定公开首屏像素就绪验证、首次OCR及KDF/存储/React/SDK性能归因';assert a in t;t=t.replace(a,'RF-312：Windows实际OCR、KDF/存储/React/SDK性能归因；固定公开PDF首屏正文区域已验收',1)
text='\n\n### RF-312 Windows 固定公开 PDF 首屏文字可见验收（2026-10-05）\n\n'
text+='- 仅非默认 native-perf 增加独立 sdk-pdf-preview 模式：真实 SDK Preview/Close、固定主文档/frame/loader/时钟、公开素材路径与已核验密文摘要门禁；有界 PNG 解码、固定正文 ROI 二值掩码及连续两次实际间隔≥250ms。Node 独立 PNG/CRC/解码/掩码复核，整组失败抑制指标。默认前端、依赖和生产附件协议不修改。\n'
text+='- 首轮100对象三次因把3035字节公开PDF明文与3076字节SOLC物理密文混作同一资源拒绝。修复为 consume 时绑定唯一 prechecked FileProof 密文SHA，逐截图前后核验物理密文；原三份失败、EXE、源码快照和所有检查失败保留。\n'
text+='- 第二轮三次在首页、PowerShell身份采样及PDF子树变化失败；首页超时真实复现而原因未定。新v2合同保留不稳定截图及开销，排除其就绪贡献；主文档门禁和原预算保持，完整失败组/EXE继续保存。\n'
text+=f"- 最终90项原生回归、严格Clippy/格式/diff通过；Node198 passed/0 failed/1既有权限skip。{len(freeze)}输入与{len(resources)}资源冻结，新Release exit0；100/5000各3/3实际首屏通过，共{images}PNG独立解码，真实关闭及事件清理通过。指标包含采样开销，只证明指定首屏文字区域，不能外推整页/其他页/任意PDF或DWM材质。\n"
for size in ['100','5000']:
 a=next(x for x in results[size]['summary'] if x['name']=='firstMatchObservedMs');b=next(x for x in results[size]['summary'] if x['name']=='stableReadyObservedMs')
 text+=f"- {size}对象首次匹配/重复稳定观测中位为{a['medianMs']:.2f}/{b['medianMs']:.2f}ms；n=3的P95为最大值，完整截图、解码、等待开销另列，不以减法虚构净渲染耗时。\n"
text+=f"- 最终两组fresh CIM核验{identities}身份退出，精确清理{caches}缓存并解除{links}私有链接；24附件密文、Vault、证明、公开源171文件、旧/失败构建及源码/资源保持。[口径与全部证据](performance/RF-312-native-pdf-first-page.md)可复核。\n"
text+='- 按本阶段独立本地提交，不推送。RF-312继续[!]，274/283、3待验证、6待执行不变；下一本地项实际OCR/归因/首页偶发超时，再补Windows RF-121部分原生验收。RF-112/121完整外部验收及RF-122～127前置不解除，goal继续active。\n'
assert text.split('\n')[2] not in t;p.write_text(t+text,encoding='utf-8',newline='\n')
print(json.dumps({'acceptedGroups':list(results),'images':images,'exitIdentities':identities,'cachePaths':caches,'links':links,'metrics':{k:v['summary'] for k,v in results.items()}},ensure_ascii=False))
