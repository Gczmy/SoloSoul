import pathlib,json,hashlib,subprocess,time,datetime,shutil,sys
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-pixels-20261005');old=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-structure-20261005')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
write=lambda n,v:(s/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['frame-ready-native-tests','frame-ready-native-clippy','frame-ready-fmt-check','frame2-node-tests','frame2-js-format-check','frame2-diff-check']:
 assert json.loads((s/(name+'.receipt.json')).read_text(encoding='utf-8-sig'))['exitCode']==0,name
prior=json.loads((old/'source-freeze.json').read_text(encoding='utf-8-sig'))['files']
files={p:sha(r/p) for p in prior};
for p in ['tauri/src-tauri/src/native_perf/sdk_pdf_pixels.rs','tauri/src-tauri/src/native_perf/fixtures/pdf-first-page.png','tauri/scripts/native-perf-pdf-pixels.mjs','tauri/scripts/native-perf-pdf-preview-contract.mjs','tauri/scripts/native-perf-pdf-preview.mjs','tauri/scripts/native-perf-pdf-preview.test.mjs']:files[p]=sha(r/p)
write('source-freeze-frame.json',{'at':now(),'head':json.loads((s/'baseline.json').read_text(encoding='utf-8-sig'))['head'],'files':files})
public=json.loads((old/'public-source-freeze.json').read_text(encoding='utf-8-sig'))['files']
assert all(sha(pathlib.Path(p))==h for p,h in public.items())
write('public-source-freeze-frame.json',{'at':now(),'files':public})
bin=s/'bin-frame';bin.mkdir(exist_ok=False);records=[]
resources=json.loads((old/'resource-freeze.json').read_text(encoding='utf-8-sig'))
for v in resources['records']:
 source=pathlib.Path(v['copy']);assert sha(source)==v['sha256'];copy=bin/v['relativePath'];assert copy.resolve().is_relative_to(bin.resolve());copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,copy);assert sha(copy)==v['sha256'];records.append({**v,'source':str(source),'copy':str(copy)})
write('resource-freeze-frame.json',{'at':now(),'records':records,'oldExeSha256':resources['oldExeSha256']})
initial=json.loads((s/'build-checkpoint-initial.json').read_text(encoding='utf-8-sig'));assert sha(pathlib.Path(initial['exe']))==initial['sha256']
second=json.loads((s/'build-checkpoint-final.json').read_text(encoding='utf-8-sig'));assert sha(pathlib.Path(second['exe']))==second['sha256']
print(json.dumps({'inputs':len(files),'resources':len(records),'publicFiles':len(public)}),flush=True)
args=['cargo','build','--locked','--release','-p','solo_soul','--features','native-perf','--bin','solo_soul'];started=time.time()
with (s/'release-build-frame.stdout.log').open('xb') as out,(s/'release-build-frame.stderr.log').open('xb') as err:
 c=subprocess.Popen(args,cwd=r/'tauri',stdout=out,stderr=err);write('release-build-frame.live.json',{'command':args,'pid':c.pid,'startedAt':now()});print('Started release PID '+str(c.pid),flush=True);rc=c.wait()
write('release-build-frame.receipt.json',{'command':args,'pid':c.pid,'exitCode':rc,'elapsedSeconds':time.time()-started,'finishedAt':now()});print('Release exit '+str(rc),flush=True)
if rc:raise SystemExit(rc)
assert all(sha(r/p)==h for p,h in files.items())
assert all(sha(pathlib.Path(v['source']))==v['sha256']==sha(pathlib.Path(v['copy'])) for v in records)
exe=bin/'solo_soul.exe';assert not exe.exists();shutil.copy2(r/'tauri/target/release/solo_soul.exe',exe)
markers=['--native-perf-media-prepare','windows-native-sdk-media-journey-requested','windows-native-sdk-pdf-diagnostic-requested','windows-native-sdk-pdf-target-diagnostic-requested','windows-native-sdk-pdf-component-diagnostic-requested','windows-native-sdk-pdf-structure-diagnostic-requested','windows-native-sdk-startup-requested','windows-native-sdk-pdf-first-page-requested','windows-native-sdk-pdf-cipher-binding-requested','windows-native-sdk-pdf-frame-stability-requested'];data=exe.read_bytes();assert all(x.encode() in data for x in markers)
for p,h in json.loads((s/'baseline.json').read_text(encoding='utf-8-sig'))['oldPdfBuilds'].items():assert sha(pathlib.Path(p))==h
assert sha(pathlib.Path(initial['exe']))==initial['sha256']
assert sha(pathlib.Path(second['exe']))==second['sha256']
write('build-checkpoint-frame.json',{'at':now(),'exe':str(exe),'bytes':len(data),'sha256':sha(exe),'frozenInputsUnchanged':len(files),'resourcesUnchanged':len(records),'markers':markers,'previousPdfBuildsPreserved':True,'initialFailedBuildPreserved':initial,'secondFailedBuildPreserved':second});print('Frozen release copied and verified',flush=True)
