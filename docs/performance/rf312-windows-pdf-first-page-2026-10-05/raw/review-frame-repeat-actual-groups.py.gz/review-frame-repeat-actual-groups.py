import pathlib,json,hashlib,datetime,sys
sys.stdout.reconfigure(encoding='utf-8')
assert len(sys.argv)==2 and sys.argv[1] in ['100','5000']
group='samples'+sys.argv[1]+'-frame-repeat'
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-pixels-20261005')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda n:json.loads((s/n).read_text(encoding='utf-8-sig'))
report=load(group+'/native-perf-sdk-journey-results.json');build=load('build-checkpoint-frame.json');assert len(report['samples'])==3 and report['success'] and report['scope']=='windows-native-sdk-public-pdf-first-page-performance' and len(report['summary'])==5 and all(x['successfulSamples']==3 and x['medianMs'] is not None for x in report['summary']) and report['sourceUnchanged']
identities={};cleanup_pids=set();attachments=[];summaries=[]
for x in report['samples']:
 assert x['cleanupIntegrity']['complete'],x['index']
 root=pathlib.Path(x['root']);assert root==s/group/('sample-%03d'%x['index'])
 for name in ['beforeSnapshot','afterSnapshot']:
  for p in (x.get(name) or {}).get('processes',[]):
   key=(p['pid'],p['creationMs']);assert p['creationMs']>0;value={k:p[k] for k in ['pid','creationMs','executableName']};assert key not in identities or identities[key]==value;identities[key]=value
 for p in x['cleanup']['cleanup']:cleanup_pids.add(p['pid'])
 consumed=json.loads((root/'native-perf-consumed.json').read_text(encoding='utf-8-sig'))
 # Owned media proof binds attachment ciphertext bytes before GUI writes.
 owned=json.loads((root/'native-perf-owned.json').read_text(encoding='utf-8-sig'))
 ciphertexts=[f for f in owned['fixture']['files'] if f['relativePath'].startswith('attachments/')]
 assert len(ciphertexts)==4
 for f in ciphertexts:
  path=root/'vault'/f['relativePath'];assert path.resolve().is_relative_to((root/'vault').resolve()) and sha(path)==f['sha256']
 attachments.append({'index':x['index'],'ciphertextsUnchanged':ciphertexts})
 assert not (root/'native-perf-ready.json').exists(), 'consumed ready marker must remain removed'
 summaries.append({'index':x['index'],'success':x['success'],'reason':x.get('nativeProof',{}).get('reason'),'sdkCalls':len(x['nativeProof']['calls']),'pdfPreview':x['nativeProof']['pdfPreview']})
public=load('public-source-freeze-frame.json')['files'];assert all(sha(pathlib.Path(p))==h for p,h in public.items())
freeze=load('source-freeze-frame.json')['files'];assert all(sha(r/p)==h for p,h in freeze.items())
resources=load('resource-freeze-frame.json')['records'];assert all(sha(pathlib.Path(v['source']))==v['sha256']==sha(pathlib.Path(v['copy'])) for v in resources)
assert sha(pathlib.Path(build['exe']))==build['sha256']
base=load('baseline.json');assert all(sha(pathlib.Path(p))==h for p,h in base['oldPdfBuilds'].items())
initial=load('build-checkpoint-initial.json');assert sha(pathlib.Path(initial['exe']))==initial['sha256']
second=load('build-checkpoint-final.json');assert sha(pathlib.Path(second['exe']))==second['sha256']
write=lambda n,v:(s/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
write(group+'-identity-scope.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exe':build['exe'],'identities':list(identities.values()),'additionalCleanupPids':sorted(cleanup_pids-set(p for p,c in identities))})
write(group+'-actual-pdf-review.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':report['success'],'sourceUnchanged':True,'publicFilesUnchanged':len(public),'frozenInputsUnchanged':len(freeze),'resourcesUnchanged':len(resources),'oldPdfBuildsPreserved':True,'ownedAttachmentCiphertextsUnchanged':attachments,'fixedPublicFirstPageTextOnly':True,'renderVerified':True,'summary':report['summary'],'samples':summaries})
print(json.dumps({'reportSuccess':report['success'],'identities':len(identities),'extraCleanupPids':len(cleanup_pids-set(p for p,c in identities)),'publicFiles':len(public),'inputs':len(freeze)}),flush=True)
