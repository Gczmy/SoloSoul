import {readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {checkPdfFirstPage,summarizePdfFirstPage} from 'file:///C:/Users/40299571/SoloSoul/tauri/scripts/native-perf-pdf-preview-contract.mjs';
import {inspectPdfPixels} from 'file:///C:/Users/40299571/SoloSoul/tauri/scripts/native-perf-pdf-pixels.mjs';
const stage=process.argv[2],group=process.argv[3];if(!['samples100-frame-repeat','samples5000-frame-repeat'].includes(group))throw new Error('Exact group required');const report=JSON.parse(await readFile(path.join(stage,group+'/native-perf-sdk-journey-results.json'),'utf8'));
let images=0;
for(const sample of report.samples){
 const owned=JSON.parse(await readFile(path.join(sample.root,'native-perf-owned.json'),'utf8'));
 const proof=checkPdfFirstPage(sample.nativeProof,owned,sample.bound,owned.fixture);
 for(const shot of proof.pdfPreview.samples){
  const bytes=await readFile(path.join(sample.root,shot.fileName));
  if(bytes.length!==shot.bytes||createHash('sha256').update(bytes).digest('hex')!==shot.sha256)throw new Error('Screenshot changed');
  const pixels=inspectPdfPixels(bytes);if(Object.entries(pixels).some(([k,v])=>shot[k]!==v))throw new Error('Pixel decoder differs');images++;
 }
}
const summary=summarizePdfFirstPage(report.samples,3,report.sourceUnchanged&&!report.interrupted);
if(JSON.stringify(summary)!==JSON.stringify(report.summary))throw new Error('Distribution differs');
const receipt={at:new Date().toISOString(),strictProofs:report.samples.length,independentImages:images,summary,scope:'fixed public first-page text only'};
await writeFile(path.join(stage,group+'-native-proof-review.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(receipt));
