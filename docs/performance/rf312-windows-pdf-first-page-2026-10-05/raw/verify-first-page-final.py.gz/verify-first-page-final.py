import pathlib,json,gzip,hashlib,datetime,sys,subprocess,re
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-pixels-20261005')
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda n:json.loads((s/n).read_text(encoding='utf-8-sig'))
base=load('baseline.json');freeze=load('source-freeze-frame.json')['files']
assert all(sha((r/p).read_bytes())==h for p,h in freeze.items())
assert all(sha(pathlib.Path(p).read_bytes())==h for p,h in base['oldPdfBuilds'].items())
initial=load('build-checkpoint-initial.json');final=load('build-checkpoint-frame.json');second=load('build-checkpoint-final.json');assert sha(pathlib.Path(second['exe']).read_bytes())==second['sha256']
assert sha(pathlib.Path(initial['exe']).read_bytes())==initial['sha256']
assert sha(pathlib.Path(final['exe']).read_bytes())==final['sha256']
for name in ['public-source-freeze-frame.json']:
 assert all(sha(pathlib.Path(p).read_bytes())==h for p,h in load(name)['files'].items())
for f in load('resource-freeze-frame.json')['records']:
 assert sha(pathlib.Path(f['source']).read_bytes())==f['sha256']==sha(pathlib.Path(f['copy']).read_bytes())
index=r/'docs/performance/rf312-windows-pdf-first-page-2026-10-05/index.json'
data=json.loads(index.read_text(encoding='utf-8-sig'))
for f in data['files']:
 b=(index.parent/f['archive']).read_bytes();original=pathlib.Path(f['original']).read_bytes()
 assert len(b)==f['archiveBytes'] and sha(b)==f['archiveSha256']
 assert len(original)==f['bytes'] and sha(original)==f['sha256'] and gzip.decompress(b)==original
assert b'\r' not in index.read_bytes()
git=['git','-c','safe.directory='+r.as_posix(),'-c','core.safecrlf=false']
stash=subprocess.check_output(git+['rev-parse','stash@{0}'],cwd=r,text=True).strip()
assert stash==base['stash'] if 'stash' in base else stash=='dd695bba03ce1ea274185d4cc9ed0e69501b3d90'
sub=subprocess.check_output(git+['submodule','status'],cwd=r,text=True).strip()
assert sub.startswith('f55fc4b5a257cb8d7d9273168c3fd05b01b9d921')
report=(r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md').read_text(encoding='utf-8-sig')
assert '已关闭：**274 / 283**' in report
links=[]
for p in [r/'docs/performance/RF-312-native-pdf-first-page.md',r/'docs/performance/RF-312-native-pdf-diagnostic.md',r/'docs/performance/RF-312-windows-native-app-baseline.md',r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md']:
 text=p.read_text(encoding='utf-8-sig')
 for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',text):
  if target.startswith(('http:','https:','#','mailto:','codex:')):continue
  raw=target.split('#',1)[0].strip('<>');
  if not raw:continue
  if ' ' in raw and not target.startswith('<'):continue
  path=p.parent/raw;assert path.exists(),(p,raw);links.append({'from':p.relative_to(r).as_posix(),'target':target})
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archivesByteExact':len(data['files']),'localLinksVerified':len(links),'counts':{'total':283,'closed':274,'waiting':3,'pending':6},'frozenInputsUnchanged':len(freeze),'stashAndSubmodulePreserved':True,'scope':'RF-312 fixed public first-page text visibility; full task remains open','pushPerformed':False}
(s/'precommit-review.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(receipt))
