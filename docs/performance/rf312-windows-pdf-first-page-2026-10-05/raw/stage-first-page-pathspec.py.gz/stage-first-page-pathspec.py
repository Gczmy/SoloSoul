import pathlib,json,hashlib,subprocess,sys,datetime
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-pixels-20261005')
git=['git','-c','safe.directory='+r.as_posix(),'-c','core.safecrlf=false','-c','core.autocrlf=false']
def output(args):return subprocess.check_output(git+args,cwd=r)
code=['tauri/scripts/native-perf-sdk-journey.mjs','tauri/scripts/run-node-tests.mjs','tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/src/native_perf/fixture.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs','tauri/src-tauri/src/native_perf/sdk_cdp.rs','tauri/src-tauri/src/native_perf/sdk_journey.rs','tauri/src-tauri/src/native_perf/sdk_pdf.rs','tauri/src-tauri/src/native_perf/startup.rs','tauri/src-tauri/src/native_perf/sdk_pdf_pixels.rs','tauri/src-tauri/src/native_perf/fixtures/pdf-first-page.png','tauri/scripts/native-perf-pdf-pixels.mjs','tauri/scripts/native-perf-pdf-preview-contract.mjs','tauri/scripts/native-perf-pdf-preview.mjs','tauri/scripts/native-perf-pdf-preview.test.mjs']
docs=['docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md','docs/performance/RF-312-native-pdf-first-page.md','docs/performance/RF-312-native-pdf-diagnostic.md','docs/performance/RF-312-windows-native-app-baseline.md','docs/performance/rf312-windows-pdf-first-page-2026-10-05.json']
folder=r/'docs/performance/rf312-windows-pdf-first-page-2026-10-05';archive=sorted(p.relative_to(r).as_posix() for p in folder.rglob('*') if p.is_file())
assert archive and all(p.endswith(('.gz','.gitattributes','index.json')) for p in archive)
allowed=set(code+docs+archive);assert len(allowed)==len(code)+len(docs)+len(archive)
assert not output(['diff','--cached','--name-only']), 'Existing staged changes must be preserved'
status=output(['status','--porcelain=v1','-z','--untracked-files=all']).decode('utf-8').split('\0');actual=set()
for row in status:
 if not row:continue
 assert row[:2] in [' M','??'],row[:2];actual.add(row[3:])
assert actual==allowed,{'unexpected':sorted(actual-allowed),'missing':sorted(allowed-actual)}
base=json.loads((s/'baseline.json').read_text(encoding='utf-8-sig'));unchanged=0
for path,h in base['sourceBefore'].items():
 if path in code:continue
 assert hashlib.sha256((r/path).read_bytes()).hexdigest()==h,path;unchanged+=1
assert output(['rev-parse','HEAD']).decode().strip()==base['head']
pathspec=s/'first-page-stage-paths.nul';pathspec.write_bytes(b'\0'.join(p.encode('utf-8') for p in sorted(allowed))+b'\0')
subprocess.run(git+['add','--pathspec-from-file='+str(pathspec),'--pathspec-file-nul'],cwd=r,check=True)
staged=set(x for x in output(['diff','--cached','--name-only','-z']).decode('utf-8').split('\0') if x)
assert staged==allowed
subprocess.run(git+['diff','--cached','--check'],cwd=r,check=True)
for path in staged:assert output(['show',':'+path])==(r/path).read_bytes(),path
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'codeFiles':len(code),'documentFiles':len(docs),'archiveFiles':len(archive),'stagedPaths':sorted(staged),'stagedBlobsByteExact':True,'unrelatedFrozenSourcesUnchanged':unchanged,'headBefore':base['head'],'pushPerformed':False}
(s/'staged-review.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='stagedPaths'}))
