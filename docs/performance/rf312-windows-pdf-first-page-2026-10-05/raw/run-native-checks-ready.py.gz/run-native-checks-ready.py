import subprocess,pathlib,time,json,datetime,sys,os
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-pixels-20261005')
env=os.environ.copy();env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','')
def run(name,args,cwd=None):
 started=time.time()
 with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
  c=subprocess.Popen(args,cwd=cwd or r/'tauri',env=env,stdout=out,stderr=err)
  (s/(name+'.live.json')).write_text(json.dumps({'pid':c.pid,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}),encoding='utf-8')
  print('Started '+name+' PID '+str(c.pid),flush=True);rc=c.wait()
 receipt={'command':args,'pid':c.pid,'exitCode':rc,'elapsedSeconds':time.time()-started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (s/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt),flush=True)
 if rc: raise SystemExit(rc)
run('pixel-ready-fmt-write',['cargo','+1.99.0','fmt','--all'])
run('pixel-ready-native-tests',['cargo','test','--locked','-p','solo_soul','--features','native-perf','--lib','native_perf','--','--test-threads=1'])
run('pixel-ready-native-clippy',['cargo','clippy','--locked','-p','solo_soul','--features','native-perf','--all-targets','--','-D','warnings'])
run('pixel-ready-fmt-check',['cargo','+1.99.0','fmt','--all','--','--check'])
