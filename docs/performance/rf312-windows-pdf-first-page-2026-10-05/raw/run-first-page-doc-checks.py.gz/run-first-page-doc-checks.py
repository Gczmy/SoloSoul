import subprocess,pathlib,time,json,datetime,sys,os
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-pixels-20261005')
env=os.environ.copy();env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','')
def run(name,args,cwd=None):
 started=time.time()
 with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
  c=subprocess.Popen(args,cwd=cwd or r/'tauri',env=env,stdout=out,stderr=err)
  (s/(name+'.live.json')).write_text(json.dumps({'pid':c.pid,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}),encoding='utf-8')
  print('Started '+name+' PID '+str(c.pid),flush=True);rc=c.wait()
 receipt={'command':args,'pid':c.pid,'exitCode':rc,'elapsedSeconds':time.time()-started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (s/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt),flush=True)
 if rc: raise SystemExit(rc)
run('first-page-doc-format',['node','node_modules/prettier/bin/prettier.cjs','--write','../docs/performance/RF-312-native-pdf-first-page.md','../docs/performance/rf312-windows-pdf-first-page-2026-10-05.json'])
run('first-page-doc-boundary',['node','scripts/check-markdown-chunk-boundary.mjs'])
run('first-page-doc-diff',['git','-c','safe.directory='+r.as_posix(),'-c','core.safecrlf=false','diff','--check'],r)
