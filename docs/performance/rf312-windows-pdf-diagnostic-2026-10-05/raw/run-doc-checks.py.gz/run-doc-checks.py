import pathlib,json,datetime,subprocess,time,os
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-20261005');sysenv=os.environ.copy();sysenv['PATH']=r'C:\Program Files\Git\usr\bin;'+sysenv.get('PATH','')
def run(name,args,cwd=None):
 started=time.time()
 with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
  child=subprocess.Popen(args,cwd=cwd or r/'tauri',env=sysenv,stdout=out,stderr=err);print('Started '+name+' PID '+str(child.pid),flush=True);code=child.wait()
 receipt={'command':args,'exitCode':code,'pid':child.pid,'elapsedSeconds':time.time()-started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()};(s/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(receipt),flush=True)
 if code:raise SystemExit(code)
run('pdf-doc-format',['node','node_modules/prettier/bin/prettier.cjs','--write','../docs/performance/RF-312-native-pdf-diagnostic.md'])
run('pdf-doc-boundary',['node','scripts/check-markdown-chunk-boundary.mjs'])
run('pdf-doc-diff',['git','-c','safe.directory='+r.as_posix(),'-c','core.safecrlf=false','diff','--check'],r)
