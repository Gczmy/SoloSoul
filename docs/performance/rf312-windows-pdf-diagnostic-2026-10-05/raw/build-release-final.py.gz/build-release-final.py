import pathlib,json,hashlib,subprocess,time,datetime,shutil,sys
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-20261005')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['final-native-tests','final-native-clippy','final-fmt-check','final-node-tests','final-js-format-check','final-diff-check']:
 assert json.loads((s/(name+'.receipt.json')).read_text(encoding='utf-8-sig'))['exitCode']==0,name
freeze=json.loads((s/'source-freeze-final.json').read_text(encoding='utf-8-sig'))
assert all(sha(r/p)==h for p,h in freeze['files'].items())
args=['cargo','build','--locked','--release','-p','solo_soul','--features','native-perf','--bin','solo_soul'];started=time.time()
with (s/'final-release-build.stdout.log').open('xb') as out,(s/'final-release-build.stderr.log').open('xb') as err:
 c=subprocess.Popen(args,cwd=r/'tauri',stdout=out,stderr=err)
 (s/'final-release-build.live.json').write_text(json.dumps({'command':args,'pid':c.pid,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}),encoding='utf-8')
 print('Started PDF diagnostic Release build PID '+str(c.pid),flush=True);rc=c.wait()
receipt={'command':args,'pid':c.pid,'exitCode':rc,'elapsedSeconds':time.time()-started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(s/'final-release-build.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt),flush=True)
if rc:raise SystemExit(rc)
assert all(sha(r/p)==h for p,h in freeze['files'].items())
exe=s/'bin-final/solo_soul.exe';assert not exe.exists();shutil.copy2(r/'tauri/target/release/solo_soul.exe',exe)
resources=json.loads((s/'resource-freeze-final.json').read_text(encoding='utf-8-sig'))
assert all(sha(pathlib.Path(x['source']))==x['sha256']==sha(pathlib.Path(x['copy'])) for x in resources['records'])
assert sha(pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-preview-20261005\bin-scroll\solo_soul.exe'))==resources['oldExeSha256']
markers=[b'--native-perf-media-prepare',b'windows-native-sdk-media-journey-requested',b'windows-native-sdk-pdf-diagnostic-requested',b'windows-native-sdk-startup-requested']
data=exe.read_bytes();assert all(marker in data for marker in markers)
record={'exe':str(exe),'bytes':len(data),'sha256':sha(exe),'frozenInputsUnchanged':True,'resourcesUnchanged':True,'markers':[x.decode() for x in markers],'oldExePreserved':True}
(s/'build-checkpoint-final.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps(record),flush=True)
