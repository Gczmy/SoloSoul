import pathlib,json,gzip,hashlib,datetime,stat
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-20261005');dest=r/'docs/performance/rf312-windows-pdf-diagnostic-2026-10-05'
sha=lambda data:hashlib.sha256(data).hexdigest()
assert dest.is_dir() and not dest.is_symlink() and not list(dest.iterdir()) if dest.exists() else True
if not dest.exists(): dest.mkdir()
files=[p for p in s.iterdir() if p.is_file() and p.suffix in ['.json','.log','.py','.ps1']]
for group in ['samples100','samples100-final']:
 folder=s/group
 assert folder.is_dir()
 files.extend(p for p in folder.iterdir() if p.is_file() and p.suffix in ['.json','.log'])
 samples=sorted(x for x in folder.iterdir() if x.is_dir())
 assert [x.name for x in samples]==['sample-001','sample-002','sample-003']
 for sample in samples:
  assert not sample.is_symlink() and not sample.stat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT
  files.extend(p for p in sample.iterdir() if p.is_file() and p.suffix in ['.json','.log','.png'])
records=[]
for p in sorted(set(files)):
 assert not p.is_symlink() and not p.stat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT
 relative=p.relative_to(s).as_posix();assert not any(x in p.relative_to(s).parts for x in ['vault','webview','profile','models','bin','bin-final'])
 data=p.read_bytes();out=dest/'raw'/(relative+'.gz');out.parent.mkdir(parents=True,exist_ok=True)
 encoded=gzip.compress(data,compresslevel=9,mtime=0);assert gzip.decompress(encoded)==data;out.write_bytes(encoded)
 records.append({'original':str(p),'relativeOriginal':relative,'bytes':len(data),'sha256':sha(data),'archive':out.relative_to(dest).as_posix(),'archiveBytes':len(encoded),'archiveSha256':sha(encoded)})
index={'schemaVersion':1,'task':'RF-312','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'format':'gzip byte-exact originals; original newlines retained; index uses LF and archives use -text','files':records}
(dest/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'archives':len(records),'originalBytes':sum(x['bytes'] for x in records),'archiveBytes':sum(x['archiveBytes'] for x in records)}))
