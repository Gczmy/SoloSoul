import {readFile, writeFile, lstat, realpath} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import {checkJourney, checkBound, summarizeJourneys, PHASES} from '../../tauri/scripts/native-perf-sdk-journey.mjs';
import {memoryReading} from '../../tauri/scripts/native-perf-memory.mjs';
import {describeAuthAttribution} from '../../tauri/scripts/native-perf-auth-contract.mjs';
import {checkMaintenanceAdmission} from '../../tauri/scripts/native-perf-maintenance-contract.mjs';

const stage = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(stage, '../..');
const load = async file => JSON.parse((await readFile(file,'utf8')).replace(/^\uFEFF/,''));
const sha = async file => createHash('sha256').update(await readFile(file)).digest('hex');
const proof = await load(path.join(stage,'input-proof.json'));
assert.equal(await sha(proof.exe),proof.exeSha256);
for (const row of proof.resources) assert.equal(await sha(row.copy),row.sha256);
for (const [file,hash] of Object.entries(proof.sourceFiles)) assert.equal(await sha(path.join(root,file)),hash);
const sortedStats = values => {
  const v=[...values].sort((a,b)=>a-b);
  assert(v.length && v.every(Number.isFinite));
  return {n:v.length, median:(v[Math.floor((v.length-1)/2)]+v[Math.ceil((v.length-1)/2)])/2,
    p95:v[Math.ceil(v.length*.95)-1], min:v[0], max:v.at(-1)};
};
const groups=[];
for (const size of [100,5000]) {
  const dir=path.join(stage,`samples${size}`);
  const report=await load(path.join(dir,'native-perf-sdk-journey-results.json'));
  const receipt=await load(path.join(stage,`journey-${size}.receipt.json`));
  assert.equal(report.exeSha256,proof.exeSha256);
  assert.equal(report.samplesRequested,5);
  assert.equal(report.memoryIntervalMs,2000);
  assert.equal(report.sourceUnchanged,true);
  assert.equal(report.interrupted,false);
  assert.equal(receipt.sourceUnchanged,true);
  assert.equal(receipt.pdfiumOverrideInherited,false);
  assert.equal(receipt.resourcesUnchanged,true);
  assert.equal(receipt.originalFixtureUnchanged,true);
  assert.deepEqual(report.samples.map(s=>s.index),[1,2,3,4,5]);
  const items=[],collection=[],intervals=[],maxima=[];
  for (const s of report.samples) {
    const expected=path.join(dir,`sample-${String(s.index).padStart(3,'0')}`);
    assert.equal(s.root.toLowerCase(),expected.toLowerCase());
    assert.deepEqual(await load(path.join(dir,`sample-${String(s.index).padStart(3,'0')}.json`)),s);
    const artifacts={};
    for (const name of ['native-perf-sdk-journey.json','native-perf-auth-attribution.json','native-perf-maintenance-admission.json']) {
      const file=path.join(expected,name), stat=await lstat(file);
      assert(stat.isFile() && !stat.isSymbolicLink());
      assert.equal((await realpath(file)).toLowerCase(),file.toLowerCase());
      assert(stat.size <= (name.includes('auth-attribution') ? 262144 : 4194304));
      artifacts[name]={value:await load(file),sha256:await sha(file)};
    }
    const native=artifacts['native-perf-sdk-journey.json'].value;
    assert.deepEqual(native,s.nativeProof);
    checkBound(s.bound,s.owned,s.processId,s.bound.port);
    let journeyValid=false, journeyRejection=null;
    try {checkJourney(native,s.owned,s.bound,report.fixture,false);journeyValid=true;}
    catch(e) {journeyRejection=e.message;}
    const auth=artifacts['native-perf-auth-attribution.json'].value;
    const authDescription=describeAuthAttribution(auth,s.owned,s.bound);
    const maintenance=checkMaintenanceAdmission(artifacts['native-perf-maintenance-admission.json'].value,auth,s.owned,s.bound);
    const mem=s.memorySeries;
    assert.equal(mem.schemaVersion,1);
    assert.equal(mem.requestedIntervalMs,2000);
    assert.equal(mem.sampleCount,mem.samples.length);
    let creationMs, webviewSeen=false;
    const validValues=[];
    for(const [i,p] of mem.samples.entries()) {
      assert.equal(p.index,i+1);
      assert(Number.isFinite(p.collectionMs) && p.collectionMs>=0 && p.finishedAtMs>=p.startedAtMs);
      if(i) {
        const prev=mem.samples[i-1];
        assert(p.startedAtMs>=prev.finishedAtMs,'Memory queries overlap');
        intervals.push(p.startedAtMs-prev.startedAtMs);
      }
      const v=memoryReading(p.snapshot,{launchedAt:mem.launchedAtMs,pid:s.processId,exe:proof.exe,creationMs},s.bound.browserPid);
      if(v.valid) {
        creationMs??=v.creationMs;
        if(webviewSeen && v.scope==='root-only-before-webview') {v.valid=false;v.reason='Previously observed WebView tree disappeared';}
        webviewSeen ||= v.scope==='root-and-exact-udf-webview-tree';
      }
      if(v.valid && v.scope==='root-only-before-webview' && p.kind!=='periodic') {v.valid=false;v.reason='UI checkpoint has no verified WebView tree';}
      assert.deepEqual(v,p.validation);
      if(v.valid) validValues.push(p.snapshot.workingSetBytes);
      collection.push(p.collectionMs);
    }
    assert.equal(mem.validSampleCount,validValues.length);
    assert.equal(mem.partialMaximumWorkingSetBytes,validValues.length?Math.max(...validValues):null);
    const coverage=mem.samples.length>=3 && validValues.length===mem.samples.length && webviewSeen &&
      mem.samples.some(p=>p.kind==='before-input') && mem.samples.some(p=>p.kind==='after-journey');
    if(mem.complete) {
      assert.equal(mem.reason,null);assert(coverage);
      assert.equal(mem.observedMaximumWorkingSetBytes,Math.max(...validValues));
    }
    assert.equal(mem.collectionMaximumMs,Math.max(...mem.samples.map(p=>p.collectionMs)));
    assert.equal(mem.collectionTotalMs,mem.samples.reduce((n,p)=>n+p.collectionMs,0));
    assert.equal(mem.actualMaximumStartIntervalMs,mem.samples.length>1?Math.max(...mem.samples.slice(1).map((p,i)=>p.startedAtMs-mem.samples[i].startedAtMs)):null);
    assert.equal(mem.confirmedExitedObservations,mem.samples.reduce((n,p)=>n+(p.snapshot.exitedProcesses?.length??0),0));
    assert.equal(s.cleanupIntegrity.complete,true);
    assert.notEqual(s.cleanupIncomplete,true);
    const accepted=s.success && journeyValid && mem.complete && authDescription.frontend.flows.length===2 &&
      authDescription.frontend.flows.every(f=>f.outcome==='finished') && maintenance.failures.length===0;
    if(mem.complete) maxima.push(mem.observedMaximumWorkingSetBytes);
    items.push({index:s.index,accepted,reportedSuccess:s.success,uiSuccess:s.uiSuccess,
      journeyContractValid:journeyValid,journeyRejection,
      failedStep:native.failedStep,reason:native.reason,timeoutState:native.lastProbe?.timeoutState??null,
      phases:native.phases.map(p=>({name:p.name,durationMs:p.durationMs})),
      calls:native.calls.length,runId:s.owned.runId,pid:s.processId,
      authenticationFlowOutcomes:authDescription.frontend.flows.map(f=>f.outcome),
      maintenanceFailures:maintenance.failures,
      memory:{complete:mem.complete,sampleCount:mem.sampleCount,validSampleCount:mem.validSampleCount,
        observedMaximumWorkingSetBytes:mem.observedMaximumWorkingSetBytes,
        collectionMaximumMs:mem.collectionMaximumMs,actualMaximumStartIntervalMs:mem.actualMaximumStartIntervalMs},
      recordedIdentities:[...new Map([
        ...s.beforeSnapshot.processes,...s.afterSnapshot.processes,
        ...mem.samples.flatMap(p=>[...p.snapshot.processes,...(p.snapshot.exitedProcesses??[])])
      ].map(p=>[`${p.pid}:${p.creationMs}`,{pid:p.pid,creationMs:p.creationMs,executableName:p.executableName}])).values()],
      artifactSha256:Object.fromEntries(Object.entries(artifacts).map(([k,v])=>[k,v.sha256]))});
  }
  assert.deepEqual(report.summary,summarizeJourneys(report.samples,5,report.sourceUnchanged&&!report.interrupted));
  const complete=receipt.exitCode===0 && report.success && items.every(s=>s.accepted);
  groups.push({objects:size,complete,requested:5,accepted:items.filter(s=>s.accepted).length,
    diagnosticOnly:true,acceptedUnobservedPerformanceMetrics:null,
    observedStageDistribution:complete?Object.fromEntries(PHASES.map(name=>[name,
      sortedStats(items.map(s=>s.phases.find(p=>p.name===name).durationMs))])):null,
    observedMemoryDistribution:complete?sortedStats(maxima):null,
    collectionDurationDistribution:sortedStats(collection),actualIntervalDistribution:sortedStats(intervals),
    samplePoints:items.reduce((n,s)=>n+s.memory.sampleCount,0),
    validSamplePoints:items.reduce((n,s)=>n+s.memory.validSampleCount,0),samples:items});
}
assert.equal(new Set(groups.flatMap(g=>g.samples.map(s=>s.runId))).size,10);
const result={schemaVersion:1,task:'RF-312',scope:'current Windows home journey and sampled memory',
  accepted:groups.every(g=>g.complete),diagnosticOnly:true,
  unobservedPerformanceMetrics:null,continuousPeakMemoryMeasured:false,
  originalHomeTimeoutRootCauseEstablished:false,rf312TaskClosed:false,
  baseCommit:proof.baseCommit,exeSha256:proof.exeSha256,
  sourceManifestSha256:proof.sourceManifestSha256,groups};
await writeFile(path.join(stage,'validation.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({accepted:result.accepted,groups:groups.map(({samples,...g})=>g)},null,2));
process.exitCode=result.accepted?0:1;
