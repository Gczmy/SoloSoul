from pathlib import Path
import datetime, gzip, hashlib, io, json, re, tarfile

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
destination = root/'docs/performance/rf312-windows-current-home-memory-2026-10-10'
primary = destination.with_suffix('.json')
report = root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md'
baseline_doc = root/'docs/performance/RF-312-windows-native-app-baseline.md'
current_doc = root/'docs/performance/RF-312-current-windows-home-memory.md'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
save = lambda p,x: p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
assert not destination.exists() and not primary.exists() and not current_doc.exists()
validation=load(stage/'validation.json')
inputs=load(stage/'input-proof.json')
cleanup=load(stage/'cache-cleanup.json')
assert validation['accepted'] and len(validation['groups'])==2
assert cleanup['preservedBytesVerified'] and len(cleanup['removedCachePaths'])==80
assert cleanup['matchingOwnedIdentitiesLive']==0 and cleanup['processesTerminatedByThisTool']==0
assert cleanup['identitiesChecked']==90 and len(cleanup['linksUnlinked'])==10
for p in cleanup['preservedVaultAndRootFiles']:
    assert sha(Path(p['path']).read_bytes())==p['sha256']
for p in cleanup['applicationLogs']:
    assert sha(Path(p['copy']).read_bytes())==p['sha256']
for p,digest in inputs['sourceFiles'].items(): assert sha((root/p).read_bytes())==digest,p
assert sha(Path(inputs['exe']).read_bytes())==inputs['exeSha256']
for item in inputs['resources']: assert sha(Path(item['copy']).read_bytes())==item['sha256']
assert [g['accepted'] for g in validation['groups']]==[5,5]
assert sum(g['samplePoints'] for g in validation['groups'])==97

files=list(sorted(p for p in stage.iterdir() if p.is_file() and p.suffix in ['.py','.ps1','.mjs','.json','.log']))
for size in [100,5000]:
    group=stage/f'samples{size}'
    files.extend(sorted(p for p in group.iterdir() if p.is_file() and p.suffix=='.json'))
    for number in range(1,6):
        sample=group/f'sample-{number:03}'
        files.extend(sorted(p for p in sample.iterdir() if p.is_file() and p.name.startswith('native-perf-') and p.suffix=='.json'))
files.extend(sorted(p for p in (stage/'application-logs').rglob('*') if p.is_file()))
assert len(files)==len(set(files))
destination.mkdir()
archive=destination/'raw.tar.gz'
entries=[]
with archive.open('xb') as disk:
    with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for file in files:
                assert not file.is_symlink() and file.resolve().is_relative_to(stage.resolve())
                data=file.read_bytes();name=file.relative_to(stage).as_posix()
                assert '/vault/' not in name and '/profile/' not in name
                entry=tarfile.TarInfo(name);entry.size=len(data);entry.mtime=0;entry.mode=0o644
                tar.addfile(entry,io.BytesIO(data))
                entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers()
    assert len(members)==len(entries)
    for m,e in zip(members,entries):
        assert m.name==e['path'] and m.isfile() and m.size==e['bytes']
        assert sha(tar.extractfile(m).read())==e['sha256']
index={'schemaVersion':1,'task':'RF-312','scope':'current Windows diagnostic home/memory byte-preserved originals',
    'archive':'raw.tar.gz','archiveSha256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,
    'entryCount':len(entries),'entries':entries,'excludes':['EXE','DLL','models','physical Vault','private cache trees']}
save(destination/'index.json',index)
evidence={**validation,'date':'2026-10-10','archiveIndex':destination.name+'/index.json',
    'rawOriginalsByteVerified':True,'rawRecordCount':len(entries),'device':load(stage/'device.json'),
    'commands':[load(stage/f'journey-{n}.receipt.json') for n in [100,5000]],
    'cleanup':{'identitiesChecked':90,'matchingOwnedIdentitiesLive':0,'cachePathsRemoved':80,
        'linksUnlinked':10,'vaultAndRootFilesBytePreserved':len(cleanup['preservedVaultAndRootFiles']),
        'applicationLogsPreserved':len(cleanup['applicationLogs']),'processesTerminatedByCacheTool':0},
    'limitations':['Optional auth/maintenance instrumentation and SDK/query overhead remain enabled',
        'Observed working-set maximum is not a continuous peak or exclusive physical memory',
        'Only ten current runs; original intermittent home timeout not reproduced and root cause remains unknown',
        'No sleep, warm restart, new OCR/preview or other-platform measurements in this group',
        'Not an alternating controlled performance comparison with older builds'],
    'nextLocal':['RF-121 actual DOM/theme/palette-bound composed-window matrix',
        'Continue bounded home timeout attribution if reproduced',
        'Current-build same-profile restart revalidation'],
    'pushPerformed':False}
save(primary,evidence)

small,big=validation['groups']
fmt=lambda value: f'{value:.2f}'
def times(group,phase):
    s=group['observedStageDistribution'][phase]
    return fmt(s['median'])+' / '+fmt(s['p95'])
doc='''# RF-312 当前 Windows 首页行程与内存复核

2026-10-10，RF-1104 后的新冻结构建完成公开 100/5000 对象各五次完整行程。十次均通过，97/97 个内存点有效，二十条认证流程结束，维护准入失败为零；本组没有复现旧首页超时。**RF-312 整项仍待验证，旧超时根因仍未知。**

冻结基线为 `9687d53a0dfa91487e58631e70d1013d2a8f7980`；GUI EXE SHA256 为 `62c67208b195b6f738f6dce120914fa9f27e9cb0bc2024c086b61fedc016bd42`。复用 RF-1104 已验收构建，94 个资源与 1827 项源码输入前后逐字节核验；本阶段不改生产代码、依赖、默认路径或采样预算。

设备为 Intel Core i7-9700、8 核/8 线程、约 16 GiB RAM，Windows 11 Enterprise LTSC 26100，Node 24.16.0。两档均使用生产 Argon2id 64 MiB/3 次/并行 4 的公开合成 Vault；各样本新建私有 root/profile，不访问正式账户。TEMP/TMP 使用 D 盘，GUI 不继承 PDFium 路径覆盖。

## 当前观测

下面每格为中位数 / nearest-rank P95，单位 ms，每档 n=5，P95 是本组最大值。包含 SDK、认证诊断和查询开销，不能当作未插桩性能基线或与旧构建的受控优化对照。

| 阶段 | 100 对象 | 5000 对象 |
|---|---:|---:|
'''
for label,phase in [('登录表单启动','startup'),('主密码解锁至首页','password-unlock'),('工作区首批卡片','workspace'),('搜索 needle','search-needle'),('应用锁定','application-lock'),('主密码重解锁至首页','password-reunlock')]:
    doc+=f'| {label} | {times(small,phase)} | {times(big,phase)} |\n'
doc+='\n每两秒目标间隔进行串行 owned 进程树查询，UI 前后另有固定检查点，实际间隔保存在原件中。查询不重叠，每点重新验证 PID/birth、唯一 WebView browser、精确 UDF 与 working set 总和；确认退出的短命后代单列，不伪造零读数。\n\n'
doc+='| 内存与查询观测 | 100 对象 | 5000 对象 |\n|---|---:|---:|\n'
for label,key,scale in [('有效点数','samplePoints',None),('采样最大工作集中位 / P95（MiB）','observedMemoryDistribution',1048576),('单次查询中位 / 最大（ms）','collectionDurationDistribution',1)]:
    if scale is None: values=[str(g[key]) for g in [small,big]]
    else:
        tail='max' if key=='collectionDurationDistribution' else 'p95'
        values=[fmt(g[key]['median']/scale)+' / '+fmt(g[key][tail]/scale) for g in [small,big]]
    doc+=f'| {label} | {values[0]} | {values[1]} |\n'
doc+='''
工作集相加可能重复计算共享页，查询窗口不是原子快照，采样最大值不能代表连续峰值。旧首页超时记录、旧失败组与旧构建全部保留；本组成功不证明 RF-1104 修复了旧首页超时，不把成功子集拼成整组。

## 复跑与证据

在已按公开夹具合同准备并冻结的 D 盘测试包上，从 `tauri/` 执行，两个输出目录必须不存在：

```powershell
node scripts/native-perf-sdk-journey.mjs --exe D:\\SoloSoul\\build\\rf1104-update-preferences-20261010\\bin\\solo_soul.exe --fixture D:\\SoloSoul\\build\\rf312-maintenance-20261009\\fixtures\\vault100 --output D:\\SoloSoul\\build\\new-home-memory-100 --samples 5 --memory-interval-ms 2000
node scripts/native-perf-sdk-journey.mjs --exe D:\\SoloSoul\\build\\rf1104-update-preferences-20261010\\bin\\solo_soul.exe --fixture D:\\SoloSoul\\build\\rf312-maintenance-20261009\\fixtures\\vault5000 --output D:\\SoloSoul\\build\\new-home-memory-5000 --samples 5 --memory-interval-ms 2000
```

沿用原 SDK 128 调用、50 秒阶段和 300 秒完整行程预算。两个驱动 exit 0；另一次独立复核重读十份原生证明，执行现有行程/认证/维护合同，并重新计算所有内存点的身份、读数和分布，exit 0。源码和工具没有变化，不重复未受影响的 Rust/前端全套检查，不将旧检查当作本阶段新运行。

fresh CIM 核对 90 个记录身份退出后，缓存工具仅删除本轮 80 个精确缓存目录、解除 10 个联接，没有终止额外进程。240 个 Vault/根级证明文件及十份应用日志在清理前后逐字节校验；原始公开夹具、构建和资源保持。

完整[结构化验收](rf312-windows-current-home-memory-2026-10-10.json)与[原始字节索引](rf312-windows-current-home-memory-2026-10-10/index.json)归档全部十次样本、驱动输出/退出码、冻结输入、设备、复核和清理脚本。压缩包逐成员回读长度和 SHA256，不包含 EXE、DLL、模型、Vault 实体或缓存树。

下一步补 RF-121 Windows 实际主题/色板/前台状态绑定的窗口矩阵；首页问题出现时继续有界失败归因，并可补当前构建的同 profile 重启复核。系统睡眠、多端与 RF-112/121 原生缺口仍未完成，RF-122～127 前置不解除。按 RF-312 本阶段独立本地提交，不推送。
'''
current_doc.write_text(doc,encoding='utf-8',newline='\n')

report_before=report.read_bytes().decode('utf-8').replace('\r\n','\n')
rows_before=re.findall(r'^\| \d+ \| \[RF-\d+\].*$',report_before,re.M)
assert len(rows_before)==294
assert '### RF-312 当前 Windows 首页行程与内存复核' not in report_before
report_text=report_before.replace('RF-1104 更新源偏好许可范围修复验收完成；RF-312 整项待验证',
    'RF-1104 已验收；RF-312 当前 Windows 两档各五次首页行程与内存复核通过，整项待验证',1)
report_text=report_text.replace('- 当前处理：**RF-1104 已验收，下一步继续 RF-312 Windows 首页超时归因与 RF-121 原生材质矩阵；RF-112/121/312 与 RF-122～127 前置保持**。',
    '- 当前处理：**RF-312 当前 Windows 两档完整行程与内存复核已验，下一步补 RF-121 实际主题绑定的窗口矩阵；旧首页超时根因、RF-112/121/312 与 RF-122～127 前置保持**。',1)
report_text+='\n\n### RF-312 当前 Windows 首页行程与内存复核（2026-10-10）\n\n'
report_text+='- 使用 RF-1104 已验收新 GUI、相同原公开夹具及原预算，100/5000 各 5/5 完整行程，97/97 有效串行内存点；二十条认证流程结束，维护准入失败零。冻结1827项源码、94资源与原夹具前后不变。\n'
report_text+='- 重读全部十份原生证明并执行现有合同，独立复算进程身份、内存读数和分布。采样最大工作集中位约589/699 MiB，仅为带 SDK/诊断的观测，不当作连续峰值或未插桩性能基线；本组没有复现旧首页超时，根因保持未知。\n'
report_text+='- fresh CIM核对90个记录身份退出，仅清理80个本轮缓存并解除10个联接；240份Vault/根级原件与十份日志逐字保留。全部原始样本、命令/退出码与脚本归档并回读SHA，见[口径与复跑](performance/RF-312-current-windows-home-memory.md)、[结构化验收](performance/rf312-windows-current-home-memory-2026-10-10.json)。\n'
report_text+='- 本阶段按RF-312独立本地提交，不推送；285/294关闭、3待验证、6待执行保持。下一本地项为RF-121 Windows实际主题/色板/前台绑定的窗口矩阵；首页失败归因、当前构建热启动复核、睡眠、多端与RF-112/121/122～127前置仍未完成，goal active。\n'
assert re.findall(r'^\| \d+ \| \[RF-\d+\].*$',report_text,re.M)==rows_before
report.write_bytes(report_text.replace('\n','\r\n').encode('utf-8'))
baseline_before=baseline_doc.read_bytes().decode('utf-8').replace('\r\n','\n')
baseline_before+='\n\n## 2026-10-10 · 当前构建首页与内存复核\n\n'
baseline_before+='RF-1104后的冻结构建使用原公开100/5000对象各五次完整六阶段行程及2000ms目标内存采样，两组均exit0，97/97点有效，十次维护准入失败零。旧首页超时未复现，不能推断根因已修复；诊断/SDK开销仍在，采样最大工作集不是连续峰值。全部样本、独立合同复算和精确缓存清理见[当前复核](RF-312-current-windows-home-memory.md)。RF-312继续待验证，RF-112/121及RF-122～127前置保持；按本阶段独立本地提交，不推送。\n'
baseline_doc.write_bytes(baseline_before.replace('\n','\r\n').encode('utf-8'))
print(json.dumps({'task':'RF-312','archiveRecords':len(entries),'archiveBytes':archive.stat().st_size,
    'wholeGroupsAccepted':True,'taskRowsUnchanged':True,'closed':285,'total':294}))
