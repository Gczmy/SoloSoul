import pathlib,json,hashlib,sys,datetime
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;g='auth100-final';root=s/g
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):
 p=s/name;assert not p.exists();p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def files(base):
 rows=[]
 for p in sorted(base.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():
   assert p.resolve().is_relative_to(base.resolve());rows.append({'relativePath':str(p.relative_to(base)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':sha(p)})
 return rows
report=load(root/'native-perf-sdk-journey-results.json');auth=load(root/'native-perf-auth-attribution-results.json')
assert report['success'] is False and report['sourceUnchanged'] is True and len(report['samples'])==1 and report['samplesRequested']==3
assert auth['success'] is False and auth['performanceMetrics'] is None
sample=report['samples'][0];private=pathlib.Path(sample['root']);assert private==root/'sample-001'
assert sample['processId']==31612 and sample['ownedProcessExit']=={'exitCode':1,'signal':None,'error':None}
assert sample['success'] is False and sample['cleanupIntegrity']['complete'] is False and sample['phases']==[]
assert sample['cleanup']['cleanup']==[] and not sample.get('bound') and not sample.get('nativeProof')
negative=load(s/'auth-env-rejection.receipt.json');assert negative['pid']==26648 and negative['exitCode']==1
assert (s/'auth-env-rejection.stderr.log').read_text().strip()=='native-perf preflight failed: native-perf refuses inherited PDFIUM_LIBRARY_PATH'
assert negative['command'][2]==str(private) and negative['environment']['PDFIUM_LIBRARY_PATH']
assert (private/'native-perf-ready.json').is_file() and not (private/'native-perf-consumed.json').exists()
assert not (private/'native-perf-auth-attribution.json').exists()
mode=sys.argv[1]
if mode=='before':
 build=load(s/'build-checkpoint.json')
 write(g+'-failure-identity-scope.json',{'exe':build['exe'],'identities':[],'additionalCleanupPids':[31612,26648]})
 inventory={'root':str(private),'vaultFiles':files(private/'vault'),'topLevelArtifacts':[{'relativePath':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(private.iterdir()) if p.is_file()], 'groupFiles':[{'path':str(root/n),'sha256':sha(root/n)} for n in ['native-perf-sdk-journey-results.json','native-perf-auth-attribution-results.json','sample-001.json']]}
 write(g+'-failure-pre-cache-review.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'safeToVerifyAbsence':True,'performanceAccepted':False,'oldCleanupIntegrityStillFalse':True,'birthIdentityAvailable':False,'guardRejectionReproduced':True,'inventory':inventory})
 print('Verified failed startup evidence and froze vault/proofs; requires fresh PID absence before cleanup')
elif mode=='after':
 before=load(s/(g+'-failure-pre-cache-review.json'));inv=before['inventory'];cleanup=load(s/(g+'-cache-cleanup.json'))
 assert cleanup['complete'] and cleanup['processesTerminated']==0 and len(cleanup['verifiedIdentities'])==2
 assert all(q['creationMs'] is None and q['status']=='absent; cleanup-only PID without stored birth' for q in cleanup['verifiedIdentities'])
 assert files(private/'vault')==inv['vaultFiles']
 for row in inv['topLevelArtifacts']:
  p=private/row['relativePath'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
 for row in inv['groupFiles']:assert sha(pathlib.Path(row['path']))==row['sha256']
 for p in cleanup['removedCachePaths']:assert not pathlib.Path(p).exists()
 write(g+'-failure-post-cache-review.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'performanceAccepted':False,'oldCleanupIntegrityStillFalse':True,'vaultFilesPreserved':len(inv['vaultFiles']),'topLevelArtifactsPreserved':len(inv['topLevelArtifacts']),'processesTerminated':0,'cleanupOnlyPidAbsence':2})
 print('Failed group vault and original false reports unchanged; no guessed birth identity or new performance acceptance')
else:raise AssertionError(mode)
