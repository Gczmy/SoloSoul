import pathlib,json,hashlib,subprocess,time,datetime,shutil,sys,os
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(__file__).parent;old=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-ocr-20261005')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
write=lambda n,v:(s/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
required=['auth-target-node','auth-types','auth-core-tests','auth-store-tests','auth-lint','auth-final-js-format','auth-native-tests','auth-native-clippy','auth-default-tests-pdfium','auth-default-clippy-final','auth-final-fmt-check-final','auth-full-node-alone','auth-full-vitest','auth-cli-fmt','auth-cli-clippy','auth-cli-tests','auth-vite-build']
for name in required:assert json.loads((s/(name+'.receipt.json')).read_text(encoding='utf-8-sig'))['exitCode']==0,name
before=json.loads((old/'source-freeze-final.json').read_text(encoding='utf-8-sig'))['files']
generated_before={p:h for p,h in before.items() if p.replace('\\','/').startswith('tauri/dist/')}
files={p:sha(r/p) for p in before if p not in generated_before}
for p in ['tauri/src/stores/authStore.ts','tauri/src/lib/nativePerfAuth.ts','tauri/src/stores/authStore.test.ts','tauri/crates/solosoul-core/src/native_perf_unlock.rs','tauri/src-tauri/src/native_perf/auth_contract.rs','tauri/src-tauri/src/native_perf/auth_trace.rs','tauri/scripts/native-perf-auth-contract.mjs','tauri/scripts/native-perf-auth-attribution.mjs','tauri/scripts/native-perf-auth-attribution.test.mjs','tauri/scripts/run-node-tests.mjs']:
 files[p]=sha(r/p)
# 本轮前端也有改动；冻结所有前端源码、静态输入和 Vite 配置，不能沿用仅 Rust 的旧输入集合。
for directory in ['tauri/src','tauri/public']:
 for entry in sorted((r/directory).rglob('*')):
  if entry.is_file():
   assert not entry.is_symlink(),str(entry)
   files[str(entry.relative_to(r)).replace('\\','/')]=sha(entry)
for relative in ['tauri/index.html','tauri/package.json','tauri/package-lock.json','tauri/tsconfig.json','tauri/vite.config.ts','tauri/vite-env.d.ts']:
 files[relative]=sha(r/relative)
write('source-freeze.json',{'at':now(),'baseCommit':'5a5cf361f1f51cd4471a8bbccd86f5d2b20974e6','files':files,'changedPriorBuildInputs':[p for p,h in before.items() if p in files and files[p]!=h],'priorGeneratedFrontendArtifacts':generated_before,'priorGeneratedFrontendArtifactsRebuilt':len(generated_before)})
assert (r/'tauri/dist/index.html').is_file()
frontend={str(p.relative_to(r)):sha(p) for p in sorted((r/'tauri/dist').rglob('*')) if p.is_file()};assert frontend
write('frontend-freeze.json',{'at':now(),'files':frontend})
public=json.loads((old/'public-source-freeze-final.json').read_text(encoding='utf-8-sig'))['files']
plain=json.loads(pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-journey-20261004\fixtures-before.json').read_text(encoding='utf-8-sig'))
for v in plain: public[v['path']]=v['sha256']
assert all(sha(pathlib.Path(p))==h for p,h in public.items())
write('public-source-freeze.json',{'at':now(),'files':public})
bin=s/'bin';bin.mkdir(exist_ok=False);records=[]
resources=json.loads((old/'resource-freeze-final.json').read_text(encoding='utf-8-sig'))
for v in resources['records']:
 source=pathlib.Path(v['copy']);assert sha(source)==v['sha256'];copy=bin/v['relativePath'];assert copy.resolve().is_relative_to(bin.resolve());copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,copy);assert sha(copy)==v['sha256'];records.append({**v,'source':str(source),'copy':str(copy)})
write('resource-freeze.json',{'at':now(),'records':records})
base=json.loads((old/'baseline-after-rf1094.json').read_text(encoding='utf-8-sig'));oldexes=dict(base['oldPdfBuilds']);oldexes[base['priorOcrBuild']['exe']]=base['priorOcrBuild']['sha256'];oldbin=old/'bin-final/solo_soul.exe';oldexes[str(oldbin)]=sha(oldbin)
assert all(sha(pathlib.Path(p))==h for p,h in oldexes.items());write('previous-build-freeze.json',{'at':now(),'files':oldexes})
print(json.dumps({'sourceInputs':len(files),'frontendFiles':len(frontend),'resources':len(records),'publicFiles':len(public),'previousBuilds':len(oldexes)}),flush=True)
args=['cargo','build','--locked','--release','-p','solo_soul','--features','native-perf','--bin','solo_soul'];started=time.time();env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','')
with (s/'release-build.stdout.log').open('xb') as out,(s/'release-build.stderr.log').open('xb') as err:
 c=subprocess.Popen(args,cwd=r/'tauri',env=env,stdout=out,stderr=err);write('release-build.live.json',{'command':args,'pid':c.pid,'startedAt':now()});print('Started Release PID '+str(c.pid),flush=True);rc=c.wait()
write('release-build.receipt.json',{'command':args,'pid':c.pid,'exitCode':rc,'elapsedSeconds':time.time()-started,'finishedAt':now()});print('Release exit '+str(rc),flush=True)
if rc:raise SystemExit(rc)
assert all(sha(r/p)==h for p,h in files.items());assert all(sha(r/p)==h for p,h in frontend.items());assert all(sha(pathlib.Path(v['source']))==v['sha256']==sha(pathlib.Path(v['copy'])) for v in records)
exe=bin/'solo_soul.exe';assert not exe.exists();shutil.copy2(r/'tauri/target/release/solo_soul.exe',exe);markers=['windows-native-auth-attribution','windows-native-sdk-ui-journey-requested'];data=exe.read_bytes();assert all(x.encode() in data for x in markers)
assert all(sha(pathlib.Path(p))==h for p,h in oldexes.items());assert all(sha(pathlib.Path(p))==h for p,h in public.items())
write('build-checkpoint.json',{'at':now(),'exe':str(exe),'bytes':len(data),'sha256':sha(exe),'sourceInputsUnchanged':len(files),'frontendFilesUnchanged':len(frontend),'resourcesUnchanged':len(records),'markers':markers,'previousBuildsPreserved':len(oldexes),'publicFilesUnchanged':len(public)});print('Frozen authentication Release verified',flush=True)
