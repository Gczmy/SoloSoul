#Requires -Version 7.0
param([Parameter(Mandatory=$true)][string]$StageRoot,[Parameter(Mandatory=$true)][ValidateSet("auth100-clean-env","auth5000-clean-env")][string]$GroupName)
$ErrorActionPreference='Stop'
function TaskFull([string]$Text) {
    if($Text.StartsWith('\\?\')){$Text=$Text.Substring(4)}
    return [IO.Path]::GetFullPath($Text).TrimEnd('\')
}
function TaskSame([string]$Left,[string]$Right) { return (TaskFull $Left).Equals((TaskFull $Right),[StringComparison]::OrdinalIgnoreCase) }
function TaskOrdinary([string]$ItemPath) {
    $item=Get-Item -LiteralPath $ItemPath -Force
    if(-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {throw 'Cleanup directory is not ordinary'}
    if(-not (TaskSame $item.FullName $ItemPath)){throw 'Cleanup directory path changed'}
    return $item
}
function TaskTree([string]$ItemPath) {
    $pending=[Collections.Generic.Stack[string]]::new();$pending.Push($ItemPath)
    while($pending.Count -gt 0){
        $folder=$pending.Pop();$null=TaskOrdinary $folder
        foreach($entry in Get-ChildItem -LiteralPath $folder -Force){
            if($entry.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Cleanup tree contains a reparse entry'}
            if($entry.PSIsContainer){$pending.Push($entry.FullName)}
        }
    }
}

$taskStage=TaskFull $StageRoot
if(-not(TaskSame $taskStage 'C:\Users\40299571\AppData\Local\Temp\ss-rf312-auth-attribution-20261005')){throw 'Only this exact media stage is allowed'}
$null=TaskOrdinary $taskStage
$taskScope=Get-Content -LiteralPath (Join-Path $taskStage ($GroupName+'-identity-scope.json')) -Raw -Encoding utf8 | ConvertFrom-Json
$taskReport=Get-Content -LiteralPath (Join-Path $taskStage ($GroupName+'\native-perf-sdk-journey-results.json')) -Raw -Encoding utf8 | ConvertFrom-Json
if(-not $taskReport.success -or $taskReport.scope -ne 'windows-native-sdk-input-performance' -or -not $taskReport.sourceUnchanged -or $taskReport.samples.Count -ne 3 -or $taskReport.summary.Count -ne 6 -or @($taskReport.summary|Where-Object{$_.successfulSamples -ne 3 -or $null -eq $_.medianMs -or $null -eq $_.p95Ms}).Count -ne 0){throw 'Complete six-phase group contract changed'}
$taskAuth=Get-Content -LiteralPath (Join-Path $taskStage ($GroupName+'\native-perf-auth-attribution-results.json')) -Raw -Encoding utf8 | ConvertFrom-Json
$taskReview=Get-Content -LiteralPath (Join-Path $taskStage ($GroupName+'-actual-auth-review.json')) -Raw -Encoding utf8 | ConvertFrom-Json
if(-not $taskAuth.success -or -not $taskAuth.diagnosticOnly -or $null -ne $taskAuth.performanceMetrics -or $taskAuth.samples.Count -ne 3 -or -not $taskReview.success -or $taskReview.wholeSamples -ne 3){throw 'Independent authentication review missing'}
$taskTargets=@();$taskLinks=@();$taskRoots=@();$taskVerified=@();$taskPreservedLogs=@()
$taskPackagedBase='C:\Users\40299571\AppData\Local\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache'
$taskRoamingBases=@([Environment]::GetFolderPath('ApplicationData'),(Join-Path $taskPackagedBase 'Roaming'))
$taskLocalBases=@([Environment]::GetFolderPath('LocalApplicationData'),(Join-Path $taskPackagedBase 'Local'))
foreach($sample in $taskReport.samples){
  if(-not $sample.cleanupIntegrity.complete -or -not $sample.success -or -not $sample.nativeProof.success -or $sample.nativeProof.scope -ne 'windows-native-sdk-ui-journey' -or $sample.nativeProof.phases.Count -ne 6){throw 'Complete native sample contract changed'}
  $authSample=@($taskAuth.samples|Where-Object{$_.index -eq $sample.index})
  if($authSample.Count -ne 1 -or -not $authSample[0].success -or -not $authSample[0].journeySuccess -or $authSample[0].diagnostic.frontend.flows.Count -ne 2 -or @($authSample[0].diagnostic.frontend.flows|Where-Object{$_.outcome -ne 'finished'}).Count -ne 0){throw 'Authentication sample contract changed'}
  $root=TaskFull $sample.root
  $expected=Join-Path $taskStage ($GroupName+'\sample-'+([int]$sample.index).ToString('000'))
  if(-not(TaskSame $root $expected)){throw 'Root outside exact sample'}
  $null=TaskOrdinary $root
  $owned=Get-Content -LiteralPath (Join-Path $root 'native-perf-owned.json') -Raw -Encoding utf8 | ConvertFrom-Json
  if($owned.schemaVersion -ne 1 -or $owned.scope -ne 'windows-native-perf-owned' -or -not $owned.nativePerfFeature -or $owned.runId -notmatch '^[a-f0-9]{32}$' -or $owned.identifier -ne ('com.solosoul.rf312perf.'+$owned.runId) -or -not(TaskSame $owned.root $root)){throw 'Owner marker changed'}
  if(-not(TaskSame $owned.vault (Join-Path $root 'vault')) -or -not(TaskSame $owned.webview (Join-Path $root 'webview')) -or -not(TaskSame $owned.profile (Join-Path $root 'profile'))){throw 'Private namespace changed'}
  $roaming=TaskFull $owned.roaming;$local=TaskFull $owned.local
  if(-not($taskRoamingBases|Where-Object{TaskSame $roaming (Join-Path $_ $owned.identifier)}) -or -not($taskLocalBases|Where-Object{TaskSame $local (Join-Path $_ $owned.identifier)})){throw 'Known-folder owner namespace changed'}
  if($owned.ownedPaths.Count -ne 3 -or -not(TaskSame $owned.ownedPaths[0] $root) -or -not(TaskSame $owned.ownedPaths[1] $roaming) -or -not(TaskSame $owned.ownedPaths[2] $local)){throw 'Owner paths disagree'}
  $taskRoots+=$root
  foreach($child in @('app-data','plugins','profile','temp','webview','models')){$taskTargets+=Join-Path $root $child}
  $taskTargets+=@($roaming,$local)
}
$taskIds=@($taskScope.identities);$taskPids=@($taskIds|ForEach-Object{[uint32]$_.pid}|Sort-Object -Unique)
for($offset=0;$offset -lt $taskPids.Count;$offset+=32){
  $last=[Math]::Min($offset+31,$taskPids.Count-1);$batch=@($taskPids[$offset..$last]);$filter=($batch|ForEach-Object{'ProcessId='+$_}) -join ' OR '
  $rows=@(Get-CimInstance Win32_Process -Filter $filter -Property ProcessId,CreationDate,Name)
  foreach($id in @($taskIds|Where-Object{$batch -contains [uint32]$_.pid})){
    $current=@($rows|Where-Object{$_.ProcessId -eq $id.pid});if($current.Count -gt 1){throw 'Ambiguous process metadata'};$state='absent'
    if($current.Count -eq 1){
      if($null -eq $current[0].CreationDate -or [string]::IsNullOrEmpty($current[0].Name)){throw 'Incomplete process metadata'}
      $birth=([DateTimeOffset]$current[0].CreationDate.ToUniversalTime()).ToUnixTimeMilliseconds()
      if($birth -eq [long]$id.creationMs){throw 'Recorded process still live'};$state='pid-reused-with-different-creation'
    }
    $taskVerified+=[ordered]@{pid=$id.pid;creationMs=$id.creationMs;executableName=$id.executableName;status=$state}
  }
}
foreach($extraPid in @($taskScope.additionalCleanupPids)){
  $extraRows=@(Get-CimInstance Win32_Process -Filter ('ProcessId='+[uint32]$extraPid) -Property ProcessId,CreationDate,Name)
  if($extraRows.Count -ne 0){throw 'Additional cleanup PID still present; identify it before cache removal'}
  $taskVerified+=[ordered]@{pid=$extraPid;creationMs=$null;executableName=$null;status='absent; cleanup-only PID without stored birth'}
}
$exeRows=@(Get-CimInstance Win32_Process -Filter "Name='solo_soul.exe'" -Property ProcessId,ExecutablePath)
if(@($exeRows|Where-Object{[string]::IsNullOrEmpty($_.ExecutablePath) -or (TaskSame $_.ExecutablePath $taskScope.exe)}).Count -gt 0){throw 'Owned or ambiguous EXE still live'}
$taskTargets=@($taskTargets|Sort-Object -Unique)
foreach($candidate in $taskTargets){$absolute=TaskFull $candidate;if(-not(TaskSame $candidate $absolute)){throw 'Unresolved target'};$null=TaskOrdinary $absolute}
foreach($root in $taskRoots){
  $model=Join-Path $root 'models'
  foreach($entry in Get-ChildItem -LiteralPath $model -Force){
    if($entry.Attributes -band [IO.FileAttributes]::ReparsePoint){
      $targets=@($entry.Target)
      if(-not(TaskSame (Split-Path -Parent $entry.FullName) $model) -or $entry.LinkType -notin @('SymbolicLink','Junction') -or $targets.Count -ne 1 -or -not((TaskFull $targets[0]).StartsWith('C:\Users\40299571\AppData\Local\Temp\ss-rf312-auth-attribution-20261005\bin'+'\',[StringComparison]::OrdinalIgnoreCase))){throw 'Unexpected model link'}
      $taskLinks+=[ordered]@{path=$entry.FullName;linkType=$entry.LinkType;targets=$targets}
    }
  }
  $inet=Join-Path $root 'profile\AppData\Local\Microsoft\Windows\INetCache';$linkPath=Join-Path $inet 'Content.IE5';$targetPath=Join-Path $inet 'IE'
  if(Test-Path -LiteralPath $linkPath){
    $null=TaskOrdinary $inet;$link=Get-Item -LiteralPath $linkPath -Force;$targets=@($link.Target)
    if(-not($link.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $link.LinkType -ne 'Junction' -or $targets.Count -ne 1 -or -not(TaskSame $targets[0] $targetPath) -or -not(TaskSame $link.FullName $linkPath)){throw 'Unexpected private cache link'}
    if(Test-Path -LiteralPath $targetPath){$null=TaskOrdinary $targetPath}
    $taskLinks+=[ordered]@{path=$link.FullName;linkType=$link.LinkType;targets=$targets}
  }
}
foreach($root in $taskRoots){
  $logs=Join-Path $root 'app-data\logs'
  if(Test-Path -LiteralPath $logs){
    TaskTree $logs
    foreach($entry in Get-ChildItem -LiteralPath $logs -File -Recurse -Force){
      $relative=$entry.FullName.Substring($logs.Length).TrimStart('\');$copy=Join-Path $root ('preserved-app-logs\'+$relative)
      if(Test-Path -LiteralPath $copy){throw 'Log preservation target already exists'}
      $null=New-Item -ItemType Directory -Path (Split-Path -Parent $copy) -Force
      $hash=(Get-FileHash -LiteralPath $entry.FullName -Algorithm SHA256).Hash
      Copy-Item -LiteralPath $entry.FullName -Destination $copy
      if((Get-FileHash -LiteralPath $copy -Algorithm SHA256).Hash -ne $hash){throw 'Copied log differs'}
      $taskPreservedLogs+=[ordered]@{source=$entry.FullName;copy=$copy;sha256=$hash.ToLowerInvariant()}
    }
  }
}
foreach($link in $taskLinks){Remove-Item -LiteralPath $link.path -Force}
foreach($candidate in $taskTargets){TaskTree (TaskFull $candidate)}
$taskDeleted=@()
foreach($candidate in $taskTargets){$absolute=TaskFull $candidate;Remove-Item -LiteralPath $absolute -Recurse -Force;$taskDeleted+=$absolute}
$receipt=[ordered]@{at=[DateTime]::UtcNow.ToString('o');stageRoot=$taskStage;roots=$taskRoots;verifiedIdentities=$taskVerified;removedCachePaths=$taskDeleted;unlinkedCacheEntries=$taskLinks;preservedLogs=$taskPreservedLogs;preserved=@('Vault','all proofs and reports','all EXEs and resources','source fixtures');processesTerminated=0;complete=$true}
[IO.File]::WriteAllText((Join-Path $taskStage ($GroupName+'-cache-cleanup.json')),($receipt|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
Write-Output ('Exited identities: '+$taskVerified.Count+'; removed private cache paths: '+$taskDeleted.Count+'; unlinked entries: '+$taskLinks.Count)
