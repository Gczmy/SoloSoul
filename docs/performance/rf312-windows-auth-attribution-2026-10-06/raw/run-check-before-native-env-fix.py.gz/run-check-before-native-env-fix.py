import pathlib,sys,subprocess,json,time,datetime,os
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul');name=sys.argv[1];args=sys.argv[2:];assert args and name.replace('-','').isalnum()
env=os.environ.copy();env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','');start=time.time()
env['PDFIUM_LIBRARY_PATH']=str(r/'tauri/src-tauri/resources/pdfium/pdfium.dll')
env['CARGO_BUILD_JOBS']='2'
with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
 p=subprocess.Popen(args,cwd=r/'tauri',env=env,stdout=out,stderr=err)
 (s/(name+'.live.json')).write_text(json.dumps({'command':args,'pid':p.pid,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n',encoding='utf-8')
 print('Started '+name+' PID '+str(p.pid),flush=True);code=p.wait()
(s/(name+'.receipt.json')).write_text(json.dumps({'command':args,'pid':p.pid,'exitCode':code,'environment':{'PDFIUM_LIBRARY_PATH':env['PDFIUM_LIBRARY_PATH'],'CARGO_BUILD_JOBS':env['CARGO_BUILD_JOBS']},'elapsedSeconds':time.time()-start,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n',encoding='utf-8')
print(name+' exit '+str(code),flush=True)
if code:
 print((s/(name+'.stderr.log')).read_text(encoding='utf-8',errors='replace')[-6000:]);print((s/(name+'.stdout.log')).read_text(encoding='utf-8',errors='replace')[-6000:])
raise SystemExit(code)
