from verify_auth_freezes import verify_sources
import pathlib,json,hashlib,sys,datetime
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda n:json.loads((s/n).read_text(encoding='utf-8-sig'))
for group in sys.argv[1:]:
 assert group in ['auth100-clean-env','auth5000-clean-env']
 cleanup=load(group+'-cache-cleanup.json');assert cleanup['complete'] and cleanup['processesTerminated']==0
 frozen=load(group+'-pre-cache-vault-freeze.json');vault_files=0;artifacts=0
 assert len(frozen['roots'])==3
 for sample in frozen['roots']:
  root=pathlib.Path(sample['root']);assert root.resolve().is_relative_to((s/group).resolve())
  paths={str(p.relative_to(root/'vault')).replace('\\','/'):p for p in (root/'vault').rglob('*') if p.is_file()}
  assert set(paths)==set(v['relativePath'] for v in sample['files'])
  for value in sample['files']:
   p=paths[value['relativePath']];assert p.stat().st_size==value['bytes'] and sha(p)==value['sha256'];vault_files+=1
  for value in sample['topLevelArtifacts']:
   p=root/value['relativePath'];assert p.is_file() and p.stat().st_size==value['bytes'] and sha(p)==value['sha256'];artifacts+=1
 for value in frozen['groupFiles']:assert sha(pathlib.Path(value['path']))==value['sha256']
 for value in cleanup['preservedLogs']:assert sha(pathlib.Path(value['copy']))==value['sha256']
 for value in cleanup['removedCachePaths']:assert not pathlib.Path(value).exists()
 for value in cleanup['unlinkedCacheEntries']:assert not pathlib.Path(value['path']).exists()
 verify_sources(s,r)
 for name in ['frontend-freeze.json']:
  values=load(name)['files'];assert all(sha(r/p)==h for p,h in values.items()),name
 for name in ['public-source-freeze.json','previous-build-freeze.json']:
  values=load(name)['files'];assert all(sha(pathlib.Path(p))==h for p,h in values.items()),name
 for value in load('resource-freeze.json')['records']:assert sha(pathlib.Path(value['source']))==value['sha256']==sha(pathlib.Path(value['copy']))
 build=load('build-checkpoint.json');assert sha(pathlib.Path(build['exe']))==build['sha256']
 out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'wholeSamples':3,'vaultFilesUnchanged':vault_files,'topLevelArtifactsUnchanged':artifacts,'groupReportsUnchanged':len(frozen['groupFiles']),'preservedLogs':len(cleanup['preservedLogs']),'recordedIdentitiesChecked':len(cleanup['verifiedIdentities']),'removedPrivateCachePaths':len(cleanup['removedCachePaths']),'unlinkedPrivateCacheEntries':len(cleanup['unlinkedCacheEntries']),'processesTerminatedByCacheTool':0,'sourceAndFrontendFrozen':True,'publicSourcesAndPreviousBuildsUnchanged':True,'resourcesUnchanged':True}
 p=s/(group+'-post-cache-review.json');assert not p.exists();p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(out,ensure_ascii=False),flush=True)
