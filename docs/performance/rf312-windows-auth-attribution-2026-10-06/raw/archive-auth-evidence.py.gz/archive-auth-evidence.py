import pathlib,json,hashlib,gzip,sys,datetime
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul');dest=r/'docs/performance/rf312-windows-auth-attribution-2026-10-06'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda n:json.loads((s/n).read_text(encoding='utf-8-sig'))
assert load('release-build.receipt.json')['exitCode']==0 and load('required-checks.json')['success']
for group in ['auth100-clean-env','auth5000-clean-env']:
 assert load(group+'/native-perf-auth-attribution-results.json')['success']
 assert load(group+'-actual-auth-review.json')['success'] and load(group+'-post-cache-review.json')['success']
assert load('auth100-final-failure-post-cache-review.json')['success']
if dest.exists():
 assert dest.is_dir() and not dest.is_symlink() and list(dest.iterdir())==[dest/'raw']
 assert (dest/'raw').is_dir() and not (dest/'raw').is_symlink() and not list((dest/'raw').iterdir())
else:(dest/'raw').mkdir(parents=True)
files=[p for p in s.iterdir() if p.is_file() and p.suffix in ['.py','.ps1','.json','.md','.log','.mjs','.js']]
for group in ['auth100-clean-env','auth5000-clean-env','auth100-final']:
 g=s/group;assert g.is_dir()
 files.extend(p for p in g.iterdir() if p.is_file() and p.suffix in ['.json','.log'])
 expected_json={'sample-%03d.json'%q['index'] for q in json.loads((g/'native-perf-sdk-journey-results.json').read_text(encoding='utf-8-sig'))['samples']}
 for sample in sorted(g.glob('sample-*')):
  assert not sample.is_symlink()
  if sample.is_file():
   assert sample.name in expected_json;continue
  assert sample.is_dir()
  files.extend(p for p in sample.iterdir() if p.is_file() and p.suffix in ['.json','.log','.png'])
  logs=sample/'preserved-app-logs'
  if logs.exists():files.extend(p for p in logs.rglob('*') if p.is_file())
sources=s/'current-sources'
if sources.exists():files.extend(p for p in sources.rglob('*') if p.is_file())
rows=[]
for p in sorted(set(files)):
 assert not p.is_symlink() and p.resolve().is_relative_to(s.resolve())
 body=p.read_bytes();rel=pathlib.PurePosixPath('raw')/pathlib.PurePosixPath(str(p.relative_to(s)).replace('\\','/')+'.gz')
 copy=dest/pathlib.Path(str(rel));copy.parent.mkdir(parents=True,exist_ok=True);assert not copy.exists()
 data=gzip.compress(body,compresslevel=9,mtime=0);copy.write_bytes(data);assert gzip.decompress(copy.read_bytes())==body
 rows.append({'original':str(p),'archive':str(rel),'bytes':len(body),'sha256':sha(body),'archiveBytes':len(data),'archiveSha256':sha(data)})
index={'schemaVersion':1,'task':'RF-312','scope':'windows-native-auth-attribution-raw-synthetic-only','files':rows}
(dest/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for row in rows:
 raw=(dest/row['archive']).read_bytes();body=gzip.decompress(raw)
 assert len(raw)==row['archiveBytes'] and sha(raw)==row['archiveSha256'] and len(body)==row['bytes'] and sha(body)==row['sha256']
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'archives':len(rows),'originalBytes':sum(v['bytes'] for v in rows),'archiveBytes':sum(v['archiveBytes'] for v in rows),'excluded':['EXEs','model/DLL binaries','Vault physical files','cache trees'],'allDecompressedBytesVerified':True,'index':str(dest/'index.json')}
p=s/'raw-archive-review.json';assert not p.exists();p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(receipt,ensure_ascii=False),flush=True)
