from verify_auth_freezes import verify_sources
import pathlib,json,hashlib,sys,datetime
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul');d=r/'docs/performance';stem='rf312-windows-auth-attribution-2026-10-06'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
index=load(d/stem/'index.json');paths={q['archive'] for q in index['files']}
for name in ['auth100-final/native-perf-sdk-journey-results.json','auth100-final/native-perf-auth-attribution-results.json','auth-env-rejection.stderr.log','native-driver-mode-failure.json','auth-sdk-mode-red.stdout.log','auth-default-tests.stdout.log','auth-full-node.stdout.log']:
 assert 'raw/'+name+'.gz' in paths,name
checks=load(s/'required-checks.json');assert checks['success'];build=load(s/'build-checkpoint.json');assert sha(pathlib.Path(build['exe']))==build['sha256'];verify_sources(s,r)
additional={n:load(s/(n+'.receipt.json')) for n in ['auth-sdk-mode-target','auth-sdk-mode-full-node','auth-sdk-mode-format','auth-native100-clean-env','auth-native5000-clean-env']};assert all(v['exitCode']==0 for v in additional.values())
groups=[];tables=[];ambiguous=0
for count in [100,5000]:
 g='auth'+str(count)+'-clean-env';actual=load(s/(g+'-actual-auth-review.json'));post=load(s/(g+'-post-cache-review.json'));report=load(s/g/'native-perf-sdk-journey-results.json')
 assert actual['success'] and post['success'] and report['success'] and len(actual['samples'])==3
 ambiguous+=sum(not q['accountsBackendPairing']['paired'] for q in actual['samples'])
 groups.append({'objectCount':count,'samplesRequested':3,'wholeSamplesAccepted':3,'diagnosticOnly':True,'performanceMetrics':None,'samples':actual['samples'],'summary':actual['summary'],'cleanup':post})
 tables.append({q['name']:q for q in actual['summary']})
failure=load(s/'auth100-final-failure-post-cache-review.json');assert failure['success'] and failure['performanceAccepted'] is False
result={'schemaVersion':1,'task':'RF-312','scope':'windows-native-auth-attribution-acceptance','date':'2026-10-06','stageAccepted':True,'taskClosed':False,'diagnosticOnly':True,'performanceMetrics':None,'oldHomeTimeoutReproduced':False,'oldHomeTimeoutRootCauseEstablished':False,'instrumentation':{'requestOrResponseBodyRead':False,'originalFetchPromisePreserved':True,'fixedTokensOnly':True,'backendDefaultFeatureEnabled':False,'frontendDefaultBridgeAbsentNoOp':True,'frontendDefaultBytesUnchanged':False,'clocksSubtracted':False,'nestedDurationsSummed':False,'concurrentAccountsSamplesUnpaired':ambiguous,'stageCompletedMeans':'call returned; best-effort persistence/background work not independently proven','stateSetDoneMeans':'Zustand synchronous set and subscribers returned; not React paint'},'frozenBuild':build,'measurementSourceFreeze':load(s/'measurement-source-freeze.json'),'checks':checks['requiredChecks'],'additionalChecks':additional,'testCounts':{'frontend':{'files':256,'passed':2244},'defaultRustWorkspace':{'passed':1861,'ignored':3},'nativePerfRust':{'passed':99},'coreObserverFeature':{'passed':2},'cli':{'passed':336,'ignored':2},'nodeFinal':{'passed':214,'skipped':1},'nodeTargetedFinal':{'passed':19},'authStoreTargeted':{'passed':16}},'groups':groups,'failuresPreserved':{'sdkMode':{'beforeGuiSampleCreation':True,'redRegressionPreserved':True,'fixedMode':'sdk-input'},'guiInheritedPdfium':{'originalGroupSuccess':False,'originalCleanupIntegrityComplete':False,'negativeGuardReproduced':True,'guardUnchanged':True,'onlyGuiRunnerEnvironmentCorrected':True,'postCleanup':failure},'defaultPdfium':{'failedPdfTests':18,'explicitVerifiedDllFollowingExistingCI':True,'productLoaderChanged':False},'nodePowerShellMock':{'originalBudgetMs':15000,'originalFailurePreserved':True,'laterFullRunPassed':True,'rootCauseProven':False},'releasePreflight':{'oldMixedFreezeEntries':459,'oldSourceConfigEntries':424,'oldGeneratedDistEntries':35,'compilerStartedOnFailedPreflight':False,'newSources':1314,'newGeneratedDist':35,'oldFreezeRetained':True}},'rawArchive':{'index':stem+'/index.json','files':len(index['files']),'allDecompressedBytesVerified':True},'remaining':['account-write internal attribution','old intermittent home timeout','same-scope multiplatform distributions','system sleep coverage','RF-112 isolated macOS restoration','RF-121 full native material matrix','RF-122 to RF-127 original dependencies'],'localCommitOnly':True,'pushed':False}
def save(p,text):
 assert not p.exists(),str(p);p.write_text(text,encoding='utf-8',newline='\n')
save(d/(stem+'.json'),json.dumps(result,ensure_ascii=False,indent=2)+'\n')
text=(s/'auth-attribution-notes.md').read_text(encoding='utf-8-sig').replace('# RF-312 Windows 认证阶段诊断（两档完整样本已核验）','# RF-312 Windows 认证阶段原生诊断')
text+='''
## 冻结与实际分布

新Release SHA-256 `{sha}`，103510528字节。1314源码/配置、35新dist、94资源、185公开源和十个旧EXE保持。默认前端包含桥缺失时不记录的helper，不能声称默认前端字节完全不变。两档各三个全新owned root/profile，生产Argon2id 64MiB/3 iter/4 parallelism。

以下为中位 / P95，单位ms，每格n=3，P95为这三次最大值，包含观测开销。首次登录与再次解锁分开统计，带观测器的结果只用于归因，不构成新的无观测器性能基线。

| 阶段 | 100 首次登录 | 5000 首次登录 | 100 再次解锁 | 5000 再次解锁 |
| --- | ---: | ---: | ---: | ---: |
'''.replace('{sha}',build['sha256'])
for key,label in [('login-await','前端实际login await'),('backend-attempt','后端login全调用'),('account-write-call','账户写入调用'),('kdf','KDF'),('accounts-await','登录后账户列表await'),('login-after-headers','响应头到实际await完成'),('state-write','同步状态写入')]:
 values=[]
 for flow in [1,2]:
  for table in tables:
   q=table['flow'+str(flow)+':'+key];values.append(f"{q['medianMs']:.2f} / {q['p95Ms']:.2f}")
 text+='| '+label+' | '+' | '.join(values)+' |\n'
text+='''
## 复跑、原件与未完成范围

先准备[公开合成Vault](RF-312-native-vault-baseline.md)，构建 `cargo build --locked --release -p solo_soul --features native-perf --bin solo_soul` 并冻结当前源码、dist、资源和EXE。GUI测量环境必须没有 `PDFIUM_LIBRARY_PATH` 覆盖，输出使用新绝对目录，不重用consumed marker，也不并发运行内存采样。下列 `C:\\rf312` 是另一份已准备并核验测试包的路径示例：

```powershell
cd C:\\Users\\40299571\\SoloSoul\\tauri
node scripts/native-perf-auth-attribution.mjs --exe C:\\rf312\\bin\\solo_soul.exe --fixture C:\\rf312\\vault100 --output C:\\rf312\\new-auth100 --samples 3
node scripts/native-perf-auth-attribution.mjs --exe C:\\rf312\\bin\\solo_soul.exe --fixture C:\\rf312\\vault5000 --output C:\\rf312\\new-auth5000 --samples 3
```

[结构化验收]({stem}.json)及[{count}份逐字节原件]({stem}/index.json)包含所有成功、失败、红绿回归、冻结和清理证据；不含EXE/模型/DLL、Vault物理文件或缓存树。旧首页超时、系统睡眠和完整多端同口径验收未完成；RF-312继续待验证，RF-112/121和RF-122～127前置保持。按本阶段独立本地提交，不推送。
'''.replace('{stem}',stem).replace('{count}',str(len(index['files'])))
save(d/'RF-312-native-auth-attribution.md',text)
main=r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';lines=main.read_text(encoding='utf-8-sig').splitlines();assert lines[2].startswith('> 最后更新：')
lines[2]='> 最后更新：2026-10-06（RF-312认证观测两档已验；账户写入归因/首页超时继续）'
indices=[i for i,line in enumerate(lines) if line.startswith('- 当前处理：')];assert len(indices)==1
lines[indices[0]]='- 当前处理：**RF-312：Windows认证观测100/5000各三次完整行程已验；下一步账户写入内部归因和RF-121完整窗口合成。原首页超时根因、多端和依赖门禁保持未完成**。'
text='\n'.join(lines)+'\n';old='[!] Windows100/5000首次OCR已验；首页超时/多端待验';assert text.count(old)==1;text=text.replace(old,'[!] Windows认证观测已验；首页超时/多端待验')
checkpoint='''
### RF-312 Windows 认证阶段原生观测验收（2026-10-06）

- 固定前端桥与非默认Rust观察器分别记录IPC响应头、真实await、同步状态写入及后端阶段，不读请求/响应正文，原Promise/密码管理/业务结果保持。绑定owned root/runId/PID/frame/loader/timeOrigin，时钟分开、嵌套不相加，三个账户列表并发样本保留歧义。
- 新冻结Release `{sha}`；1314源码/配置、35新dist、94资源、185公开源和十个旧EXE保持。Release后仅修正两个外部Node包装器/回归文件，Rust/前端及其余1312输入不变，新测量冻结另存。
- 100/5000各三次完整六阶段、每样本61次SDK调用和两条finished认证流通过。账户写入调用1803.06～5258.70ms、KDF127.61～198.92ms；仅为带观测器的阶段归因，具体原子写/权限内部和旧首页超时根因尚未证明，同步set不是React绘制。
- 默认Rust1861/非默认99/Core观察器2/前端2244/CLI336/最终Node214通过；默认Rust3、CLI2既有ignored和Node1既有权限skip保持，严格Clippy/格式/类型/Lint/新Vite构建通过。SDK模式红绿回归、GUI继承DLL变量拒绝、单测PDFium缺路径、原15秒Node失败和旧dist冻结失败原件全部保留，未降预算/断言/身份门禁，未修改依赖或原生环境守卫。
- 成功组fresh CIM核验54个PID/birth身份退出，旧失败另确认两个无birth PID缺席；精确清理56缓存/六链接，保留六份日志、59个完整Vault文件和全部证明/公开源/资源/旧构建。缓存工具未终止进程，旧失败success/cleanupIntegrity仍false。
- [复跑与口径](performance/RF-312-native-auth-attribution.md)、[结构化验收](performance/{stem}.json)和[{count}份原件](performance/{stem}/index.json)归档。按本阶段独立本地提交，不推送；276/285、3待验证、6待执行不变。下一本地项账户写入内部归因及Windows RF-121完整窗口合成，首页超时/睡眠/多端和RF-112/121/122～127前置保持未完成，goal active。
'''.replace('{sha}',build['sha256']).replace('{stem}',stem).replace('{count}',str(len(index['files'])))
main.write_text(text+checkpoint,encoding='utf-8',newline='\n')
base=d/'RF-312-windows-native-app-baseline.md';text=base.read_text(encoding='utf-8-sig')
text+='''

## 2026-10-06 · 认证阶段原生观测

100/5000各三个完整六阶段样本、每次两条finished认证流通过。响应头、前端真实await、同步状态写入和后端阶段分开记录；原Promise/隐私/身份/预算规则保持。带观测器的数据仅作归因，performanceMetrics=null，不替代旧无观测器基线。

十二次账户写入调用1803.06～5258.70ms、KDF127.61～198.92ms；写入内部的原子写/权限设置尚待拆分。两类时钟不相减、嵌套时长不相加、同步set不等于React绘制，未证明旧首页超时根因。[完整口径](RF-312-native-auth-attribution.md)、[结构化验收]({stem}.json)和[所有原件]({stem}/index.json)保留成功与失败、红绿回归、冻结和清理。RF-312下一本地项为账户写入和Windows RF-121完整窗口合成；首页超时/睡眠/多端及其他任务前置保持。独立本地提交，不推送。
'''.replace('{stem}',stem)
base.write_text(text,encoding='utf-8',newline='\n')
print('Saved canonical diagnostic and acceptance; checkpoint remains 276/285, 3 waiting, 6 pending')
