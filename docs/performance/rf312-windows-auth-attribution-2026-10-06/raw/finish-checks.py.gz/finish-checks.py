import pathlib,subprocess,sys
s=pathlib.Path(__file__).parent
commands=[
 ('auth-full-node-alone',['node','scripts/run-node-tests.mjs']),
 ('auth-full-vitest',['node','node_modules/vitest/vitest.mjs','run']),
 ('auth-cli-fmt',['cargo','+1.99.0','fmt','--manifest-path','../solosoul_cli/Cargo.toml','--','--check']),
 ('auth-cli-clippy',['cargo','clippy','--locked','--manifest-path','../solosoul_cli/Cargo.toml','--all-targets','--','-D','warnings']),
 ('auth-cli-tests',['cargo','test','--locked','--manifest-path','../solosoul_cli/Cargo.toml','--verbose','--no-fail-fast']),
 ('auth-vite-build',['node','node_modules/vite/bin/vite.js','build']),
]
for name,args in commands:
 rc=subprocess.call([sys.executable,str(s/'run-check.py'),name,*args])
 if rc:raise SystemExit(rc)
print('Required remaining frontend/CLI checks complete',flush=True)
