# RF-312 Windows 认证阶段诊断（两档完整样本已核验）

本轮用于区分旧首页超时发生在输入触发、IPC 返回、前端等待、账户刷新、状态提交还是后端解锁阶段。必要代码检查已完成：默认 Rust workspace 1861 passed/0 failed/3既有ignored，非默认Rust 99项、Core观察器2项，完整Vitest 256文件/2244项、CLI 336 passed/0 failed/2既有ignored、Node最后复验214 passed/0 failed/1既有权限skip（新增真实SDK模式边界回归后）。默认与非默认严格Clippy、类型、格式和新Vite构建均通过。新隔离Release已成功构建，100/5000各三次完整原生行程与独立时钟复算通过；原首页超时本轮未复现，根因未确定。

观测接口只接收固定阶段名，不读取请求/响应正文、密码、账户名或错误消息。fetch返回原Promise，Tauri-Response响应头只说明协议状态；实际invoke Promise完成由authStore在await之后记录。桥缺失或异常时不改变业务结果。

后端阶段包括root-read、maintenance-admission、sync-disable、blocking-queue、worker-vault-read、core-unlock，以及Core内的recovery、precheck、master-config、kdf、verify、account-write-call、kdf-upgrade、vault-open、session-publish、pin-reset-call。audit-call和cleanup-dispatch表示调用返回，不证明best-effort持久化成功或后台清理完成。running没有终结耗时；interrupted只记录到失败的耗时，不作为成功完成时长。

前端使用同一文档performance时钟；后端使用进程内Instant时钟，零点为第一次记录认证命令时创建的观察器，不是应用进程启动时刻。两者不相减。core-unlock包含KDF等内部阶段，嵌套时长不能相加。只有同命令的前后端记录数量一致且各自串行时才按顺序配对；并发时明确记为有歧义。

独立artifact绑定runId、PID、mainFrameId、loaderId和timeOrigin。采集在导航、子frame和进程守卫解除之前完成。未知字段、非法阶段顺序、将来时间、终结attempt之后的stage或未经核对的root均拒绝。正常IPC observer的旧字段不变。

实际采用同一新冻结Release、公开生产KDF 100/5000对象数据，各3次fresh root/profile，完整startup→password-unlock→workspace→search→application-lock→password-reunlock行程。原时限、IPC完整性、真实输入和cleanup要求保持，失败组保留，不拼接成功子集。带观测器的计时仅供阶段诊断，本报告performanceMetrics=null；底层runner输出不作为新的无观测器性能基线。

全量Node首次出现PowerShell mock 15000ms超时，失败记录保留。Rust检查链结束后，同一命令与原预算单独复验通过，符合资源竞争的可能解释，但未证明旧超时的完整根因。默认Rust第一次缺显式PDFium路径，18项PDF测试因DLL加载失败；按现有CI指定本机已核对DLL后整组通过，没有产品加载器/依赖/断言改动。Release最初的输入冻结器混入35个旧Vite产物，文件名变化导致编译前停止；现已分开冻结1314个当前源码/配置输入和35个新dist产物，旧失败脚本与记录保留。

state-set-done表示Zustand同步set调用和同步订阅返回，finished表示随后已安排原有备份提醒；两者不证明React渲染/绘制完成。GUI就绪仍由原有home探针和完整六阶段门禁决定。认证快照采集稍晚于最终GUI探针；各自IPC计数分别保存，对共同前缀核对同一命令序列，不假定后台请求停止。

真实运行还保留两类驱动失败：首次外部包装器给SDK传入不支持的sdk-ui模式，未创建GUI样本；新增调用真实SDK帮助入口的红测复现后修正为sdk-input，目标19项与全量Node214项通过。随后首个GUI样本因临时检查运行器继承单测PDFIUM_LIBRARY_PATH在隔离入口前退出，实际相同EXE明确复现固定拒绝码；只为GUI调用去除该继承，未放松原生守卫。两类旧失败原件保留，旧失败整组统计和cleanupIntegrity仍为失败。

源码冻结1314项中，仅上面两个外部Node包装器/回归文件在Release后变动；Rust、前端及其余1312项保持，新测量冻结另存，原Release冻结不重写。100/5000新组各3/3、每样本61次SDK调用、两条finished认证流通过；3个样本中的账户列表有并发，明确保留配对歧义，不拼接或跨时钟推算。

成功组fresh CIM核验54个有记录的PID/birth身份退出；旧启动失败组另核验两个缺少birth的PID已不存在，不冒充完整身份。只清理56个精确owned缓存目录、解除六个已核对链接，六份应用日志副本保留，59个完整Vault文件与全部证明/原失败状态清理前后逐字节保持，缓存工具没有终止任何进程。

账户写入调用在12次登录/再次解锁中耗时1803.06～5258.70ms，当前源代码含清单原子写和两次Windows权限命令；该范围是调用归因，尚不能把具体ACL调用认定为全部耗时或旧首页超时根因。KDF为127.61～198.92ms；状态写入为1.20～4.50ms，但不是React绘制耗时。下一本地步骤为账户写入内部归因和Windows RF-121完整窗口合成；RF-312及多端、睡眠与RF-112/121/122～127前置未关闭。
