import pathlib,subprocess,sys
s=pathlib.Path(__file__).parent;kind=sys.argv[1]
commands={
 'frontend':[
  ('auth-final-js-format',['node','node_modules/prettier/bin/prettier.cjs','--check','src/lib/nativePerfAuth.ts','src/stores/authStore.ts','src/stores/authStore.test.ts','src-tauri/src/native_perf/observer.js','src-tauri/src/native_perf/observer.node.test.mjs','scripts/native-perf-auth-contract.mjs','scripts/native-perf-auth-attribution.mjs','scripts/native-perf-auth-attribution.test.mjs','scripts/run-node-tests.mjs']),
  ('auth-full-node',['node','scripts/run-node-tests.mjs']),
  ('auth-full-vitest',['node','node_modules/vitest/vitest.mjs','run']),
  ('auth-vite-build',['node','node_modules/vite/bin/vite.js','build']),
 ],
 'rust':[
  ('auth-native-tests',['cargo','test','--locked','-p','solo_soul','--features','native-perf','native_perf','--lib']),
  ('auth-native-clippy',['cargo','clippy','--locked','--workspace','--all-targets','--features','native-perf','--','-D','warnings']),
  ('auth-default-tests',['cargo','test','--locked','--workspace','--verbose','--no-fail-fast']),
  ('auth-default-clippy',['cargo','clippy','--locked','--workspace','--all-targets','--','-D','warnings']),
  ('auth-final-fmt-check',['cargo','+1.99.0','fmt','--all','--','--check']),
 ],
}
for name,args in commands[kind]:
 rc=subprocess.call([sys.executable,str(s/'run-check.py'),name,*args])
 if rc: raise SystemExit(rc)
print(kind+' chain complete',flush=True)
