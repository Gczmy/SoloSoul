import pathlib,subprocess,sys
s=pathlib.Path(__file__).parent
for name,args in [
 ('auth-pdfium-pe',['node','../scripts/verify-windows-pdfium.mjs','src-tauri/resources/pdfium/pdfium.dll']),
 ('auth-core-pdfium',['cargo','test','--locked','-p','solosoul-core','--lib']),
 ('auth-default-tests-pdfium',['cargo','test','--locked','--workspace','--verbose','--no-fail-fast']),
 ('auth-default-clippy-final',['cargo','clippy','--locked','--workspace','--all-targets','--','-D','warnings']),
 ('auth-final-fmt-check-final',['cargo','+1.99.0','fmt','--all','--','--check']),
]:
 code=subprocess.call([sys.executable,str(s/'run-check.py'),name,*args])
 if code:raise SystemExit(code)
print('Default Rust checks complete with verified existing PDFium',flush=True)
