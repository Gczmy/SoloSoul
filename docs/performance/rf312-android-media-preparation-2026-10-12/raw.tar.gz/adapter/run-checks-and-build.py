from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('D:/SoloSoul');S=Path(__file__).parent;D=R/'build/rf312-maintenance-20261009'
files={p.relative_to(R).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'tauri/crates').rglob('*') if p.is_file() and p.suffix in ['.rs','.toml'] and 'target' not in p.parts}
for p in [R/'tauri/Cargo.toml',R/'tauri/Cargo.lock',R/'tauri/crates/solosoul-core/tests/fixtures/ocr_test.png',R/'tauri/crates/solosoul-core/tests/fixtures/text_only.pdf',R/'tauri/crates/solosoul-core/tests/fixtures/scanned.pdf']:files[p.relative_to(R).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(S/'sources.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env.update(CARGO_HOME=str(D/'cargo-home'),CARGO_TARGET_DIR=str(D/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(D/'ort-cache'),PDFIUM_LIBRARY_PATH=str(R/'tauri/src-tauri/resources/pdfium/pdfium.dll'),TEMP=str(S/'tmp'),TMP=str(S/'tmp'),PYTHONUTF8='1')
commands=[('fmt',['cargo','fmt','--all','--','--check']),('media-tests',['cargo','test','--locked','--offline','-p','solosoul-core','--example','perf_baseline','media::tests','--','--test-threads=1']),('media-clippy',['cargo','clippy','--locked','--offline','-p','solosoul-core','--example','perf_baseline','--','-D','warnings']),('release-generator',['cargo','build','--locked','--offline','-p','solosoul-core','--release','--example','perf_baseline'])]
rows=[]
for label,command in commands:
 assert all(hashlib.sha256((R/n).read_bytes()).hexdigest()==h for n,h in files.items())
 began=time.monotonic()
 with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(command,cwd=R/'tauri',env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
  (S/(label+'.live.json')).write_text(json.dumps({'pid':p.pid,'command':command})+'\n',encoding='utf-8')
  print(label,'live PID',p.pid,flush=True);code=p.wait()
 row={'label':label,'command':command,'exitCode':code,'elapsedSeconds':time.monotonic()-began};rows.append(row)
 (S/(label+'.receipt.json')).write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
 print(label,'exit',code,flush=True)
 if code:raise SystemExit(code)
assert all(hashlib.sha256((R/n).read_bytes()).hexdigest()==h for n,h in files.items())
(S/'checks.receipt.json').write_text(json.dumps({'rows':rows,'sourcesUnchanged':True,'defaultDependenciesAndLockfileUnchanged':True,'nativeUiOrPerformanceAccepted':False},indent=2)+'\n',encoding='utf-8')
print('All adapter checks/build complete; no native UI samples claimed',flush=True)
