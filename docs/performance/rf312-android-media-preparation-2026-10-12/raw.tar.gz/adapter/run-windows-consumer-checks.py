from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('D:/SoloSoul');S=Path(__file__).parent;D=R/'build/rf312-maintenance-20261009'
files=json.loads((S/'sources.json').read_text(encoding='utf-8'))
for p in (R/'tauri/src-tauri').rglob('*'):
 if p.is_file() and p.suffix in ['.rs','.toml'] and 'target' not in p.parts and 'gen' not in p.parts:files[p.relative_to(R).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(S/'consumer-sources.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env.update(CARGO_HOME=str(D/'cargo-home'),CARGO_TARGET_DIR=str(D/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(D/'ort-cache'),PDFIUM_LIBRARY_PATH=str(R/'tauri/src-tauri/resources/pdfium/pdfium.dll'),TEMP=str(S/'tmp'),TMP=str(S/'tmp'),PYTHONUTF8='1')
rows=[]
for label,command in [('windows-consumer-clippy',['cargo','clippy','--locked','--offline','-p','solo_soul','--lib','--features','native-perf','--','-D','warnings']),('windows-consumer-tests',['cargo','test','--locked','--offline','-p','solo_soul','--lib','--features','native-perf','native_perf::media_fixture::','--','--test-threads=1'])]:
 assert all(hashlib.sha256((R/n).read_bytes()).hexdigest()==h for n,h in files.items())
 began=time.monotonic()
 with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(command,cwd=R/'tauri',env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
  (S/(label+'.live.json')).write_text(json.dumps({'pid':p.pid,'command':command})+'\n',encoding='utf-8');print(label,'live PID',p.pid,flush=True);code=p.wait()
 row={'label':label,'command':command,'exitCode':code,'elapsedSeconds':time.monotonic()-began};rows.append(row);(S/(label+'.receipt.json')).write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
 print(label,'exit',code,flush=True)
 if code:raise SystemExit(code)
assert all(hashlib.sha256((R/n).read_bytes()).hexdigest()==h for n,h in files.items())
(S/'consumer-checks.receipt.json').write_text(json.dumps({'rows':rows,'sourcesUnchanged':True,'nativeWindowsGuiOrAndroidRuntimeNotExecutedByTheseChecks':True},indent=2)+'\n',encoding='utf-8')
