from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('D:/SoloSoul');S=Path(__file__).parent;B=S.parent;source=B/'rf312-media-fixtures-d-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
generator=load(S/'generator.json');files=load(S/'sources.json');exe=Path(generator['path'])
sourceproofs={str(count):{p.relative_to(source/f'vault{count}').as_posix():sha(p) for p in (source/f'vault{count}').rglob('*') if p.is_file()} for count in [100,5000]}
(S/'source-fixture-proof.json').write_text(json.dumps(sourceproofs,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env.update(SOLOSOUL_SECURE='1',TEMP=str(S/'tmp'),TMP=str(S/'tmp'),PYTHONUTF8='1');rows=[]
def run(label,args,wanted):
 assert sha(exe)==generator['sha256'] and all(sha(R/n)==h for n,h in files.items())
 began=time.monotonic();command=[str(exe),*args]
 with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(command,cwd=R/'tauri',env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
  (S/(label+'.live.json')).write_text(json.dumps({'pid':p.pid,'command':command})+'\n',encoding='utf-8');print(label,'live PID',p.pid,flush=True);code=p.wait()
 row={'label':label,'exitCode':code,'expectedExitCode':wanted,'command':command,'elapsedSeconds':time.monotonic()-began};rows.append(row);(S/(label+'.receipt.json')).write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
 assert code==wanted,label;print(label,'exit',code,flush=True)
for count in [100,5000]:
 src=source/f'vault{count}';out=S/f'android-vault{count}';assert not out.exists()
 run(f'android-{count}-copy',['--copy-android-media-fixture',str(src),'--media-fixture-output',str(out)],0)
 before={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()}
 run(f'android-{count}-verify',['--verify-android-media-fixture',str(out)],0)
 assert before=={p.relative_to(out).as_posix():sha(p) for p in out.rglob('*') if p.is_file()}
 assert sourceproofs[str(count)]=={p.relative_to(src).as_posix():sha(p) for p in src.rglob('*') if p.is_file()}
 marker=load(out/'rf312-media-fixture.json');assert marker['schemaVersion']==1 and marker['scope']=='synthetic-android-media-vault-fixture' and marker['metadataVaultRoot']=='/data/user/0/com.solosoul.app'
 assert marker['media']['baseFixture']['objectCount']==count and marker['media']['baseFixture']['buildProfile']=='release' and marker['media']['baseFixture']['kdf']=={'memoryKiB':65536,'iterations':3,'parallelism':4}
 lines=(S/f'android-{count}-verify.stdout.log').read_text(encoding='utf-8-sig').splitlines()
 candidates=[json.loads(line) for line in lines if line.startswith('{')]
 assert len(candidates)==1 and candidates[0]['scope']=='synthetic-android-media-read-only-verification' and candidates[0]['success'] is True and candidates[0]['nativeUiMeasured'] is False
 verify=candidates[0];assert verify['verification']['allObjectContentsVerified']==count and verify['verification']['attachmentCount']==4 and verify['verification']['sourceFilesUnchanged']
 run(f'android-{count}-host-rejection',['--verify-media-fixture',str(out)],1)
 run(f'host-{count}-android-rejection',['--verify-android-media-fixture',str(src)],1)
result={'rows':rows,'currentSourceBuild':True,'sourcesAndOriginal1005000FixturesUnchanged':True,'bothProductionKdfCopiesAndIndependentAllObjectFourAssetVerification':True,'bothMixedPlatformModesRejected':True,'nativeAndroidUiOrPerformanceAccepted':False}
(S/'fixture-preparation.receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print('Android media copies100/5000 independently verified; host/android cross-mode guards retained; no native UI result',flush=True)
