from pathlib import Path
import hashlib,json,zipfile
R=Path('D:/SoloSoul');S=Path(__file__).parent;O=R/'docs/performance/rf312-integrated-windows-home-memory-2026-10-14'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
index=load(O/'index.json');assert sha(O/'raw.tar.gz')==index['archiveSha256']
files=[S/'verify-ipc.py',S/'verify-ipc-observer-fields-original.py',S/'ipc-independent.json',Path(__file__)]
rows=[]
with zipfile.ZipFile(O/'ipc-raw.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for p in files:
        data=p.read_bytes();z.writestr(p.name,data);rows.append(dict(member=p.name,bytes=len(data),sha256=sha(p)))
with zipfile.ZipFile(O/'ipc-raw.zip') as z:
    assert z.testzip() is None
    for row in rows:
        data=z.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
result=dict(task='RF-312',rows=load(S/'ipc-independent.json')['rows'],
    actualEventNamesTimestampsAndTotalsRecomputed=True,originalNativeSamplesNotRerunOrChanged=True,
    scope='Windows JavaScript HTTP invoke transport attempts, excludes arguments/responses and later teardown; not all backend or OS IPC',
    initialOfflineVerifierError='KeyError: attempts; observer commands are individual timestamped events, not aggregate rows; original source retained and actual tool output reported, no separate original stderr file',
    archive=dict(path='ipc-raw.zip',sha256=sha(O/'ipc-raw.zip'),members=rows,allLengthsSha256AndCrcVerified=True),
    originalArchiveUnchanged=True,originalArchiveSha256=index['archiveSha256'])
with (O/'ipc-supplement.json').open('x',encoding='utf-8',newline='\n') as out:json.dump(result,out,indent=2);out.write('\n')
primary=O.with_suffix('.json');summary=load(primary)
summary['ipcSupplement']=O.name+'/ipc-supplement.json'
summary['observedTransportCounts']=result['rows']
with primary.open('w',encoding='utf-8',newline='\n') as out:json.dump(summary,out,ensure_ascii=False,indent=2);out.write('\n')
print('Original197-member archive unchanged; IPC recount and initial offline source separately verified')
