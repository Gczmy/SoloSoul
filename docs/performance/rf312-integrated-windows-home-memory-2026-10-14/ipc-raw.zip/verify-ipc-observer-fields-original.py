from pathlib import Path
import json,statistics
S=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
rows=[]
for size in [100,5000]:
    report=load(S/f'samples{size}'/'native-perf-sdk-journey-results.json')
    values=[]
    for sample in report['samples']:
        ipc=sample['ipcAll'];observer=sample['nativeProof']['lastProbe']['observer']
        assert sample['success'] and ipc['reason'] is None and observer['valid'] and not observer['invalidReasons']
        expected={x['command']:x['attempts'] for x in observer['commands']}
        assert expected=={x['command']:x['attempts'] for x in ipc['commands']}
        assert ipc['attempts']==observer['total']==observer['observedCount']==sum(expected.values())
        values.append(dict(index=sample['index'],attempts=ipc['attempts'],listen=expected.get('plugin:event|listen',0),
            unlisten=expected.get('plugin:event|unlisten',0),titlebarControls=expected.get('set_titlebar_controls',0)))
    rows.append(dict(objects=size,samples=values,medianAttempts=statistics.median(x['attempts'] for x in values),
        maximumAttempts=max(x['attempts'] for x in values)))
with (S/'ipc-independent.json').open('x',encoding='utf-8') as out:json.dump(dict(task='RF-312',rows=rows,
    observedScope='Windows JavaScript HTTP invoke transport attempts; no arguments or responses',backendAllIpc=False),out,indent=2)
print(json.dumps(rows))
