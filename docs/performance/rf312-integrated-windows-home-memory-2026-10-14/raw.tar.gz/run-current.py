from pathlib import Path
import datetime, hashlib, json, os, subprocess, time

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
baseline = root / 'build/rf121-theme-binding-20261010/current-windows-native-retry1-20261014'
cache = root / 'build/rf312-maintenance-20261009'

def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

def save(name, value):
    with (stage / name).open('x', encoding='utf-8', newline='\n') as out:
        out.write(json.dumps(value, indent=2) + '\n')

sources = json.loads((baseline / 'sources.json').read_text())
package = json.loads((baseline / 'runtime-package.json').read_text())
exe = Path(package['exe'])
assert package['sha256'] == '446e6221baa45285607fa594ba4dd7ea151edf8de83ce281c6fcd80aad3734a1'
assert package['gitHead'] == 'a7fbda801f50013b8364c756452f33f7efa96bfd'
assert len(sources)==1983

def verify():
    assert sha(exe) == package['sha256']
    assert len(package['resources']) == 94
    for row in package['resources']:
        assert sha(Path(row['copy'])) == row['sha256'], row['copy']
    for name, digest in sources.items():
        assert sha(root / name) == digest, name

verify()
fixtures = {}
for size in [100, 5000]:
    fixture = cache / 'fixtures' / f'vault{size}'
    fixtures[str(size)] = {str(p.relative_to(fixture)): sha(p)
        for p in sorted(fixture.rglob('*')) if p.is_file()}
    assert fixtures[str(size)]
save('input-proof.json', {'task':'RF-312', 'baseCommit':'a7fbda801f50013b8364c756452f33f7efa96bfd',
    'exe':str(exe), 'exeSha256':package['sha256'], 'resources':package['resources'],
    'sourceManifestSha256':sha(baseline/'sources.json'),
    'sourceFiles':sources, 'fixtureHashes':fixtures,
    'scope':'current optional diagnostic build, 5 full journeys per fixture, 2000ms serial memory sampling',
    'unobservedPerformanceBaseline':False, 'originalHomeTimeoutRootCauseEstablished':False})
env = os.environ.copy()
env.update({'TEMP':str(cache/'tmp'), 'TMP':str(cache/'tmp'),
    'npm_config_cache':str(cache/'npm-cache')})
for key in ['PDFIUM_LIBRARY_PATH','SOLOSOUL_REGISTRY_PUBKEY','WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS','WEBVIEW2_USER_DATA_FOLDER','SOLOSOUL_NATIVE_PERF_ROOT','SOLOSOUL_NATIVE_PERF_PORT']:env.pop(key,None)
env['PATH'] = 'C:/Program Files/Git/usr/bin;' + env.get('PATH','')

for size in [100, 5000]:
    preflight=(root/'build/rf121-theme-binding-20261010/rf1133-current-session-preflight.py').read_text(encoding='utf-8')
    preflight=preflight.replace('rf1133-native-matrix-20261012/session-before-native.json','rf312-integrated-windows-home-memory-20261014/session-before-'+str(size)+'.json')
    probe=root/'build'/('rf312-integrated-windows-home-session-'+str(size)+'-20261014.py')
    with probe.open('x',encoding='utf-8') as out:out.write(preflight)
    subprocess.run(['C:/Python314/python.exe',str(probe)],cwd=root,check=True)
    session=json.loads((stage/('session-before-'+str(size)+'.json')).read_text(encoding='utf-8'))
    assert session.get('connectionState')==0 and session.get('inputDesktopAvailable')
    verify()
    fixture = cache/'fixtures'/f'vault{size}'
    output = stage/f'samples{size}'
    assert not output.exists()
    name = f'journey-{size}'
    command = ['node','scripts/native-perf-sdk-journey.mjs', '--exe',str(exe),
        '--fixture',str(fixture),'--output',str(output),'--samples','5',
        '--memory-interval-ms','2000']
    start = time.monotonic()
    with (stage/(name+'.stdout.log')).open('xb') as out, (stage/(name+'.stderr.log')).open('xb') as err:
        process = subprocess.Popen(command,cwd=root/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json', {'pid':process.pid,'command':command,
            'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
        print(f'{name} live PID {process.pid}',flush=True)
        code = process.wait()
    verify()
    after = {str(p.relative_to(fixture)):sha(p) for p in sorted(fixture.rglob('*')) if p.is_file()}
    assert after == fixtures[str(size)], 'Original fixture changed'
    save(name+'.receipt.json', {'command':command,'pid':process.pid,'exitCode':code,
        'elapsedSeconds':time.monotonic()-start,'sourceUnchanged':True,
        'resourcesUnchanged':True,'originalFixtureUnchanged':True,
        'pdfiumOverrideInherited':False,'temporaryDirectory':env['TEMP'],
        'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    print(f'{name} terminal exit {code}',flush=True)
    result = json.loads((output/'native-perf-sdk-journey-results.json').read_text())
    if any(sample.get('cleanupIncomplete') for sample in result['samples']):
        print('Cleanup incomplete; stop before any further native launch',flush=True)
        raise SystemExit(1)
print('Both complete groups reached terminal results; inspect all samples and observed collection windows',flush=True)
