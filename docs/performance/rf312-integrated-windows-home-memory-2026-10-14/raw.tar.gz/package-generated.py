from pathlib import Path
import datetime, gzip, hashlib, io, json, re, tarfile

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
destination = root/'docs/performance/rf312-integrated-windows-home-memory-2026-10-14'
primary = destination.with_suffix('.json')
report = root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md'
baseline_doc = root/'docs/performance/RF-312-windows-native-app-baseline.md'
current_doc = root/'docs/performance/RF-312-integrated-windows-home-memory.md'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
save = lambda p,x: p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
assert not destination.exists() and not primary.exists() and not current_doc.exists()
validation=load(stage/'validation.json')
inputs=load(stage/'input-proof.json')
cleanup=load(stage/'cache-cleanup.json')
assert validation['accepted'] and len(validation['groups'])==2
assert cleanup['preservedBytesVerified'] and len(cleanup['removedCachePaths'])==80
assert cleanup['matchingOwnedIdentitiesLive']==0 and cleanup['processesTerminatedByThisTool']==0
assert cleanup['identitiesChecked']==90 and len(cleanup['linksUnlinked'])==0
for p in cleanup['preservedVaultAndRootFiles']:
    assert sha(Path(p['path']).read_bytes())==p['sha256']
for p in cleanup['applicationLogs']:
    assert sha(Path(p['copy']).read_bytes())==p['sha256']
for p,digest in inputs['sourceFiles'].items(): assert sha((root/p).read_bytes())==digest,p
assert sha(Path(inputs['exe']).read_bytes())==inputs['exeSha256']
for item in inputs['resources']: assert sha(Path(item['copy']).read_bytes())==item['sha256']
assert [g['accepted'] for g in validation['groups']]==[5,5]
assert sum(g['samplePoints'] for g in validation['groups'])==sum(g['validSamplePoints'] for g in validation['groups'])==88

files=list(sorted(p for p in stage.iterdir() if p.is_file() and p.suffix in ['.py','.ps1','.mjs','.json','.log']))
for size in [100,5000]:
    group=stage/f'samples{size}'
    files.extend(sorted(p for p in group.iterdir() if p.is_file() and p.suffix=='.json'))
    for number in range(1,6):
        sample=group/f'sample-{number:03}'
        files.extend(sorted(p for p in sample.iterdir() if p.is_file() and p.name.startswith('native-perf-') and p.suffix=='.json'))
files.extend(sorted(p for p in (stage/'application-logs').rglob('*') if p.is_file()))
assert len(files)==len(set(files))
destination.mkdir()
archive=destination/'raw.tar.gz'
entries=[]
with archive.open('xb') as disk:
    with gzip.GzipFile(fileobj=disk,mode='wb',filename='',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as tar:
            for file in files:
                assert not file.is_symlink() and file.resolve().is_relative_to(stage.resolve())
                data=file.read_bytes();name=file.relative_to(stage).as_posix()
                assert '/vault/' not in name and '/profile/' not in name
                entry=tarfile.TarInfo(name);entry.size=len(data);entry.mtime=0;entry.mode=0o644
                tar.addfile(entry,io.BytesIO(data))
                entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers()
    assert len(members)==len(entries)
    for m,e in zip(members,entries):
        assert m.name==e['path'] and m.isfile() and m.size==e['bytes']
        assert sha(tar.extractfile(m).read())==e['sha256']
index={'schemaVersion':1,'task':'RF-312','scope':'current Windows diagnostic home/memory byte-preserved originals',
    'archive':'raw.tar.gz','archiveSha256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,
    'entryCount':len(entries),'entries':entries,'excludes':['EXE','DLL','models','physical Vault','private cache trees']}
save(destination/'index.json',index)
evidence={**validation,'date':'2026-10-14','archiveIndex':destination.name+'/index.json',
    'rawOriginalsByteVerified':True,'rawRecordCount':len(entries),'device':load(stage/'device.json'),
    'commands':[load(stage/f'journey-{n}.receipt.json') for n in [100,5000]],
    'cleanup':{'identitiesChecked':90,'matchingOwnedIdentitiesLive':0,'cachePathsRemoved':80,
        'linksUnlinked':0,'vaultAndRootFilesBytePreserved':len(cleanup['preservedVaultAndRootFiles']),
        'applicationLogsPreserved':len(cleanup['applicationLogs']),'processesTerminatedByCacheTool':0},
    'limitations':['Optional auth/maintenance instrumentation and SDK/query overhead remain enabled',
        'Observed working-set maximum is not a continuous peak or exclusive physical memory',
        'Only ten current runs; original intermittent home timeout not reproduced and root cause remains unknown',
        'No sleep, warm restart, new OCR/preview or other-platform measurements in this group',
        'Not an alternating controlled performance comparison with older builds'],
    'nextLocal':['RF-121 actual DOM/theme/palette-bound composed-window matrix',
        'Continue bounded home timeout attribution if reproduced',
        'Current-build OCR/preview measurement; paired startup already measured separately'],
    'pushPerformed':False}
evidence.update(goal='active',runtimeSourceCount=1983,pairedStartupMeasuredInSeparateGroup=True,fullRF121Accepted=False,fullRF312Accepted=False)
save(primary,evidence)

