from pathlib import Path
import json,shutil
R=Path('D:/SoloSoul');S=Path(__file__).parent;O=R/'build/rf312-home-memory-20261010'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
v=load(S/'validation.json');cleanup=load(S/'cache-cleanup.json')
assert v['accepted'] and load(S/'independent.receipt.json')['exitCode']==0
assert all(g['samplePoints']==g['validSamplePoints'] for g in v['groups'])
assert len(cleanup['linksUnlinked'])==0 and len(cleanup['preservedVaultAndRootFiles'])==240
assert len(load(S/'input-proof.json')['sourceFiles'])==1983
shutil.copyfile(R/'build/rf312-current-windows-startup-20261014/device.json',S/'device.json')
text=(O/'package-current.py').read_text(encoding='utf-8')
text=text[:text.index('small,big=validation')]
text=text.replace('rf312-windows-current-home-memory-2026-10-10','rf312-integrated-windows-home-memory-2026-10-14')
text=text.replace('RF-312-current-windows-home-memory.md','RF-312-integrated-windows-home-memory.md')
text=text.replace("'date':'2026-10-10'","'date':'2026-10-14'")
text=text.replace("len(cleanup['linksUnlinked'])==10","len(cleanup['linksUnlinked'])==0")
text=text.replace("'linksUnlinked':10","'linksUnlinked':0")
text=text.replace("assert sum(g['samplePoints'] for g in validation['groups'])==97",
    "assert sum(g['samplePoints'] for g in validation['groups'])==sum(g['validSamplePoints'] for g in validation['groups'])==88")
text=text.replace("'Current-build same-profile restart revalidation'", "'Current-build OCR/preview measurement; paired startup already measured separately'")
anchor='save(primary,evidence)'
assert text.count(anchor)==1
text=text.replace(anchor,"evidence.update(goal='active',runtimeSourceCount=1983,pairedStartupMeasuredInSeparateGroup=True,fullRF121Accepted=False,fullRF312Accepted=False)\n"+anchor)
generated=S/'package-generated.py'
compile(text,str(generated),'exec')
with generated.open('x',encoding='utf-8',newline='\n') as out:out.write(text)
exec(compile(text,str(generated),'exec'),{'__file__':str(generated),'__name__':'__main__'})
print('Ten current full home journeys, 88/88 exact memory points and 240 preserved files archived without legacy report mutations')
