from pathlib import Path
import json,hashlib,gzip,subprocess,re,datetime
from verify_auth_freezes import verify_sources
s=Path(__file__).parent;r=Path(r'C:\Users\40299571\SoloSoul')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
verify_sources(s,r)
for name in ['cli-source-freeze.json','frontend-freeze.json']:assert all(sha(r/p)==h for p,h in load(s/name)['files'].items()),name
for name in ['public-source-freeze.json','previous-build-freeze.json']:assert all(sha(Path(p))==h for p,h in load(s/name)['files'].items()),name
for row in load(s/'resource-freeze.json')['records']:assert sha(Path(row['source']))==row['sha256']==sha(Path(row['copy']))
freeze=load(s/'owned-acl-exit-original-records-freeze.json')['files'];assert all(sha(s/p)==h for p,h in freeze.items())
folder=r/'docs/performance/rf1097-windows-acl-exit-diagnostic-2026-10-06';index=load(folder/'index.json');assert len(index['entries'])==153
assert index['wholeOriginalFailureSamplesIncluded']==3 and index['wholeDiagnosticSamplesIncluded']==3 and not index['applicationPerformanceAccepted'] and not index['rawVaultOrCacheOrAccountFilesIncluded']
for row in index['entries']:
 p=folder/row['archive'];assert p.is_file() and p.parent==folder/'raw'
 packed=p.read_bytes();assert hashlib.sha256(packed).hexdigest()==row['gzipSha256'];raw=gzip.decompress(packed)
 assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'] and raw==(s/row['sourceRelativePath']).read_bytes()
artifact=load(r/'docs/performance/rf1097-windows-acl-exit-diagnostic-2026-10-06.json')
assert artifact['task']=='RF-1097' and artifact['actualRetainedIcaclsExitCodes']==12 and artifact['wholeDiagnosticSamples']==3 and artifact['readonlyAclDescriptors']==45 and artifact['freshTerminalIdentities']==148
assert not artifact['originalFailureRootCauseKnown'] and not artifact['originalFailedGroupAccepted'] and not artifact['applicationPerformanceAccepted'] and not artifact['aclEquivalenceAccepted']
assert artifact['observerOverheadPreventsPerformanceAcceptance'] and artifact['originalAclMismatchStillPresent']
for check in artifact['documentChecks']:
 p=s/(check['label']+'.receipt.json');assert sha(p)==check['receiptSha256'] and load(p)['exitCode']==check['exitCode']==0
 assert sha(s/(check['label']+'.stdout.log'))==check['stdoutSha256'] and sha(s/(check['label']+'.stderr.log'))==check['stderrSha256']
md=r/'docs/performance/RF-1097-windows-acl-exit-diagnostic.md';text=md.read_text(encoding='utf-8')
for link in re.findall(r'\]\(([^)]+)\)',text):
 if link.startswith('https://'):continue
 assert (md.parent/link).is_file(),link
report=(r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md').read_text(encoding='utf-8-sig')
rows=[line for line in report.splitlines() if re.match(r'^\| \d+ \| \[RF-\d+\]',line)]
assert len(rows)==287 and len(set(re.search(r'\[(RF-\d+)\]',x).group(1) for x in rows))==287
counts={k:sum(k in x for x in rows) for k in ['[x]','[!]','[~]','[ ]']};assert counts=={'[x]':277,'[!]':3,'[~]':1,'[ ]':6},counts
assert len([x for x in rows if '[RF-1097]' in x and '[~]' in x])==1
assert 'RF-1097 限定退出码诊断记录' in report and '148记录身份' in report
for link in ['performance/RF-1097-windows-acl-exit-diagnostic.md','performance/rf1097-windows-acl-exit-diagnostic-2026-10-06.json','performance/rf1097-windows-acl-exit-diagnostic-2026-10-06/index.json']:
 assert link in report and (r/'docs'/link).is_file()
def git(*args,cwd=r):
 return subprocess.check_output(['git','-c','safe.directory='+str(cwd).replace('\\','/'),'-c','core.safecrlf=false',*args],cwd=cwd,text=True,encoding='utf-8').strip()
assert git('rev-parse','HEAD')=='ed23f897604eedd6cfe5d3f4afef9efc0cf9cf6e'
assert 'dd695bba03ce1ea274185d4cc9ed0e69501b3d90' in git('stash','list','--format=%H')
sub=r/'SoloSoul_plugin_market';assert git('rev-parse','HEAD',cwd=sub)=='f55fc4b5a257cb8d7d9273168c3fd05b01b9d921' and git('status','--porcelain',cwd=sub)==''
assert git('diff','--cached','--name-only')==''
assert git('diff','--name-only').splitlines()==['docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md','tauri/crates/solosoul-core/src/vault_service/mod.rs']
assert git('diff','--numstat','--','tauri/crates/solosoul-core/src/vault_service/mod.rs').split('\t')[:2]==['8','0']
assert git('diff','--check')==''
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'rawArchivesByteExact':153,'taskCounts':counts,'sourceAndAllFrozenInputsPreserved':True,'originalFailurePreserved':True,'protectedStashAndSubmodulePreserved':True,'noStagingOrCommitOrPush':True,'applicationPerformanceAccepted':False,'rf1097Closed':False}
p=s/'owned-acl-exit-doc-independent-verification.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(result))
