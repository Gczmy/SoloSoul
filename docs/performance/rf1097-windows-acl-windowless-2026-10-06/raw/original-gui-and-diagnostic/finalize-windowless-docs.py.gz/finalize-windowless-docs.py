from verify_auth_freezes import verify_sources
import pathlib,json,hashlib,re,sys,datetime
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul');d=r/'docs/performance';stem='rf1097-windows-acl-windowless-2026-10-06'
old=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-account-write-20261006')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=load(s/'required-checks.json');build=load(s/'build-checkpoint.json');baseline=load(s/'baseline-build-checkpoint.json');index=load(d/stem/'index.json');comparison=load(s/'gui-permission-comparison.json');acl=load(s/'gui-acl-equivalence.json')
assert checks['success'] and len(checks['checks'])==9 and all(q['exitCode']==0 for q in checks['checks'].values())
assert load(s/'release-build.receipt.json')['exitCode']==0 and sha(pathlib.Path(build['exe']))==build['sha256'] and sha(pathlib.Path(baseline['exe']))==baseline['sha256']
assert comparison['success'] and comparison['permissionStageReductionObserved'] and acl['success'] and acl['descriptorsChecked']==36
assert load(s/'raw-archive-review.json')['success'];verify_sources(s,r)
current=load(s/'source-freeze.json')['files'];prior=load(old/'source-freeze.json')['files'];assert current.keys()==prior.keys();changed=[p for p in current if current[p]!=prior[p]];assert changed==['tauri/crates/solosoul-core/src/vault_service/mod.rs']
counts={}
for label,expected in [('windowless-default-tests',(1861,0,3)),('windowless-native-tests',(100,0,0)),('windowless-core-native',(2,0,0)),('windowless-cli-tests',(336,0,2))]:
 text=(s/(label+'.stdout.log')).read_text(encoding='utf-8-sig');rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert rows,label
 totals=tuple(sum(int(q[i]) for q in rows) for i in range(3));assert totals==expected,(label,totals);counts[label]=dict(zip(['passed','failed','ignored'],totals))
groups=[];totals={key:0 for key in ['vaultFilesUnchanged','topLevelArtifactsUnchanged','preservedLogs','recordedIdentitiesChecked','removedPrivateCachePaths','unlinkedPrivateCacheEntries']}
for group,count,version in [('legacy100',100,'legacy'),('windowless100',100,'windowless'),('windowless5000',5000,'windowless'),('legacy5000',5000,'legacy')]:
 review=load(s/(group+'-actual-auth-review.json'));post=load(s/(group+'-post-cache-review.json'));report=load(s/group/'native-perf-sdk-journey-results.json')
 assert review['success'] and post['success'] and report['success'] and len(review['samples'])==3
 assert not review['oldTimeoutRootCauseEstablished'] and not review['nestedStageDurationsAdded'] and not review['frontBackendClocksSubtracted']
 for key in totals:totals[key]+=post[key]
 groups.append({'name':group,'objectCount':count,'version':version,'samplesRequested':3,'wholeSamplesAccepted':3,'samples':review['samples'],'summary':review['summary'],'cleanup':post})
control=load(s/'controlled-mechanism/control-results.json');assert control['success'] and not control['applicationPerformanceAccepted'] and control['callsSucceeded']==24 and control['pairedSamples']==6
source=load(s/'scope-verification.json');assert source['onlyTwoCreationFlagsAndImportConstantChanged']
result={'schemaVersion':1,'task':'RF-1097','scope':'windows-private-acl-no-console-acceptance','date':'2026-10-06','taskClosedInThisLocalCommit':True,'rf312TaskClosed':False,'oldHomeTimeoutRootCauseEstablished':False,'changes':{'productionFiles':changed,'addedLines':8,'dependenciesChanged':False,'frontendChanged':False,'unixChanged':False,'permissionArgumentsChanged':False,'standardStreamsChanged':False,'exitStatusAndErrorPropagationChanged':False,'creationFlag':'CREATE_NO_WINDOW (0x08000000)'},'baselineBuild':baseline,'frozenBuild':build,'scopeVerification':source,'sourceFreeze':{'mainInputs':1314,'cliInputs':108,'frontendDistInputs':35,'mainSha256':sha(s/'source-freeze.json'),'cliSha256':sha(s/'cli-source-freeze.json'),'frontendSha256':sha(s/'frontend-freeze.json')},'checks':checks,'testCounts':counts,'unaffectedFrontendAndNode':{'reusedEvidence':'rf312-windows-account-write-attribution-2026-10-06.json','sha256':sha(d/'rf312-windows-account-write-attribution-2026-10-06.json'),'inputsUnchangedExceptOneRustModule':True,'rerunClaimed':False},'controlledMechanism':control,'groups':groups,'guiAcl':acl,'guiComparison':comparison,'preservationTotals':totals,'rawArchive':{'index':stem+'/index.json','files':len(index['files']),'allDecompressedBytesVerified':True},'remaining':['old intermittent home timeout','system sleep coverage','same-scope multiplatform distributions','RF-112 isolated macOS lock/unlock restore','RF-121 full native material and accessibility matrix','RF-122 to RF-127 dependencies'],'localCommitOnly':True,'pushed':False}
def save(p,text):
 assert not p.exists(),str(p);p.write_text(text,encoding='utf-8',newline='\n')
save(d/(stem+'.json'),json.dumps(result,ensure_ascii=False,indent=2)+'\n')
text='''# RF-1097 Windows 私有权限命令无窗口启动验收

Windows GUI 登录和再次解锁会写入账户清单。前一阶段确认目录和文件权限调用占账户写入耗时的99.74%～99.83%；本项只给两处 `icacls` 添加 `CREATE_NO_WINDOW`，避免创建控制台。用户名校验、命令参数、标准流继承、退出状态检查和错误传播保持，Unix 权限及前端、依赖均未改。

先以真实无控制台 GUI 父进程提取原生产函数做六组交替配对，24次调用和24份完整 owner/group/DACL 检查通过。机制对照只证明该调用方式的差异；应用验收另用新旧冻结 EXE、相同资源和公开数据集完成。

100对象按旧→新、5000对象按新→旧顺序运行，各版本各三次完整行程。共12个独立 root/profile，覆盖启动、主密码登录、工作区、搜索、应用锁定、再次解锁。原SDK调用、进程身份、主文档/frame/loader和时限门禁保持，不跨失败组拼接样本。

## 实际 GUI 分布

每格为中位数 / P95，单位ms，n=3的P95仅为本组三次最大观测值。首次登录和再次解锁分开；前后端时钟不相减，父子阶段不相加，不把同步状态写入当作React绘制。

| 阶段 | 100旧 | 100新 | 5000旧 | 5000新 |
| --- | ---: | ---: | ---: | ---: |
'''
for flow,title in [(1,'首次登录'),(2,'再次解锁')]:
 for metric,label in [('account-directory-permission','目录权限'),('account-manifest-permission','文件权限'),('account-write-call','账户写入父阶段'),('backend-attempt','后端登录调用'),('login-await','前端登录await'),('kdf','KDF')]:
  values=[]
  for dataset in comparison['datasets']:
   row=next(q for q in dataset['authenticationStageComparisons'] if q['name']=='flow'+str(flow)+':'+metric)
   for version in ['legacy','windowless']:
    v=row[version];values.append(f"{v['medianMs']:.2f} / {v['p95Ms']:.2f}")
  text+='| '+title+' '+label+' | '+' | '.join(values)+' |\n'
text+='''
两档数据、两次认证的目录/文件权限子阶段中位数及P95均降低。完整六阶段分布及每次原始值见结构化证据；本结论限定本机公开样本和当前带观测器构建，不外推系统冷启动、多端分布或无观测器净CPU时间，也没有证明旧首页偶发超时根因。

## 权限、检查与保全

12个GUI样本分别核对Vault目录、账户清单文件及配置文件，共36份owner/group/DACL安全描述符。两版本、两数据规模按角色完全一致；目录及清单仍为受保护的当前用户显式FullControl，配置保持原继承行为。原始SID/SDDL不入报告，保存摘要和结构字段。这里只验证本轮隔离样本，不宣称清除了所有既存显式ACL或证明磁盘持久性。

'''
text+=f"默认Rust {counts['windowless-default-tests']['passed']}、非默认原生 {counts['windowless-native-tests']['passed']}、Core观察器 {counts['windowless-core-native']['passed']}、CLI {counts['windowless-cli-tests']['passed']} 全通过；默认Rust3项及CLI2项既有ignored保持。默认/非默认/CLI严格Clippy及格式检查通过。F/WEB/Node沿用前一已提交同输入证据，不冒充新运行。\n\n"
text+=f"新EXE SHA-256 `{build['sha256']}`；旧EXE `{baseline['sha256']}`。1314项主项目输入、108项CLI输入、35份dist、188份新旧资源副本、185份公开源及12个以前构建保持。\n\n"
text+=f"确认进程退出后，只清理{totals['removedPrivateCachePaths']}个精确owned缓存、解除{totals['unlinkedPrivateCacheEntries']}个已核验链接；{totals['vaultFilesUnchanged']}个Vault文件、{totals['preservedLogs']}份日志及全部证明、公开源和新旧构建保留。缓存工具未终止进程。\n\n"
text+=f"[结构化验收]({stem}.json)、[{len(index['files'])}份逐字节原件]({stem}/index.json)及[此前账户写入归因](RF-312-native-account-write-attribution.md)可复核。标准库调用使用稳定的[CommandExt::creation_flags](https://doc.rust-lang.org/std/os/windows/process/trait.CommandExt.html)，标志语义见[Microsoft进程创建标志](https://learn.microsoft.com/en-us/windows/win32/procthread/process-creation-flags)。\n\n"
text+='''按RF-1097独立本地提交，不推送。RF-312首页超时、睡眠和多端仍待验收；RF-112/121未关闭，RF-122～127前置保持，整体goal继续active。
'''
save(d/'RF-1097-windows-acl-windowless.md',text)
report_path=r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';report=report_path.read_text(encoding='utf-8-sig');head,rest=report.split('## 4. 修复进度与执行索引',1);block,tail=rest.split('## 5.',1)
assert '**277 / 287**' in block and '进行中：1；待执行：6' in block
block=block.replace('**277 / 287**；实际修复（已关闭）：277','**278 / 287**；实际修复（已关闭）：278').replace('进行中：1；待执行：6','进行中：0；待执行：6')
row=next(q for q in block.splitlines() if '[RF-1097]' in q);assert '[~] 进行中' in row;block=block.replace(row,row.replace('[~] 进行中','[x] 完成'))
block=re.sub(r'- 当前处理：\*\*.*?\*\*。','- 当前处理：**RF-1097已完成本机真实GUI权限/性能对照；下一本地项为RF-121 Windows完整窗口合成。RF-312首页超时/睡眠/多端及RF-112/121/122～127前置继续未完成**。',block,count=1)
head=head.replace('RF-1097 Windows权限命令无窗口启动修复中','RF-1097 Windows权限命令无窗口启动修复完成')
report=head+'## 4. 修复进度与执行索引'+block+'## 5.'+tail
report+='\n### RF-1097 完整验收与关闭（2026-10-06）\n\n'
report+='- 生产仅一个Rust文件八行新增，两处icacls使用CREATE_NO_WINDOW；标准流、权限参数、退出状态/错误传播、Unix及前端/依赖保持。独立GUI六组机制对照24次调用/24份ACL先通过，随后真实新旧GUI完整对照。\n'
report+='- 100旧→新、5000新→旧，各版本各三次完整六阶段，共12个fresh root/profile；两次认证的目录/文件权限中位数及P95均降低，原SDK/身份/时限门禁保持。36份完整owner/group/DACL按角色一致，配置继承保持，不外推既存显式ACL或旧首页超时根因。\n'
report+='- 默认Rust1861/非默认100/Core2/CLI336通过，既有ignored保持；严格Clippy/格式全通过，未受影响F/WEB/Node证据明确复用。新旧EXE、1314主项目/108CLI/35dist输入及资源/公开源/以前构建均冻结。\n'
report+=f"- fresh身份复核后仅清理{totals['removedPrivateCachePaths']}个owned缓存和{totals['unlinkedPrivateCacheEntries']}个核验链接；{totals['vaultFilesUnchanged']}个Vault文件、{totals['preservedLogs']}份日志及全部证明/新旧构建保留，缓存工具未终止进程。\n"
report+=f"- [实际分布与复跑](performance/RF-1097-windows-acl-windowless.md)、[结构化证据](performance/{stem}.json)和[{len(index['files'])}份原件](performance/{stem}/index.json)归档。独立本地提交（本提交，以RF-1097检索），不推送；278/287关闭、3待验证、6待执行。RF-312及RF-112/121/122～127前置不解除，下一本地项RF-121 Windows完整合成，goal active。\n"
report_path.write_text(report,encoding='utf-8',newline='\n');print('RF-1097 acceptance documents and report prepared from completed actual evidence',flush=True)
