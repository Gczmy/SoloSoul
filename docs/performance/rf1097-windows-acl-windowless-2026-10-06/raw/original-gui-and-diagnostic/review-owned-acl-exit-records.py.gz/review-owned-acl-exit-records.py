from pathlib import Path
import json,hashlib,datetime,collections
from verify_auth_freezes import verify_sources
s=Path(__file__).parent;r=Path(r'C:\Users\40299571\SoloSoul')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
verify_sources(s,r)
freeze=load(s/'owned-acl-exit-original-records-freeze.json')['files'];assert all(sha(s/p)==h for p,h in freeze.items())
helpers=load(s/'owned-acl-exit-helper-freeze.json')['files'];assert all(sha(s/p)==h for p,h in helpers.items())
assert load(s/'owned-acl-exit-capability-probe.receipt.json')['exitCode']==0
assert load(s/'legacy-exit-diagnostic5000.receipt.json')['exitCode']==0
assert load(s/'owned-acl-exit-observer-run.receipt.json')['exitCode']==0
assert load(s/'owned-acl-exit-actual-auth-review.receipt.json')['exitCode']==0
assert load(s/'legacy5000-exit-diagnostic-01-actual-auth-review.json')['success']
obs=load(s/'owned-acl-exit-observer.result.json');assert obs['success'] and len(obs['parentRecords'])==3 and len(obs['childRecords'])==12 and obs['identityFailures']==[] and obs['liveChildHandles']==0
assert obs['diagnosticOnly'] and not obs['performanceAccepted'] and not obs['commandsOrBodiesCollected'] and not obs['processKilled'] and not obs['systemSettingsChanged']
report=load(s/'legacy5000-exit-diagnostic-01/native-perf-sdk-journey-results.json');assert report['samplesRequested']==3 and len(report['samples'])==3 and report['success'] and report['sourceUnchanged']
seen=set();samples=[]
for sample in report['samples']:
 index=sample['index'];parent=next(x for x in obs['parentRecords'] if x['sample']==index)
 root=Path(sample['root']);assert root==s/'legacy5000-exit-diagnostic-01'/('sample-%03d'%index)
 actual=next(x for x in sample['beforeProcessDiagnostics']['processes'] if x['role']=='root')
 assert parent['pid']==actual['pid']==sample['processId']==sample['nativeProof']['pid']
 assert parent['birthFileTime']//10000-11644473600000==actual['creationMs']
 assert parent['exeSha256']==report['exeSha256']==load(s/'baseline-build-checkpoint.json')['sha256']
 assert sha(root/'native-perf-sdk-journey-requested.json')==parent['requestSha256'] and sha(root/'native-perf-owned.json')==parent['ownedSha256']
 children=sorted([x for x in obs['childRecords'] if x['sample']==index],key=lambda x:x['birthFileTime']);assert len(children)==4
 for child in children:
  assert child['parentPid']==parent['pid'] and child['parentBirthFileTime']==parent['birthFileTime'] and child['birthFileTime']>=parent['birthFileTime'] and child['exitFileTime']>=child['birthFileTime']
  assert child['sameRetainedHandle'] and not child['commandBodyRecorded'] and child['exitCode']==0 and child['exitCodeHex']=='0x00000000'
  identity=(child['pid'],child['birthFileTime']);assert identity not in seen;seen.add(identity)
 raw=load(root/'native-perf-auth-attribution.json');logins=[a for a in raw['backend']['attempts'] if a['kind']=='login'];assert len(logins)==2
 stages=[x for a in logins for x in a['stages'] if x['name'] in ['account-directory-permission','account-manifest-permission']]
 assert len(stages)==4 and all(x['outcome']=='completed' for x in stages)
 samples.append({'sample':index,'parentPid':parent['pid'],'sameWindowsClockParentBirthMatched':True,'completeLoginAttempts':2,'permissionSubstagesCompleted':4,'retainedChildExitCodes':[x['exitCode'] for x in children]})
acl=load(s/'owned-acl-exit-readonly-acl-diagnostic.json');assert acl['readOnlyObservationCompleted'] and acl['descriptorsObserved']==45 and acl['fileBytesUnchanged'] and not acl['rawSidOrSddlRecorded'] and not acl['aclEquivalenceAccepted']
failed=[x for x in acl['records'] if not x['expectedContractMatches']]
assert len(failed)==1 and failed[0]['group']=='legacy5000' and failed[0]['sample']==1 and failed[0]['kind']=='account-manifest' and failed[0]['protected'] is False and failed[0]['inherited'] is True
assert acl['currentUserFullControlOnlyEveryObservedTarget']
assert all(x['expectedContractMatches'] for x in acl['records'] if x['group'].startswith('windowless') or x['group']=='legacy5000-exit-diagnostic-01')
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'targetedDiagnosticComplete':True,'oldFailureReproduced':False,'originalFailureRootCauseKnown':False,'originalFailedGroupPreserved':True,'originalProofsVerified':len(freeze),'sourceAndHelpersPreserved':True,'wholeDiagnosticSamples':3,'completedLoginAttempts':6,'actualRetainedIcaclsExitCodes':12,'nonzeroExitCodes':0,'originalFailedGroupAccepted':False,'applicationPerformanceAccepted':False,'aclEquivalenceAccepted':False,'readonlyAclDescriptors':45,'originalAclMismatchStillPresent':True,'candidateObservedAclTargetsMatchExpected':True,'noRawBodiesOrSidOrSddl':True,'observerSnapshotWallMs':obs['snapshotTotalMilliseconds'],'observerSnapshotWallMsIsNotCpuTime':True,'observerOverheadPreventsPerformanceAcceptance':True,'samples':samples,'nextAction':'Use a non-default fixed safe error outcome observation to capture the actual permission-helper failure category; external handles cannot reconstruct historical unlogged spawn errors.'}
p=s/'owned-acl-exit-independent-review.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:result[k] for k in ['targetedDiagnosticComplete','oldFailureReproduced','actualRetainedIcaclsExitCodes','readonlyAclDescriptors','originalFailureRootCauseKnown','applicationPerformanceAccepted']}))
