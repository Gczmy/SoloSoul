from verify_auth_freezes import verify_sources
import pathlib,json,gzip,hashlib,re,sys,subprocess,datetime,urllib.parse
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul');d=r/'docs/performance';stem='rf1097-windows-acl-windowless-2026-10-06'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
proof=load(d/(stem+'.json'));index=load(d/stem/'index.json');assert proof['taskClosedInThisLocalCommit'] and not proof['rf312TaskClosed'] and not proof['oldHomeTimeoutRootCauseEstablished']
assert proof['guiAcl']==load(s/'gui-acl-equivalence.json') and proof['guiAcl']['descriptorsChecked']==36 and proof['guiAcl']['ownerGroupAndDaclIdenticalByRole']
assert proof['guiComparison']==load(s/'gui-permission-comparison.json') and proof['guiComparison']['permissionStageReductionObserved'] and proof['guiComparison']['wholeSamples']==12
assert proof['scopeVerification']==load(s/'scope-verification.json') and proof['checks']==load(s/'required-checks.json')
archives=set();original_bytes=0
for q in index['files']:
 assert q['archive'] not in archives;archives.add(q['archive']);p=d/stem/q['archive'];assert p.resolve().is_relative_to((d/stem).resolve())
 compressed=p.read_bytes();body=gzip.decompress(compressed);assert len(compressed)==q['archiveBytes'] and sha(compressed)==q['archiveSha256'] and len(body)==q['bytes'] and sha(body)==q['sha256'];original_bytes+=len(body)
 assert pathlib.Path(q['original']).read_bytes()==body
assert proof['rawArchive']['files']==len(index['files'])
for key,name in [('mainSha256','source-freeze.json'),('cliSha256','cli-source-freeze.json'),('frontendSha256','frontend-freeze.json')]:
 assert sha((s/name).read_bytes())==proof['sourceFreeze'][key]
verify_sources(s,r)
for name in ['cli-source-freeze.json','frontend-freeze.json']:
 assert all(sha((r/p).read_bytes())==h for p,h in load(s/name)['files'].items()),name
for key in ['baselineBuild','frozenBuild']:
 q=proof[key];assert sha(pathlib.Path(q['exe']).read_bytes())==q['sha256']
whole=0;attempts=0;totals={key:0 for key in proof['preservationTotals']}
for group in proof['groups']:
 name=group['name'];review=load(s/(name+'-actual-auth-review.json'));post=load(s/(name+'-post-cache-review.json'))
 assert review['success'] and post['success'] and group['wholeSamplesAccepted']==3 and group['samples']==review['samples'] and group['summary']==review['summary'] and group['cleanup']==post
 whole+=3
 for key in totals:totals[key]+=post[key]
 for sample in review['samples']:
  raw=load(s/name/('sample-%03d'%sample['index'])/'native-perf-auth-attribution.json');logins=[a for a in raw['backend']['attempts'] if a['kind']=='login'];assert len(logins)==2
  for flow,attempt in zip(sample['flows'],logins):
   parent=next(q for q in attempt['stages'] if q['name']=='account-write-call');sub=flow['accountWriteSubsteps'];assert abs(sub['parentDurationMs']-(parent['endedAtMs']-parent['startedAtMs']))<1e-8
   for q in sub['children']:
    original=next(v for v in attempt['stages'] if v['name']==q['name']);assert abs(q['durationMs']-(original['endedAtMs']-original['startedAtMs']))<1e-8
   attempts+=1
 assert all(q['n']==3 and q['p95Ms']==max(q['samplesMs']) for q in review['summary'])
assert whole==12 and attempts==24 and totals==proof['preservationTotals']
report=(r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md').read_text(encoding='utf-8-sig');block=report.split('## 4. 修复进度与执行索引',1)[1].split('## 5.',1)[0]
lines=re.findall(r'^\|\s*\d+\s*\|\s*\[RF-\d+\].*$',block,re.M);ids=[re.search(r'\[RF-(\d+)\]',q).group(1) for q in lines];assert len(ids)==len(set(ids))==287
states={'closed':sum('[x]' in q for q in lines),'waiting':sum('[!]' in q for q in lines),'inProgress':sum('[~]' in q for q in lines),'pending':sum('[ ]' in q for q in lines)}
assert states=={'closed':278,'waiting':3,'inProgress':0,'pending':6},states
assert '[x]' in next(q for q in lines if '[RF-1097]' in q)
for id in ['112','121','312']:assert '[!]' in next(q for q in lines if '[RF-'+id+']' in q)
for id in ['122','123','124','125','126','127']:assert '[ ]' in next(q for q in lines if '[RF-'+id+']' in q)
links=0
for p in [r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md',d/'RF-1097-windows-acl-windowless.md']:
 for ref in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text(encoding='utf-8-sig')):
  path=urllib.parse.unquote(ref.strip().strip('<>').split('#',1)[0])
  if not path or re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',path):continue
  assert (p.parent/path).exists(),(str(p),ref);links+=1
base=load(s/'git-preservation-before-rf1097.json')
def git(*args,cwd=r):return subprocess.check_output(['git','-c','safe.directory='+str(cwd).replace(chr(92),'/'),'-c','core.safecrlf=false',*args],cwd=cwd,text=True).strip()
assert git('rev-parse','HEAD')==base['head'] and git('stash','list','--format=%H')==base['stashes']
sub=r/'SoloSoul_plugin_market';assert git('rev-parse','HEAD',cwd=sub)==base['submoduleHead'] and not git('status','--short',cwd=sub) and git('ls-tree','HEAD','SoloSoul_plugin_market')==base['submoduleTree']
subprocess.run(['git','-c','safe.directory=C:/Users/40299571/SoloSoul','-c','core.safecrlf=false','diff','--check'],cwd=r,check=True)
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'rawArchivesVerified':len(index['files']),'rawBytesVerified':original_bytes,'wholeNativeSamples':whole,'accountWriteAttemptsIndependentlyRecomputed':attempts,'states':states,'relativeLinksChecked':links,'rf312StillOpen':True,'sixDependencyGatesRetained':True,'sourceFreezeVerified':True,'stashAndSubmodulePreserved':True,'diffCheckPassed':True}
proof['documentationVerification']=receipt;(d/(stem+'.json')).write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=s/'documentation-verification.json';assert not p.exists();p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(receipt,ensure_ascii=False),flush=True)
