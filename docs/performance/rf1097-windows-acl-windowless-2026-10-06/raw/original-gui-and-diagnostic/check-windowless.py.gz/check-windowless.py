import pathlib,json,hashlib,subprocess,sys,datetime
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
 for name in ['source-freeze.json','cli-source-freeze.json','frontend-freeze.json']:
  q=load(s/name)['files'];assert all(sha(r/p)==h for p,h in q.items()),name
steps=[('windowless-rust-fmt',['cargo','+1.99.0','fmt','--all','--','--check']),('windowless-default-clippy',['cargo','clippy','--locked','--workspace','--all-targets','--','-D','warnings']),('windowless-default-tests',['cargo','test','--locked','--workspace','--verbose','--no-fail-fast']),('windowless-native-clippy',['cargo','clippy','--locked','-p','solo_soul','--features','native-perf','--all-targets','--','-D','warnings']),('windowless-native-tests',['cargo','test','--locked','-p','solo_soul','--features','native-perf','native_perf::']),('windowless-core-native',['cargo','test','--locked','-p','solosoul-core','--features','native-perf','native_perf_unlock::']),('windowless-cli-fmt',['cargo','+1.99.0','fmt','--manifest-path','../solosoul_cli/Cargo.toml','--','--check']),('windowless-cli-clippy',['cargo','clippy','--locked','--manifest-path','../solosoul_cli/Cargo.toml','--all-targets','--','-D','warnings']),('windowless-cli-tests',['cargo','test','--locked','--manifest-path','../solosoul_cli/Cargo.toml','--verbose','--no-fail-fast'])]
receipts={}
for name,args in steps:
 verify();rc=subprocess.call([sys.executable,str(s/'run-check.py'),name,*args]);receipt=load(s/(name+'.receipt.json'));receipts[name]=receipt
 if rc:raise SystemExit(rc)
verify();p=s/'required-checks.json';assert not p.exists();p.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'checks':receipts,'sourceInputsUnchanged':1314,'cliInputsUnchanged':108,'frontendDistUnchanged':35,'frontendChecksReusedFrom':'ed23f897','nodeOrFrontendRerunClaimed':False,'budgetsAssertionsOrSecurityWeakened':False},ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print('All RF-1097 R, CLI and source checks complete',flush=True)
