from verify_auth_freezes import verify_sources
import pathlib,json,hashlib,gzip,datetime,subprocess,sys
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul')
control=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-acl-windowless-20261006')
dest=r/'docs/performance/rf1097-windows-acl-windowless-2026-10-06'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda body:hashlib.sha256(body).hexdigest()
checks=load(s/'required-checks.json');assert checks['success'] and len(checks['checks'])==9 and all(q['exitCode']==0 for q in checks['checks'].values())
assert load(s/'release-build.receipt.json')['exitCode']==0
assert load(s/'gui-acl-equivalence.json')['success']
assert load(s/'gui-permission-comparison.json')['permissionStageReductionObserved']
verify_sources(s,r)
for name in ['cli-source-freeze.json','frontend-freeze.json']:
 assert all(sha((r/p).read_bytes())==h for p,h in load(s/name)['files'].items()),name
for checkpoint in ['baseline-build-checkpoint.json','build-checkpoint.json']:
 q=load(s/checkpoint);assert sha(pathlib.Path(q['exe']).read_bytes())==q['sha256']
for group in ['legacy100','windowless100','windowless5000','legacy5000']:
 assert load(s/(group+'-actual-auth-review.json'))['success'] and load(s/(group+'-post-cache-review.json'))['success']
 assert load(s/group/'native-perf-sdk-journey-results.json')['success']
before=load(s/'before.json');assert subprocess.check_output(['git','-c','safe.directory=C:/Users/40299571/SoloSoul','rev-parse','HEAD'],cwd=r,text=True).strip()==before['baseCommit']
rel='tauri/crates/solosoul-core/src/vault_service/mod.rs';baseline=(s/'permissions-before-rf1097.rs').read_bytes();assert sha(baseline)==before['sourceSha256']
original=subprocess.check_output(['git','-c','safe.directory=C:/Users/40299571/SoloSoul','show','HEAD:'+rel],cwd=r)
assert original.replace(b'\r\n',b'\n')==baseline.replace(b'\r\n',b'\n')
current=(r/rel).read_bytes();assert sha(current)==load(s/'source-freeze.json')['files'][rel]
for folder,data in [('baseline-sources',baseline),('current-sources',current)]:
 p=s/folder/rel;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
assert sha((control/'control-results.json').read_bytes())==before['controlEvidenceSha256']
control_files=[p for p in control.iterdir() if p.is_file() and p.suffix in ['.rs','.py','.ps1','.json','.log','.csv','.marker']]
control_files += sorted((control/'workloads').glob('*/accounts.json'))
assert len([p for p in control_files if p.parent.parent.name=='workloads'])==12
for p in control_files:
 assert not p.is_symlink() and p.resolve().is_relative_to(control.resolve())
 copy=s/'controlled-mechanism'/p.relative_to(control);assert not copy.exists();copy.parent.mkdir(parents=True,exist_ok=True);copy.write_bytes(p.read_bytes())
files=[p for p in s.iterdir() if p.is_file() and p.suffix in ['.py','.ps1','.json','.md','.log','.rs']]
for group in ['legacy100','windowless100','windowless5000','legacy5000']:
 g=s/group;assert g.is_dir() and not g.is_symlink();report=load(g/'native-perf-sdk-journey-results.json');expected={'sample-%03d.json'%q['index'] for q in report['samples']}
 files += [p for p in g.iterdir() if p.is_file() and p.suffix in ['.json','.log']]
 for sample in sorted(g.glob('sample-*')):
  assert not sample.is_symlink()
  if sample.is_file():assert sample.name in expected;continue
  assert sample.is_dir()
  files += [p for p in sample.iterdir() if p.is_file() and p.suffix in ['.json','.log','.png']]
  logs=sample/'preserved-app-logs'
  if logs.exists():files += [p for p in logs.rglob('*') if p.is_file()]
for folder in ['baseline-sources','current-sources','controlled-mechanism']:
 files += [p for p in (s/folder).rglob('*') if p.is_file()]
assert not dest.exists();(dest/'raw').mkdir(parents=True);rows=[]
for p in sorted(set(files)):
 assert not p.is_symlink() and p.resolve().is_relative_to(s.resolve());body=p.read_bytes();rel='raw/'+str(p.relative_to(s)).replace(chr(92),'/')+'.gz';copy=dest/rel;assert not copy.exists();copy.parent.mkdir(parents=True,exist_ok=True);data=gzip.compress(body,compresslevel=9,mtime=0);copy.write_bytes(data);assert gzip.decompress(copy.read_bytes())==body
 rows.append({'original':str(p),'archive':rel,'bytes':len(body),'sha256':sha(body),'archiveBytes':len(data),'archiveSha256':sha(data)})
index={'schemaVersion':1,'task':'RF-1097','scope':'owned-windows-acl-windowless-synthetic-only','files':rows}
(dest/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for q in rows:
 data=(dest/q['archive']).read_bytes();body=gzip.decompress(data);assert len(data)==q['archiveBytes'] and sha(data)==q['archiveSha256'] and len(body)==q['bytes'] and sha(body)==q['sha256']
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'archives':len(rows),'originalBytes':sum(q['bytes'] for q in rows),'archiveBytes':sum(q['archiveBytes'] for q in rows),'allDecompressedBytesVerified':True,'controlEvidenceCopiedByteForByte':True,'excluded':['EXEs','model/DLL binaries','GUI Vault physical files','cache trees'],'index':str(dest/'index.json')}
p=s/'raw-archive-review.json';assert not p.exists();p.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(receipt,ensure_ascii=False),flush=True)
