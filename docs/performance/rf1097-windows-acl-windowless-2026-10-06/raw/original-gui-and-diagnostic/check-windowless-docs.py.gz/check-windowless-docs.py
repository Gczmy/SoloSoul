import pathlib,json,subprocess,sys,datetime
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul');stem='rf1097-windows-acl-windowless-2026-10-06';proof_path=r/'docs/performance'/(stem+'.json')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
paths=['../docs/performance/RF-1097-windows-acl-windowless.md','../docs/performance/'+stem+'.json','../docs/performance/'+stem+'/index.json']
steps=[('doc-initial-prettier',['node','node_modules/prettier/bin/prettier.cjs','--write',*paths]),('doc-markdown-boundary',['node','scripts/check-markdown-chunk-boundary.mjs']),('doc-evidence-review',[sys.executable,'-X','utf8',str(s/'verify-windowless-docs.py')])]
receipts={}
for name,args in steps:
 rc=subprocess.call([sys.executable,str(s/'run-check.py'),name,*args]);receipts[name]=load(s/(name+'.receipt.json'))
 if rc:raise SystemExit(rc)
proof=load(proof_path);assert proof['documentationVerification']['success'];proof['documentationToolChecks']={'success':True,'checks':receipts,'outputs':{name:{'stdout':(s/(name+'.stdout.log')).read_text(encoding='utf-8-sig'),'stderr':(s/(name+'.stderr.log')).read_text(encoding='utf-8-sig')} for name in receipts}}
proof_path.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for name,args in [('doc-final-prettier',['node','node_modules/prettier/bin/prettier.cjs','--write',*paths]),('doc-prettier-check',['node','node_modules/prettier/bin/prettier.cjs','--check',*paths])]:
 rc=subprocess.call([sys.executable,str(s/'run-check.py'),name,*args]);receipts[name]=load(s/(name+'.receipt.json'))
 if rc:raise SystemExit(rc)
p=s/'doc-required-checks.json';assert not p.exists();p.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'checks':receipts,'documentationEvidenceVerified':True,'finalFormattedBytesChecked':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print('RF-1097 document links, evidence, boundary and final formatting checks all complete',flush=True)
