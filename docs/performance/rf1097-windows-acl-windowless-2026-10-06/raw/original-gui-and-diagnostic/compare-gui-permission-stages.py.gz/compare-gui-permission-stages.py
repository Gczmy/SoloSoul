from verify_auth_freezes import verify_sources
import pathlib,json,hashlib,statistics,math,datetime,sys
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def distribution(values):
 assert len(values)==3 and all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and v>=0 for v in values)
 return {'n':3,'medianMs':statistics.median(values),'p95Ms':sorted(values)[math.ceil(.95*len(values))-1],'samplesMs':values}
def compare(a,b):
 assert a['n']==b['n']==3
 return {'legacy':a,'windowless':b,'medianReductionMs':a['medianMs']-b['medianMs'],'medianReductionPercent':None if a['medianMs']==0 else 100*(a['medianMs']-b['medianMs'])/a['medianMs'],'p95ReductionMs':a['p95Ms']-b['p95Ms'],'bothMedianAndP95Lower':b['medianMs']<a['medianMs'] and b['p95Ms']<a['p95Ms']}
assert load(s/'gui-acl-equivalence.json')['success']
assert load(s/'required-checks.json')['success']
rows=[];hashes={}
for count in [100,5000]:
 old_group='legacy'+str(count);new_group='windowless'+str(count)
 old=load(s/(old_group+'-actual-auth-review.json'));new=load(s/(new_group+'-actual-auth-review.json'))
 assert old['success'] and new['success'] and old['wholeSamples']==new['wholeSamples']==3
 assert not old['oldTimeoutRootCauseEstablished'] and not new['oldTimeoutRootCauseEstablished']
 assert set(x['runId'] for x in old['samples']).isdisjoint(x['runId'] for x in new['samples'])
 hashes[old_group]=sha(s/(old_group+'-actual-auth-review.json'));hashes[new_group]=sha(s/(new_group+'-actual-auth-review.json'))
 left={v['name']:v for v in old['summary']};right={v['name']:v for v in new['summary']};assert left.keys()==right.keys()
 stages=[{'name':name,**compare(left[name],right[name])} for name in left]
 old_journey=load(s/old_group/'native-perf-sdk-journey-results.json');new_journey=load(s/new_group/'native-perf-sdk-journey-results.json')
 assert old_journey['success'] and new_journey['success']
 journey=[]
 for a,b in zip(old_journey['summary'],new_journey['summary']):
  assert a['name']==b['name'] and a['successfulSamples']==b['successfulSamples']==3
  phase=a['name'];av=[p['durationMs'] for sample in old_journey['samples'] for p in sample['phases'] if p['name']==phase];bv=[p['durationMs'] for sample in new_journey['samples'] for p in sample['phases'] if p['name']==phase]
  da=distribution(av);db=distribution(bv)
  assert abs(da['medianMs']-a['medianMs'])<1e-8 and abs(db['medianMs']-b['medianMs'])<1e-8 and abs(da['p95Ms']-a['p95Ms'])<1e-8 and abs(db['p95Ms']-b['p95Ms'])<1e-8
  journey.append({'name':phase,**compare(da,db)})
 permission=[v for v in stages if v['name'].endswith(':account-directory-permission') or v['name'].endswith(':account-manifest-permission')]
 assert len(permission)==4
 rows.append({'objectCount':count,'legacyGroup':old_group,'windowlessGroup':new_group,'groupOrder':'legacy-then-windowless' if count==100 else 'windowless-then-legacy','permissionStageReductionObserved':all(v['bothMedianAndP95Lower'] for v in permission),'authenticationStageComparisons':stages,'sixPhaseJourneyComparisons':journey})
verify_sources(s,r)
for name in ['cli-source-freeze.json','frontend-freeze.json']:
 assert all(sha(r/p)==h for p,h in load(s/name)['files'].items()),name
for name in ['baseline-build-checkpoint.json','build-checkpoint.json']:
 q=load(s/name);assert sha(pathlib.Path(q['exe']))==q['sha256']
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'scope':'windows-owned-public-gui-permission-comparison','wholeGroups':4,'wholeSamples':12,'originalBudgetsAndAssertionsPreserved':True,'oldHomeTimeoutRootCauseEstablished':False,'sameBackendClockPerStage':True,'frontBackendClocksSubtracted':False,'nestedStageDurationsAdded':False,'crossProcessTimestampSubtracted':False,'n3P95IsObservedMaximum':True,'systemColdStateClaimed':False,'noInstrumentationOrCpuNetTimeClaimed':True,'permissionStageReductionObserved':all(v['permissionStageReductionObserved'] for v in rows),'actualAclEqual':True,'reviewHashes':hashes,'datasets':rows}
p=s/'gui-permission-comparison.json';assert not p.exists();p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Whole-group GUI comparison complete; permission stage reduction observed: '+str(result['permissionStageReductionObserved']),flush=True)
