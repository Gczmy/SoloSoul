import pathlib,json,hashlib,subprocess,os,sys,time,datetime,shutil
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul');old=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-account-write-20261006')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(name,value):
 p=s/name;assert not p.exists(),str(p);p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def verify():
 for name in ['source-freeze.json','cli-source-freeze.json','frontend-freeze.json']:
  assert all(sha(r/p)==h for p,h in load(s/name)['files'].items()),name
checks=load(s/'required-checks.json');assert checks['success'] and len(checks['checks'])==9 and all(q['exitCode']==0 for q in checks['checks'].values());verify()
assert load(s/'scope-verification.json')['onlyTwoCreationFlagsAndImportConstantChanged']
before=load(s/'before.json');assert subprocess.check_output(['git','-c','safe.directory=C:/Users/40299571/SoloSoul','rev-parse','HEAD'],cwd=r,text=True).strip()==before['baseCommit']
for folder in ['bin','baseline-bin']:(s/folder).mkdir(exist_ok=False)
resources=[]
for v in load(old/'resource-freeze.json')['records']:
 source=pathlib.Path(v['copy']);assert sha(source)==v['sha256']
 for folder in ['bin','baseline-bin']:
  copy=s/folder/v['relativePath'];assert copy.resolve().is_relative_to((s/folder).resolve());copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,copy);assert sha(copy)==v['sha256'];resources.append({'relativePath':folder+'/'+v['relativePath'],'source':str(source),'copy':str(copy),'sha256':v['sha256']})
write('resource-freeze.json',{'at':now(),'records':resources})
public=load(old/'public-source-freeze.json')['files'];assert all(sha(pathlib.Path(p))==h for p,h in public.items());write('public-source-freeze.json',{'files':public})
previous=load(old/'previous-build-freeze.json')['files'];base=load(old/'build-checkpoint.json');previous[base['exe']]=base['sha256'];assert all(sha(pathlib.Path(p))==h for p,h in previous.items());write('previous-build-freeze.json',{'files':previous})
baseline=s/'baseline-bin/solo_soul.exe';shutil.copy2(pathlib.Path(base['exe']),baseline);assert sha(baseline)==base['sha256'];write('baseline-build-checkpoint.json',{'at':now(),'exe':str(baseline),'bytes':baseline.stat().st_size,'sha256':sha(baseline),'sourceCommit':before['baseCommit'],'sourceFreezeSha256':sha(old/'source-freeze.json'),'originalExe':base['exe'],'binaryRelocatedWithIdenticalResources':True,'resourcesCopied':94,'sourceChangedFromOriginalBinary':False})
print('Prepared byte-identical baseline GUI and both 94-resource packages',flush=True)
args=['cargo','build','--locked','--release','-p','solo_soul','--features','native-perf','--bin','solo_soul'];env=os.environ.copy();env['CARGO_BUILD_JOBS']='2';env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','');env.pop('PDFIUM_LIBRARY_PATH',None);start=time.time()
with (s/'release-build.stdout.log').open('xb') as out,(s/'release-build.stderr.log').open('xb') as err:
 p=subprocess.Popen(args,cwd=r/'tauri',env=env,stdout=out,stderr=err);write('release-build.live.json',{'command':args,'pid':p.pid,'at':now()});print('Started RF-1097 Release PID '+str(p.pid),flush=True);rc=p.wait()
write('release-build.receipt.json',{'command':args,'pid':p.pid,'exitCode':rc,'elapsedSeconds':time.time()-start,'at':now()});print('RF-1097 Release exit '+str(rc),flush=True)
if rc:raise SystemExit(rc)
verify()
for name in ['public-source-freeze.json','previous-build-freeze.json']:assert all(sha(pathlib.Path(p))==h for p,h in load(s/name)['files'].items()),name
assert all(sha(pathlib.Path(v['source']))==v['sha256']==sha(pathlib.Path(v['copy'])) for v in resources) and sha(baseline)==base['sha256']
exe=s/'bin/solo_soul.exe';assert not exe.exists();shutil.copy2(r/'tauri/target/release/solo_soul.exe',exe);data=exe.read_bytes();markers=['windows-native-auth-attribution','account-manifest-serialize','account-directory-create','account-directory-permission','account-manifest-atomic-write','account-manifest-permission'];assert all(v.encode() in data for v in markers) and sha(exe)!=base['sha256']
write('build-checkpoint.json',{'at':now(),'exe':str(exe),'bytes':len(data),'sha256':sha(exe),'sourceInputsUnchanged':1314,'cliInputsUnchanged':108,'frontendFilesUnchanged':35,'resourceCopiesUnchanged':188,'publicFilesUnchanged':185,'previousBuildsPreserved':len(previous),'markers':markers,'baselineExeSha256':base['sha256'],'changedProductionFiles':['tauri/crates/solosoul-core/src/vault_service/mod.rs']});print('RF-1097 new and baseline GUI packages frozen',flush=True)
