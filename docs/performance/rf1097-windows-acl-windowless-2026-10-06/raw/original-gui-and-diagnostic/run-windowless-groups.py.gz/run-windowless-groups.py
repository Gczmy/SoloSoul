import pathlib,json,hashlib,subprocess,sys
from verify_auth_freezes import verify_sources
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plans=[('legacy100','legacy-native100',100,'baseline-build-checkpoint.json'),('windowless100','windowless-native100',100,'build-checkpoint.json'),('windowless5000','windowless-native5000',5000,'build-checkpoint.json'),('legacy5000','legacy-native5000',5000,'baseline-build-checkpoint.json')]
def verify():
 verify_sources(s,r)
 for name in ['cli-source-freeze.json','frontend-freeze.json']:assert all(sha(r/p)==h for p,h in load(s/name)['files'].items()),name
 for name in ['public-source-freeze.json','previous-build-freeze.json']:assert all(sha(pathlib.Path(p))==h for p,h in load(s/name)['files'].items()),name
 for row in load(s/'resource-freeze.json')['records']:assert sha(pathlib.Path(row['source']))==row['sha256']==sha(pathlib.Path(row['copy']))
 for name in ['baseline-build-checkpoint.json','build-checkpoint.json']:
  build=load(s/name);assert sha(pathlib.Path(build['exe']))==build['sha256']
assert load(s/'required-checks.json')['success']
for group,label,count,checkpoint in plans:
 verify();build=load(s/checkpoint);output=s/group;assert not output.exists()
 fixture=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\solosoul-rf312-native-fixtures-20260930')/('vault'+str(count))
 args=['node','scripts/native-perf-auth-attribution.mjs','--exe',build['exe'],'--fixture',str(fixture),'--output',str(output),'--samples','3']
 rc=subprocess.call([sys.executable,str(s/'run-check.py'),label,*args]);verify()
 if rc:raise SystemExit(rc)
print('All four whole native groups complete; opposite version order between object sizes retained',flush=True)
