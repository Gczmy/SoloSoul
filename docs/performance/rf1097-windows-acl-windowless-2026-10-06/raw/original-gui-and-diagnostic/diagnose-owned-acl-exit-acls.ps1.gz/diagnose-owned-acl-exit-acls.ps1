$ErrorActionPreference='Stop'
$stagePath='C:\Users\40299571\AppData\Local\Temp\ss-rf1097-acl-windowless-20261006'
if((Split-Path -LiteralPath $PSCommandPath) -ne $stagePath){throw 'Unexpected ACL diagnostic stage'}
function Full([string]$value){if($value.StartsWith('\\?\')){$value=$value.Substring(4)};return [IO.Path]::GetFullPath($value).TrimEnd('\')}
function Same([string]$a,[string]$b){return (Full $a).Equals((Full $b),[StringComparison]::OrdinalIgnoreCase)}
function Ordinary([string]$path,[bool]$directory){$item=Get-Item -LiteralPath $path -Force;if($item.PSIsContainer -ne $directory -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or -not(Same $item.FullName $path)){throw 'Unexpected ordinary ACL target'}}
$taskSid=[Security.Principal.WindowsIdentity]::GetCurrent().User;$rows=@()
foreach($group in @('legacy100','windowless100','windowless5000','legacy5000','legacy5000-exit-diagnostic-01')){
 $report=Get-Content -LiteralPath (Join-Path $stagePath ($group+'\native-perf-sdk-journey-results.json')) -Raw | ConvertFrom-Json
 if(-not $report.success -or -not $report.sourceUnchanged -or $report.samples.Count -ne 3 -or $report.samplesRequested -ne 3){throw 'Whole GUI journey missing'}
 $count=if($group -in @('legacy100','windowless100')){100}else{5000}
 $authAccepted=$group -ne 'legacy5000'
 if($authAccepted){$review=Get-Content -LiteralPath (Join-Path $stagePath ($group+'-actual-auth-review.json')) -Raw | ConvertFrom-Json;if(-not $review.success -or $review.wholeSamples -ne 3){throw 'Complete independent diagnostic review missing'}}
 foreach($sample in $report.samples){
  $root=Join-Path $stagePath ($group+'\sample-'+([int]$sample.index).ToString('000'));Ordinary $root $true
  $owned=Get-Content -LiteralPath (Join-Path $root 'native-perf-owned.json') -Raw | ConvertFrom-Json;$vault=Join-Path $root 'vault'
  if(-not(Same $owned.root $root) -or -not(Same $sample.root $root) -or -not(Same $owned.vault $vault) -or $owned.scope -ne 'windows-native-perf-owned' -or $owned.runId -ne $sample.nativeProof.runId -or $owned.fixture.accountId -ne ('acc_rf312_'+$count) -or $owned.fixture.objectCount -ne $count -or -not $sample.success -or -not $sample.cleanupIntegrity.complete){throw 'Owned public Vault identity rejected'}
  $targets=@(@{kind='vault-directory';path=$vault;directory=$true;protected=$true;inherited=$false;inheritance=3},@{kind='account-manifest';path=(Join-Path $vault 'accounts.json');directory=$false;protected=$true;inherited=$false;inheritance=0},@{kind='account-config';path=(Join-Path $vault ($owned.fixture.accountId+'\config.json'));directory=$false;protected=$false;inherited=$true;inheritance=0})
  foreach($target in $targets){
   Ordinary $target.path $target.directory
   $before=if($target.directory){$null}else{(Get-FileHash -LiteralPath $target.path -Algorithm SHA256).Hash.ToLowerInvariant()}
   $acl=Get-Acl -LiteralPath $target.path;$rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]))
   $currentOnly=$rules.Count -eq 1 -and $rules[0].IdentityReference -eq $taskSid -and $rules[0].AccessControlType -eq [Security.AccessControl.AccessControlType]::Allow -and $rules[0].FileSystemRights -eq [Security.AccessControl.FileSystemRights]::FullControl -and $rules[0].PropagationFlags -eq [Security.AccessControl.PropagationFlags]::None
   $matches=$currentOnly -and $acl.AreAccessRulesProtected -eq $target.protected -and $rules[0].IsInherited -eq $target.inherited -and [int]$rules[0].InheritanceFlags -eq $target.inheritance
   $descriptor=$acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]'Owner,Group,Access')
   $descriptorHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($descriptor))).ToLowerInvariant()
   if(-not $target.directory -and (Get-FileHash -LiteralPath $target.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $before){throw 'ACL read changed file bytes'}
   $rows+=[ordered]@{group=$group;sample=[int]$sample.index;kind=$target.kind;authReviewAccepted=$authAccepted;expectedContractMatches=$matches;protected=$acl.AreAccessRulesProtected;ruleCount=$rules.Count;inherited=if($rules.Count -eq 1){$rules[0].IsInherited}else{$null};inheritanceFlags=if($rules.Count -eq 1){[int]$rules[0].InheritanceFlags}else{$null};currentUserFullControlOnly=$currentOnly;ownerCurrentUser=($acl.GetOwner([Security.Principal.SecurityIdentifier]) -eq $taskSid);descriptorSha256=$descriptorHash;contentSha256=$before}
  }
 }
}
if($rows.Count -ne 45){throw 'Expected 45 complete ACL observations'}
$result=[ordered]@{at=[DateTime]::UtcNow.ToString('o');readOnlyObservationCompleted=$true;diagnosticOnly=$true;originalFailedGroupAccepted=$false;applicationPerformanceAccepted=$false;aclEquivalenceAccepted=$false;descriptorsObserved=$rows.Count;contractMismatchCount=@($rows | Where-Object {-not $_.expectedContractMatches}).Count;currentUserFullControlOnlyEveryObservedTarget=(@($rows | Where-Object {-not $_.currentUserFullControlOnly}).Count -eq 0);fileBytesUnchanged=$true;rawSidOrSddlRecorded=$false;productionPermissionsChanged=$false;records=$rows}
$output=Join-Path $stagePath 'owned-acl-exit-readonly-acl-diagnostic.json';$bytes=[Text.UTF8Encoding]::new($false).GetBytes(($result | ConvertTo-Json -Depth 10)+[char]10)
$stream=[IO.FileStream]::new($output,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read);try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
Write-Output ('Read-only ACL diagnostic: 45 descriptors; {0} exact-contract mismatches; no equivalence accepted' -f $result.contractMismatchCount)
