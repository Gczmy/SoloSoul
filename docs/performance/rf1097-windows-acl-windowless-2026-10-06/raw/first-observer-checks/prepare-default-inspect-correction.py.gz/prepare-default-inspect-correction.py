from pathlib import Path
import json,hashlib,subprocess,datetime,time
s=Path(__file__).parent;r=Path(r'C:\Users\40299571\SoloSoul');current=r/'tauri/crates/solosoul-core/src/vault_service/mod.rs';frozen=json.loads((s/'source-freeze.json').read_text())['files'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before_sha=sha(current);assert before_sha==frozen['tauri/crates/solosoul-core/src/vault_service/mod.rs']
module=current.read_text(encoding='utf-8');extracted=(s/'default-contract/after.rs').read_text(encoding='utf-8')
def corrected(text):
 old='let username = sanitize_windows_username(&username).map_err(|error| {';assert text.count(old)==2;text=text.replace(old,'let username = sanitize_windows_username(&username).inspect_err(|_| {')
 for target in ['Directory','File']:
  old='crate::native_perf_unlock::PermissionTarget::'+target+',\n            crate::native_perf_unlock::PermissionOutcome::InvalidUsername,\n        );\n        error\n    })?;';new=old.replace('\n        error','');assert text.count(old)==1;text=text.replace(old,new)
 return text
proposed=s/'proposed-default-inspect-mod.rs';assert not proposed.exists();proposed.write_text(corrected(module),encoding='utf-8',newline='\n')
# This allow is limited to the public probe harness main, not the verbatim production helpers.
original=extracted.replace('fn main() {','#[allow(clippy::vec_init_then_push)]\nfn main() {');assert original!=extracted
for name,source in [('before',original),('proposed',corrected(original))]:
 src=s/('default-contract/'+name+'-targeted-inspect-clippy.rs');assert not src.exists();src.write_text(source,encoding='utf-8',newline='\n');driver=r'C:\Users\40299571\.rustup\toolchains\stable-x86_64-pc-windows-msvc\bin\clippy-driver.exe';args=[driver,'--edition=2021','--crate-name','rf1097_default_inspect_'+name,'--check-cfg','cfg(feature, values("native-perf"))','--emit=metadata','-o',str(s/('default-contract/'+name+'-inspect-clippy.rmeta')),str(src),'-D','warnings'];begin=time.monotonic();result=subprocess.run(args,capture_output=True)
 for kind,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  p=s/('default-inspect-'+name+'.'+kind+'.log');assert not p.exists();p.write_bytes(data)
 receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':args,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-begin,'sourceSha256':sha(src),'featureEnabled':False,'productionSourceChanged':False,'testHarnessOnlyLintExemption':'vec_init_then_push on probe main'};p=s/('default-inspect-'+name+'.receipt.json');assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
 if name=='before':assert result.returncode!=0 and result.stderr.count(b'unnecessary map of the identity function')==2
 else:assert result.returncode==0,result.stderr.decode('utf-8',errors='replace')
 print('Default-only helper '+name+' targeted Clippy exit '+str(result.returncode),flush=True)
assert sha(current)==before_sha
p=s/'default-inspect-proposed-proof.json';assert not p.exists();p.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'actualBeforeRejected':True,'actualProposedPassed':True,'proposedModuleSha256':sha(proposed),'frozenProductionSourceUnchanged':True,'correctionApplied':False,'fullWorkspaceCheckSubstituted':False,'mapsReplaced':2},indent=2)+'\n',encoding='utf-8');print('Proposed inspect_err correction confirmed by actual targeted Clippy; current live source untouched',flush=True)