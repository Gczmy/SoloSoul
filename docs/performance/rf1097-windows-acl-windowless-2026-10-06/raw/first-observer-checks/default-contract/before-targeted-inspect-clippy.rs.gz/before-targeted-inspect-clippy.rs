#![windows_subsystem="windows"]
use std::path::Path;
use std::os::windows::process::CommandExt;
const CREATE_NO_WINDOW:u32=0x08000000;
fn sanitize_windows_username(username: &str) -> Result<String, String> {
    if username.is_empty() {
        return Err("Windows username is empty".to_string());
    }
    if !username
        .chars()
        .all(|c| c.is_alphanumeric() || c == ' ' || c == '-' || c == '_' || c == '.')
    {
        return Err(format!(
            "Windows username contains invalid characters: {}",
            username
        ));
    }
    Ok(username.to_string())
}

fn set_private_dir(path: &Path) -> Result<(), String> {
    let path_str = path.to_string_lossy();
    let username = std::env::var("USERNAME").map_err(|_| {
        #[cfg(feature = "native-perf")]
        crate::native_perf_unlock::permission(
            crate::native_perf_unlock::PermissionTarget::Directory,
            crate::native_perf_unlock::PermissionOutcome::UsernameUnavailable,
        );
        "USERNAME environment variable not found".to_string()
    })?;
    let username = sanitize_windows_username(&username).map_err(|error| {
        #[cfg(feature = "native-perf")]
        crate::native_perf_unlock::permission(
            crate::native_perf_unlock::PermissionTarget::Directory,
            crate::native_perf_unlock::PermissionOutcome::InvalidUsername,
        );
        error
    })?;
    let status = std::process::Command::new("icacls")
        .creation_flags(CREATE_NO_WINDOW)
        .arg(path_str.as_ref())
        .arg("/inheritance:r")
        .arg("/grant")
        .arg(format!("{username}:(OI)(CI)F"))
        .status()
        .map_err(|e| {
            #[cfg(feature = "native-perf")]
            crate::native_perf_unlock::permission(
                crate::native_perf_unlock::PermissionTarget::Directory,
                crate::native_perf_unlock::PermissionOutcome::SpawnError {
                    os_error: e.raw_os_error(),
                },
            );
            format!("icacls failed to start: {e}")
        })?;
    #[cfg(feature = "native-perf")]
    crate::native_perf_unlock::permission(
        crate::native_perf_unlock::PermissionTarget::Directory,
        crate::native_perf_unlock::PermissionOutcome::Exited {
            code: status.code(),
            success: status.success(),
        },
    );
    if !status.success() {
        return Err(format!(
            "icacls returned exit code {:?} when setting permissions on {path_str}",
            status.code()
        ));
    }
    Ok(())
}

fn set_private_file(path: &Path) -> Result<(), String> {
    let path_str = path.to_string_lossy();
    let username = std::env::var("USERNAME").map_err(|_| {
        #[cfg(feature = "native-perf")]
        crate::native_perf_unlock::permission(
            crate::native_perf_unlock::PermissionTarget::File,
            crate::native_perf_unlock::PermissionOutcome::UsernameUnavailable,
        );
        "USERNAME environment variable not found".to_string()
    })?;
    let username = sanitize_windows_username(&username).map_err(|error| {
        #[cfg(feature = "native-perf")]
        crate::native_perf_unlock::permission(
            crate::native_perf_unlock::PermissionTarget::File,
            crate::native_perf_unlock::PermissionOutcome::InvalidUsername,
        );
        error
    })?;
    let status = std::process::Command::new("icacls")
        .creation_flags(CREATE_NO_WINDOW)
        .arg(path_str.as_ref())
        .arg("/inheritance:r")
        .arg("/grant")
        .arg(format!("{username}:F"))
        .status()
        .map_err(|e| {
            #[cfg(feature = "native-perf")]
            crate::native_perf_unlock::permission(
                crate::native_perf_unlock::PermissionTarget::File,
                crate::native_perf_unlock::PermissionOutcome::SpawnError {
                    os_error: e.raw_os_error(),
                },
            );
            format!("icacls failed to start: {e}")
        })?;
    #[cfg(feature = "native-perf")]
    crate::native_perf_unlock::permission(
        crate::native_perf_unlock::PermissionTarget::File,
        crate::native_perf_unlock::PermissionOutcome::Exited {
            code: status.code(),
            success: status.success(),
        },
    );
    if !status.success() {
        return Err(format!(
            "icacls returned exit code {:?} when setting permissions on {path_str}",
            status.code()
        ));
    }
    Ok(())
}

#[repr(C)] struct FileTime { low:u32, high:u32 }
#[link(name="kernel32")] extern "system" {
 fn GetConsoleWindow()->isize;
 fn GetCurrentProcess()->isize;
 fn GetProcessTimes(handle:isize,c:*mut FileTime,e:*mut FileTime,k:*mut FileTime,u:*mut FileTime)->i32;
}
#[allow(clippy::vec_init_then_push)]
fn main() {
 let root=std::path::PathBuf::from(std::env::args().nth(1).expect("owned public root"));
 assert_eq!(root,std::path::PathBuf::from(r#"C:\Users\40299571\AppData\Local\Temp\ss-rf1097-permission-outcomes-20261006\default-contract\after"#));assert!(!root.exists());
 std::fs::create_dir(&root).unwrap();let private=root.join("private");std::fs::create_dir(&private).unwrap();let file=private.join("public.json");std::fs::write(&file,[91_u8,93,10]).unwrap();
 let normalize=|outcome:Result<(),String>|match outcome {Ok(())=>"ok".to_string(),Err(error)=>error.replace(root.to_str().unwrap(),"<fixture-root>")};
 let mut rows=Vec::new();rows.push(("directory-success",normalize(set_private_dir(&private))));rows.push(("file-success",normalize(set_private_file(&file))));
 rows.push(("missing-directory",normalize(set_private_dir(&root.join("missing-directory")))));rows.push(("missing-file",normalize(set_private_file(&root.join("missing-file")))));
 let username=std::env::var_os("USERNAME").expect("existing Windows test user");
 std::env::set_var("USERNAME","");rows.push(("empty-username",normalize(set_private_file(&file))));
 std::env::set_var("USERNAME","invalid/fixture-user");rows.push(("invalid-username",normalize(set_private_file(&file))));
 std::env::remove_var("USERNAME");rows.push(("missing-username",normalize(set_private_file(&file))));std::env::set_var("USERNAME",username);
 let mut csv=String::new();for (name,result) in rows {assert!(!result.contains(char::from(10)) && !result.contains(char::from(9)));csv.push_str(name);csv.push(char::from(9));csv.push_str(&result);csv.push(char::from(10));}
 std::fs::write(root.join("results.tsv"),csv).unwrap();
 let (mut c,mut e,mut k,mut u)=(FileTime{low:0,high:0},FileTime{low:0,high:0},FileTime{low:0,high:0},FileTime{low:0,high:0});
 assert_ne!(unsafe{GetProcessTimes(GetCurrentProcess(),&mut c,&mut e,&mut k,&mut u)},0);
 let birth=((c.high as u64)<<32)|c.low as u64;let console=unsafe{GetConsoleWindow()};assert_eq!(console,0);
 std::fs::write(root.join("identity.json"),format!(r#"{{"pid":{},"birthFileTime":{},"consoleWindowHandle":{},"defaultFeatureDisabled":true}}"#,std::process::id(),birth,console)).unwrap();
}
