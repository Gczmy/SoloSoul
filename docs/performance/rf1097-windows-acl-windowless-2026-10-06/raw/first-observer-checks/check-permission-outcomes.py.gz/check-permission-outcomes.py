import pathlib,json,hashlib,subprocess,sys,datetime
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
 for name in ['source-freeze.json','cli-source-freeze.json','frontend-freeze.json']:
  assert all(sha(r/p)==h for p,h in load(s/name)['files'].items()),name
steps=[
 ('permission-actual-failure',['cargo','test','--locked','-p','solosoul-core','--features','native-perf','permission_outcome_tests::']),
 ('permission-contract-target',['cargo','test','--locked','-p','solo_soul','--features','native-perf','native_perf::permission_contract::']),
 ('permission-rust-fmt',['cargo','+1.99.0','fmt','--all','--','--check']),
 ('permission-default-clippy',['cargo','clippy','--locked','--workspace','--all-targets','--','-D','warnings']),
 ('permission-default-tests',['cargo','test','--locked','--workspace','--verbose','--no-fail-fast']),
 ('permission-native-clippy',['cargo','clippy','--locked','-p','solo_soul','--features','native-perf','--all-targets','--','-D','warnings']),
 ('permission-native-tests',['cargo','test','--locked','-p','solo_soul','--features','native-perf','native_perf::']),
 ('permission-core-native-clippy',['cargo','clippy','--locked','-p','solosoul-core','--features','native-perf','--all-targets','--','-D','warnings']),
 ('permission-core-native-tests',['cargo','test','--locked','-p','solosoul-core','--features','native-perf','native_perf_unlock::']),
 ('permission-cli-fmt',['cargo','+1.99.0','fmt','--manifest-path','../solosoul_cli/Cargo.toml','--','--check']),
 ('permission-cli-clippy',['cargo','clippy','--locked','--manifest-path','../solosoul_cli/Cargo.toml','--all-targets','--','-D','warnings']),
 ('permission-cli-tests',['cargo','test','--locked','--manifest-path','../solosoul_cli/Cargo.toml','--verbose','--no-fail-fast'])]
receipts={}
for name,args in steps:
 verify();code=subprocess.call([sys.executable,'-X','utf8',str(s/'run-check.py'),name,*args]);receipts[name]=load(s/(name+'.receipt.json'))
 if code:raise SystemExit(code)
verify();p=s/'required-checks.json';assert not p.exists();p.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'checks':receipts,'frozenMainInputs':1315,'frozenCliInputs':108,'frozenFrontendDist':35,'frontendChecksReusedFrom':'ed23f897','nodeOrFrontendRerunClaimed':False,'oldFailuresKept':True,'securityOrBudgetsWeakened':False},indent=2)+'\n',encoding='utf-8',newline='\n');print('All actual permission observation checks completed',flush=True)
