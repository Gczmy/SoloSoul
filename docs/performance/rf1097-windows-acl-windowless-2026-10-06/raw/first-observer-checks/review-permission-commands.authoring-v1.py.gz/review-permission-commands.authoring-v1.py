from pathlib import Path
import json,hashlib,datetime,math,copy,sys,re
s=Path(__file__).parent;groups=['legacy100','windowless100','windowless5000','legacy5000'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def require(condition,reason):
 if not condition:raise ValueError(reason)
def exact(value,keys):return isinstance(value,dict) and set(value)==set(keys.split())
def finite(n):return type(n) in [int,float] and math.isfinite(n) and n>=0
def number(n):return n is None or type(n) is int and -(2**31)<=n<2**31
def unique_pairs(pairs):
 obj={}
 for k,v in pairs:require(k not in obj,'duplicate-json-key');obj[k]=v
 return obj
def read(p):
 require(p.is_file() and not p.is_symlink() and p.stat().st_size<=262144,'bounded-ordinary-artifact-required');return json.loads(p.read_text(encoding='utf-8-sig'),object_pairs_hook=unique_pairs)
def validate(value,backend,run_id,pid):
 require(exact(value,'schemaVersion scope runId pid clockScope atMs valid invalidReasons maxCommands commands'),'side-top-level-fields')
 require(type(value['schemaVersion']) is int and value['schemaVersion']==1 and value['scope']=='windows-native-permission-commands','side-schema-scope')
 require(re.fullmatch('[0-9a-fA-F]{32}',run_id) is not None and value['runId']==run_id and type(value['pid']) is int and value['pid']==pid and pid>0,'side-run-process-identity')
 require(value['clockScope']==backend['clockScope']=='process-monotonic' and finite(value['atMs']) and value['atMs']==backend['atMs'],'side-atomic-clock')
 require(value['valid'] is True and value['invalidReasons']==[] and type(value['maxCommands']) is int and value['maxCommands']==64,'side-validity-bound')
 commands=value['commands'];require(isinstance(commands,list) and len(commands)<=64,'side-command-bound')
 expected={};logins=0
 for attempt in backend['attempts']:
  if attempt['kind']=='login':logins+=1
  for token,stage in enumerate(attempt['stages']):
   if stage['name'] in ['account-directory-permission','account-manifest-permission']:
    require(attempt['kind']=='login' and attempt['rootVerified'] is True,'side-owned-login-stage')
    require(stage['outcome'] in ['completed','interrupted'] and finite(stage['startedAtMs']) and finite(stage['endedAtMs']) and stage['startedAtMs']<=stage['endedAtMs']<=value['atMs'],'side-stage-final-clock')
    key=(attempt['id'],token);require(key not in expected,'side-ambiguous-stage');expected[key]=stage
 require(logins==2 and len(expected)==4 and len(commands)==4,'whole-two-login-four-command-records')
 previous=0.0;seen=set();rows=[];accepted=True
 for cmd in commands:
  require(exact(cmd,'attemptId stageToken kind atMs outcome exitCode osError'),'side-command-fields')
  require(type(cmd['attemptId']) is int and type(cmd['stageToken']) is int and cmd['attemptId']>0 and cmd['stageToken']>=0,'side-command-token')
  key=(cmd['attemptId'],cmd['stageToken']);require(key not in seen and key in expected,'side-duplicate-or-foreign-command');seen.add(key);stage=expected[key]
  require(cmd['kind'] in ['directory','file'] and stage['name']=={'directory':'account-directory-permission','file':'account-manifest-permission'}[cmd['kind']],'side-command-role')
  require(finite(cmd['atMs']) and previous<=cmd['atMs'] and stage['startedAtMs']<=cmd['atMs']<=stage['endedAtMs'],'side-command-clock');previous=cmd['atMs']
  require(number(cmd['exitCode']) and number(cmd['osError']),'side-numeric-status')
  outcome=cmd['outcome'];ok=(outcome=='success' and cmd['exitCode']==0 and cmd['osError'] is None) or (outcome=='exit-failure' and cmd['exitCode']!=0 and cmd['osError'] is None) or (outcome=='spawn-error' and cmd['exitCode'] is None) or (outcome in ['username-unavailable','invalid-username'] and cmd['exitCode'] is None and cmd['osError'] is None)
  require(ok,'side-fixed-status');require((stage['outcome']=='completed')==(outcome=='success'),'side-stage-status-correlation')
  accepted=accepted and outcome=='success';rows.append(dict(cmd,stage=stage['name'],durationMs=stage['endedAtMs']-stage['startedAtMs']))
 require(seen==set(expected),'side-missing-command')
 return {'contractValid':True,'allFourActualCommandsSucceeded':accepted,'commands':rows}
def negatives(good,backend,run_id,pid):
 rejected=0
 for pointer,bad in [('runId','f'*32),('pid',pid+1),('clockScope','frontend'),('atMs',good['atMs']+1),('maxCommands',65),('valid',False),('privatePath','sentinel')]:
  changed=copy.deepcopy(good);changed[pointer]=bad
  try:validate(changed,backend,run_id,pid)
  except ValueError:rejected+=1
  else:raise ValueError('negative-top-level-accepted')
 for field,bad in [('kind','unknown'),('exitCode',2147483648),('osError','sentinel'),('stageToken',9999),('path','sentinel'),('atMs',float('inf')),('outcome','arbitrary-error-text')]:
  changed=copy.deepcopy(good);changed['commands'][0][field]=bad
  try:validate(changed,backend,run_id,pid)
  except ValueError:rejected+=1
  else:raise ValueError('negative-command-accepted')
 for mode in ['missing','duplicate','overflow']:
  changed=copy.deepcopy(good)
  if mode=='missing':changed['commands'].pop()
  elif mode=='duplicate':changed['commands'][1]=copy.deepcopy(changed['commands'][0])
  else:changed['commands']=[copy.deepcopy(changed['commands'][0]) for _ in range(65)]
  try:validate(changed,backend,run_id,pid)
  except ValueError:rejected+=1
  else:raise ValueError('negative-cardinality-accepted')
 failure=copy.deepcopy(good);failed_backend=copy.deepcopy(backend);cmd=failure['commands'][0];cmd['outcome']='exit-failure';cmd['exitCode']=5
 attempt=next(a for a in failed_backend['attempts'] if a['id']==cmd['attemptId']);attempt['stages'][cmd['stageToken']]['outcome']='interrupted';diagnostic=validate(failure,failed_backend,run_id,pid);require(diagnostic['contractValid'] and not diagnostic['allFourActualCommandsSucceeded'],'actual-failure-must-remain-failed')
 return {'malformedOrPrivateCasesRejected':rejected,'typedFailurePreservedAndNotAccepted':True,'failureNegativeControlIsSynthetic':True}
if __name__=='__main__':
 require(len(sys.argv)==2 and sys.argv[1] in groups,'exact-group-required');group=sys.argv[1];root=s/group
 result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'group':group,'scope':'independent-fixed-numeric-permission-commands-review','success':False,'wholeSamples':3,'diagnosticOnly':True,'permissionResultsAccepted':False,'rawPathsUsernamesOrErrorTextRecorded':False,'samples':[]}
 try:
  report=json.loads((root/'native-perf-sdk-journey-results.json').read_text(encoding='utf-8-sig'));require(report['samplesRequested']==3 and len(report['samples'])==3,'whole-group-required')
  for sample in report['samples']:
   sample_root=root/('sample-'+str(sample['index']).zfill(3));require(Path(sample['root']).resolve()==sample_root.resolve() and not sample_root.is_symlink(),'exact-sample-root')
   raw=read(sample_root/'native-perf-auth-attribution.json');proof=read(sample_root/'native-perf-sdk-journey-proof.json');side_path=sample_root/'native-perf-permission-commands.json';side=read(side_path)
   require(raw['runId']==proof['runId']==sample['owned']['runId'] and raw['pid']==proof['pid']==sample['bound']['pid'],'exact-owned-proof-identity')
   checked=validate(side,raw['backend'],raw['runId'],raw['pid']);row={'index':sample['index'],'runId':raw['runId'],'pid':raw['pid'],'artifactSha256':sha(side_path),'authArtifactSha256':sha(sample_root/'native-perf-auth-attribution.json'),**checked}
   if checked['allFourActualCommandsSucceeded']:row['negativeControls']=negatives(side,raw['backend'],raw['runId'],raw['pid'])
   result['samples'].append(row)
  require(report['success'] is True and all(x['success'] for x in report['samples']),'actual-whole-journey-failed');require(all(x['allFourActualCommandsSucceeded'] for x in result['samples']),'actual-permission-command-failed')
  result['success']=True;result['permissionResultsAccepted']=True
 except (ValueError,AssertionError,KeyError,TypeError,FileNotFoundError):result['error']='whole-group-or-fixed-command-proof-rejected'
 out=s/(group+'-permission-commands-review.json');require(not out.exists(),'refuse-overwrite-review');out.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n');print(group+' fixed permission command proof accepted: '+str(result['success']));sys.exit(0 if result['success'] else 1)