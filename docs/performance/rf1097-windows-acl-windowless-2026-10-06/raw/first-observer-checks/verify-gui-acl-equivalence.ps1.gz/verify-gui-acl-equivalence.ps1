#Requires -Version 7.0
param([Parameter(Mandatory=$true)][string]$StageRoot)
$ErrorActionPreference='Stop'
function TaskFull([string]$Text){if($Text.StartsWith('\\?\')){$Text=$Text.Substring(4)};return [IO.Path]::GetFullPath($Text).TrimEnd('\')}
function TaskSame([string]$Left,[string]$Right){return (TaskFull $Left).Equals((TaskFull $Right),[StringComparison]::OrdinalIgnoreCase)}
function TaskOrdinary([string]$Text,[bool]$Directory){$entry=Get-Item -LiteralPath $Text -Force;if($entry.PSIsContainer -ne $Directory -or ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -or -not(TaskSame $entry.FullName $Text)){throw 'ACL target is not the expected ordinary item'}}
$taskExpected=$PSScriptRoot
if(-not(TaskSame $StageRoot $taskExpected)){throw 'Only this exact GUI comparison stage is allowed'}
TaskOrdinary $taskExpected $true
$taskOutput=Join-Path $taskExpected 'gui-acl-equivalence.json'
if(Test-Path -LiteralPath $taskOutput){throw 'GUI ACL evidence already exists'}
$taskSid=[Security.Principal.WindowsIdentity]::GetCurrent().User
$taskRows=@();$taskDescriptors=@{'vault-directory'=@();'account-manifest'=@();'account-config'=@()}
foreach($group in @('legacy100','windowless100','windowless5000','legacy5000')){
 $report=Get-Content -LiteralPath (Join-Path $taskExpected ($group+'\native-perf-sdk-journey-results.json')) -Raw -Encoding utf8 | ConvertFrom-Json
 $review=Get-Content -LiteralPath (Join-Path $taskExpected ($group+'-actual-auth-review.json')) -Raw -Encoding utf8 | ConvertFrom-Json
 $checkpointName=if($group.StartsWith('legacy')){'baseline-build-checkpoint.json'}else{'build-checkpoint.json'}
 $build=Get-Content -LiteralPath (Join-Path $taskExpected $checkpointName) -Raw -Encoding utf8 | ConvertFrom-Json
 if(-not $report.success -or -not $report.sourceUnchanged -or $report.samplesRequested -ne 3 -or $report.samples.Count -ne 3 -or $report.exeSha256 -ne $build.sha256 -or -not $review.success -or $review.wholeSamples -ne 3 -or (Get-FileHash -LiteralPath $build.exe -Algorithm SHA256).Hash.ToLowerInvariant() -ne $build.sha256){throw 'Frozen complete GUI group missing'}
 $count=if($group.EndsWith('5000')){5000}else{100}
 foreach($sample in $report.samples){
  if(-not $sample.success -or -not $sample.cleanupIntegrity.complete -or -not $sample.nativeProof.success -or $sample.nativeProof.phases.Count -ne 6){throw 'Complete native GUI sample missing'}
  $root=Join-Path $taskExpected ($group+'\sample-'+([int]$sample.index).ToString('000'))
  if(-not(TaskSame $sample.root $root)){throw 'Unexpected sample root'}
  TaskOrdinary $root $true
  $owned=Get-Content -LiteralPath (Join-Path $root 'native-perf-owned.json') -Raw -Encoding utf8 | ConvertFrom-Json
  $vault=Join-Path $root 'vault'
  if($owned.schemaVersion -ne 1 -or $owned.scope -ne 'windows-native-perf-owned' -or -not $owned.nativePerfFeature -or $owned.preparationStatus -ne 'ready' -or $owned.runId -notmatch '^[a-f0-9]{32}$' -or $owned.runId -ne $sample.nativeProof.runId -or -not(TaskSame $owned.root $root) -or -not(TaskSame $owned.vault $vault) -or $owned.fixture.accountId -ne ('acc_rf312_'+$count) -or $owned.fixture.objectCount -ne $count){throw 'Owned synthetic Vault identity changed'}
  $targets=@([ordered]@{kind='vault-directory';path=$vault;directory=$true;protected=$true;inherited=$false;inheritance=3},[ordered]@{kind='account-manifest';path=(Join-Path $vault 'accounts.json');directory=$false;protected=$true;inherited=$false;inheritance=0},[ordered]@{kind='account-config';path=(Join-Path $vault ($owned.fixture.accountId+'\config.json'));directory=$false;protected=$false;inherited=$true;inheritance=0})
  foreach($target in $targets){
   TaskOrdinary $target.path $target.directory
   $beforeHash=if($target.directory){$null}else{(Get-FileHash -LiteralPath $target.path -Algorithm SHA256).Hash.ToLowerInvariant()}
   $acl=Get-Acl -LiteralPath $target.path
   $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]))
   if($acl.AreAccessRulesProtected -ne $target.protected -or $rules.Count -ne 1 -or $rules[0].IsInherited -ne $target.inherited -or $rules[0].IdentityReference -ne $taskSid -or $rules[0].AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or $rules[0].FileSystemRights -ne [Security.AccessControl.FileSystemRights]::FullControl -or [int]$rules[0].InheritanceFlags -ne $target.inheritance -or $rules[0].PropagationFlags -ne [Security.AccessControl.PropagationFlags]::None){throw 'Production ACL contract differs from the observed unchanged baseline'}
   $descriptor=$acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]'Owner,Group,Access')
   $taskDescriptors[$target.kind]+=$descriptor
   $descriptorHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($descriptor))).ToLowerInvariant()
   if(-not $target.directory -and (Get-FileHash -LiteralPath $target.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $beforeHash){throw 'ACL observation changed file content'}
   $taskRows+=[ordered]@{group=$group;sample=[int]$sample.index;runId=$owned.runId;kind=$target.kind;protected=$acl.AreAccessRulesProtected;inherited=$rules[0].IsInherited;currentUserFullControlOnly=$true;ownerCurrentUser=($acl.GetOwner([Security.Principal.SecurityIdentifier]) -eq $taskSid);inheritanceFlags=[int]$rules[0].InheritanceFlags;securityDescriptorSha256=$descriptorHash;contentSha256=$beforeHash}
  }
 }
}
foreach($kind in $taskDescriptors.Keys){if($taskDescriptors[$kind].Count -ne 12 -or @($taskDescriptors[$kind]|Sort-Object -Unique).Count -ne 1){throw ('Complete owner/group/DACL descriptors differ by role: '+$kind)}}
$result=[ordered]@{at=[DateTime]::UtcNow.ToString('o');success=$true;wholeGroups=4;wholeSamples=12;descriptorsChecked=$taskRows.Count;privateDescriptorsChecked=24;inheritedConfigDescriptorsChecked=12;ownerGroupAndDaclIdenticalByRole=$true;ownerCurrentUserObservedNotRequired=$true;rawSidOrSddlRecorded=$false;fileContentsUnchanged=$true;records=$taskRows}
[IO.File]::WriteAllText($taskOutput,($result|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
Write-Output '36 real GUI ACL descriptors verified equal by role across both executables and dataset sizes'
