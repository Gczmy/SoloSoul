from pathlib import Path
import json,hashlib,subprocess,sys,os,time,datetime
s=Path(__file__).parent;r=Path(r'C:\Users\40299571\SoloSoul')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def new(name,value):
 p=s/name;assert not p.exists(),name;p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+chr(10),encoding='utf-8',newline=chr(10))
def extract(t,name,windows=False):
 at=t.index('fn '+name+'(',t.index('#[cfg(windows)]'+chr(10)+'fn '+name)) if windows else t.index('fn '+name+'(')
 begin=t.index('{',at);depth=0;quoted=None;escape=False
 for i in range(begin,len(t)):
  c=t[i]
  if quoted:
   if escape:escape=False
   elif c==chr(92):escape=True
   elif c==quoted:quoted=None
   continue
  if c in [chr(34),chr(39)]:quoted=c;continue
  if c=='{':depth+=1
  elif c=='}':
   depth-=1
   if depth==0:return t[at:i+1]
 raise AssertionError('Unclosed extracted production function')
current=r/'tauri/crates/solosoul-core/src/vault_service/mod.rs';before=s/'before/tauri/crates/solosoul-core/src/vault_service/mod.rs'
expected=json.loads((s/'source-freeze.json').read_text())['files']['tauri/crates/solosoul-core/src/vault_service/mod.rs'];assert sha(current)==expected
base=s/'default-contract';assert not base.exists();base.mkdir()
record={'at':now(),'scope':'actual default-feature-disabled production helper before/after parity','beforeSourceSha256':sha(before),'afterSourceSha256':sha(current),'featureEnabled':False,'sourceFunctionsExtractedVerbatim':True,'processStdoutOrStderrCaptured':False,'casesArePublicFixtures':True,'variants':{}}
for variant,source in [('before',before),('after',current)]:
 text=source.read_text(encoding='utf-8');functions=(chr(10)*2).join([extract(text,'sanitize_windows_username'),extract(text,'set_private_dir',True),extract(text,'set_private_file',True)])
 root=base/variant;exe=base/(variant+'.exe');rust=base/(variant+'.rs')
 header=chr(10).join(['#![windows_subsystem="windows"]','use std::path::Path;','use std::os::windows::process::CommandExt;','const CREATE_NO_WINDOW:u32=0x08000000;',''])
 main=r'''
#[repr(C)] struct FileTime { low:u32, high:u32 }
#[link(name="kernel32")] extern "system" {
 fn GetConsoleWindow()->isize;
 fn GetCurrentProcess()->isize;
 fn GetProcessTimes(handle:isize,c:*mut FileTime,e:*mut FileTime,k:*mut FileTime,u:*mut FileTime)->i32;
}
fn main() {
 let root=std::path::PathBuf::from(std::env::args().nth(1).expect("owned public root"));
 assert_eq!(root,std::path::PathBuf::from(EXPECTED_ROOT));assert!(!root.exists());
 std::fs::create_dir(&root).unwrap();let private=root.join("private");std::fs::create_dir(&private).unwrap();let file=private.join("public.json");std::fs::write(&file,[91_u8,93,10]).unwrap();
 let normalize=|outcome:Result<(),String>|match outcome {Ok(())=>"ok".to_string(),Err(error)=>error.replace(root.to_str().unwrap(),"<fixture-root>")};
 let mut rows=Vec::new();rows.push(("directory-success",normalize(set_private_dir(&private))));rows.push(("file-success",normalize(set_private_file(&file))));
 rows.push(("missing-directory",normalize(set_private_dir(&root.join("missing-directory")))));rows.push(("missing-file",normalize(set_private_file(&root.join("missing-file")))));
 let username=std::env::var_os("USERNAME").expect("existing Windows test user");
 std::env::set_var("USERNAME","");rows.push(("empty-username",normalize(set_private_file(&file))));
 std::env::set_var("USERNAME","invalid/fixture-user");rows.push(("invalid-username",normalize(set_private_file(&file))));
 std::env::remove_var("USERNAME");rows.push(("missing-username",normalize(set_private_file(&file))));std::env::set_var("USERNAME",username);
 let mut csv=String::new();for (name,result) in rows {assert!(!result.contains(char::from(10)) && !result.contains(char::from(9)));csv.push_str(name);csv.push(char::from(9));csv.push_str(&result);csv.push(char::from(10));}
 std::fs::write(root.join("results.tsv"),csv).unwrap();
 let (mut c,mut e,mut k,mut u)=(FileTime{low:0,high:0},FileTime{low:0,high:0},FileTime{low:0,high:0},FileTime{low:0,high:0});
 assert_ne!(unsafe{GetProcessTimes(GetCurrentProcess(),&mut c,&mut e,&mut k,&mut u)},0);
 let birth=((c.high as u64)<<32)|c.low as u64;let console=unsafe{GetConsoleWindow()};assert_eq!(console,0);
 std::fs::write(root.join("identity.json"),format!(r#"{{"pid":{},"birthFileTime":{},"consoleWindowHandle":{},"defaultFeatureDisabled":true}}"#,std::process::id(),birth,console)).unwrap();
}
'''
 main=main.replace('EXPECTED_ROOT','r#"'+str(root)+'"#')
 rust.write_text(header+functions+chr(10)+main,encoding='utf-8',newline=chr(10))
 args=['rustc','--edition=2021','--crate-name','rf1097_default_'+variant,'--check-cfg','cfg(feature, values("native-perf"))','-C','opt-level=2','-o',str(exe),str(rust)]
 begin=time.monotonic();result=subprocess.run(args,cwd=r/'tauri',capture_output=True);(base/(variant+'-compile.stdout.log')).write_bytes(result.stdout);(base/(variant+'-compile.stderr.log')).write_bytes(result.stderr)
 new('default-'+variant+'-compile.receipt.json',dict(command=args,exitCode=result.returncode,elapsedSeconds=time.monotonic()-begin,at=now()))
 assert result.returncode==0,(variant,result.stderr.decode('utf-8',errors='replace')[-2500:])
 args=[str(exe),str(root)];begin=time.monotonic();proc=subprocess.Popen(args,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);pid=proc.pid;rc=proc.wait()
 new('default-'+variant+'-run.receipt.json',dict(command=args,pid=pid,exitCode=rc,elapsedSeconds=time.monotonic()-begin,at=now(),processStreamsCaptured=False));assert rc==0
 identity=json.loads((root/'identity.json').read_text());assert identity['pid']==pid and identity['consoleWindowHandle']==0 and identity['defaultFeatureDisabled']
 rows=dict(line.split(chr(9),1) for line in (root/'results.tsv').read_text().splitlines());assert len(rows)==7 and rows['directory-success']==rows['file-success']=='ok'
 for kind in ['missing-directory','missing-file']:assert rows[kind].startswith('icacls returned exit code Some(')
 assert rows['empty-username']=='Windows username is empty' and rows['invalid-username']=='Windows username contains invalid characters: invalid/fixture-user' and rows['missing-username']=='USERNAME environment variable not found'
 assert (root/'private/public.json').read_bytes()==bytes([91,93,10]) and not (root/'missing-file').exists() and not (root/'missing-directory').exists()
 record['variants'][variant]={'source':str(rust),'sourceSha256':sha(rust),'exe':str(exe),'exeSha256':sha(exe),'root':str(root),'identity':identity,'results':rows}
 print('Default production helper '+variant+' seven real cases passed',flush=True)
assert record['variants']['before']['results']==record['variants']['after']['results'];assert sha(current)==expected
record.update({'success':True,'allSevenCasesExactBeforeAfter':True,'publicContentsUnchanged':True,'aclEquivalenceNotYetVerified':True,'applicationPerformanceAccepted':False})
new('default-helper-parity.json',record);print('Default feature-disabled permission helper result parity passed; ACL verification pending',flush=True)
