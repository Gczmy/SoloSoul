from pathlib import Path
import subprocess,json,time,datetime,os,sys
s=Path(__file__).parent;r=Path(r'C:\Users\40299571\SoloSoul');load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
pwsh=r'C:\Users\40299571\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe';env=os.environ.copy();env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','');env.pop('PDFIUM_LIBRARY_PATH',None)
def step(name,command):
 for suffix in ['.stdout.log','.stderr.log','.live.json','.receipt.json']:assert not (s/(name+suffix)).exists(),name+suffix
 start=time.monotonic()
 with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(command,cwd=r,env=env,stdout=out,stderr=err)
  (s/(name+'.live.json')).write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':p.pid,'command':command},indent=2)+'\n',encoding='utf-8');print('Started '+name+' PID '+str(p.pid),flush=True);rc=p.wait()
 (s/(name+'.receipt.json')).write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':rc,'command':command,'elapsedSeconds':time.monotonic()-start},indent=2)+'\n',encoding='utf-8');print(name+' actual exit '+str(rc),flush=True)
 if rc:sys.exit(rc)
python=lambda name,*args:[sys.executable,'-X','utf8',str(s/name),*args]
assert load(s/'paired-build-result.json')['success']
step('whole-paired-gui',python('run-paired-permission-groups.py'))
assert load(s/'paired-groups-result.json')['success']
step('gui-acl-review',[pwsh,'-NoLogo','-NoProfile','-File',str(s/'verify-gui-acl-equivalence.ps1'),'-StageRoot',str(s)])
step('gui-permission-distributions',python('compare-gui-permission-stages.py'))
assert load(s/'gui-permission-comparison.json')['permissionStageReductionObserved'],'Actual regression must not be accepted'
from rf1097_acceptance_gate import acceptance,GROUPS
acceptance(cleanup=False)
for group in GROUPS:
 step(group+'-verified-cache-cleanup',[pwsh,'-NoLogo','-NoProfile','-File',str(s/'cleanup-windowless-caches.ps1'),'-StageRoot',str(s),'-GroupName',group])
 step(group+'-cache-preservation-review',python('review-post-cache-windowless.py',group))
acceptance()
step('raw-evidence-archive',python('archive-windowless-evidence.py'))
step('final-acceptance-documents',python('finalize-windowless-docs.py'))
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'wholeGuiGroups':4,'wholeSamples':12,'actualPermissionCommandsSucceeded':48,'fullAclDescriptors':36,'rawArchiveAndDocumentsPrepared':True,'committed':False,'pushed':False,'finalGitDiffAndLocalCommitStillRequired':True}
p=s/'gui-acceptance-pipeline-result.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print('Complete actual acceptance and documents prepared; final Git review and local commit remain',flush=True)