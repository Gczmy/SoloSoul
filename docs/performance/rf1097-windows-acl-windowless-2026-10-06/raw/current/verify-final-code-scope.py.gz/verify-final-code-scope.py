from pathlib import Path
import json,hashlib,subprocess,ast,datetime
s=Path(__file__).parent;r=Path(r'C:\Users\40299571\SoloSoul');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));git=['git','-c','safe.directory=C:/Users/40299571/SoloSoul','-c','core.autocrlf=false'];base=load(s/'before.json')['head'];assert subprocess.check_output(git+['rev-parse','HEAD'],cwd=r,text=True).strip()==base
expected={'tauri/crates/solosoul-core/src/vault_service/mod.rs','tauri/crates/solosoul-core/src/native_perf_unlock.rs','tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/src/native_perf/auth_trace.rs','tauri/src-tauri/src/native_perf/sdk_journey.rs'};changed=set(subprocess.check_output(git+['diff','--name-only','HEAD','--','tauri'],cwd=r,text=True).splitlines());assert changed==expected
untracked=set(subprocess.check_output(git+['ls-files','--others','--exclude-standard','--','tauri'],cwd=r,text=True).splitlines());assert untracked=={'tauri/src-tauri/src/native_perf/permission_contract.rs'}
assert not subprocess.check_output(git+['diff','--cached','--name-only'],cwd=r,text=True).strip()
mod='tauri/crates/solosoul-core/src/vault_service/mod.rs';old=subprocess.check_output(git+['show',base+':'+mod],cwd=r).decode('utf-8');current=(r/mod).read_text(encoding='utf-8')
helper=(s/'prove-default-permission-parity.py').read_text();tree=ast.parse(helper);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='extract');space={};exec(ast.get_source_segment(helper,node),space);extract=space['extract']
for name in ['sanitize_windows_username','set_private_dir','set_private_file']:
 assert extract(old,name)==extract(current,name),name+' non-Windows/sanitizer function changed'
reconstructed=current
for name in ['set_private_dir','set_private_file']:
 before=extract(old,name,True);after=extract(current,name,True);assert after.count('.creation_flags(CREATE_NO_WINDOW)')==1 and after.count('.inspect_err(|_|')==1
 assert before.count('.arg(')==after.count('.arg(')==4 and before.count('.status()')==after.count('.status()')==1
 for literal in ['.arg(path_str.as_ref())','.arg("/inheritance:r")','.arg("/grant")','"USERNAME environment variable not found"','"icacls failed to start: {e}"','"icacls returned exit code {:?} when setting permissions on {path_str}"']:
  assert before.count(literal)==after.count(literal)==1
 assert '.stdin(' not in after and '.stdout(' not in after and '.stderr(' not in after
 reconstructed=reconstructed.replace(after,before,1)
blocks=['#[cfg(windows)]\nuse std::os::windows::process::CommandExt;\n','// RF-1097：GUI 权限子进程不创建控制台，保留参数、标准流与退出状态检查。\n#[cfg(windows)]\nconst CREATE_NO_WINDOW: u32 = 0x08000000;\n\n']
for block in blocks:assert reconstructed.count(block)==1;reconstructed=reconstructed.replace(block,'',1)
marker='#[cfg(all(test, windows, feature = "native-perf"))]\nmod permission_outcome_tests {';assert reconstructed.count(marker)==1;reconstructed=reconstructed.split(marker)[0]
assert reconstructed.rstrip()==old.rstrip(),'Production module has an unrelated change outside the two Windows helpers'
core_lib=(r/'tauri/crates/solosoul-core/src/lib.rs').read_text();gui_lib=(r/'tauri/src-tauri/src/lib.rs').read_text();assert '#[cfg(feature = "native-perf")]\npub mod native_perf_unlock;' in core_lib and '#[cfg(all(feature = "native-perf", target_os = "windows"))]\nmod native_perf;' in gui_lib
for p in ['tauri/crates/solosoul-core/src/lib.rs','tauri/src-tauri/src/lib.rs','tauri/src-tauri/src/native_perf/auth_contract.rs','tauri/src-tauri/src/commands/auth.rs']:
 assert (r/p).read_bytes()==subprocess.check_output(git+['show',base+':'+p],cwd=r),p
for name in ['source-freeze.json','cli-source-freeze.json','frontend-freeze.json']:assert all(sha(r/p)==h for p,h in load(s/name)['files'].items()),name
assert load(s/'default-helper-parity.json')['success'] and load(s/'default-helper-acl-verification.json')['success']
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'baseCommit':base,'changedTrackedCodeFiles':sorted(changed),'addedNondefaultCodeFiles':sorted(untracked),'noStagedChanges':True,'productionModuleOutsideWindowsHelpersReconstructsBaseExactly':True,'usernameValidationAndUnixFunctionsByteExact':True,'windowsCommandArgumentsStatusAndInheritedStreamsUnchanged':True,'twoCreationFlagsCalls':2,'twoErrorOnlyInspectObservers':2,'defaultHelperSevenActualCasesAndFullAclPass':True,'newTraceAndValidatorCompileOnlyNondefaultWindowsFeature':True,'originalAuthContractAndLoginCommandByteExact':True,'dependencyOrFrontendChange':False,'actualApplicationAcceptanceStillPending':True};out=s/'final-code-scope-verification.json';assert not out.exists();out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print('Final code scope verified: original production module reconstructed except two Windows helpers; arguments/errors/Unix paths and original auth contract preserved; no dependency/frontend changes.')