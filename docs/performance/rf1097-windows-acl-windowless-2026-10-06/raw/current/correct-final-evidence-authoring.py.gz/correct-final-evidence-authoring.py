from pathlib import Path
import ast,shutil,json,datetime,hashlib
s=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf1097-permission-outcomes-v2-20261006');p=s/'prepare-final-evidence-tools.py'
old=p.read_text(encoding='utf-8-sig');new=old.replace("files['finalize-windowless-docs.py']=r'''",'files[\'finalize-windowless-docs.py\']=r"""',1)
closing="print('RF-1097 documents prepared from complete actual evidence',flush=True)\n'''\nfor name,body in files.items():"
assert old.count(closing)==1
new=new.replace(closing,"print('RF-1097 documents prepared from complete actual evidence',flush=True)\n\"\"\"\nfor name,body in files.items():",1)
ast.parse(new)
backup=s/'prepare-final-evidence-tools.authoring-v1.py';assert not backup.exists();shutil.copy2(p,backup);p.write_text(new,encoding='utf-8',newline='\n')
q=s/'final-evidence-authoring-correction.json';assert not q.exists();q.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalExitCode':1,'reason':'Nested Python string delimiter in temporary preparation script','correctedBeforeAnyPreparedScriptExecuted':True,'productionSourcesOrAcceptancePredicatesChanged':False,'originalSha256':hashlib.sha256(backup.read_bytes()).hexdigest(),'correctedSha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf-8',newline='\n')