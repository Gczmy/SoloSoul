from pathlib import Path
import json,datetime,hashlib
s=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf1097-permission-outcomes-v2-20261006');r=Path(r'C:\Users\40299571\SoloSoul');load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
receipt=load(s/'legacy-release.receipt.json');baseline=load(s/'baseline-build-checkpoint.json');live=load(s/'windowless-release.live.json')
assert receipt['exitCode']==0 and baseline['sameSafePermissionObserver'] and baseline['peSubsystem']=='Windows GUI'
assert hashlib.sha256(Path(baseline['exe']).read_bytes()).hexdigest()==baseline['sha256']
report_path=r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';assert 'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md' not in load(s/'source-freeze.json')['files']
text=report_path.read_text(encoding='utf-8-sig');old=next(line for line in text.splitlines() if line.startswith('- 当前处理：'))
assert 'RF-1097' in old and '277/287' in old
new='- 当前处理：**RF-1097：最终12项R/CLI检查与默认七种前后行为、四份ACL和源码范围复核通过；同安全观测设施的基线Release已exit 0并冻结，无窗口版本Release构建中。153份历史诊断压缩/解压字节复核通过。新的公开100/5000各三次整组、48次权限结果和36份ACL仍未验收；本项继续进行中、277/287及RF-112/121/312和RF-122～127前置保持，尚未提交或推送**。'
text=text.replace(old,new,1)
heading='### RF-1097 同观测设施配对构建检查点（2026-10-06）';assert heading not in text
text+='\n'+heading+'\n\n'
text+=f"- 基线Release实际exit 0，耗时{receipt['elapsedSeconds']:.2f}秒；独立冻结GUI EXE {baseline['bytes']}字节、SHA `{baseline['sha256']}`。包含本轮固定安全权限结果观测，与待验无窗口版本仅两处创建标志及导入/常量不同；最终候选源码已经逐字恢复。\n"
text+=f"- 第二版Release由同一串行构建脚本启动，PID {live['pid']}；尚无终态回执。12项R/CLI已通过，新的四组GUI与48次权限结果、36份ACL仍须实际执行，不能以构建成功代替。\n"
text+='- 原失败153份诊断档案的gzip及解压后长度/哈希全部复核；历史文件权限失败原因仍未知、原失败组不接纳。归档/报告脚本已更新并语法通过，缺少配对构建产物时实际拒绝提前验收，尚未运行最终归档或关闭。\n'
text+='- 保持277/287、RF-1097进行中及RF-112/121/312与RF-122～127前置，尚未提交或推送，goal active。\n'
report_path.write_text(text,encoding='utf-8',newline='\n')
p=s/'paired-build-report-checkpoint.json';assert not p.exists();p.write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'legacyReleaseExitCode':0,'legacyExeSha256':baseline['sha256'],'windowlessBuildPid':live['pid'],'fullApplicationAcceptanceClaimed':False,'reportSha256':hashlib.sha256(report_path.read_bytes()).hexdigest(),'productionSourceEdited':False,'committedOrPushed':False},indent=2)+'\n',encoding='utf-8',newline='\n')
print('Recorded actual baseline Release success without closing RF-1097')