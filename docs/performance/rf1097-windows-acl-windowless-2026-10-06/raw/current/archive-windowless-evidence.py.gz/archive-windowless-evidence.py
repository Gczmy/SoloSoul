from rf1097_acceptance_gate import *
import datetime,sys
sys.stdout.reconfigure(encoding='utf-8')
accepted=acceptance();dest=R/'docs/performance'/STEM;assert not dest.exists()
# Preserve the six final code inputs and the five tracked base inputs byte exactly.
scope=accepted['sourceScope'];paths=scope['changedTrackedCodeFiles']+scope['addedNondefaultCodeFiles']
for rel in paths:
 current=S/'current-sources'/rel;assert not current.exists();current.parent.mkdir(parents=True,exist_ok=True);current.write_bytes((R/rel).read_bytes())
 if rel in scope['changedTrackedCodeFiles']:
  base=S/'baseline-sources'/rel;assert not base.exists();base.parent.mkdir(parents=True,exist_ok=True);base.write_bytes(git('show','HEAD:'+rel))
entries=[]
def include(p,label,root):
 assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(root.resolve())
 entries.append((p,label+'/'+p.relative_to(root).as_posix()))
def top(root,label):
 for p in root.iterdir():
  if p.is_file() and p.suffix in ('.py','.ps1','.json','.md','.log','.rs','.csv','.marker'):include(p,label,root)
def whole_group(root,label):
 top(root,label)
 for sample in sorted(root.glob('sample-*')):
  if sample.is_file():continue
  assert sample.is_dir() and not sample.is_symlink()
  for p in sample.iterdir():
   if p.is_file() and p.suffix in ('.json','.log','.png'):include(p,label,root)
  logs=sample/'preserved-app-logs'
  if logs.exists():
   for p in logs.rglob('*'):
    if p.is_file():include(p,label,root)
def evidence_tree(root,label):
 if not root.exists():return
 for p in root.rglob('*'):
  if p.is_file() and p.suffix in ('.py','.ps1','.json','.md','.log','.rs','.csv','.marker'):include(p,label,root)
top(S,'current');top(V1,'first-observer-checks');top(OLD,'original-gui-and-diagnostic');top(CONTROL,'independent-mechanism')
for group in GROUPS:
 whole_group(S/group,'current/'+group);whole_group(OLD/group,'original-gui-and-diagnostic/'+group)
for name in ('before','default-contract','variant-source','baseline-sources','current-sources'):evidence_tree(S/name,'current/'+name)
for name in ('before','default-contract'):evidence_tree(V1/name,'first-observer-checks/'+name)
for p in CONTROL.glob('workloads/*/accounts.json'):include(p,'independent-mechanism',CONTROL)
assert len(list(CONTROL.glob('workloads/*/accounts.json')))==12
# The earlier 153 archives are verified and referenced, without duplicating their bytes.
reference=S/'historical-diagnostic-archive-reference.json';assert not reference.exists();reference.write_text(json.dumps(accepted['historicalDiagnostic'],indent=2)+'\n',encoding='utf-8',newline='\n');include(reference,'current',S)
assert len(set(name for p,name in entries))==len(entries)
(dest/'raw').mkdir(parents=True);rows=[]
for p,name in sorted(entries,key=lambda x:x[1]):
 body=p.read_bytes();relative='raw/'+name+'.gz';archive=dest/relative;assert archive.resolve().is_relative_to(dest.resolve());archive.parent.mkdir(parents=True,exist_ok=True);data=gzip.compress(body,compresslevel=9,mtime=0);archive.write_bytes(data)
 assert gzip.decompress(archive.read_bytes())==body
 rows.append({'original':str(p),'archive':relative,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'archiveBytes':len(data),'archiveSha256':hashlib.sha256(data).hexdigest()})
index={'schemaVersion':2,'task':'RF-1097','scope':'owned-windows-acl-windowless-public-synthetic-only','baseCommit':load(S/'before.json')['head'],'historicalFailureAccepted':False,'historicalDiagnostic':accepted['historicalDiagnostic'],'files':rows}
(dest/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for row in rows:
 archive=dest/row['archive'];body=gzip.decompress(archive.read_bytes());assert sha(archive)==row['archiveSha256'] and len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'archives':len(rows),'originalBytes':sum(row['bytes'] for row in rows),'archiveBytes':sum(row['archiveBytes'] for row in rows),'allDecompressedBytesVerified':True,'originalFailureAndFirstClippyFailurePreserved':True,'historicalDiagnosticArchivesVerified':153,'allSixFinalCodeInputsAndFiveBaseInputsPreserved':True,'excluded':['EXEs','model/DLL binaries','GUI Vault physical files','cache trees'],'index':str(dest/'index.json')}
assert not (S/'raw-archive-review.json').exists();(S/'raw-archive-review.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(receipt),flush=True)
