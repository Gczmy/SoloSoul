import pathlib,json,hashlib
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify_sources(stage,repo):
 old_path=stage/'source-freeze.json';old=json.loads(old_path.read_text(encoding='utf-8-sig'))['files']
 correction=stage/'measurement-source-freeze.json'
 if not correction.exists():
  assert all(sha(repo/p)==h for p,h in old.items());return len(old)
 fresh=json.loads(correction.read_text(encoding='utf-8-sig'))
 allowed={'tauri/scripts/native-perf-auth-attribution.mjs','tauri/scripts/native-perf-auth-attribution.test.mjs'}
 assert fresh['originalSourceFreezeSha256']==sha(old_path)
 assert set(fresh['files'])==set(old) and set(fresh['changedExternalDriverInputs'])==allowed
 assert {p for p,h in old.items() if fresh['files'][p]!=h}==allowed and fresh['rustAndFrontendInputsChanged'] is False
 assert all(sha(repo/p)==h for p,h in old.items() if p not in allowed)
 assert all(sha(repo/p)==h for p,h in fresh['files'].items())
 assert fresh['frozenExeSha256']==json.loads((stage/'build-checkpoint.json').read_text(encoding='utf-8-sig'))['sha256']
 return len(old)
