from pathlib import Path
import importlib.util,json,copy,hashlib,datetime,sys
s=Path(__file__).parent;p=s/'review-permission-commands.py';spec=importlib.util.spec_from_file_location('rf1097_fixed_permission_reviewer',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
run='0123456789abcdef0123456789abcdef';pid=1234
back={'clockScope':'process-monotonic','atMs':10,'attempts':[]};commands=[]
for aid,offset in [(1,0),(2,4)]:
 stages=[]
 for token,kind in [(0,'directory'),(1,'file')]:
  start=offset+token*2;stages.append({'name':'account-'+('directory' if kind=='directory' else 'manifest')+'-permission','startedAtMs':start,'endedAtMs':start+1,'outcome':'completed'});commands.append({'attemptId':aid,'stageToken':token,'kind':kind,'atMs':start+0.5,'outcome':'success','exitCode':0,'osError':None})
 back['attempts'].append({'id':aid,'kind':'login','rootVerified':True,'stages':stages})
good={'schemaVersion':1,'scope':'windows-native-permission-commands','runId':run,'pid':pid,'clockScope':'process-monotonic','atMs':10,'valid':True,'invalidReasons':[],'maxCommands':64,'commands':commands}
assert m.validate(good,back,run,pid)['allFourActualCommandsSucceeded'];controls=m.negatives(good,back,run,pid);assert controls['malformedOrPrivateCasesRejected']==17 and controls['typedFailurePreservedAndNotAccepted']
fixed=[]
for outcome,code,os_code in [('exit-failure',5,None),('exit-failure',None,None),('spawn-error',None,5),('spawn-error',None,None),('username-unavailable',None,None),('invalid-username',None,None)]:
 value=copy.deepcopy(good);backend=copy.deepcopy(back);value['commands'][0].update(outcome=outcome,exitCode=code,osError=os_code);backend['attempts'][0]['stages'][0]['outcome']='interrupted';result=m.validate(value,backend,run,pid);assert result['contractValid'] and not result['allFourActualCommandsSucceeded'];fixed.append({'outcome':outcome,'exitCode':code,'osError':os_code,'contractValid':True,'wholeGroupMustBeRejected':True})
extra=0
for field,value in [('exitCode',False),('osError',True),('atMs',-1),('atMs',float('nan')),('kind','file'),('outcome','exit-failure')]:
 changed=copy.deepcopy(good);changed['commands'][0][field]=value
 try:m.validate(changed,back,run,pid)
 except ValueError:extra+=1
 else:raise AssertionError('Malformed numeric, role, or status accepted')
assert extra==6
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'success':True,'scope':'temporary independent permission proof validator, synthetic public controls only','reviewerSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'allControlsSynthetic':True,'newGuiRunOrExitStatusMeasurementClaimed':False,'fixturePositiveAccepted':True,'originalSeventeenNegativeControls':controls,'extraMalformedCasesRejected':extra,'sixFixedFailures':fixed,'originalAuthClockAndJourneyReviewerStillRequired':True,'oldFailedGroupAccepted':False};out=s/'independent-permission-review-controls.json';assert not out.exists();out.write_text(json.dumps(record,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8',newline='\n');print('Independent reviewer synthetic controls pass: 23 malformed cases rejected; six typed failures preserved and excluded from whole-group acceptance.',flush=True)