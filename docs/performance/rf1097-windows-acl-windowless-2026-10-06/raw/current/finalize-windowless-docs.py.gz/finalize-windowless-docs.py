from rf1097_acceptance_gate import *
import datetime,sys
sys.stdout.reconfigure(encoding='utf-8')
a=acceptance();d=R/'docs/performance';index=load(d/STEM/'index.json');archive=load(S/'raw-archive-review.json');assert archive['success'] and len(index['files'])==archive['archives']
for row in index['files']:
 p=d/STEM/row['archive'];body=gzip.decompress(p.read_bytes());assert sha(p)==row['archiveSha256'] and len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
comparison=a['comparison'];groups=[];totals={key:0 for key in ('vaultFilesUnchanged','topLevelArtifactsUnchanged','preservedLogs','recordedIdentitiesChecked','removedPrivateCachePaths','unlinkedPrivateCacheEntries')}
for group,count,version in [('legacy100',100,'legacy'),('windowless100',100,'windowless'),('windowless5000',5000,'windowless'),('legacy5000',5000,'legacy')]:
 auth=load(S/(group+'-actual-auth-review.json'));commands=load(S/(group+'-permission-commands-review.json'));post=load(S/(group+'-post-cache-review.json'))
 for key in totals:totals[key]+=post[key]
 groups.append({'name':group,'objectCount':count,'version':version,'wholeSamplesAccepted':3,'authReview':auth,'permissionCommandsReview':commands,'cleanup':post})
build=load(S/'build-checkpoint.json');baseline=load(S/'baseline-build-checkpoint.json')
result={'schemaVersion':2,'task':'RF-1097','scope':'windows-private-acl-no-console-acceptance','date':'2026-10-06','taskAcceptedForLocalCommit':True,'localCommitOnly':True,'pushed':False,'rf312TaskClosed':False,'oldHomeTimeoutRootCauseEstablished':False,'productionChanges':{'creationFlag':'CREATE_NO_WINDOW (0x08000000)','creationFlagCalls':2,'defaultErrorOnlyInspectObservers':2,'parametersOrInheritedStandardStreamsOrErrorPropagationChanged':False,'unixChanged':False,'dependenciesChanged':False,'frontendChanged':False},'nondefaultMeasurement':{'sameObserverInBothReleaseBuilds':True,'fixedNumericPermissionOutcomes':True,'permissionContractSeparateFromUnchangedAuthContract':True,'rawPathsUsernamesAndErrorTextRecorded':False},'sourceScope':a['sourceScope'],'baselineBuild':baseline,'windowlessBuild':build,'sourceFreeze':{'mainInputs':1315,'cliInputs':108,'frontendDistInputs':35,'mainSha256':sha(S/'source-freeze.json'),'cliSha256':sha(S/'cli-source-freeze.json'),'frontendSha256':sha(S/'frontend-freeze.json')},'checks':a['checks'],'testCounts':a['testCounts'],'defaultHelperParity':load(S/'default-helper-parity.json'),'defaultHelperAcl':load(S/'default-helper-acl-verification.json'),'permissionReviewSyntheticControls':load(S/'independent-permission-review-controls.json'),'actualPermissionCommandsSucceeded':48,'guiAcl':a['guiAcl'],'guiComparison':comparison,'groups':groups,'preservationTotals':totals,'controlledMechanism':a['controlledMechanism'],'historicalDiagnostic':a['historicalDiagnostic'],'firstObserverDefaultClippy':{'exitCode':101,'preservedAndFixedWithoutSuppressingLint':True},'unaffectedFrontendAndNode':{'reusedEvidence':'rf312-windows-account-write-attribution-2026-10-06.json','sha256':sha(d/'rf312-windows-account-write-attribution-2026-10-06.json'),'rerunClaimed':False},'rawArchive':{'index':STEM+'/index.json','files':len(index['files']),'allDecompressedBytesVerified':True},'remaining':['RF-312 intermittent home timeout','system sleep coverage','same-scope multiplatform distributions','RF-112 isolated macOS restore','RF-121 full native composition/accessibility matrix','RF-122 to RF-127 dependencies']}
text='''# RF-1097 Windows 私有权限命令无窗口启动验收

Windows GUI 登录和再次解锁会写入账户清单。前一阶段观察到目录和文件权限调用占账户写入耗时的99.74%～99.83%；本项给两处 `icacls` 添加 `CREATE_NO_WINDOW`。用户名校验、命令参数、标准流继承、退出状态与错误传播保持，Unix、前端和依赖未改。

原第一轮5000对象基线组的文件权限阶段失败，历史未记录退出类别，原因仍未知；该失败及限定诊断完整保留，不计作通过。本轮仅在非默认测试功能中增加固定安全类别和数字状态观测，两版Release使用同一设施。原认证契约、SDK/身份/时限门禁保持。每个完整样本要求两次认证的四次权限命令均实际成功。

100对象按旧→新、5000对象按新→旧，各版本各三次完整六阶段行程，共12个独立root/profile、48次实际权限命令，全部exit 0。辅助结果与同进程同认证阶段绑定，不跨失败组拼接样本。

## 实际 GUI 分布

每格为中位数 / P95，单位ms；n=3时P95为本组三次最大观测值。前后端时钟不相减，父子阶段不相加，不把同步状态写入作为React绘制。

| 阶段 | 100旧 | 100新 | 5000旧 | 5000新 |
| --- | ---: | ---: | ---: | ---: |
'''
for flow,title in [(1,'首次登录'),(2,'再次解锁')]:
 for metric,label in [('account-directory-permission','目录权限'),('account-manifest-permission','文件权限'),('account-write-call','账户写入父阶段'),('backend-attempt','后端登录调用'),('login-await','前端登录await'),('kdf','KDF')]:
  values=[]
  for dataset in comparison['datasets']:
   row=next(q for q in dataset['authenticationStageComparisons'] if q['name']=='flow'+str(flow)+':'+metric)
   for version in ('legacy','windowless'):
    value=row[version];values.append(f"{value['medianMs']:.2f} / {value['p95Ms']:.2f}")
  text+='| '+title+' '+label+' | '+' | '.join(values)+' |\n'
text+='''
两档数据、两次认证的目录/文件权限中位数及P95均降低。完整行程分布和每次原值见结构化证据；结论限定本机公开样本和当前带观测器构建，不外推系统冷启动、多端或无观测器净CPU时间，也未证明旧首页超时根因。

## 权限、检查与保全

12个GUI样本的Vault目录、账户清单和配置文件共36份完整owner/group/DACL按角色一致。目录及清单保持受保护的当前用户显式FullControl，配置保持原继承；SID/SDDL不入报告。此结论限定隔离样本，不证明清除了所有既存显式ACL。默认生产函数七种真实前后行为、四份完整ACL也已分别通过。

默认Rust1861、非默认原生105、核心观察器3、实际权限失败回归1、定向契约2、CLI336通过；定向契约含于非默认总数，未加总重复计数。默认Rust3项、CLI2项既有ignored保持，严格Clippy和格式检查通过。首轮默认Clippy exit101已保留，使用 `inspect_err` 修正，无lint抑制。F/WEB/Node明确复用同输入的前一已提交证据。

'''
text+=f"新EXE SHA-256 `{build['sha256']}`；同观测器旧EXE `{baseline['sha256']}`。1315主项目、108CLI、35dist输入及188资源副本、185公开源和以前构建冻结保持。\n\n"
text+=f"fresh身份核验后只清理{totals['removedPrivateCachePaths']}个owned缓存、解除{totals['unlinkedPrivateCacheEntries']}个核验链接；{totals['vaultFilesUnchanged']}个Vault文件、{totals['preservedLogs']}份日志和全部证明、新旧构建保留，缓存工具未终止进程。\n\n"
text+=f"[结构化验收]({STEM}.json)、[{len(index['files'])}份原件索引]({STEM}/index.json)、[原失败及限定诊断](RF-1097-windows-acl-exit-diagnostic.md)可复核。实现使用稳定的[CommandExt::creation_flags](https://doc.rust-lang.org/std/os/windows/process/trait.CommandExt.html)，标志语义见[Microsoft进程创建标志](https://learn.microsoft.com/en-us/windows/win32/procthread/process-creation-flags)。\n\n"
text+='按RF-1097独立本地提交，不推送。RF-312首页超时/睡眠/多端、RF-112/121及RF-122～127前置保持未完成，goal继续active。\n'
for p,body in [(d/(STEM+'.json'),json.dumps(result,ensure_ascii=False,indent=2)+'\n'),(d/'RF-1097-windows-acl-windowless.md',text)]:
 assert not p.exists();p.write_text(body,encoding='utf-8',newline='\n')
report_path=R/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';report=report_path.read_text(encoding='utf-8-sig');head,rest=report.split('## 4. 修复进度与执行索引',1);block,tail=rest.split('## 5.',1)
assert '**277 / 287**' in block and '进行中：1；待执行：6' in block
block=block.replace('**277 / 287**；实际修复（已关闭）：277','**278 / 287**；实际修复（已关闭）：278').replace('进行中：1；待执行：6','进行中：0；待执行：6')
row=next(line for line in block.splitlines() if '[RF-1097]' in line);assert '[~] 进行中' in row;block=block.replace(row,row.replace('[~] 进行中','[x] 完成'))
block=re.sub(r'- 当前处理：\*\*.*?\*\*。','- 当前处理：**RF-1097本机真实GUI权限/性能对照已验收；下一本地项为RF-312首页超时诊断及RF-121 Windows完整窗口合成。RF-112/121/312及RF-122～127前置保持未完成**。',block,count=1)
head=head.replace('RF-1097 Windows权限命令无窗口启动修复中','RF-1097 Windows权限命令无窗口启动修复完成')
report=head+'## 4. 修复进度与执行索引'+block+'## 5.'+tail
report+='\n### RF-1097 完整验收与关闭（2026-10-06）\n\n'
report+='- 生产两处icacls增加CREATE_NO_WINDOW，参数/标准流/错误传播及Unix保持；固定数字权限观测仅非默认测试启用，新旧Release共用。原第一轮GUI权限失败原因未知、限定诊断及首轮Clippy101完整保留，不计作通过。\n'
report+='- 最终12项R/CLI检查exit0，默认1861/非默认105/核心3/实际权限失败1/定向契约2/CLI336通过，定向契约不重复加总，既有ignored保持；默认七种前后实际行为、四份ACL及源码范围通过。1315主项目/108CLI/35dist输入和新旧资源/公开源/以前构建冻结。\n'
report+='- 新100旧→新、5000新→旧各三次完整六阶段，12个独立root/profile的48次权限命令全部exit0，原SDK/身份/时限门禁保持；36份owner/group/DACL按角色一致。两次认证目录/文件权限中位数与P95均降低，不外推旧首页超时根因或既存显式ACL。\n'
report+=f"- fresh身份核验后仅清理{totals['removedPrivateCachePaths']}个owned缓存、解除{totals['unlinkedPrivateCacheEntries']}个核验链接；{totals['vaultFilesUnchanged']}个Vault文件、{totals['preservedLogs']}份日志及全部证明/构建保留，缓存工具未终止进程。\n"
report+=f"- [复跑与分布](performance/RF-1097-windows-acl-windowless.md)、[结构化证据](performance/{STEM}.json)及[{len(index['files'])}份原件](performance/{STEM}/index.json)归档。按RF-1097独立本地提交，不推送；278/287关闭、3待验证、6待执行。RF-112/121/312及RF-122～127前置不解除，goal active。\n"
report_path.write_text(report,encoding='utf-8',newline='\n');print('RF-1097 documents prepared from complete actual evidence',flush=True)
