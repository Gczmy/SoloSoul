import sys,json,datetime
from pathlib import Path
s=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf1097-permission-outcomes-v2-20261006');sys.path.insert(0,str(s))
from rf1097_acceptance_gate import verify_diagnostic_archive,acceptance
verified=verify_diagnostic_archive()
try:acceptance()
except FileNotFoundError as exc:
 assert Path(exc.filename)==s/'paired-build-result.json';pending='paired-build-result.json'
else:raise AssertionError('Incomplete actual build must not be accepted')
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'historicalDiagnostic':verified,'finalGateRejectedMissingPairedBuild':True,'nextActualPrerequisite':pending,'actualGuiAcceptanceClaimed':False,'productionSourceEdited':False}
p=s/'final-evidence-preflight.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(result))