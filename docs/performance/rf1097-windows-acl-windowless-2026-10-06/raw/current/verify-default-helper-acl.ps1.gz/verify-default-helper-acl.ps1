$ErrorActionPreference = 'Stop'
$stage = 'C:\Users\40299571\AppData\Local\Temp\ss-rf1097-permission-outcomes-v2-20261006'
$proof = Get-Content -LiteralPath (Join-Path $stage 'default-helper-parity.json') -Raw -Encoding utf8 | ConvertFrom-Json
if (!$proof.success -or !$proof.allSevenCasesExactBeforeAfter -or $proof.featureEnabled) { throw 'Actual default helper parity prerequisite failed' }
$currentSid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
function HashText([string]$value) { [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($value))).ToLowerInvariant() }
$rows = @(); $byRole = @{}; $terminals = @(); $peRows = @()
foreach ($variant in @('before', 'after')) {
  $data = $proof.variants.$variant
  $ownedRoot = [IO.Path]::GetFullPath($data.root)
  $expectedRoot = Join-Path $stage ('default-contract\' + $variant)
  if ($ownedRoot -cne $expectedRoot) { throw 'Unexpected fixture root' }
  if ((Get-FileHash -LiteralPath $data.exe -Algorithm SHA256).Hash.ToLowerInvariant() -cne $data.exeSha256) { throw 'Frozen executable changed' }
  if ((Get-FileHash -LiteralPath $data.source -Algorithm SHA256).Hash.ToLowerInvariant() -cne $data.sourceSha256) { throw 'Frozen extracted source changed' }
  $bytes = [IO.File]::ReadAllBytes($data.exe)
  if ($bytes[0] -ne 77 -or $bytes[1] -ne 90) { throw 'Missing DOS PE header' }
  $peOffset = [BitConverter]::ToInt32($bytes, 60)
  if ([BitConverter]::ToUInt32($bytes, $peOffset) -ne 17744) { throw 'Missing PE signature' }
  $machine = [BitConverter]::ToUInt16($bytes, $peOffset + 4)
  $optionalMagic = [BitConverter]::ToUInt16($bytes, $peOffset + 24)
  $subsystem = [BitConverter]::ToUInt16($bytes, $peOffset + 24 + 68)
  if ($machine -ne 34404 -or $optionalMagic -ne 523 -or $subsystem -ne 2) { throw 'Probe must be AMD64 Windows GUI PE' }
  $peRows += [ordered]@{ variant=$variant; sha256=$data.exeSha256; machine='AMD64'; optionalHeader='PE32+'; subsystem='Windows GUI'; actualParentConsoleHandle=$data.identity.consoleWindowHandle }
  foreach ($role in @('directory','file')) {
    $target = if ($role -eq 'directory') { Join-Path $ownedRoot 'private' } else { Join-Path $ownedRoot 'private\public.json' }
    $acl = Get-Acl -LiteralPath $target
    $rules = @($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]))
    if (!$acl.AreAccessRulesProtected -or $rules.Count -ne 1) { throw 'Expected protected one-entry DACL' }
    $rule = $rules[0]
    $expectedInheritance = if ($role -eq 'directory') { 3 } else { 0 }
    if ($acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -cne $currentSid -or $rule.IdentityReference.Value -cne $currentSid -or $rule.IsInherited -or [int]$rule.AccessControlType -ne 0 -or [int]$rule.FileSystemRights -ne 2032127 -or [int]$rule.InheritanceFlags -ne $expectedInheritance -or [int]$rule.PropagationFlags -ne 0) { throw 'Expected explicit current-user-only FullControl descriptor' }
    $sections = [Security.AccessControl.AccessControlSections]::Owner -bor [Security.AccessControl.AccessControlSections]::Group -bor [Security.AccessControl.AccessControlSections]::Access
    $descriptor = $acl.GetSecurityDescriptorSddlForm($sections)
    if ($variant -eq 'before') { $byRole[$role] = $descriptor } elseif ($byRole[$role] -cne $descriptor) { throw 'Full owner/group/DACL descriptor differs across variants' }
    $rows += [ordered]@{ variant=$variant; role=$role; ownerIsCurrentUser=$true; protected=$true; explicitCurrentUserFullControlOnly=$true; accessEntryCount=$rules.Count; inheritanceFlags=[int]$rule.InheritanceFlags; propagationFlags=[int]$rule.PropagationFlags; fullOwnerGroupDaclSha256=(HashText $descriptor); rawSidOrSddlPublished=$false }
  }
  $content = [IO.File]::ReadAllBytes((Join-Path $ownedRoot 'private\public.json'))
  if ($content.Length -ne 3 -or $content[0] -ne 91 -or $content[1] -ne 93 -or $content[2] -ne 10) { throw 'Public fixture bytes changed' }
  if ((Test-Path -LiteralPath (Join-Path $ownedRoot 'missing-directory')) -or (Test-Path -LiteralPath (Join-Path $ownedRoot 'missing-file'))) { throw 'Missing failure target was created' }
  $observed = @(Get-CimInstance -ClassName Win32_Process -Filter ('ProcessId = ' + [int]$data.identity.pid))
  $sameIdentity = $false
  if ($observed.Count -gt 1) { throw 'Ambiguous process identity' }
  if ($observed.Count -eq 1) {
    $actualBirth = $observed[0].CreationDate.ToFileTimeUtc()
    $sameIdentity = [Math]::Abs($actualBirth - [long]$data.identity.birthFileTime) -le 10
  }
  if ($sameIdentity) { throw 'Recorded default probe is still live' }
  $terminals += [ordered]@{variant=$variant; recordedPid=[int]$data.identity.pid; recordedBirthFileTime=[long]$data.identity.birthFileTime; freshCimAt=[DateTime]::UtcNow.ToString('o'); sameRecordedIdentityLive=$false; pidReusedByOtherIdentity=($observed.Count -eq 1)}
}
$result = [ordered]@{at=[DateTime]::UtcNow.ToString('o');success=$true;scope='seven actual default-feature-disabled production helper scenarios plus four full owner/group/DACL descriptors';allSevenCasesExactBeforeAfter=$true;fullOwnerGroupDaclEqualForBothRoles=$true;aclRows=$rows;peRows=$peRows;freshTerminalIdentities=$terminals;publicFixtureBytesUnchanged=$true;productionAclChangedByVerifier=$false;streamsCaptured=$false;defaultFeatureEnabled=$false;broaderApplicationPerformanceAccepted=$false}
$out = Join-Path $stage 'default-helper-acl-verification.json'
if (Test-Path -LiteralPath $out) { throw 'Refuse to overwrite proof result' }
[IO.File]::WriteAllText($out,($result|ConvertTo-Json -Depth 12)+[Environment]::NewLine,[Text.UTF8Encoding]::new($false))
Write-Output 'Default helper actual parity and four full ACL descriptor checks passed; recorded probe identities terminal.'