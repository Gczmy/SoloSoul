from pathlib import Path
import json,hashlib,subprocess,sys,os,time,datetime,shutil
sys.stdout.reconfigure(encoding='utf-8')
s=Path(__file__).parent;r=Path(r'C:\Users\40299571\SoloSoul');old=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf1097-acl-windowless-20261006')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def new(name,value):
 p=s/name;assert not p.exists(),name;p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
mod='tauri/crates/solosoul-core/src/vault_service/mod.rs';candidate=(r/mod).read_bytes();candidate_files=load(s/'source-freeze.json')['files']
assert sha(r/mod)==candidate_files[mod]
legacy=candidate
removed=[]
for block,count in [(b'#[cfg(windows)]\nuse std::os::windows::process::CommandExt;\n',1),('// RF-1097：GUI 权限子进程不创建控制台，保留参数、标准流与退出状态检查。\n#[cfg(windows)]\nconst CREATE_NO_WINDOW: u32 = 0x08000000;\n\n'.encode(),1),(b'        .creation_flags(CREATE_NO_WINDOW)\n',2)]:
 assert legacy.count(block)==count;legacy=legacy.replace(block,b'');removed.append({'sha256':hashlib.sha256(block).hexdigest(),'occurrences':count})
assert b'CREATE_NO_WINDOW' not in legacy and candidate!=legacy
legacy_files=dict(candidate_files);legacy_files[mod]=hashlib.sha256(legacy).hexdigest()
def verify(files):
 assert len(files)==1315 and all(sha(r/p)==h for p,h in files.items()),'Frozen main source changed'
 for name in ['cli-source-freeze.json','frontend-freeze.json']:assert all(sha(r/p)==h for p,h in load(s/name)['files'].items()),name
 for name in ['previous-public-source-freeze.json','previous-previous-build-freeze.json']:assert all(sha(Path(p))==h for p,h in load(s/name)['files'].items()),name
 for v in load(s/'previous-resource-freeze.json')['records']:assert sha(Path(v['source']))==v['sha256']==sha(Path(v['copy']))
 assert subprocess.check_output(['git','-c','safe.directory=C:/Users/40299571/SoloSoul','rev-parse','HEAD'],cwd=r,text=True).strip()==load(s/'before.json')['head']
checks=load(s/'required-checks.json');assert checks['success'] and len(checks['checks'])==12 and all(v['exitCode']==0 for v in checks['checks'].values())
assert load(s/'default-helper-acl-verification.json')['success'];verify(candidate_files)
variant=s/'variant-source';variant.mkdir();(variant/'windowless-mod.rs').write_bytes(candidate);(variant/'legacy-mod.rs').write_bytes(legacy)
new('legacy-source-freeze.json',{'at':now(),'files':legacy_files,'candidateFreezeSha256':sha(s/'source-freeze.json'),'onlyChangedFile':mod,'soleDifference':'the two CREATE_NO_WINDOW calls and their import/constant','permissionDiagnosticImplementationIdentical':True,'removedBlocks':removed})
resources=[];previous=load(s/'previous-previous-build-freeze.json')['files']
for checkpoint in ['build-checkpoint.json','baseline-build-checkpoint.json']:
 v=load(old/checkpoint);assert sha(Path(v['exe']))==v['sha256'];previous[v['exe']]=v['sha256']
new('previous-build-freeze.json',{'at':now(),'files':previous});new('public-source-freeze.json',load(s/'previous-public-source-freeze.json'))
source_resources=[v for v in load(s/'previous-resource-freeze.json')['records'] if v['relativePath'].startswith('bin/')];assert len(source_resources)==94
for folder in ['bin','baseline-bin']:
 (s/folder).mkdir()
 for v in source_resources:
  relative=Path(v['relativePath']).relative_to('bin');source=Path(v['copy']);copy=s/folder/relative;assert copy.resolve().is_relative_to((s/folder).resolve()) and not source.is_symlink()
  copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,copy);assert sha(copy)==v['sha256'];resources.append({'relativePath':(Path(folder)/relative).as_posix(),'source':str(source),'copy':str(copy),'sha256':v['sha256']})
new('resource-freeze.json',{'at':now(),'records':resources})
def verify_external():
 assert all(sha(Path(p))==h for p,h in previous.items())
 assert all(sha(Path(v['source']))==v['sha256']==sha(Path(v['copy'])) for v in resources)
args=['cargo','build','--locked','--release','-p','solo_soul','--features','native-perf','--bin','solo_soul'];env=os.environ.copy();env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','');env['CARGO_BUILD_JOBS']='2';env.pop('PDFIUM_LIBRARY_PATH',None)
markers=['windows-native-auth-attribution','windows-native-permission-commands','account-manifest-serialize','account-directory-create','account-directory-permission','account-manifest-atomic-write','account-manifest-permission']
for name,folder,files,contents,freeze,checkpoint in [('legacy','baseline-bin',legacy_files,legacy,'legacy-source-freeze.json','baseline-build-checkpoint.json'),('windowless','bin',candidate_files,candidate,'source-freeze.json','build-checkpoint.json')]:
 assert (r/mod).read_bytes()==candidate,'Candidate source must be restored between builds'
 try:
  (r/mod).write_bytes(contents);verify(files);verify_external();begin=time.monotonic()
  with (s/(name+'-release.stdout.log')).open('xb') as out,(s/(name+'-release.stderr.log')).open('xb') as err:
   process=subprocess.Popen(args,cwd=r/'tauri',env=env,stdout=out,stderr=err);new(name+'-release.live.json',{'command':args,'pid':process.pid,'at':now(),'sourceFreezeSha256':sha(s/freeze)});print('Started paired '+name+' Release PID '+str(process.pid),flush=True);code=process.wait()
  new(name+'-release.receipt.json',{'command':args,'pid':process.pid,'exitCode':code,'elapsedSeconds':time.monotonic()-begin,'at':now(),'sourceFreezeSha256':sha(s/freeze),'jobs':2,'pdfiumEnvironmentOverrideRemoved':True});print(name+' Release exit '+str(code),flush=True)
  assert code==0,name+' actual release failure retained'
  verify(files);verify_external();exe=s/folder/'solo_soul.exe';assert not exe.exists();shutil.copy2(r/'tauri/target/release/solo_soul.exe',exe);binary=exe.read_bytes();assert all(marker.encode() in binary for marker in markers)
  pe=int.from_bytes(binary[60:64],'little');assert binary[pe:pe+4]==b'PE\x00\x00' and int.from_bytes(binary[pe+4:pe+6],'little')==0x8664 and int.from_bytes(binary[pe+24+68:pe+24+70],'little')==2
  new(checkpoint,{'at':now(),'exe':str(exe),'bytes':len(binary),'sha256':sha(exe),'sourceFreezeSha256':sha(s/freeze),'mainInputs':1315,'cliInputs':108,'frontendDistInputs':35,'resourceCopies':188,'markers':markers,'version':name,'sameSafePermissionObserver':True,'productionAclArgumentsOrErrorsChanged':False,'nativePerfFeatureOnly':True,'peSubsystem':'Windows GUI'})
 finally:
  actual=(r/mod).read_bytes();assert actual in (candidate,legacy),'Unrelated live source change must not be overwritten';(r/mod).write_bytes(candidate);verify(candidate_files)
verify(candidate_files);verify_external();baseline=load(s/'baseline-build-checkpoint.json');fresh=load(s/'build-checkpoint.json');assert baseline['sha256']!=fresh['sha256']
new('paired-build-result.json',{'at':now(),'success':True,'legacy':baseline,'windowless':fresh,'candidateSourceRestoredByteExactly':True,'sameNondefaultMeasurementImplementation':True,'onlyCreationFlagsDiffer':True,'oldFailedGroupsAndBinariesPreserved':True,'applicationAcceptancePending':True});print('Both paired Release binaries frozen with identical safe permission observation; actual GUI groups remain required',flush=True)