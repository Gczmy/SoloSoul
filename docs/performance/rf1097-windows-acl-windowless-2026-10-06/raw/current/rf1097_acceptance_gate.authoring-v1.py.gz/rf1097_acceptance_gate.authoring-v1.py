from pathlib import Path
import json,hashlib,gzip,subprocess,re
from verify_auth_freezes import verify_sources
S=Path(__file__).parent
R=Path(r'C:\Users\40299571\SoloSoul')
OLD=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf1097-acl-windowless-20261006')
V1=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf1097-permission-outcomes-20261006')
CONTROL=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-acl-windowless-20261006')
GROUPS=('legacy100','windowless100','windowless5000','legacy5000')
STEM='rf1097-windows-acl-windowless-2026-10-06'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):
 return subprocess.check_output(['git','-c','safe.directory=C:/Users/40299571/SoloSoul',*args],cwd=R)
def verify_diagnostic_archive():
 d=R/'docs/performance';p=d/'rf1097-windows-acl-exit-diagnostic-2026-10-06.json'
 result=load(p);assert result['originalFailedGroupPreserved'] and not result['originalFailedGroupAccepted'] and not result['originalFailureRootCauseKnown']
 raw=OLD/'legacy5000/sample-001/native-perf-auth-attribution.json'
 assert sha(raw)==result['originalFailureRawSha256']
 index_path=d/result['rawIndex'];index=load(index_path);assert len(index['files'])==result['rawEntries']==153
 for row in index['files']:
  archive=index_path.parent/row['archive'];assert archive.resolve().is_relative_to(index_path.parent.resolve()) and not archive.is_symlink()
  data=archive.read_bytes();body=gzip.decompress(data)
  assert len(data)==row['archiveBytes'] and hashlib.sha256(data).hexdigest()==row['archiveSha256']
  assert len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
 return {'documentSha256':sha(p),'indexSha256':sha(index_path),'rawArchivesVerified':153,'originalFailureRawSha256':sha(raw),'originalFailedGroupAccepted':False,'historicalFailureCauseKnown':False}
def acceptance(cleanup=True):
 # All prerequisites are actual artifacts. Missing artifacts are a hard rejection.
 checks=load(S/'required-checks.json');assert checks['success'] and len(checks['checks'])==12
 for name,row in checks['checks'].items():
  assert row['exitCode']==0 and load(S/(name+'.receipt.json'))==row
 paired=load(S/'paired-build-result.json');assert paired['success'] and paired['candidateSourceRestoredByteExactly'] and paired['sameNondefaultMeasurementImplementation'] and paired['onlyCreationFlagsDiffer']
 for name in ('legacy','windowless'):assert load(S/(name+'-release.receipt.json'))['exitCode']==0
 whole=load(S/'paired-groups-result.json');assert whole['success'] and whole['wholeGroups']==4 and whole['wholeSamples']==12 and whole['actualPermissionCommandsSucceeded']==48 and not whole['oldFailureAccepted']
 comparison=load(S/'gui-permission-comparison.json');assert comparison['success'] and comparison['permissionStageReductionObserved'] and not comparison['oldHomeTimeoutRootCauseEstablished']
 acl=load(S/'gui-acl-equivalence.json');assert acl['success'] and acl['descriptorsChecked']==36
 assert verify_sources(S,R)==1315
 for name in ('cli-source-freeze.json','frontend-freeze.json'):assert all(sha(R/p)==h for p,h in load(S/name)['files'].items())
 for name in ('public-source-freeze.json','previous-build-freeze.json'):assert all(sha(Path(p))==h for p,h in load(S/name)['files'].items())
 for row in load(S/'resource-freeze.json')['records']:assert sha(Path(row['source']))==row['sha256']==sha(Path(row['copy']))
 for name in ('baseline-build-checkpoint.json','build-checkpoint.json'):
  b=load(S/name);assert b['sameSafePermissionObserver'] and sha(Path(b['exe']))==b['sha256'] and b['mainInputs']==1315
 assert git('rev-parse','HEAD').decode().strip()==load(S/'before.json')['head']
 assert not git('diff','--cached','--name-only').strip()
 preserved=load(S/'previous-git-preservation-before-rf1097.json')
 assert git('stash','list','--format=%H').decode().strip()==preserved['stashes']
 sub=R/'SoloSoul_plugin_market';subgit=lambda *args:subprocess.check_output(['git','-c','safe.directory='+str(sub).replace('\\','/'),*args],cwd=sub)
 assert subgit('rev-parse','HEAD').decode().strip()==preserved['submoduleHead'] and not subgit('status','--porcelain').strip()
 assert git('ls-tree','HEAD','SoloSoul_plugin_market').decode().strip()==preserved['submoduleTree']
 scope=load(S/'final-code-scope-verification.json');assert scope['success'] and scope['usernameValidationAndUnixFunctionsByteExact'] and scope['windowsCommandArgumentsStatusAndInheritedStreamsUnchanged'] and not scope['dependencyOrFrontendChange']
 assert load(S/'default-helper-acl-verification.json')['success']
 expected={'permission-default-tests':(1861,0,3),'permission-native-tests':(105,0,0),'permission-core-native-tests':(3,0,0),'permission-actual-failure':(1,0,0),'permission-contract-target':(2,0,0),'permission-cli-tests':(336,0,2)}
 counts={}
 for name,wanted in expected.items():
  rows=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (S/(name+'.stdout.log')).read_text(encoding='utf-8-sig'),re.M)
  assert rows and tuple(sum(int(row[i]) for row in rows) for i in range(3))==wanted
  counts[name]=dict(zip(('passed','failed','ignored'),wanted))
 commands=0
 for group in GROUPS:
  auth=load(S/(group+'-actual-auth-review.json'));permission=load(S/(group+'-permission-commands-review.json'));journey=load(S/group/'native-perf-sdk-journey-results.json')
  assert auth['success'] and auth['wholeSamples']==3 and journey['success'] and len(journey['samples'])==3 and all(row['success'] for row in journey['samples'])
  assert permission['success'] and permission['permissionResultsAccepted'] and len(permission['samples'])==3
  for row in permission['samples']:
   assert row['contractValid'] and row['allFourActualCommandsSucceeded'] and len(row['commands'])==4
   p=S/group/('sample-'+str(row['index']).zfill(3))/'native-perf-permission-commands.json';assert sha(p)==row['artifactSha256']
   assert all(cmd['outcome']=='success' and cmd['exitCode']==0 and cmd['osError'] is None for cmd in row['commands']);commands+=4
  if cleanup:assert load(S/(group+'-post-cache-review.json'))['success']
 assert commands==48
 original=load(OLD/'before.json');assert sha(CONTROL/'control-results.json')==original['controlEvidenceSha256']
 control=load(CONTROL/'control-results.json');assert control['success'] and not control['applicationPerformanceAccepted'] and control['callsSucceeded']==24 and control['pairedSamples']==6
 assert load(V1/'permission-default-clippy.receipt.json')['exitCode']==101
 diagnostic=verify_diagnostic_archive()
 return {'checks':checks,'testCounts':counts,'comparison':comparison,'guiAcl':acl,'sourceScope':scope,'historicalDiagnostic':diagnostic,'controlledMechanism':control,'actualPermissionCommandsSucceeded':commands}
