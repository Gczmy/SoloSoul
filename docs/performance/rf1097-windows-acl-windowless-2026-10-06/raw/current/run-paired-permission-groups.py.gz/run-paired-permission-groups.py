from pathlib import Path
import json,hashlib,subprocess,sys,os,time,datetime
from verify_auth_freezes import verify_sources
s=Path(__file__).parent;r=Path(r'C:\Users\40299571\SoloSoul');load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def new(name,value):
 p=s/name;assert not p.exists(),name;p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def verify():
 assert verify_sources(s,r)==1315
 for name in ['cli-source-freeze.json','frontend-freeze.json']:assert all(sha(r/p)==h for p,h in load(s/name)['files'].items()),name
 for name in ['public-source-freeze.json','previous-build-freeze.json']:assert all(sha(Path(p))==h for p,h in load(s/name)['files'].items()),name
 for row in load(s/'resource-freeze.json')['records']:assert sha(Path(row['source']))==row['sha256']==sha(Path(row['copy']))
 for name in ['baseline-build-checkpoint.json','build-checkpoint.json']:
  build=load(s/name);assert build['sameSafePermissionObserver'] and sha(Path(build['exe']))==build['sha256']
assert load(s/'paired-build-result.json')['success'] and load(s/'required-checks.json')['success'] and len(load(s/'required-checks.json')['checks'])==12
assert load(s/'default-helper-acl-verification.json')['success']
plans=[('legacy100',100,'baseline-build-checkpoint.json'),('windowless100',100,'build-checkpoint.json'),('windowless5000',5000,'build-checkpoint.json'),('legacy5000',5000,'baseline-build-checkpoint.json')]
new('paired-group-plan.json',{'at':now(),'groups':plans,'samplesPerWholeGroup':3,'oppositeVersionOrderAcrossObjectCounts':True,'originalFailedFourGroupsPreserved':True,'sameBoundedPermissionObserverInBothBuilds':True,'originalJourneyDriverAndAllBudgetsUnchanged':True,'pdfiumEnvironmentOverrideRemoved':True})
env=os.environ.copy();env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','');env.pop('PDFIUM_LIBRARY_PATH',None)
for group,count,checkpoint in plans:
 verify();build=load(s/checkpoint);output=s/group;assert not output.exists();fixture=Path(r'C:\Users\40299571\AppData\Local\Temp\solosoul-rf312-native-fixtures-20260930')/('vault'+str(count));args=['node','scripts/native-perf-auth-attribution.mjs','--exe',build['exe'],'--fixture',str(fixture),'--output',str(output),'--samples','3'];begin=time.monotonic()
 with (s/(group+'.stdout.log')).open('xb') as out,(s/(group+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(args,cwd=r/'tauri',env=env,stdout=out,stderr=err);new(group+'.live.json',{'command':args,'pid':p.pid,'at':now(),'exeSha256':build['sha256']});print('Started whole paired GUI '+group+' PID '+str(p.pid),flush=True);rc=p.wait()
 new(group+'.receipt.json',{'command':args,'pid':p.pid,'exitCode':rc,'elapsedSeconds':time.monotonic()-begin,'at':now(),'exeSha256':build['sha256'],'pdfiumEnvironmentOverrideRemoved':True});print(group+' actual whole GUI exit '+str(rc),flush=True);verify()
 # Auxiliary proof is reviewed even when the UI group fails; its failure remains a failure.
 args=[sys.executable,'-X','utf8',str(s/'review-permission-commands.py'),group];begin=time.monotonic();command_review=subprocess.run(args,capture_output=True)
 for kind,data in [('stdout',command_review.stdout),('stderr',command_review.stderr)]:
  q=s/(group+'-permission-review.'+kind+'.log');assert not q.exists();q.write_bytes(data)
 new(group+'-permission-review.receipt.json',{'command':args,'exitCode':command_review.returncode,'elapsedSeconds':time.monotonic()-begin,'at':now()});print(group+' separate fixed command proof exit '+str(command_review.returncode),flush=True)
 if rc or command_review.returncode:raise SystemExit(rc or command_review.returncode)
 args=[sys.executable,'-X','utf8',str(s/'review-windowless-auth.py'),group];begin=time.monotonic();review=subprocess.run(args,capture_output=True)
 for kind,data in [('stdout',review.stdout),('stderr',review.stderr)]:
  q=s/(group+'-auth-review.'+kind+'.log');assert not q.exists();q.write_bytes(data)
 new(group+'-auth-review.receipt.json',{'command':args,'exitCode':review.returncode,'elapsedSeconds':time.monotonic()-begin,'at':now(),'originalReviewScriptCopiedByteExactly':True});print(group+' original strict auth proof exit '+str(review.returncode),flush=True);verify()
 if review.returncode:raise SystemExit(review.returncode)
new('paired-groups-result.json',{'at':now(),'success':True,'wholeGroups':4,'wholeSamples':12,'actualPermissionCommandsSucceeded':48,'oppositeVersionOrderAcrossObjectCounts':True,'oldFailureAccepted':False,'originalSdkIdentityClockAndBudgetsPreserved':True,'guiAclComparisonStillRequired':True,'oldHomeTimeoutRootCauseEstablished':False});print('All four whole groups and both original plus auxiliary proofs pass; complete GUI ACL comparison still required',flush=True)