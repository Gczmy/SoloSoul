import pathlib,json,hashlib,subprocess,time,datetime,sys,struct,csv,statistics,math
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(__file__).parent;r=pathlib.Path(r'C:\Users\40299571\SoloSoul');pwsh=r'C:\Users\40299571\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(name,value):
 p=s/name;assert not p.exists(),str(p);p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(name,args):
 start=time.time()
 with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(args,cwd=s,stdin=subprocess.DEVNULL,stdout=out,stderr=err);write(name+'.live.json',{'command':args,'pid':p.pid,'at':now()});print(name+' PID '+str(p.pid),flush=True);rc=p.wait()
 receipt={'command':args,'pid':p.pid,'exitCode':rc,'elapsedSeconds':time.time()-start,'at':now()};write(name+'.receipt.json',receipt);print(name+' exit '+str(rc),flush=True)
 if rc:
  print((s/(name+'.stderr.log')).read_text(encoding='utf-8-sig',errors='replace')[-5000:]);raise SystemExit(rc)
 return receipt
inputs=load(s/'experiment-input.json');assert sha(pathlib.Path(inputs['productionFile']))==inputs['productionSha256'];assert inputs['baseCommit']=='ed23f897604eedd6cfe5d3f4afef9efc0cf9cf6e'
run('control-build',['rustc','--edition=2021','-O','--crate-name','acl_gui_control',str(s/'acl_gui_control.rs'),'-o',str(s/'acl_gui_control.exe')])
exe=s/'acl_gui_control.exe';data=exe.read_bytes();pe=struct.unpack_from('<I',data,0x3c)[0];assert data[pe:pe+4]==b'PE\0\0' and struct.unpack_from('<H',data,pe+4)[0]==0x8664
optional=pe+24;assert struct.unpack_from('<H',data,optional)[0]==0x20b;subsystem=struct.unpack_from('<H',data,optional+68)[0];assert subsystem==2
write('control-exe.json',{'sha256':sha(exe),'bytes':len(data),'machine':'AMD64','subsystem':subsystem,'subsystemName':'Windows GUI','sourceSha256':sha(s/'acl_gui_control.rs'),'productionChanged':False})
start=time.time()
with (s/'control-run.stdout.log').open('xb') as out,(s/'control-run.stderr.log').open('xb') as err:
 p=subprocess.Popen([str(exe)],cwd=s,stdin=subprocess.DEVNULL,stdout=out,stderr=err);write('control-run.live.json',{'pid':p.pid,'exe':str(exe),'at':now()});print('GUI control PID '+str(p.pid),flush=True)
 while not (s/'identity.json').exists():
  if p.poll() is not None:
   write('control-run.receipt.json',{'pid':p.pid,'exitCode':p.returncode,'elapsedSeconds':time.time()-start,'at':now(),'identityMissing':True});print((s/'control-run.stderr.log').read_text(encoding='utf-8-sig',errors='replace'));raise SystemExit(p.returncode or 1)
  time.sleep(.01)
 identity=load(s/'identity.json');assert identity['pid']==p.pid and identity['parentConsoleWindow']==0
 command="Get-CimInstance Win32_Process -Filter 'ProcessId="+str(p.pid)+"' -Property ProcessId,CreationDate,ExecutablePath,Name | Select-Object ProcessId,CreationDate,ExecutablePath,Name | ConvertTo-Json -Compress"
 raw=subprocess.check_output([pwsh,'-NoProfile','-Command',command],cwd=s);write('control-identity-observation.json',json.loads(raw.decode('utf-8-sig')))
 observation=load(s/'control-identity-observation.json');assert observation['ProcessId']==p.pid and observation['Name']=='acl_gui_control.exe' and pathlib.Path(observation['ExecutablePath']).resolve()==exe.resolve() and observation['CreationDate']
 with (s/'go.marker').open('xb') as f:f.write(b'go-owned-control-only\n')
 rc=p.wait();write('control-run.receipt.json',{'pid':p.pid,'exitCode':rc,'elapsedSeconds':time.time()-start,'at':now(),'parentConsoleWindow':0});print('GUI control exit '+str(rc),flush=True)
 if rc:print((s/'control-run.stderr.log').read_text(encoding='utf-8-sig',errors='replace'));raise SystemExit(rc)
assert (s/'complete.marker').read_bytes()==b'all-24-status-calls-returned-success\n'
run('control-acl',[pwsh,'-NoProfile','-File',str(s/'verify-acl-equivalence.ps1'),'-StageRoot',str(s)])
rows=list(csv.DictReader((s/'metrics.csv').open(encoding='utf-8-sig',newline='')));assert len(rows)==12 and all(q['exitCode']=='0' for q in rows)
expected=[(str(i),mode) for i in range(1,7) for mode in (['legacy','windowless'] if i%2 else ['windowless','legacy'])];assert [(q['pair'],q['mode']) for q in rows]==expected
summary=[];paired=[]
for mode in ['legacy','windowless']:
 for key in ['directoryMs','fileMs']:
  values=[float(q[key]) for q in rows if q['mode']==mode];assert len(values)==6 and all(math.isfinite(v) and v>=0 for v in values)
  summary.append({'mode':mode,'stage':key,'n':6,'medianMs':statistics.median(values),'p95Ms':max(values),'samplesMs':values})
for i in range(1,7):
 pair=[q for q in rows if q['pair']==str(i)];modes={q['mode']:q for q in pair};legacy=sum(float(modes['legacy'][k]) for k in ['directoryMs','fileMs']);fresh=sum(float(modes['windowless'][k]) for k in ['directoryMs','fileMs']);paired.append({'pair':i,'order':[q['mode'] for q in pair],'legacyPermissionCallsMs':legacy,'windowlessPermissionCallsMs':fresh,'reductionPercent':100*(legacy-fresh)/legacy})
files=[p for p in (s/'workloads').rglob('*') if p.is_file()];assert len(files)==12 and all(p.read_bytes()==b'[]\n' and not p.is_symlink() for p in files)
assert sha(pathlib.Path(inputs['productionFile']))==inputs['productionSha256']
final_command="Get-CimInstance Win32_Process -Filter 'ProcessId="+str(p.pid)+"' -Property ProcessId,CreationDate,Name | Select-Object ProcessId,CreationDate,Name | ConvertTo-Json -Compress"
raw=subprocess.check_output([pwsh,'-NoProfile','-Command',final_command],cwd=s).decode('utf-8-sig').strip();final=json.loads(raw) if raw else None
assert final is None or final['CreationDate']!=observation['CreationDate']
write('control-results.json',{'at':now(),'success':True,'scope':'mechanism-only Windows GUI parent paired ACL creation-flags','parentConsoleWindow':0,'productionChanged':False,'exe':load(s/'control-exe.json'),'processIdentity':observation,'finalIdentity':final,'callsSucceeded':24,'pairedSamples':6,'balancedOrder':True,'summary':summary,'pairs':paired,'acl':load(s/'acl-equivalence.json'),'fixtureFilesUnchanged':12,'applicationPerformanceAccepted':False,'oldHomeTimeoutRootCauseEstablished':False})
print(json.dumps({'callsSucceeded':24,'pairedSamples':6,'summary':summary,'pairedReductionsPercent':[q['reductionPercent'] for q in paired],'aclDescriptorsIdentical':True,'applicationPerformanceAccepted':False},ensure_ascii=False),flush=True)
