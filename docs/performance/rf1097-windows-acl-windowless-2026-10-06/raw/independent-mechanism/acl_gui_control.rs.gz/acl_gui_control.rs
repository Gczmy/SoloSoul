#![windows_subsystem = "windows"]
use std::path::Path;
use std::io::Write;
use std::os::windows::fs::MetadataExt;
use std::time::{Duration,Instant};
#[link(name="kernel32")]
extern "system" { fn GetConsoleWindow() -> isize; fn GetCurrentProcessId() -> u32; }
const ROOT: &str = r"C:\Users\40299571\AppData\Local\Temp\ss-rf312-acl-windowless-20261006";
fn write_new(p:&Path,bytes:&[u8])->Result<(),String>{std::fs::OpenOptions::new().write(true).create_new(true).open(p).and_then(|mut f|f.write_all(bytes)).map_err(|e|e.to_string())}
fn main()->Result<(),String>{
 let root=Path::new(ROOT);
 let meta=std::fs::symlink_metadata(root).map_err(|e|e.to_string())?;
 if !meta.is_dir() || meta.file_attributes() & 0x400 != 0 {return Err("Only the exact ordinary owned stage is allowed".into())}
 // 仅读取当前测试进程的控制台句柄与 PID，不操作其他窗口。
 let (console,pid)=unsafe{(GetConsoleWindow(),GetCurrentProcessId())};
 if console!=0{return Err("Benchmark GUI parent unexpectedly attached to console".into())}
 write_new(&root.join("identity.json"),format!("{{\"pid\":{pid},\"parentConsoleWindow\":{console},\"scope\":\"owned-gui-acl-creationflag-control\"}}\n").as_bytes())?;
 let wait=Instant::now();
 while !root.join("go.marker").exists(){if wait.elapsed()>Duration::from_secs(30){return Err("Controlled start marker timeout".into())}std::thread::sleep(Duration::from_millis(10));}
 let workloads=root.join("workloads");std::fs::create_dir(&workloads).map_err(|e|e.to_string())?;
 let mut output=String::from("pair,mode,directoryMs,fileMs,exitCode\n");
 for pair in 1..=6 {
  let modes=if pair%2==1{["legacy","windowless"]}else{["windowless","legacy"]};
  for mode in modes {
   let dir=workloads.join(format!("{mode}-{pair:03}"));std::fs::create_dir(&dir).map_err(|e|e.to_string())?;
   let before=Instant::now();if mode=="legacy"{legacy::directory(&dir)?}else{windowless::directory(&dir)?};let directory_ms=before.elapsed().as_secs_f64()*1000.0;
   let file=dir.join("accounts.json");write_new(&file,b"[]\n")?;
   let before=Instant::now();if mode=="legacy"{legacy::file(&file)?}else{windowless::file(&file)?};let file_ms=before.elapsed().as_secs_f64()*1000.0;
   output.push_str(&format!("{pair},{mode},{directory_ms:.9},{file_ms:.9},0\n"));
  }
 }
 if unsafe{GetConsoleWindow()}!=0{return Err("Benchmark console state changed".into())}
 write_new(&root.join("metrics.csv"),output.as_bytes())?;
 write_new(&root.join("complete.marker"),b"all-24-status-calls-returned-success\n")?;
 Ok(())
}

mod legacy { use std::path::Path;
#[cfg(windows)]
/// Validate Windows username to prevent icacls command injection.
/// Only allow characters valid in Windows usernames.
fn sanitize_windows_username(username: &str) -> Result<String, String> {
    if username.is_empty() {
        return Err("Windows username is empty".to_string());
    }
    if !username
        .chars()
        .all(|c| c.is_alphanumeric() || c == ' ' || c == '-' || c == '_' || c == '.')
    {
        return Err(format!(
            "Windows username contains invalid characters: {}",
            username
        ));
    }
    Ok(username.to_string())
}

#[cfg(windows)]
fn set_private_dir(path: &Path) -> Result<(), String> {
    let path_str = path.to_string_lossy();
    let username = std::env::var("USERNAME")
        .map_err(|_| "USERNAME environment variable not found".to_string())?;
    let username = sanitize_windows_username(&username)?;
    let status = std::process::Command::new("icacls")
        .arg(path_str.as_ref())
        .arg("/inheritance:r")
        .arg("/grant")
        .arg(format!("{username}:(OI)(CI)F"))
        .status()
        .map_err(|e| format!("icacls failed to start: {e}"))?;
    if !status.success() {
        return Err(format!(
            "icacls returned exit code {:?} when setting permissions on {path_str}",
            status.code()
        ));
    }
    Ok(())
}

#[cfg(windows)]
fn set_private_file(path: &Path) -> Result<(), String> {
    let path_str = path.to_string_lossy();
    let username = std::env::var("USERNAME")
        .map_err(|_| "USERNAME environment variable not found".to_string())?;
    let username = sanitize_windows_username(&username)?;
    let status = std::process::Command::new("icacls")
        .arg(path_str.as_ref())
        .arg("/inheritance:r")
        .arg("/grant")
        .arg(format!("{username}:F"))
        .status()
        .map_err(|e| format!("icacls failed to start: {e}"))?;
    if !status.success() {
        return Err(format!(
            "icacls returned exit code {:?} when setting permissions on {path_str}",
            status.code()
        ));
    }
    Ok(())
}
pub(super) fn directory(p: &Path) -> Result<(), String> { set_private_dir(p) }
pub(super) fn file(p: &Path) -> Result<(), String> { set_private_file(p) }
}
mod windowless { use std::path::Path; use std::os::windows::process::CommandExt;
#[cfg(windows)]
/// Validate Windows username to prevent icacls command injection.
/// Only allow characters valid in Windows usernames.
fn sanitize_windows_username(username: &str) -> Result<String, String> {
    if username.is_empty() {
        return Err("Windows username is empty".to_string());
    }
    if !username
        .chars()
        .all(|c| c.is_alphanumeric() || c == ' ' || c == '-' || c == '_' || c == '.')
    {
        return Err(format!(
            "Windows username contains invalid characters: {}",
            username
        ));
    }
    Ok(username.to_string())
}

#[cfg(windows)]
fn set_private_dir(path: &Path) -> Result<(), String> {
    let path_str = path.to_string_lossy();
    let username = std::env::var("USERNAME")
        .map_err(|_| "USERNAME environment variable not found".to_string())?;
    let username = sanitize_windows_username(&username)?;
    let status = std::process::Command::new("icacls").creation_flags(0x08000000)
        .arg(path_str.as_ref())
        .arg("/inheritance:r")
        .arg("/grant")
        .arg(format!("{username}:(OI)(CI)F"))
        .status()
        .map_err(|e| format!("icacls failed to start: {e}"))?;
    if !status.success() {
        return Err(format!(
            "icacls returned exit code {:?} when setting permissions on {path_str}",
            status.code()
        ));
    }
    Ok(())
}

#[cfg(windows)]
fn set_private_file(path: &Path) -> Result<(), String> {
    let path_str = path.to_string_lossy();
    let username = std::env::var("USERNAME")
        .map_err(|_| "USERNAME environment variable not found".to_string())?;
    let username = sanitize_windows_username(&username)?;
    let status = std::process::Command::new("icacls").creation_flags(0x08000000)
        .arg(path_str.as_ref())
        .arg("/inheritance:r")
        .arg("/grant")
        .arg(format!("{username}:F"))
        .status()
        .map_err(|e| format!("icacls failed to start: {e}"))?;
    if !status.success() {
        return Err(format!(
            "icacls returned exit code {:?} when setting permissions on {path_str}",
            status.code()
        ));
    }
    Ok(())
}
pub(super) fn directory(p: &Path) -> Result<(), String> { set_private_dir(p) }
pub(super) fn file(p: &Path) -> Result<(), String> { set_private_file(p) }
}
