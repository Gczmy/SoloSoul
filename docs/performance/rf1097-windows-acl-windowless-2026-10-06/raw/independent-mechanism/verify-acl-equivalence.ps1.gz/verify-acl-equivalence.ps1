#Requires -Version 7.0
param([Parameter(Mandatory=$true)][string]$StageRoot)
$ErrorActionPreference='Stop'
$taskExpected='C:\Users\40299571\AppData\Local\Temp\ss-rf312-acl-windowless-20261006'
$taskResolved=(Resolve-Path -LiteralPath $StageRoot).Path
if(-not [IO.Path]::GetFullPath($taskResolved).Equals($taskExpected,[StringComparison]::OrdinalIgnoreCase)){throw 'Only this exact control stage is allowed'}
$taskRoot=Get-Item -LiteralPath $taskResolved -Force
if(-not $taskRoot.PSIsContainer -or ($taskRoot.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Stage root is not ordinary'}
$taskBase=Join-Path $taskExpected 'workloads';$taskEntry=Get-Item -LiteralPath $taskBase -Force
if(-not $taskEntry.PSIsContainer -or ($taskEntry.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Workload root is not ordinary'}
$taskExpectedNames=@();foreach($pair in 1..6){foreach($mode in @('legacy','windowless')){$taskExpectedNames+=('{0}-{1:000}' -f $mode,$pair)}}
$taskChildren=@(Get-ChildItem -LiteralPath $taskBase -Force)
if($taskChildren.Count -ne 12 -or @($taskChildren|Where-Object{$_.Name -notin $taskExpectedNames}).Count -ne 0){throw 'Unexpected workload paths'}
$taskSid=[Security.Principal.WindowsIdentity]::GetCurrent().User
$taskRows=@();$taskDirectorySddl=@();$taskFileSddl=@()
foreach($child in $taskChildren){
 if(-not $child.PSIsContainer -or ($child.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Workload directory is not ordinary'}
 $entries=@(Get-ChildItem -LiteralPath $child.FullName -Force)
 if($entries.Count -ne 1 -or $entries[0].Name -ne 'accounts.json' -or $entries[0].PSIsContainer -or ($entries[0].Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Unexpected workload file'}
 foreach($kind in @('directory','file')){
  $path=if($kind -eq 'directory'){$child.FullName}else{$entries[0].FullName}
  $acl=Get-Acl -LiteralPath $path
  $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]))
  $expectedInheritance=if($kind -eq 'directory'){[Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit}else{[Security.AccessControl.InheritanceFlags]::None}
  if(-not $acl.AreAccessRulesProtected -or $rules.Count -ne 1 -or $rules[0].IsInherited -or $rules[0].IdentityReference -ne $taskSid -or $rules[0].AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or $rules[0].FileSystemRights -ne [Security.AccessControl.FileSystemRights]::FullControl -or $rules[0].InheritanceFlags -ne $expectedInheritance -or $rules[0].PropagationFlags -ne [Security.AccessControl.PropagationFlags]::None){throw 'Current-user private ACL contract not satisfied'}
  $sddl=$acl.GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]'Owner,Group,Access')
  if($kind -eq 'directory'){$taskDirectorySddl+=$sddl}else{$taskFileSddl+=$sddl}
  $hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($sddl))).ToLowerInvariant()
  $taskRows+=[ordered]@{sample=$child.Name;kind=$kind;protected=$true;explicitCurrentUserFullControlOnly=$true;ownerCurrentUser=($acl.GetOwner([Security.Principal.SecurityIdentifier]) -eq $taskSid);inheritanceFlags=[int]$rules[0].InheritanceFlags;securityDescriptorSha256=$hash}
 }
}
if(@($taskDirectorySddl|Sort-Object -Unique).Count -ne 1 -or @($taskFileSddl|Sort-Object -Unique).Count -ne 1){throw 'Security descriptors differ between default and no-window calls'}
$taskOutput=Join-Path $taskExpected 'acl-equivalence.json'
if(Test-Path -LiteralPath $taskOutput){throw 'ACL evidence already exists'}
$taskResult=[ordered]@{at=[DateTime]::UtcNow.ToString('o');success=$true;descriptorsChecked=24;directoryDescriptorsIdentical=$true;fileDescriptorsIdentical=$true;rawSidOrSddlRecorded=$false;records=$taskRows}
[IO.File]::WriteAllText($taskOutput,($taskResult|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
Write-Output '24 private ACL descriptors verified identical by target kind; no raw SID or SDDL recorded'
