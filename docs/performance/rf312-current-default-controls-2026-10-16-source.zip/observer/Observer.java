package org.solosoul.rf312observer;

import android.app.Activity;
import android.app.Instrumentation;
import android.app.UiAutomation;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Xml;
import android.view.accessibility.AccessibilityNodeInfo;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import org.xmlpull.v1.XmlSerializer;

/** Separate-package observer for the dedicated public-fixture emulator only. */
public final class Observer extends Instrumentation {
    private String token;
    private int nodes;

    @Override public void onCreate(Bundle arguments) {
        super.onCreate(arguments);
        token = arguments.getString("token", "");
        if (!token.matches("[a-f0-9]{32}")) throw new IllegalArgumentException("Invalid owned namespace");
        start();
    }

    private static void write(File file, String value) throws Exception {
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(value.getBytes(StandardCharsets.UTF_8));
        }
    }

    private void emit(XmlSerializer xml, AccessibilityNodeInfo node, int depth) throws Exception {
        if (depth > 200 || ++nodes > 5000) throw new IllegalStateException("Unexpected hierarchy size");
        xml.startTag(null, "node");
        xml.attribute(null, "package", String.valueOf(node.getPackageName()));
        xml.attribute(null, "class", String.valueOf(node.getClassName()));
        xml.attribute(null, "text", node.getText() == null ? "" : node.getText().toString());
        xml.attribute(null, "content-desc", node.getContentDescription() == null ? "" : node.getContentDescription().toString());
        xml.attribute(null, "password", String.valueOf(node.isPassword()));
        xml.attribute(null, "enabled", String.valueOf(node.isEnabled()));
        xml.attribute(null, "clickable", String.valueOf(node.isClickable()));
        xml.attribute(null, "focusable", String.valueOf(node.isFocusable()));
        xml.attribute(null, "focused", String.valueOf(node.isFocused()));
        xml.attribute(null, "visible-to-user", String.valueOf(node.isVisibleToUser()));
        Rect bounds = new Rect();
        node.getBoundsInScreen(bounds);
        xml.attribute(null, "bounds", "["+bounds.left+","+bounds.top+"]["+bounds.right+","+bounds.bottom+"]");
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) emit(xml, child, depth+1);
        }
        xml.endTag(null, "node");
    }

    @Override public void onStart() {
        File root = new File(getTargetContext().getFilesDir(), token);
        try {
            if (!root.mkdir()) throw new IllegalStateException("Namespace already exists");
            UiAutomation automation = getUiAutomation();
            if (automation == null) throw new IllegalStateException("Observer not connected");
            write(new File(root, "ready"), "ready");
            long deadline = SystemClock.uptimeMillis()+120000;
            for (int ordinal = 1; SystemClock.uptimeMillis() < deadline; ) {
                if (new File(root, "stop").exists()) {
                    write(new File(root, "stopped"), "stopped");
                    finish(Activity.RESULT_OK, new Bundle());
                    return;
                }
                String name = String.format(java.util.Locale.ROOT, "%03d", ordinal);
                if (!new File(root, "request-"+name).exists()) {
                    SystemClock.sleep(50);
                    continue;
                }
                AccessibilityNodeInfo active = automation.getRootInActiveWindow();
                File temporary = new File(root, "response-"+name+".tmp");
                try (FileOutputStream out = new FileOutputStream(temporary)) {
                    XmlSerializer xml = Xml.newSerializer();
                    xml.setOutput(out, "UTF-8");
                    xml.startDocument("UTF-8", true);
                    xml.startTag(null, "hierarchy");
                    // Never collect unrelated app contents.
                    if (active != null && "com.solosoul.app".contentEquals(active.getPackageName())) {
                        nodes = 0;
                        emit(xml, active, 0);
                    }
                    xml.endTag(null, "hierarchy");
                    xml.endDocument();
                }
                if (!temporary.renameTo(new File(root, "response-"+name+".xml"))) {
                    throw new IllegalStateException("Cannot atomically publish hierarchy");
                }
                ordinal++;
            }
            throw new IllegalStateException("Owned observer lifetime exhausted");
        } catch (Exception error) {
            try { write(new File(root, "error"), error.toString()); } catch (Exception ignored) { }
            Bundle failure = new Bundle();
            failure.putString("error", error.toString());
            finish(Activity.RESULT_CANCELED, failure);
        }
    }
}
