from contextlib import contextmanager
from pathlib import Path
import hashlib
import json
import subprocess
import time
import uuid

PACKAGE = 'org.solosoul.rf312observer'
B = Path('D:/SoloSoul/build/android-native-feasibility-20261010')

@contextmanager
def session(adb, read, output):
    build = json.loads((B/'persistent-external-ax-20261015/build-complete.json').read_text(encoding='utf-8'))
    apk = Path(build['apk'])
    assert build['accepted'] and build['instrumentationTarget'] == PACKAGE
    assert hashlib.sha256(apk.read_bytes()).hexdigest() == build['sha256']
    assert not read('shell','pm','list','packages',PACKAGE)
    target = output/'persistent-observer'
    target.mkdir(exist_ok=False)
    namespace = uuid.uuid4().hex
    remote = 'files/'+namespace+'/'
    installed = False
    process = None
    stdout = stderr = None
    cleanup = dict(originalPackageAbsent=True,targetPackageUnchanged=True,
        observerPackage=PACKAGE,targetInstrumentationInjected=False,namespace=namespace)
    ordinal = 0
    began = time.monotonic()

    def exists(name):
        try:
            adb('shell','run-as',PACKAGE,'test','-e',remote+name,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            return True
        except subprocess.CalledProcessError as error:
            if error.returncode == 1 and error.stdout == error.stderr == b'':
                return False
            raise

    def get(name):
        return read('shell','run-as',PACKAGE,'cat',remote+name)

    def touch(name):
        adb('shell','run-as',PACKAGE,'touch',remote+name,stdout=subprocess.PIPE,stderr=subprocess.PIPE)

    def ensure_alive():
        if exists('error'):
            raise RuntimeError('Independent observer failed: '+get('error'))
        if process.poll() is not None:
            raise RuntimeError('Independent observer exited before requested stop')

    def dump(timeout):
        nonlocal ordinal
        ordinal += 1
        name = f'{ordinal:03d}'
        touch('request-'+name)
        deadline = time.monotonic()+timeout
        while time.monotonic() < deadline:
            ensure_alive()
            if exists('response-'+name+'.xml'):
                return get('response-'+name+'.xml')
            time.sleep(.05)
        raise TimeoutError('Independent observer did not publish a hierarchy within remaining budget')

    try:
        adb('install','--no-streaming',str(apk),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        installed = True
        (target/'installed-package.txt').write_text(read('shell','dumpsys','package',PACKAGE),encoding='utf-8')
        stdout = (target/'instrumentation.stdout.log').open('xb')
        stderr = (target/'instrumentation.stderr.log').open('xb')
        command = [str(B/'sdk/platform-tools/adb.exe'),'-H','127.0.0.1','-P','5057','-s','emulator-5578',
            'shell','am','instrument','-w','-r','-e','token',namespace,PACKAGE+'/'+PACKAGE+'.Observer']
        process = subprocess.Popen(command,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW)
        (target/'live.json').write_text(json.dumps(dict(pid=process.pid,command=command)),encoding='utf-8')
        deadline = time.monotonic()+15
        while not exists('ready'):
            ensure_alive()
            if time.monotonic() >= deadline:
                raise TimeoutError('Independent observer initialization exceeded 15 seconds')
            time.sleep(.05)
        cleanup['initializationSeconds'] = time.monotonic()-began
        cleanup['connectedBeforeActivityStart'] = True
        yield dump
    finally:
        if process is not None:
            if process.poll() is None:
                touch('stop')
                try:
                    cleanup['observerCommandExitCode'] = process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    cleanup['gracefulStopTimedOut'] = True
                    adb('shell','am','force-stop',PACKAGE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                    cleanup['observerCommandExitCode'] = process.wait(timeout=10)
            else:
                cleanup['observerCommandExitCode'] = process.returncode
            cleanup['normalObserverStopReceipt'] = exists('stopped')
            if exists('error'):
                cleanup['observerError'] = get('error')
        if stdout is not None: stdout.close()
        if stderr is not None: stderr.close()
        if installed:
            adb('uninstall',PACKAGE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            cleanup['observerUninstalled'] = not bool(read('shell','pm','list','packages',PACKAGE))
            cleanup['observerInstrumentationAbsent'] = PACKAGE not in read('shell','dumpsys','activity','instrumentation')
        cleanup['allObserverRequests'] = ordinal
        (target/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf-8')
        assert cleanup.get('observerUninstalled') is True
        assert cleanup.get('observerInstrumentationAbsent') is True
        assert cleanup.get('normalObserverStopReceipt') is True and not cleanup.get('gracefulStopTimedOut')
        assert not cleanup.get('observerError')
