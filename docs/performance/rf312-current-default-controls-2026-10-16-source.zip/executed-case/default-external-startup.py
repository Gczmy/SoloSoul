"""Observe the default APK's public login form from outside the target process."""
from pathlib import Path
import importlib.util
import json
import hashlib
import re
import subprocess
import time
import uuid
import xml.etree.ElementTree as ET

APP = 'com.solosoul.app'
R = Path('D:/SoloSoul/build/worktrees/rf1158-perf-owner')

def visible_bounds(node):
    bounds = re.fullmatch(r'\[(\d+),(\d+)\]\[(\d+),(\d+)\]', node.get('bounds', ''))
    return (bounds is not None and int(bounds[3]) > int(bounds[1])
        and int(bounds[4]) > int(bounds[2]) and node.get('visible-to-user', 'true') == 'true')

def observe(adb, read, output, count, uid):
    helper_path=Path(__file__).with_name('persistent-ax-session.py')
    inputs=json.loads(Path(__file__).with_name('inputs.json').read_text(encoding='utf-8'))
    assert hashlib.sha256(helper_path.read_bytes()).hexdigest()==inputs['persistentSessionSha256']
    spec=importlib.util.spec_from_file_location('persistent_ax',helper_path)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    with helper.session(adb,read,output) as persistent_dump:
        return observe_connected(adb,read,output,count,uid,persistent_dump)

def observe_connected(adb, read, output, count, uid, persistent_dump):
    assert count in [100, 5000]
    reader_path = Path(__file__).with_name('android-home-native-regression-fixed.py')
    inputs = json.loads(Path(__file__).with_name('inputs.json').read_text(encoding='utf-8'))
    assert hashlib.sha256(reader_path.read_bytes()).hexdigest() == inputs['processReaderSha256']
    reader_spec = importlib.util.spec_from_file_location('committed_process_reader', reader_path)
    process_reader = importlib.util.module_from_spec(reader_spec)
    reader_spec.loader.exec_module(process_reader)
    target = output/'default-external'
    target.mkdir(exist_ok=False)
    assert not read('shell', 'pm', 'list', 'packages', APP+'.releaseprobe')
    assert APP not in read('shell', 'dumpsys', 'activity', 'instrumentation')
    adb('shell', 'am', 'force-stop', APP)
    assert not process_reader.read_process_ids(read, APP)
    begin = time.monotonic()
    framework = read('shell', 'am', 'start', '-W', '-n', APP+'/.MainActivity')
    (target/'framework-start.txt').write_text(framework, encoding='utf-8')
    assert re.search(r'^Status:\s*ok\s*$', framework, re.M), framework
    elapsed = re.findall(r'^TotalTime:\s*(\d+)\s*$', framework, re.M)
    assert len(elapsed) == 1 and int(elapsed[0]) > 0, framework
    pid = process_reader.read_process_ids(read, APP)
    assert re.fullmatch(r'[1-9]\d*', pid), pid
    (target/'observed-process-start.json').write_text(json.dumps(dict(pid=int(pid),uid=uid,
        frameworkTotalTimeMs=int(elapsed[0]))),encoding='utf-8')
    expected = f'acc_rf312_{count}'
    attempts = []
    ready = None
    while time.monotonic()-begin < 45:
        if process_reader.read_process_ids(read, APP) != pid:
            raise RuntimeError('Target process changed before form readiness')
        remaining = 45-(time.monotonic()-begin)
        ordinal = len(attempts)+1
        text=persistent_dump(max(.001,remaining))
        (target/f'ax-{ordinal:03d}.xml').write_text(text,encoding='utf-8')
        tree = ET.fromstring(text)
        nodes = [n for n in tree.iter('node') if n.get('package') == APP]
        labels = [n.get(key, '') for n in nodes for key in ['text', 'content-desc']]
        password = [n for n in nodes if n.get('class') == 'android.widget.EditText'
            and n.get('password') == 'true' and n.get('enabled') == 'true']
        unlock = [n for n in nodes if 'Unlock' in [n.get('text'), n.get('content-desc')]
            and n.get('enabled') == 'true' and n.get('clickable') == 'true']
        state = dict(ordinal=ordinal, ownedNodes=len(nodes), passwordFields=len(password),
            unlockButtons=len(unlock), expectedPublicAccount=any(expected in s for s in labels),
            expectedPublicName=any('Performance Fixture' in s for s in labels))
        attempts.append(state)
        if (len(password) == len(unlock) == 1 and visible_bounds(password[0]) and visible_bounds(unlock[0])
                and state['expectedPublicAccount'] and state['expectedPublicName']):
            focus = read('shell', 'dumpsys', 'window', 'displays')
            (target/'window-focus.txt').write_text(focus, encoding='utf-8')
            assert re.search(r'mCurrentFocus=.*'+re.escape(APP)+'/', focus), 'Target window must own focus'
            ready = dict(state, hostObservedFormReadyUpperBoundMs=(time.monotonic()-begin)*1000)
            break
    if ready is None:
        raise RuntimeError('Default public password form not observed within original 45-second budget')
    assert ready['hostObservedFormReadyUpperBoundMs'] <= 45000
    assert process_reader.read_process_ids(read, APP) == pid
    assert APP not in read('shell', 'dumpsys', 'activity', 'instrumentation')
    assert not read('shell', 'pm', 'list', 'packages', APP+'.releaseprobe')
    spec = importlib.util.spec_from_file_location('external_memory', R/'tauri/scripts/android-process-memory.py')
    memory = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(memory)
    folder = target/'memory'
    collector = memory.AdbRunner('D:/SoloSoul/build/android-native-feasibility-20261010/sdk/platform-tools/adb.exe',
        'emulator-5578', 'SoloSoul_RF312_Default_20261016V2', folder, host='127.0.0.1', port=5057)
    assert collector.prefix[1:5]==['-H','127.0.0.1','-P','5057']
    snapshot = memory.collect_snapshot(collector, APP, uid, 'com.android.webview')
    assert snapshot['fullProcessScopeAccepted']
    roots = [p for p in snapshot['processes'] if p['role'] == 'app']
    assert len(roots) == 1 and roots[0]['pid'] == int(pid) and roots[0]['uid'] == uid
    (folder/'result.json').write_text(json.dumps(snapshot, indent=2)+'\n', encoding='utf-8')
    evidence = dict(schemaVersion=1, scope='default-apk-external-startup-control',
        success=True, objectCount=count, frameworkTotalTimeMs=int(elapsed[0]),
        form=ready, attempts=attempts, targetInstrumentationInjected=False,
        externalUiAutomationObserver=True, javaScriptInjected=False,
        frameworkStartupExcludesFormReadiness=True,
        formTimeIncludesAdbAndAccessibilityPolling=True, twoCommittedFramesProven=False,
        observedFormPssBytes=snapshot['pssBytes'], pid=int(pid), uid=uid,
        fullMediaOrPerformanceAccepted=False, fullRf312Accepted=False)
    (target/'evidence.json').write_text(json.dumps(evidence, indent=2)+'\n', encoding='utf-8')
    return evidence
