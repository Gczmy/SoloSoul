"""Own an isolated API31 runtime for the frozen current default Release controls."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import re
import socket
import subprocess
import sys
import time
import traceback

stage = Path(__file__).resolve().parent
root = Path('D:/SoloSoul/build/worktrees/rf1158-perf-owner')
base = Path('D:/SoloSoul/build/android-native-feasibility-20261010')
previous = Path('D:/SoloSoul/build/rf1109-full-home-current-20261015')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, indent=2)+'\n', encoding='utf-8', newline='\n')
plan = load(stage / 'external-plan.json')
assert plan['requested'] == 10 and plan['compiledSourceHead'] == '0a95806cd40e9d09200e16795a139f1c7ee755b2'
assert load(stage / 'android-release-package/package-verification.json')['acceptedPackagePreparation']
assert not (stage / 'android-release-build/receipt.json').is_file() or load(stage / 'android-release-build/receipt.json')['exitCode'] == 0
proof = stage / 'native-default-controls'
proof.mkdir(exist_ok=False)
name, serial = plan['avd'], plan['serial']
assert name == 'SoloSoul_RF312_Default_20261016V2' and serial == 'emulator-5578'
config = stage / 'avd' / (name+'.avd') / 'config.ini'
config_hash = sha(config)
assert config_hash == load(stage / 'avd-preparation.json')['configSha256']
for port in [5057, 5578, 5579]:
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', port))
adb = base / 'sdk/platform-tools/adb.exe'
pwsh = 'C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
env = dict(os.environ, ANDROID_HOME=str(base / 'sdk'), ANDROID_SDK_ROOT=str(base / 'sdk'),
    ANDROID_AVD_HOME=str(stage / 'avd'), ANDROID_USER_HOME=str(stage / 'android-user'),
    ANDROID_EMULATOR_HOME=str(stage / 'android-user'), ANDROID_ADB_SERVER_PORT='5057',
    ADB_SERVER_SOCKET='tcp:127.0.0.1:5057', TEMP=str(stage), TMP=str(stage), PYTHONDONTWRITEBYTECODE='1')
record = dict(scope='current-default-release-ten-external-controls', passed=False, oldPrivateServerTouched=False,
              targetInstrumentationInjected=False, javaScriptInjected=False, commands=[])
sequence = 0
server = emulator = None
identified = installed = mutation_started = False
all_restored = False
settings_before = None

def host_processes():
    command = 'Get-CimInstance Win32_Process | Select-Object Name,ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3'
    rows = json.loads(subprocess.check_output([pwsh, '-NoProfile', '-Command', command], text=True))
    return rows if isinstance(rows, list) else [rows]

def old_server(rows):
    matches = [p for p in rows if p['ProcessId'] == 38780]
    assert len(matches) == 1
    row = matches[0]
    assert datetime.datetime.fromisoformat(row['CreationDate']) == datetime.datetime.fromisoformat('2026-10-15T10:36:02.224448+01:00')
    assert row['Name'] == 'adb.exe' and Path(row['ExecutablePath']) == adb
    assert row['CommandLine'].endswith('-L tcp:localhost:5049 server nodaemon')
    return row

old_identity = old_server(host_processes())
save(proof / 'old-server-before.json', old_identity)

def call(label, args, required=True, timeout=30):
    global sequence
    sequence += 1
    result = subprocess.run([str(adb), '-H', '127.0.0.1', '-P', '5057', *args], cwd=stage, env=env,
        stdin=subprocess.DEVNULL, capture_output=True, timeout=timeout, creationflags=subprocess.CREATE_NO_WINDOW)
    prefix = f'{sequence:03d}-{label}'
    (proof / (prefix+'.stdout')).write_bytes(result.stdout)
    (proof / (prefix+'.stderr')).write_bytes(result.stderr)
    record['commands'].append(dict(label=label, exitCode=result.returncode))
    if required:
        result.check_returncode()
    return result

def device(label, args, **kwargs):
    return call(label, ['-s', serial, *args], **kwargs)

def settings():
    result = {}
    for namespace, key in [('global', 'disable_window_blurs'), ('secure', 'high_text_contrast_enabled'),
            ('system', 'font_scale'), ('global', 'animator_duration_scale'), ('global', 'transition_animation_scale'),
            ('global', 'window_animation_scale')]:
        result[namespace+'.'+key] = device('setting-'+key, ['shell', 'settings', 'get', namespace, key]).stdout.decode()
    result['night'] = device('night', ['shell', 'cmd', 'uimode', 'night']).stdout.decode()
    return result

try:
    server_log = (proof / 'adb-server.log').open('xb')
    server = subprocess.Popen([str(adb), '-L', 'tcp:localhost:5057', 'server', 'nodaemon'], cwd=stage,
        env=dict(env, ADB_SERVER_SOCKET='tcp:localhost:5057'), stdin=subprocess.DEVNULL, stdout=server_log,
        stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    time.sleep(1)
    assert server.poll() is None
    assert call('empty-devices', ['devices']).stdout.decode().strip() == 'List of devices attached'
    emu_log = (proof / 'emulator.log').open('xb')
    command = [str(base / 'sdk/emulator/emulator.exe'), '-avd', name, '-port', '5578', '-accel', 'on',
        '-gpu', 'swiftshader', '-memory', '2048', '-cores', '2', '-no-window', '-no-snapshot', '-no-audio', '-no-boot-anim']
    emulator = subprocess.Popen(command, cwd=stage, env=env, stdin=subprocess.DEVNULL, stdout=emu_log,
        stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    record.update(serverPid=server.pid, emulatorLauncherPid=emulator.pid, emulatorCommand=command)
    save(proof / 'live.json', record)
    print('Fresh dedicated API31 boot started; Release build/package already terminal', flush=True)
    deadline = time.monotonic()+240
    while time.monotonic() < deadline:
        result = device('boot', ['shell', 'getprop', 'sys.boot_completed'], required=False, timeout=10)
        if result.returncode == 0 and result.stdout.strip() == b'1':
            break
        time.sleep(3)
    else:
        raise TimeoutError('Original 240-second boot budget exhausted')
    assert device('avd', ['emu', 'avd', 'name']).stdout.decode().splitlines()[0].strip() == name
    identified = True
    assert device('api', ['shell', 'getprop', 'ro.build.version.sdk']).stdout.strip() == b'31'
    assert device('abi', ['shell', 'getprop', 'ro.product.cpu.abi']).stdout.strip() == b'x86_64'
    assert sha(config) == config_hash, 'AVD configuration changed during initial boot; preserve and review'
    processes = host_processes()
    actual_old = old_server(processes)
    assert actual_old == old_identity
    own_server = [p for p in processes if p['ProcessId'] == server.pid]
    own_vm = [p for p in processes if p['Name'].startswith('qemu-system-x86_64') and
              name in (p['CommandLine'] or '') and str(base / 'sdk/emulator') in (p['ExecutablePath'] or '')]
    assert len(own_server) == len(own_vm) == 1
    save(proof / 'owned-host-processes.json', [*own_server, *own_vm, old_identity])
    device('provider', ['shell', 'dumpsys', 'webviewupdate'])
    device('system-anr', ['shell', 'dumpsys', 'dropbox', '--print', 'system_app_anr'], timeout=45)
    device('last-anr', ['shell', 'dumpsys', 'activity', 'lastanr'])
    windows = device('preflight-windows', ['shell', 'dumpsys', 'window']).stdout.decode()
    focus = [line.strip() for line in windows.splitlines() if 'mCurrentFocus=' in line]
    screenshot = device('preflight-screenshot', ['exec-out', 'screencap', '-p']).stdout
    assert screenshot.startswith(b'\x89PNG\r\n\x1a\n')
    (proof / 'preflight.png').write_bytes(screenshot)
    assert not any('Application Not Responding' in line or 'Application Error' in line for line in focus)
    for package in ['com.solosoul.app', 'com.solosoul.app.test', 'com.solosoul.app.releaseprobe', 'org.solosoul.rf312observer']:
        absent = device('absent-'+package, ['shell', 'pm', 'path', package], required=False)
        assert absent.returncode in (0, 1) and not absent.stdout.strip() and not absent.stderr.strip()
    save(proof / 'environment-preflight.json', dict(api=31, abi='x86_64', focus=focus,
        pngSha256=sha(proof / 'preflight.png'), avdConfigUnchanged=True, nativeTestsStarted=0))
    print('API31 preflight captured; waiting for local Launcher and ANR evidence review', flush=True)
    deadline = time.monotonic()+600
    while not (proof / 'continue-native.json').is_file():
        assert time.monotonic() < deadline, 'Bounded local preflight review expired'
        time.sleep(1)
    review = load(proof / 'continue-native.json')
    assert review['pngSha256'] == sha(proof / 'preflight.png') and review['screenInspected']
    assert review['blockingSystemErrorDialogAbsent'] and review['systemAnrEvidenceReviewed']
    settings_before = settings()
    packages = {row['kind']: row for row in load(previous / 'android-debug-package2/packages.json')['packages']}
    installed = True
    for kind in ['main', 'test']:
        row = packages[kind]
        assert row['signatureVerified'] and sha(Path(row['path'])) == row['sha256']
        device('install-'+kind, ['install', '-t', row['path']], timeout=120)
        package = 'com.solosoul.app'+('.test' if kind == 'test' else '')
        path = device('installed-path-'+kind, ['shell', 'pm', 'path', package]).stdout.decode().strip()
        assert re.fullmatch(r'package:/data/app/(?:[A-Za-z0-9_~+=.-]+/){1,2}base\.apk', path)
        payload = device('installed-bytes-'+kind, ['exec-out', 'cat', path.removeprefix('package:')], timeout=120).stdout
        assert hashlib.sha256(payload).hexdigest() == row['sha256']
    device('prewarm-main', ['shell', 'am', 'start', '-W', '-n', 'com.solosoul.app/.MainActivity'], timeout=45)
    manifest = load(stage / 'android-release-package/assets/bundled-resource-manifest.json')
    marker = manifest['version']+'\n'+''.join(f"{e['path']}\t{e['size']}\t{e['sha256']}\n" for e in sorted(manifest['files'], key=lambda e:e['path']))
    deadline = time.monotonic()+45
    while time.monotonic() < deadline:
        present = device('resource-marker-present', ['shell', 'run-as', 'com.solosoul.app', 'test', '-f', 'app_resources/.bundled-resource-manifest'], required=False)
        if present.returncode == 0:
            break
        assert present.returncode == 1 and not present.stdout and not present.stderr
        time.sleep(1)
    else:
        raise TimeoutError('Actual MainActivity resource preparation exceeded 45 seconds')
    actual_marker = device('resource-marker', ['exec-out', 'run-as', 'com.solosoul.app', 'cat', 'app_resources/.bundled-resource-manifest']).stdout.decode()
    assert actual_marker == marker
    expected = {'app_resources/'+entry['path']:entry['sha256'] for entry in manifest['files']}
    text = device('resource-file-hashes', ['shell', 'run-as', 'com.solosoul.app', 'sha256sum', *sorted(expected)]).stdout.decode()
    actual = {}
    for line in text.splitlines():
        match = re.fullmatch(r'([a-f0-9]{64})  (.+)', line)
        assert match
        actual[match[2]] = match[1]
    assert actual == expected
    device('prewarm-force-stop', ['shell', 'am', 'force-stop', 'com.solosoul.app'])
    payload = device('prewarm-private', ['exec-out', 'run-as', 'com.solosoul.app', 'tar', '-cf', '-', '.'], timeout=120).stdout
    baseline = proof / 'prepared-empty-private.tar'
    baseline.write_bytes(payload)
    spec = importlib.util.spec_from_file_location('restore', root / 'tauri/scripts/android-home-native-regression.py')
    restore = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(restore)
    inventory = restore.inventory(baseline, require_empty=True)
    save(proof / 'prepared-empty-private-inventory.json', inventory)
    save(proof / 'environment-ready.json', dict(api=31, abi='x86_64', preflightReviewed=True,
        actualMainActivityResourcesVerified=True, resourceFiles=len(expected), manifestVersion=manifest['version'],
        preparedPrivateEntries=len(inventory), preparedPrivateTarSha256=sha(baseline), settingsBefore=settings_before,
        initializationExcludedFromMeasuredControls=True, targetInstrumentationInjected=False))
    mutation_started = True
    command = [sys.executable, str(stage / 'run-current-cohort.py')]
    with (proof / 'cohort.stdout').open('xb') as stdout, (proof / 'cohort.stderr').open('xb') as stderr:
        child = subprocess.Popen(command, cwd=root, env=env, stdin=subprocess.DEVNULL, stdout=stdout,
            stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
        save(proof / 'cohort.live.json', dict(pid=child.pid, command=command))
        print('Actual MainActivity resources verified; current default ten-control cohort started', flush=True)
        code = child.wait()
    report = load(stage / 'external-terminal.json')
    all_restored = bool(report['outcomes']) and all(row['allOriginalStateRestored'] for row in report['outcomes'])
    record['cohortRestored'] = all_restored
    record['cohortCompleted'] = len(report['outcomes'])
    assert code == 0 and report.get('all10ControlsPassed') and all_restored
    record['passed'] = True
except Exception as error:
    record['error'] = type(error).__name__+': '+str(error)
    (proof / 'error.txt').write_text(traceback.format_exc(), encoding='utf-8')
    print(record['error'], flush=True)
finally:
    cleanup = {}
    if not identified and emulator is not None:
        try:
            # Console ownership can be proven even if Android did not finish booting.
            identity = device('cleanup-boot-avd', ['emu', 'avd', 'name'], required=False)
            identified = identity.returncode == 0 and identity.stdout.decode().splitlines()[0].strip() == name
        except Exception as error:
            cleanup['bootIdentityVerificationError'] = repr(error)
    if identified:
        try:
            assert device('cleanup-avd', ['emu', 'avd', 'name']).stdout.decode().splitlines()[0].strip() == name
            if settings_before is not None:
                settings_after = settings()
                cleanup['systemSettingsExactlyRestored'] = settings_after == settings_before
                save(proof / 'system-restoration.json', dict(before=settings_before, after=settings_after,
                    exactlyEqual=settings_after == settings_before))
            if installed and (not mutation_started or all_restored):
                device('cleanup-force-stop', ['shell', 'am', 'force-stop', 'com.solosoul.app'])
                cleanup['testUninstalled'] = device('uninstall-test', ['uninstall', 'com.solosoul.app.test']).stdout.strip() == b'Success'
                cleanup['mainUninstalled'] = device('uninstall-main', ['uninstall', 'com.solosoul.app']).stdout.strip() == b'Success'
            elif installed:
                cleanup['packagesRetainedForStrictRecovery'] = True
            device('emulator-stop', ['emu', 'kill'])
            cleanup['emulatorShutdownRequested'] = True
        except Exception as error:
            cleanup['error'] = repr(error)
    if emulator is not None:
        try:
            emulator.wait(timeout=45)
            cleanup['emulatorLauncherExited'] = True
        except subprocess.TimeoutExpired:
            cleanup['emulatorLauncherExited'] = False
    if server is not None and server.poll() is None:
        try:
            call('server-stop', ['kill-server'])
            server.wait(timeout=15)
            cleanup['ownedServerExited'] = True
        except Exception as error:
            cleanup['serverError'] = repr(error)
    try:
        cleanup['oldPrivateServerIdentityUnchanged'] = old_server(host_processes()) == old_identity
    except Exception as error:
        cleanup['oldPrivateServerVerificationError'] = repr(error)
    record['cleanup'] = cleanup
    save(proof / 'result.json', record)
    print(json.dumps(dict(passed=record['passed'], cleanup=cleanup)), flush=True)
if not record['passed']:
    raise SystemExit(1)
