"""Prepare ten fresh controls; this script never starts ADB or an emulator."""
from pathlib import Path
import ast
import hashlib
import json
import shutil
import subprocess

stage = Path(__file__).resolve().parent
root = Path('D:/SoloSoul/build/worktrees/rf1158-perf-owner')
base = Path('D:/SoloSoul/build/android-native-feasibility-20261010')
previous = Path('D:/SoloSoul/build/rf1109-full-home-current-20261015')
old = base / 'rf312-fixed-default-external-v2-20261015/external-cohort/100-001'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, indent=2)+'\n', encoding='utf-8', newline='\n')

release = load(stage / 'android-release-package/package-verification.json')
assert release['acceptedPackagePreparation'] and release['defaultFeaturesOnly']
assert release['applicationDebuggable'] is False and release['observerMarkersPresent'] is False
assert release['sourceHead'] == '0a95806cd40e9d09200e16795a139f1c7ee755b2'
assert sha(Path(release['apk']['path'])) == release['apk']['sha256']
assert not (stage / 'external-plan.json').exists()
sources = load(stage / 'sources.json')
current = {name: sha(root / name) for name in sources}
changed = sorted(name for name in sources if sources[name] != current[name])
assert changed == ['tauri/scripts/android-process-memory.py', 'tauri/scripts/test_android_process_memory.py'], changed
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert subprocess.check_output(['git', 'status', '--porcelain', '--ignore-submodules'], cwd=root, text=True) == ''
assert 'RF-1170' in subprocess.check_output(['git', 'log', '-1', '--format=%s'], cwd=root, text=True)
for folder, filename in [('tauri/dist', 'frontend.json'), ('tauri/src-tauri/resources-mobile', 'mobile-resources.json')]:
    expected = load(stage / filename)
    assert {p.relative_to(root / folder).as_posix(): sha(p) for p in (root / folder).rglob('*') if p.is_file()} == expected
    current.update({folder+'/'+name: digest for name, digest in expected.items()})

packages = {row['kind']: row for row in load(previous / 'android-debug-package2/packages.json')['packages']}
assert set(packages) == {'main', 'test'}
assert all(sha(Path(row['path'])) == row['sha256'] and row['signatureVerified'] for row in packages.values())
assert all(row['certificateSha256'] == release['certificateSha256'] for row in packages.values())
prior = load(old / 'inputs.json')
for fixture in prior['fixedFixtures'].values():
    directory = Path(fixture['root'])
    assert {p.relative_to(directory).as_posix(): sha(p) for p in directory.rglob('*') if p.is_file()} == fixture['files']
assert sha(Path(prior['runtimeTest']['path'])) == prior['runtimeTest']['sha256']

def replace_once(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)

driver = (old / 'default-external-native-driver.py').read_text(encoding='utf-8')
driver = driver.replace("Path('D:/SoloSoul')", "Path('"+root.as_posix()+"')")
driver = replace_once(driver, "Path('D:/SoloSoul/tauri/scripts/android-home-native-regression.py')",
                      "Path('"+(root / 'tauri/scripts/android-home-native-regression.py').as_posix()+"')")
driver = replace_once(driver, "'-P', '5049'", "'-P', '5057'")
startup = (old / 'default-external-startup.py').read_text(encoding='utf-8')
startup = replace_once(startup, "R = Path('D:/SoloSoul')", "R = Path('"+root.as_posix()+"')")
startup = replace_once(startup,
    "collector = memory.AdbRunner(str(R/'build/android-native-feasibility-20261010/sdk/platform-tools/adb.exe'),\n"
    "        'emulator-5586', 'SoloSoul_RF121_API31_20261010', folder)\n"
    "    assert collector.prefix[1:5]==['-H','localhost','-P','5049']\n"
    "    collector.prefix[2]='127.0.0.1'",
    "collector = memory.AdbRunner('"+(base / 'sdk/platform-tools/adb.exe').as_posix()+"',\n"
    "        'emulator-5578', 'SoloSoul_RF312_Default_20261016V2', folder, host='127.0.0.1', port=5057)\n"
    "    assert collector.prefix[1:5]==['-H','127.0.0.1','-P','5057']")
session = (old / 'persistent-ax-session.py').read_text(encoding='utf-8')
session = replace_once(session, "'-P','5049','-s','emulator-5586'", "'-P','5057','-s','emulator-5578'")
helpers = {'default-external-native-driver.py': driver, 'default-external-startup.py': startup,
           'persistent-ax-session.py': session,
           'android-home-native-regression-fixed.py': (old / 'android-home-native-regression-fixed.py').read_text(encoding='utf-8')}
assert sha(old / 'default-external-startup.py') == prior['externalObserverSha256']
assert sha(old / 'persistent-ax-session.py') == prior['persistentSessionSha256']
assert sha(old / 'android-home-native-regression-fixed.py') == prior['processReaderSha256']
for text in helpers.values():
    ast.parse(text)

out = stage / 'external-cohort'
out.mkdir(exist_ok=False)
samples = []
for ordinal in range(1, 6):
    for count in [100, 5000]:
        case = out / f'{count}-{ordinal:03d}'
        case.mkdir(exist_ok=False)
        for name, text in helpers.items():
            (case / name).write_text(text, encoding='utf-8', newline='\n')
        inputs = {key: prior[key] for key in ['fixedFixtures', 'runtimeTest', 'processReaderSourceCommit']}
        inputs.update(runtimeSourceFiles=current, release=release,
            originalDebug=dict(packages['main'], copy=packages['main']['path']),
            originalTest=dict(packages['test'], copy=packages['test']['path']),
            sourceParentHead=head, compiledSourceHead=release['sourceHead'],
            runtimeHelperOnlyDeltasFromCompiledSource=changed,
            scope='current-default-release-external-startup-control-only',
            publicOcrImage=dict(path=str(root / 'tauri/crates/solosoul-core/tests/fixtures/ocr_test.png'),
                                sha256=prior['publicOcrImage']['sha256']),
            externalObserverSha256=sha(case / 'default-external-startup.py'),
            persistentSessionSha256=sha(case / 'persistent-ax-session.py'),
            processReaderSha256=sha(case / 'android-home-native-regression-fixed.py'),
            canonicalMemoryReaderSha256=sha(root / 'tauri/scripts/android-process-memory.py'),
            rf1161ComponentSha256=sha(root / 'tauri/src/components/forms/PasswordInput.tsx'))
        assert sha(Path(inputs['publicOcrImage']['path'])) == inputs['publicOcrImage']['sha256']
        save(case / 'inputs.json', inputs)
        samples.append(dict(objectCount=count, ordinal=ordinal, root=str(case),
            frozenFiles={name: sha(case / name) for name in [*helpers, 'inputs.json']}))
save(stage / 'external-plan.json', dict(samples=samples, requested=10, cohortsCombinedWithOld=False,
    stopOnFirstFailure=True, noTargetInstrumentationOrJavaScript=True, originalFormBudgetSeconds=45,
    adbEndpoint='127.0.0.1:5057', serial='emulator-5578', avd='SoloSoul_RF312_Default_20261016V2',
    compiledSourceHead=release['sourceHead'], validationSourceHead=head,
    runtimeHelperOnlyDeltasFromCompiledSource=changed, fullRF312Accepted=False))
save(stage / 'cohort-preparation.json', dict(scriptsPrepared=40, inputSets=10,
    runtimeSources=len(current), nativeTestsStarted=0, compiledSourceUnchangedExceptDiagnosticHelpers=True,
    originalComparisonBudgetsPreserved=True))
print('Ten current default Release controls prepared; no native process started')
