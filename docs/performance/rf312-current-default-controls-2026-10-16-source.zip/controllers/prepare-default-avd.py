from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

stage = Path(__file__).resolve().parent
base = Path('D:/SoloSoul/build/android-native-feasibility-20261010')
sdk = base / 'sdk'
name = 'SoloSoul_RF312_Default_20261016V2'
destination = stage / 'avd' / (name + '.avd')
assert destination.resolve().is_relative_to(stage.resolve()) and not destination.exists()
home = stage / 'android-user'
home.mkdir(exist_ok=False)
destination.parent.mkdir(exist_ok=False)
properties = (sdk / 'system-images/android-31/default/x86_64/source.properties').read_text()
assert 'AndroidVersion.ApiLevel=31' in properties and 'SystemImage.Abi=x86_64' in properties
manager = sdk / 'cmdline-tools/latest/bin/avdmanager.bat'
assert manager.is_file()
env = dict(os.environ, JAVA_HOME='C:/Users/40299571/ss-android/jdk', ANDROID_HOME=str(sdk),
           ANDROID_SDK_ROOT=str(sdk), ANDROID_AVD_HOME=str(destination.parent), ANDROID_USER_HOME=str(home),
           ANDROID_EMULATOR_HOME=str(home), TEMP=str(stage), TMP=str(stage),
           JAVA_TOOL_OPTIONS='-Duser.home=' + str(home) + ' -Djava.io.tmpdir=' + str(stage))
command = ['cmd.exe', '/d', '/c', str(manager), 'create', 'avd', '--name', name,
           '--package', 'system-images;android-31;default;x86_64', '--device', 'pixel_2', '--path', str(destination)]
started = time.monotonic()
result = subprocess.run(command, env=env, cwd=stage, input=b'no\n', capture_output=True,
                        timeout=120, creationflags=subprocess.CREATE_NO_WINDOW)
(stage / 'avd-create.stdout.log').write_bytes(result.stdout)
(stage / 'avd-create.stderr.log').write_bytes(result.stderr)
record = dict(command=command, exitCode=result.returncode, elapsedSeconds=round(time.monotonic()-started, 3),
              api=31, abi='x86_64', name=name, oldAvdDirectoriesModified=False, emulatorStarted=False)
if result.returncode == 0:
    config = destination / 'config.ini'
    assert config.is_file()
    content = config.read_text()
    assert 'image.sysdir.1=system-images\\android-31\\default\\x86_64\\' in content or 'image.sysdir.1=system-images/android-31/default/x86_64/' in content
    record.update(configSha256=hashlib.sha256(config.read_bytes()).hexdigest(),
                  systemImageSourcePropertiesSha256=hashlib.sha256(properties.encode()).hexdigest(),
                  createdNewDedicatedAvd=True)
(stage / 'avd-preparation.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
result.check_returncode()
print(json.dumps({k: v for k, v in record.items() if k != 'command'}))
