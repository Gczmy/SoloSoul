"""Execute one complete fresh current default cohort, stopping at the first failure."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

stage = Path(__file__).resolve().parent
root = Path('D:/SoloSoul/build/worktrees/rf1158-perf-owner')
base = Path('D:/SoloSoul/build/android-native-feasibility-20261010')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, indent=2)+'\n', encoding='utf-8', newline='\n')
plan = load(stage / 'external-plan.json')
boot = load(stage / 'native-default-controls/environment-ready.json')
owned = load(stage / 'native-default-controls/owned-host-processes.json')
prepared_inventory = load(stage / 'native-default-controls/prepared-empty-private-inventory.json')
assert boot['api'] == 31 and boot['abi'] == 'x86_64'
assert boot['actualMainActivityResourcesVerified'] and boot['preflightReviewed']
assert plan['requested'] == 10 and len(plan['samples']) == 10
assert not (stage / 'external-terminal.json').exists()
pwsh = 'C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'

def validate_host(row):
    command = f"Get-CimInstance Win32_Process -Filter 'ProcessId = {row['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json"
    actual = json.loads(subprocess.check_output([pwsh, '-NoProfile', '-Command', command], text=True))
    assert all(actual[k] == row[k] for k in ['Name', 'ProcessId', 'ExecutablePath', 'CommandLine'])
    assert datetime.datetime.fromisoformat(actual['CreationDate']) == datetime.datetime.fromisoformat(row['CreationDate'])

spec = importlib.util.spec_from_file_location('restore', root / 'tauri/scripts/android-home-native-regression.py')
restore = importlib.util.module_from_spec(spec)
spec.loader.exec_module(restore)
env = dict(os.environ, ANDROID_ADB_SERVER_PORT='5057', ADB_SERVER_SOCKET='tcp:127.0.0.1:5057',
           TEMP=str(stage), TMP=str(stage), PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1')
outcomes = []
terminal = dict(allRequestedCompleted=False, stoppedOnFirstFailure=True, fullRF312Accepted=False)
try:
    for sample in plan['samples']:
        if (stage / 'external-stop-requested.json').exists():
            terminal['stoppedAtSafeRestorationBoundary'] = True
            raise RuntimeError('Requested stop at restored sample boundary')
        for row in owned:
            validate_host(row)
        case = Path(sample['root'])
        assert case.resolve().is_relative_to(stage / 'external-cohort') and not case.is_symlink()
        assert all(sha(case / name) == value for name, value in sample['frozenFiles'].items())
        inputs = load(case / 'inputs.json')
        assert all(sha(root / name) == digest for name, digest in inputs['runtimeSourceFiles'].items())
        assert inputs['release']['observerMarkersPresent'] is False
        command = [sys.executable, '-X', 'utf8', str(case / 'default-external-native-driver.py'),
            '--adb', str(base / 'sdk/platform-tools/adb.exe'), '--serial', plan['serial'],
            '--avd', plan['avd'], '--apk', inputs['release']['apk']['path'],
            '--test-apk', inputs['runtimeTest']['path'], '--restore-apk', inputs['originalDebug']['copy'],
            '--output', str(case / 'journey'), '--mode', 'supported', '--scenario', 'baseline',
            '--object-count', str(sample['objectCount']), '--fixture', inputs['fixedFixtures'][str(sample['objectCount'])]['root']]
        began = time.monotonic()
        with (case / 'stdout.log').open('xb') as stdout, (case / 'stderr.log').open('xb') as stderr:
            child = subprocess.Popen(command, cwd=root, env=env, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
            save(case / 'live.json', dict(pid=child.pid, command=command))
            print(f"Current default external control {sample['objectCount']} round {sample['ordinal']} started", flush=True)
            code = child.wait()
        report = load(case / 'journey/report.json') if (case / 'journey/report.json').exists() else {}
        evidence = report.get('defaultExternalEvidence', {})
        safe = all(report.get(k) is True for k in ['restored', 'originalApksRestored', 'ownedProbeRemoved',
                    'blurRestored', 'ownedPublicOcrInputRemoved', 'frozenInputsUnchanged'])
        inventory_ok = False
        if safe:
            before = case / 'journey/private-data-before.tar'
            after = case / 'journey/private-data-restored.tar'
            entries = restore.inventory(before, require_empty=True)
            inventory_ok = entries == restore.inventory(after, require_empty=True)
            assert inventory_ok and len(entries) == report['backup']['entries']
            assert entries == prepared_inventory, 'Prepared empty-account baseline changed between controls'
            save(case / 'independent-restoration-audit.json', dict(entries=len(entries),
                allContentsLinksModesMatch=True, preparedBaselineExactlyMatched=True,
                beforeSha256=sha(before), restoredSha256=sha(after)))
        source_ok = all(sha(root / name) == digest for name, digest in inputs['runtimeSourceFiles'].items())
        helpers_ok = all(sha(case / name) == digest for name, digest in sample['frozenFiles'].items())
        passed = bool(code == 0 and report.get('passed') is True and evidence.get('success') is True and
                      evidence.get('targetInstrumentationInjected') is False and evidence.get('javaScriptInjected') is False
                      and safe and inventory_ok and source_ok and helpers_ok)
        result = dict(objectCount=sample['objectCount'], ordinal=sample['ordinal'], driverExitCode=code,
            passed=passed, allOriginalStateRestored=safe, independentInventoryMatched=inventory_ok,
            sourceInputsUnchanged=source_ok, helpersUnchanged=helpers_ok,
            elapsedSeconds=round(time.monotonic()-began, 3), error=report.get('error'), fullRF312Accepted=False)
        save(case / 'terminal.json', result)
        outcomes.append(result)
        save(stage / 'external-progress.json', dict(requested=10, completed=len(outcomes), outcomes=outcomes))
        print(json.dumps(result), flush=True)
        if not passed:
            raise RuntimeError('Default control failed; preserve this cohort and stop without subset acceptance')
    terminal.update(allRequestedCompleted=True, stoppedOnFirstFailure=False, all10ControlsPassed=True)
except Exception as error:
    terminal['error'] = type(error).__name__+': '+str(error)
finally:
    terminal['outcomes'] = outcomes
    save(stage / 'external-terminal.json', terminal)
    print(json.dumps(dict(completed=len(outcomes), all10ControlsPassed=terminal.get('all10ControlsPassed', False))), flush=True)
if not terminal['allRequestedCompleted']:
    raise SystemExit(1)
