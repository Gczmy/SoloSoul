from pathlib import Path
import hashlib, importlib.util, io, json, tarfile

R = Path('D:/SoloSoul')
B = Path(__file__).parent
CONTROL = B / 'rf312-first-ocr-probe-round14-20261012'
S = B / 'rf312-first-ocr-probe-round15-20261012'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda raw: hashlib.sha256(raw).hexdigest()
inputs = load(S / 'inputs.json')
assert all(sha((R / n).read_bytes()) == h for n, h in inputs['runtimeSourceFiles'].items())
assert sha((S / 'AndroidMediaPerfInstrumentedTest.kt').read_bytes()) == inputs['runtimeTest']['homeTestSourceSha256']
assert 'performAction(' not in (S / 'AndroidMediaPerfInstrumentedTest.kt').read_text(encoding='utf-8')
red = load(CONTROL / 'red-100-diagnostic/device-files/report.json')
partial = load(CONTROL / 'first-100-diagnostic/device-files/report.json')
assert red['legacySimpleMotionEvent']['toolType'] == partial['legacySimpleMotionEvent']['toolType'] == 0
assert 'firstOcr' not in red and all(partial['firstOcr'][k] for k in ['hello', 'soloSoul', 'digits'])
for a, z in zip(red['nativePickerFileAction']['events'], partial['nativePickerFileAction']['events']):
    assert a['toolType'] == 0 and z['toolType'] == 1
    for key in ['action', 'source', 'pointerId', 'pointerCount', 'pressure', 'size', 'deviceId', 'x', 'y']:
        assert a[key] == z[key], key

spec = importlib.util.spec_from_file_location('finger_archive_restore', R / 'tauri/scripts/android-home-native-regression.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
restores, rows, targets = [], [], []
for count in [100, 5000]:
    d = S / f'first-{count}-diagnostic'
    receipt, driver, native = load(S / f'first-{count}-diagnostic.receipt.json'), load(d / 'report.json'), load(d / 'device-files/report.json')
    assert receipt['exitCode'] == 0 and all(receipt[k] for k in ['passed', 'restored', 'originalApksRestored', 'ownedProbeRemoved', 'blurRestored', 'sourceInputsUnchanged'])
    assert driver['ownedPublicOcrInputRemoved'] and native['success'] and len(native['phases']) == 12
    a, z = d / 'private-data-before.tar', d / 'private-data-restored.tar'
    inventory = helper.inventory(a, require_empty=True)
    assert inventory == helper.inventory(z)
    restores.append({'objectCount': count, 'entries': len(inventory), 'allContentsLinksModesMatch': True,
                     'beforeTarSha256': sha(a.read_bytes()), 'afterTarSha256': sha(z.read_bytes())})
    targets.extend([a, z])
    rows.append({'objectCount': count, 'samples': 1, 'actualExitCode': 0, 'all12PhasesPassed': True,
                 'firstOcr': native['firstOcr'], 'nativeFingerEvents': native['nativePickerFileAction'],
                 'legacySimpleMotionEvent': native['legacySimpleMotionEvent'], 'ocrWindowVisibility': native['ocrWindowVisibility'],
                 'manualOcrCorpusVisible': True, 'readiness': next(row['verified'] for row in load(S / 'all-finger-readiness-verification.json') if row['objectCount'] == count),
                 'phaseDurationsDiagnosticOnly': [{k: p[k] for k in ['name', 'success', 'durationMs', 'transportAttempts']} for p in native['phases']],
                 'originalApksPrivateDataBlurAndOwnedImageRestored': True, 'fullPerformanceAccepted': False})
(S / 'independent-restoration-audit.json').write_text(json.dumps(restores, indent=2) + '\n', encoding='utf-8')
for p in targets:
    assert p.resolve().is_relative_to(B.resolve()) and not p.is_symlink()
    p.unlink()
(S / 'private-backup-cleanup.json').write_text(json.dumps({'removed': len(targets), 'allPairsIndependentlyVerified': True, 'allFailuresRetained': True}) + '\n', encoding='utf-8')
target = R / 'docs/performance/rf312-android-finger-2026-10-12'
target.mkdir(exist_ok=False)
members = {}
for root in [CONTROL, S]:
    for p in root.rglob('*'):
        rel = p.relative_to(root)
        if 'project' in rel.parts or not p.is_file() or p.suffix.lower() not in {'.json', '.log', '.py', '.kt', '.png'}:
            continue
        assert not p.is_symlink()
        members[root.name + '/' + rel.as_posix()] = p.read_bytes()
for name in ['build-rf312-first-ocr-probe-round14.py', 'build-rf312-first-ocr-probe-round15.py', 'archive-rf312-finger-journey.py']:
    members['orchestration/' + name] = (B / name).read_bytes()
archive = target / 'raw.tar'
with tarfile.open(archive, 'w') as output:
    for name, raw in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode = len(raw), 0o644
        output.addfile(info, io.BytesIO(raw))
index = {'task': 'RF-312', 'scope': 'ordinary native finger event selection and strict draw readiness',
         'archiveSha256': sha(archive.read_bytes()), 'members': {n: {'bytes': len(raw), 'sha256': sha(raw)} for n, raw in sorted(members.items())},
         'privateDataCompiledProgramsKeysAndDatabasesExcluded': True}
with tarfile.open(archive) as source:
    assert {m.name for m in source} == set(members)
    for name, metadata in index['members'].items():
        raw = source.extractfile(name).read()
        assert len(raw) == metadata['bytes'] and sha(raw) == metadata['sha256']
(target / 'index.json').write_text(json.dumps(index, indent=2) + '\n', encoding='utf-8')
summary = {'task': 'RF-312', 'status': 'partial-verification', 'wholeRF312Accepted': False,
           'productSourceAndMainApkUnchanged': True, 'mainApkSha256': inputs['release']['apk']['sha256'],
           'signedIndependentTestApk': inputs['runtimeTest'], 'accessibilityFallbackAbsent': True,
           'control': {'sameApkWithinRound14': True, 'unknownPointerActualExitCode': 1,
                       'unknownPointerInputInjectedButPickerDidNotReturn': True, 'ordinaryFingerReachedKnownOcrCorpus': True,
                       'fingerRound14ActualExitCode': 1, 'laterScannedPdfPaintJointAssertionFailed': True,
                       'specificFailedAttachedShownFocusComponentNotSeparatelyRecorded': True,
                       'comparableSourceCoordsIdPressureSizeDeviceAndAction': True, 'onlyPointerToolTypeModeChanged': True},
           'runs': rows, 'restorationAudit': restores, 'controlRestorationAudit': load(CONTROL / 'independent-restoration-audit.json'),
           'readinessVerifierChecks': load(S / 'finger-readiness-verifier-checks.json'),
           'paintGateDefinition': 'actual resumed/attached/shown/focused Main WebView, real compositor callback/two frames; shared original10s and enclosing45s deadline; no softened condition',
           'firstOcrDefinition': rows[0]['firstOcr']['definition'], 'memoryDefinition': 'main-process PSS including runner, excluding renderer and continuous peak',
           'oldHistoricalFailuresAllUniquelyExplained': False,
           'mechanismReferences': ['https://developer.android.com/reference/android/view/MotionEvent.html',
                                   'https://developer.android.com/reference/android/view/MotionEvent.PointerProperties',
                                   'https://raw.githubusercontent.com/androidx/androidx/androidx-main/recyclerview/recyclerview-selection/src/main/java/androidx/recyclerview/selection/MotionEvents.java'],
           'deviceSelectorLibraryVersionIndependentlyDecompiledOrMatched': False,
           'remaining': ['repeated complete100/5000 cohorts and median/tail metrics', 'renderer/full-process memory and sampler attribution',
                         'process-cold launch', 'physical hardware and other platforms', 'stable search capture after IME transition'],
           'rawIndex': target.name + '/index.json'}
(R / 'docs/performance/rf312-android-finger-2026-10-12.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'members': len(members), 'archiveBytes': archive.stat().st_size, 'nativeControlsRetained': 2, 'wholeFingerJourneysPassed': 2, 'wholeRF312Accepted': False}))
