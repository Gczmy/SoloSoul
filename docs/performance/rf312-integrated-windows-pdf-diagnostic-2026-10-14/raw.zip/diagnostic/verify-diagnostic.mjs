import assert from 'node:assert/strict';
import { readFile, writeFile, lstat, realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { checkBound } from '../../tauri/scripts/native-perf-sdk-journey.mjs';
import { checkPdfDiagnostic } from '../../tauri/scripts/native-perf-pdf-contract.mjs';
import { pngCrc, inspectPdfPixels } from '../../tauri/scripts/native-perf-pdf-pixels.mjs';
import { describeAuthAttribution } from '../../tauri/scripts/native-perf-auth-contract.mjs';
import { checkMaintenanceAdmission } from '../../tauri/scripts/native-perf-maintenance-contract.mjs';
import { normalizeWindowsPath } from '../../tauri/scripts/native-perf-run.mjs';
import { verifyRetainedMedia } from '../rf1147-ocr-picker-settlement-20261014/verify-retained-media.mjs';
const repo='D:/SoloSoul',stage=path.join(repo,'build/rf312-current-windows-pdf-diagnostic-retry1-20261014');
const load=async file=>JSON.parse((await readFile(file,'utf8')).replace(/^\uFEFF/,''));
const sha=async file=>createHash('sha256').update(await readFile(file)).digest('hex');
const proof=await load(path.join(stage,'input-proof.json'));
assert.equal((await load(path.join(stage,'terminal.json'))).accepted,true);
assert.equal(await sha(proof.runtime.exe),proof.runtime.sha256);
for(const [name,hash] of Object.entries(proof.sources))assert.equal(await sha(path.join(repo,name)),hash,name);
for(const row of proof.runtime.resources){assert.equal(await sha(row.source),row.sha256);assert.equal(await sha(row.copy),row.sha256);}
const ids=new Set(),records=[];
for(const size of [100,5000]){
  const group=path.join(stage,`samples${size}`),report=await load(path.join(group,'native-perf-sdk-journey-results.json'));
  assert.equal(report.success,true);assert.equal(report.diagnosticOnly,true);assert.equal(report.performanceMetrics,null);
  assert.equal(report.samples.length,3);assert.equal(report.samplesRequested,3);assert.equal(report.fixture.objectCount,size);
  assert.equal(report.sourceUnchanged,true);assert.equal(report.interrupted,false);assert.deepEqual(report.summary,[]);
  assert.deepEqual(report.sourceBefore,report.sourceAfter);assert.equal(report.exeSha256,proof.runtime.sha256);
  for(const sample of report.samples){
    assert.equal(sample.success,true);assert.equal(sample.cleanupIntegrity.complete,true);
    const root=path.join(group,`sample-${String(sample.index).padStart(3,'0')}`);
    const owned=await load(path.join(root,'native-perf-owned.json'));assert.deepEqual(owned,sample.owned);
    assert.equal(ids.has(owned.runId),false);ids.add(owned.runId);
    const bound=checkBound(await load(path.join(root,'native-perf-sdk-journey-bound.json')),owned,sample.processId,sample.port);
    assert.deepEqual(bound,sample.bound);
    const native=await load(path.join(root,'native-perf-sdk-journey.json'));assert.deepEqual(native,sample.nativeProof);
    checkPdfDiagnostic(native,owned,bound,report.fixture);assert.equal(native.pdfDiagnostic.schemaVersion,4);
    const mediaHashes=await verifyRetainedMedia(owned,report.mediaFixture,root);
    const auth=await load(path.join(root,'native-perf-auth-attribution.json'));
    const attribution=describeAuthAttribution(auth,owned,bound);
    const admission=await load(path.join(root,'native-perf-maintenance-admission.json'));
    checkMaintenanceAdmission(admission,auth,owned,bound);
    const info=native.pdfDiagnostic.screenshot,file=path.join(root,info.fileName),stat=await lstat(file);
    assert.ok(stat.isFile()&&!stat.isSymbolicLink());assert.equal(stat.size,info.bytes);
    assert.equal(normalizeWindowsPath(await realpath(file)),normalizeWindowsPath(file));assert.equal(await sha(file),info.sha256);
    const bytes=await readFile(file);assert.deepEqual(bytes.subarray(0,8),Buffer.from([137,80,78,71,13,10,26,10]));
    let at=8,chunks=0;
    while(at<bytes.length){
      assert.ok(++chunks<=64&&at+12<=bytes.length);
      const length=bytes.readUInt32BE(at),next=at+12+length;assert.ok(next<=bytes.length);
      assert.equal(pngCrc(bytes.subarray(at+4,next-4)),bytes.readUInt32BE(next-4));at=next;
    }
    assert.equal(at,bytes.length);assert.equal(bytes.toString('ascii',12,16),'IHDR');
    const width=bytes.readUInt32BE(16),height=bytes.readUInt32BE(20);assert.equal(width,1200);assert.equal(height,831);
    assert.throws(()=>inspectPdfPixels(bytes),/PDF fixed viewport or RGBA format changed/);
    records.push({objects:size,index:sample.index,runId:owned.runId,pid:sample.processId,
      originalPdfSchema4ContractAccepted:true,authFlows:attribution.frontend.flows.length,
      authSource:auth.binding.source,maintenanceFailures:admission.failures.length,mediaHashes,
      screenshot:{...info,width,height,chunks,allChunkCrcVerified:true},
      originalFirstPage1028x749PixelGateAccepted:false,
      originalPixelGateError:'PDF fixed viewport or RGBA format changed',
      diagnosticOnly:true,performanceMetrics:null});
  }
}
assert.equal(ids.size,6);
await writeFile(path.join(stage,'independent-verification.json'),JSON.stringify({task:'RF-312',
  pdfCapabilityDiagnosticAccepted:true,accepted:true,groups:[100,5000],samplesPerGroup:3,distinctRuns:6,
  allOriginalPdfAndAuthMaintenanceContractsReplayed:true,sourceAndRuntimeAndResourcesUnchanged:true,
  mainScreenshotViewport:[1200,831],historicalFirstPageViewport:[1028,749],
  originalFirstPagePixelGateActuallyRefusedAllSix:true,originalPixelReferenceUnchanged:true,
  pdfFirstPagePerformanceAccepted:false,fullRF312Accepted:false,records},null,2)+'\n',{flag:'wx'});
process.stdout.write('Six original PDF schema4/auth/maintenance diagnostics independently verified; six actual current PNGs refused by unchanged historical first-page viewport guard\n');
