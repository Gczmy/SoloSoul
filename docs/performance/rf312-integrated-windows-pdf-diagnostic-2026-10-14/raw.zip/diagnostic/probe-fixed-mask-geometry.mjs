import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
const stage='D:/SoloSoul/build/rf312-current-windows-pdf-diagnostic-retry1-20261014';
const original='D:/SoloSoul/tauri/scripts/native-perf-pdf-pixels.mjs';
const source=await readFile(original,'utf8');
const roi='Object.freeze({ x: 180, y: 225, width: 430, height: 36 })';
assert.equal(source.split(roi).length,2);
// An offline, fixed geometry hypothesis only; preserve the original decoder,
// reference PNG, 530-pixel target and exact reference mask SHA unchanged.
const candidate=source.replace(/\b1028\b/g,'1200').replace(/\b749\b/g,'831')
  .replace(roi,'Object.freeze({ x: 266, y: 221, width: 430, height: 36 })');
const modulePath=stage+'/offline-fixed-mask-geometry-candidate.mjs';
await writeFile(modulePath,candidate,{flag:'wx'});
const {inspectPdfPixels}=await import(pathToFileURL(modulePath).href);
const results=[];
for(const objects of [100,5000])for(let i=1;i<=3;i++){
  const file=`${stage}/samples${objects}/sample-${String(i).padStart(3,'0')}/native-perf-sdk-pdf-screenshot.png`;
  const bytes=await readFile(file),result=inspectPdfPixels(bytes);
  results.push({objects,index:i,file,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),result});
}
await writeFile(stage+'/offline-fixed-mask-geometry-probe.json',JSON.stringify({task:'RF-312',
  offlineHypothesisOnly:true,productionFilesModified:false,originalReferenceMaskUnchanged:true,
  expectedViewport:[1200,831],fixedCandidateRoi:{x:266,y:221,width:430,height:36},
  originalDecoderSha256:createHash('sha256').update(source).digest('hex'),
  nativePdfPerformanceAccepted:false,results},null,2)+'\n',{flag:'wx'});
process.stdout.write(JSON.stringify(results.map(v=>({objects:v.objects,index:v.index,...v.result})))+'\n');
