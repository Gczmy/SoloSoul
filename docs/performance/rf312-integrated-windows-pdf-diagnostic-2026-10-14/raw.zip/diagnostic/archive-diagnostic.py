from pathlib import Path
import hashlib,json,os,zipfile
R=Path('D:/SoloSoul');S=Path(__file__).parent;F=R/'build/rf312-current-windows-pdf-diagnostic-20261014'
name='rf312-integrated-windows-pdf-diagnostic-2026-10-14';O=R/'docs/performance'/name
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as out:json.dump(v,out,indent=2);out.write('\n')
proof=load(S/'input-proof.json');verified=load(S/'independent-verification.json');cleanup=load(S/'accepted-cache-cleanup.json')
probe=load(S/'offline-fixed-mask-geometry-probe.json')
assert verified['accepted'] and len(verified['records'])==6 and verified['originalFirstPagePixelGateActuallyRefusedAllSix']
assert all(r['result']['matches'] and r['result']['darkPixels']==530 and r['result']['maskSha256']=='6f307e964c1dba0a23593241d6d193823cdf8feebb3946ca80b5af9a4a165044' for r in probe['results'])
assert cleanup['identitiesChecked']==60 and len(cleanup['removedCachePaths'])==48 and len(cleanup['preservedVaultAndRootFiles'])==162
assert cleanup['preservedBytesVerified'] and cleanup['processesTerminatedByThisTool']==0
assert all(not Path(p).exists() for p in cleanup['removedCachePaths'])
assert all(sha(Path(row['path']))==row['sha256'] for row in cleanup['preservedVaultAndRootFiles'])
assert all(sha(R/n)==h for n,h in proof['sources'].items())
pkg=proof['runtime'];assert sha(Path(pkg['exe']))==pkg['sha256']
assert all(sha(Path(row['source']))==sha(Path(row['copy']))==row['sha256'] for row in pkg['resources'])
first=load(F/'session-before-100.json');assert first['connectionState']==4 and not first['inputDesktopAvailable']
assert not (F/'100.live.json').exists() and not (F/'samples100').exists()
members={};excluded={'vault','app-data','profile','webview','temp','tmp','models','plugins','runtime','__pycache__'}
for prefix,directory in [('diagnostic',S),('desktop-preflight-refused',F)]:
    for root,dirs,files in os.walk(directory,followlinks=False):
        dirs[:]=[n for n in dirs if n not in excluded]
        for n in dirs:
            p=Path(root)/n;assert not p.is_symlink() and not p.stat().st_file_attributes&0x400
        for n in files:
            p=Path(root)/n
            if p.suffix not in ['.json','.log','.py','.mjs','.ps1','.png']:continue
            assert not p.is_symlink() and not p.stat().st_file_attributes&0x400
            members[prefix+'/'+p.relative_to(directory).as_posix()]=p
for n in ['prepare-rf312-current-windows-pdf-diagnostic-original-cli-name-20261014.py',
    'prepare-rf312-current-windows-pdf-diagnostic-20261014.py','run-rf312-current-windows-pdf-diagnostic-20261014.py',
    'prepare-rf312-current-windows-pdf-diagnostic-retry1-20261014.py','run-rf312-current-windows-pdf-diagnostic-retry1-20261014.py']:
    members['helpers/'+n]=R/'build'/n
for n in ['tauri/src-tauri/src/native_perf/sdk_pdf.rs','tauri/src-tauri/src/native_perf/sdk_pdf_pixels.rs',
    'tauri/scripts/native-perf-pdf-contract.mjs','tauri/scripts/native-perf-pdf-pixels.mjs',
    'tauri/scripts/native-perf-pdf-preview-contract.mjs']:
    members['sources/'+n]=R/n
O.mkdir(exist_ok=False);rows=[]
with zipfile.ZipFile(O/'raw.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for n,p in sorted(members.items()):
        data=p.read_bytes();z.writestr(n,data);rows.append(dict(member=n,source=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(O/'raw.zip') as z:
    assert z.testzip() is None
    for row in rows:
        data=z.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',dict(task='RF-312',members=rows,allLengthsSha256AndCrcVerified=True,programsVaultsResourcesAndCachesExcluded=True))
(O/'.gitattributes').write_text('raw.zip -text\n',encoding='utf-8',newline='\n')
put(O.with_suffix('.json'),dict(task='RF-312',pdfCapabilityDiagnosticAccepted=True,pdfFirstPagePerformanceAccepted=False,
    performanceMetrics=None,fullRF312Accepted=False,goal='active',sourceHead='6875946682a7f49ef360c4491934251f0082ae35',
    runtimeSha256=pkg['sha256'],sourceCount=1983,compiledSourcesDifferOnlyTwoExternalNodeFiles=True,
    samplesPerGroup=3,groups=[100,5000],nativeJourneys=6,diagnosticSchemaVersion=4,
    originalPdfAuthMaintenanceContractsReplayed=True,originalFirstPagePixelGateRefusedAllSix=True,
    currentMainViewport=[1200,831],originalFirstPageViewport=[1028,749],originalReferenceImageAndMaskUnchanged=True,
    sameMainCaptureAndParametersUsedByDiagnosticAndFirstPage=True,
    offlineGeometryOnly=dict(viewport=[1200,831],roi=[266,221,430,36],sixActualScreenshotsMatchOriginal530PixelMask=True,
        productionFilesModified=False,nativePerformanceAccepted=False),
    desktopRefusalPreserved=dict(callerSession=1,state='Disconnected',inputDesktopError=5,guiRunsStarted=0),
    desktopExplicitlyReconnectedAndRetriedNewNamespace=True,
    cleanup=dict(identitiesChecked=60,cachePathsRemoved=48,linksUnlinked=0,preservedFiles=162,bytesVerified=True,otherProcessesTerminated=0),
    independentVerification=verified,archive=dict(path=name+'/raw.zip',members=len(rows),bytes=(O/'raw.zip').stat().st_size,sha256=sha(O/'raw.zip'),allLengthsSha256AndCrcVerified=True)))
p=R/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';t=p.read_text(encoding='utf-8')
old='- 任务总数：**338**（P1：60；P2：277；P3：1）。';assert t.count(old)==1
t=t.replace(old,'- 任务总数：**339**（P1：60；P2：278；P3：1）。',1)
old='- 已关闭：**327 / 338**；实际修复（已关闭）：327；排除：0；待验证/阻塞：5（RF-112、RF-121、RF-312、RF-1109、RF-1128）；暂缓：0；进行中：0；待执行：6。';assert t.count(old)==1
t=t.replace(old,old.replace('327 / 338','327 / 339').replace('待执行：6','待执行：7'),1)
assert t.count('、RF-1148（RF-904')==1;t=t.replace('、RF-1148（RF-904','、RF-1148、RF-1149（RF-904',1)
row='| 338 | [RF-1148](#rf-1148) | P2 | 认证诊断外部消费者与当前SDK固定路由一致 | RF-1147原生OCR记录及独立Node拒绝；RF-1147独立提交后实施 | [x] 完成 |'
assert t.count(row)==1;t=t.replace(row,row+'\n| 339 | [RF-1149](#rf-1149) | P2 | 固定PDF首屏测量与当前正式setup窗口几何一致 | 当前六次schema4诊断及原像素门禁拒绝 | [ ] 待执行 |',1)
start=t.index('- 当前处理：');end=t.index('\n',start)
t=t[:start]+'- 当前处理：RF-312当前Windows六次PDF能力诊断已独立复核/清理/归档；新RF-1149固定几何差异待实施，首屏性能未验。此前7个提交已按明确元数据授权推送、0/0干净；用户已准备前台，RF-121完整矩阵仍待执行，goal active。'+t[end:]
t+='\n\n### RF-312 当前Windows PDF能力诊断（2026-10-14，部分验收）\n\n'
t+='- 截至`687594668`的7个独立提交及本机路径/构建/运行元数据获明确授权，实际推送完成，ls-remote相同SHA、上游0/0、完整工作区干净。PDF首次入口在Session1 Disconnected/InputDesktop error5处拒绝，零GUI/零输入；用户连接解锁并最小化Codex后，新记录命名空间复跑，100/5000各3/3原schema4诊断与driver退出0。源码/同GUI/94资源/公开输入保持，不重跑无关默认检查。\n'
t+='- 原PDF诊断、同runId/PID/frame/loader/timeOrigin、当前认证/维护、截图路径/长度/SHA及PNG chunk CRC独立复核通过；两张不同SHA截图已查看，公开PDF首页文字可见。schema4仍renderVerified=false、performanceMetrics=null，不能称PDF首屏性能验收。\n'
t+='- 诊断和首屏代码都在同一main上使用完全相同Page.captureScreenshot参数。六张实际PNG为1200×831，旧1028×749/ROI(180,225,430,36)解码器真实拒绝。只在离线副本测试固定新ROI(266,221,430,36)，六张均得到原530个深色像素和完全相同`6f307e…165044`掩码SHA；原参考图片/掩码/生产源码未修改。确认为固定窗口布局/坐标合同差异，另登记RF-1149，不通过任意尺寸、寻字或放宽像素条件绕过。\n'
t+=f'- fresh CIM确认60个实际身份退出，清理48个精确自有缓存、无联接，162份公开Vault/截图/证明与日志字节保持，未停止其他进程。[结构化诊断](performance/{name}.json)及[{len(rows)}成员索引](performance/{name}/index.json)长度/SHA/ZIP CRC回读通过，排除程序、资源实体、Vault/缓存。累计327/339关闭，原5待验证/6前置任务及新RF-1149保持；goal active，继续真实首屏测量和RF-121矩阵。独立本地提交。\n'
t+='\n\n### RF-1149\n\n**固定PDF首屏测量与当前正式setup窗口几何一致** · P2 · 来源：当前真实PDF诊断的六张截图与原像素门禁。\n\n'
t+='- **入口：**仅非默认Windows native-perf的Rust/Node首屏像素合同及相关回归；当前默认客户端/前端/资源保持。\n'
t+='- **证据：**当前main截图1200×831，旧固定1028×749门禁拒绝；离线固定ROI平移后六张均完全等于原530像素/掩码SHA。诊断与首屏使用同一main和相同截图参数，不能继续宣称旧视口可验当前GUI。\n'
t+='- **执行：**显式声明当前固定几何及版本，保留历史固定记录的消费能力和原参考/掩码；每一被声明的版本只接受自己的固定尺寸/ROI，不自动搜索、裁切或缩放参考，不接受任意窗口。原两次稳定/至少250ms间隔、16次/25秒、主文档/子树/资源/可信输入/128调用及全行程预算保持。\n'
t+='- **验收：**实际当前及历史PNG红绿、空白/偏移/缺字/未知视口和格式/CRC/版本混用均拒绝；原生相关Rust/严格Clippy/格式、相关与完整Node检查；新冻结GUI100/5000各三次真实首屏完整行程，逐PNG独立解码和归属/清理通过。旧诊断/拒绝保留，不将离线六张算作性能样本。单项独立提交。\n'
p.write_text(t,encoding='utf-8',newline='\n')
print(json.dumps(dict(task='RF-312',capabilityOnly=True,members=len(rows),newQueuedTask='RF-1149',closed='327/339')))
