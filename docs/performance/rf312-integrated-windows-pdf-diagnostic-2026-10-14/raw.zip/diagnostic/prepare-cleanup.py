from pathlib import Path
R=Path('D:/SoloSoul');S=Path(__file__).parent
text=(R/'build/rf1147-ocr-picker-settlement-20261014/prepare-accepted-cleanup-retry1.py').read_text(encoding='utf-8')
text=text.replace('rf1147-ocr-acceptance-retry1-20261014','rf312-current-windows-pdf-diagnostic-retry1-20261014')
text=text.replace('rf1147NativeAcceptanceVerified','pdfCapabilityDiagnosticVerified')
target=S/'prepare-cleanup-adapted.py';compile(text,str(target),'exec')
with target.open('x',encoding='utf-8',newline='\n') as out:out.write(text)
print('Original terminal-owned identity/path/reparse/Vault cleanup guards adapted to completed six PDF capability diagnostics; no performance acceptance')
