from pathlib import Path
import json
R=Path('D:/SoloSoul');S=R/'build/rf312-current-windows-pdf-diagnostic-retry1-20261014'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert load(S/'terminal.json')['accepted'] and load(S/'independent-verification.json')['accepted']
proof=load(S/'input-proof.json');groups=[]
for size in [100,5000]:
    report=load(S/f'samples{size}/native-perf-sdk-journey-results.json')
    assert report['success'] and len(report['samples'])==3
    samples=[]
    for sample in report['samples']:
        assert sample['success'] and sample['cleanupIntegrity']['complete']
        ids={(p['pid'],p['creationMs']) for n in ['beforeSnapshot','afterSnapshot'] for p in sample[n]['processes']}
        assert len(ids)>=9
        samples.append(dict(index=sample['index'],runId=sample['owned']['runId'],pid=sample['processId'],
            recordedIdentities=[dict(pid=p,creationMs=t) for p,t in sorted(ids)]))
    groups.append(dict(objects=size,terminal=True,samples=samples))
with (S/'accepted-cleanup-plan.json').open('x',encoding='utf-8',newline='\n') as out:
    json.dump(dict(pdfCapabilityDiagnosticVerified=True,groups=groups),out,indent=2);out.write('\n')
text=(R/'build/rf1146-native-ocr-20261014/cleanup-failed-owned.ps1').read_text(encoding='utf-8')
text=text.replace('rf1146-native-ocr-20261014','rf312-current-windows-pdf-diagnostic-retry1-20261014')
text=text.replace('failed-cleanup-plan.json','accepted-cleanup-plan.json').replace('failed-cache-cleanup','accepted-cache-cleanup')
old="if (-not $validation.terminalOwnedSamplesCleanupEligible -or $validation.nativeMatrixAccepted -or $validation.failedSamplesAccepted -or $validation.groups.Count -ne 1)"
assert text.count(old)==1
text=text.replace(old,"if (-not $validation.pdfCapabilityDiagnosticVerified -or $validation.groups.Count -ne 2)")
text=text.replace('Count -ne 24','Count -ne 48').replace('Exact twenty-four owned cache paths required','Exact forty-eight owned cache paths required')
old_exe='D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\current-windows-native-retry1-20261014\\runtime\\bin\\solo_soul.exe'
assert text.count(old_exe)==1
text=text.replace(old_exe,str(Path(proof['runtime']['exe'])))
with (S/'cleanup-accepted-owned.ps1').open('x',encoding='utf-8',newline='\n') as out:out.write(text)
print('Six actual terminal native runs; 48 absolute owned cache targets prepared with original identity/reparse/Vault preservation guards')
