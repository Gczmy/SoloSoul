from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');T=R/'build';B=T/'rf1147-ocr-picker-settlement-20261014';S=T/'rf312-current-windows-pdf-diagnostic-20261014'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pkg=load(B/'runtime-package.json');compiled=load(B/'sources.json');current={n:sha(R/n) for n in compiled}
changed={n:dict(compiled=h,current=current[n]) for n,h in compiled.items() if current[n]!=h}
assert set(changed)=={'tauri/scripts/native-perf-auth-contract.mjs','tauri/scripts/native-perf-auth-attribution.test.mjs'}
assert sha(Path(pkg['exe']))==pkg['sha256'] and all(sha(Path(x['source']))==sha(Path(x['copy']))==x['sha256'] for x in pkg['resources'])
front=load(B/'frontend.json');assert all(sha(R/'tauri/dist'/n)==v['sha256'] for n,v in front['files'].items())
assert (R/'tauri/scripts/native-perf-pdf.mjs').is_file()
proof=load(T/'rf1147-ocr-acceptance-retry1-20261014/input-proof.json')
proof.update(mode='pdf-diagnostic',validationHead='6875946682a7f49ef360c4491934251f0082ae35',sources=current,
    sourceHasUncommittedRf1147Fix=False,diagnosticOnly=True,performanceMetrics=None,
    currentGuiNotRebuilt=True,compiled1983InputsDifferOnlyTwoExternalNodeFiles=True,
    compiledSourceDifferences=changed,defaultRustAndFrontendAnd94ResourceBytesUnchanged=True,
    originalPdfDiagnosticSchema4AndBudgetsAndGuardsPreserved=True)
for key in ['initialWholeTreeSettlementWithinOriginal25SecondBudgetAdded','originalOwnershipMessageAndInputChecksPreserved']:
    proof.pop(key,None)
for fixture in proof['fixtures']:
    p=Path(fixture['path']);assert {f.relative_to(p).as_posix():sha(f) for f in p.rglob('*') if f.is_file()}==fixture['files']
S.mkdir(exist_ok=False)
with (S/'input-proof.json').open('x',encoding='utf-8',newline='\n') as out:json.dump(proof,out,indent=2);out.write('\n')
runner=(T/'run-rf1146-native-media-ocr-20261014.py').read_text(encoding='utf-8')
runner=runner.replace("['media','ocr']","['pdf']").replace("S=T/f'rf1146-native-{mode}-20261014'","S=T/'rf312-current-windows-pdf-diagnostic-20261014'")
runner=runner.replace('rf1146-native-{mode}-20261014/session-before-','rf312-current-windows-pdf-diagnostic-20261014/session-before-')
runner=runner.replace('rf1146-native-{mode}-session-{size}-20261014','rf312-current-windows-pdf-diagnostic-session-{size}-20261014')
target=T/'run-rf312-current-windows-pdf-diagnostic-20261014.py';compile(runner,str(target),'exec')
with target.open('x',encoding='utf-8',newline='\n') as out:out.write(runner)
print('Current frozen GUI PDF schema4 capability diagnostic prepared:100/5000 each3; original masks/budgets/identity/readiness unchanged; no PDF performance claim')
