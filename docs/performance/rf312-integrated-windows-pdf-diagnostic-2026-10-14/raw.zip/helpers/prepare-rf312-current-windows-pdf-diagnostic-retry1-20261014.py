from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');T=R/'build';old='rf312-current-windows-pdf-diagnostic-20261014';new='rf312-current-windows-pdf-diagnostic-retry1-20261014'
F=T/old;S=T/new
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
first=load(F/'session-before-100.json')
assert first['connectionState']==4 and not first['inputDesktopAvailable']
assert not (F/'100.live.json').exists() and not (F/'samples100').exists()
proof=load(F/'input-proof.json');assert all(sha(R/n)==h for n,h in proof['sources'].items())
pkg=proof['runtime'];assert sha(Path(pkg['exe']))==pkg['sha256']
assert all(sha(Path(x['source']))==sha(Path(x['copy']))==x['sha256'] for x in pkg['resources'])
for fixture in proof['fixtures']:
    p=Path(fixture['path']);assert {f.relative_to(p).as_posix():sha(f) for f in p.rglob('*') if f.is_file()}==fixture['files']
proof.update(originalDesktopPreflightRefusalPreserved=True,userConfirmedConnectedUnlockedAndCodexMinimized=True,
    originalPreflightRefusalSource=str(F/'session-before-100.json'),originalPreflightRefusalSha256=sha(F/'session-before-100.json'))
S.mkdir(exist_ok=False)
with (S/'input-proof.json').open('x',encoding='utf-8',newline='\n') as out:json.dump(proof,out,indent=2);out.write('\n')
text=(T/('run-'+old+'.py')).read_text(encoding='utf-8')
assert text.count('rf312-current-windows-pdf-diagnostic-session-')==1
text=text.replace(old,new).replace('rf312-current-windows-pdf-diagnostic-session-','rf312-current-windows-pdf-diagnostic-retry1-session-')
target=T/('run-'+new+'.py');compile(text,str(target),'exec')
with target.open('x',encoding='utf-8',newline='\n') as out:out.write(text)
print('PDF diagnostic resumed in new exact output/probe namespace after explicit desktop confirmation; old Disconnected/zero-GUI refusal preserved')
