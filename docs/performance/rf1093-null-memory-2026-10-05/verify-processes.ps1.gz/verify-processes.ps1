﻿$ErrorActionPreference='Stop'
$rfStage='C:\Users\40299571\AppData\Local\Temp\ss-rf1093-null-memory-20261005'
$records=@(Get-Content -Raw -LiteralPath (Join-Path $rfStage 'owned-identities.json') -Encoding UTF8 | ConvertFrom-Json)
$live=@(Get-CimInstance Win32_Process -Property ProcessId,CreationDate,Name)
if (@($live | Where-Object {[int]$_.ProcessId -eq $PID}).Count -ne 1) {throw 'Fresh CIM does not contain its current querying process'}
$checks=@()
foreach ($record in $records) {
  $rows=@($live | Where-Object { [int]$_.ProcessId -eq [int]$record.pid })
  $same=$false; $unverifiable=($rows.Count -gt 1)
  foreach ($row in $rows) {
    if ($row.CreationDate -and $row.Name) {
      $creation=([DateTimeOffset]$row.CreationDate.ToUniversalTime()).ToUnixTimeMilliseconds()
      if ($creation -eq [long]$record.creationMs -and $row.Name -ieq $record.executableName) { $same=$true }
    } else { $unverifiable=$true }
  }
  $checks+=@([ordered]@{pid=$record.pid;creationMs=$record.creationMs;executableName=$record.executableName;sameIdentityLive=$same;unverifiableCurrentPidPresent=$unverifiable;currentPidPresent=($rows.Count -gt 0)})
}
$none=@($checks | Where-Object {$_.sameIdentityLive -or $_.unverifiableCurrentPidPresent}).Count -eq 0
[ordered]@{at=[DateTime]::UtcNow.ToString('o');queryProperties=@('ProcessId','CreationDate','Name');identityDefinition='PID + CreationDate Unix milliseconds + executable basename';noneOwnedLive=$none;checks=$checks;extraProcessesTerminated=0} | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $rfStage 'final-process-check.json')
if (!$none) { throw 'Recorded owned identity remains live; no cache cleanup authorized by this check' }
Write-Output ('Verified '+$checks.Count+' identities; none owned live; no extra processes terminated')
