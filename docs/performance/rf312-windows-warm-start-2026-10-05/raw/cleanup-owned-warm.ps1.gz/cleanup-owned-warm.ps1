﻿param([Parameter(Mandatory=$true)][string]$StageRoot)
$ErrorActionPreference='Stop'
function TaskFull([string]$Text) {
    if($Text.StartsWith('\\?\')){$Text=$Text.Substring(4)}
    return [IO.Path]::GetFullPath($Text).TrimEnd('\')
}
function TaskSame([string]$Left,[string]$Right) { return (TaskFull $Left).Equals((TaskFull $Right),[StringComparison]::OrdinalIgnoreCase) }
function TaskOrdinary([string]$ItemPath) {
    $item=Get-Item -LiteralPath $ItemPath -Force
    if(-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {throw 'Cleanup directory is not ordinary'}
    if(-not (TaskSame $item.FullName $ItemPath)){throw 'Cleanup directory path changed'}
    return $item
}
function TaskTree([string]$ItemPath) {
    $pending=[Collections.Generic.Stack[string]]::new();$pending.Push($ItemPath)
    while($pending.Count -gt 0){
        $folder=$pending.Pop();$null=TaskOrdinary $folder
        foreach($entry in Get-ChildItem -LiteralPath $folder -Force){
            if($entry.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Cleanup tree contains a reparse entry'}
            if($entry.PSIsContainer){$pending.Push($entry.FullName)}
        }
    }
}
$taskStage=TaskFull $StageRoot
if(-not (TaskSame $taskStage 'C:\Users\40299571\AppData\Local\Temp\ss-rf312-warm-20261005')){throw 'Only the explicitly owned warm-stage root is allowed'}
$null=TaskOrdinary $taskStage
$taskRoots=@();$taskIdentities=@();$taskVerified=@();$taskTargets=@();$taskLinks=@()
foreach($group in @('samples100','samples5000')){
    $groupDir=Join-Path $taskStage $group;$null=TaskOrdinary $groupDir
    $report=Get-Content -LiteralPath (Join-Path $groupDir 'report.json') -Raw -Encoding utf8 | ConvertFrom-Json
    if(-not $report.summary.complete -or $report.samples.Count -ne 5){throw 'Only complete verified five-pair groups can be cleaned'}
    foreach($sample in $report.samples){
        if(-not $sample.success -or $sample.cleanupIncomplete -or -not $sample.first.cleanupIntegrity.complete -or -not $sample.warm.cleanupIntegrity.complete){throw 'Paired owned process exit is incomplete'}
        $root=TaskFull $sample.root
        $expected=Join-Path $groupDir ('sample-'+([int]$sample.index).ToString('000'))
        if(-not(TaskSame $root $expected)){throw 'Sample root changed'}
        $null=TaskOrdinary $root
        $owned=Get-Content -LiteralPath (Join-Path $root 'native-perf-owned.json') -Raw -Encoding utf8 | ConvertFrom-Json
        if($owned.schemaVersion -ne 1 -or $owned.scope -ne 'windows-native-perf-owned' -or $owned.nativePerfFeature -ne $true -or $owned.runId -notmatch '^[a-f0-9]{32}$' -or $owned.identifier -ne ('com.solosoul.rf312perf.'+$owned.runId) -or -not(TaskSame $owned.root $root)){throw 'Sample ownership marker is invalid'}
        foreach($entry in @($sample.first,$sample.warm)){
            foreach($identity in $entry.identities){
                if([long]$identity.pid -le 0 -or [long]$identity.creationMs -le 0 -or $identity.executableName -notmatch '^[^\\/:\x00-\x1f]{1,260}$'){throw 'Invalid bounded owned process identity'}
                $taskIdentities+=$identity
            }
        }
        $roaming=Join-Path ([Environment]::GetFolderPath('ApplicationData')) $owned.identifier
        $local=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) $owned.identifier
        if(-not(TaskSame $owned.roaming $roaming) -or -not(TaskSame $owned.local $local)){throw 'Known-folder owner namespace changed'}
        $taskRoots+=$root
        foreach($child in @('app-data','plugins','profile','temp','webview','models')){$taskTargets+=Join-Path $root $child}
        $taskTargets+=@($roaming,$local)
    }
}
$taskPids=@($taskIdentities | ForEach-Object {[uint32]$_.pid} | Sort-Object -Unique)
for($offset=0;$offset -lt $taskPids.Count;$offset+=32){
    $last=[Math]::Min($offset+31,$taskPids.Count-1);$batch=@($taskPids[$offset..$last]);$filter=($batch|ForEach-Object{'ProcessId='+$_}) -join ' OR '
    $rows=@(Get-CimInstance Win32_Process -Filter $filter -Property ProcessId,CreationDate,Name)
    foreach($id in @($taskIdentities | Where-Object {$batch -contains [uint32]$_.pid})){
        $current=@($rows|Where-Object{$_.ProcessId -eq $id.pid})
        if($current.Count -gt 1){throw 'Fresh process metadata is ambiguous'}
        $state='absent'
        if($current.Count -eq 1){
            if($null -eq $current[0].CreationDate -or [string]::IsNullOrEmpty($current[0].Name)){throw 'Fresh process metadata is incomplete'}
            $birth=([DateTimeOffset]$current[0].CreationDate.ToUniversalTime()).ToUnixTimeMilliseconds()
            if($birth -eq [long]$id.creationMs){throw 'An owned process is still live or has ambiguous creation metadata'}
            $state='pid-reused-with-different-creation'
        }
        $taskVerified+=[ordered]@{pid=$id.pid;creationMs=$id.creationMs;executableName=$id.executableName;status=$state}
    }
}
# Model links are removed as entries; their targets remain in the frozen resource directory.
foreach($root in $taskRoots){
    $modelDir=Join-Path $root 'models';$null=TaskOrdinary $modelDir
    foreach($entry in Get-ChildItem -LiteralPath $modelDir -Force){
        if($entry.Attributes -band [IO.FileAttributes]::ReparsePoint){
            if(-not(TaskSame (Split-Path -Parent $entry.FullName) $modelDir) -or $entry.LinkType -notin @('SymbolicLink','Junction')){throw 'Unexpected owned model link'}
            $taskLinks+=[ordered]@{path=$entry.FullName;linkType=$entry.LinkType;targets=@($entry.Target)}
            Remove-Item -LiteralPath $entry.FullName -Force
        }
    }
}
$taskDeleted=@()
foreach($candidate in $taskTargets){
    $absolute=TaskFull $candidate
    if(Test-Path -LiteralPath $absolute){
        $null=TaskOrdinary $absolute;TaskTree $absolute
        # Every candidate is derived from the checked exact root or known-folder namespace above.
        if(-not($taskTargets|Where-Object{TaskSame $_ $absolute})){throw 'Cleanup target escaped the explicit set'}
        Remove-Item -LiteralPath $absolute -Recurse -Force
        $taskDeleted+=$absolute
    }
}
$receipt=[ordered]@{observedAt=(Get-Date).ToUniversalTime().ToString('o');stageRoot=$taskStage;pairRoots=$taskRoots;verifiedIdentities=$taskVerified;processIdentityCount=$taskVerified.Count;unlinkedModelEntries=$taskLinks;removedCachePaths=$taskDeleted;preserved=@('Vault','startup proofs','owner/consumed/ticket/stop markers','reports','all EXEs and frozen resources','public source fixtures');complete=$true}
$text=$receipt|ConvertTo-Json -Depth 12
[IO.File]::WriteAllText((Join-Path $taskStage 'cleanup.json'),$text,[Text.UTF8Encoding]::new($false))
Write-Output ('Verified identities: '+$taskVerified.Count+'; cache paths removed: '+$taskDeleted.Count+'; model links unlinked: '+$taskLinks.Count)
