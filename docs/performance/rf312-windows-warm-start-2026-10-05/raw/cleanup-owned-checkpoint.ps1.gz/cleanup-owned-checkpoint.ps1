param([Parameter(Mandatory=$true)][string]$StageRoot)
$ErrorActionPreference='Stop'
function TaskFull([string]$Text) {
    if($Text.StartsWith('\\?\')){$Text=$Text.Substring(4)}
    return [IO.Path]::GetFullPath($Text).TrimEnd('\')
}
function TaskSame([string]$Left,[string]$Right) { return (TaskFull $Left).Equals((TaskFull $Right),[StringComparison]::OrdinalIgnoreCase) }
function TaskOrdinary([string]$ItemPath) {
    $item=Get-Item -LiteralPath $ItemPath -Force
    if(-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {throw 'Cleanup directory is not ordinary'}
    if(-not (TaskSame $item.FullName $ItemPath)){throw 'Cleanup directory path changed'}
    return $item
}
function TaskTree([string]$ItemPath) {
    $pending=[Collections.Generic.Stack[string]]::new();$pending.Push($ItemPath)
    while($pending.Count -gt 0){
        $folder=$pending.Pop();$null=TaskOrdinary $folder
        foreach($entry in Get-ChildItem -LiteralPath $folder -Force){
            if($entry.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Cleanup tree contains a reparse entry'}
            if($entry.PSIsContainer){$pending.Push($entry.FullName)}
        }
    }
}
$taskStage=TaskFull $StageRoot
if(-not (TaskSame $taskStage 'C:\Users\40299571\AppData\Local\Temp\ss-rf312-warm-20261005')){throw 'Only the explicitly owned warm-stage root is allowed'}
$null=TaskOrdinary $taskStage
$taskRoots=@();$taskIdentities=@();$taskVerified=@();$taskTargets=@();$taskLinks=@();$taskGroupChecks=@()
$taskPackagedBase='C:\Users\40299571\AppData\Local\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache'
$taskRoamingBases=@([Environment]::GetFolderPath('ApplicationData'),(Join-Path $taskPackagedBase 'Roaming'))
$taskLocalBases=@([Environment]::GetFolderPath('LocalApplicationData'),(Join-Path $taskPackagedBase 'Local'))
foreach($group in @('samples100','samples100-checkpoint','samples5000-checkpoint')){
    $groupDir=Join-Path $taskStage $group;$null=TaskOrdinary $groupDir
    $report=Get-Content -LiteralPath (Join-Path $groupDir 'report.json') -Raw -Encoding utf8 | ConvertFrom-Json
    $failed=$group -eq 'samples100'
    if(-not $report.sourceUnchanged){throw 'Source fixture changed'}
    if($failed){
        if($report.summary.complete -or $report.samples.Count -ne 1 -or $report.samples[0].success -or $null -ne $report.summary.metrics){throw 'Original failed group changed'}
    } elseif(-not $report.summary.complete -or $report.samples.Count -ne 5){throw 'Final five-pair group incomplete'}
    foreach($sample in $report.samples){
        if(-not $sample.first.cleanupIntegrity.complete){throw 'First GUI exit incomplete'}
        $entries=@($sample.first)
        if(-not $failed){
            if(-not $sample.success -or $sample.cleanupIncomplete -or -not $sample.warm.cleanupIntegrity.complete -or -not $sample.originalEvidenceUnchanged -or -not $sample.fixtureAfterWarm.immutableFilesUnchanged){throw 'Paired integrity incomplete'}
            $entries+=@($sample.warm)
        }
        $root=TaskFull $sample.root
        $expected=Join-Path $groupDir ('sample-'+([int]$sample.index).ToString('000'))
        if(-not(TaskSame $root $expected)){throw 'Sample root changed'}
        $null=TaskOrdinary $root
        $owned=Get-Content -LiteralPath (Join-Path $root 'native-perf-owned.json') -Raw -Encoding utf8 | ConvertFrom-Json
        if($owned.schemaVersion -ne 1 -or $owned.scope -ne 'windows-native-perf-owned' -or $owned.nativePerfFeature -ne $true -or $owned.runId -notmatch '^[a-f0-9]{32}$' -or $owned.identifier -ne ('com.solosoul.rf312perf.'+$owned.runId) -or -not(TaskSame $owned.root $root)){throw 'Ownership marker invalid'}
        if(-not(TaskSame $owned.vault (Join-Path $root 'vault')) -or -not(TaskSame $owned.webview (Join-Path $root 'webview')) -or -not(TaskSame $owned.profile (Join-Path $root 'profile'))){throw 'Private namespace changed'}
        $roaming=TaskFull $owned.roaming;$local=TaskFull $owned.local
        if(-not($taskRoamingBases|Where-Object{TaskSame $roaming (Join-Path $_ $owned.identifier)}) -or -not($taskLocalBases|Where-Object{TaskSame $local (Join-Path $_ $owned.identifier)})){throw 'Known-folder owner namespace changed'}
        if($owned.ownedPaths.Count -ne 3 -or -not(TaskSame $owned.ownedPaths[0] $root) -or -not(TaskSame $owned.ownedPaths[1] $roaming) -or -not(TaskSame $owned.ownedPaths[2] $local)){throw 'Owner paths disagree'}
        foreach($entry in $entries){
            foreach($identity in $entry.identities){
                if([long]$identity.pid -le 0 -or [long]$identity.creationMs -le 0 -or $identity.executableName -notmatch '^[^\\/:\x00-\x1f]{1,260}$'){throw 'Invalid bounded process identity'}
                $taskIdentities+=$identity
            }
        }
        $taskRoots+=$root
        foreach($child in @('app-data','plugins','profile','temp','webview','models')){$taskTargets+=Join-Path $root $child}
        $taskTargets+=@($roaming,$local)
    }
    $taskGroupChecks+=[ordered]@{group=$group;sampleCount=$report.samples.Count;historicalFailureRetained=$failed}
}
# The historical unawaited diagnostic retained no process handle. Query only test EXE paths, never foreign command lines.
$taskExes=@('bin','bin-markers','bin-checkpoint')|ForEach-Object{Join-Path $taskStage ($_.ToString()+'\solo_soul.exe')}
$taskExeRows=@(Get-CimInstance Win32_Process -Filter "Name='solo_soul.exe'" -Property ProcessId,CreationDate,Name,ExecutablePath)
if(@($taskExeRows|Where-Object{[string]::IsNullOrEmpty($_.ExecutablePath) -or $_.ExecutablePath -in $taskExes}).Count -gt 0){throw 'Owned or ambiguous executable still live'}
$taskPids=@($taskIdentities|ForEach-Object{[uint32]$_.pid}|Sort-Object -Unique)
for($offset=0;$offset -lt $taskPids.Count;$offset+=32){
    $last=[Math]::Min($offset+31,$taskPids.Count-1);$batch=@($taskPids[$offset..$last]);$filter=($batch|ForEach-Object{'ProcessId='+$_}) -join ' OR '
    $rows=@(Get-CimInstance Win32_Process -Filter $filter -Property ProcessId,CreationDate,Name)
    foreach($id in @($taskIdentities|Where-Object{$batch -contains [uint32]$_.pid})){
        $current=@($rows|Where-Object{$_.ProcessId -eq $id.pid})
        if($current.Count -gt 1){throw 'Fresh process metadata ambiguous'}
        $state='absent'
        if($current.Count -eq 1){
            if($null -eq $current[0].CreationDate -or [string]::IsNullOrEmpty($current[0].Name)){throw 'Fresh process metadata incomplete'}
            $birth=([DateTimeOffset]$current[0].CreationDate.ToUniversalTime()).ToUnixTimeMilliseconds()
            if($birth -eq [long]$id.creationMs){throw 'Owned process still live or ambiguous'}
            $state='pid-reused-with-different-creation'
        }
        $taskVerified+=[ordered]@{pid=$id.pid;creationMs=$id.creationMs;executableName=$id.executableName;status=$state}
    }
}
# Verify exact allowed targets before any unlink or recursive removal.
$taskTargets=@($taskTargets|Sort-Object -Unique)
foreach($candidate in $taskTargets){$absolute=TaskFull $candidate;if(-not(TaskSame $candidate $absolute)){throw 'Unresolved target'};$null=TaskOrdinary $absolute}
foreach($root in $taskRoots){
    $modelDir=Join-Path $root 'models';$null=TaskOrdinary $modelDir
    foreach($entry in Get-ChildItem -LiteralPath $modelDir -Force){
        if($entry.Attributes -band [IO.FileAttributes]::ReparsePoint){
            if(-not(TaskSame (Split-Path -Parent $entry.FullName) $modelDir) -or $entry.LinkType -notin @('SymbolicLink','Junction')){throw 'Unexpected model link'}
            $targets=@($entry.Target)
            if($targets.Count -ne 1 -or -not(@('bin','bin-markers','bin-checkpoint')|Where-Object{(TaskFull $targets[0]).StartsWith((Join-Path $taskStage $_)+'\',[StringComparison]::OrdinalIgnoreCase)})){throw 'Model link target outside exact frozen bins'}
            $taskLinks+=[ordered]@{path=$entry.FullName;linkType=$entry.LinkType;targets=$targets}
        }
    }
}
# Windows created these fixed junctions inside each private USERPROFILE. Unlink entries, never follow them.
foreach($root in $taskRoots){
    $inet=Join-Path $root 'profile\AppData\Local\Microsoft\Windows\INetCache'
    $linkPath=Join-Path $inet 'Content.IE5';$targetPath=Join-Path $inet 'IE'
    if(Test-Path -LiteralPath $linkPath){
        $null=TaskOrdinary $inet;$link=Get-Item -LiteralPath $linkPath -Force
        $targets=@($link.Target)
        if(-not($link.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $link.LinkType -ne 'Junction' -or $targets.Count -ne 1 -or -not(TaskSame $targets[0] $targetPath) -or -not(TaskSame $link.FullName $linkPath)){throw 'Unexpected private INetCache link'}
        if(Test-Path -LiteralPath $targetPath){$null=TaskOrdinary $targetPath}
        $taskLinks+=[ordered]@{path=$link.FullName;linkType=$link.LinkType;targets=$targets;scope='fixed private USERPROFILE INetCache junction'}
    }
}
foreach($link in $taskLinks){Remove-Item -LiteralPath $link.path -Force}
# Never recurse into link targets. All remaining trees must be ordinary.
foreach($candidate in $taskTargets){TaskTree (TaskFull $candidate)}
$taskDeleted=@()
foreach($candidate in $taskTargets){$absolute=TaskFull $candidate;Remove-Item -LiteralPath $absolute -Recurse -Force;$taskDeleted+=$absolute}
$receipt=[ordered]@{observedAt=[DateTime]::UtcNow.ToString('o');stageRoot=$taskStage;groups=$taskGroupChecks;pairRoots=$taskRoots;verifiedIdentities=$taskVerified;processIdentityCount=$taskVerified.Count;unlinkedCacheEntries=$taskLinks;removedCachePaths=$taskDeleted;historicalUnawaitedDiagnosticExitCodeUnavailable=$true;note='Historical failed group stays failed; fresh metadata authorizes cache cleanup only';preserved=@('Vault','all proofs and markers','reports','all EXEs and frozen resources','public source fixtures');complete=$true}
[IO.File]::WriteAllText((Join-Path $taskStage 'cleanup-checkpoint.json'),($receipt|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
Write-Output ('Verified identities: '+$taskVerified.Count+'; cache paths removed: '+$taskDeleted.Count+'; cache links unlinked: '+$taskLinks.Count)
