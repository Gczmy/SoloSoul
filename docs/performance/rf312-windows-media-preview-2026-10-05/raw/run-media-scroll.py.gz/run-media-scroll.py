
import pathlib,json,hashlib,subprocess,time,datetime,sys
sys.stdout.reconfigure(encoding='utf-8')
root=pathlib.Path(r'C:\Users\40299571\SoloSoul')
stage=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-preview-20261005')
source=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-media-20261005')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
build=json.loads((stage/'scroll-build-checkpoint.json').read_text(encoding='utf-8-sig'))
assert json.loads((stage/'scroll-release-build.receipt.json').read_text(encoding='utf-8-sig'))['exitCode']==0
assert sha(pathlib.Path(build['exe']))==build['sha256']
freeze=json.loads((stage/'scroll-source-freeze.json').read_text(encoding='utf-8-sig'))
assert all(sha(root/p)==h for p,h in freeze['files'].items())
for count in [100,5000]:
    name='media'+str(count)+'-scroll'
    output=stage/('samples'+str(count)+'-scroll')
    assert not output.exists()
    args=['node','scripts/native-perf-media.mjs','--exe',build['exe'],'--fixture',str(source/('vault'+str(count))),'--output',str(output),'--samples','5','--memory-interval-ms','2000']
    started=time.time()
    with (stage/(name+'.stdout.log')).open('xb') as out,(stage/(name+'.stderr.log')).open('xb') as err:
        child=subprocess.Popen(args,stdout=out,stderr=err,cwd=root/'tauri')
        (stage/(name+'.live.json')).open('x',encoding='utf-8').write(json.dumps({'command':args,'pid':child.pid,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}))
        print('Started '+name+' PID '+str(child.pid),flush=True)
        rc=child.wait()
    receipt={'command':args,'pid':child.pid,'exitCode':rc,'elapsedSeconds':time.time()-started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (stage/(name+'.receipt.json')).open('x',encoding='utf-8').write(json.dumps(receipt,indent=2))
    print(json.dumps(receipt),flush=True)
    group=json.loads((output/'native-perf-sdk-journey-results.json').read_text(encoding='utf-8-sig'))
    print(json.dumps({'group':count,'success':group['success'],'sampleCount':len(group['samples']),'sourceUnchanged':group['sourceUnchanged'],'summary':group['summary'],'memorySummary':group.get('memorySummary'),'failedSteps':[{'index':s['index'],'reason':s.get('nativeProof',{}).get('reason'),'step':s.get('nativeProof',{}).get('failedStep'),'error':s.get('error'),'memoryReason':s.get('memorySeries',{}).get('reason')} for s in group['samples'] if not s['success']]},ensure_ascii=False),flush=True)
    if rc or not group['success']: raise SystemExit(rc or 1)
