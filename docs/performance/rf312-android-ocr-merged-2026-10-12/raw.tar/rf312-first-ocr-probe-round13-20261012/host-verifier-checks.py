import copy,importlib.util,json
from pathlib import Path
s=Path(__file__).parent;b=s.parent
spec=importlib.util.spec_from_file_location('rf312_merged_consumer',s/'media-native-driver.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
ev=json.loads((b/'rf312-first-ocr-probe-round12-20261012/first-100-diagnostic/device-files/report.json').read_text(encoding='utf-8'));rows=[]
def check(name,v,expect=None):
 try:m.verify_fixed_evidence(v,100,ev['runId'],ev['uid']);error=None
 except RuntimeError as exc:error=str(exc)
 assert error==expect,(name,error,expect)
 rows.append({'case':name,'accepted':error is None,'actualError':error})
check('actual-native-twelve-phase-report-replayed-read-only',copy.deepcopy(ev))
v=copy.deepcopy(ev);v['phases']=[p for p in v['phases'] if p['name']!='search-needle'];check('missing-search-phase',v,'Complete twelve-phase UI sequence required')
v=copy.deepcopy(ev);v['nativePickerFileAction']['accepted']=False;check('unaccepted-native-file-action',v,'Actual native file accessibility click required')
v=copy.deepcopy(ev);v['ocrWindowVisibility']['nearForegroundPixels']=0;check('blank-ocr-window',v,'Actual visible public OCR window pixels required')
v=copy.deepcopy(ev);v['ocrWindowVisibility']['style']['visible']=False;check('ocr-outside-visible-window',v,'Actual visible public OCR window pixels required')
v=copy.deepcopy(ev);next(p for p in v['phases'] if p['name']=='search-needle')['ui']['searchResults']=50;check('wrong-small-vault-search-result-count',v,'Actual known public search results required')
v=copy.deepcopy(ev);p=next(p for p in v['phases'] if p['name']=='first-ocr-user-flow');p['observer']['commands']=[e for e in p['observer']['commands'] if e['command']!='ocr_scan_image'];check('missing-first-ocr-transport',v,'Exactly one first public OCR transport required')
v=copy.deepcopy(ev);p=v['phases'][-1];event=copy.deepcopy(p['observer']['commands'][-1]);event['command']='ocr_scan_image';p['observer']['commands'].append(event);p['observer']['observedCount']+=1;p['ipcEnd']+=1;p['transportAttempts']+=1;check('second-ocr-in-whole-journey',v,'Exactly one OCR transport in whole journey required')
actual={'checksPassed':True,'cases':rows,'originalFailedReceiptNotChanged':True,'positiveCaseIsReplayOnlyNotFreshNativeRun':True}
assert actual==json.loads((s/'host-verifier-checks.json').read_text(encoding='utf-8'))
print('Actual saved verifier checks reproduced: positive replay and7 negative cases')
