from pathlib import Path
import json
B=Path(__file__).parent;old=B/'rf312-first-ocr-probe-20261012';S=B/'rf312-first-ocr-probe-round2-20261012'
r=json.loads((old/'first-100-diagnostic/report.json').read_text());audit=json.loads((old/'post-failure-owned-media-cleanup-audit.json').read_text())
assert r['restored'] and audit['ownedPublicFileAbsent'] and audit['ownedMediaIndexAbsent']
S.mkdir(exist_ok=False)
for name in ['AndroidMediaPerfInstrumentedTest.kt','inputs.json','current-runtime-sources.json','media-native-driver.py','run-first-100-diagnostic.py','run-first-5000-diagnostic.py']:
    raw=(old/name).read_text(encoding='utf-8').replace(old.name,S.name)
    if name.endswith('.kt'):
        raw=raw.replace('''"input" -> n.className?.toString()=="android.widget.EditText" && n.isFocused''','''"input" -> n.isEditable
                "focused-input" -> n.isEditable && n.isFocused''')
        raw=raw.replace('''report.put("lastNativePickerTarget",trace);writeReport()''','''trace.put("editableClasses",JSONArray(nodes.filter {it.isEditable}.map {it.className?.toString()}))
                .put("focusedClasses",JSONArray(nodes.filter {it.isFocused}.map {it.className?.toString()}))
            report.put("lastNativePickerTarget",trace);writeReport()''')
        needle='''            while(pickerMatch("input",fileName)==null && SystemClock.elapsedRealtimeNanos()-began<TimeUnit.SECONDS.toNanos(45))Thread.sleep(50)
            check(pickerMatch("input",fileName)!=null)'''
        assert raw.count(needle)==1
        raw=raw.replace(needle,'''            pickerTap("input",fileName,began)
            while(pickerMatch("focused-input",fileName)==null && SystemClock.elapsedRealtimeNanos()-began<TimeUnit.SECONDS.toNanos(45))Thread.sleep(50)
            check(pickerMatch("focused-input",fileName)!=null)''')
    if name=='media-native-driver.py':
        needle="                adb('shell','rm',public_image,stdout=subprocess.PIPE)"
        assert raw.count(needle)==1
        raw=raw.replace(needle,"""                state=read('shell','sh','-c',f'"if test -e {public_image}; then echo present; else echo absent; fi"')
                if state=='present':
                    if read('shell','sha256sum',public_image).split()!=[expected,public_image]:raise RuntimeError('Remaining owned image changed')
                    adb('shell','rm',public_image,stdout=subprocess.PIPE)
                elif state!='absent':raise RuntimeError('Owned file existence could not be established')""")
    (S/name).write_text(raw,encoding='utf-8',newline='\n')
builder=(B/'build-rf312-first-ocr-probe.py').read_text(encoding='utf-8').replace(old.name,S.name)
(B/'build-rf312-first-ocr-probe-round2.py').write_text(builder,encoding='utf-8',newline='\n')
print(S)
