from pathlib import Path
import json
B=Path(__file__).parent;old=B/'rf312-first-ocr-probe-round2-20261012';S=B/'rf312-first-ocr-probe-round3-20261012'
r=json.loads((old/'first-100-diagnostic/report.json').read_text());assert r['restored'] and r['ownedPublicOcrInputRemoved']
S.mkdir(exist_ok=False)
for name in ['AndroidMediaPerfInstrumentedTest.kt','inputs.json','current-runtime-sources.json','media-native-driver.py','run-first-100-diagnostic.py','run-first-5000-diagnostic.py']:
    raw=(old/name).read_text(encoding='utf-8').replace(old.name,S.name)
    if name.endswith('.kt'):
        needle='''            for(action in listOf(KeyEvent.ACTION_DOWN,KeyEvent.ACTION_UP)) {
                check(instrumentation.uiAutomation.injectInputEvent(KeyEvent(action,KeyEvent.KEYCODE_ENTER),true))
            }'''
        assert raw.count(needle)==1
        raw=raw.replace(needle,'''            val down=SystemClock.uptimeMillis()
            for(action in listOf(KeyEvent.ACTION_DOWN,KeyEvent.ACTION_UP)) {
                val event=KeyEvent(down,SystemClock.uptimeMillis(),action,KeyEvent.KEYCODE_ENTER,0,0,
                    KeyCharacterMap.VIRTUAL_KEYBOARD,0,KeyEvent.FLAG_FROM_SYSTEM,android.view.InputDevice.SOURCE_KEYBOARD)
                val injected=instrumentation.uiAutomation.injectInputEvent(event,true)
                report.put("lastNativePickerKey",JSONObject().put("key","ENTER").put("action",action).put("source",event.source)
                    .put("downTime",event.downTime).put("eventTime",event.eventTime).put("injected",injected));writeReport()
                check(injected)
            }''')
    (S/name).write_text(raw,encoding='utf-8',newline='\n')
builder=(B/'build-rf312-first-ocr-probe-round2.py').read_text(encoding='utf-8').replace(old.name,S.name)
(B/'build-rf312-first-ocr-probe-round3.py').write_text(builder,encoding='utf-8',newline='\n')
print(S)
