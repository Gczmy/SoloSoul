from pathlib import Path
import json,hashlib
R=Path('D:/SoloSoul');B=Path(__file__).parent;old=B/'rf312-text-visual-probe-round2-20261012';S=B/'rf312-first-ocr-probe-20261012'
S.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=(old/'AndroidMediaPerfInstrumentedTest.kt').read_text(encoding='utf-8')
source=source.replace('import android.graphics.BitmapFactory','''import android.graphics.BitmapFactory
import android.graphics.Rect
import android.view.KeyCharacterMap
import android.view.accessibility.AccessibilityNodeInfo''')
needle='    @Test fun fixedMediaUiDiagnostic() {'
assert source.count(needle)==1
insert='''    private fun nativePickerNodes():List<AccessibilityNodeInfo> {
        val root=instrumentation.uiAutomation.rootInActiveWindow?:return emptyList()
        val pkg=root.packageName?.toString()
        if(pkg !in setOf("com.android.documentsui","com.google.android.documentsui"))return emptyList()
        val nodes=ArrayList<AccessibilityNodeInfo>();val queue=java.util.ArrayDeque<AccessibilityNodeInfo>();queue.add(root)
        while(queue.isNotEmpty()) {
            val node=queue.removeFirst();nodes.add(node);check(nodes.size<=2048)
            for(i in 0 until node.childCount)node.getChild(i)?.let {queue.add(it)}
        }
        return nodes
    }

    private fun pickerMatch(kind:String,fileName:String):Rect? {
        val nodes=nativePickerNodes()
        try {
            val matches=nodes.filter { n -> n.isVisibleToUser && n.isEnabled && when(kind) {
                "file" -> n.text?.toString()==fileName
                "search" -> n.isClickable && (n.contentDescription?.toString()=="Search" || n.viewIdResourceName?.endsWith("/menu_search")==true)
                "input" -> n.className?.toString()=="android.widget.EditText" && n.isFocused
                else -> false
            } }
            val trace=JSONObject().put("kind",kind).put("documentsUiBound",nodes.isNotEmpty()).put("matchingKnownTarget",matches.size)
            report.put("lastNativePickerTarget",trace);writeReport()
            if(matches.size!=1)return null
            val bounds=Rect();matches.single().getBoundsInScreen(bounds)
            return bounds.takeIf { it.width()>0 && it.height()>0 }
        } finally { nodes.forEach {it.recycle()} }
    }

    private fun pickerTap(kind:String,fileName:String,began:Long):Long {
        var bounds:Rect?=null
        while(SystemClock.elapsedRealtimeNanos()-began<TimeUnit.SECONDS.toNanos(45)) {
            bounds=pickerMatch(kind,fileName)
            if(bounds!=null)break
            Thread.sleep(50)
        }
        val target=bounds?:throw AssertionError("Known native document picker target unavailable: $kind")
        val display=instrumentation.targetContext.resources.displayMetrics
        check(target.centerX() in 1 until display.widthPixels && target.centerY() in 1 until display.heightPixels)
        val down=SystemClock.uptimeMillis();val selected=SystemClock.elapsedRealtimeNanos()
        for(action in listOf(MotionEvent.ACTION_DOWN,MotionEvent.ACTION_UP)) {
            val event=MotionEvent.obtain(down,SystemClock.uptimeMillis(),action,target.centerX().toFloat(),target.centerY().toFloat(),0)
            event.source=android.view.InputDevice.SOURCE_TOUCHSCREEN
            try {check(instrumentation.uiAutomation.injectInputEvent(event,true))}finally {event.recycle()}
        }
        return selected
    }

    private fun choosePublicNativeImage(fileName:String):Long {
        val began=SystemClock.elapsedRealtimeNanos()
        val recent=pickerMatch("file",fileName)
        if(recent==null) {
            pickerTap("search",fileName,began)
            while(pickerMatch("input",fileName)==null && SystemClock.elapsedRealtimeNanos()-began<TimeUnit.SECONDS.toNanos(45))Thread.sleep(50)
            check(pickerMatch("input",fileName)!=null)
            val events=requireNotNull(KeyCharacterMap.load(KeyCharacterMap.VIRTUAL_KEYBOARD).getEvents(fileName.toCharArray()))
            for(event in events)check(instrumentation.uiAutomation.injectInputEvent(event,true))
            for(action in listOf(KeyEvent.ACTION_DOWN,KeyEvent.ACTION_UP)) {
                check(instrumentation.uiAutomation.injectInputEvent(KeyEvent(action,KeyEvent.KEYCODE_ENTER),true))
            }
        }
        return pickerTap("file",fileName,began)
    }

    private fun buttonWithPublicText(scenario:ActivityScenario<MainActivity>,text:String):String {
        require(text=="Select image")
        val observed=waitFor(scenario,"""(() => {
          const found=[...document.querySelectorAll('button')].filter(e=>e.textContent.trim()===${JSONObject.quote(text)});
          const e=found.length===1?found[0]:null;const parts=[];
          for(let n=e;n&&n!==document.body;n=n.parentElement)parts.unshift(n.tagName.toLowerCase()+':nth-child('+([...n.parentElement.children].indexOf(n)+1)+')');
          return JSON.stringify({matches:found.length,enabled:!!e&&!e.disabled,selector:e?'body > '+parts.join(' > '):null});})()""") { it.optInt("matches")==1 && it.optBoolean("enabled") }
        return observed.getString("selector")
    }

    private fun firstPublicOcr(scenario:ActivityScenario<MainActivity>,fileName:String) {
        check(fileName=="rf312-ocr-$runId.png")
        val before=observer(scenario)
        assertEquals("No previous OCR scan in this actual application process",0,(0 until before.getJSONArray("commands").length()).count {before.getJSONArray("commands").getJSONObject(it).getString("command")=="ocr_scan_image"})
        touch(scenario,".android-navigation a[href='/tools']")
        waitFor(scenario,page) {it.optString("path")=="/tools"}
        val index=js(scenario,"""JSON.stringify({index:[...document.querySelectorAll('.android-tool-grid > button')].findIndex(e=>e.querySelector('strong')?.textContent.includes('OCR'))})""").getInt("index")
        check(index>=0);touch(scenario,".android-tool-grid > button:nth-child(${index+1})")
        waitFor(scenario,page) {it.optString("path")=="/ocr"}
        touch(scenario,buttonWithPublicText(scenario,"Select image"))
        val selectedAt=choosePublicNativeImage(fileName)
        report.put("ocrFileSelectionNativeAtNs",selectedAt)
        val result=waitFor(scenario,"""(() => {const text=document.body.textContent||'';return JSON.stringify({
          path:location.pathname,hello:text.includes('Hello'),soloSoul:text.toLowerCase().includes('solosoul'),digits:text.includes('1234567890'),
          imported:false,alerts:document.querySelectorAll('[role="alert"]').length});})()""",selectedAt) {
            it.optString("path")=="/ocr" && it.optBoolean("hello") && it.optBoolean("soloSoul") && it.optBoolean("digits")
        }
        val finished=SystemClock.elapsedRealtimeNanos()
        report.put("firstOcr",result.put("nativeFileSelectedAtNs",selectedAt).put("nativeResultObservedAtNs",finished)
          .put("fromFileSelectionMs",(finished-selectedAt)/1_000_000.0)
          .put("definition","native file row selection to actual known corpus in result DOM; includes picker result/IPC/decode/MLKit initialization and polling")
          .put("nativeSystemPickerUsed",true).put("firstActualOcrTransport",true).put("confidenceNotMeasured",true))
        painted(scenario,selectedAt);captureScreenshot(scenario,"diagnostic-first-ocr-result")
        val after=observer(scenario)
        assertEquals(1,(0 until after.getJSONArray("commands").length()).count {after.getJSONArray("commands").getJSONObject(it).getString("command")=="ocr_scan_image"})
        touch(scenario,".android-navigation a[href='/']")
        waitFor(scenario,page) {it.optBoolean("home")}
    }

'''
source=source.replace(needle,insert+needle)
needle='''            measure("password-unlock") { unlock() }'''
assert source.count(needle)==1
source=source.replace(needle,needle+'''
            measure("first-ocr-user-flow") {firstPublicOcr(scenario,requireNotNull(args.getString("publicImageName")))}''')
source=source.replace('assertEquals(10,phases.length())','assertEquals(11,phases.length())')
source=source.replace('.put("unmeasured",JSONArray(listOf("OCR",', '.put("unmeasured",JSONArray(listOf("repeated-full-journey",')
(S/'AndroidMediaPerfInstrumentedTest.kt').write_text(source,encoding='utf-8',newline='\n')
inputs=load(old/'inputs.json');current={n:sha(R/n) for n in inputs['runtimeSourceFiles']};assert current==inputs['runtimeSourceFiles']
png=R/'tauri/crates/solosoul-core/tests/fixtures/ocr_test.png';assert sha(png)=='56a9d54d9b70a3ee1b22e0b08b755b6cfc15ee125df4b11d52f8523583dcacaa'
inputs['publicOcrImage']={'path':str(png),'sha256':sha(png),'bytes':png.stat().st_size};inputs['sourceParentHead']='442987d31'
(S/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
(S/'current-runtime-sources.json').write_text(json.dumps(current,indent=2)+'\n',encoding='utf-8')
driver=(old/'media-native-driver.py').read_text(encoding='utf-8').replace(old.name,S.name)
driver=driver.replace('import uuid','import uuid\nimport shlex') if 'import uuid' in driver else 'import shlex\n'+driver
driver=driver.replace("'password-unlock','workspace'","'password-unlock','first-ocr-user-flow','workspace'")
driver=driver.replace('    commands = []','    commands = []\n    public_image = None\n    public_image_staged = False')
needle='''        tag = f"rf312-media-{uuid.uuid4().hex}"'''
assert driver.count(needle)==1
driver=driver.replace(needle,needle+'''
        image_name='rf312-ocr-'+tag.removeprefix('rf312-media-')+'.png'
        public_image='/sdcard/Download/'+image_name
        image=frozen_inputs['publicOcrImage']
        if digest(Path(image['path']))!=image['sha256']:raise RuntimeError('Public OCR PNG changed')
        adb('shell','sh','-c',f'"test ! -e {public_image}"',stdout=subprocess.PIPE)
        adb('push',image['path'],public_image,stdout=subprocess.PIPE)
        public_image_staged=True
        if read('shell','sha256sum',public_image).split()!=[image['sha256'],public_image]:raise RuntimeError('Staged OCR image bytes mismatch')
        adb('shell','am','broadcast','-a','android.intent.action.MEDIA_SCANNER_SCAN_FILE','-d','file://'+public_image,stdout=subprocess.PIPE)
        report['publicOcrInput']={'path':public_image,'fileName':image_name,'sha256':image['sha256'],'publicFixtureOnly':True}
''')
driver=driver.replace('''                     "-e", "objectCount", str(args.object_count),''','''                     "-e", "objectCount", str(args.object_count),
                     "-e", "publicImageName", image_name,''')
guard="    phases=evidence.get('phases',[])";assert driver.count(guard)==1
driver=driver.replace(guard,"    if not all(evidence.get('firstOcr',{}).get(k) is True for k in ['hello','soloSoul','digits','nativeSystemPickerUsed','firstActualOcrTransport']):raise RuntimeError('Actual first public OCR corpus required')\n"+guard)
needle='''        try:
            frozen()
            report['frozenInputsUnchanged'] = True'''
assert driver.count(needle)==1
driver=driver.replace(needle,'''        if public_image_staged:
            try:
                if not re.fullmatch(r'/sdcard/Download/rf312-ocr-[a-f0-9]{32}\\.png',public_image):raise RuntimeError('Owned image path rejected')
                expected=frozen_inputs['publicOcrImage']['sha256']
                if read('shell','sha256sum',public_image).split()!=[expected,public_image]:raise RuntimeError('Owned public image changed; retain for inspection')
                canonical=read('shell','readlink','-f',public_image)
                if not canonical.endswith('/Download/'+Path(public_image).name):raise RuntimeError('Owned media path alias changed')
                where=shlex.quote("_data='"+canonical+"'")
                adb('shell','content','delete','--uri','content://media/external/file','--where',where,stdout=subprocess.PIPE)
                adb('shell','rm',public_image,stdout=subprocess.PIPE)
                adb('shell','sh','-c',f'"test ! -e {public_image}"',stdout=subprocess.PIPE)
                report['ownedPublicOcrInputRemoved']=True
            except Exception as error:
                report['publicOcrCleanupError']=str(error)
        try:
            frozen()
            report['frozenInputsUnchanged'] = True''')
driver=driver.replace("and not report.get('sourceRestoreError'))","and not report.get('sourceRestoreError')\n                                and report.get('ownedPublicOcrInputRemoved'))")
(S/'media-native-driver.py').write_text(driver,encoding='utf-8',newline='\n')
for name in ['run-first-100-diagnostic.py','run-first-5000-diagnostic.py']:
    (S/name).write_text((old/name).read_text().replace(old.name,S.name),encoding='utf-8',newline='\n')
builder=(B/'build-rf312-text-visual-probe-round2.py').read_text().replace(old.name,S.name)
(B/'build-rf312-first-ocr-probe.py').write_text(builder,encoding='utf-8',newline='\n')
print(S)
