from pathlib import Path
import json
B=Path(__file__).parent;old=B/'rf312-first-ocr-probe-round4-20261012';S=B/'rf312-first-ocr-probe-round5-20261012'
r=json.loads((old/'first-100-diagnostic/report.json').read_text());assert r['restored'] and r['ownedPublicOcrInputRemoved']
S.mkdir(exist_ok=False)
for name in ['AndroidMediaPerfInstrumentedTest.kt','inputs.json','current-runtime-sources.json','media-native-driver.py','run-first-100-diagnostic.py','run-first-5000-diagnostic.py']:
    raw=(old/name).read_text(encoding='utf-8').replace(old.name,S.name)
    if name.endswith('.kt'):
        raw=raw.replace('''"input" -> n.isEditable''','''"roots" -> n.isClickable && n.contentDescription?.toString()=="Show roots"
                "downloads" -> !n.isEditable && n.text?.toString()=="Downloads"
                "input" -> n.isEditable''')
        needle='''        if(recent==null) {
            pickerTap("search",fileName,began)''';assert raw.count(needle)==1
        raw=raw.replace(needle,'''        if(recent==null) {
            pickerTap("roots",fileName,began)
            pickerTap("downloads",fileName,began)
            if(pickerMatch("file",fileName)!=null)return pickerTap("file",fileName,began)
            pickerTap("search",fileName,began)''')
        raw=raw.replace('''        if(kind=="file")captureNativePicker("diagnostic-picker-known-file")''','''        if(kind=="file") {
            captureNativePicker("diagnostic-picker-known-file")
            bounds=pickerMatch(kind,fileName)
            check(bounds!=null && bounds==target)
        }''')
    if name=='media-native-driver.py':
        needle="        report['publicOcrInput']={'path':public_image,'fileName':image_name,'sha256':image['sha256'],'publicFixtureOnly':True}"
        assert raw.count(needle)==1
        raw=raw.replace(needle,needle+'''
        canonical_image=read('shell','readlink','-f',public_image)
        image_where=shlex.quote("_data='"+canonical_image+"'")
        media_state=read('shell','content','query','--uri','content://media/external/file','--where',image_where,'--projection','_id:_display_name:mime_type:date_modified:_size')
        (output/'owned-public-image-media-before.log').write_text(media_state+'\\n',encoding='utf-8')
''')
    (S/name).write_text(raw,encoding='utf-8',newline='\n')
builder=(B/'build-rf312-first-ocr-probe-round4.py').read_text(encoding='utf-8').replace(old.name,S.name)
(B/'build-rf312-first-ocr-probe-round5.py').write_text(builder,encoding='utf-8',newline='\n')
print(S)
