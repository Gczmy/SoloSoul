from pathlib import Path
import hashlib, importlib.util, io, json, tarfile

R = Path('D:/SoloSoul')
B = Path(__file__).parent
S = B / 'rf312-first-ocr-probe-round13-20261012'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda raw: hashlib.sha256(raw).hexdigest()
spec = importlib.util.spec_from_file_location('merged_restore_audit', R / 'tauri/scripts/android-home-native-regression.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
inputs = load(S / 'inputs.json')
assert all(sha((R / n).read_bytes()) == h for n, h in inputs['runtimeSourceFiles'].items())
assert sha(Path(inputs['runtimeTest']['path']).read_bytes()) == inputs['runtimeTest']['sha256']
assert sha((S / 'AndroidMediaPerfInstrumentedTest.kt').read_bytes()) == inputs['runtimeTest']['homeTestSourceSha256']
rows, restorations, private_targets = [], [], []
for count in [100, 5000]:
    d = S / f'first-{count}-diagnostic'
    receipt = load(S / f'first-{count}-diagnostic.receipt.json')
    driver = load(d / 'report.json')
    native = load(d / 'device-files/report.json')
    assert receipt['exitCode'] == 0 and all(receipt[k] for k in ['passed', 'restored', 'originalApksRestored', 'ownedProbeRemoved', 'blurRestored', 'sourceInputsUnchanged'])
    assert driver['ownedPublicOcrInputRemoved'] and native['success'] and len(native['phases']) == 12
    assert all(p['success'] for p in native['phases'])
    before, after = d / 'private-data-before.tar', d / 'private-data-restored.tar'
    inventory = helper.inventory(before, require_empty=True)
    assert inventory == helper.inventory(after)
    restorations.append({'objectCount': count, 'entries': len(inventory), 'allContentsLinksModesMatch': True,
                         'beforeTarSha256': sha(before.read_bytes()), 'afterTarSha256': sha(after.read_bytes())})
    private_targets.extend([before, after])
    rows.append({'objectCount': count, 'samples': 1, 'actualDriverExitCode': 0, 'all12PhasesPassed': True,
                 'firstOcr': native['firstOcr'], 'nativeFileAction': native['nativePickerFileAction'],
                 'ocrWindowVisibility': native['ocrWindowVisibility'], 'manualKnownOcrCorpusVisible': True,
                 'searchMatchesInFixture': count // 20, 'displayedSearchResults': min(count // 20, 50),
                 'phaseDurationsDiagnosticOnly': [{k: p[k] for k in ['name', 'success', 'durationMs', 'transportAttempts']} for p in native['phases']],
                 'mainProcessPssSampleCount': len(native['memorySamples']), 'rendererMemoryIncluded': False,
                 'originalApksPrivateDataBlurAndOwnedPublicImageRestored': True,
                 'fullPerformanceAccepted': False})
(S / 'independent-restoration-audit.json').write_text(json.dumps(restorations, indent=2) + '\n', encoding='utf-8')
for p in private_targets:
    assert p.resolve().is_relative_to(B.resolve()) and not p.is_symlink()
    p.unlink()
(S / 'private-backup-cleanup.json').write_text(json.dumps({'removed': len(private_targets), 'allPairsIndependentlyVerified': True, 'originalNativeSuccessesAndFailuresRetained': True}) + '\n', encoding='utf-8')

roots = [B / 'rf312-first-ocr-probe-20261012'] + [B / f'rf312-first-ocr-probe-round{i}-20261012' for i in range(2, 14)]
outcomes = []
for root in roots:
    for receipt_path in sorted(root.glob('first-*-diagnostic.receipt.json')):
        receipt = load(receipt_path)
        d = root / receipt_path.name.removesuffix('.receipt.json')
        driver, native = load(d / 'report.json'), load(d / 'device-files/report.json')
        assert all(driver[k] for k in ['restored', 'originalApksRestored', 'ownedProbeRemoved', 'blurRestored'])
        if root == roots[0]:
            audit = load(root / 'post-failure-owned-media-cleanup-audit.json')
            assert audit['ownedPublicFileAbsent'] and audit['ownedMediaIndexAbsent']
        else:
            assert driver['ownedPublicOcrInputRemoved']
        outcomes.append({'run': root.name, 'objectCount': native['objectCount'], 'driverExitCode': receipt['exitCode'],
                         'nativeReportedSuccess': native['success'], 'nativeErrorClass': native.get('errorClass'),
                         'driverError': driver.get('error'), 'originalResultUnmodified': True,
                         'originalApksPrivateDataAndOwnedImageRestored': True})
assert len(outcomes) == 15 and sum(r['driverExitCode'] != 0 for r in outcomes) == 12
target = R / 'docs/performance/rf312-android-ocr-merged-2026-10-12'
target.mkdir(exist_ok=False)
members = {}
for root in roots:
    for p in root.rglob('*'):
        rel = p.relative_to(root)
        if 'project' in rel.parts or not p.is_file() or p.suffix.lower() not in {'.json', '.log', '.py', '.kt', '.png'}:
            continue
        assert not p.is_symlink()
        members[root.name + '/' + rel.as_posix()] = p.read_bytes()
for p in sorted(B.glob('build-rf312-first-ocr-probe*.py')):
    members['orchestration/' + p.name] = p.read_bytes()
for p in sorted(B.glob('prepare-rf312-first-ocr*.py')):
    members['orchestration/' + p.name] = p.read_bytes()
members['orchestration/archive-rf312-ocr-merged.py'] = Path(__file__).read_bytes()
archive = target / 'raw.tar'
with tarfile.open(archive, 'w') as output:
    for name, raw in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode = len(raw), 0o644
        output.addfile(info, io.BytesIO(raw))
index = {'task': 'RF-312', 'scope': 'Android first OCR and merged search/media journey diagnostics',
         'archiveSha256': sha(archive.read_bytes()),
         'members': {n: {'bytes': len(raw), 'sha256': sha(raw)} for n, raw in sorted(members.items())},
         'privateDataProgramsKeysAndDatabasesExcluded': True}
with tarfile.open(archive) as source:
    assert {m.name for m in source} == set(members)
    for name, metadata in index['members'].items():
        raw = source.extractfile(name).read()
        assert len(raw) == metadata['bytes'] and sha(raw) == metadata['sha256']
(target / 'index.json').write_text(json.dumps(index, indent=2) + '\n', encoding='utf-8')
summary = {'task': 'RF-312', 'status': 'partial-verification', 'wholeRF312Accepted': False,
           'scope': 'real process-first Android OCR and merged12-stage100/5000 native UI diagnostics',
           'productSourceAndMainApkUnchanged': True, 'mainApkSha256': inputs['release']['apk']['sha256'],
           'signedIndependentTestApk': inputs['runtimeTest'], 'sameRound12TestApkReusedForRound13': True,
           'hostConsumerChecks': load(S / 'host-verifier-checks.json'),
           'device': {'serial': 'emulator-5586', 'avd': 'SoloSoul_RF121_API31_20261010', 'api': 31,
                      'abi': 'x86_64', 'gpu': 'swiftshader', 'memoryMiB': 2048, 'cores': 2, 'physicalDevice': False},
           'definitions': {'firstOcr': rows[0]['firstOcr']['definition'],
                           'phaseTiming': 'native elapsedRealtimeNanos; includes instrumentation/readiness/input/polling/diagnostic overhead',
                           'startup': 'Activity launch to usable production password form; excludes runner/process launch',
                           'memory': 'serial main-process PSS including runner; not renderer or continuous peak',
                           'ipc': 'actual early JS transport sends including startup/retries/channels; no arguments or bodies',
                           'confidence': 'ML Kit confidence is unavailable; UI100% is placeholder, not measured accuracy'},
           'runs': rows, 'restorationAudit': restorations, 'allNativeOutcomesIncludingFailures': outcomes,
           'historicalRootCauseUniquelyProven': False,
           'manualReview': {'ocrKnownCorpus100And5000': True, 'searchResultScreens100And5000': True,
                            'scannedPdf5000RasterContent': True,
                            'searchNavbarColorDuringImeTransitionNotAcceptedAsFinalStyle': True},
           'remaining': ['repeated complete100/5000 cohorts and median/tail metrics',
                         'renderer/full-process memory and sampler overhead attribution',
                         'process-cold launch', 'physical hardware and other platforms',
                         'stable search capture after IME transition; not a claimed style repair'],
           'rawIndex': target.name + '/index.json'}
(R / 'docs/performance/rf312-android-ocr-merged-2026-10-12.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'members': len(members), 'archiveBytes': archive.stat().st_size, 'nativeRunsRetained': len(outcomes),
                  'failedRunsRetained': 12, 'merged12StageRunsAccepted': 2, 'wholeRF312Accepted': False}))
