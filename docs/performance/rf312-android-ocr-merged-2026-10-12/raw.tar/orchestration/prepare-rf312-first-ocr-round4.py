from pathlib import Path
import json
B=Path(__file__).parent;old=B/'rf312-first-ocr-probe-round3-20261012';S=B/'rf312-first-ocr-probe-round4-20261012'
r=json.loads((old/'first-100-diagnostic/report.json').read_text());assert r['restored'] and r['ownedPublicOcrInputRemoved']
S.mkdir(exist_ok=False)
for name in ['AndroidMediaPerfInstrumentedTest.kt','inputs.json','current-runtime-sources.json','media-native-driver.py','run-first-100-diagnostic.py','run-first-5000-diagnostic.py']:
    raw=(old/name).read_text(encoding='utf-8').replace(old.name,S.name)
    if name.endswith('.kt'):
        raw=raw.replace('"file" -> n.text?.toString()==fileName','"file" -> !n.isEditable && n.text?.toString()==fileName')
        needle='''trace.put("editableClasses",JSONArray(nodes.filter {it.isEditable}.map {it.className?.toString()}))'''
        assert raw.count(needle)==1
        raw=raw.replace(needle,'''trace.put("matchedKnownNodes",JSONArray(matches.map { n -> JSONObject().put("class",n.className?.toString())
                .put("resourceId",n.viewIdResourceName).put("editable",n.isEditable).put("clickable",n.isClickable) }))
            '''+needle)
        needle='''    private fun pickerTap(kind:String,fileName:String,began:Long):Long {'''
        assert raw.count(needle)==1
        raw=raw.replace(needle,'''    private fun captureNativePicker(name:String) {
        val root=instrumentation.uiAutomation.rootInActiveWindow?:return
        try {
            check(root.packageName?.toString() in setOf("com.android.documentsui","com.google.android.documentsui"))
            val bitmap=requireNotNull(instrumentation.uiAutomation.takeScreenshot())
            try {File(evidence,name+".png").outputStream().use {check(bitmap.compress(Bitmap.CompressFormat.PNG,100,it))}}finally {bitmap.recycle()}
        } finally {root.recycle()}
    }

'''+needle)
        raw=raw.replace('''        val target=bounds?:throw AssertionError("Known native document picker target unavailable: $kind")''','''        if(bounds==null) {captureNativePicker("failure-picker-$kind");throw AssertionError("Known native document picker target unavailable: $kind")}
        val target=requireNotNull(bounds)
        if(kind=="file")captureNativePicker("diagnostic-picker-known-file")''')
        raw=raw.replace('''        check(mainReady)
        val result=waitFor''','''        if(!mainReady)captureNativePicker("failure-picker-after-file-click")
        check(mainReady)
        val result=waitFor''')
    (S/name).write_text(raw,encoding='utf-8',newline='\n')
builder=(B/'build-rf312-first-ocr-probe-round3.py').read_text(encoding='utf-8').replace(old.name,S.name)
(B/'build-rf312-first-ocr-probe-round4.py').write_text(builder,encoding='utf-8',newline='\n')
print(S)
