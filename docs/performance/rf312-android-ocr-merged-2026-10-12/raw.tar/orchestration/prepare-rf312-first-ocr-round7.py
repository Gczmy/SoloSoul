from pathlib import Path
import json
B=Path(__file__).parent;old=B/'rf312-first-ocr-probe-round6-20261012';S=B/'rf312-first-ocr-probe-round7-20261012'
r=json.loads((old/'first-100-diagnostic/report.json').read_text());assert r['restored'] and r['ownedPublicOcrInputRemoved']
S.mkdir(exist_ok=False)
for name in ['AndroidMediaPerfInstrumentedTest.kt','inputs.json','current-runtime-sources.json','media-native-driver.py','run-first-100-diagnostic.py','run-first-5000-diagnostic.py']:
    raw=(old/name).read_text(encoding='utf-8').replace(old.name,S.name)
    if name.endswith('.kt'):
        needle='''"file" -> !n.isEditable && (n.text?.toString()==fileName || n.contentDescription?.toString()?.contains(fileName)==true)''';assert raw.count(needle)==1
        raw=raw.replace(needle,'''"file" -> !n.isEditable && n.viewIdResourceName?.endsWith("/preview_icon")!=true &&
                    (n.text?.toString()==fileName || n.contentDescription?.toString()?.contains(fileName)==true)''')
    (S/name).write_text(raw,encoding='utf-8',newline='\n')
builder=(B/'build-rf312-first-ocr-probe-round6.py').read_text(encoding='utf-8').replace(old.name,S.name)
(B/'build-rf312-first-ocr-probe-round7.py').write_text(builder,encoding='utf-8',newline='\n')
print(S)
