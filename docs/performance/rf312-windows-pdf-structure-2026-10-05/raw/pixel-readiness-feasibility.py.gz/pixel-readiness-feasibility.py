import pathlib,struct,zlib,hashlib,json,datetime,sys
sys.stdout.reconfigure(encoding='utf-8')
s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-structure-20261005')
reference=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-component-20261005\samples100\sample-001\native-perf-sdk-pdf-screenshot.png')
b=reference.read_bytes();assert hashlib.sha256(b).hexdigest()=='5ffffdfc3c9f4a9db05a3170f5df71d07da13ce35a6528ffb011a435ff54b4c9' and len(b)<=262144 and b[:8]==b'\x89PNG\r\n\x1a\n'
chunks=[];offset=8;header=None
while offset<len(b):
 length=struct.unpack('>I',b[offset:offset+4])[0];assert length<=262144;kind=b[offset+4:offset+8];data=b[offset+8:offset+8+length];crc=struct.unpack('>I',b[offset+8+length:offset+12+length])[0];assert zlib.crc32(kind+data)&0xffffffff==crc;offset+=12+length
 if kind==b'IHDR':header=struct.unpack('>IIBBBBB',data)
 if kind==b'IDAT':chunks.append(data)
 if kind==b'IEND':break
assert offset==len(b) and header==(1028,749,8,6,0,0,0)
w,h=header[:2];stride=w*4;expected=(stride+1)*h;decompressor=zlib.decompressobj();raw=decompressor.decompress(b''.join(chunks),expected+1);assert len(raw)==expected and decompressor.eof and not decompressor.unused_data and not decompressor.unconsumed_tail
pixels=bytearray(stride*h);previous=bytearray(stride)
def paeth(a,b,c):
 p=a+b-c;pa,pb,pc=abs(p-a),abs(p-b),abs(p-c);return a if pa<=pb and pa<=pc else b if pb<=pc else c
for y in range(h):
 f=raw[y*(stride+1)];assert 0<=f<=4;row=bytearray(raw[y*(stride+1)+1:(y+1)*(stride+1)])
 for x in range(stride):
  a=row[x-4] if x>=4 else 0;b0=previous[x];c=previous[x-4] if x>=4 else 0
  add=0 if f==0 else a if f==1 else b0 if f==2 else (a+b0)//2 if f==3 else paeth(a,b0,c)
  row[x]=(row[x]+add)&255
 pixels[y*stride:(y+1)*stride]=row;previous=row
roi={'x':180,'y':225,'width':430,'height':36};mask=bytearray();points=[]
for y in range(roi['y'],roi['y']+roi['height']):
 for x in range(roi['x'],roi['x']+roi['width']):
  pixel=pixels[(y*w+x)*4:(y*w+x)*4+4];dark=pixel[3]>=240 and max(pixel[:3])<=64;mask.append(int(dark))
  if dark:points.append((x,y))
sha=lambda b:hashlib.sha256(b).hexdigest();digest=sha(mask);assert points and digest!=sha(bytes(len(mask)))
shifted=bytearray(len(mask))
for y in range(roi['height']):shifted[y*roi['width']+1:(y+1)*roi['width']]=mask[y*roi['width']:(y+1)*roi['width']-1]
assert sha(shifted)!=digest;partial=mask[:];partial[:len(mask)//2]=bytes(len(mask)//2);assert sha(partial)!=digest
matching=[]
for group in [pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-20261005\samples100-final'),pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-targets-20261005\samples100'),pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-pdf-component-20261005\samples100')]:
 for i in range(1,4):
  p=group/f'sample-{i:03d}'/'native-perf-sdk-pdf-screenshot.png';assert p.read_bytes()==reference.read_bytes();matching.append(str(p))
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Offline feasibility only; no new native readiness/performance claim','reference':str(reference),'referencePngSha256':sha(reference.read_bytes()),'publicPdfSha256':'ca60313e25ffa64f848d86780201a9570a0dbcb3bf733bfb5e4a65ed73f4fdfe','viewport':{'width':w,'height':h},'region':roi,'darkMaskRule':'alpha>=240 and RGB channels<=64, one byte per pixel row-major','darkMaskSha256':digest,'darkPixels':len(points),'textBounds':{'left':min(x for x,y in points),'top':min(y for x,y in points),'right':max(x for x,y in points),'bottom':max(y for x,y in points)},'blankRejected':True,'onePixelShiftRejected':True,'PartialRegionRejected':True,'matchingPriorNativeScreenshots':matching,'defaultImageDependencyAlreadyPresent':True,'renderVerified':False,'performanceMetrics':None,'next':'If actual structure exposes no suitable loading signal, evaluate bounded native screenshot checks of this public first-page region, enforcing dimensions, owned source/target and frame/loader identity; repeat and record capture overhead.'}
(s/'pixel-readiness-feasibility.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({k:v for k,v in record.items() if k not in ['matchingPriorNativeScreenshots','next']}))
