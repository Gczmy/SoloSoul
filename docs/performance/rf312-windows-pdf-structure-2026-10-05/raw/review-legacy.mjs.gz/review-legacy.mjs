import fs from 'node:fs';
import assert from 'node:assert/strict';
import { checkPdfDiagnostic } from 'file:///C:/Users/40299571/SoloSoul/tauri/scripts/native-perf-pdf-contract.mjs';
const groups = [
'C:/Users/40299571/AppData/Local/Temp/ss-rf312-pdf-20261005/samples100-final/native-perf-sdk-journey-results.json',
'C:/Users/40299571/AppData/Local/Temp/ss-rf312-pdf-targets-20261005/samples100/native-perf-sdk-journey-results.json',
'C:/Users/40299571/AppData/Local/Temp/ss-rf312-pdf-component-20261005/samples100/native-perf-sdk-journey-results.json',
];
const accepted = [];
for (const path of groups) {
 const r=JSON.parse(fs.readFileSync(path,'utf8').replace(/^\uFEFF/,''));
 assert.equal(r.success,true); assert.equal(r.samples.length,3);
 for (const x of r.samples) {
  assert.equal(x.success,true);
  checkPdfDiagnostic(x.nativeProof,x.owned,x.bound,r.fixture);
  accepted.push({report:path,index:x.index,schemaVersion:x.nativeProof.pdfDiagnostic.schemaVersion,renderVerified:x.nativeProof.pdfDiagnostic.renderVerified,performanceMetrics:x.nativeProof.pdfDiagnostic.performanceMetrics});
 }
}
const proof={at:new Date().toISOString(),scope:'Actual archived v1, v2 and v3 native proofs checked by current v4-aware offline contract',accepted};
fs.writeFileSync('C:/Users/40299571/AppData/Local/Temp/ss-rf312-pdf-structure-20261005/legacy-proof-review.json',JSON.stringify(proof,null,2)+'\n');
console.log(JSON.stringify({accepted:accepted.length,versions:[...new Set(accepted.map(x=>x.schemaVersion))]}));
