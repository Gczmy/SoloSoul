from pathlib import Path
r=Path(r'C:\Users\40299571\SoloSoul')
def read(p):return (r/p).read_text(encoding='utf-8-sig')
def write(p,t):(r/p).write_text(t,encoding='utf-8',newline='\n')
p='tauri/src-tauri/src/native_perf/sdk_pdf_viewer.js';t=read(p)
t=t.replace('const { expectedUrl } = __REQUEST__;','const { expectedUrl, expectedPdfUrl } = __REQUEST__;')
t=t.replace("const viewers = [...document.querySelectorAll('pdf-viewer')];","const viewers = documentMatches ? [...document.querySelectorAll('pdf-viewer')] : [];")
probe="""  // 只返回结构与几何；不读文本、id、class、HTML或原始URL。
  const structure = () => {
    const counts = { embed: 0, object: 0, iframe: 0, canvas: 0, pdfViewer: 0, customElements: 0 };
    const customTags = [], embeds = [], canvases = [], roots = [document];
    let scannedElements = 0, openShadowRoots = 0, truncated = false;
    const size = (v) => Number.isFinite(v) ? Math.min(16384, Math.max(0, Math.round(v))) : 0;
    const visible = (el) => {
      const rect = el.getBoundingClientRect(), style = getComputedStyle(el);
      return rect.width > 0 && rect.height > 0 && rect.right > 0 && rect.bottom > 0 &&
        rect.left < innerWidth && rect.top < innerHeight && style.display !== 'none' && style.visibility !== 'hidden';
    };
    const sourceClass = (source) => {
      if (source === expectedPdfUrl) return 'owned-pdf';
      if (!source || source === 'about:blank') return 'blank';
      try {
        const u = new URL(source);
        if (u.protocol === 'chrome-extension:' && /^[a-p]{32}$/.test(u.hostname) && !u.username && !u.password)
          return 'component-extension';
      } catch { /* 保留分类，不返回原始值。 */ }
      return 'other';
    };
    for (let ri = 0; ri < roots.length; ri++) {
      const walker = document.createTreeWalker(roots[ri], NodeFilter.SHOW_ELEMENT);
      for (let el; (el = walker.nextNode()); ) {
        if (scannedElements === 512) { truncated = true; break; }
        scannedElements++;
        const tag = el.localName;
        if (tag === 'pdf-viewer') counts.pdfViewer++;
        if (tag.includes('-')) {
          counts.customElements++;
          if (/^[a-z][a-z0-9-]{0,63}$/.test(tag) && !customTags.includes(tag)) {
            if (customTags.length < 32) customTags.push(tag); else truncated = true;
          }
        }
        if (['embed', 'object', 'iframe'].includes(tag)) {
          counts[tag]++;
          if (embeds.length < 8) {
            const rect = el.getBoundingClientRect();
            embeds.push({ kind: tag, sourceClass: sourceClass(tag === 'object' ? el.data : el.src),
              visible: visible(el), width: size(rect.width), height: size(rect.height) });
          } else truncated = true;
        }
        if (tag === 'canvas') {
          counts.canvas++;
          if (canvases.length < 8) canvases.push({ width: size(el.width), height: size(el.height), visible: visible(el) });
          else truncated = true;
        }
        if (el.shadowRoot) {
          if (openShadowRoots < 8) { roots.push(el.shadowRoot); openShadowRoots++; }
          else truncated = true;
        }
      }
      if (scannedElements === 512) { if (ri + 1 < roots.length) truncated = true; break; }
    }
    return { schemaVersion: 1, scope: 'windows-native-sdk-pdf-structure',
      documentReadyState: document.readyState, visibilityState: document.visibilityState,
      scannedElements, openShadowRoots, truncated, counts, customTags, embeds, canvases };
  };
"""
t=t.replace('  return {\n    schemaVersion: 1,',probe+'  return {\n    schemaVersion: 2,',1)
t=t.replace('    timeOriginMs: performance.timeOrigin,','    timeOriginMs: performance.timeOrigin,\n    structure: documentMatches ? structure() : null,')
write(p,t)
p='tauri/src-tauri/src/native_perf/sdk_pdf.rs';t=read(p);t=t.replace('mod targets;','mod targets;\n#[path = "sdk_pdf_structure.rs"]\nmod structure;',1)
t=t.replace('v.len()) != 10\n        || v["schemaVersion"] != 1','v.len()) != 11\n        || v["schemaVersion"] != 2',1)
t=t.replace('|| (v["paintedFrames"] == 2 && v["loadSucceeded"] != true)','|| (v["paintedFrames"] == 2 && v["loadSucceeded"] != true)\n        || !structure::valid(&v["structure"])',1)
t=t.replace('json!({"expectedUrl":url})','json!({"expectedUrl":url,"expectedPdfUrl":pdf})')
t=t.replace('json!({"schemaVersion":3,"scope":"windows-native-sdk-public-pdf-capability"','json!({"schemaVersion":4,"scope":"windows-native-sdk-public-pdf-capability"',1)
t=t.replace('let good = json!({"result":{"value":{"schemaVersion":1,"scope":"windows-native-sdk-pdf-viewer-candidate"','let mut good = json!({"result":{"value":{"schemaVersion":2,"scope":"windows-native-sdk-pdf-viewer-candidate"',1)
t=t.replace('assert!(candidate(&good).is_ok());','good["result"]["value"]["structure"] = structure::tests::empty();\n        assert!(candidate(&good).is_ok());',1)
write(p,t)
p='tauri/src-tauri/src/native_perf/sdk_pdf_targets.rs';t=read(p);t=t.replace('use super::{candidate, identifier, url_class, APP, VIEWER};','use super::{candidate, identifier, structure, url_class, APP, VIEWER};')
t=t.replace('json!({"expectedUrl":current.url})','json!({"expectedUrl":current.url,"expectedPdfUrl":pdf})')
needle='c.pdf_diagnostic.as_mut().unwrap()["targetDiagnostic"]["candidates"].as_array_mut().unwrap().push(json!({"snapshotIndex":index,"sessionId":session.id,"targetId":current.proof["id"],"frame":frame,"state":state,"observedAtMs":c.started.elapsed().as_secs_f64()*1000.0}));'
assert needle in t
t=t.replace(needle,'let trees=json!({"before":structure::frames(&before,&frame,pdf)?,"after":structure::frames(&after,&frame,pdf)?});\n            c.pdf_diagnostic.as_mut().unwrap()["targetDiagnostic"]["candidates"].as_array_mut().unwrap().push(json!({"snapshotIndex":index,"sessionId":session.id,"targetId":current.proof["id"],"frame":frame,"state":state,"observedAtMs":c.started.elapsed().as_secs_f64()*1000.0,"frameTrees":trees}));')
t=t.replace('json!({"schemaVersion":2,"scope":"windows-native-sdk-pdf-related-targets"','json!({"schemaVersion":3,"scope":"windows-native-sdk-pdf-related-targets"',1);write(p,t)
p='tauri/src-tauri/src/native_perf.rs';t=read(p);t=t.replace('windows-native-sdk-pdf-component-diagnostic-requested";','windows-native-sdk-pdf-component-diagnostic-requested\\0windows-native-sdk-pdf-structure-diagnostic-requested";',1);write(p,t)
p='tauri/scripts/native-perf-sdk-journey.mjs';t=read(p);t=t.replace("'windows-native-sdk-pdf-component-diagnostic-requested',","'windows-native-sdk-pdf-component-diagnostic-requested',\n        'windows-native-sdk-pdf-structure-diagnostic-requested',",1);t=t.replace('proof.pdfDiagnostic.schemaVersion !== 3','proof.pdfDiagnostic.schemaVersion !== 4');t=t.replace('Current PDF diagnostic requires component-session evidence','Current PDF diagnostic requires bounded structure evidence');write(p,t)
print('Updated fixed probe and Native schema; strict structure validators follow.')
