from pathlib import Path
import hashlib,json,zipfile
R=Path('D:/SoloSoul');S=Path(__file__).parent
N='rf312-integrated-windows-ocr-partial-2026-10-14';O=R/'docs/performance'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=load(S/'input-proof.json');report=load(S/'samples100/native-perf-sdk-journey-results.json')
assert not report['success'] and len(report['samples'])==3 and [x['success'] for x in report['samples']]==[True,False,False]
assert all(x['cleanupIntegrity']['complete'] for x in report['samples'])
assert report['samples'][1]['nativeProof']['reason']==report['samples'][2]['nativeProof']['reason']=='ocr-picker-controls-changed'
assert all(x['medianMs'] is None and x['p95Ms'] is None for x in report['summary'])
assert len(proof['sources'])==1983 and all(sha(R/n)==h for n,h in proof['sources'].items())
pkg=proof['runtime'];assert sha(Path(pkg['exe']))==pkg['sha256'] and all(sha(Path(x['copy']))==sha(Path(x['source']))==x['sha256'] for x in pkg['resources'])
cleanup=load(S/'failed-cache-cleanup.json');assert cleanup['identitiesChecked']==27 and len(cleanup['removedCachePaths'])==24 and cleanup['preservedBytesVerified']
assert len(cleanup['preservedVaultAndRootFiles'])==77 and cleanup['processesTerminatedByThisTool']==0
assert all(sha(Path(x['path']))==x['sha256'] for x in cleanup['preservedVaultAndRootFiles'])
assert all(not Path(p).exists() for p in cleanup['removedCachePaths'])
members={};excluded={'vault','app-data','profile','webview','temp','tmp','models','plugins'}
for p in S.rglob('*'):
    rel=p.relative_to(S)
    if any(s in excluded for s in rel.parts):continue
    if p.is_file() and p.suffix in ['.json','.log','.py','.mjs','.ps1']:
        assert not p.is_symlink() and not p.stat().st_file_attributes&0x400
        members['native/'+rel.as_posix()]=p
for p in [R/'tauri/src-tauri/src/native_perf/sdk_ocr_picker.rs',R/'tauri/scripts/native-perf-ocr.mjs',R/'tauri/scripts/native-perf-ocr-contract.mjs',R/'build/run-rf1146-native-media-ocr-20261014.py']:
    members['sources/'+p.name]=p
O.mkdir(exist_ok=False);rows=[]
with zipfile.ZipFile(O/'raw.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for n,p in sorted(members.items()):
        b=p.read_bytes();z.writestr(n,b);rows.append(dict(member=n,source=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with zipfile.ZipFile(O/'raw.zip') as z:
    assert z.testzip() is None
    for row in rows:
        b=z.read(row['member']);assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
def put(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as out:json.dump(v,out,indent=2);out.write('\n')
put(O/'index.json',dict(task='RF-312',members=rows,allLengthsSha256AndCrcVerified=True,programsPrivateDataAssetsAndCachesExcluded=True))
(O/'.gitattributes').write_text('raw.zip -text\n',encoding='utf-8',newline='\n')
put(O.with_suffix('.json'),dict(task='RF-312',accepted=False,fullRF312Accepted=False,goal='active',sourceHead='2e4952ad0',
    runtimeSha256=pkg['sha256'],sourceCount=1983,runtimeNotRebuilt=True,objects=100,requestedSamples=3,acceptedSamples=1,
    sampleOutcomes=[dict(index=s['index'],success=s['success'],reason=s['nativeProof']['reason'],failedStep=s['nativeProof']['failedStep']) for s in report['samples']],
    completeGroupMetrics=report['summary'],dataset5000NotStarted=True,originalBudgetsGuardsAndFailuresPreserved=True,
    successfulSampleOnly=dict(completeThreeLineResult=True,firstScanCount=1,ownedForegroundPickerVerified=True,viewportAndTwoFrameReadinessVerified=True),
    exactChangedControlSnapshotNotRecorded=True,rootCauseUnestablished=True,
    cleanup=dict(identitiesChecked=27,cachePathsRemoved=24,preservedFiles=77,bytesVerified=True,otherProcessesTerminated=0),
    next='Capture read-only expected/observed control snapshots and failing substep before changing any picker readiness logic; no broadening current strict ownership or message guards.',
    archive=dict(path=N+'/raw.zip',members=len(rows),bytes=(O/'raw.zip').stat().st_size,sha256=sha(O/'raw.zip'),allLengthsSha256AndCrcVerified=True)))
print(json.dumps(dict(task='RF-312',wholeGroupAccepted=False,accepted1Requested3=True,members=len(rows),exact24CachesRemoved=True)))
