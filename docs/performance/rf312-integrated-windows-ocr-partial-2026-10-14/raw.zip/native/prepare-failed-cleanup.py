from pathlib import Path
import json
R=Path('D:/SoloSoul');S=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
report=load(S/'samples100/native-perf-sdk-journey-results.json')
assert not report['success'] and len(report['samples'])==3
samples=[]
for s in report['samples']:
    assert s['cleanupIntegrity']['complete']
    snapshots=[s[n] for n in ['beforeSnapshot','afterSnapshot'] if n in s]
    ids={(p['pid'],p['creationMs']) for snapshot in snapshots for p in snapshot.get('processes',[])}
    assert len(ids)>=9
    samples.append(dict(index=s['index'],runId=s['owned']['runId'],pid=s['processId'],recordedIdentities=[dict(pid=p,creationMs=t) for p,t in sorted(ids)]))
plan=dict(terminalOwnedSamplesCleanupEligible=True,nativeMatrixAccepted=False,failedSamplesAccepted=False,groups=[dict(objects=100,terminal=True,samples=samples)])
with (S/'failed-cleanup-plan.json').open('x',encoding='utf-8') as out:json.dump(plan,out,indent=2)
text=(R/'build/rf1146-native-media-20261014/cleanup-failed-owned.ps1').read_text(encoding='utf-8')
text=text.replace('rf1146-native-media-20261014','rf1146-native-ocr-20261014')
text=text.replace('groups.Count -ne 2','groups.Count -ne 1').replace('samples.Count -ne 5','samples.Count -ne 3')
text=text.replace('Count -ne 80','Count -ne 24').replace('Exact eighty owned cache paths required','Exact twenty-four owned cache paths required')
with (S/'cleanup-failed-owned.ps1').open('x',encoding='utf-8',newline='\n') as out:out.write(text)
print('OCR whole group remains rejected; exact24 cache targets prepared using actual27 identities and original ownership guards')
