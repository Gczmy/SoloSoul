from pathlib import Path
import json, math, statistics

B = Path(__file__).parent
S = B / 'rf312-merged-repeat-api31-20261012'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
terminal = load(S / 'cohort-terminal.json')
assert terminal['allRequestedSamplesCompleted'] is True

def metric(values):
    ordered = sorted(values)
    if not ordered:
        return {'successfulSamples': 0, 'median': None, 'p95NearestRank': None}
    return {'successfulSamples': len(values), 'valuesInRunOrder': values, 'median': statistics.median(values),
            'p95NearestRank': ordered[math.ceil(.95 * len(ordered)) - 1], 'minimum': ordered[0], 'maximum': ordered[-1]}

groups = []
for count in [100, 5000]:
    attempts = [row for row in terminal['rows'] if row['objectCount'] == count]
    assert len(attempts) == 5
    accepted = []
    for row in attempts:
        root = Path(row['root'])
        receipt = load(root / f'first-{count}-diagnostic.receipt.json')
        assert receipt['exitCode'] == row['actualExitCode'] and row['fullyRestoredAndSourceUnchanged']
        if row['passed']:
            native = load(root / f'first-{count}-diagnostic/device-files/report.json')
            assert native['success'] and len(native['phases']) == 12 and all(p['success'] for p in native['phases'])
            accepted.append(native)
    names = [p['name'] for p in accepted[0]['phases']] if accepted else []
    assert all([p['name'] for p in native['phases']] == names for native in accepted)
    groups.append({'objectCount': count, 'attemptedSamples': len(attempts), 'successfulSamples': len(accepted),
                   'failures': [row for row in attempts if not row['passed']],
                   'phaseDurationMs': {name: metric([next(p['durationMs'] for p in native['phases'] if p['name'] == name) for native in accepted]) for name in names},
                   'wholeNativeJourneySpanMs': metric([(native['phases'][-1]['nativeFinishedAtNs'] - native['phases'][0]['nativeStartedAtNs']) / 1e6 for native in accepted]),
                   'firstOcrNativeFileTapToDomMs': metric([native['firstOcr']['fromFileSelectionMs'] for native in accepted]),
                   'actualEarlyJsTransportSends': metric([native['phases'][-1]['observer']['observedCount'] for native in accepted]),
                   'mainIncludingRunnerMaximumSampledPssBytes': metric([max(sample['pssBytes'] for sample in native['memorySamples']) for native in accepted]),
                   'mainIncludingRunnerMedianSampledPssBytes': metric([statistics.median(sample['pssBytes'] for sample in native['memorySamples']) for native in accepted]),
                   'rendererMemoryMeasured': False, 'continuousPeakMeasured': False,
                   'sampledMemoryReadDurationMs': metric([statistics.median((sample['finishedAtNs'] - sample['startedAtNs']) / 1e6 for sample in native['memorySamples']) for native in accepted])})
summary = {'task': 'RF-312', 'status': 'repeated-complete-journey-diagnostic', 'wholeRF312Accepted': False,
           'all10RequestedSamplesCompleted': True, 'all10Passed': terminal['all10Passed'], 'groups': groups,
           'allFailuresRetained': True, 'failedAttemptsNotReplaced': True,
           'p95Definition': 'nearest rank; ceil(.95*n)-1 in zero-based sorted values; with5 successful samples equals maximum; conditional on successful runs when failures exist',
           'phaseDefinition': 'native elapsedRealtimeNanos includes readiness/input/observation/painting overhead; not pure product operation latency',
           'memoryDefinition': 'main-process PSS includes instrumentation runner; excludes renderer; sampled maximum is not continuous peak',
           'cacheDefinition': 'process-first OCR and Activity startup; no OS page/model-cache clearing; not OS-cold startup',
           'remaining': ['renderer/full-process memory and sampler attribution', 'process-cold launch', 'physical hardware and other platforms', 'stable search capture after IME transition']}
(S / 'repeated-journey-summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'all10Passed': summary['all10Passed'], 'groups': [{'objectCount': g['objectCount'], 'successful': g['successfulSamples'], 'failures': len(g['failures']), 'ocrMedianMs': g['firstOcrNativeFileTapToDomMs']['median'], 'ocrP95Ms': g['firstOcrNativeFileTapToDomMs']['p95NearestRank']} for g in groups]}))
