from pathlib import Path
import datetime, hashlib, json, os, subprocess, time

R = Path('D:/SoloSoul')
B = Path(__file__).parent
S = B / 'rf312-merged-repeat-api31-20261012'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan = load(S / 'plan.json')
rows = []
environment = os.environ.copy()
environment.update(PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1', TEMP=str(B / 'tmp'), TMP=str(B / 'tmp'))
assert not (S / 'cohort-terminal.json').exists()
def record(name, value):
    (S / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
for sample in plan['samples']:
    root = Path(sample['root'])
    assert all(sha(root / name) == digest for name, digest in sample['files'].items())
    assert not (root / 'first-{}-diagnostic.receipt.json'.format(sample['objectCount'])).exists()
    command = ['C:/Python314/python.exe', str(root / 'run-sample.py')]
    started = time.monotonic()
    with (root / 'cohort-launcher.stdout.log').open('xb') as output, (root / 'cohort-launcher.stderr.log').open('xb') as error:
        process = subprocess.Popen(command, cwd=R, env=environment, stdin=subprocess.DEVNULL, stdout=output, stderr=error, creationflags=subprocess.CREATE_NO_WINDOW)
        record('cohort-live.json', {'pid': process.pid, 'command': command, 'sample': sample,
                                  'completed': len(rows), 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()})
        print('Native sample', sample['objectCount'], sample['ordinal'], 'PID', process.pid, flush=True)
        code = process.wait()
    receipt_path = root / f'first-{sample["objectCount"]}-diagnostic.receipt.json'
    driver_path = root / f'first-{sample["objectCount"]}-diagnostic/report.json'
    receipt, driver = load(receipt_path) if receipt_path.exists() else {}, load(driver_path) if driver_path.exists() else {}
    safe = all(driver.get(key) is True for key in ['restored', 'originalApksRestored', 'ownedProbeRemoved', 'blurRestored', 'ownedPublicOcrInputRemoved', 'frozenInputsUnchanged']) and receipt.get('sourceInputsUnchanged') is True
    row = {'ordinal': sample['ordinal'], 'objectCount': sample['objectCount'], 'root': str(root), 'actualExitCode': code,
           'passed': code == 0 and receipt.get('passed') is True, 'fullyRestoredAndSourceUnchanged': safe,
           'elapsedSeconds': time.monotonic() - started, 'error': driver.get('error')}
    rows.append(row)
    record('cohort-progress.json', {'requested': len(plan['samples']), 'completed': len(rows), 'rows': rows, 'failuresRetained': True, 'fullRF312Accepted': False})
    print('Sample finished', json.dumps(row), flush=True)
    if not safe:
        record('cohort-terminal.json', {'allRequestedSamplesCompleted': False, 'stoppedBecauseRestorationOrSourceGateNotProven': True, 'rows': rows, 'fullRF312Accepted': False})
        raise SystemExit(1)
accepted = len(rows) == 10 and all(row['passed'] for row in rows)
record('cohort-terminal.json', {'allRequestedSamplesCompleted': True, 'all10Passed': accepted, 'rows': rows, 'fullRF312Accepted': False})
raise SystemExit(0 if accepted else 1)
