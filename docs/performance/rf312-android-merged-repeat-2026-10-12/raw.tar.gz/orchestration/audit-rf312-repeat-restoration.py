from pathlib import Path
import hashlib, importlib.util, json

R = Path('D:/SoloSoul')
B = Path(__file__).parent.resolve()
S = B / 'rf312-merged-repeat-api31-20261012'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
terminal = load(S / 'cohort-terminal.json')
assert terminal['allRequestedSamplesCompleted']
spec = importlib.util.spec_from_file_location('repeat_private_restore', R / 'tauri/scripts/android-home-native-regression.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
rows, targets = [], []
for sample in terminal['rows']:
    root = Path(sample['root']).resolve()
    assert root.is_relative_to(B) and root.parent == B
    count = sample['objectCount']
    driver = load(root / f'first-{count}-diagnostic/report.json')
    assert sample['fullyRestoredAndSourceUnchanged']
    assert all(driver[k] for k in ['restored', 'originalApksRestored', 'ownedProbeRemoved', 'blurRestored', 'ownedPublicOcrInputRemoved', 'frozenInputsUnchanged'])
    a = root / f'first-{count}-diagnostic/private-data-before.tar'
    z = root / f'first-{count}-diagnostic/private-data-restored.tar'
    inventory = helper.inventory(a, require_empty=True)
    assert inventory == helper.inventory(z)
    rows.append({'root': root.name, 'objectCount': count, 'ordinal': sample['ordinal'], 'actualExitCode': sample['actualExitCode'],
                 'entries': len(inventory), 'allContentsLinksModesMatch': True,
                 'beforeSha256': hashlib.sha256(a.read_bytes()).hexdigest(), 'afterSha256': hashlib.sha256(z.read_bytes()).hexdigest()})
    targets.extend([a, z])
(S / 'independent-restoration-audit.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8')
for target in targets:
    assert target.resolve().is_relative_to(B) and target.name in ['private-data-before.tar', 'private-data-restored.tar'] and not target.is_symlink()
    target.unlink()
(S / 'private-backup-cleanup.json').write_text(json.dumps({'removed': len(targets), 'allPairsIndependentlyVerified': True,
                                                        'allNativeFailuresAndSuccessesRetained': True}) + '\n', encoding='utf-8')
print('Repeated native restoration pairs independently verified:', len(rows), '; private TARs removed:', len(targets))
