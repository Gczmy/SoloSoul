from pathlib import Path
import hashlib, json

B = Path(__file__).parent
SOURCE = B / 'rf312-first-ocr-probe-round15-20261012'
S = B / 'rf312-merged-repeat-api31-20261012'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs = load(SOURCE / 'inputs.json')
for count in [100, 5000]:
    receipt = load(SOURCE / f'first-{count}-diagnostic.receipt.json')
    assert receipt['exitCode'] == 0 and receipt['passed'] and receipt['restored']
assert sha(Path(inputs['runtimeTest']['path'])) == inputs['runtimeTest']['sha256']
assert sha(SOURCE / 'AndroidMediaPerfInstrumentedTest.kt') == inputs['runtimeTest']['homeTestSourceSha256']
S.mkdir(exist_ok=False)
samples = []
for ordinal in range(1, 6):
    for count in [100, 5000]:
        name = f'rf312-merged-repeat-{count}-{ordinal:03d}-20261012'
        target = B / name
        target.mkdir(exist_ok=False)
        copies = {}
        for filename in ['inputs.json', 'current-runtime-sources.json', 'AndroidMediaPerfInstrumentedTest.kt', 'media-native-driver.py', 'verify-finger-readiness.py']:
            raw = (SOURCE / filename).read_bytes()
            (target / filename).write_bytes(raw)
            copies[filename] = sha(target / filename)
        launcher = (SOURCE / f'run-first-{count}-diagnostic.py').read_text(encoding='utf-8').replace(SOURCE.name, name)
        (target / 'run-sample.py').write_text(launcher, encoding='utf-8', newline='\n')
        copies['run-sample.py'] = sha(target / 'run-sample.py')
        assert load(target / 'inputs.json') == inputs
        samples.append({'ordinal': ordinal, 'objectCount': count, 'root': str(target.resolve()), 'files': copies})
plan = {'task': 'RF-312', 'samplesPerCount': 5, 'order': 'alternating100/5000 for5 rounds', 'samples': samples,
        'sameMainApk': inputs['release']['apk'], 'sameTestApk': inputs['runtimeTest'],
        'failuresRetainedAndNeverReplaced': True, 'fullRF312Accepted': False,
        'startupDefinition': 'Activity launch; excludes runner/process start; OS caches not cleared',
        'tailDefinition': 'nearest-rank p95=sorted[ceil(.95*n)-1]; for5 samples this is the maximum; diagnostic scope only'}
(S / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n', encoding='utf-8')
print('Prepared10 frozen repeated complete native journeys; no APK rebuild or native run yet')
