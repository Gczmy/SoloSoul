from pathlib import Path
import hashlib, io, json, tarfile

R = Path('D:/SoloSoul')
B = Path(__file__).parent
S = B / 'rf312-merged-repeat-api31-20261012'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda raw: hashlib.sha256(raw).hexdigest()
plan, summary, terminal = load(S / 'plan.json'), load(S / 'repeated-journey-summary.json'), load(S / 'cohort-terminal.json')
assert terminal['all10Passed'] and summary['all10Passed'] and len(terminal['rows']) == 10
assert all(g['attemptedSamples'] == g['successfulSamples'] == 5 and not g['failures'] for g in summary['groups'])
assert len(load(S / 'independent-restoration-audit.json')) == 10 and load(S / 'private-backup-cleanup.json')['removed'] == 20
members = {}
for root in [S] + [Path(sample['root']) for sample in plan['samples']]:
    for p in root.rglob('*'):
        if not p.is_file() or p.suffix.lower() not in {'.json', '.log', '.py', '.kt', '.png'}:
            continue
        assert not p.is_symlink()
        members[root.name + '/' + p.relative_to(root).as_posix()] = p.read_bytes()
for name in ['prepare-rf312-merged-repeat.py', 'run-rf312-merged-repeat.py', 'summarize-rf312-merged-repeat.py', 'audit-rf312-repeat-restoration.py', 'archive-rf312-merged-repeat.py']:
    members['orchestration/' + name] = (B / name).read_bytes()
target = R / 'docs/performance/rf312-android-merged-repeat-2026-10-12'
target.mkdir(exist_ok=False)
archive = target / 'raw.tar'
with tarfile.open(archive, 'w') as output:
    for name, raw in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode = len(raw), 0o644
        output.addfile(info, io.BytesIO(raw))
index = {'task': 'RF-312', 'scope': 'same-APK repeated complete native finger OCR/search/media journey',
         'archiveSha256': sha(archive.read_bytes()), 'members': {n: {'bytes': len(raw), 'sha256': sha(raw)} for n, raw in sorted(members.items())},
         'privateDataCompiledProgramsKeysAndDatabasesExcluded': True}
with tarfile.open(archive) as source:
    assert {m.name for m in source} == set(members)
    for name, metadata in index['members'].items():
        raw = source.extractfile(name).read()
        assert len(raw) == metadata['bytes'] and sha(raw) == metadata['sha256']
(target / 'index.json').write_text(json.dumps(index, indent=2) + '\n', encoding='utf-8')
summary.update({'sameMainApk': plan['sameMainApk'], 'sameTestApk': plan['sameTestApk'],
                'order': plan['order'], 'allNativeOutcomes': terminal['rows'],
                'restorationAudit': load(S / 'independent-restoration-audit.json'),
                'backupCleanup': load(S / 'private-backup-cleanup.json'),
                'transportCommandAttribution': load(S / 'transport-command-attribution.json'),
                'ipcFollowup': 'listen/unlisten comprise most sends, concentrated in workspace/attachment/lock phases; per-event/owner attribution needed before claiming leaks or optimizing',
                'rawIndex': target.name + '/index.json'})
(R / 'docs/performance/rf312-android-merged-repeat-2026-10-12.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'members': len(members), 'archiveBytes': archive.stat().st_size, 'all10Passed': True, 'wholeRF312Accepted': False}))
