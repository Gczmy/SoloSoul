from pathlib import Path
import json,subprocess,time
R=Path('D:/SoloSoul');S=R/'build/rf312-current-windows-startup-20261014'
assert json.loads((S/'verification.json').read_text(encoding='utf-8'))['accepted']
cmd=['node',str(R/'build/verify-rf312-current-windows-startup-20261014.mjs')]
began=time.monotonic()
with (S/'independent-verifier.stdout.log').open('xb') as out,(S/'independent-verifier.stderr.log').open('xb') as err:
    p=subprocess.Popen(cmd,cwd=R,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    print('independent verifier live',p.pid,flush=True);code=p.wait()
with (S/'independent-verifier.receipt.json').open('x',encoding='utf-8') as out:
    json.dump(dict(command=cmd,pid=p.pid,exitCode=code,elapsedSeconds=time.monotonic()-began),out,indent=2)
print('independent verifier exit',code,flush=True)
raise SystemExit(code)
