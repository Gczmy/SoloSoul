from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');T=R/'build'
files=[('prepare-rf312-current-startup-20261012.py','prepare-rf312-current-windows-startup-generated-20261014.py'),
       ('run-rf312-current-startup-20261012.py','run-rf312-current-windows-startup-20261014.py')]
replacements=[('rf312-current-startup-20261012','rf312-current-windows-startup-20261014'),
    ('rf1129-native-build-20261011/runtime-package.json','current-windows-native-retry1-20261014/runtime-package.json'),
    ('rf1129-native-build-20261011/sources.json','current-windows-native-retry1-20261014/sources.json'),
    ('rf1129-native-build-20261011/build.receipt.json','current-windows-native-retry1-20261014/native-release.receipt.json'),
    ("'ss-rf312-current-startup-'+label+'-20261012'","'ss-rf312-current-windows-startup-'+label+'-20261014'")]
for old,new in files:
    text=(T/old).read_text(encoding='utf-8')
    for a,b in replacements:text=text.replace(a,b)
    if old.startswith('run-'):
        anchor="for fixture in proof['fixtures']:\n    verify();"
        assert text.count(anchor)==1
        insert="""for fixture in proof['fixtures']:
    # Fresh read-only desktop/session gate per cohort; no UI input or settings changes.
    label=fixture['label']
    source=(R/'build/rf121-theme-binding-20261010/rf1133-current-session-preflight.py').read_text(encoding='utf-8')
    source=source.replace('rf1133-native-matrix-20261012/session-before-native.json', 'rf312-current-windows-startup-20261014/session-before-'+label+'.json')
    probe=R/'build'/('rf312-current-windows-startup-session-'+label+'-20261014.py')
    with probe.open('x',encoding='utf-8') as out:out.write(source)
    subprocess.run(['C:/Python314/python.exe',str(probe)],cwd=R,check=True)
    session=load(S/('session-before-'+label+'.json'))
    assert session.get('connectionState')==0 and session.get('inputDesktopAvailable'), 'Interactive desktop precondition unavailable'
    verify();"""
        text=text.replace(anchor,insert)
    compile(text,str(T/new),'exec')
    with (T/new).open('x',encoding='utf-8',newline='\n') as out:out.write(text)
exec(compile((T/files[0][1]).read_text(encoding='utf-8'),str(T/files[0][1]),'exec'),{'__file__':str(T/files[0][1]),'__name__':'__main__'})
proof=json.loads((T/'rf312-current-windows-startup-20261014/input-proof.json').read_text(encoding='utf-8'))
assert len(proof['currentValidationSources'])==1983 and not proof['sourceDifferences']
assert proof['releasePackage']['sha256']=='446e6221baa45285607fa594ba4dd7ea151edf8de83ce281c6fcd80aad3734a1'
print('Current Windows paired startup prepared: same new Release, 1983 exact sources, five pairs per dataset, no UI input')
