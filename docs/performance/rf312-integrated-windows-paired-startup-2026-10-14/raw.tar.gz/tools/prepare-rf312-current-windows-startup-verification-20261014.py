from pathlib import Path
R=Path('D:/SoloSoul');T=R/'build';S=T/'rf312-current-windows-startup-20261014'
text=(T/'verify-rf312-current-startup-20261012.mjs').read_text(encoding='utf-8')
text=text.replace('rf312-current-startup-20261012','rf312-current-windows-startup-20261014')
text=text.replace('sourceFiles:1839','sourceFiles:1983')
text=text.replace('liveHistoricalTicketAgeRejectionPreserved:true','archivedContractClockOnlyNoLiveTicketAuthority:true')
with (T/'verify-rf312-current-windows-startup-20261014.mjs').open('x',encoding='utf-8',newline='\n') as out:out.write(text)
text=(T/'prepare-rf312-current-startup-cleanup-20261012.py').read_text(encoding='utf-8')
text=text.replace('rf312-current-startup-20261012','rf312-current-windows-startup-20261014')
text=text.replace('ss-rf312-current-startup-vault100-20261012','ss-rf312-current-windows-startup-vault100-20261014')
text=text.replace('ss-rf312-current-startup-vault5000-20261012','ss-rf312-current-windows-startup-vault5000-20261014')
anchor="(S/'cleanup-owned.ps1').write_text(s,encoding='utf-8',newline='\\n')"
assert text.count(anchor)==1
insert="""old_exe='D:\\\\SoloSoul\\\\build\\\\rf121-theme-binding-20261010\\\\ss-rf1129-diagnostic-runtime-20261011\\\\bin\\\\solo_soul.exe'
new_exe='D:\\\\SoloSoul\\\\build\\\\rf121-theme-binding-20261010\\\\current-windows-native-retry1-20261014\\\\runtime\\\\bin\\\\solo_soul.exe'
assert old_exe in s
s=s.replace(old_exe,new_exe)
"""
text=text.replace(anchor,insert+anchor)
compile(text,str(T/'prepare-rf312-current-windows-startup-cleanup-20261014.py'),'exec')
with (T/'prepare-rf312-current-windows-startup-cleanup-20261014.py').open('x',encoding='utf-8',newline='\n') as out:out.write(text)
print('Original strict startup contracts and historical-clock replay retained; cleanup derivation prepared without execution')
