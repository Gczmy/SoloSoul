from pathlib import Path
import hashlib,json,subprocess
R=Path('D:/SoloSoul');W=R/'build/rf121-theme-binding-20261010';S=R/'build/rf312-current-windows-startup-20261014';S.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
package=load(W/'current-windows-native-retry1-20261014/runtime-package.json')
assert sha(Path(package['exe']))==package['sha256'] and package['windowsGuiSubsystem']==2
assert len(package['resources'])==94
assert all(sha(Path(r['copy']))==r['sha256']==sha(Path(r['source'])) for r in package['resources'])
original=load(W/'current-windows-native-retry1-20261014/sources.json');current={n:sha(R/n) for n in original}
diff={n:{'buildSha256':h,'currentSha256':current[n]} for n,h in original.items() if current[n]!=h}
core={'tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/src/native_perf/startup.rs','tauri/src-tauri/src/native_perf/sdk_journey.rs','tauri/src-tauri/src/native_perf/sdk_cdp.rs','tauri/src-tauri/src/native_perf/fixture.rs','tauri/scripts/native-perf-startup.mjs'}
assert core.issubset(current) and not(core&diff.keys()), 'Startup engine changed since Release build'
for n in diff:assert not n.startswith('tauri/src/') and not n.startswith('tauri/crates/') and not n.startswith('solosoul_cli/'),n
fixtures=[]
for label in ['vault100','vault5000']:
    p=R/'build/rf312-maintenance-20261009/fixtures'/label
    assert p.is_dir();files=[]
    for f in sorted(p.rglob('*')):
        if f.is_file():
            assert not(f.stat().st_file_attributes&0x400)
            files.append({'path':f.relative_to(p).as_posix(),'sha256':sha(f),'bytes':f.stat().st_size})
    fixtures.append({'label':label,'path':str(p),'files':files})
proof={'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
       'releasePackage':package,'releaseBuildSources':original,'currentValidationSources':current,'sourceDifferences':diff,
       'releaseBuildReceipt':load(W/'current-windows-native-retry1-20261014/native-release.receipt.json'),
       'releaseBuildNotRerun':True,'startupEngineAndProductionSourcesUnchanged':True,
       'sourceManifestAllBytesEqualCurrent':not bool(diff),'fixtures':fixtures,'samplesPerDataset':5,
       'mode':'SDK-CDP-read-only paired startup; no password or other UI input',
       'otherPlatformsAccepted':False,'fullRF312Accepted':False}
(S/'input-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'sources':len(current),'differences':list(diff),'releaseSha256':package['sha256'],'fixtures':[len(x['files']) for x in fixtures]}))
