from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('D:/SoloSoul');S=R/'build/rf312-current-windows-startup-20261014'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=load(S/'input-proof.json');package=proof['releasePackage']
def save(name,obj):
    with (S/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,indent=2)
def verify():
    assert all(sha(R/n)==h for n,h in proof['currentValidationSources'].items())
    assert sha(Path(package['exe']))==package['sha256']
    assert all(sha(Path(r['source']))==sha(Path(r['copy']))==r['sha256'] for r in package['resources'])
    for f in proof['fixtures']:
        p=Path(f['path']);assert {x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file()}=={x['path'] for x in f['files']}
        assert all(sha(p/x['path'])==x['sha256'] for x in f['files'])
env=os.environ.copy()
temp=R/'build/android-native-feasibility-20261010/tmp'
env.update(TEMP=str(temp),TMP=str(temp),PYTHONUTF8='1')
for key in ['PDFIUM_LIBRARY_PATH','SOLOSOUL_REGISTRY_PUBKEY','WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS','WEBVIEW2_USER_DATA_FOLDER','SOLOSOUL_NATIVE_PERF_ROOT','SOLOSOUL_NATIVE_PERF_PORT']:env.pop(key,None)
rows=[]
for fixture in proof['fixtures']:
    # Fresh read-only desktop/session gate per cohort; no UI input or settings changes.
    label=fixture['label']
    source=(R/'build/rf121-theme-binding-20261010/rf1133-current-session-preflight.py').read_text(encoding='utf-8')
    source=source.replace('rf1133-native-matrix-20261012/session-before-native.json', 'rf312-current-windows-startup-20261014/session-before-'+label+'.json')
    probe=R/'build'/('rf312-current-windows-startup-session-'+label+'-20261014.py')
    with probe.open('x',encoding='utf-8') as out:out.write(source)
    subprocess.run(['C:/Python314/python.exe',str(probe)],cwd=R,check=True)
    session=load(S/('session-before-'+label+'.json'))
    assert session.get('connectionState')==0 and session.get('inputDesktopAvailable'), 'Interactive desktop precondition unavailable'
    verify();label=fixture['label'];output=R/'build'/('ss-rf312-current-windows-startup-'+label+'-20261014')
    assert not output.exists()
    cmd=['node','scripts/native-perf-startup.mjs','--exe',package['exe'],'--fixture',fixture['path'],'--output',str(output),'--samples','5']
    start=time.monotonic()
    with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=R/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(label+'.live.json',{'pid':p.pid,'command':cmd,'output':str(output)});print(label,'live PID',p.pid,flush=True);code=p.wait()
    verify();report=load(output/'report.json') if (output/'report.json').is_file() else None
    complete=bool(code==0 and report and report.get('summary',{}).get('complete') and report.get('sourceUnchanged'))
    receipt={'command':cmd,'output':str(output),'exitCode':code,'elapsedSeconds':time.monotonic()-start,'accepted':complete,'sourceAndArtifactHashesUnchanged':True,'summary':report.get('summary') if report else None}
    save(label+'.receipt.json',receipt);rows.append(receipt);print(label,'terminal exit',code,'accepted',complete,flush=True)
    if report and any(sample.get('cleanupIncomplete') for sample in report.get('samples',[])):
        save('verification.json',{'accepted':False,'rows':rows,'stoppedForIncompleteCleanup':True});raise SystemExit(1)
accepted=len(rows)==2 and all(row['accepted'] for row in rows)
save('verification.json',{'accepted':accepted,'rows':rows,'sameProfileStartupOnly':True,'fullRF312Accepted':False,'fullRF121Accepted':False})
raise SystemExit(0 if accepted else 1)
