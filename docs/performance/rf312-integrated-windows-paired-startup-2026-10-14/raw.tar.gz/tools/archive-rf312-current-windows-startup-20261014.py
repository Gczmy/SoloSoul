from pathlib import Path
import json
R=Path('D:/SoloSoul');T=R/'build';S=T/'rf312-current-windows-startup-20261014'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
proof=load(S/'input-proof.json');v=load(S/'independent-validation.json')
assert len(proof['currentValidationSources'])==1983 and not proof['sourceDifferences']
assert v['memorySnapshotsValid']==len(v['memorySnapshots'])==40
assert load(S/'independent-verifier.receipt.json')['exitCode']==0
text=(T/'archive-rf312-current-startup-20261012.py').read_text(encoding='utf-8')
text=text.replace('rf312-current-startup-20261012','rf312-current-windows-startup-20261014')
text=text.replace('rf312-current-windows-paired-startup-2026-10-12','rf312-integrated-windows-paired-startup-2026-10-14')
text=text.replace("'ss-rf312-current-startup-'+fixture['label']+'-20261012'", "'ss-rf312-current-windows-startup-'+fixture['label']+'-20261014'")
text=text.replace("validation['memorySnapshotsValid']==39", "validation['memorySnapshotsValid']==40")
text=text.replace("'sourcesValidated':1839", "'sourcesValidated':1983")
text=text.replace("'memorySnapshotsValid':39,'memorySnapshotsMissing':1", "'memorySnapshotsValid':40,'memorySnapshotsMissing':0")
text=text.replace("'originalNullMemoryReadingRetained':True", "'originalNullMemoryReadingRetained':False")
text=text.replace('d05636dcc',proof['sourceHead'])
start=text.index("outcomes={'sourceHead':")
end=text.index("put(S/'observed-tool-outcomes.json'",start)
text=text[:start]+"""outcomes={'sourceHead':proof['sourceHead'],'nativeDatasetDriverExitCodes':[load(S/(f['label']+'.receipt.json'))['exitCode'] for f in proof['fixtures']],
 'independentVerifierExitCodes':[load(S/'independent-verifier.receipt.json')['exitCode']],
 'historicalClockValidation':'original gate replayed at recorded warm.beforeSnapshot.observedAt; no live authority or budget change',
 'memoryScope':'40 actual accepted snapshots; startup contract unchanged, not a full journey or continuous peak memory baseline',
 'nativeTestReruns':0,'oldFailuresModified':False,'cleanupObservedExitCode':0}
"""+text[end:]
names=[('prepare-rf312-current-startup-20261012.py','prepare-rf312-current-windows-startup-20261014.py'),
       ('run-rf312-current-startup-20261012.py','run-rf312-current-windows-startup-20261014.py'),
       ('verify-rf312-current-startup-20261012.mjs','verify-rf312-current-windows-startup-20261014.mjs'),
       ('prepare-rf312-current-startup-cleanup-20261012.py','prepare-rf312-current-windows-startup-cleanup-20261014.py'),
       ('archive-rf312-current-startup-20261012.py','archive-rf312-current-windows-startup-20261014.py')]
for a,b in names:text=text.replace(a,b)
anchor='rows=[]\nwith tarfile.open'
assert text.count(anchor)==1
extras="""for name in ['prepare-rf312-current-windows-startup-generated-20261014.py','prepare-rf312-current-windows-startup-verification-20261014.py',
 'run-rf312-current-windows-startup-independent-20261014.py','rf312-current-windows-startup-session-vault100-20261014.py',
 'rf312-current-windows-startup-session-vault5000-20261014.py']:
 members['tools/'+name]=R/'build'/name
"""
text=text.replace(anchor,extras+anchor)
anchor="put(R/'docs/performance'/(N+'.json'),result)"
assert text.count(anchor)==1
text=text.replace(anchor,"result.update(device=load(S/'device.json'),releaseSourceHead=proof['releasePackage']['gitHead'],goal='active',currentSourceManifestMatchesBuild=True)\n"+anchor)
generated=T/'archive-rf312-current-windows-startup-generated-20261014.py'
compile(text,str(generated),'exec')
with generated.open('x',encoding='utf-8',newline='\n') as out:out.write(text)
exec(compile(text,str(generated),'exec'),{'__file__':str(generated),'__name__':'__main__'})
