# RF-312 current default Release preparation and rejected native protocol

This archive preserves the exact local build and diagnostic recipe at source
525da2ea01aa9966726a951d0282735caa315d04. It is not a completed performance baseline.
The default Release APK and separate self-targeted UiAutomation observer were built
and verified; no application APK, native library, signing key, private TAR, Vault,
raw process identity, screenshot or raw application log is included.

The scripts retain their original local SDK/worktree/output paths and frozen
artifact bindings. On another machine, rebuild at the recorded source, generate
the same production frontend and public media fixtures, configure paths and bind
new artifact hashes before running; preserve original guards. The unused legacy
releaseprobe input remains a rejected-install artifact binding, not an installed
target runner. Do not remove it merely to pass a guard. This is a local recipe,
not a universal turnkey command.

Use the default custom-protocol feature only, cargo --locked --offline --release
for x86_64-linux-android, current frontendDist override only, and original mobile
resources. Gradle packaging remains offline with rustBuild excluded only because
the exact separately verified current library is supplied. Signing is for internal
validation with the existing test certificate, never production signing.

The independent observer instruments org.solosoul.rf312observer itself. The target
app is nondebuggable and no target JavaScript is injected. Hierarchies are limited
to the app and dedicated emulator's document picker. Input requires a fresh exact
node match, visible/enabled state, native screen bounds, one real finger pair, or
one of two public fixture strings. Preserve 45-second phase and 240-second observer
bounds, process/package ownership and complete private/system restoration.

The first memory preflight was rejected before any product install because raw
ADB CRLF line endings did not match the local LF-only parser. The next independently
named run normalizes only line endings and retains original CPU/memory bounds.
It launched and actually unlocked the public 100-object account with two native
finger pairs and public keyboard events, then failed the original home-statistics
assertion within 45 seconds. The accessibility tree kept an em dash/zero counts
while recent records appeared. No full protocol or performance sample is accepted.
The original rejection is not relabelled success. Actual home pixels and freshly
refreshed native nodes still need correlation; no product defect is proven.

All 148 original private entries, package bytes/UID/debug flags and literal system
settings were restored. The observer, app/test packages, emulator and private ADB
were removed; protected old ADB was only inspected. Raw failed records and private
readbacks stay local. Do not rerun one-shot scripts into existing output folders.
