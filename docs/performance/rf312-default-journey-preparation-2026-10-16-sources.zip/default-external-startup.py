"""Initial native protocol proof for the full default Release journey, not a performance distribution."""
from pathlib import Path
import hashlib,importlib.util,json,re,subprocess,time
import xml.etree.ElementTree as ET

S=Path(__file__).parent;APP='com.solosoul.app'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
def visible(n):
    m=re.fullmatch(r'\[(\d+),(\d+)\]\[(\d+),(\d+)\]',n.get('bounds',''))
    return bool(m and int(m[3])>int(m[1]) and int(m[4])>int(m[2]) and n.get('visible-to-user')=='true' and n.get('enabled')=='true')
def labels(nodes):
    return [n.get(k,'') for n in nodes for k in ('text','content-desc') if n.get(k)]
def observe(adb,read,output,count,uid):
    assert count in (100,5000)
    inputs=load(S/'inputs.json')
    session_path=S/'journey-observer-session.py'
    assert sha(session_path)==inputs['journeyObserverSessionSha256']
    spec=importlib.util.spec_from_file_location('current_independent_observer',session_path)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    source=S/'android-home-native-regression-fixed.py'
    assert sha(source)==inputs['processReaderSha256']
    spec=importlib.util.spec_from_file_location('strict_process_reader',source)
    reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
    target=output/'default-external';target.mkdir(exist_ok=False)
    stages=[];started=time.monotonic();process_id=None
    def focused():
        text=read('shell','dumpsys','window','displays')
        if not re.search(r'mCurrentFocus=.*'+re.escape(APP)+'/',text):raise RuntimeError('Native application focus required')
        if process_id is not None and reader.read_process_ids(read,APP)!=process_id:raise RuntimeError('Application process changed')
        if APP in read('shell','dumpsys','activity','instrumentation'):raise RuntimeError('Target instrumentation forbidden')
    with helper.session(adb,read,output) as observer:
        adb('shell','am','force-stop',APP,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert not reader.read_process_ids(read,APP)
        launched=time.monotonic()
        framework=read('shell','am','start','-W','-n',APP+'/.MainActivity')
        (target/'framework-start.txt').write_text(framework,encoding='utf-8')
        assert re.search(r'^Status:\s*ok\s*$',framework,re.M)
        times=re.findall(r'^TotalTime:\s*(\d+)\s*$',framework,re.M);assert len(times)==1 and int(times[0])>0
        process_id=reader.read_process_ids(read,APP);assert re.fullmatch(r'[1-9]\d*',process_id)
        save(target/'observed-process-start.json',dict(pid=int(process_id),uid=uid,frameworkTotalTimeMs=int(times[0])))
        def snapshot(deadline,*,capture=False):
            remaining=deadline-time.monotonic()
            if not 0<remaining<=45:raise TimeoutError('Original 45-second phase bound exhausted')
            row=observer.snapshot(remaining,screenshot=capture)
            if not row['allowedRoot'] or row['rootPackage']!=APP:return row,[]
            nodes=[n for n in ET.fromstring(row['xml']).iter('node') if n.get('package')==APP and visible(n)]
            return row,nodes
        def wait(predicate,deadline,*,capture=False):
            while time.monotonic()<deadline:
                row,nodes=snapshot(deadline)
                if predicate(nodes):
                    focused()
                    if capture:row,nodes=snapshot(deadline,capture=True)
                    if not predicate(nodes):raise RuntimeError('State changed during final native screenshot')
                    if time.monotonic()>=deadline:raise TimeoutError('Native evidence arrived after phase bound')
                    return row,nodes
            raise TimeoutError('Native visible state not established within phase bound')
        def unique(predicate,deadline):
            stable=None;first=0;observations=0
            while time.monotonic()<deadline:
                _,nodes=snapshot(deadline);matches=[n for n in nodes if predicate(n)]
                if len(matches)!=1:stable=None;observations=0;continue
                current=helper.Client.target(matches[0]);now=time.monotonic()
                if current!=stable:stable=current;first=now;observations=1
                else:observations+=1
                if observations>=3 and now-first>=.350:
                    focused();return matches[0]
            raise TimeoutError('Single target did not remain stable for three observations and 350ms')
        password=lambda n:n.get('class')=='android.widget.EditText' and n.get('password')=='true'
        unlock=lambda n:n.get('clickable')=='true' and 'Unlock' in (n.get('text'),n.get('content-desc'))
        def login(nodes):
            words=labels(nodes)
            return (sum(password(n) for n in nodes)==1 and sum(unlock(n) for n in nodes)==1
                    and any(f'acc_rf312_{count}' in x for x in words) and any('Performance Fixture' in x for x in words))
        row,nodes=wait(login,launched+45,capture=True)
        stages.append(dict(name='public-password-form-accessibility',hostObservedUpperBoundMs=(time.monotonic()-launched)*1000,
            nativeScreenshot=row.get('screenshot'),expectedPublicAccount=True,onePasswordAndUnlock=True))
        began=time.monotonic();deadline=began+45
        node=unique(password,deadline);observer.tap(node,deadline-time.monotonic())
        node=unique(lambda n:password(n) and n.get('focused')=='true',deadline)
        assert node.get('text','')==''
        observer.type_public(node,'perf-baseline-only-password',deadline-time.monotonic())
        wait(lambda nodes:sum(password(n) and len(n.get('text',''))==len('perf-baseline-only-password') for n in nodes)==1,deadline)
        node=unique(unlock,deadline);observer.tap(node,deadline-time.monotonic())
        def home(nodes):
            words=labels(nodes)
            return not any(password(n) for n in nodes) and str(count) in words and any('Identity'==x for x in words)
        row,nodes=wait(home,deadline,capture=True)
        stages.append(dict(name='public-password-unlock-home',hostObservedUpperBoundMs=(time.monotonic()-began)*1000,
            nativeScreenshot=row.get('screenshot'),objectCount=count,publicHomeCountVerified=True,
            passwordFormGone=True,realNativeFingerAndKeyboard=True))
        focused()
        summary=dict(success=True,scope='default-release-independent-public-unlock-observer-smoke',
            objectCount=count,frameworkTotalTimeMs=int(times[0]),stages=stages,
            stageNames=['framework-startup','public-password-form-accessibility','public-password-unlock-home'],
            targetInstrumentationInjected=False,javaScriptInjected=False,externalUiAutomationObserver=True,
            defaultReleaseNonDebuggable=True,fullDefaultJourneyAccepted=False,performanceDistributionAccepted=False,
            startupUsesAccessibilityUpperBound=True,twoCommittedFramesProven=False,
            elapsedSeconds=time.monotonic()-started,pid=int(process_id),uid=uid)
        save(target/'evidence.json',summary)
    assert load(output/'independent-observer/cleanup.json')['accepted']
    return summary
