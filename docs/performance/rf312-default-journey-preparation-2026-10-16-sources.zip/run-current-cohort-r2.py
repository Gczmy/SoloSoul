from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,time
S=Path(__file__).parent;W=Path('D:/SoloSoul/build/worktrees/rf1158-perf-owner')
B=Path('D:/SoloSoul/build/android-native-feasibility-20261010')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=load(S/'inputs.json');plan=load(S/'external-plan.json')
assert plan['requested']==1 and plan['scope']=='native-unlock-protocol-proof-only'
assert all(sha(S/n)==h for n,h in load(S/'native-tool-inputs-r2.json').items())
spec=importlib.util.spec_from_file_location('canonical_empty_backup_audit',W/'tauri/scripts/android-home-native-regression.py')
home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
result=dict(scope='default-release-independent-public-unlock-prototype',prototypePassed=False,outcomes=[],
 fullDefaultJourneyAccepted=False,performanceDistributionAccepted=False)
out=S/'prototype-100';command=[sys.executable,str(S/'default-external-native-driver.py'),
 '--adb',str(B/'sdk/platform-tools/adb.exe'),'--serial',plan['serial'],'--avd',plan['avd'],
 '--apk',inputs['release']['apk']['path'],'--restore-apk',inputs['originalDebug']['copy'],
 '--test-apk',inputs['runtimeTest']['path'],'--fixture',inputs['fixedFixtures']['100']['root'],
 '--object-count','100','--mode','supported','--output',str(out)]
started=time.monotonic()
with (S/'prototype-100.stdout.log').open('xb') as stdout,(S/'prototype-100.stderr.log').open('xb') as stderr:
    child=subprocess.Popen(command,cwd=W,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    save(S/'prototype-100.live.json',dict(pid=child.pid,command=command))
    code=child.wait()
row=dict(exitCode=code,elapsedSeconds=time.monotonic()-started,allOriginalStateRestored=False,passed=False)
try:
    report=load(out/'report.json')
    before=home.inventory(out/'private-data-before.tar',require_empty=True)
    after=home.inventory(out/'private-data-restored.tar',require_empty=True)
    row['originalPrivateEntries']=len(before)
    row['allOriginalStateRestored']=bool(before==after and report.get('restored') and report.get('originalApksRestored')
        and report.get('blurRestored') and report.get('ownedProbeRemoved') and report.get('ownedPublicOcrInputRemoved')
        and report.get('frozenInputsUnchanged') and not report.get('restoreError') and not report.get('sourceRestoreError'))
    evidence=load(out/'default-external/evidence.json')
    cleanup=load(out/'independent-observer/cleanup.json')
    row['passed']=bool(code==0 and report['passed'] and evidence['success'] and cleanup['accepted']
        and row['allOriginalStateRestored'] and evidence['objectCount']==100
        and evidence['stageNames']==['framework-startup','public-password-form-accessibility','public-password-unlock-home']
        and not evidence['targetInstrumentationInjected'] and not evidence['javaScriptInjected']
        and not evidence['fullDefaultJourneyAccepted'] and not evidence['performanceDistributionAccepted'])
except Exception as error:row['auditError']=repr(error)
result['outcomes'].append(row);result['prototypePassed']=row['passed']
save(S/'external-terminal-r2.json',result)
print(json.dumps(result),flush=True)
raise SystemExit(0 if result['prototypePassed'] else 1)
