from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import time
import zipfile

stage = Path(__file__).resolve().parent
root = Path('D:/SoloSoul/build/worktrees/rf1158-perf-owner')
base = Path('D:/SoloSoul/build/android-native-feasibility-20261010')
previous = Path('D:/SoloSoul/build/rf1183-status-body-contrast-20261016')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n', encoding='utf-8', newline='\n')
receipt = load(stage / 'android-release-build/receipt.json')
library = load(stage / 'android-release-build/library.json')
assert receipt['exitCode'] == 0 and receipt['sourceFrontendAndResourcesUnchanged']
assert library['actualCargoReleaseBuilt'] and library['defaultFeaturesOnly'] and not library['earlyObserverMarkersPresent']
lib = Path(library['path'])
assert sha(lib) == library['sha256']
out = stage / 'android-release-package'
out.mkdir(exist_ok=False)
sources = load(stage / 'sources.json')
frontend = load(stage / 'frontend.json')
old_frontend = load(stage / 'old-frontend-preserved.json')
mobile = load(stage / 'mobile-resources.json')
inputs = load(stage / 'android-release-build/input-proof.json')
packages = load(previous / 'android-debug-package2/packages.json')['packages']
g = root / 'tauri/src-tauri/gen/android'
generated = load(Path('D:/SoloSoul/build/rf1109-full-home-current-20261015/kotlin-codegen-preparation.json'))['generated']
metadata = load(previous / 'android-debug-package2/generated-metadata.json')['ignoredBuildMetadataHashes']
metadata_paths = {g / name: digest for name, digest in metadata.items()}
bridge = g / 'app/src/main/java/com/solosoul/app/generated'
generated_paths = {bridge / row['name']: row['generatedSha256'] for row in generated}
debug_outputs = [g / 'app/build/outputs/apk/x86_64/debug/app-x86_64-debug.apk',
                 g / 'app/build/outputs/apk/androidTest/x86_64/debug/app-x86_64-debug-androidTest.apk']
debug_output_hashes = {p: sha(p) for p in debug_outputs}
asset_source = previous / 'android-debug-package2/assets'
asset_hashes = {p.relative_to(asset_source).as_posix(): sha(p) for p in asset_source.rglob('*') if p.is_file()}
assert asset_hashes == load(stage / 'assets.json') and len(asset_hashes) == 98 and 'bundled-resource-manifest.json' in asset_hashes
assets = out / 'assets'
shutil.copytree(asset_source, assets)
jni = out / 'jni/x86_64/libsolo_soul.so'
jni.parent.mkdir(parents=True)
shutil.copyfile(lib, jni)
assert sha(jni) == library['sha256']
save(out / 'asset-inputs.json', dict(assetHashes=asset_hashes,
    copiedFromVerifiedCurrentDebugResources=True, sourceManifestVersion=load(assets / 'bundled-resource-manifest.json')['version']))

def frozen():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == inputs['sourceHead']
    assert all(sha(root / name) == digest for name, digest in sources.items())
    assert {p.relative_to(stage / 'current-dist').as_posix(): sha(p) for p in (stage / 'current-dist').rglob('*') if p.is_file()} == frontend
    assert {p.relative_to(root / 'tauri/dist').as_posix(): sha(p) for p in (root / 'tauri/dist').rglob('*') if p.is_file()} == old_frontend
    assert {p.relative_to(root / 'tauri/src-tauri/resources-mobile').as_posix(): sha(p) for p in (root / 'tauri/src-tauri/resources-mobile').rglob('*') if p.is_file()} == mobile
    assert all(sha(path) == digest for path, digest in {**metadata_paths, **generated_paths, **debug_output_hashes}.items())
    assert all(sha(Path(row['path'])) == row['sha256'] for row in packages)
    assert {p.relative_to(assets).as_posix(): sha(p) for p in assets.rglob('*') if p.is_file()} == asset_hashes
    assert sha(lib) == sha(jni) == library['sha256']

save(out / 'ignored-build-and-bridge-binding.json', dict(metadata={str(p):h for p,h in metadata_paths.items()}, generatedBridge={str(p):h for p,h in generated_paths.items()}, currentDebugOutputs={str(p):h for p,h in debug_output_hashes.items()}))
frozen()
init = out / 'package.init.gradle'
init.write_text("""gradle.beforeProject { project ->
  project.pluginManager.withPlugin('com.android.application') {
    def android = project.extensions.getByName('android')
    android.sourceSets.getByName('main').assets.setSrcDirs([project.file('""" + assets.as_posix() + """')])
    android.sourceSets.getByName('main').jniLibs.setSrcDirs([project.file('""" + (out / 'jni').as_posix() + """')])
    project.extensions.getByName('androidComponents').finalizeDsl { extension ->
      extension.buildTypes.getByName('release').signingConfig = null
    }
  }
}
""", encoding='utf-8', newline='\n')
jdk = Path('C:/Users/40299571/ss-android/jdk')
sdk = base / 'sdk'
env = dict(os.environ, JAVA_HOME=str(jdk), ANDROID_HOME=str(sdk), ANDROID_SDK_ROOT=str(sdk),
    NDK_HOME=str(sdk / 'ndk/27.0.12077973'), ANDROID_NDK_HOME=str(sdk / 'ndk/27.0.12077973'),
    ANDROID_USER_HOME=str(base / 'android-user'), RUSTUP_HOME=str(base / 'rustup'), RUSTUP_TOOLCHAIN='1.96.0',
    CARGO_HOME=str(base / 'cargo-home'), CARGO_TARGET_DIR=str(base / 'cargo-target'), CARGO_BUILD_JOBS='1',
    CARGO_NET_OFFLINE='true', GRADLE_USER_HOME=str(base / 'gradle-home'), TEMP=str(stage), TMP=str(stage),
    JAVA_TOOL_OPTIONS='-Duser.home=' + str(base / 'java-home') + ' -Djava.io.tmpdir=' + str(stage))
env['PATH'] = str(jdk / 'bin') + ';' + env.get('PATH', '')
for key in ['ANDROID_SDK_HOME', 'SOLOSOUL_RF312_ANDROID_BUILD_OFFLINE', 'PDFIUM_LIBRARY_PATH',
            'SOLOSOUL_KEYSTORE_PATH', 'SOLOSOUL_KEYSTORE_PASSWORD', 'SOLOSOUL_KEY_ALIAS', 'SOLOSOUL_KEY_PASSWORD',
            'SOLOSOUL_REGISTRY_PUBKEY', 'GITHUB_RUN_NUMBER']:
    env.pop(key, None)

def run(label, command, expected=0):
    frozen()
    began = time.monotonic()
    with (out / (label + '.stdout.log')).open('xb') as stdout, (out / (label + '.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen(command, cwd=g, env=env, stdin=subprocess.DEVNULL, stdout=stdout,
                                 stderr=stderr, creationflags=subprocess.CREATE_NO_WINDOW)
        save(out / (label + '.live.json'), dict(pid=child.pid, command=command, startedUnixSeconds=time.time()))
        print(label + ' started', flush=True)
        code = child.wait()
    frozen()
    save(out / (label + '.receipt.json'), dict(exitCode=code, elapsedSeconds=round(time.monotonic()-began, 3),
                                            frozenInputsHeld=True))
    assert code == expected, (label, code)
    return (out / (label + '.stdout.log')).read_text(encoding='utf-8')

nm = sdk / 'ndk/27.0.12077973/toolchains/llvm/prebuilt/windows-x86_64/bin/llvm-nm.exe'
old = load(base / 'rf1161-default-android-20261015/android-release-package/package-verification.json')
prior = run('prior-default-jni-exports', [str(nm), '-D', '--defined-only', old['library']['copy']])
current = run('current-default-jni-exports', [str(nm), '-D', '--defined-only', str(lib)])
exports = lambda text: sorted(line.split()[-1] for line in text.splitlines() if line.split() and
    (line.split()[-1].startswith('Java_') or line.split()[-1] == 'JNI_OnLoad'))
assert exports(prior) and exports(prior) == exports(current)
save(out / 'jni-exports.json', dict(names=exports(current), unchanged=True))
started = time.time()
run('release-gradle-package', ['cmd.exe', '/d', '/c', str(g / 'gradlew.bat'), ':app:assembleX86_64Release',
    '-x', ':app:rustBuildX86_64Release', '--init-script', str(init), '--offline', '--no-daemon', '--max-workers', '2'])
apk_files = list((g / 'app/build/outputs/apk/x86_64/release').glob('*.apk'))
assert len(apk_files) == 1 and apk_files[0].stat().st_mtime >= started - 2
unsigned = out / 'app-x86_64-release-unsigned.apk'
shutil.copyfile(apk_files[0], unsigned)
stripped = g / 'app/build/intermediates/stripped_native_libs/x86_64Release/stripX86_64ReleaseDebugSymbols/out/lib/x86_64/libsolo_soul.so'
with zipfile.ZipFile(unsigned) as archive:
    assert all(not n.startswith('lib/') or n.startswith('lib/x86_64/') for n in archive.namelist())
    actual = archive.read('lib/x86_64/libsolo_soul.so')
    assert hashlib.sha256(actual).hexdigest() == sha(stripped)
    assert b'android-native-ipc-transport-observer' not in actual and b'__SOLOSOUL_ANDROID_NATIVE_PERF__' not in actual
    for name, digest in asset_hashes.items():
        assert hashlib.sha256(archive.read('assets/' + name)).hexdigest() == digest
badging = run('release-badging', [str(sdk / 'build-tools/35.0.0/aapt2.exe'), 'dump', 'badging', str(unsigned)])
assert "package: name='com.solosoul.app'" in badging and "native-code: 'x86_64'" in badging
assert 'application-debuggable' not in badging and "minSdkVersion:'28'" in badging and "targetSdkVersion:'36'" in badging
assert "launchable-activity: name='com.solosoul.app.MainActivity'" in badging
signer = load(base / 'rf312-android-release-build-20261012/internal-test-signer.json')
key = Path(signer['keyFile'])
assert signer['existingTestApkCertificateMatches'] and sha(key) == signer['keyFileSha256']
assert signer['certificateSha256'] == packages[0]['certificateSha256']
tool = [str(jdk / 'bin/java.exe'), '-jar', str(sdk / 'build-tools/35.0.0/lib/apksigner.jar')]
run('unsigned-check', tool + ['verify', '--verbose', str(unsigned)], expected=1)
signed = out / 'app-x86_64-release-default-internal-validation.apk'
run('internal-test-sign', tool + ['sign', '--ks', str(key), '--ks-key-alias', 'androiddebugkey',
    '--ks-pass', 'pass:android', '--key-pass', 'pass:android', '--out', str(signed), str(unsigned)])
certificate = run('internal-test-signature', tool + ['verify', '--verbose', '--print-certs', str(signed)])
assert re.findall(r'certificate SHA-256 digest: (\S+)', certificate) == [signer['certificateSha256']]
with zipfile.ZipFile(unsigned) as a, zipfile.ZipFile(signed) as b:
    assert all(hashlib.sha256(a.read(n)).digest() == hashlib.sha256(b.read(n)).digest()
               for n in a.namelist() if not n.endswith('/'))
    assert all(n.endswith('/') or re.fullmatch(r'META-INF/(?:MANIFEST\.MF|[^/]+\.(?:SF|RSA|DSA|EC))', n)
               for n in set(b.namelist()) - set(a.namelist()))
assert sha(key) == signer['keyFileSha256']
frozen()
save(out / 'package-verification.json', dict(acceptedPackagePreparation=True,
    apk=dict(path=str(signed), sha256=sha(signed), bytes=signed.stat().st_size),
    sourceHead=inputs['sourceHead'], library=library, packagedStrippedLibrarySha256=sha(stripped),
    defaultFeaturesOnly=True, observerMarkersPresent=False, applicationDebuggable=False,
    certificateSha256=signer['certificateSha256'], productionSigningUsed=False,
    minSdk=28, targetSdk=36, abi='x86_64', assetFilesVerified=len(asset_hashes),
    sourceFrontendResourcesAndDebugArtifactsUnchanged=True, signingChangedCodeOrAssets=False,
    nativeRuntimeAccepted=False, RF312Closed=False))
print('Current default Release APK prepared; native default-control queue remains unaccepted', flush=True)
