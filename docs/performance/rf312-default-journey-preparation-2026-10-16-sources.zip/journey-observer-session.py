from contextlib import contextmanager
from pathlib import Path
import hashlib,json,os,re,shlex,subprocess,time,uuid
import xml.etree.ElementTree as ET

S=Path(__file__).parent
PKG='org.solosoul.rf312observer'
APP='com.solosoul.app'
ALLOWED={APP,'com.android.documentsui'}
BASE=Path('D:/SoloSoul/build/android-native-feasibility-20261010')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)

class Client:
    def __init__(self,adb,output,process,remote):
        self.adb=adb;self.output=output;self.process=process;self.remote=remote;self.ordinal=0
        self.deadline=time.monotonic()+240
    def call(self,*args,deadline,**kwargs):
        remaining=min(deadline,self.deadline)-time.monotonic()
        if remaining<=0:raise TimeoutError('Original full/phase observation budget exhausted')
        return self.adb(*args,timeout=remaining,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kwargs)
    def exists(self,name,deadline):
        if not re.fullmatch(r'(?:ready|error|stopped|response-\d{3}\.json)',name):raise ValueError('Invalid protocol name')
        try:self.call('shell','run-as',PKG,'test','-e',self.remote+name,deadline=deadline);return True
        except subprocess.CalledProcessError as e:
            if e.returncode==1 and e.stdout==e.stderr==b'':return False
            raise
    def get(self,name,deadline):
        if not re.fullmatch(r'(?:ready|error|stopped|response-\d{3}\.json|frame-\d{3}\.png)',name):raise ValueError('Invalid protocol name')
        size=self.call('shell','run-as',PKG,'stat','-c','%s',self.remote+name,deadline=deadline).stdout.strip()
        if not re.fullmatch(rb'[1-9]\d*',size) or int(size)>4*1024*1024:raise RuntimeError('Invalid bounded response size')
        data=self.call('exec-out','run-as',PKG,'cat',self.remote+name,deadline=deadline).stdout
        if len(data)!=int(size):raise RuntimeError('Response size changed')
        return data
    def alive(self,deadline):
        if self.exists('error',deadline):raise RuntimeError('Independent observer: '+self.get('error',deadline).decode())
        if self.process.poll() is not None:raise RuntimeError('Independent observer exited early')
    def request(self,value,timeout):
        if not 0<timeout<=45:raise ValueError('Per-phase observer budget must be within 45 seconds')
        self.ordinal+=1
        if self.ordinal>512:raise RuntimeError('Bounded observer request count exhausted')
        name=f'{self.ordinal:03d}';deadline=min(self.deadline,time.monotonic()+timeout)
        payload=json.dumps(value,ensure_ascii=True,separators=(',',':')).encode()
        if len(payload)>16384:raise ValueError('Bounded public request too large')
        save(self.output/('request-'+name+'.json'),value)
        temporary=self.remote+'request-'+name+'.tmp';final=self.remote+'request-'+name+'.json'
        command='run-as '+PKG+' sh -c '+shlex.quote('umask 077; cat > '+temporary+' && mv '+temporary+' '+final)
        self.alive(deadline)
        self.call('shell',command,input=payload,deadline=deadline)
        response='response-'+name+'.json'
        while not self.exists(response,deadline):
            self.alive(deadline);time.sleep(min(.025,max(0,deadline-time.monotonic())))
        raw=self.get(response,deadline);result=json.loads(raw)
        if result.get('success') is not True or result.get('action')!=value['action']:
            raise RuntimeError('Independent observer action mismatch')
        if type(result.get('nativeStartedAtNs')) is not int or type(result.get('nativeFinishedAtNs')) is not int or result['nativeFinishedAtNs']<result['nativeStartedAtNs']:
            raise RuntimeError('Invalid native observation clock')
        if type(result.get('allowedRoot')) is not bool or result['allowedRoot']!=(result.get('rootPackage') in ALLOWED):
            raise RuntimeError('Invalid root ownership receipt')
        if value['action']=='snapshot':
            xml=result.get('xml')
            if not isinstance(xml,str) or '<!DOCTYPE' in xml.upper():raise RuntimeError('Invalid hierarchy receipt')
            tree=ET.fromstring(xml)
            if tree.tag!='hierarchy' or len(list(tree.iter('node')))>5000:raise RuntimeError('Invalid bounded hierarchy')
            if not result['allowedRoot'] and list(tree):raise RuntimeError('Unrelated hierarchy contents refused')
        else:
            if not result['allowedRoot'] or result.get('rootPackage')!=value['expectedPackage']:
                raise RuntimeError('Input receipt owner differs')
            if value['action']=='tap' and (result.get('singleFingerPair') is not True or result.get('toolType')!='finger'
                    or result.get('bounds')!=value['target']['bounds']):
                raise RuntimeError('Single exact native finger receipt required')
            if value['action']=='type-public' and (result.get('publicTextOnly') is not True
                    or type(result.get('keyEvents')) is not int or result['keyEvents']<=0 or result['keyEvents']%2):
                raise RuntimeError('Public native keyboard receipt required')
        if time.monotonic()>deadline:raise TimeoutError('Observer result arrived after phase deadline')
        (self.output/response).write_bytes(raw)
        if 'screenshot' in result:
            frame='frame-'+name+'.png'
            if result['screenshot']!=frame or result.get('rootPackage') not in ALLOWED:raise RuntimeError('Invalid screenshot ownership')
            image=self.get(frame,deadline)
            if not image.startswith(b'\x89PNG\r\n\x1a\n'):raise RuntimeError('Native screenshot is not PNG')
            (self.output/frame).write_bytes(image)
        return result
    def snapshot(self,timeout,*,screenshot=False):
        return self.request(dict(action='snapshot',screenshot=screenshot),timeout)
    @staticmethod
    def target(node):
        fields=('package','class','text','content-desc','password','bounds')
        row={k:node.attrib[k] for k in fields}
        if row['package'] not in ALLOWED or node.get('enabled')!='true' or node.get('visible-to-user')!='true':
            raise RuntimeError('Target outside allowed visible hierarchy')
        return row
    def tap(self,node,timeout):
        return self.request(dict(action='tap',expectedPackage=node.get('package'),target=self.target(node)),timeout)
    def type_public(self,node,value,timeout):
        if value not in ('perf-baseline-only-password','needle'):raise ValueError('Only public fixture text allowed')
        if node.get('package')!=APP:raise RuntimeError('Public text requires application owner')
        return self.request(dict(action='type-public',expectedPackage=APP,target=self.target(node),text=value),timeout)
    def back(self,package,timeout):
        if package not in ALLOWED:raise ValueError('Unowned back target')
        return self.request(dict(action='back',expectedPackage=package),timeout)

@contextmanager
def session(adb,read,output):
    package=load(S/'observer-build-r3/package.json');apk=Path(package['apk'])
    assert package['passed'] and package['instrumentationTarget']==PKG and not package['targetInstrumentationInjected']
    assert sha(apk)==package['sha256']
    assert all(sha(S/'observer-source'/n)==h for n,h in package['sourceSha256'].items())
    assert not read('shell','pm','list','packages',PKG)
    folder=output/'independent-observer';folder.mkdir(exist_ok=False)
    token=uuid.uuid4().hex;remote='files/'+token+'/'
    installed=False;process=None;stdout=stderr=None;client=None;original_error=None
    cleanup=dict(accepted=False,targetInstrumentationInjected=False,javaScriptInjected=False,originalObserverAbsent=True)
    try:
        adb('install','--no-streaming',str(apk),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        installed=True
        base=read('shell','pm','path',PKG)
        assert re.fullmatch(r'package:/data/app/(?:[A-Za-z0-9_~+=.-]+/){1,2}base\.apk',base)
        actual=read('shell','sha256sum',base.removeprefix('package:')).split()
        assert actual==[package['sha256'],base.removeprefix('package:')]
        assert APP not in read('shell','dumpsys','activity','instrumentation')
        stdout=(folder/'instrumentation.stdout.log').open('xb');stderr=(folder/'instrumentation.stderr.log').open('xb')
        command=[str(BASE/'sdk/platform-tools/adb.exe'),'-H','127.0.0.1','-P','5057','-s','emulator-5578',
                 'shell','am','instrument','-w','-r','-e','token',token,PKG+'/'+PKG+'.Observer']
        process=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
        save(folder/'live.json',dict(pid=process.pid,command=command,observerApkSha256=package['sha256']))
        client=Client(adb,folder,process,remote);deadline=time.monotonic()+15
        while not client.exists('ready',deadline):
            client.alive(deadline);time.sleep(.025)
        cleanup['connectedBeforeTargetStart']=True
        yield client
    except BaseException as error:
        original_error=error;cleanup['originalError']=repr(error);raise
    finally:
        errors=[]
        if client is not None:
            deadline=time.monotonic()+10
            # Cleanup gets its own original ten-second stop budget even after
            # measurement expiry; it cannot extend accepted measurement time.
            client.deadline=deadline
            try:
                if process.poll() is None:
                    client.call('shell','run-as',PKG,'touch',remote+'stop',deadline=deadline)
                    cleanup['commandExitCode']=process.wait(timeout=max(.001,deadline-time.monotonic()))
                else:cleanup['commandExitCode']=process.returncode
                cleanup['normalStopReceipt']=client.exists('stopped',deadline)
                if client.exists('error',deadline):cleanup['observerError']=client.get('error',deadline).decode()
            except Exception as error:
                errors.append(repr(error))
                if process.poll() is None:
                    adb('shell','am','force-stop',PKG,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                    process.wait(timeout=10);cleanup['forcedOwnObserverStop']=True
            cleanup['requests']=client.ordinal
        for handle in (stdout,stderr):
            if handle is not None:handle.close()
        if installed:
            try:
                current=read('shell','pm','path',PKG)
                assert current==base
                assert read('shell','sha256sum',current.removeprefix('package:')).split()==[package['sha256'],current.removeprefix('package:')]
                adb('uninstall',PKG,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                cleanup['observerUninstalled']=not read('shell','pm','list','packages',PKG)
                cleanup['observerInstrumentationAbsent']=PKG not in read('shell','dumpsys','activity','instrumentation')
            except Exception as error:errors.append(repr(error))
        cleanup['errors']=errors
        cleanup['accepted']=bool(cleanup.get('normalStopReceipt') and cleanup.get('observerUninstalled')
            and cleanup.get('observerInstrumentationAbsent') and cleanup.get('commandExitCode')==0
            and not cleanup.get('observerError') and not cleanup.get('forcedOwnObserverStop') and not errors)
        save(folder/'cleanup.json',cleanup)
        if not cleanup['accepted'] and original_error is None:raise RuntimeError('Independent observer cleanup not verified')
