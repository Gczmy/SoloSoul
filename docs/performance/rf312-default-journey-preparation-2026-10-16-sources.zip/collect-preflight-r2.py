from pathlib import Path
import datetime as dt, hashlib, json, os, re, subprocess

S=Path(__file__).parent
P=S/'native-default-protocol-smoke-r2'
out=P/'preflight-independent'
out.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
live=load(P/'live.json')
shell=r'C:\Users\40299571\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe'
script='''$ErrorActionPreference='Stop'
@(Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -eq SERVER_PID -or ($_.Name -like 'qemu-system-*' -and $_.ParentProcessId -eq LAUNCHER_PID) } | ForEach-Object {
 [pscustomobject]@{Name=$_.Name;ProcessId=$_.ProcessId;ParentProcessId=$_.ParentProcessId;CreationDate=$_.CreationDate.ToString('yyyy-MM-ddTHH:mm:ss.ffffffzzz');ExecutablePath=$_.ExecutablePath;CommandLine=$_.CommandLine}
}) | ConvertTo-Json -Depth 4
'''.replace('SERVER_PID',str(live['serverPid'])).replace('LAUNCHER_PID',str(live['emulatorLauncherPid']))
(out/'capture-owned-host.ps1').write_text(script,encoding='utf-8')
result=subprocess.run([shell,'-NoLogo','-NoProfile','-NonInteractive','-File',str(out/'capture-owned-host.ps1')],
    capture_output=True,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
(out/'host.stdout').write_bytes(result.stdout);(out/'host.stderr').write_bytes(result.stderr)
result.check_returncode()
owners=json.loads(result.stdout.decode('utf-8-sig'))
assert len(owners)==2 and sum(r['ProcessId']==live['serverPid'] for r in owners)==1
vm=next(r for r in owners if r['Name'].startswith('qemu-system-'))
assert vm['ParentProcessId']==live['emulatorLauncherPid']
assert Path(vm['ExecutablePath']).resolve().is_relative_to(Path('D:/SoloSoul/build/android-native-feasibility-20261010/sdk/emulator').resolve())
birth=dt.datetime.fromisoformat(vm['CreationDate'])
save(P/'independent-owned-host-processes.json',owners)
adb=Path('D:/SoloSoul/build/android-native-feasibility-20261010/sdk/platform-tools/adb.exe')
def call(label,args):
    r=subprocess.run([str(adb),'-H','127.0.0.1','-P','5057','-s','emulator-5578',*args],
        capture_output=True,stdin=subprocess.DEVNULL,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr)
    r.check_returncode();return r.stdout
assert call('avd',['emu','avd','name']).decode().splitlines()[0]=='SoloSoul_RF312_Default_20261016V2'
assert call('api',['shell','getprop','ro.build.version.sdk']).strip()==b'31'
assert call('abi',['shell','getprop','ro.product.cpu.abi']).strip()==b'x86_64'
provider=call('webview',['shell','dumpsys','webviewupdate']).decode()
assert '91.0.4472.114' in provider
for package in ['com.solosoul.app','com.solosoul.app.test','com.solosoul.app.releaseprobe','org.solosoul.rf312observer']:
    assert not call('absent-'+package,['shell','pm','list','packages',package]).strip()
inventory=call('dropbox',['shell','dumpsys','dropbox']).decode('utf-8').replace('\r\n','\n')
call('system-app-anr',['shell','dumpsys','dropbox','--print','system_app_anr'])
last=call('last-anr',['shell','dumpsys','activity','lastanr']).decode('utf-8')
rows=re.findall(r'^(2026-\d\d-\d\d \d\d:\d\d:\d\d) (\S+) \(([^\n]*)\)$',inventory,re.M)
count=re.search(r'^Drop box contents: (\d+) entries$',inventory,re.M)
assert count and len(rows)==int(count[1]) and rows
assert re.search(r'^Max entries: 1000$',inventory,re.M)
assert [r[0] for r in rows]==sorted(r[0] for r in rows)
prebirth=lambda stamp:dt.datetime.strptime(stamp,'%Y-%m-%d %H:%M:%S').replace(tzinfo=birth.tzinfo)<birth
assert prebirth(rows[0][0])
assert all(prebirth(stamp) for stamp,tag,_ in rows if tag.endswith('_anr')), 'Current boot ANR: reject before installing product'
assert '<no ANR has occurred since boot>' in last
windows=call('windows',['shell','dumpsys','window']).decode('utf-8')
focus=[r.strip() for r in windows.splitlines() if 'mCurrentFocus=' in r]
assert len(focus)==1 and 'com.android.launcher3' in focus[0]
png=call('screenshot',['exec-out','screencap','-p'])
assert png.startswith(b'\x89PNG\r\n\x1a\n')
(out/'preflight.png').write_bytes(png)
assert sha(P/'preflight.png')==load(P/'environment-preflight.json')['pngSha256']
save(out/'result.json',dict(passed=True,currentVmBirth=vm['CreationDate'],currentBootAnrAbsent=True,
    completeDropBoxEntries=len(rows),allFourProductObserverPackagesAbsent=True,focus=focus,
    originalPngSha256=sha(P/'preflight.png'),latestPngSha256=sha(out/'preflight.png'),
    screenshotInspectionStillRequired=True,api=31,abi='x86_64',webView='91.0.4472.114'))
print(json.dumps(dict(passed=True,entries=len(rows),screenInspectionStillRequired=True)))
