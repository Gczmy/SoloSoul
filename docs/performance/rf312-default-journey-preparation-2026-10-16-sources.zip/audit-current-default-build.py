from pathlib import Path
import hashlib,json,re,struct,zipfile
S=Path(__file__).parent;W=Path('D:/SoloSoul/build/worktrees/rf1158-perf-owner')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
package=load(S/'android-release-package/package-verification.json')
library=load(S/'android-release-build/library.json')
assert package['acceptedPackagePreparation'] and package['sourceHead']==library['sourceHead']=='525da2ea01aa9966726a951d0282735caa315d04'
assert package['defaultFeaturesOnly'] and library['actualCargoReleaseBuilt'] and library['defaultFeaturesOnly']
assert not package['applicationDebuggable'] and not package['observerMarkersPresent'] and not library['earlyObserverMarkersPresent']
assert sha(Path(package['apk']['path']))==package['apk']['sha256'] and sha(Path(library['path']))==library['sha256']
assert load(S/'android-release-build/receipt.json')['sourceFrontendAndResourcesUnchanged']
assert load(S/'android-release-build/receipt.json')['debugAndDedicatedOldArtifactsPreserved']
sources=load(S/'sources.json');assert len(sources)==1795 and all(sha(W/n)==h for n,h in sources.items())
frontend=load(S/'frontend.json');assert len(frontend)==38
assert {p.relative_to(S/'current-dist').as_posix():sha(p) for p in (S/'current-dist').rglob('*') if p.is_file()}==frontend
mobile=load(S/'mobile-resources.json');assert len(mobile)==46
assert {p.relative_to(W/'tauri/src-tauri/resources-mobile').as_posix():sha(p) for p in (W/'tauri/src-tauri/resources-mobile').rglob('*') if p.is_file()}==mobile
assert {p.relative_to(W/'tauri/dist').as_posix():sha(p) for p in (W/'tauri/dist').rglob('*') if p.is_file()}==load(S/'old-frontend-preserved.json')
preserved=load(S/'android-release-build/preserved-artifacts.json')
assert all(sha(Path(n))==h for n,h in preserved.items())
data=Path(library['path']).read_bytes()
assert data[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<HH',data,16)==(3,62)
assert not any(x in data for x in (b'android-native-ipc-transport-observer',b'__SOLOSOUL_ANDROID_NATIVE_PERF__'))
all_keys={n:n.encode() in data for n in frontend};assert all(all_keys.values()),all_keys
assets=load(S/'assets.json');assert len(assets)==98
with zipfile.ZipFile(package['apk']['path']) as z:
    assert z.testzip() is None
    assert hashlib.sha256(z.read('lib/x86_64/libsolo_soul.so')).hexdigest()==library['sha256']==package['packagedStrippedLibrarySha256']
    assert all(hashlib.sha256(z.read('assets/'+n)).hexdigest()==h for n,h in assets.items())
    dex=b''.join(z.read(n) for n in z.namelist() if re.fullmatch(r'classes(?:\d+)?\.dex',n))
    assert dex and b'AndroidFixedVaultPerfInstrumentedTest' not in dex
receipts={'prior-default-jni-exports':0,'current-default-jni-exports':0,'release-gradle-package':0,
 'release-badging':0,'unsigned-check':1,'internal-test-sign':0,'internal-test-signature':0}
assert all(load(S/'android-release-package'/f'{n}.receipt.json')['exitCode']==code for n,code in receipts.items())
badging=(S/'android-release-package/release-badging.stdout.log').read_text()
assert "package: name='com.solosoul.app'" in badging and 'application-debuggable' not in badging
assert "minSdkVersion:'28'" in badging and "targetSdkVersion:'36'" in badging and "native-code: 'x86_64'" in badging
cert=(S/'android-release-package/internal-test-signature.stdout.log').read_text()
assert re.findall(r'certificate SHA-256 digest: (\S+)',cert)==[package['certificateSha256']]
assert load(S/'android-release-package/jni-exports.json')['unchanged']
binding=load(S/'android-release-package/ignored-build-and-bridge-binding.json')
assert all(sha(Path(p))==h for group in binding.values() for p,h in group.items())
observer=load(S/'observer-build-r3/package.json')
assert observer['passed'] and observer['instrumentationTarget']=='org.solosoul.rf312observer'
assert sha(Path(observer['apk']))==observer['sha256']
assert all(sha(S/'observer-source'/n)==h for n,h in observer['sourceSha256'].items())
with zipfile.ZipFile(observer['apk']) as z:
    assert z.testzip() is None
    d=z.read('classes.dex')
    assert all(n in d for n in (b'singleFingerPair',b'type-public',b'getRealMetrics',b'com.android.documentsui'))
assert load(S/'protocol-unit-receipt.json')['tests']==16
v=dict(passed=True,sourceHead=package['sourceHead'],sourceFiles=1795,frontendFiles=38,mobileResources=46,
 androidAssets=98,all38CurrentFrontendKeysActuallyEmbedded=True,librarySha256=library['sha256'],
 apkSha256=package['apk']['sha256'],apkBytes=package['apk']['bytes'],defaultFeaturesOnly=True,
 applicationDebuggable=False,earlyObserverMarkersAbsent=True,currentJniAndAssetsMatchActualApk=True,
 originalDebugOldReleaseAndWorkspaceDistPreserved=True,sourceInputsHeld=True,certificateVerified=True,
 actualSeparateObserverCompiledAndVerified=True,observerProtocolUnitTests=16,
 originalMissingCompilePlatformAndPreflightRejectionsPreserved=True,
 existingJavaSource8R8AndGradleWarningsRetained=True,nativeRuntimeAccepted=False,fullDefaultJourneyAccepted=False,
 independentOfNativeSmokeResult=True)
with (S/'independent-default-build-audit.json').open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
print(json.dumps(dict(passed=True,sourceFiles=1795,embeddedCurrentFrontendFiles=38,actualApkAssets=98,defaultReleaseVerified=True,nativeRuntimeAccepted=False)))
