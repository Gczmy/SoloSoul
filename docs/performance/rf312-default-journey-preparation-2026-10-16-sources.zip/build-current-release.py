from pathlib import Path
import hashlib,json,os,shutil,struct,subprocess,time,traceback

S=Path(__file__).parent.resolve();W=Path('D:/SoloSoul/build/worktrees/rf1158-perf-owner')
B=Path('D:/SoloSoul/build/android-native-feasibility-20261010')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
git=lambda *a:subprocess.check_output(['git',*a],cwd=W).decode('utf-8-sig')
prepared=load(S/'input-preparation.json');assert prepared['passed']
HEAD=prepared['sourceHead'];assert git('rev-parse','HEAD').strip()==HEAD
assert not git('status','--porcelain','--ignore-submodules').strip()
out=S/'android-release-build';out.mkdir(exist_ok=False)
sources=load(S/'sources.json');frontend=load(S/'frontend.json');mobile=load(S/'mobile-resources.json')
old_frontend=load(S/'old-frontend-preserved.json')
old=load(S/'previous-default-package.json')
restore=load(S/'restore-debug-packages.json')
F=S/'current-dist';R=W/'tauri/src-tauri/resources-mobile';D=W/'tauri/dist'
debug=B/'cargo-target/x86_64-linux-android/debug/libsolo_soul.so'
generated=W/'tauri/src-tauri/gen/android/app/src/main/jniLibs/x86_64/libsolo_soul.so'
preserved={str(debug):sha(debug)}
if generated.is_file():preserved[str(generated)]=sha(generated)
for p in restore['packages']:preserved[p['path']]=p['sha256']
preserved[old['apk']['path']]=old['apk']['sha256']
preserved[old['library']['path']]=old['library']['sha256']
cache=B/'cargo-target/x86_64-linux-android/release/libsolo_soul.so'
if cache.exists():
    backup=out/'previous-cache-release-libsolo_soul.so';shutil.copyfile(cache,backup)
    assert sha(backup)==sha(cache);preserved[str(backup)]=sha(backup)
save(out/'preserved-artifacts.json',preserved)
def frozen():
    assert git('rev-parse','HEAD').strip()==HEAD
    assert not git('status','--porcelain','--ignore-submodules').strip()
    assert all(sha(W/n)==h for n,h in sources.items())
    for root,expected in [(F,frontend),(R,mobile),(D,old_frontend)]:
        assert {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}==expected
    assert all(sha(Path(n))==h for n,h in preserved.items())
tool=B/'rustup/toolchains/1.96.0-x86_64-pc-windows-msvc/bin'
ndk=B/'sdk/ndk/27.0.12077973/toolchains/llvm/prebuilt/windows-x86_64/bin'
override=load(S/'tauri-config-override.json')
assert override==dict(build=dict(frontendDist=prepared['relativeFrontendDist']))
env=dict(os.environ,TEMP=str(S),TMP=str(S),CARGO_HOME=str(B/'cargo-home'),
 CARGO_TARGET_DIR=str(B/'cargo-target'),CARGO_BUILD_JOBS='1',RUSTUP_HOME=str(B/'rustup'),
 RUSTUP_TOOLCHAIN='1.96.0',RUSTC=str(tool/'rustc.exe'),
 CARGO_TARGET_X86_64_LINUX_ANDROID_LINKER=str(ndk/'x86_64-linux-android28-clang.cmd'),
 CC_x86_64_linux_android=str(ndk/'x86_64-linux-android28-clang.cmd'),
 AR_x86_64_linux_android=str(ndk/'llvm-ar.exe'),ANDROID_HOME=str(B/'sdk'),
 ANDROID_SDK_ROOT=str(B/'sdk'),NDK_HOME=str(B/'sdk/ndk/27.0.12077973'),
 ANDROID_NDK_HOME=str(B/'sdk/ndk/27.0.12077973'),ORT_CACHE_DIR=str(B/'ort-cache'),
 RUSTFLAGS='-Clink-arg=-landroid -Clink-arg=-llog -Clink-arg=-lOpenSLES',
 PYTHONDONTWRITEBYTECODE='1')
env['PATH']=str(tool)+';'+env.get('PATH','')
for key in ['PDFIUM_LIBRARY_PATH','TAURI_ANDROID_PROJECT_PATH','TAURI_CONFIG','CARGO_ENCODED_RUSTFLAGS','SOLOSOUL_REGISTRY_PUBKEY']:
    env.pop(key,None)
env['TAURI_CONFIG']=json.dumps(override,separators=(',',':'))
command=[str(tool/'cargo.exe'),'build','--locked','--offline','-p','solo_soul','--lib','--release','--target','x86_64-linux-android']
save(out/'input-proof.json',dict(task='RF-312',sourceHead=HEAD,sourceFiles=len(sources),frontendFiles=len(frontend),
 mobileResourceFiles=len(mobile),defaultFeatures=['custom-protocol'],extraFeatures=[],profile='release',
 command=command,rustcSha256=sha(tool/'rustc.exe'),cargoSha256=sha(tool/'cargo.exe'),
 linkerSha256=sha(ndk/'x86_64-linux-android28-clang.cmd'),frontendOnlyConfigOverride=override,
 currentProductionFrontendByteIdentical=True,tauriCliOrSymlinkCopyInvoked=False,
 productionSigningUsed=False,nativeRuntimeAccepted=False,fullDefaultJourneyAccepted=False))
frozen();started=time.monotonic()
with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
    child=subprocess.Popen(command,cwd=W/'tauri',env=env,stdin=subprocess.DEVNULL,
        stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    save(out/'live.json',dict(pid=child.pid,command=command,startedUnixSeconds=time.time()))
    print('Current-source default Android Release started; no optional performance feature; D-only caches and temporary files',flush=True)
    code=child.wait()
try:
    frozen();held=True
except Exception:
    held=False;(out/'frozen-input-failure.txt').write_text(traceback.format_exc(),encoding='utf-8')
save(out/'receipt.json',dict(exitCode=code,elapsedSeconds=round(time.monotonic()-started,3),
 sourceFrontendAndResourcesUnchanged=held,debugAndDedicatedOldArtifactsPreserved=held,
 frontendOnlyConfigOverride=override))
assert code==0 and held,'Release build failed or exact frozen inputs changed'
data=cache.read_bytes()
assert data[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<HH',data,16)==(3,62)
assert b'android-native-ipc-transport-observer' not in data and b'__SOLOSOUL_ANDROID_NATIVE_PERF__' not in data
copy=out/'release-libsolo_soul.so';shutil.copyfile(cache,copy);assert sha(copy)==sha(cache)
save(out/'library.json',dict(path=str(copy),sha256=sha(copy),bytes=copy.stat().st_size,
 sourceHead=HEAD,actualCargoReleaseBuilt=True,defaultFeaturesOnly=True,earlyObserverMarkersPresent=False,
 frozenInputsHeld=True,nativeRuntimeAccepted=False,fullDefaultJourneyAccepted=False))
print('Current-source default Release library verified; APK and complete native journeys still required',flush=True)
