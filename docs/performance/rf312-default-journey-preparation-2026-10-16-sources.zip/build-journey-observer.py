from pathlib import Path
import hashlib,json,os,re,subprocess,time,zipfile
S=Path(__file__).parent;B=Path('D:/SoloSoul/build/android-native-feasibility-20261010')
J=Path('C:/Users/40299571/ss-android/jdk')
SDK=B/'sdk';TOOLS=SDK/'build-tools/35.0.0';ANDROID=SDK/'platforms/android-36/android.jar'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
src=S/'observer-source';out=S/'observer-build-r3';out.mkdir(exist_ok=False)
assert ANDROID.is_file() and (J/'bin/javac.exe').is_file() and (TOOLS/'lib/d8.jar').is_file()
sources={p.name:sha(p) for p in src.iterdir() if p.is_file()}
assert set(sources)=={'Observer.java','AndroidManifest.xml'}
signer=load(B/'rf312-android-release-build-20261012/internal-test-signer.json')
key=Path(signer['keyFile']);assert sha(key)==signer['keyFileSha256']
assert signer['certificateSha256']=='168f60830e2bc0297f0660f68f2a049c416fa5f49296b3b76b4e6d894a3f8cc6'
env=dict(os.environ,JAVA_HOME=str(J),TEMP=str(S),TMP=str(S),
 JAVA_TOOL_OPTIONS='-Duser.home='+str(B/'java-home')+' -Djava.io.tmpdir='+str(S))
steps=[]
def frozen():
    assert {p.name:sha(p) for p in src.iterdir() if p.is_file()}==sources
    assert sha(key)==signer['keyFileSha256']
def run(label,cmd,expected=0):
    frozen();started=time.monotonic()
    r=subprocess.run(cmd,cwd=S,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
    (out/(label+'.stdout.log')).write_bytes(r.stdout);(out/(label+'.stderr.log')).write_bytes(r.stderr)
    steps.append(dict(step=label,exitCode=r.returncode,elapsedSeconds=round(time.monotonic()-started,3)))
    save(out/'build-progress.json',steps);frozen();assert r.returncode==expected,(label,r.returncode)
    return r.stdout.decode('utf-8')
classes=out/'classes';classes.mkdir()
run('javac',[str(J/'bin/javac.exe'),'--release','11','-cp',str(ANDROID),'-d',str(classes),str(src/'Observer.java')])
jar=out/'observer-classes.jar'
with zipfile.ZipFile(jar,'x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(classes.rglob('*.class')):z.write(p,p.relative_to(classes).as_posix())
dex=out/'dex';dex.mkdir()
run('d8',[str(J/'bin/java.exe'),'-cp',str(TOOLS/'lib/d8.jar'),'com.android.tools.r8.D8',
 '--lib',str(ANDROID),'--min-api','28','--output',str(dex),str(jar)])
assert (dex/'classes.dex').is_file()
unsigned=out/'observer-unsigned.apk'
run('aapt2',[str(TOOLS/'aapt2.exe'),'link','-o',str(unsigned),'--manifest',str(src/'AndroidManifest.xml'),
 '-I',str(ANDROID),'--min-sdk-version','28','--target-sdk-version','35','--version-code','1','--version-name','0.0.1'])
with zipfile.ZipFile(unsigned,'a',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(dex.glob('*.dex')):z.write(p,p.name)
aligned=out/'observer-aligned.apk'
run('zipalign',[str(TOOLS/'zipalign.exe'),'-f','4',str(unsigned),str(aligned)])
apk=out/'external-journey-observer.apk'
tool=[str(J/'bin/java.exe'),'-jar',str(TOOLS/'lib/apksigner.jar')]
run('sign',tool+['sign','--ks',str(key),'--ks-key-alias','androiddebugkey','--ks-pass','pass:android',
 '--key-pass','pass:android','--v4-signing-enabled','false','--out',str(apk),str(aligned)])
cert=run('verify',tool+['verify','--verbose','--print-certs',str(apk)])
assert re.findall(r'certificate SHA-256 digest: (\S+)',cert)==[signer['certificateSha256']]
badging=run('badging',[str(TOOLS/'aapt2.exe'),'dump','badging',str(apk)])
manifest=run('manifest-tree',[str(TOOLS/'aapt2.exe'),'dump','xmltree',str(apk),'--file','AndroidManifest.xml'])
assert "package: name='org.solosoul.rf312observer'" in badging and "targetSdkVersion:'35'" in badging
assert 'application-debuggable' in badging and 'launchable-activity' not in badging
assert 'android:targetPackage' in manifest and '"org.solosoul.rf312observer"' in manifest
assert '"com.solosoul.app"' not in manifest
with zipfile.ZipFile(aligned) as a,zipfile.ZipFile(apk) as b:
    assert all(hashlib.sha256(a.read(n)).digest()==hashlib.sha256(b.read(n)).digest() for n in a.namelist())
frozen()
save(out/'package.json',dict(passed=True,apk=str(apk),sha256=sha(apk),bytes=apk.stat().st_size,
 sourceSha256=sources,compileSdk=36,compileSdkAndroidJarSha256=sha(ANDROID),originalMissingPlatformCompilePreserved=True,certificateSha256=signer['certificateSha256'],instrumentationTarget='org.solosoul.rf312observer',
 applicationUnderTest='com.solosoul.app',separatePackage=True,targetInstrumentationInjected=False,
 productionSigningUsed=False,nativeRuntimeAccepted=False,lifetimeBoundSeconds=240,perPhaseBudgetSeconds=45,requestBound=512,
 targetNodeRevalidatedBeforeInput=True,singleNativeFingerPair=True,onlyTwoPublicInputStrings=True,
 allowedHierarchyPackages=['com.solosoul.app','com.android.documentsui'],steps=steps))
print(json.dumps(dict(passed=True,compiledObserver=True,instrumentsOwnPackageOnly=True,nativeRuntimeAccepted=False,bytes=apk.stat().st_size)))
