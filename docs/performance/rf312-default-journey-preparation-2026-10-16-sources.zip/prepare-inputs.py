from pathlib import Path
import hashlib,json,os,shutil,subprocess

S=Path(__file__).parent.resolve()
W=Path('D:/SoloSoul/build/worktrees/rf1158-perf-owner')
B=Path('D:/SoloSoul/build/android-native-feasibility-20261010')
V=Path('D:/SoloSoul/build/rf1183-status-body-contrast-20261016')
OLD=Path('D:/SoloSoul/build/rf312-current-default-release-20261016')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
git=lambda *a:subprocess.check_output(['git',*a],cwd=W).decode('utf-8-sig')
head=git('rev-parse','HEAD').strip()
assert head=='525da2ea01aa9966726a951d0282735caa315d04'
assert not git('status','--porcelain','--ignore-submodules').strip()
assert not (S/'input-preparation.json').exists()
names=git('ls-files','-z','--','tauri').rstrip('\0').split('\0')
sources={n:sha(W/n) for n in names if (W/n).is_file()}
assert len(sources)==1795
native_sources=load(Path('D:/SoloSoul/build/rf121-current-card-api35-r3-20261016/sources.json'))
assert sources==native_sources
prior_sources=load(V/'sources.json')
assert all(sources[n]==h for n,h in prior_sources.items())
added=sorted(set(sources)-set(prior_sources))
assert len(added)==2 and all(n.startswith('tauri/scripts/') and n.endswith('.py') for n in added)
assert load(V/'checks-r3/receipt.json')['passed'] and load(V/'final-css-checks/receipt.json')['passed']
assert load(V/'browser-full-audit.json')['passed']
frontend=load(V/'frontend.json');assert len(frontend)==38
source_dist=Path(load(V/'frontend-binding.json')['frontendRoot'])
assert {p.relative_to(source_dist).as_posix():sha(p) for p in source_dist.rglob('*') if p.is_file()}==frontend
dest=S/'current-dist';shutil.copytree(source_dist,dest)
assert {p.relative_to(dest).as_posix():sha(p) for p in dest.rglob('*') if p.is_file()}==frontend
mobile=load(V/'mobile-resources.json');assert len(mobile)==46
assert {p.relative_to(W/'tauri/src-tauri/resources-mobile').as_posix():sha(p) for p in (W/'tauri/src-tauri/resources-mobile').rglob('*') if p.is_file()}==mobile
old_dist=W/'tauri/dist'
old_frontend={p.relative_to(old_dist).as_posix():sha(p) for p in old_dist.rglob('*') if p.is_file()}
relative=Path(os.path.relpath(dest,W/'tauri/src-tauri')).as_posix()
assert relative.startswith('../') and ':' not in relative and (W/'tauri/src-tauri'/relative).resolve()==dest
save(S/'sources.json',sources);save(S/'frontend.json',frontend);save(S/'mobile-resources.json',mobile)
save(S/'old-frontend-preserved.json',old_frontend)
save(S/'tauri-config-override.json',dict(build=dict(frontendDist=relative)))
assets=V/'android-debug-package2/assets'
asset_hashes={p.relative_to(assets).as_posix():sha(p) for p in assets.rglob('*') if p.is_file()}
assert len(asset_hashes)==98
save(S/'assets.json',asset_hashes)
packages=load(V/'android-debug-package2/packages.json')
assert all(sha(Path(p['path']))==p['sha256'] for p in packages['packages'])
save(S/'restore-debug-packages.json',packages)
old=load(OLD/'android-release-package/package-verification.json')
assert sha(Path(old['apk']['path']))==old['apk']['sha256']
save(S/'previous-default-package.json',old)
save(S/'input-preparation.json',dict(passed=True,task='RF-312',sourceHead=head,sourceFiles=len(sources),
 frontendFiles=38,mobileResources=46,androidAssets=98,actualCurrentProductionBuildReused=True,
 previousProductionBuildSourceGuardSha256=sha(V/'source-guard.json'),
 previousProductionBrowserAuditSha256=sha(V/'browser-full-audit.json'),
 previousProductionFrontendSha256=sha(V/'frontend.json'),frontendByteIdentical=True,
 newFilesSinceVerifiedBuildAreOnlyNonProductHelpers=added,oldWorkspaceDistPreserved=True,
 frontendRoot=str(dest),relativeFrontendDist=relative,
 noProductSourceOrDependencyChanged=True,defaultReleaseRebuildRequired=True,
 nativeTestsStarted=0,fullDefaultJourneyAccepted=False))
print(json.dumps(dict(passed=True,sourceHead=head,sourceFiles=len(sources),frontendFiles=38,androidAssets=98,newNonProductHelpers=added,nativeTestsStarted=0)))
