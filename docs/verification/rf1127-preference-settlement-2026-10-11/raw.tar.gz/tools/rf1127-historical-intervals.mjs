import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {validateObserver,ipcDelta} from '../../tauri/scripts/native-perf-run.mjs';
import {checkPreferenceWrites,preferenceWriteDelta,correlatePreferenceInterval,correlateSettledThemeInterval} from '../../tauri/scripts/native-perf-preference-contract.mjs';
const w=new URL('./',import.meta.url), repo=new URL('../../',w);
const index=JSON.parse(await readFile(new URL('docs/verification/rf121-windows-window-restore-2026-10-11/index.json',repo),'utf8'));
const sha=b=>createHash('sha256').update(b).digest('hex');
async function original(name){
 const member=index.members.find(x=>x.member===name);assert(member);
 const data=await readFile(new URL(name,w));assert.equal(sha(data),member.sha256);assert.equal(data.length,member.bytes);
 return JSON.parse(data.toString('utf8'));
}
const rows=[];
for(const mode of ['dark-expanded','dark-collapsed']){
 const base=`ss-rf121-composed-window-restore-${mode}-caption-round2-20261011/actual100/`;
 for(let i=1;i<=3;i++){
  const root=base+`sample-${String(i).padStart(3,'0')}/`;
  const owned=await original(root+'native-perf-owned.json'),bound=await original(root+'native-perf-sdk-journey-bound.json');
  const prep=await original(root+'native-perf-surface-appearance-prepared.json'),restore=await original(root+'native-perf-surface-appearance-restored.json');
  const identity={runId:owned.runId,pid:bound.pid};
  assert.deepEqual(prep.binding,bound.binding);assert.deepEqual(restore.binding,bound.binding);
  const sequence=[prep.initial,...prep.steps,...restore.steps];
  sequence.forEach(x=>checkPreferenceWrites(x.preferenceWrites,identity));
  for(let j=1;j<sequence.length;j++)preferenceWriteDelta(sequence[j-1].preferenceWrites,sequence[j].preferenceWrites,identity);
  for(const [a,b] of [[prep.steps[1],prep.steps[2]],[restore.steps.at(-3),restore.steps.at(-2)]]){
   const front=ipcDelta(validateObserver(a.observer,owned.runId),validateObserver(b.observer,owned.runId));assert.equal(front.reason,null);
   const transport=front.commands.find(c=>c.command==='user_data_update_preference')?.attempts??0;
   let originalStrictAccepted=true;try{correlatePreferenceInterval(a.preferenceWrites,b.preferenceWrites,identity,transport);}catch{originalStrictAccepted=false;}
   const proof=correlateSettledThemeInterval(a.preferenceWrites,b.preferenceWrites,restore.steps.at(-1).preferenceWrites,identity,transport);
   rows.push({mode,sample:i,identity,from:a.action,to:b.action,transport,originalAggregateAccepted:transport===1,originalStrictAccepted,proof});
  }
 }
}
assert.equal(rows.length,12);assert(rows.some(x=>!x.originalStrictAccepted));
await writeFile(new URL('../rf1127-preference-settlement-20261011/historical-intervals.json',w),JSON.stringify({
 task:'RF-1127',retrospectiveContractEvidence:true,accepted:false,newNativeRun:false,
 originalArchiveBytesVerified:true,originalFailedResultsModified:false,fullRF121Accepted:false,rows},null,2)+'\n',{flag:'wx'});
process.stdout.write(JSON.stringify({historicalIntervals:rows.length,originalStrictRejected:rows.filter(x=>!x.originalStrictAccepted).length,newContractVerified:rows.length,newNativeRun:false})+'\n');
