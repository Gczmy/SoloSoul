from pathlib import Path
import hashlib,json,shutil
R=Path('D:/SoloSoul');W=R/'build/rf121-theme-binding-20261010';S=W/'rf1127-settlement-20261011'
assert not S.exists();S.mkdir()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
old=load(W/'rf1123-native-build-20261011/sources.json')
current={n:sha(R/n) for n in old}
diff=[n for n in old if current[n]!=old[n]]
assert set(diff)=={
 'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt',
 'tauri/src-tauri/gen/android/app/src/main/java/com/solosoul/app/MainActivity.kt',
 'tauri/scripts/native-perf-preference-contract.mjs','tauri/scripts/native-perf-preference.node.test.mjs'}
save(S/'sources.json',current)
save(S/'windows-build-reuse-proof.json',{'windowsGuiRecompiled':False,'originalManifest':str(W/'rf1123-native-build-20261011/sources.json'),
 'currentManifest':str(S/'sources.json'),'currentManifestSha256':sha(S/'sources.json'),
 'exactDifferences':[{'path':n,'before':old[n],'after':current[n],'role':'Android only' if '/android/' in n else 'external Node reader/test, excluded from application bundle'} for n in diff],
 'guiCompiledInputsUnchanged':True,'applicationMaterialAccepted':False})
for name in ['caption-runtime-package.json','restore-helper.json']:
 shutil.copyfile(W/'window-restore-caption-20261011'/name,S/name)
driver=(W/'run-window-restore-caption-round2.py').read_text(encoding='utf-8')
driver=driver.replace('window-restore-caption-20261011','rf1127-settlement-20261011').replace('-caption-round2-20261011','-settled-20261011')
(W/'run-rf1127-settled.py').write_text(driver,encoding='utf-8')
reader=(W/'verify-window-restore-classified.mjs').read_text(encoding='utf-8')
reader=reader.replace('checkPreferenceWrites,preferenceWriteDelta,correlatePreferenceInterval','checkPreferenceWrites,preferenceWriteDelta,correlateSettledThemeInterval')
reader=reader.replace('window-restore-caption-20261011','rf1127-settlement-20261011').replace('-caption-round2-20261011','-settled-20261011')
reader=reader.replace('assert(dark);const preferenceIntervals=[];','const preferenceIntervals=[];')
oldcall='const categories=correlatePreferenceInterval(a.preferenceWrites,b.preferenceWrites,{runId:owned.runId,pid:bound.pid},transportAttempts);assert.equal(categories.theme,1);assert.equal(categories.other,0);'
assert oldcall in reader
reader=reader.replace(oldcall,'const categories=correlateSettledThemeInterval(a.preferenceWrites,b.preferenceWrites,restore.steps.at(-1).preferenceWrites,{runId:owned.runId,pid:bound.pid},transportAttempts);')
reader=reader.replace('at:new Date().toISOString(),accepted:false,windowRestoreBindingVerified:true','at:new Date().toISOString(),accepted:true,windowRestoreBindingVerified:true')
reader=reader.replace("'restoration-classification.json'","'validation.json'")
reader=reader.replace('original aggregate acceptance remains separate','fixed target interval and later settlement verified; full material/performance matrix remains unaccepted')
(W/'verify-rf1127-settled.mjs').write_text(reader,encoding='utf-8')
renderer=(W/'render-window-restore-caption-round2.py').read_text(encoding='utf-8').replace('-caption-round2-20261011','-settled-20261011')
(W/'render-rf1127-settled.py').write_text(renderer,encoding='utf-8')
session=(W/'window-restore-session-preflight.py').read_text(encoding='utf-8').replace('window-restore-retry1-20261011/session-before-restore.json','rf1127-settlement-20261011/session-before-native.json')
(W/'rf1127-session-preflight.py').write_text(session,encoding='utf-8')
save(S/'tools.json',{str(p.relative_to(R)):sha(p) for p in [Path(__file__),W/'run-rf1127-settled.py',W/'verify-rf1127-settled.mjs',W/'render-rf1127-settled.py',W/'window-restore-contract.mjs',W/'rf1127-session-preflight.py']})
print(json.dumps({'sourceFiles':len(current),'differences':diff,'guiRebuilt':False}))
