from pathlib import Path
import json,hashlib,tarfile,io
R=Path('D:/SoloSoul');B=Path(__file__).parent;W=R/'build/rf121-theme-binding-20261010';S=W/'rf1127-settlement-20261011'
name='rf1127-preference-settlement-2026-10-11';out=R/'docs/verification'/name
assert not out.exists();out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
assert load(B/'node-green.receipt.json')['exitCode']==0
assert load(B/'node-red.receipt.json')['exitCode']==1
assert load(B/'node-all.receipt.json')['exitCode']==1
assert load(B/'node-all-elevated.receipt.json')['exitCode']==0
assert load(B/'format-check.receipt.json')['exitCode']==0
historical=load(B/'historical-intervals.json');assert historical['accepted']==False and len(historical['rows'])==12
session=load(S/'session-before-native-recheck1.json');assert session['connectionState']==4 and not session['inputDesktopAvailable']
assert not any(W.glob('ss-rf121-composed-window-restore-*-settled-20261011'))
members={}
def add(p,n):
 assert p.is_file() and not (p.stat().st_file_attributes&0x400)
 assert n not in members;members[n]=p
for base,label in [(B,'checks'),(S,'native-preparation')]:
 for p in base.iterdir():
  if p.is_file() and p.suffix in {'.json','.log','.py'}:add(p,label+'/'+p.name)
for n in ['run-rf1127-settled.py','verify-rf1127-settled.mjs','render-rf1127-settled.py','rf1127-session-preflight.py','rf1127-session-recheck1.py','run-rf1127-cohorts.py','rf1127-historical-intervals.mjs','window-restore-contract.mjs']:
 add(W/n,'tools/'+n)
for n in ['native-perf-preference-contract.mjs','native-perf-preference.node.test.mjs']:
 add(R/'tauri/scripts'/n,'current/tauri/scripts/'+n)
put(B/'pending-native.json',{'task':'RF-1127','newNativeTestsStarted':0,'queueExecuted':False,'preparedQueueSha256':sha((W/'run-rf1127-cohorts.py').read_bytes()),'session':session,'fullRF121Accepted':False})
add(B/'pending-native.json','checks/pending-native.json')
original=R/'docs/verification/rf121-windows-window-restore-2026-10-11/index.json'
add(original,'original-evidence/index.json')
rows=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as t:
 for n,p in sorted(members.items()):
  data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data));rows.append({'member':n,'source':str(p),'bytes':len(data),'sha256':sha(data)})
with tarfile.open(out/'raw.tar.gz') as t:
 assert len(t.getmembers())==len(rows)
 for x in rows:
  d=t.extractfile(x['member']).read();assert len(d)==x['bytes'] and sha(d)==x['sha256']
put(out/'index.json',{'task':'RF-1127','members':rows,'allMembersReadbackVerified':True,'newNativeTestsStarted':0,'accepted':False})
(out/'.gitattributes').write_text('raw.tar.gz -text\n',encoding='utf-8')
put(R/'docs/verification'/(name+'.json'),{'task':'RF-1127','accepted':False,'status':'implementation-verified; new-native-matrix-awaits-interactive-session1',
 'sourceHead':'82df28d2bc2ed1e16b31759858d22e15ac7a9117','productionApplicationChanged':False,'strictIntervalContractUnchanged':True,
 'newContract':'correlateSettledThemeInterval','targetThemeMustAlreadyBeCompleted':True,'originalTransportCountPreserved':True,
 'originalRunningSnapshotsUnmodified':True,'terminalPrefixImmutable':True,'laterIdsCannotFillOriginalInterval':True,
 'dedicatedTests':{'passed':9,'failed':0,'skipped':0},'completeNodeTests':{'passed':240,'failed':0,'existingSkipped':1,'exitCode':0},
 'failuresRetained':['missing new export before implementation','original complete Node sandbox junction permissions'],
 'historicalIntervalsVerified':12,'historicalStrictRejected':sum(not x['originalStrictAccepted'] for x in historical['rows']),
 'historicalProofIsNewNativeRun':False,'newNativeTestsStarted':0,'nativeQueueExecuted':False,'session':session,
 'windowsGuiRecompiled':False,'fixtureOrUserDataTouched':False,'processesTerminated':0,'fullRF121Accepted':False,'performanceAccepted':False,
 'remaining':'new four groups of three native journeys, independent appearance/window pixel validation, precise cache cleanup',
 'archive':{'path':name+'/raw.tar.gz','members':len(rows),'bytes':(out/'raw.tar.gz').stat().st_size,'sha256':sha((out/'raw.tar.gz').read_bytes()),'readbackVerified':True},
 'ledgerClosed':False,'commitCreated':False})
print(json.dumps({'members':len(rows),'accepted':False,'newNativeTests':0}))
