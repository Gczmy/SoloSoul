from pathlib import Path
import ast
import sys

original = Path(__file__).parent
stage = original/'after-rf1106'
assert sys.argv[1:] in [[],['--proposal-only']]
if sys.argv[1:]:
    stage = original/'final-helper-proposal'
    stage.mkdir(exist_ok=False)
else:
    assert stage.is_dir() and (stage/'sources-fixed.json').is_file()
def changed(text,old,new):
    assert text.count(old) == 1, old
    return text.replace(old,new)
def save(name,text):
    ast.parse(text)
    with (stage/name).open('x',encoding='utf-8',newline='\n') as out: out.write(text)

cleanup = (original/'prepare-cleanup-all.py').read_text(encoding='utf-8')
cleanup = changed(cleanup,"stage = Path(__file__).parent", "stage = Path(__file__).parent\noriginal = stage.parent")
cleanup = changed(cleanup,"load(stage/'startup-100.receipt.json')", "load(original/'startup-100.receipt.json')")
cleanup = changed(cleanup,"load(stage/'round2/startup-100.receipt.json')", "load(original/'round2/startup-100.receipt.json')")
cleanup = changed(cleanup,'    ("\'validation.json\'","\'cleanup-plan.json\'"),',
    '    ("\'validation.json\'",r"\'after-rf1106\\cleanup-plan.json\'"),')
cleanup = changed(cleanup,r"'D:\SoloSoul\build\rf312-warm-current-20261010\ss-rf1105-runtime\bin\solo_soul.exe'",
    r"'D:\SoloSoul\build\rf312-warm-current-20261010\after-rf1106\ss-rf1105-runtime\bin\solo_soul.exe'")
for relative in ['samples100','samples5000']:
    cleanup = changed(cleanup,"'round3\\\\"+relative+"'", "'after-rf1106\\\\round3\\\\"+relative+"'")
save('prepare-cleanup-all.py',cleanup)

archive = (original/'archive-complete.py').read_text(encoding='utf-8')
archive = changed(archive,"stage = Path(__file__).parent", "stage = Path(__file__).parent\ninitial_stage = stage.parent")
archive = changed(archive,"cleanup = load(stage/'cache-cleanup.json')", "cleanup = load(initial_stage/'cache-cleanup.json')")
old_iter = '''for file in stage.iterdir():
    if file.is_file() and file.suffix in {'.py','.ps1','.mjs','.json','.log','.toml'}:
        add(file,'checks-and-tools/'+file.name)'''
new_iter = '''for folder,label in [(stage,'current-checks-and-tools'),(initial_stage,'initial-checks-and-tools')]:
    for file in folder.iterdir():
        if file.is_file() and file.suffix in {'.py','.ps1','.mjs','.json','.log','.toml'}:
            add(file,label+'/'+file.name)'''
archive = changed(archive,old_iter,new_iter)
archive = changed(archive,"for folder in [stage/'round2',stage/'round3']:", "for folder in [initial_stage/'round2',stage/'round3']:")
archive = changed(archive,"for folder in [stage/'samples100',stage/'round2/samples100',stage/'round3/samples100',stage/'round3/samples5000']:",
    "for folder in [initial_stage/'samples100',initial_stage/'round2/samples100',stage/'round3/samples100',stage/'round3/samples5000']:")
archive = changed(archive,"    relative = folder.relative_to(stage).as_posix()",
    "    relative = ('current/'+folder.relative_to(stage).as_posix()) if folder.is_relative_to(stage) else ('initial/'+folder.relative_to(initial_stage).as_posix())")
archive = changed(archive,"for file in (stage/'application-logs').rglob('*'):", "for file in (initial_stage/'application-logs').rglob('*'):")
archive = changed(archive,"    if file.is_file(): add(file,file.relative_to(stage).as_posix())",
    "    if file.is_file(): add(file,file.relative_to(initial_stage).as_posix())")
archive = changed(archive,"'sdkBudgetsUnchanged':True,'defaultDependenciesChanged':False,'defaultProductCodeChanged':False,",
    "'sdkBudgetsUnchanged':True,'defaultDependenciesChanged':False,'defaultProductCodeChanged':False,\n    'dependencyTestOnlyFixes':['RF-1106','RF-1107'],'reusedChecks':load(stage/'reused-checks.json'),")
save('archive-complete.py',archive)

close = (original/'close-report.py').read_text(encoding='utf-8')
close = close.replace('285 / 295','287 / 297').replace('286 / 295','288 / 297')
close = close.replace('实际修复（已关闭）：285','实际修复（已关闭）：287').replace('实际修复（已关闭）：286','实际修复（已关闭）：288')
close = close.replace('286/295','288/297')
close = changed(close,'- 修复后Node定向10通过，完整229项中228通过、0失败、1既有Windows文件symlink权限跳过；格式通过。',
    '- 修复后Node定向10通过，完整229项中228通过、0失败、1既有Windows文件symlink权限跳过；格式通过。RF-1106和RF-1107测试时序/断言修复已分别提交，当前Rust检查按六源码SHA复用已实际通过结果，原失败保持，复用来源逐字记录。')
save('close-report.py',close)

verify = (original/'verify-staged.py').read_text(encoding='utf-8')
verify = changed(verify,'== 295','== 297')
verify = changed(verify,"{'x':286,'!':3,' ':6}","{'x':288,'!':3,' ':6}")
verify = verify.replace('tasks286/295','tasks288/297')
guard = '''expected={'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md','docs/verification/RF-1105-startup-auth-tail.md',
    base+'.json',base+'/.gitattributes',base+'/index.json',base+'/raw.tar.gz',
    'tauri/scripts/native-perf-startup.mjs','tauri/scripts/native-perf-startup.test.mjs',
    'tauri/src-tauri/src/native_perf/startup.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs'}
actual=set(subprocess.run(['git','diff','--cached','--name-only'],cwd=root,check=True,capture_output=True,text=True).stdout.splitlines())
assert actual==expected,actual
'''
verify = changed(verify,"index = json.loads(staged(base+'/index.json'))",guard+"index = json.loads(staged(base+'/index.json'))")
save('verify-staged.py',verify)
print('RF-1105 final helpers adapted for original failures, fresh namespace, separate dependencies and 297 task cards; no cleanup/archive/closure executed')
