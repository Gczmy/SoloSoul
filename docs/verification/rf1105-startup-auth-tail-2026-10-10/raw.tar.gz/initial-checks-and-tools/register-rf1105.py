from pathlib import Path
p = Path('D:/SoloSoul/docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md')
s = p.read_text(encoding='utf-8-sig')
before = '- 已关闭：**285 / 294**；实际修复（已关闭）：285；排除：0；待验证/阻塞：3（RF-112、RF-121、RF-312）；暂缓：0；进行中：0；待执行：6。'
after = before.replace('285 / 294','285 / 295').replace('进行中：0','进行中：1')
assert s.count(before) == 1
s = s.replace(before,after)
before = 'RF-1103、RF-1104（RF-904'
assert s.count(before) == 1
s = s.replace(before,'RF-1103、RF-1104、RF-1105（RF-904')
lines = s.splitlines(keepends=True)
assert sum(line.startswith('- 当前处理：') for line in lines) == 1
lines = [('- 当前处理：**RF-1105：当前热启动的Node与Rust门禁均仍要求旧两调用序列，按真实四调用认证尾序修复并重跑；原失败样本保留，Windows会话捕获已恢复，完整原生矩阵与RF-112/121/312及后续前置不提前关闭**。\n' if line.startswith('- 当前处理：') else line) for line in lines]
s = ''.join(lines)
row = '| 294 | [RF-1104](#rf-1104) | P1 | 更新源网络等待不阻断重解锁，写入重新校验原目录与会话 | 无（RF-312维护准入诊断发现） | [x] 完成 |'
assert s.count(row) == 1
s = s.replace(row,row+'\n| 295 | [RF-1105](#rf-1105) | P2 | 热启动门禁精确校验当前认证诊断尾序 | 无（RF-312当前构建热启动发现） | [~] 进行中 |')
card = '''### RF-1105

**热启动门禁精确校验当前认证诊断尾序** · P2 · 来源：RF-312 当前构建热启动

- **前置：**无；仅修复非默认 Windows 原生验收门禁。
- **入口：**`tauri/scripts/native-perf-startup.mjs`、对应 Node 回归、`tauri/src-tauri/src/native_perf/startup.rs` 与既有重启票据测试。
- **现状证据：**首轮四份原生启动证明成功，Node 因旧两调用预期拒绝；修正 Node 后新样本第一代通过，Rust 票据准备仍拒绝。生产诊断尾序明确为启动读回/同文档核验，再执行认证快照/同文档核验，合计四个固定只读调用。
- **执行：**两处门禁精确接纳该四调用序列；遗漏、交换、重复和输入调用继续拒绝。身份、frame/loader/时钟、observer/IPC、票据一次性、原配置目录、退出检查、夹具与预算保持。
- **验收：**真实旧原件离线复核与 Node/Rust 红绿、对应完整检查、新构建以及两档公开夹具各五组同目录重启；失败组和退出核验不完整的原记录保留，不以新鲜退出重查改写历史结果。
- **验证配置：**Node 定向/完整回归与格式；Rust 格式、默认/非默认严格 Clippy、非默认诊断与原生重启票据测试、新 GUI Release、DOC。默认产品认证与启动行为不改；本项不关闭 RF-312 整项。

'''
assert s.count('## 7. 每项执行记录模板') == 1
s = s.replace('## 7. 每项执行记录模板',card+'## 7. 每项执行记录模板')
p.write_text(s,encoding='utf-8',newline='\n')
print('RF-1105 registered in progress; 295 tasks, 285 closed')
