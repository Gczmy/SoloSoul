from pathlib import Path
import collections, hashlib, io, json, re, subprocess, tarfile
root = Path('D:/SoloSoul')
base = 'docs/verification/rf1105-startup-auth-tail-2026-10-10'
sha = lambda b: hashlib.sha256(b).hexdigest()
def staged(path):
    return subprocess.run(['git','show',':'+path],cwd=root,check=True,capture_output=True).stdout
index = json.loads(staged(base+'/index.json'))
archive = staged(base+'/raw.tar.gz')
assert sha(archive) == index['archiveSha256']
assert archive == (root/base/'raw.tar.gz').read_bytes()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
    members = {i.name:tar.extractfile(i).read() for i in tar.getmembers() if i.isfile()}
assert len(members) == index['memberCount']
for item in index['members']:
    assert len(members[item['path']]) == item['bytes']
    assert sha(members[item['path']]) == item['sha256']
for key in members:
    if key.startswith('source-after/'):
        assert members[key] == staged(key[len('source-after/'):])
report = staged('docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md').decode('utf-8-sig')
rows = re.findall(r'^\| \d+ \| \[(RF-\d+)\].*$',report,re.M)
cards = re.findall(r'^### (RF-\d+)\s*$',report,re.M)
assert len(rows) == len(set(rows)) == len(cards) == len(set(cards)) == 295
assert set(rows) == set(cards)
statuses = collections.Counter()
for line in report.splitlines():
    if re.match(r'^\| \d+ \| \[RF-\d+\]',line):
        statuses[re.search(r'\[([x!~ ])\]',line)[1]] += 1
assert statuses == {'x':286,'!':3,' ':6},statuses
record = json.loads(staged(base+'.json'))
assert record['accepted'] and not record['rf312Closed']
assert all(g['complete'] and len(g['samples'])==5 for g in record['validation']['groups'])
print(f'Staged archive {len(members)}/{len(members)} exact hashes; four source-after bytes match Git; tasks286/295, remaining3+6')
