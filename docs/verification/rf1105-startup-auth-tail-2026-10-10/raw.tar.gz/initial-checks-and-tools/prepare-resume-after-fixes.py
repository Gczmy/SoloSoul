from pathlib import Path
import ast

stage = Path(__file__).parent
s = (stage/'prepare-resume-after-rf1106.py').read_text(encoding='utf-8')
def replace(old,new):
    global s
    assert s.count(old) == 1, old
    s = s.replace(old,new)
replace("dependency=root/'build/rf1106-preference-write-checkpoint-20261010'",
    "dependency=root/'build/rf1106-preference-write-checkpoint-20261010'\nchecks_stage=root/'build/rf1107-download-low-speed-cause-20261010'")
replace("assert record['accepted'] and not record['rf1105Closed']",
    "assert record['accepted'] and not record['rf1105Closed']\nsecond_record=load(root/'docs/verification/rf1107-download-low-speed-cause-2026-10-10.json')\nassert second_record['accepted'] and not second_record['rf1105Closed']")
replace("sources=load(dependency/'sources-final.json')", "sources=load(checks_stage/'sources-final.json')")
replace("assert {p for p,h in sources.items() if previous[p]!=h}=={updater}",
    "download='tauri/src-tauri/src/commands/update_download.rs'\nassert {p for p,h in sources.items() if previous[p]!=h}=={updater,download}\nassert record['productionParity']['productPrefixEqualAfterExcludingTestOnlyInsertions']\nassert second_record['productionParity']['productPrefixUnchanged']")
replace("'scope':'RF-1105 exact gate fixes; separately committed RF-1106 test synchronization',",
    "'scope':'RF-1105 exact gate fixes; separately committed RF-1106 and RF-1107 test corrections',")
replace("'evidence':'docs/verification/rf1106-preference-write-checkpoint-2026-10-10.json'}})",
    "'evidence':'docs/verification/rf1106-preference-write-checkpoint-2026-10-10.json'},\n    'additionalDependencyTestOnlyChange':{'task':'RF-1107','source':download,'sha256':sources[download],\n        'evidence':'docs/verification/rf1107-download-low-speed-cause-2026-10-10.json'}})")
for old,new in [
    ('rf1106-format-check','rf1107-format-check'),
    ('rf1106-clippy-default','rf1107-clippy-default'),
    ('rf1106-clippy-native','rf1107-clippy-native'),
    ('rf1106-native-regression','rf1107-native-regression'),
    ('rf1106-native-preferences','rf1107-native-preferences'),
    ('rf1106-default-workspace','rf1107-default-workspace'),
]: replace(f"(dependency,'{old}')", f"(checks_stage,'{new}')")
replace("if origin==dependency:", "if origin==checks_stage:")
replace("len(receipt['sourceFiles'])==5", "len(receipt['sourceFiles'])==6")
replace("shutil.copy2(dependency/'run-check.py',stage/'run-rust-check.py')", "shutil.copy2(checks_stage/'run-check.py',stage/'run-rust-check.py')")
replace("Fresh RF-1105 continuation prepared after RF-1106 commit; old failures untouched; not executed",
    "Fresh RF-1105 continuation prepared after separate RF-1107 and RF-1106 commits; old failures untouched; not executed")
ast.parse(s)
proposal=stage/'prepare-resume-after-fixes.generated.py'
with proposal.open('x',encoding='utf-8',newline='\n') as out: out.write(s)
print('Adapted RF-1105 prerequisite proposal generated and parsed; dependency gate not executed')
