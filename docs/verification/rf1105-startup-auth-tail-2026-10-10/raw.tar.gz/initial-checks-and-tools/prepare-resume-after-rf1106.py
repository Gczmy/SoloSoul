from pathlib import Path
import datetime, hashlib, json, shutil, subprocess

root=Path('D:/SoloSoul')
old=Path(__file__).parent
dependency=root/'build/rf1106-preference-write-checkpoint-20261010'
stage=old/'after-rf1106'
load=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
record=load(root/'docs/verification/rf1106-preference-write-checkpoint-2026-10-10.json')
assert record['accepted'] and not record['rf1105Closed']
subject=subprocess.run(['git','log','-1','--format=%s'],cwd=root,check=True,capture_output=True,text=True).stdout.strip()
assert '[RF-1106]' in subject,subject
changed=set(subprocess.run(['git','diff','--name-only'],cwd=root,check=True,capture_output=True,text=True).stdout.splitlines())
four={'tauri/scripts/native-perf-startup.mjs','tauri/scripts/native-perf-startup.test.mjs',
    'tauri/src-tauri/src/native_perf/startup.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs'}
assert changed==four,changed
assert not subprocess.run(['git','diff','--cached','--name-only'],cwd=root,check=True,capture_output=True,text=True).stdout.strip()
sources=load(dependency/'sources-final.json')
assert len(sources)==1830
for name,digest in sources.items(): assert sha(root/name)==digest,name
previous=load(old/'sources-fixed.json')
updater='tauri/src-tauri/src/commands/update_preferences.rs'
assert {p for p,h in sources.items() if previous[p]!=h}=={updater}
assert load(old/'rf1105-rust-default.receipt.json')['exitCode']==101
assert not (old/'runtime-new.json').exists() and not (old/'round3').exists()
stage.mkdir(exist_ok=False)
def save(name,value):
    with (stage/name).open('x',encoding='utf-8',newline='\n') as out: out.write(json.dumps(value,indent=2)+'\n')
save('sources-fixed.json',sources)
save('source-delta-fixed.json',{'changed':load(old/'source-delta-fixed.json')['changed'],
    'defaultProductCodeChanged':False,'scope':'RF-1105 exact gate fixes; separately committed RF-1106 test synchronization',
    'dependencyTestOnlyChange':{'task':'RF-1106','source':updater,'sha256':sources[updater],
        'evidence':'docs/verification/rf1106-preference-write-checkpoint-2026-10-10.json'}})
reused=[]
mapping={
    'rf1105-targeted':(old,'rf1105-targeted'),
    'rf1105-node-full':(old,'rf1105-node-full'),
    'rf1105-format-green':(old,'rf1105-format-green'),
    'rf1105-rust-format-check':(dependency,'rf1106-format-check'),
    'rf1105-clippy-default':(dependency,'rf1106-clippy-default'),
    'rf1105-clippy-native':(dependency,'rf1106-clippy-native'),
    'rf1105-rust-native':(dependency,'rf1106-native-regression'),
    'rf1105-rust-preferences':(dependency,'rf1106-native-preferences'),
    'rf1105-rust-default':(dependency,'rf1106-default-workspace'),
}
for target,(origin,name) in mapping.items():
    receipt=load(origin/(name+'.receipt.json'))
    assert receipt['exitCode']==0
    if origin==dependency:
        assert receipt['sourceUnchanged'] and len(receipt['sourceFiles'])==5
        for file,digest in receipt['sourceFiles'].items(): assert sources[file]==digest
    else:
        assert all(sources[file]==previous[file] for file in four)
    copied=[]
    for suffix in ['stdout.log','stderr.log','receipt.json']:
        file=origin/(name+'.'+suffix)
        shutil.copy2(file,stage/(target+'.'+suffix))
        assert sha(stage/(target+'.'+suffix))==sha(file)
        copied.append({'source':str(file),'copy':str(stage/(target+'.'+suffix)),'sha256':sha(file)})
    reused.append({'check':target,'originalCheck':name,'executedAgain':False,'files':copied})
for name in ['rf1105-red','rf1105-rust-red']:
    for suffix in ['stdout.log','stderr.log','receipt.json']:
        shutil.copy2(old/(name+'.'+suffix),stage/(name+'.'+suffix))
shutil.copy2(old/'failed-offline-validation.json',stage/'failed-offline-validation.json')
shutil.copy2(old/'run-current.py',stage/'run-current.py')
shutil.copy2(dependency/'run-check.py',stage/'run-rust-check.py')
verifier=(old/'verify-fixed.mjs').read_text(encoding='utf-8')
assert verifier.count("const root = path.resolve(stage,'../..');")==1
verifier=verifier.replace("'../../tauri/","'../../../tauri/").replace(
    "const root = path.resolve(stage,'../..');","const root = path.resolve(stage,'../../..');")
with (stage/'verify-fixed.mjs').open('x',encoding='utf-8',newline='\n') as out: out.write(verifier)
save('reused-checks.json',{'task':'RF-1105','checks':reused,'sourceManifestSha256':sha(stage/'sources-fixed.json'),
    'dependencyCommitSubject':subject,'originalDefaultFailurePreserved':True,
    'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
original=(old/'run-complete.py').read_text(encoding='utf-8')
tail=original[original.index('env = os.environ.copy()'):]
header='''from pathlib import Path
import datetime, hashlib, json, os, shutil, struct, subprocess, sys, time, tomllib
root=Path('D:/SoloSoul')
stage=Path(__file__).parent
cache=root/'build/rf312-maintenance-20261009'
baseline=root/'build/rf121-theme-binding-20261010'
load=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources=load(stage/'sources-fixed.json')
def save(name,value):
    with (stage/name).open('x',encoding='utf-8',newline='\\n') as out: out.write(json.dumps(value,indent=2)+'\\n')
def verify():
    for name,digest in sources.items(): assert sha(root/name)==digest,name
def run(name,command):
    verify()
    code=subprocess.call([sys.executable,'-X','utf8',str(stage/'run-rust-check.py'),name,*command],cwd=root)
    assert code==0,(name,code)
    verify()
run('rf1105-rust-rf905',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','rf905','--','--nocapture'])
'''
with (stage/'run-complete.py').open('x',encoding='utf-8',newline='\n') as out: out.write(header+tail)
print('Fresh RF-1105 continuation prepared after RF-1106 commit; old failures untouched; not executed')
