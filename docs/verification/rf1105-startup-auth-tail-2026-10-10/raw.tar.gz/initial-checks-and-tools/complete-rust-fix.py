from pathlib import Path
import json
stage = Path(__file__).parent
root = Path('D:/SoloSoul')
receipt = json.loads((stage/'rf1105-rust-red.receipt.json').read_text())
assert receipt['exitCode'] == 101 and receipt['sourceUnchanged']
log = (stage/'rf1105-rust-red.stdout.log').read_text()
err = (stage/'rf1105-rust-red.stderr.log').read_text()
assert '0 passed; 1 failed' in log
assert 'first startup proof is not a successful exclusive read-only prime' in log + err
path = root/'tauri/src-tauri/src/native_perf/startup.rs'
data = path.read_bytes()
old = b'proof["calls"] != json!(["Runtime.evaluate", "Page.getFrameTree"])'
new = b'proof["calls"] != json!(["Runtime.evaluate", "Page.getFrameTree", "Runtime.evaluate", "Page.getFrameTree"])'
assert data.count(old) == 1
path.write_bytes(data.replace(old,new))
path = root/'tauri/src-tauri/src/native_perf/preflight_tests.rs'
data = path.read_bytes()
newline = b'\r\n' if b'\r\n' in data else b'\n'
old = b'    let prepared = startup::prepare_restart(&config.root, &folders).unwrap();'
assert data.count(old) == 1
code = '''    // The current producer has a fixed startup pair and authentication/frame tail.
    // Reject a malformed tail before the stop-hash check, then restore original bytes.
    let original_proof = fs::read(&proof_path).unwrap();
    for calls in [
        json!([]),
        json!(["Runtime.evaluate", "Page.getFrameTree"]),
        json!(["Runtime.evaluate", "Page.getFrameTree", "Runtime.evaluate"]),
        json!(["Runtime.evaluate", "Page.getFrameTree", "Runtime.evaluate", "Page.getFrameTree", "Runtime.evaluate", "Page.getFrameTree"]),
        json!(["Runtime.evaluate", "Page.getFrameTree", "Page.getFrameTree", "Runtime.evaluate"]),
        json!(["Runtime.evaluate", "Page.getFrameTree", "Input.insertText", "Page.getFrameTree"]),
    ] {
        let mut invalid = proof.clone();
        invalid["calls"] = calls;
        fs::write(&proof_path, serde_json::to_vec(&invalid).unwrap()).unwrap();
        assert_eq!(
            startup::prepare_restart(&config.root, &folders).unwrap_err(),
            "first startup proof is not a successful exclusive read-only prime"
        );
    }
    fs::write(&proof_path, original_proof).unwrap();
'''.encode().replace(b'\n',newline)
path.write_bytes(data.replace(old,code+old))
print('Rust red verified; fixed exact four-call gate and strengthened real one-use ticket test')
