from pathlib import Path
import ast
stage = Path(__file__).parent
text = (stage/'run-current.py').read_text()
assert text.count('stage = Path(__file__).parent') == 1
text = text.replace('stage = Path(__file__).parent', "stage = Path(__file__).parent / 'round2'\nstage.mkdir(exist_ok=False)")
needle = "sources = load(baseline / 'sources-applied.json')"
replacement = """original_sources = load(baseline / 'sources-applied.json')
sources = {name:sha(root/name) for name in original_sources}
delta = {name:{'before':old,'after':sources[name]} for name,old in original_sources.items() if sources[name] != old}
assert set(delta) == {'tauri/scripts/native-perf-startup.mjs','tauri/scripts/native-perf-startup.test.mjs'}
save('source-delta.json', {'externalNodeRunnerChangesOnly':True,'GUIBuildInputsUnchanged':True,'changed':delta})
save('sources-current.json', sources)"""
assert text.count(needle) == 1
text = text.replace(needle,replacement)
assert text.count("'sourceManifestSha256':sha(baseline/'sources-applied.json')") == 1
text = text.replace("'sourceManifestSha256':sha(baseline/'sources-applied.json')", "'sourceManifestSha256':sha(stage/'sources-current.json')")
ast.parse(text)
with (stage/'run-fixed.py').open('x',encoding='utf-8',newline='\n') as out: out.write(text)
print('Prepared fixed runner, fresh round2 output, exact two external Node source changes')
