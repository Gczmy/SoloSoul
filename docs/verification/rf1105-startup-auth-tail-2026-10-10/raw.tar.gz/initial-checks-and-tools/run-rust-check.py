from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
root = Path('D:/SoloSoul')
stage = Path(__file__).parent
cache = root/'build/rf312-maintenance-20261009'
name = sys.argv[1]
command = sys.argv[2:]
assert command
env = os.environ.copy()
env.update({'TEMP':str(cache/'tmp'),'TMP':str(cache/'tmp'),
    'CARGO_HOME':str(cache/'cargo-home'),'CARGO_TARGET_DIR':str(cache/'cargo-target'),
    'CARGO_BUILD_JOBS':'1','ORT_CACHE_DIR':str(cache/'ort-cache'),
    'npm_config_cache':str(cache/'npm-cache'),
    'PDFIUM_LIBRARY_PATH':str(root/'tauri/src-tauri/resources/pdfium/pdfium.dll')})
env['PATH'] = 'C:/Program Files/Git/usr/bin;' + env.get('PATH','')
before = {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
    for p in [root/'tauri/scripts/native-perf-startup.mjs',root/'tauri/scripts/native-perf-startup.test.mjs',
        root/'tauri/src-tauri/src/native_perf/startup.rs',root/'tauri/src-tauri/src/native_perf/preflight_tests.rs']}
began = time.monotonic()
with (stage/(name+'.stdout.log')).open('xb') as out, (stage/(name+'.stderr.log')).open('xb') as err:
    p = subprocess.Popen(command,cwd=root/'tauri',env=env,stdout=out,stderr=err,
        creationflags=subprocess.CREATE_NO_WINDOW)
    with (stage/(name+'.live.json')).open('x',encoding='utf-8') as log:
        json.dump({'pid':p.pid,'command':command,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},log,indent=2)
    print(f'{name} live PID {p.pid}',flush=True)
    code = p.wait()
unchanged = all(hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in before.items())
with (stage/(name+'.receipt.json')).open('x',encoding='utf-8',newline='\n') as out:
    out.write(json.dumps({'pid':p.pid,'command':command,'exitCode':code,
        'elapsedSeconds':time.monotonic()-began,'sourceUnchanged':unchanged,'sourceFiles':before,
        'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print(f'{name} terminal exit {code}',flush=True)
raise SystemExit(code)
