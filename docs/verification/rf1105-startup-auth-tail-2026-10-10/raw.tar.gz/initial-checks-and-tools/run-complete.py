from pathlib import Path
import datetime, hashlib, json, os, shutil, struct, subprocess, sys, time, tomllib

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
cache = root/'build/rf312-maintenance-20261009'
baseline = root/'build/rf121-theme-binding-20261010'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
    with (stage/name).open('x',encoding='utf-8',newline='\n') as out:
        out.write(json.dumps(value,indent=2)+'\n')
def run(name,command):
    code = subprocess.call([sys.executable,'-X','utf8',str(stage/'run-rust-check.py'),name,*command],cwd=root)
    assert code == 0, (name,code)

subprocess.run([sys.executable,'-X','utf8',str(stage/'complete-rust-fix.py')],check=True)
run('rf1105-rust-format-write',['cargo','fmt','--all'])
original = load(baseline/'sources-applied.json')
sources = {name:sha(root/name) for name in original}
delta = {name:{'before':old,'after':sources[name]} for name,old in original.items() if sources[name]!=old}
assert set(delta) == {'tauri/scripts/native-perf-startup.mjs','tauri/scripts/native-perf-startup.test.mjs',
    'tauri/src-tauri/src/native_perf/startup.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs'},delta
save('sources-fixed.json',sources)
save('source-delta-fixed.json',{'changed':delta,'defaultProductCodeChanged':False,
    'scope':'Exact startup verification gates and corresponding regression fixtures'})
def verify():
    for name,digest in sources.items(): assert sha(root/name)==digest,name
jobs = [
    ('rf1105-rust-format-check',['cargo','fmt','--all','--check']),
    ('rf1105-clippy-default',['cargo','clippy','--locked','--all-targets','--','-D','warnings']),
    ('rf1105-clippy-native',['cargo','clippy','--locked','--features','native-perf','--all-targets','--','-D','warnings']),
    ('rf1105-rust-native',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','native_perf::','--','--nocapture']),
    ('rf1105-rust-rf905',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','rf905','--','--nocapture']),
    ('rf1105-rust-preferences',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','commands::update_preferences::tests','--','--nocapture']),
    ('rf1105-rust-default',['cargo','test','--locked','--workspace']),
]
for name,command in jobs:
    verify(); run(name,command); verify()
assert load(stage/'rf1105-node-full.receipt.json')['exitCode'] == 0
assert load(stage/'rf1105-format-green.receipt.json')['exitCode'] == 0
node = (stage/'rf1105-node-full.stdout.log').read_text()
assert all(x in node for x in ['tests 229','pass 228','fail 0','skipped 1'])
env = os.environ.copy()
env.update({'TEMP':str(cache/'tmp'),'TMP':str(cache/'tmp'),
    'CARGO_HOME':str(cache/'cargo-home'),'CARGO_TARGET_DIR':str(cache/'cargo-target'),
    'CARGO_BUILD_JOBS':'1','ORT_CACHE_DIR':str(cache/'ort-cache'),
    'npm_config_cache':str(cache/'npm-cache')})
env['PATH'] = 'C:/Program Files/Git/usr/bin;' + env.get('PATH','')
env.pop('PDFIUM_LIBRARY_PATH',None)
manifest = root/'tauri/src-tauri/Cargo.toml'
before = manifest.read_bytes()
with (stage/'build-Cargo-before.toml').open('xb') as out: out.write(before)
name = 'rf1105-native-release-build'
command = ['npm.cmd','run','tauri','--','build','--config','src-tauri/tauri.native-perf.conf.json','--features','native-perf','--no-bundle','--ci']
began = time.monotonic()
with (stage/(name+'.stdout.log')).open('xb') as out,(stage/(name+'.stderr.log')).open('xb') as err:
    p = subprocess.Popen(command,cwd=root/'tauri',env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    save(name+'.live.json',{'pid':p.pid,'command':command,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    print(f'{name} live PID {p.pid}',flush=True)
    code = p.wait()
after = manifest.read_bytes()
with (stage/'build-Cargo-after.toml').open('xb') as out: out.write(after)
changed = [name for name,digest in sources.items() if sha(root/name)!=digest]
save(name+'.receipt.json',{'pid':p.pid,'command':command,'exitCode':code,
    'elapsedSeconds':time.monotonic()-began,'sourceUnchanged':not changed,'changedSourceFiles':changed,
    'pdfiumOverrideInherited':False,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
if changed:
    assert changed == ['tauri/src-tauri/Cargo.toml'],changed
    assert before.replace(b'\r\n',b'\n')==after.replace(b'\r\n',b'\n')
    assert tomllib.loads(before.decode())==tomllib.loads(after.decode())
    save('build-manifest-newline-parity.json',{'rawReceiptSourceUnchanged':False,
        'normalizedBytesEqual':True,'parsedTomlEqual':True,'beforeSha256':hashlib.sha256(before).hexdigest(),
        'afterSha256':hashlib.sha256(after).hexdigest(),'action':'Restore original newline bytes only'})
    manifest.write_bytes(before)
verify(); assert code == 0
runtime = stage/'ss-rf1105-runtime/bin'
runtime.mkdir(parents=True,exist_ok=False)
exe = runtime/'solo_soul.exe'
shutil.copy2(cache/'cargo-target/release/solo_soul.exe',exe)
data = exe.read_bytes(); offset = struct.unpack_from('<I',data,0x3c)[0]
assert data[offset:offset+4]==b'PE\0\0' and struct.unpack_from('<H',data,offset+24+68)[0]==2
old = load(baseline/'runtime-package-readable.json')
assert sha(exe)!=old['sha256']
resources = []
for item in old['resources']:
    source = Path(item['source'])
    relative = Path(item['copy']).relative_to(Path(old['exe']).parent)
    copy = runtime/relative
    assert copy.resolve().is_relative_to(runtime.resolve())
    assert sha(source)==item['sha256']
    copy.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(source,copy)
    assert sha(copy)==item['sha256']
    resources.append({'source':str(source),'copy':str(copy),'sha256':item['sha256']})
save('runtime-new.json',{'exe':str(exe),'sha256':sha(exe),'bytes':len(data),'windowsGuiSubsystem':2,
    'resources':resources,'previousExePreserved':True,'sourceManifestSha256':sha(stage/'sources-fixed.json')})
print('New GUI frozen; execute fresh round3 paired startup',flush=True)
script = (stage/'run-current.py').read_text()
assert script.count('stage = Path(__file__).parent') == 1
script = script.replace('stage = Path(__file__).parent', "stage = Path(__file__).parent / 'round3'\nstage.mkdir(exist_ok=False)")
script = script.replace("sources = load(baseline / 'sources-applied.json')", "sources = load(stage.parent / 'sources-fixed.json')")
script = script.replace("package = load(baseline / 'runtime-package-readable.json')", "package = load(stage.parent / 'runtime-new.json')")
script = script.replace("assert package['sha256'] == 'bf76631a27d6cef623355ce9c800a50f1b44314d0e80cdf13bb1f4386fedac6f'", "assert package['sha256'] != 'bf76631a27d6cef623355ce9c800a50f1b44314d0e80cdf13bb1f4386fedac6f'")
script = script.replace("'sourceManifestSha256':sha(baseline/'sources-applied.json')", "'sourceManifestSha256':sha(stage.parent/'sources-fixed.json')")
with (stage/'run-new-build.py').open('x',encoding='utf-8',newline='\n') as out: out.write(script)
run('rf1105-current-warm-groups',[sys.executable,'-X','utf8',str(stage/'run-new-build.py')])
run('rf1105-current-independent',['node',str(stage/'verify-fixed.mjs'),'--round3'])
print('All gates, new build and both five-pair groups verified; archive and commit remain',flush=True)
