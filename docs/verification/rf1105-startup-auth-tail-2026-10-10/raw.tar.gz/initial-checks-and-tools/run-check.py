from pathlib import Path
import datetime, json, os, subprocess, sys, time
stage = Path(__file__).parent
root = Path('D:/SoloSoul')
name = sys.argv[1]
commands = {
    'rf1105-red': ['node','--test','--test-name-pattern=startup accepts fixed authentication diagnostic tail','scripts/native-perf-startup.test.mjs'],
    'rf1105-targeted': ['node','--test','scripts/native-perf-startup.test.mjs'],
    'rf1105-node-full': ['node','scripts/run-node-tests.mjs'],
    'rf1105-format': ['node','node_modules/prettier/bin/prettier.cjs','--check','scripts/native-perf-startup.mjs','scripts/native-perf-startup.test.mjs'],
    'rf1105-format-green': ['node','node_modules/prettier/bin/prettier.cjs','--check','scripts/native-perf-startup.mjs','scripts/native-perf-startup.test.mjs'],
}
command = commands[name]
began = time.monotonic()
env = os.environ.copy()
env.update({'TEMP':str(stage),'TMP':str(stage)})
with (stage/(name+'.stdout.log')).open('xb') as out, (stage/(name+'.stderr.log')).open('xb') as err:
    result = subprocess.run(command,cwd=root/'tauri',env=env,stdout=out,stderr=err,
        creationflags=subprocess.CREATE_NO_WINDOW)
receipt = {'command':command,'exitCode':result.returncode,'elapsedSeconds':time.monotonic()-began,
    'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (stage/(name+'.receipt.json')).open('x',encoding='utf-8',newline='\n') as out:
    out.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(result.returncode)
