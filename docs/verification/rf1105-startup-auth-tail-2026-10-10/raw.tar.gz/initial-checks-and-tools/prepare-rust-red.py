from pathlib import Path
root = Path('D:/SoloSoul')
path = root/'tauri/src-tauri/src/native_perf/preflight_tests.rs'
data = path.read_bytes()
old = b'"calls":["Runtime.evaluate","Page.getFrameTree"]'
new = b'"calls":["Runtime.evaluate","Page.getFrameTree","Runtime.evaluate","Page.getFrameTree"]'
assert data.count(old) == 1
path.write_bytes(data.replace(old,new))
