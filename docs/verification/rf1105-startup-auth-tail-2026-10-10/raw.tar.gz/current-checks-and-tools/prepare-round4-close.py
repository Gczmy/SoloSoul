from pathlib import Path
base=Path(__file__).parent.resolve()
text=(base/'close-report.py').read_text(encoding='utf-8')
before="before = '- 已关闭：**287 / 297**；实际修复（已关闭）：287；排除：0；待验证/阻塞：3（RF-112、RF-121、RF-312）；暂缓：0；进行中：1；待执行：6。'"
after="before = '- 已关闭：**289 / 300**；实际修复（已关闭）：289；排除：0；待验证/阻塞：4（RF-112、RF-121、RF-312、RF-1109）；暂缓：0；进行中：1；待执行：6。'"
assert text.count(before)==1;text=text.replace(before,after)
before="after = before.replace('287 / 297','288 / 297').replace('实际修复（已关闭）：287','实际修复（已关闭）：288').replace('进行中：1','进行中：0')"
after="after = before.replace('289 / 300','290 / 300').replace('实际修复（已关闭）：289','实际修复（已关闭）：290').replace('进行中：1','进行中：0')"
assert text.count(before)==1;text=text.replace(before,after)
text=text.replace('288/297关闭、3待验证','290/300关闭、4待验证').replace('288/297, remaining3+6','290/300, remaining4+6')
text=text.replace('原1830源码/配置','原1830源码/配置')
before='- 新GUI Release exit0，1830源码/配置与94资源冻结。'
after='- 实际GUI Release exit0，Windows Rust/前端/构建及94资源未变，原构建EXE字节复核一致。后续仅4份Android原生测试或外部Python诊断变更显式绑定新1830来源清单，1826份其余来源逐字不变；原构建清单和换行回执保持。'
assert text.count(before)==1;text=text.replace(before,after)
before='- 新目录100/5000对象各5/5完整启动对'
after='- 会话1重新连接后已实测Active、OpenInputDesktop成功；本任务API31模拟器和5049私有ADB停止且fresh CIM无存活。本轮新round4目录100/5000对象各5/5完整启动对'
assert text.count(before)==1;text=text.replace(before,after)
text=text.replace('RF-112/121/312整项仍待验证','RF-112/121/312与RF-1109整项仍待验证')
before='RF-112/121/312整项仍待验证'
text=text.replace('RF-112/121/312 整项仍待验证','RF-112/121/312 与 RF-1109 仍待验证')
text=text.replace('后续深色/布局/恢复矩阵需独立场景；RF-312','后续深色/布局/恢复矩阵需独立场景，RF-1109首页保持待验证；RF-312')
text=text.replace('新构建使用原公开100/5000对象夹具','已核验Windows编译输入/EXE/94资源不变；4份仅Android测试/诊断变更显式绑定新1830来源，原清单保持。会话1已Active且输入桌面可用，专用Android模拟器与私有ADB停止。本轮round4使用原公开100/5000对象夹具')
text=text.replace('原两轮共五个失败样本保留。','原两轮共五个失败样本及round3桌面准入失败保留。')
text=text.replace('RF-121完整材质矩阵及其他任务前置不解除。','RF-121完整材质矩阵、RF-1109首页和其他任务前置不解除。')
(base/'close-round4-report.py').write_text(text,encoding='utf-8')
print('Prepared RF1105 closure at 290/300 only after actual full validation, cleanup and archive gates')
