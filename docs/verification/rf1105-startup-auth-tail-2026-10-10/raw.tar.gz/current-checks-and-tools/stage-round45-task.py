from pathlib import Path
import collections,difflib,json,re,subprocess
root=Path('D:/SoloSoul');base=Path(__file__).parent.resolve()
name='docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md'
before=subprocess.run(['git','show','HEAD:'+name],cwd=root,check=True,capture_output=True).stdout.decode()
current=(root/name).read_text(encoding='utf-8')
pending='### Android私有设备就绪与生成文件核对（2026-10-10）'
retained='### RF-1108 Android卡片截图等待原生绘制（2026-10-10）'
assert current.count(pending)==current.count(retained)==1
desired=current[:current.index(pending)]+current[current.index(retained):]
rows=[line for line in desired.splitlines() if re.match(r'^\| \d+ \| \[RF-\d+\]',line)]
assert len(rows)==300
assert collections.Counter(re.search(r'\[([x!~ ])\]',r).group(1) for r in rows)=={'x':290,'!':4,' ':6}
assert subprocess.run(['git','diff','--cached','--name-only'],cwd=root,check=True,capture_output=True).stdout==b''
patch=''.join(difflib.unified_diff(before.splitlines(True),desired.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(base/'rf1105-round45-report-stage.patch').write_text(patch,encoding='utf-8',newline='\n')
subprocess.run(['git','apply','--cached','--whitespace=error','-'],cwd=root,input=patch.encode(),check=True)
paths=['tauri/scripts/native-perf-startup.mjs','tauri/scripts/native-perf-startup.test.mjs',
       'tauri/src-tauri/src/native_perf/startup.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs',
       'docs/verification/RF-1105-startup-auth-tail.md','docs/verification/rf1105-startup-auth-tail-2026-10-10.json']
subprocess.run(['git','add','--',*paths],cwd=root,check=True)
subprocess.run(['git','add','-f','--','docs/verification/rf1105-startup-auth-tail-2026-10-10'],cwd=root,check=True)
text=(base/'verify-staged.py').read_text(encoding='utf-8')
text=text.replace('== 297','== 300').replace("{'x':288,'!':3,' ':6}","{'x':290,'!':4,' ':6}")
text=text.replace('tasks288/297, remaining3+6','tasks290/300, remaining4+6')
(base/'verify-round45-staged.py').write_text(text,encoding='utf-8')
subprocess.run(['python','-X','utf8',str(base/'verify-round45-staged.py')],cwd=root,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
print('Only RF1105 four source files and own reports/evidence staged; pending Android progress excluded; staged raw archive verified')
