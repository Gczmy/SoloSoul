from pathlib import Path
base=Path(__file__).parent.resolve()
text=(base/'prepare-cleanup-round45.py').read_text(encoding='utf-8')
before='("\'validation-round45.json\'",r"\'after-rf1106\\cleanup-plan.json\'"),'
after='("\'validation.json\'",r"\'after-rf1106\\cleanup-plan.json\'"),'
assert text.count(before)==1,text[text.index('replacements ='):text.index('replacements =')+250]
text=text.replace(before,after).replace('cleanup-plan.json','cleanup-plan-v2.json')
(base/'prepare-cleanup-round45-v2.py').write_text(text,encoding='utf-8')
print('Preserved first preparation failure and plan; corrected only original-template selector, writing a new v2 plan')
