from pathlib import Path
import datetime, gzip, hashlib, io, json, re, subprocess, tarfile

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
initial_stage = stage.parent
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
validation = load(stage/'validation.json')
cleanup = load(initial_stage/'cache-cleanup.json')
assert validation['accepted'] and len(validation['groups']) == 2
assert [len(g['samples']) for g in validation['groups']] == [5,5]
assert cleanup['matchingOwnedIdentitiesLive'] == cleanup['processesTerminatedByThisTool'] == 0
assert cleanup['preservedBytesVerified']
for row in cleanup['preservedVaultAndRootFiles']:
    assert sha(Path(row['path']).read_bytes()) == row['sha256']
for row in cleanup['applicationLogs']:
    assert sha(Path(row['copy']).read_bytes()) == row['sha256']
sources = load(stage/'sources-fixed.json')
for name,digest in sources.items(): assert sha((root/name).read_bytes()) == digest,name
package = load(stage/'runtime-new.json')
assert sha(Path(package['exe']).read_bytes()) == package['sha256']
checks = {}
for name in ['rf1105-targeted','rf1105-node-full','rf1105-format-green',
    'rf1105-rust-format-check','rf1105-clippy-default','rf1105-clippy-native',
    'rf1105-rust-native','rf1105-rust-rf905','rf1105-rust-preferences','rf1105-rust-default',
    'rf1105-native-release-build','rf1105-current-warm-groups','rf1105-current-independent']:
    receipt = load(stage/(name+'.receipt.json'))
    assert receipt['exitCode'] == 0,name
    checks[name] = receipt
    log = (stage/(name+'.stdout.log')).read_text(encoding='utf-8')
    totals = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
    if totals:
        assert all(failed=='0' for _,failed,_ in totals)
        checks[name]['testTotals'] = {'passed':sum(int(p) for p,_,_ in totals),
            'failed':0,'ignored':sum(int(i) for _,_,i in totals)}
assert load(stage/'rf1105-red.receipt.json')['exitCode'] == 1
assert load(stage/'rf1105-rust-red.receipt.json')['exitCode'] == 101
assert load(stage/'failed-offline-validation.json')['originalGroupsRemainFailed']

members = {}
def add(source,name):
    assert source.is_file() and not source.is_symlink() and not (source.lstat().st_file_attributes & 0x400)
    assert not name.lower().endswith(('.exe','.dll','.db','.onnx'))
    assert name not in members
    members[name] = source.read_bytes()
for folder,label in [(stage,'current-checks-and-tools'),(initial_stage,'initial-checks-and-tools')]:
    for file in folder.iterdir():
        if file.is_file() and file.suffix in {'.py','.ps1','.mjs','.json','.log','.toml'}:
            add(file,label+'/'+file.name)
for folder in [initial_stage/'round2',stage/'round3']:
    for file in folder.iterdir():
        if file.is_file(): add(file,folder.name+'/'+file.name)
for folder in [initial_stage/'samples100',initial_stage/'round2/samples100',stage/'round3/samples100',stage/'round3/samples5000']:
    relative = ('current/'+folder.relative_to(stage).as_posix()) if folder.is_relative_to(stage) else ('initial/'+folder.relative_to(initial_stage).as_posix())
    for file in folder.iterdir():
        if file.is_file(): add(file,relative+'/'+file.name)
        elif re.fullmatch(r'sample-00[1-5]',file.name):
            for item in file.iterdir():
                if item.is_file(): add(item,relative+'/'+file.name+'/'+item.name)
                elif item.name in {'startup-01','startup-02'}:
                    for proof in item.iterdir():
                        if proof.is_file(): add(proof,relative+'/'+file.name+'/'+item.name+'/'+proof.name)
for file in (initial_stage/'application-logs').rglob('*'):
    if file.is_file(): add(file,file.relative_to(initial_stage).as_posix())
original = load(root/'build/rf121-theme-binding-20261010/sources-applied.json')
red = load(stage/'rf1105-rust-red.receipt.json')['sourceFiles']
for name in load(stage/'source-delta-fixed.json')['changed']:
    add(root/name,'source-after/'+name)
    result = subprocess.run(['git','show','HEAD:'+name],cwd=root,check=True,capture_output=True)
    before = result.stdout
    if sha(before) != original[name]:
        before = before.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')
    assert sha(before) == original[name],name
    members['source-before/'+name] = before
    if name.endswith('preflight_tests.rs'):
        rust_red = before.replace(b'"calls":["Runtime.evaluate","Page.getFrameTree"]',
            b'"calls":["Runtime.evaluate","Page.getFrameTree","Runtime.evaluate","Page.getFrameTree"]')
    elif name.endswith('startup.rs'):
        rust_red = before
    else:
        rust_red = (root/name).read_bytes()
    assert sha(rust_red) == red[name],name
    members['source-rust-red/'+name] = rust_red

destination = root/'docs/verification/rf1105-startup-auth-tail-2026-10-10'
destination.mkdir(exist_ok=False)
archive = destination/'raw.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(mode='w',fileobj=zipped,format=tarfile.PAX_FORMAT) as tar:
            for name,data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size,info.mtime,info.mode = len(data),0,0o644
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    actual = {i.name:tar.extractfile(i).read() for i in tar.getmembers() if i.isfile()}
assert actual == members
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as out:
        out.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
index = {'schemaVersion':1,'task':'RF-1105','archive':'raw.tar.gz','archiveSha256':sha(archive.read_bytes()),
    'archiveBytes':archive.stat().st_size,'memberCount':len(members),
    'members':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())],
    'readbackAllMembersVerified':True,'includesPhysicalVaults':False,'includesExecutablesModelsOrCaches':False}
write(destination/'index.json',index)
write(destination.parent/'rf1105-startup-auth-tail-2026-10-10.json',{
    'schemaVersion':1,'task':'RF-1105','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'accepted':True,'scope':'Exact fixed read-only startup/auth tail in Node and optional Rust prime gate',
    'checks':checks,'runtime':package,'validation':validation,
    'failures':load(stage/'failed-offline-validation.json'),'cleanup':cleanup,
    'archive':{'path':destination.relative_to(root).as_posix(),**{k:index[k] for k in ['archiveSha256','archiveBytes','memberCount','readbackAllMembersVerified']}},
    'sdkBudgetsUnchanged':True,'defaultDependenciesChanged':False,'defaultProductCodeChanged':False,
    'dependencyTestOnlyFixes':['RF-1106','RF-1107'],'reusedChecks':load(stage/'reused-checks.json'),
    'fullMaterialMatrixAccepted':False,'rf312Closed':False,'originalHomeTimeoutRootCauseProven':False})
with (destination/'.gitattributes').open('x',encoding='utf-8',newline='\n') as out:
    out.write('# Keep original evidence bytes.\n* -text\n')
print(f'RF-1105 archived {len(members)} originals ({archive.stat().st_size} bytes), read back all hashes')
