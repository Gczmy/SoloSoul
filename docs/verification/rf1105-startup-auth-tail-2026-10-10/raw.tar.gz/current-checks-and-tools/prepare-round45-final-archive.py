from pathlib import Path
base=Path(__file__).parent.resolve()
text=(base/'archive-round45-complete.py').read_text(encoding='utf-8')
assert text.count("'rf1105-round45-independent'")==1
text=text.replace("'rf1105-round45-independent'","'rf1105-round45-independent-v3'")
before="'originalPartialGroupStillFailed':True,"
after="""'originalPartialGroupStillFailed':True,
    'offlineVerifierCorrections':{
        'originalZeroBackendExpectation':load(stage/'rf1105-round45-independent.receipt.json'),
        'originalSerialOnlyReadExpectation':load(stage/'rf1105-round45-independent-v2.receipt.json'),
        'canonicalReadOnlyAuthVerified':load(stage/'rf1105-round45-independent-v3.receipt.json'),
        'concurrentAccountReadsOrdinalPaired':False,'passwordFlowsAndLoginAttempts':0},
    'cleanupDriverFailuresPreserved':[
        load(stage/'rf1105-round45-prepare-cleanup-v3.receipt.json'),
        load(stage/'rf1105-round45-cache-cleanup.receipt.json')],
    'actualCleanupReceipt':load(stage/'rf1105-round45-cache-cleanup-v2.receipt.json'),"""
assert text.count(before)==1;text=text.replace(before,after)
(base/'archive-round45-final.py').write_text(text,encoding='utf-8')
text=(base/'close-round45-report.py').read_text(encoding='utf-8')
text=text.replace('二代认证快照合同','二代认证快照合同')
text=text.replace('没有密码输入或后端认证尝试。','没有密码输入或login后端尝试；完成的accounts-refresh只读记录与前端请求次数合同匹配，并发读取不作序号配对或跨时钟归因。')
before='- fresh CIM核验'
after='- 临时独立核验器首次误要求零后端记录，第二次误要求只读账号请求全串行，原exit1保留；按现有认证合同核验全部只读accounts-refresh均完成、rootVerified、前后端次数一致，零密码流程/零login尝试，并发情况显式记录无法顺序归因，v3 exit0。清理生成器的模板匹配失败与旧Windows PowerShell缺少Get-FileHash的exit1也保留，均发生于删除之前；随后使用同一守卫脚本与当前PowerShell7完成实际清理。\n- fresh CIM核验'
assert text.count(before)==1;text=text.replace(before,after)
(base/'close-round45-final-report.py').write_text(text,encoding='utf-8')
print('Prepared final archive with every native/offline/tool failure preserved and canonical concurrent read-only attribution recorded')
