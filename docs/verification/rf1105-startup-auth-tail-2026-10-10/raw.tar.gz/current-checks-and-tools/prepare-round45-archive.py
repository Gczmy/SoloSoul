from pathlib import Path
base=Path(__file__).parent.resolve()
text=(base/'archive-round4-complete.py').read_text(encoding='utf-8')
replacements=[
 ("validation = load(stage/'validation.json')","validation = load(stage/'validation-round45.json')"),
 ("'rf1105-round4-independent'","'rf1105-round45-independent'"),
 ("[initial_stage/'round2',stage/'round3',stage/'round4']","[initial_stage/'round2',stage/'round3',stage/'round4',stage/'round5']"),
 ("stage/'round4/samples5000']","stage/'round4/samples5000',stage/'round5/samples5000']"),
 ("'currentGroupReceipts':[load(stage/'round4'/f'startup-{size}.receipt.json') for size in [100,5000]],",
  "'currentGroupReceipts':[load(stage/('round4' if size==100 else 'round5')/f'startup-{size}.receipt.json') for size in [100,5000]],\n    'additionalFailedNativeGroup':load(stage/'round4/samples5000/report.json'),\n    'postFailureFreshExitCheck':load(stage/'round4-sample004-fresh-exit-check.json'),\n    'freshWholeGroupRetry':True,'originalPartialGroupStillFailed':True,")]
for before,after in replacements:
 assert text.count(before)==1,(before,text.count(before));text=text.replace(before,after)
(base/'archive-round45-complete.py').write_text(text,encoding='utf-8')
text=(base/'close-round4-report.py').read_text(encoding='utf-8')
before='本轮新round4目录100/5000对象各5/5完整启动对'
after='本轮100对象round4与5000对象全新round5各5/5完整启动对'
assert text.count(before)==1;text=text.replace(before,after)
text=text.replace('本轮round4使用原公开100/5000对象夹具','本轮100对象round4和5000对象全新round5使用原公开100/5000对象夹具')
before='- fresh CIM核验'
after='- 另保留round4的5000对象失败组：前3组完整通过，第4组在短命WebView后代消失的快照处无法完整确认归属/内存，严格拒绝后续诊断及第5组。原清理失败保持；新的fresh CIM确认9份记录身份及本任务路径无存活后，才在全新round5目录完整重跑5组，未拼接旧部分成功样本、未改预算/谓词或绕过退出核验。\n- fresh CIM核验'
assert text.count(before)==1;text=text.replace(before,after)
before='原两轮共五个失败样本及round3桌面准入失败保留。'
after='原两轮共五个失败样本及round3桌面准入失败保留。新增round4的5000对象组前3对成功、第4对因瞬时后代归属/内存无法完整核验而严格失败并停止第5对；其原清理不完整记录保持。fresh CIM确认9份记录身份和本任务路径无存活后，使用全新round5目录完整重跑5000对象5组，未拼接部分成功或放宽谓词。'
assert text.count(before)==1;text=text.replace(before,after)
(base/'close-round45-report.py').write_text(text,encoding='utf-8')
print('Prepared round45 evidence and closure, preserving every failed group and explicit full-group retry scope')
