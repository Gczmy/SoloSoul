from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path('D:/SoloSoul');base=Path(__file__).parent.resolve()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=load(base/'sources-round4.json')
def verify():
 for name,digest in sources.items():assert sha(root/name)==digest,name
def run(name,command):
 verify();start=time.monotonic()
 with (base/(name+'.stdout.log')).open('xb') as out,(base/(name+'.stderr.log')).open('xb') as err:
  result=subprocess.run(command,cwd=root/'tauri',stdin=subprocess.DEVNULL,stdout=out,stderr=err,
      creationflags=subprocess.CREATE_NO_WINDOW)
 verify()
 (base/(name+'.receipt.json')).write_text(json.dumps(dict(command=command,exitCode=result.returncode,
     elapsedSeconds=time.monotonic()-start,sourceFiles=sources,sourceUnchanged=True,
     at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n',encoding='utf-8')
 print(f'{name} exit {result.returncode}',flush=True)
 assert result.returncode==0,name
for size in [100,5000]:
 receipt=load(base/'round4'/f'startup-{size}.receipt.json');assert receipt['exitCode']==0
(base/'rf1105-round4-warm-groups.receipt.json').write_text(json.dumps(dict(
 command=['python','-X','utf8',str(base/'run-round4-current.py')],exitCode=0,sourceFiles=sources,
 sourceUnchanged=True,groupReceipts=[str(base/'round4'/f'startup-{size}.receipt.json') for size in [100,5000]],
 derivedFromActualTerminalGroupReceipts=True,originalRound3FailureRetained=True),indent=2)+'\n',encoding='utf-8')
run('rf1105-round4-independent',['node',str(base/'verify-round4.mjs'),'--round4'])
text=(base/'prepare-cleanup-all.py').read_text(encoding='utf-8')
text=text.replace("'rf1105-current-independent.receipt.json'","'rf1105-round4-independent.receipt.json'")
text=text.replace('round3','round4').replace("'cleanup-owned-all.ps1'","'cleanup-owned-round4-all.ps1'")
(base/'prepare-cleanup-round4.py').write_text(text,encoding='utf-8')
run('rf1105-round4-prepare-cleanup',['python','-X','utf8',str(base/'prepare-cleanup-round4.py')])
print('Round4 independently verified; exact bounded cache cleanup is prepared and remains to be executed',flush=True)
