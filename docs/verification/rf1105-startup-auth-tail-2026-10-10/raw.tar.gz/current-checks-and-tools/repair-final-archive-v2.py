from pathlib import Path
import json,datetime
base=Path(__file__).parent.resolve()
raw=json.loads((base/'rf1105-rust-red.receipt.json').read_text(encoding='utf-8-sig'))['sourceFiles']
normalized={name.replace(chr(92),'/'):digest for name,digest in raw.items()}
changed=json.loads((base/'source-delta-fixed.json').read_text(encoding='utf-8-sig'))['changed']
assert set(normalized)==set(changed) and len(normalized)==len(raw)==4
text=(base/'archive-round45-final.py').read_text(encoding='utf-8')
before="red = load(stage/'rf1105-rust-red.receipt.json')['sourceFiles']"
after="red = {name.replace(chr(92),'/'):digest for name,digest in load(stage/'rf1105-rust-red.receipt.json')['sourceFiles'].items()}"
assert text.count(before)==1;text=text.replace(before,after)
(base/'archive-round45-final-v2.py').write_text(text,encoding='utf-8')
(base/'archive-round45-original-failure.json').write_text(json.dumps(dict(
 accepted=False,errorType='KeyError',missingKey='tauri/scripts/native-perf-startup.mjs',
 source='archive-round45-final.py',scope='Raw archive assembly before any archive/report/index write',
 actualRedBoundSources=list(raw),archiveCreated=False,stagedFiles=0,
 reason='Windows receipt keys use backslashes; manifest keys use forward slashes. Normalize identifiers only; all four exact source hashes still required.',
 firstRepairRejected=True,firstRepairReason='Incorrect assumption of a two-source receipt rejected before any write',
 at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n',encoding='utf-8')
print('Original path-key rejection preserved; all four actual red-source SHA bindings retained, with identifier slash normalization only')
