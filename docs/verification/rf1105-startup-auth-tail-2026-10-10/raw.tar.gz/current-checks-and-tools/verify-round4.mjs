import { readFile, writeFile, lstat, realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkStartup, checkPair, checkStartupPreferences, summarizePairs } from '../../../tauri/scripts/native-perf-startup.mjs';
import { checkBound } from '../../../tauri/scripts/native-perf-sdk-journey.mjs';
import { normalizeWindowsPath, cleanupOutcome } from '../../../tauri/scripts/native-perf-run.mjs';
import { describeAuthAttribution } from '../../../tauri/scripts/native-perf-auth-contract.mjs';
import { checkMaintenanceAdmission } from '../../../tauri/scripts/native-perf-maintenance-contract.mjs';

const stage = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(stage,'../../..');
const same = (a,b) => normalizeWindowsPath(a) === normalizeWindowsPath(b);
const sha = async p => createHash('sha256').update(await readFile(p)).digest('hex');
const load = async p => {
  const s = await lstat(p);
  assert(s.isFile() && !s.isSymbolicLink() && s.size <= 32*1024*1024);
  assert(same(await realpath(p),p));
  return JSON.parse((await readFile(p,'utf8')).replace(/^\uFEFF/,''));
};
const mode = process.argv.slice(2);
assert(mode.length === 1 && ['--failed-only','--round4'].includes(mode[0]));
if(mode[0] === '--failed-only') {
  const groups = [];
  for(const [dir,count] of [[path.join(stage,'samples100'),4],[path.join(stage,'round2/samples100'),1]]) {
    const report = await load(path.join(dir,'report.json'));
    assert.equal(report.summary.complete,false);
    assert.equal(report.samples.length,count);
    const samples = [];
    for(const s of report.samples) {
      const d = path.join(dir,`sample-${String(s.index).padStart(3,'0')}`);
      assert(same(s.root,d));
      const owned = await load(path.join(d,'native-perf-owned.json'));
      const first = await load(path.join(d,'startup-01/native-perf-sdk-journey.json'));
      const bound = await load(path.join(d,'startup-01/native-perf-sdk-journey-bound.json'));
      checkStartup(first,owned,bound,1,owned.runId);
      assert.deepEqual(first,s.first.nativeProof);
      assert.equal(s.success,false);
      samples.push({index:s.index,root:d,runId:owned.runId,firstProofAcceptedOffline:true,
        originalResultUnchanged:true,error:s.error,firstError:s.first.error??null,
        originalCleanupIntegrity:s.first.cleanupIntegrity,
        recordedIdentities:s.first.identities});
    }
    groups.push({root:dir,requested:5,accepted:false,samples});
  }
  await writeFile(path.join(stage,'failed-offline-validation.json'),JSON.stringify({task:'RF-1105',
    accepted:false,firstProofsAcceptedOffline:5,originalGroupsRemainFailed:true,groups},null,2)+'\n',{flag:'wx'});
  process.stdout.write('Five original first-generation proofs accepted offline; both original groups remain failed\n');
} else {
  const active = path.join(stage,'round4');
  const proof = await load(path.join(active,'input-proof.json'));
  assert.equal(await sha(proof.exe),proof.exeSha256);
  for(const [name,hash] of Object.entries(proof.sourceFiles)) assert.equal(await sha(path.join(root,name)),hash);
  for(const row of proof.resources) assert.equal(await sha(row.copy),row.sha256);
  const groups = [];
  for(const size of [100,5000]) {
    const dir = path.join(active,`samples${size}`);
    const report = await load(path.join(dir,'report.json'));
    assert.equal(report.exeSha256,proof.exeSha256);
    assert.equal(report.samplesRequested,5); assert.equal(report.samples.length,5);
    assert.equal(report.sourceUnchanged,true); assert.equal(report.interrupted,false);
    assert.equal((await load(path.join(active,`startup-${size}.receipt.json`))).exitCode,0);
    const samples = [];
    for(const s of report.samples) {
      const d = path.join(dir,`sample-${String(s.index).padStart(3,'0')}`);
      assert(same(s.root,d));
      assert.deepEqual(await load(path.join(dir,`sample-${String(s.index).padStart(3,'0')}.json`)),s);
      assert.equal(s.success,true); assert(!s.cleanupIncomplete);
      const owned = await load(path.join(d,'native-perf-owned.json'));
      assert.deepEqual(owned,s.owned);
      const ticket = await load(path.join(d,'native-perf-startup-restart-ticket.json'));
      const stopped = await load(path.join(d,'native-perf-startup-stopped.json'));
      const used = await load(path.join(d,'native-perf-startup-restart-consumed.json'));
      assert.deepEqual(ticket,s.ticket);
      for(const [name,label] of [['native-perf-owned.json','ownedSha256'],['native-perf-consumed.json','consumedSha256'],
        ['startup-01/native-perf-sdk-journey.json','proofSha256'],['native-perf-startup-stopped.json','stoppedSha256']]) {
        assert.equal(await sha(path.join(d,name)),ticket[label]);
      }
      assert.equal(ticket.exeSha256,proof.exeSha256);
      assert.equal(ticket.uiPreferencesSha256,stopped.uiPreferencesSha256);
      assert.equal(used.ticketSha256,await sha(path.join(d,'native-perf-startup-restart-ticket.json')));
      assert.equal(used.runId,ticket.runId); assert.equal(used.ownerRunId,owned.runId);
      assert.equal(used.pid,s.warm.pid); assert.equal(used.port,s.warm.port);
      assert(same(used.root,d) && same(ticket.root,d));
      for(const exit of [ticket.exitCheck,used.exitCheck]) {
        assert.equal(exit.verified,true); assert.equal(exit.checkedIdentities,stopped.identities.length);
        assert(Number.isInteger(exit.queryPid) && exit.queryPid>0);
        assert(Number.isInteger(exit.checkedAtUnixMs));
        assert(exit.checkedAtUnixMs>=Date.parse(s.startedAt) && exit.checkedAtUnixMs<=Date.parse(s.finishedAt));
        assert(exit.checkedAtUnixMs<=s.warm.nativeProof.timeOriginMs);
      }
      assert(used.exitCheck.checkedAtUnixMs>=ticket.exitCheck.checkedAtUnixMs);
      assert(used.exitCheck.checkedAtUnixMs-ticket.exitCheck.checkedAtUnixMs<=300000);
      for(const [launch,gen] of [[s.first,1],[s.warm,2]]) {
        const ed = path.join(d,`startup-0${gen}`);
        const p = await load(path.join(ed,'native-perf-sdk-journey.json'));
        const bound = await load(path.join(ed,'native-perf-sdk-journey-bound.json'));
        assert.deepEqual(p,launch.nativeProof); assert.deepEqual(bound,launch.bound);
        checkBound(bound,{root:d,runId:launch.launchId},launch.pid,launch.port);
        checkStartup(p,owned,bound,gen,launch.launchId);
        assert.deepEqual(await load(path.join(ed,'native-perf-sdk-phase-01.json')),p.phases[0]);
        assert.deepEqual(cleanupOutcome(launch.cleanup,launch.ownedProcessExit),launch.cleanupIntegrity);
        assert.equal(launch.cleanupIntegrity.complete,true);
        const auth = await load(path.join(ed,'native-perf-auth-attribution.json'));
        const desc = describeAuthAttribution(auth,{...owned,runId:launch.launchId},bound);
        assert.equal(desc.frontend.flows.length,0);
        assert.equal(desc.backend.attempts.length,0);
        checkMaintenanceAdmission(await load(path.join(ed,'native-perf-maintenance-admission.json')),
          auth,{...owned,runId:launch.launchId},bound);
      }
      checkPair(s.first.nativeProof,s.warm.nativeProof);
      assert.deepEqual(s.profileBefore,s.profileAfterFirst);
      assert.deepEqual(s.profileBefore,s.profileAfterWarm);
      for(const row of s.profileAfterWarm) {
        const stat = await lstat(row.path);
        assert(stat.isDirectory() && !stat.isSymbolicLink()); assert.equal(stat.birthtimeMs,row.birthtimeMs);
      }
      assert.equal(s.originalEvidenceUnchanged,true);
      for(const file of owned.fixture.files) {
        if(file.relativePath==='ui_preferences.json') continue;
        assert.equal(await sha(path.join(owned.vault,file.relativePath)),file.sha256);
      }
      checkStartupPreferences(await load(path.join(owned.vault,'ui_preferences.json')),ticket.updateSourceCandidates);
      samples.push({index:s.index,root:d,runId:owned.runId,firstMs:s.first.phases[0].durationMs,
        reusedMs:s.warm.phases[0].durationMs,complete:true,
        recordedIdentities:[...s.first.identities,...s.warm.identities]});
    }
    const summary = summarizePairs(report.samples,5,true);
    assert.deepEqual(summary,report.summary);
    groups.push({objects:size,root:dir,complete:true,samples,summary});
  }
  await writeFile(path.join(stage,'validation.json'),JSON.stringify({schemaVersion:1,task:'RF-1105',
    accepted:true,groups,rf312Closed:false,diagnosticOnly:true,includesDiagnosticOverhead:true,
    osColdStartupAccepted:false,at:new Date().toISOString()},null,2)+'\n',{flag:'wx'});
  process.stdout.write('Both complete five-pair groups independently verified, exact fixed auth tail and same profile\n');
}
