from pathlib import Path
import json
base=Path(__file__).parent.resolve()
check=json.loads((base/'round4-sample004-fresh-exit-check.json').read_text(encoding='utf-8-sig'))
assert check['matchingRecordedIdentitiesLive']==check['matchingTaskPathProcessesLive']==0
failed=json.loads((base/'round4/startup-5000.receipt.json').read_text(encoding='utf-8'))
assert failed['exitCode']==1
source=(base/'run-round4-current.py').read_text(encoding='utf-8')
assert source.count("stage = Path(__file__).parent / 'round4'")==1
source=source.replace("stage = Path(__file__).parent / 'round4'","stage = Path(__file__).parent / 'round5'")
before='for size in [100,5000]:\n    verify()'
assert source.count(before)==1
source=source.replace(before,'for size in [5000]:\n    verify()')
source=source.replace("'includesDiagnosticOverhead':True,'osColdStartAccepted':False,'rf312Closed':False}",
    "'includesDiagnosticOverhead':True,'osColdStartAccepted':False,'rf312Closed':False,\n    'requestedGroups':[5000],'fullGroupRetryAfterRound4Failure':True,'originalRound4FailurePreserved':True}")
source=source.replace("Both five-pair current-build groups terminal; independent verification required", "Fresh five-pair 5000 group terminal; independent verification required")
(base/'run-round5-5000.py').write_text(source,encoding='utf-8')
verifier=(base/'verify-round4.mjs').read_text(encoding='utf-8')
verifier=verifier.replace('--round4','--round45')
before='const dir = path.join(active,`samples${size}`);'
after="const groupActive = path.join(stage,size===100?'round4':'round5');\n    const dir = path.join(groupActive,`samples${size}`);"
assert verifier.count(before)==1;verifier=verifier.replace(before,after)
before='path.join(active,`startup-${size}.receipt.json`)'
assert verifier.count(before)==1;verifier=verifier.replace(before,'path.join(groupActive,`startup-${size}.receipt.json`)')
verifier=verifier.replace("path.join(stage,'validation.json')","path.join(stage,'validation-round45.json')")
(base/'verify-round45.mjs').write_text(verifier,encoding='utf-8')
print('Original 5000 failure retained; one fresh complete five-pair retry prepared without source, budget or predicate changes')
