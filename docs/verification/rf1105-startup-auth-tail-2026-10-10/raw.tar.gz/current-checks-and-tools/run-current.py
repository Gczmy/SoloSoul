from pathlib import Path
import datetime, hashlib, json, os, subprocess, time

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
baseline = root / 'build/rf121-theme-binding-20261010'
cache = root / 'build/rf312-maintenance-20261009'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def save(name, value):
    with (stage / name).open('x', encoding='utf-8', newline='\n') as out:
        out.write(json.dumps(value, indent=2) + '\n')

sources = load(baseline / 'sources-applied.json')
package = load(baseline / 'runtime-package-readable.json')
exe = Path(package['exe'])
assert package['sha256'] == 'bf76631a27d6cef623355ce9c800a50f1b44314d0e80cdf13bb1f4386fedac6f'
def verify():
    assert sha(exe) == package['sha256']
    assert len(package['resources']) == 94 and len(sources) == 1830
    for item in package['resources']:
        assert sha(Path(item['copy'])) == sha(Path(item['source'])) == item['sha256']
    for name, digest in sources.items():
        assert sha(root / name) == digest, name

probe = (baseline / 'round5-recheck-session.py').read_text()
assert probe.count('round5-session-preflight.json') == 1
with (stage / 'session-preflight.py').open('x', encoding='utf-8', newline='\n') as out:
    out.write(probe.replace('round5-session-preflight.json', 'session-preflight.json'))
subprocess.run(['python','-X','utf8',str(stage/'session-preflight.py')],check=True,
    creationflags=subprocess.CREATE_NO_WINDOW)
session = load(stage/'session-preflight.json')
assert session['connectionStateName'] == 'Active' and session['inputDesktopAvailable']
verify()
fixtures = {}
for size in [100, 5000]:
    fixture = cache / 'fixtures' / f'vault{size}'
    fixtures[str(size)] = {str(p.relative_to(fixture)):sha(p) for p in fixture.rglob('*') if p.is_file()}
    assert fixtures[str(size)]
save('input-proof.json', {'task':'RF-312','scope':'current same-profile Windows startup',
    'exe':str(exe),'exeSha256':package['sha256'],'resources':package['resources'],
    'sourceManifestSha256':sha(baseline/'sources-applied.json'),'sourceFiles':sources,
    'fixtureHashes':fixtures,'session':session,'samplesPerFixture':5,
    'includesDiagnosticOverhead':True,'osColdStartAccepted':False,'rf312Closed':False})
env = os.environ.copy()
env.update({'TEMP':str(stage),'TMP':str(stage)})
env['PATH'] = 'C:/Program Files/Git/usr/bin;' + env.get('PATH','')
env.pop('PDFIUM_LIBRARY_PATH',None)
env.pop('SOLOSOUL_REGISTRY_PUBKEY',None)
for size in [100,5000]:
    verify()
    output = stage / f'samples{size}'
    assert not output.exists()
    name = f'startup-{size}'
    command = ['node','scripts/native-perf-startup.mjs','--exe',str(exe),
        '--fixture',str(cache/'fixtures'/f'vault{size}'),'--output',str(output),'--samples','5']
    began = time.monotonic()
    with (stage/(name+'.stdout.log')).open('xb') as out, (stage/(name+'.stderr.log')).open('xb') as err:
        process = subprocess.Popen(command,cwd=root/'tauri',env=env,stdout=out,stderr=err,
            creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',{'pid':process.pid,'command':command,
            'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
        print(f'{name} live PID {process.pid}',flush=True)
        code = process.wait()
    verify()
    fixture = cache / 'fixtures' / f'vault{size}'
    assert fixtures[str(size)] == {str(p.relative_to(fixture)):sha(p) for p in fixture.rglob('*') if p.is_file()}
    save(name+'.receipt.json',{'pid':process.pid,'command':command,'exitCode':code,
        'elapsedSeconds':time.monotonic()-began,'sourceUnchanged':True,
        'resourcesUnchanged':True,'originalFixtureUnchanged':True,'sdkBudgetsUnchanged':True,
        'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    print(f'{name} terminal exit {code}',flush=True)
    if code: raise SystemExit(code)
print('Both five-pair current-build groups terminal; independent verification required',flush=True)
