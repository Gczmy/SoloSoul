from pathlib import Path
import datetime, hashlib, json

root=Path('D:/SoloSoul')
stage=Path(__file__).parent
android=root/'build/android-native-feasibility-20261010'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
session=load(stage/'round3/session-preflight.json')
build=load(stage/'rf1105-native-release-build.receipt.json')
warm=load(stage/'rf1105-current-warm-groups.receipt.json')
parity=load(stage/'build-manifest-newline-parity.json')
runtime=load(stage/'runtime-new.json')
assert build['exitCode']==0 and warm['exitCode']==1 and warm['sourceUnchanged']
assert session['connectionStateName']=='Disconnected' and session['inputDesktopError']==5
assert parity['normalizedBytesEqual'] and parity['parsedTomlEqual']
# The Android CLI may already have normalized Cargo.toml in its live build.
# Its immutable pre-build snapshot proves Windows restored the original bytes first.
assert sha(android/'android-build-Cargo-before.toml')==parity['beforeSha256']
assert {p.name for p in (stage/'round3').iterdir()}=={'session-preflight.py','session-preflight.json'}
assert sha(Path(runtime['exe']))==runtime['sha256']
record={'task':'RF-1105','accepted':False,
    'scope':'New GUI built; sampling stopped before launching applications because Session 1 disconnected',
    'buildExitCode':0,'runtimeSha256':runtime['sha256'],'runtimeBytes':runtime['bytes'],
    'resourcesFrozen':len(runtime['resources']),'manifestOriginalBytesRestoredBeforeAndroidBuild':True,
    'restorationWitnessSha256':sha(android/'android-build-Cargo-before.toml'),
    'session':session,'warmDriverExitCode':1,'samplesStarted':0,'samplingRetryStarted':False,
    'rf1105Closed':False,'rf312Closed':False,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (stage/'desktop-preflight-stop.json').open('x',encoding='utf-8',newline='\n') as out:
    out.write(json.dumps(record,indent=2)+'\n')
report=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md'
s=report.read_text(encoding='utf-8')
lines=s.splitlines(keepends=True)
assert sum(x.startswith('- 当前处理：') for x in lines)==1
lines=[('- 当前处理：**RF-1107/1106已分别验证提交；RF-1105新GUI构建成功，原生重启采样在启动应用前因会话1断开及输入桌面错误5停止，等待交互桌面恢复。Android默认Debug构建已启动，使用D盘私有工具链；RF-112/121/312及RF-122～127前置保持未完成**。\n' if x.startswith('- 当前处理：') else x) for x in lines]
s=''.join(lines)
s+='''
### RF-1105 新构建完成、桌面准入停止（2026-10-10）

- 新Windows GUI Release实际exit0，原始回执中的Cargo.toml换行变化保留，经规范化字节和TOML等价核验后恢复原字节；1830来源和94资源冻结。Android构建前保存的Cargo.toml副本SHA与原版一致，证明恢复发生在后续Android CLI再次处理换行之前。
- 原生采样前置实际读到会话1 Disconnected、OpenInputDesktop错误5，驱动exit1；未启动测试应用，0个样本，不放宽桌面门禁、不覆盖此前失败。原件保留在 build/rf312-warm-current-20261010/after-rf1106/desktop-preflight-stop.json；本项保持进行中。
- Android交叉编译探针实际exit0，旧120秒超时记录保留。当前改动只属于非默认Windows诊断，不进入默认Android产品；独立默认Debug x86_64 APK构建已启动，工具链和缓存优先D盘，尚未进行设备验收。
'''
report.write_text(s,encoding='utf-8',newline='\n')
print('Actual desktop preflight failure retained; RF-1105 stays open; Android independent build recorded')
