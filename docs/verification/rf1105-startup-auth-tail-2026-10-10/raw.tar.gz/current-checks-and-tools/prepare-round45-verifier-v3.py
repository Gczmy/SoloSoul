from pathlib import Path
base=Path(__file__).parent.resolve()
text=(base/'verify-round45-v2.mjs').read_text(encoding='utf-8')
before='        assert(desc.serialCommandPairing.every(pairing=>pairing.paired===true));'
after="""        for (const pairing of desc.serialCommandPairing) {
          if (!pairing.paired) {
            assert.equal(pairing.command,'vault_list_accounts');
            assert.equal(pairing.reason,'concurrent-calls-prevent-ordinal-pairing');
            assert.deepEqual(pairing.pairs,[]);
          }
        }
        authChecks.push({generation:gen,passwordFlows:desc.frontend.flows.length,
          completedReadOnlyAccountRequests:desc.backend.attempts.length,
          commandPairing:desc.serialCommandPairing,authenticationAttempted:false});"""
assert text.count(before)==1;text=text.replace(before,after)
before='      const ticket = await load('
assert text.count(before)==1;text=text.replace(before,'      const authChecks = [];\n'+before)
before='        recordedIdentities:[...s.first.identities,...s.warm.identities]});'
assert text.count(before)==1;text=text.replace(before,'        authenticationReads:authChecks,\n'+before)
(base/'verify-round45-v3.mjs').write_text(text,encoding='utf-8')
source=(base/'finalize-round45-verification-v2.py').read_text(encoding='utf-8')
source=source.replace('independent-v2','independent-v3').replace('verify-round45-v2.mjs','verify-round45-v3.mjs').replace('prepare-cleanup-v2','prepare-cleanup-v3')
(base/'finalize-round45-verification-v3.py').write_text(source,encoding='utf-8')
print('V3 preserves canonical concurrent-read ambiguity explicitly; forbids authentication flows and all backend kinds except completed verified accounts-refresh')
