from pathlib import Path
import json
root = Path('D:/SoloSoul')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
record = load(root/'docs/verification/rf1105-startup-auth-tail-2026-10-10.json')
assert record['accepted'] and record['archive']['readbackAllMembersVerified']
assert [len(g['samples']) for g in record['validation']['groups']] == [5,5]
assert not record['rf312Closed']
p = root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md'
s = p.read_text(encoding='utf-8-sig')
before = '- 已关闭：**289 / 300**；实际修复（已关闭）：289；排除：0；待验证/阻塞：4（RF-112、RF-121、RF-312、RF-1109）；暂缓：0；进行中：1；待执行：6。'
after = before.replace('289 / 300','290 / 300').replace('实际修复（已关闭）：289','实际修复（已关闭）：290').replace('进行中：1','进行中：0')
assert s.count(before) == 1
s = s.replace(before,after)
row = '| 295 | [RF-1105](#rf-1105) | P2 | 热启动门禁精确校验当前认证诊断尾序 | 无（RF-312当前构建热启动发现） | [~] 进行中 |'
assert s.count(row) == 1
s = s.replace(row,row.replace('[~] 进行中','[x] 完成'))
lines = s.splitlines(keepends=True)
lines[2] = '> 最后更新：2026-10-10（RF-1105 热启动认证尾序门禁修复与当前 Windows 同目录重启完成；RF-112/121/312 与 RF-1109 仍待验证）\n'
assert sum(line.startswith('- 当前处理：') for line in lines) == 1
lines = [('- 当前处理：**RF-1105已完成；当前Windows两档公开夹具各五组同目录重启验收完成。RF-121浅色窗口绑定已通过，后续深色/布局/恢复矩阵需独立场景，RF-1109首页保持待验证；RF-312历史首页根因、系统睡眠与多端仍缺证据，RF-112/121/312及RF-122～127前置保持**。\n' if line.startswith('- 当前处理：') else line) for line in lines]
s = ''.join(lines)
native = record['checks']['rf1105-rust-native']['testTotals']
default = record['checks']['rf1105-rust-default']['testTotals']
cleanup = record['cleanup']
s += f'''
### RF-1105 当前热启动的认证尾序门禁修复（2026-10-10）

- 初次当前GUI原生四份第一代证明成功，但Node要求旧两调用尾序而拒绝；修正Node后另一独立样本的第一代通过，Rust票据门禁仍拒绝。二者同一根因：现有SDK在启动读回/同文档核验后追加认证快照/同文档核验，实际为四个固定只读调用。原两轮失败（4+1个样本）及退出核验不完整记录保留，五份第一代原件离线通过不改变失败组状态。
- Node红测0通过/1失败、exit1；Rust真实重启票据红测0通过/1失败、exit101。两处精确匹配现有四调用顺序；Node和Rust反例覆盖遗漏、重复、交换和输入调用，原PID/birth/EXE、frame/loader/时钟、observer/IPC、一次性票据、真实退出、夹具与预算保持。默认产品与依赖未改。
- 修复后Node定向10通过，完整229项中228通过、0失败、1既有Windows文件symlink权限跳过；格式通过。RF-1106和RF-1107测试时序/断言修复已分别提交，当前Rust检查按六源码SHA复用已实际通过结果，原失败保持，复用来源逐字记录。默认与非默认严格Clippy exit0；原生诊断{native['passed']}通过/0失败，许可29及更新偏好15通过；默认workspace {default['passed']}通过/0失败/{default['ignored']}既有ignored。
- 实际GUI Release exit0，Windows Rust/前端/构建及94资源未变，原构建EXE字节复核一致。后续仅4份Android原生测试或外部Python诊断变更显式绑定新1830来源清单，1826份其余来源逐字不变；原构建清单和换行回执保持。Tauri仅改写Cargo.toml换行时原始回执保留，经规范化字节/TOML等价核验后恢复原换行。旧GUI和所有失败样本保持。
- 会话1重新连接后已实测Active、OpenInputDesktop成功；本任务API31模拟器和5049私有ADB停止且fresh CIM无存活。本轮100对象round4与5000对象全新round5各5/5完整启动对，共20次独立进程启动；原配置目录与Vault身份、旧原件、首次实际退出、一次性票据/消耗、两代独立文档/进程/时钟及只读认证合同均独立复核。只覆盖配置入口至可用密码登录表单和两帧，包含SDK/观测开销；不称OS冷启动或登录后热解锁，不推断旧首页超时根因。
- 另保留round4的5000对象失败组：前3组完整通过，第4组在短命WebView后代消失的快照处无法完整确认归属/内存，严格拒绝后续诊断及第5组。原清理失败保持；新的fresh CIM确认9份记录身份及本任务路径无存活后，才在全新round5目录完整重跑5组，未拼接旧部分成功样本、未改预算/谓词或绕过退出核验。
- 临时独立核验器首次误要求零后端记录，第二次误要求只读账号请求全串行，原exit1保留；按现有认证合同核验全部只读accounts-refresh均完成、rootVerified、前后端次数一致，零密码流程/零login尝试，并发情况显式记录无法顺序归因，v3 exit0。清理生成器的模板匹配失败与旧Windows PowerShell缺少Get-FileHash的exit1也保留，均发生于删除之前；随后使用同一守卫脚本与当前PowerShell7完成实际清理。
- fresh CIM核验{cleanup['identitiesChecked']}个记录身份退出，仅删除{len(cleanup['removedCachePaths'])}个本轮缓存并解除{len(cleanup['linksUnlinked'])}个联接，{len(cleanup['preservedVaultAndRootFiles'])}份Vault/根级原件及日志逐字保留。{record['archive']['memberCount']}份归档原件全部回读SHA一致，不含物理Vault、可执行文件、模型或缓存；见[修复与当前重启口径](verification/RF-1105-startup-auth-tail.md)、[结构化验收](verification/rf1105-startup-auth-tail-2026-10-10.json)。
- RF-1105按一项一修复一提交单独提交；290/300关闭、4待验证、6待执行保持。RF-312系统睡眠、多端及历史失败根因、RF-121完整原生矩阵与RF-112/122～127前置仍未关闭，整体目标继续推进。
'''
p.write_text(s,encoding='utf-8',newline='\n')
doc = f'''# RF-1105 热启动认证尾序门禁修复

2026-10-10。当前SDK启动证明包含固定认证诊断尾序，旧Node与Rust门禁仍只要求启动的两个只读调用，导致当前构建无法进入同目录重启。两处现已精确验证 `Runtime.evaluate → Page.getFrameTree → Runtime.evaluate → Page.getFrameTree`；遗漏、重复、交换或输入调用均继续拒绝。

Node红测exit1，Rust真实一次性重启票据红测exit101；修复后Node10项定向、完整228通过/0失败/1既有权限跳过，Rust原生诊断{native['passed']}通过、许可29通过、更新偏好15通过，默认workspace {default['passed']}通过/0失败/{default['ignored']}既有ignored。格式与默认/非默认严格Clippy通过，新GUI Release完成。没有改默认产品逻辑、依赖、原SDK预算或跳过退出/身份校验。

已核验Windows编译输入/EXE/94资源不变；4份仅Android测试/诊断变更显式绑定新1830来源，原清单保持。会话1已Active且输入桌面可用，专用Android模拟器与私有ADB停止。本轮100对象round4和5000对象全新round5使用原公开100/5000对象夹具，每档五组“新私有配置目录启动 → 原目录再次启动”，共20次原生启动，整组全部通过。每组均复核首次实际退出、原配置目录birth、Vault/原件字节、唯一票据/消耗及两代独立run/PID/browser/port/frame/loader/时钟；两代认证快照合同成立，没有密码输入或login后端尝试；完成的accounts-refresh只读记录与前端请求次数合同匹配，并发读取不作序号配对或跨时钟归因。

计时定义为原生配置入口至可用密码登录表单、两帧和SDK绑定；排除OS进程spawn与重启前检，包含诊断/SDK开销。这里的“热启动”仅指同一私有配置目录的进程重启，不代表OS冷缓存、登录后工作区恢复或系统睡眠恢复，不作跨日构建性能改进比较。

原两轮共五个失败样本及round3桌面准入失败保留。新增round4的5000对象组前3对成功、第4对因瞬时后代归属/内存无法完整核验而严格失败并停止第5对；其原清理不完整记录保持。fresh CIM确认9份记录身份和本任务路径无存活后，使用全新round5目录完整重跑5000对象5组，未拼接部分成功或放宽谓词。修复后离线接受它们的第一代证明，没有将原缺少重启/样本或清理核验不完整的组改为通过。清理前fresh CIM确认记录身份退出，仅删除本轮隔离缓存；测试Vault、所有启动证明、日志与旧构建保留。全部归档成员逐字回读SHA验证。

见[结构化验收](rf1105-startup-auth-tail-2026-10-10.json)及[逐字原件索引](rf1105-startup-auth-tail-2026-10-10/index.json)。RF-1105关闭；RF-312仍缺系统睡眠、多端与历史首页根因，RF-121完整材质矩阵、RF-1109首页和其他任务前置不解除。
'''
with (root/'docs/verification/RF-1105-startup-auth-tail.md').open('x',encoding='utf-8',newline='\n') as out:
    out.write(doc)
print('RF-1105 closed after complete archive gate; 290/300, remaining4+6 unchanged')
