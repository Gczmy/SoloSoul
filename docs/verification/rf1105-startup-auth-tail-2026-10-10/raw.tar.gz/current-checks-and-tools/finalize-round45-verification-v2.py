from pathlib import Path
import datetime,hashlib,json,subprocess,time
root=Path('D:/SoloSoul');base=Path(__file__).parent.resolve()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=load(base/'sources-round4.json')
def verify():
 for name,digest in sources.items():assert sha(root/name)==digest,name
def run(name,command):
 verify();start=time.monotonic()
 with (base/(name+'.stdout.log')).open('xb') as out,(base/(name+'.stderr.log')).open('xb') as err:
  result=subprocess.run(command,cwd=root/'tauri',stdin=subprocess.DEVNULL,stdout=out,stderr=err,
      creationflags=subprocess.CREATE_NO_WINDOW)
 verify()
 (base/(name+'.receipt.json')).write_text(json.dumps(dict(command=command,exitCode=result.returncode,
     elapsedSeconds=time.monotonic()-start,sourceFiles=sources,sourceUnchanged=True,
     at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n',encoding='utf-8')
 print(f'{name} exit {result.returncode}',flush=True);assert result.returncode==0,name
assert load(base/'round4/startup-100.receipt.json')['exitCode']==0
assert load(base/'round5/startup-5000.receipt.json')['exitCode']==0
assert load(base/'round4/startup-5000.receipt.json')['exitCode']==1
run('rf1105-round45-independent-v2',['node',str(base/'verify-round45-v2.mjs'),'--round45'])
text=(base/'prepare-cleanup-all.py').read_text(encoding='utf-8')
text=text.replace("'validation.json'","'validation-round45.json'").replace("'rf1105-current-independent.receipt.json'","'rf1105-round45-independent-v2.receipt.json'")
before="assert [g['expectedSamples'] for g in groups] == [4,1,5,5]"
assert text.count(before)==1
after="""new_failed = load(stage/'round4/samples5000/report.json')
assert new_failed['summary']['complete'] is False and len(new_failed['samples']) == 4
assert [s['success'] for s in new_failed['samples']] == [True, True, True, False]
exit_check = load(stage/'round4-sample004-fresh-exit-check.json')
assert exit_check['matchingRecordedIdentitiesLive'] == exit_check['matchingTaskPathProcessesLive'] == 0
samples=[]
for sample in new_failed['samples']:
    identities=list(sample['first']['identities'])
    if sample.get('warm'):identities+=sample['warm']['identities']
    samples.append({'index':sample['index'],'root':sample['root'],'runId':sample['owned']['runId'],
        'recordedIdentities':identities,'originalNativeAccepted':sample['success']})
groups.append({'root':str(stage/'round4/samples5000'),'objects':5000,'expectedSamples':4,
    'originalNativeGroupAccepted':False,'cacheCleanupEligible':True,'samples':samples})
assert [g['expectedSamples'] for g in groups] == [4,1,5,5,4]"""
text=text.replace(before,after)
text=text.replace('validation.groups.Count -ne 4','validation.groups.Count -ne 5')
text=text.replace('targets.Count -ne 120 -or @($targets | Sort-Object -Unique).Count -ne 120',
    'targets.Count -ne 152 -or @($targets | Sort-Object -Unique).Count -ne 152')
text=text.replace('Exact one hundred twenty owned cache paths required','Exact one hundred fifty two owned cache paths required')
text=text.replace("(Join-Path $stageRoot 'after-rf1106\\\\round3\\\\samples100') = 5", "(Join-Path $stageRoot 'after-rf1106\\\\round4\\\\samples100') = 5")
before="(Join-Path $stageRoot 'after-rf1106\\\\round3\\\\samples5000') = 5"
after="(Join-Path $stageRoot 'after-rf1106\\\\round5\\\\samples5000') = 5\n    (Join-Path $stageRoot 'after-rf1106\\\\round4\\\\samples5000') = 4"
assert text.count(before)==1;text=text.replace(before,after)
text=text.replace("'cleanup-owned-all.ps1'","'cleanup-owned-round45-all.ps1'")
text=text.replace('Prepared four terminal groups, fifteen exact owned samples, 120 bounded candidate cache paths',
    'Prepared five terminal groups, nineteen exact owned samples, 152 bounded candidate cache paths')
(base/'prepare-cleanup-round45.py').write_text(text,encoding='utf-8')
run('rf1105-round45-prepare-cleanup-v2',['python','-X','utf8',str(base/'prepare-cleanup-round45.py')])
print('Round4 100 and whole round5 5000 groups independently verified; failed round4 retained; bounded cleanup prepared',flush=True)
