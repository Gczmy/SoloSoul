from pathlib import Path
base=Path(__file__).parent.resolve()
text=(base/'archive-complete.py').read_text(encoding='utf-8')
replacements=[
 ("sources = load(stage/'sources-fixed.json')","sources = load(stage/'sources-round4.json')"),
 ("'rf1105-current-warm-groups','rf1105-current-independent'","'rf1105-round4-independent'"),
 ("stage/'round3'","stage/'round4'"),
 ("stage/'round3/samples100'","stage/'round4/samples100'"),
 ("stage/'round3/samples5000'","stage/'round4/samples5000'"),
 ("'# Keep original evidence bytes.\\n* -text\\n'","'# Keep original evidence bytes.\\n* -text -diff\\n'"),
 ("'checks':checks,'runtime':package,'validation':validation,","'checks':checks,'runtime':package,'validation':validation,\n    'currentSourceFiles':sources,'round4SourceProvenance':load(stage/'round4-source-provenance.json'),\n    'currentGroupReceipts':[load(stage/'round4'/f'startup-{size}.receipt.json') for size in [100,5000]],")]
for before,after in replacements:
 assert text.count(before)==1,(before,text.count(before));text=text.replace(before,after)
before="for folder in [initial_stage/'round2',stage/'round4']:"
assert text.count(before)==1
text=text.replace(before,"for folder in [initial_stage/'round2',stage/'round3',stage/'round4']:")
before="original = load(root/'build/rf121-theme-binding-20261010/sources-applied.json')"
assert text.count(before)==1
extra="""context=root/'build/android-native-feasibility-20261010'
for relative in ['verify-session-20261010-2228-connected.json','api31-swangle-round1/boot.receipt.json',
    'api31-swangle-round1/owned-stop-before-windows.json','session2-dispatch-probe-round1/dispatch-receipt.json',
    'session2-dispatch-probe-round1/target-session-state.json']:
    add(context/relative,'session-and-device-context/'+relative)
"""
text=text.replace(before,extra+before)
(base/'archive-round4-complete.py').write_text(text,encoding='utf-8')
print('Prepared raw-byte archive for independently verified round4; original round3 desktop failure retained')
