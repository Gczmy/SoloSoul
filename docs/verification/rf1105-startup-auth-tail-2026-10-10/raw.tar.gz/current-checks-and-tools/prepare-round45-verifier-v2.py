from pathlib import Path
base=Path(__file__).parent.resolve()
text=(base/'verify-round45.mjs').read_text(encoding='utf-8')
before='        assert.equal(desc.backend.attempts.length,0);'
after="""        // Startup reads accounts, while password flows/login attempts remain absent.
        assert(auth.frontend.replies.every(r=>r.command==='vault_list_accounts' && r.status==='tauri-ok'));
        assert.equal(desc.backend.attempts.length,auth.frontend.replies.length);
        assert(desc.backend.attempts.every(a=>a.kind==='accounts-refresh' && a.outcome==='completed' && a.rootVerified===true));
        assert(desc.serialCommandPairing.every(pairing=>pairing.paired===true));"""
assert text.count(before)==1;text=text.replace(before,after)
(base/'verify-round45-v2.mjs').write_text(text,encoding='utf-8')
source=(base/'finalize-round45-verification.py').read_text(encoding='utf-8')
source=source.replace("'rf1105-round45-independent'","'rf1105-round45-independent-v2'").replace("'verify-round45.mjs'","'verify-round45-v2.mjs'")
source=source.replace("'rf1105-round45-independent.receipt.json'","'rf1105-round45-independent-v2.receipt.json'")
source=source.replace("'rf1105-round45-prepare-cleanup'","'rf1105-round45-prepare-cleanup-v2'")
(base/'finalize-round45-verification-v2.py').write_text(source,encoding='utf-8')
print('Original offline rejection preserved; v2 requires only completed accounts-refresh reads, no password flow/login, and exact canonical frontend/backend pairing')
