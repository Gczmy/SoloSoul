from pathlib import Path
import hashlib,json,datetime
root=Path('D:/SoloSoul');base=Path(__file__).parent.resolve()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
original=load(base/'sources-fixed.json')
current={name:sha(root/name) for name in original}
changed={name:dict(before=original[name],after=digest) for name,digest in current.items() if original[name]!=digest}
expected={
 'tauri/scripts/android-home-native-regression.py',
 'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidCardSurfaceInstrumentedTest.kt',
 'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidHomeInstrumentedTest.kt',
 'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt'}
assert set(changed)==expected,changed
assert len(original)==len(current)==1830
build=load(base/'rf1105-native-release-build.receipt.json');assert build['exitCode']==0
package=load(base/'runtime-new.json');assert sha(Path(package['exe']))==package['sha256']
for row in package['resources']:
 assert sha(Path(row['copy']))==sha(Path(row['source']))==row['sha256']
for task,slug in [('RF-1108','rf1108-android-card-visual-state-2026-10-10'),('RF-1109','rf1109-android-neutral-text-2026-10-10'),('RF-1110','rf1110-android-diagnostic-utf8-2026-10-10')]:
 evidence=load(root/'docs/verification'/(slug+'.json'));assert evidence['task']==task
 for name in expected:
  if name in evidence.get('sourceFiles',{}) and task=='RF-1110':assert evidence['sourceFiles'][name]==current[name]
(base/'sources-round4.json').write_text(json.dumps(current,indent=2)+'\n',encoding='utf-8')
(base/'round4-source-provenance.json').write_text(json.dumps(dict(
 sourceManifestParentSha256=sha(base/'sources-fixed.json'),sourceManifestSha256=sha(base/'sources-round4.json'),
 sourceCount=1830,changedAndroidTestOrExternalDriverFiles=changed,
 unchangedFilesCount=1826,windowsRustFrontendBuildAndResourceInputsUnchanged=True,
 actualWindowsBuildReceiptSha256=sha(base/'rf1105-native-release-build.receipt.json'),
 actualWindowsBuildExitCode=0,exeSha256=package['sha256'],resourceCount=94,
 reusedBinary=True,reason='Only Android instrumented-test Kotlin and external Android diagnostic Python changed; none is compiled or packaged in this Windows runtime.',
 originalSourcesManifestRetained=True,at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n',encoding='utf-8')
source=(base/'run-new-build.py').read_text(encoding='utf-8')
assert source.count("stage = Path(__file__).parent / 'round3'")==1
source=source.replace("stage = Path(__file__).parent / 'round3'","stage = Path(__file__).parent / 'round4'")
assert source.count("'sources-fixed.json'")==2
source=source.replace("'sources-fixed.json'","'sources-round4.json'")
(base/'run-round4-current.py').write_text(source,encoding='utf-8')
verifier=(base/'verify-fixed.mjs').read_text(encoding='utf-8')
assert '--round3' in verifier and "path.join(stage,'round3')" in verifier
verifier=verifier.replace('--round3','--round4').replace("path.join(stage,'round3')","path.join(stage,'round4')")
(base/'verify-round4.mjs').write_text(verifier,encoding='utf-8')
print('Round4 strict original 1830-source guard retained; four Android-only changes bound explicitly; Windows exe/resources unchanged',flush=True)
