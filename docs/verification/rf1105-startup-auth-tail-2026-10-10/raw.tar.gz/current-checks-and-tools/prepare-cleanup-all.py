from pathlib import Path
import json
stage = Path(__file__).parent
original = stage.parent
root = Path('D:/SoloSoul')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
positive = load(stage/'validation.json')
failed = load(stage/'failed-offline-validation.json')
assert positive['accepted'] and len(positive['groups']) == 2
assert not failed['accepted'] and failed['firstProofsAcceptedOffline'] == 5
assert load(stage/'rf1105-current-independent.receipt.json')['exitCode'] == 0
assert load(original/'startup-100.receipt.json')['exitCode'] == 1
assert load(original/'round2/startup-100.receipt.json')['exitCode'] == 1
groups = []
for group in failed['groups']:
    groups.append({'root':group['root'],'objects':100,'expectedSamples':len(group['samples']),
        'originalNativeGroupAccepted':False,'cacheCleanupEligible':True,'samples':group['samples']})
for group in positive['groups']:
    groups.append({'root':group['root'],'objects':group['objects'],'expectedSamples':5,
        'originalNativeGroupAccepted':True,'cacheCleanupEligible':True,'samples':group['samples']})
assert [g['expectedSamples'] for g in groups] == [4,1,5,5]
with (stage/'cleanup-plan.json').open('x',encoding='utf-8',newline='\n') as out:
    out.write(json.dumps({'scope':'exact owned cache cleanup only','accepted':True,
        'applicationAcceptance':False,'groups':groups},indent=2)+'\n')
text = (root/'build/rf312-home-memory-20261010/cleanup-owned.ps1').read_text()
replacements = [
    (r"'D:\SoloSoul\build\rf312-home-memory-20261010'",r"'D:\SoloSoul\build\rf312-warm-current-20261010'"),
    ("'validation.json'",r"'after-rf1106\cleanup-plan.json'"),
    ('validation.groups.Count -ne 2','validation.groups.Count -ne 4'),
    (r"'D:\SoloSoul\build\rf1104-update-preferences-20261010\bin\solo_soul.exe'",r"'D:\SoloSoul\build\rf312-warm-current-20261010\after-rf1106\ss-rf1105-runtime\bin\solo_soul.exe'"),
    ('if (-not $group.complete -or $group.samples.Count -ne 5)', 'if (-not $group.cacheCleanupEligible -or $group.samples.Count -ne $group.expectedSamples)'),
    ("$sampleRoot = Join-Path (Join-Path $stageRoot ('samples' + $group.objects))", "$sampleRoot = Join-Path $group.root"),
    ("'application-logs\\' + $group.objects + '\\sample-'", "'application-logs\\' + [IO.Path]::GetRelativePath($stageRoot,$group.root) + '\\sample-'"),
    ('targets.Count -ne 80 -or @($targets | Sort-Object -Unique).Count -ne 80','targets.Count -ne 120 -or @($targets | Sort-Object -Unique).Count -ne 120'),
    ('Exact eighty owned cache paths required','Exact one hundred twenty owned cache paths required'),
    ("task='RF-312'","task='RF-1105'"),
]
for before,after in replacements:
    assert text.count(before) == 1,(before,text.count(before))
    text = text.replace(before,after)
old = "    return [IO.Path]::GetFullPath($value).TrimEnd('\\')"
assert text.count(old) == 1
text = text.replace(old,"    $full = [IO.Path]::GetFullPath($value)\n    if ($full -eq [IO.Path]::GetPathRoot($full)) { return $full }\n    return $full.TrimEnd('\\')")
failed_script = (root/'build/rf121-theme-binding-20261010/cleanup-failed-owned.ps1').read_text()
plain = failed_script[failed_script.index('function PlainAncestors'):failed_script.index('PlainAncestors $stageRoot')]
text = text.replace('$targets = [Collections.Generic.List[string]]::new()',plain+'PlainAncestors $stageRoot\n$targets = [Collections.Generic.List[string]]::new()')
text = text.replace('        RequireBelow $sampleRoot $stageRoot','        PlainAncestors $sampleRoot\n        RequireBelow $sampleRoot $stageRoot')
text = text.replace('            RequireBelow $expectedPath (Join-Path $packageBase $parentName)', '            PlainAncestors $expectedPath\n            RequireBelow $expectedPath (Join-Path $packageBase $parentName)')
text = text.replace('            $preserved.Add([ordered]@', "            if ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Root proof is a link' }\n            $preserved.Add([ordered]@")
allowed = '''$expectedGroups = @{
    (Join-Path $stageRoot 'samples100') = 4
    (Join-Path $stageRoot 'round2\\samples100') = 1
    (Join-Path $stageRoot 'after-rf1106\\round3\\samples100') = 5
    (Join-Path $stageRoot 'after-rf1106\\round3\\samples5000') = 5
}
$oldLive = @(Get-CimInstance Win32_Process -Filter "Name = 'solo_soul.exe'" | Where-Object ExecutablePath -EQ 'D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\ss-rf121-runtime\\bin\\solo_soul.exe')
if ($oldLive.Count) { throw 'Original frozen test application is still live' }
'''
text = text.replace('$packageBase = ',allowed+'$packageBase = ')
text = text.replace('foreach ($group in $validation.groups) {', "foreach ($group in $validation.groups) {\n    $groupPath = NormalPath $group.root\n    if (-not $expectedGroups.ContainsKey($groupPath) -or $expectedGroups[$groupPath] -ne $group.samples.Count) { throw 'Fixed group path/count mismatch' }\n    RequireBelow $groupPath $stageRoot\n    PlainAncestors $groupPath")
with (stage/'cleanup-owned-all.ps1').open('x',encoding='utf-8',newline='\n') as out: out.write(text)
print('Prepared four terminal groups, fifteen exact owned samples, 120 bounded candidate cache paths')
