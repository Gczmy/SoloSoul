from pathlib import Path
import json,datetime
base=Path(__file__).parent.resolve()
red=json.loads((base/'rf1105-rust-red.receipt.json').read_text(encoding='utf-8-sig'))['sourceFiles']
assert set(red)=={'tauri/src-tauri/src/native_perf/startup.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs'},set(red)
text=(base/'archive-round45-final.py').read_text(encoding='utf-8')
before='    assert sha(rust_red) == red[name],name\n    members[\'source-rust-red/\'+name] = rust_red'
after="""    if name not in red:
        assert name.endswith('.mjs'),name
        continue
    assert sha(rust_red) == red[name],name
    members['source-rust-red/'+name] = rust_red"""
assert text.count(before)==1;text=text.replace(before,after)
(base/'archive-round45-final-v2.py').write_text(text,encoding='utf-8')
(base/'archive-round45-original-failure.json').write_text(json.dumps(dict(
 accepted=False,errorType='KeyError',missingKey='tauri/scripts/native-perf-startup.mjs',
 source='archive-round45-final.py',scope='Raw archive assembly before any archive/report/index write',
 actualRustRedBoundSources=list(red),archiveCreated=False,stagedFiles=0,
 reason='Rust red receipt binds only the two Rust sources; Node before/after has separate provenance.',
 at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n',encoding='utf-8')
print('Original archive rejection recorded; exact red Rust bindings retained; Node before/after provenance remains separate')
