from pathlib import Path
import ast, hashlib, json, subprocess
w=Path(__file__).parent
changes={}
def save(name,text):
    with (w/name).open('x',encoding='utf8',newline='\n') as f:f.write(text)
    changes[name]=hashlib.sha256(text.encode()).hexdigest()
text=(w/'verify-after-picker-sdk-only-cleanup.mjs').read_text(encoding='utf8')
text=text.replace('rf121-backdrop-checks-after-picker-20261011','rf1122-native-build-20261011').replace('${mode}-after-picker-20261011','${mode}-rf1122-20261011')
save('verify-rf1122-sdk-only-cleanup.mjs',text)
text=(w/'verify-rf1122-backdrop.mjs').read_text(encoding='utf8')
anchor='for(const sample of journey.samples){'
assert text.count(anchor)==1
text=text.replace(anchor,"assert.equal(mode,'dark-expanded');\nconst failedReader=await load(path.join(stage,'rf1122-native-build-20261011/verify-dark-expanded.receipt.json'));assert.equal(failedReader.exitCode,1);\nconst originalQueue=await load(path.join(stage,'rf1122-native-build-20261011/cohorts-complete.json'));assert.equal(originalQueue.success,false);\nfor(const sample of journey.samples.filter(s=>s.index!==2)){")
assert text.count('size,3);')==1
text=text.replace('size,3);','size,2);').replace('accepted:true,samples,sourceFiles','accepted:false,bindingSubsetVerified:true,samples,sourceFiles').replace("'validation.json'","'partial-two-bindings.json'").replace('Three complete native journeys and three exact state/pixel bindings independently verified','Only sample 1/3 state/pixel bindings independently verified; original whole-cohort failure preserved')
save('verify-rf1122-dark-two-bindings.mjs',text)
text=(w/'render-after-picker-dark-two-bindings.py').read_text(encoding='utf8').replace('-after-picker-20261011','-rf1122-20261011')
ast.parse(text)
save('render-rf1122-dark-two-bindings.py',text)
for n in ['verify-rf1122-sdk-only-cleanup.mjs','verify-rf1122-dark-two-bindings.mjs']:
    p=subprocess.run(['node','--check',str(w/n)],capture_output=True)
    assert p.returncode==0,p.stderr
with (w/'rf1122-mixed-readers-preparation.json').open('x',encoding='utf8') as f:json.dump(dict(outputs=changes,partialReaderKeepsEverySelectedBindingGuard=True,partialIndices=[1,3],originalFourQueueAccepted=False,sdkReaderCleanupOnly=True,executed=False),f,indent=2)
print('Mixed readers syntax checked; no appearance guard weakened; original failed sample excluded only from explicitly partial result',flush=True)
