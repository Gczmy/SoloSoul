"""Build the current, isolated native-perf application; retain actual receipts."""
from pathlib import Path
import ctypes,ctypes.wintypes as wt,datetime,hashlib,json,os,re,shutil,struct,subprocess,time,tomllib
root=Path('D:/SoloSoul');w=Path(__file__).parent;s=w/'rf1122-native-build-20261011';cache=root/'build/rf312-maintenance-20261009'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def save(n,v):
    with (s/n).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
s.mkdir(exist_ok=False)
parent=load(w/'rf1121-checks-20261011/green-sources.json');sources={n:sha(root/n) for n in parent}
assert len(sources)==1834
assert {n for n,h in sources.items() if h!=parent[n]}=={'tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs'}
save('sources.json',sources)
def verify():
    changes=[n for n,h in sources.items() if sha(root/n)!=h]
    return changes
def session():
    k=ctypes.WinDLL('kernel32',use_last_error=True);u=ctypes.WinDLL('user32',use_last_error=True);a=ctypes.WinDLL('wtsapi32',use_last_error=True)
    k.ProcessIdToSessionId.argtypes=[wt.DWORD,ctypes.POINTER(wt.DWORD)];k.ProcessIdToSessionId.restype=wt.BOOL;k.WTSGetActiveConsoleSessionId.restype=wt.DWORD
    u.OpenInputDesktop.argtypes=[wt.DWORD,wt.BOOL,wt.DWORD];u.OpenInputDesktop.restype=wt.HANDLE;u.CloseDesktop.argtypes=[wt.HANDLE];u.CloseDesktop.restype=wt.BOOL
    a.WTSQuerySessionInformationW.argtypes=[wt.HANDLE,wt.DWORD,ctypes.c_int,ctypes.POINTER(wt.LPWSTR),ctypes.POINTER(wt.DWORD)];a.WTSQuerySessionInformationW.restype=wt.BOOL;a.WTSFreeMemory.argtypes=[wt.LPVOID]
    sid=wt.DWORD();assert k.ProcessIdToSessionId(os.getpid(),ctypes.byref(sid));buf=wt.LPWSTR();size=wt.DWORD()
    assert a.WTSQuerySessionInformationW(None,sid.value,8,ctypes.byref(buf),ctypes.byref(size))
    try:assert size.value==4;state=ctypes.cast(buf,ctypes.POINTER(ctypes.c_int)).contents.value
    finally:a.WTSFreeMemory(buf)
    desktop=u.OpenInputDesktop(0,False,1);available=bool(desktop)
    if desktop:assert u.CloseDesktop(desktop)
    result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),callerSessionId=sid.value,activeConsoleSessionId=k.WTSGetActiveConsoleSessionId(),connectionState=state,connectionStateName=['Active','Connected','ConnectQuery','Shadow','Disconnected','Idle','Listen','Reset','Down','Init'][state],inputDesktopAvailable=available,pixelsRead=0,inputEventsSent=0,systemSettingsChanged=False)
    save('session-before-build.json',result);print(json.dumps(result),flush=True)
    assert state==0 and available,'No interactive caller desktop; refuse GUI acceptance'
session()
save('starting-state.json',dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),sourceCount=len(sources),driverSha256=sha(Path(__file__)),scope='RF-121 current native build; no material acceptance'))
env=os.environ.copy();env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),CARGO_HOME=str(cache/'cargo-home'),CARGO_TARGET_DIR=str(cache/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(cache/'ort-cache'),npm_config_cache=str(cache/'npm-cache'))
env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','')
for n in ['PDFIUM_LIBRARY_PATH','TAURI_CONFIG','TAURI_ANDROID_PROJECT_PATH','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS']:env.pop(n,None)
def run(name,cmd,e):
    assert not verify();began=time.monotonic()
    with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=root/'tauri',env=e,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()));print(name+' live PID '+str(p.pid),flush=True);code=p.wait()
    changed=verify();save(name+'.receipt.json',dict(pid=p.pid,command=cmd,exitCode=code,elapsedSeconds=time.monotonic()-began,sourceUnchanged=not changed,changedSources=changed,temp=e['TEMP'],targetDirectory=e['CARGO_TARGET_DIR']))
    print(name+' terminal '+str(code),flush=True);return code,changed
denv=env.copy();denv['PDFIUM_LIBRARY_PATH']=str(root/'tauri/src-tauri/resources/pdfium/pdfium.dll')
green=w/'rf1122-green-checks-20261011'
assert load(green/'sources.json')==sources
for name in ['workspace-fmt','native-clippy','native-tests']:
    receipt=load(green/(name+'.receipt.json'));assert receipt['exitCode']==0 and receipt['sourceUnchanged']
    shutil.copy2(green/(name+'.receipt.json'),s/(name+'.receipt.json'))
assert '132 passed; 0 failed; 0 ignored;' in (green/'native-tests.stdout.log').read_text(encoding='utf8')
manifest=root/'tauri/src-tauri/Cargo.toml';before=manifest.read_bytes();(s/'build-Cargo-before.toml').write_bytes(before)
code,changed=run('native-release-build',['npm.cmd','run','tauri','--','build','--config','src-tauri/tauri.native-perf.conf.json','--features','native-perf','--no-bundle','--ci'],env)
after=manifest.read_bytes();(s/'build-Cargo-after.toml').write_bytes(after)
if changed:
    assert changed==['tauri/src-tauri/Cargo.toml'] and before.replace(b'\r\n',b'\n')==after.replace(b'\r\n',b'\n')
    assert tomllib.loads(before.decode())==tomllib.loads(after.decode())
    save('build-manifest-newline-parity.json',dict(rawReceiptSourceUnchanged=False,normalizedBytesEqual=True,parsedTomlEqual=True,beforeSha256=hashlib.sha256(before).hexdigest(),afterSha256=hashlib.sha256(after).hexdigest(),action='Restore original newline bytes only; preserve raw build receipt'))
    manifest.write_bytes(before)
assert code==0 and not verify()
runtime=w/'ss-rf1122-backdrop-runtime-20261011/bin';runtime.mkdir(parents=True,exist_ok=False);exe=runtime/'solo_soul.exe';shutil.copy2(cache/'cargo-target/release/solo_soul.exe',exe)
data=exe.read_bytes();offset=struct.unpack_from('<I',data,0x3c)[0];assert data[offset:offset+4]==b'PE\0\0' and struct.unpack_from('<H',data,offset+24+68)[0]==2
for marker in [b'windows-native-surface-before',b'windows-native-surface-after',b'windows-native-auth-attribution',b'windows-native-maintenance-admission']:assert marker in data,marker
old=load(w/'rf121-backdrop-checks-after-picker-20261011/runtime-package.json');assert sha(exe)!=old['sha256'];rows=[]
for item in old['resources']:
    source=Path(item['source']);relative=Path(item['copy']).relative_to(Path(old['exe']).parent);copy=runtime/relative
    assert copy.resolve().is_relative_to(runtime.resolve()) and sha(source)==item['sha256']
    copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,copy);assert sha(copy)==item['sha256'];rows.append(dict(source=str(source),copy=str(copy),sha256=item['sha256']))
assert len(rows)==94
helper_stage=w/'helper-backdrop-reader-candidate-20261011';prepared=load(helper_stage/'prepared.json');foreground=load(helper_stage/'foreground-helper-prepared.json')
helper=w/'helper-target-readable/debug/rf121-wgc-backdrop-candidate.exe';hs=helper_stage/'src/main.rs';activation=Path(foreground['exe']);acs=Path(foreground['source'])
assert sha(helper)=='815a706fbb74f99b6a4d9c1095cb4a98d26fa8f3bbe813870db2ef1cfae8330a' and sha(hs)=='920b2a891fb3eda0aece6d9e6ebfc7d46cd018c13dcd3d20294d81a25261d26f'
assert sha(activation)==foreground['binarySha256'] and sha(acs)==foreground['sourceSha256']
drivers=load(helper_stage/'activation-drivers-prepared.json');assert all(sha(w/n)==h for n,h in drivers['currentCandidates'].items())
package=dict(exe=str(exe),sha256=sha(exe),bytes=len(data),windowsGuiSubsystem=2,resources=rows,helperExe=str(helper),helperSha256=sha(helper),helperSource=str(hs),helperSourceSha256=sha(hs),helperMetadataVersion=3,activationExe=str(activation),activationSha256=sha(activation),activationSource=str(acs),activationSourceSha256=sha(acs),sourceManifestSha256=sha(s/'sources.json'),gitHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),guiExecuted=False,applicationMaterialAccepted=False,nativeContractTestsReceipt='native-tests.receipt.json',currentNativeTests=132)
save('runtime-package.json',package);assert not verify();print('Current GUI and helpers frozen; 94 resources/source1834 verified. No GUI acceptance yet.',flush=True)
