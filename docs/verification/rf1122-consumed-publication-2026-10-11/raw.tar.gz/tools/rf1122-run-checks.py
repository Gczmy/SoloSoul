from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
r=Path('D:/SoloSoul');w=Path(__file__).parent;phase=sys.argv[1];assert phase in ['red','green']
s=w/('rf1122-'+phase+'-checks-20261011');s.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):(s/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
sources={n:sha(r/n) for n in load(w/'rf121-backdrop-checks-after-picker-20261011/sources.json')}
save('sources.json',sources)
for n in ['tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs']:(s/Path(n).name).write_bytes((r/n).read_bytes())
cache=r/'build/rf312-maintenance-20261009';env=os.environ.copy();env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),CARGO_HOME=str(cache/'cargo-home'),CARGO_TARGET_DIR=str(cache/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(cache/'ort-cache'),PDFIUM_LIBRARY_PATH=str(r/'tauri/src-tauri/resources/pdfium/pdfium.dll'))
env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','')
for n in ['TAURI_CONFIG','TAURI_ANDROID_PROJECT_PATH','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS']:env.pop(n,None)
def run(name,args):
    start=time.monotonic();cmd=['cargo',*args]
    with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=r/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',dict(pid=p.pid,command=cmd));print(name+' live '+str(p.pid),flush=True);code=p.wait()
    changed=[n for n,h in sources.items() if sha(r/n)!=h]
    save(name+'.receipt.json',dict(command=cmd,exitCode=code,elapsedSeconds=time.monotonic()-start,sourceUnchanged=not changed,changedSources=changed,at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    print(name+' terminal '+str(code),flush=True);assert not changed
    return code
if phase=='red':
    code=run('publication-tests',['test','--locked','-p','solo_soul','--lib','--features','native-perf','native_perf::preflight_tests::consumed_publication','--','--nocapture'])
    assert code==101
    raw=(s/'publication-tests.stdout.log').read_text(encoding='utf8');assert '1 passed; 2 failed; 0 ignored;' in raw
else:
    assert run('workspace-fmt',['fmt','--all','--check'])==0
    assert run('native-clippy',['clippy','--locked','-p','solo_soul','--all-targets','--features','native-perf','--','-D','warnings'])==0
    assert run('native-tests',['test','--locked','-p','solo_soul','--lib','--features','native-perf','native_perf::','--','--nocapture'])==0
    assert '132 passed; 0 failed; 0 ignored;' in (s/'native-tests.stdout.log').read_text(encoding='utf8')
    assert run('workspace-clippy',['clippy','--locked','--','-D','warnings'])==0
    assert run('workspace-tests',['test','--locked','--verbose'])==0
print('RF-1122 '+phase+' complete',flush=True)
