from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
w=Path(__file__).parent;s=w/'rf1122-native-build-20261011';root=w.parent.parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=load(s/'sources.json');assert len(manifest)==1834
assert all(sha(root/n)==h for n,h in manifest.items())
assert not load(s/'cohorts-complete.json')['success']
assert not load(s/'dark-collapsed-followup.json')['subsetSuccess']
name='verify-dark-collapsed-sdk-cleanup';cmd=['node',str(w/'verify-rf1122-sdk-only-cleanup.mjs'),'dark-collapsed']
env=os.environ.copy();env.update(TEMP=str(s),TMP=str(s));start=time.monotonic()
with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
    p=subprocess.run(cmd,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
with (s/(name+'.receipt.json')).open('x',encoding='utf8') as f:json.dump(dict(command=cmd,exitCode=p.returncode,elapsedSeconds=time.monotonic()-start),f,indent=2)
assert p.returncode==0,p.returncode
assert all(sha(root/n)==h for n,h in manifest.items())
groups=[]
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
    c=w/f'ss-rf121-composed-window-backdrop-{mode}-rf1122-20261011'
    assert load(c/'actual100.receipt.json')['exitCode']==0
    full=mode in ['baseline','light-collapsed']
    path=c/('validation.json' if full else 'sdk-only-mixed-cleanup-validation.json');v=load(path)
    assert len(v['samples'])==3
    if full:assert v['accepted'] and v['nativeSystemBackdropVerified']
    else:assert not v['accepted'] and v['cleanupOnly'] and v['journeysOnlyAccepted']
    groups.append(dict(label=mode,captureRoot=str(c),terminal=True,samples=v['samples'],readerPath=str(path),readerSha256=sha(path),readerScope='complete independent binding' if full else 'SDK-only cleanup; appearance rejected'))
with (w/'rf1122-mixed-cache-cleanup-plan.json').open('x',encoding='utf8') as f:json.dump(dict(cacheCleanupEligible=True,failedSamplesAccepted=False,fullMaterialMatrixAccepted=False,groups=groups,plannedExactCacheTargets=96,originalFourQueueAccepted=False,darkCollapsedAppearanceAccepted=False,freshCimRequiredBeforeDeletion=True),f,indent=2)
text=(w/'rf1122-cleanup-owned.ps1').read_text(encoding='utf8').replace('rf1122-backdrop-cache-cleanup','rf1122-mixed-cache-cleanup').replace('Four terminal independently verified owned groups','Four terminal SDK-verified owned groups').replace('application-logs-rf1122-backdrop','application-logs-rf1122-mixed')
with (w/'rf1122-mixed-cleanup-owned.ps1').open('x',encoding='utf8',newline='\n') as f:f.write(text)
c=w/'ss-rf121-composed-window-backdrop-dark-expanded-rf1122-20261011'
v=load(c/'partial-two-bindings.json');images=load(c/'rendered-captures.json')
assert not v['accepted'] and v['bindingSubsetVerified'] and [x['index'] for x in images]==[1,3]
for x in images:assert sha(Path(x['png']))==x['pngSha256']
with (c/'partial-visual-review.json').open('x',encoding='utf8') as f:json.dump(dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),actualImagesInspected=2,indices=[1,3],images=images,notes='实际查看两张深色展开截图，文字、卡片、侧栏与顶部栏边界可见，OCR及备份提示保留。样本2额外偏好写入未通过计数，整组保持失败。',fullMatrixAccepted=False,wholeCohortAccepted=False),f,indent=2,ensure_ascii=False)
print('Four SDK groups terminal; 96 exact owned cache targets planned. Both dark appearance groups remain rejected.',flush=True)
