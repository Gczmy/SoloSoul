from pathlib import Path
import ast,hashlib,json,subprocess
w=Path(__file__).parent;old='rf121-backdrop-checks-after-picker-20261011';new='rf1122-native-build-20261011'
changes={'run-rf121-backdrop-after-picker.py':'run-rf1122-backdrop.py','verify-rf121-backdrop-after-picker.mjs':'verify-rf1122-backdrop.mjs','render-rf121-backdrop-after-picker.py':'render-rf1122-backdrop.py','run-backdrop-after-picker-queue.py':'run-rf1122-backdrop-queue.py'}
hashes={}
for original,target in changes.items():
    p=w/original;text=p.read_text(encoding='utf8').replace(old,new).replace('-after-picker-20261011','-rf1122-20261011')
    if original=='run-backdrop-after-picker-queue.py':
        for a,b in changes.items():text=text.replace(a,b)
        text=text.replace("'rf121-backdrop-after-picker-session-before-'","'rf1122-backdrop-session-before-'")
        anchor="assert package['priorFailedNativeTestsPreserved'] and load(s/'native-contract-tests.receipt.json')['exitCode']==101";assert text.count(anchor)==1
        text=text.replace(anchor,"assert package['currentNativeTests']==132  # This new source has its own full successful native suite.")
    if target.endswith('.py'):ast.parse(text)
    with (w/target).open('x',encoding='utf8') as f:f.write(text)
    hashes[target]=dict(original=original,originalSha256=hashlib.sha256(p.read_bytes()).hexdigest(),newSha256=hashlib.sha256((w/target).read_bytes()).hexdigest())
v=subprocess.run(['node','--check',str(w/'verify-rf1122-backdrop.mjs')],capture_output=True);assert v.returncode==0
with (w/'rf1122-cohorts-preparation.json').open('x',encoding='utf8') as f:json.dump(dict(drivers=hashes,nodeSyntaxExitCode=0,fullGuardLogicChanged=False,fullFourCohortsRequired=True,executed=False),f,indent=2)
print('Current-source cohort tools prepared; full verification gates retained')
