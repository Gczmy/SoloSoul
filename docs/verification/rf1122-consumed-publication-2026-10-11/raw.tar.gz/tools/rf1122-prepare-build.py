from pathlib import Path
import ast,hashlib,json
w=Path(__file__).parent;original=w/'run-backdrop-current-build.py';text=original.read_text(encoding='utf8')
text=text.replace("s=w/'rf121-backdrop-checks-20261011'","s=w/'rf1122-native-build-20261011'")
old='assert sources==parent and len(sources)==1834';assert text.count(old)==1
text=text.replace(old,"assert len(sources)==1834\nassert {n for n,h in sources.items() if h!=parent[n]}=={'tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs'}")
start=text.index("code,changed=run('native-clippy'");end=text.index("manifest=root/'tauri/src-tauri/Cargo.toml'",start)
text=text[:start]+"""green=w/'rf1122-green-checks-20261011'
assert load(green/'sources.json')==sources
for name in ['workspace-fmt','native-clippy','native-tests']:
    receipt=load(green/(name+'.receipt.json'));assert receipt['exitCode']==0 and receipt['sourceUnchanged']
    shutil.copy2(green/(name+'.receipt.json'),s/(name+'.receipt.json'))
assert '132 passed; 0 failed; 0 ignored;' in (green/'native-tests.stdout.log').read_text(encoding='utf8')
"""+text[end:]
text=text.replace("ss-rf121-backdrop-runtime-20261011/bin","ss-rf1122-backdrop-runtime-20261011/bin")
text=text.replace("old=load(w/'rf1116-checks-20261011/runtime-package.json')","old=load(w/'rf121-backdrop-checks-after-picker-20261011/runtime-package.json')")
text=text.replace("guiExecuted=False,applicationMaterialAccepted=False)","guiExecuted=False,applicationMaterialAccepted=False,nativeContractTestsReceipt='native-tests.receipt.json',currentNativeTests=132)")
ast.parse(text);target=w/'rf1122-run-build.py'
with target.open('x',encoding='utf8') as f:f.write(text)
print(json.dumps(dict(driver=str(target),originalSha256=hashlib.sha256(original.read_bytes()).hexdigest(),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),executed=False)))
