from pathlib import Path
import json,os,subprocess,shutil
r=Path('D:/SoloSoul');w=Path(__file__).parent
shutil.copy2(w/'rf1122-run-checks.py',w/'rf1122-red-checks-20261011/executed-check-driver.py')
env=os.environ.copy();env.update(TEMP=str(r/'build/rf312-maintenance-20261009/tmp'),TMP=str(r/'build/rf312-maintenance-20261009/tmp'))
p=subprocess.run(['cargo','fmt','--all'],cwd=r/'tauri',env=env,capture_output=True)
for stream in ['stdout','stderr']:(w/('rf1122-format.'+stream+'.log')).write_bytes(getattr(p,stream))
with (w/'rf1122-format.receipt.json').open('x',encoding='utf8') as f:json.dump(dict(command=['cargo','fmt','--all'],exitCode=p.returncode),f)
assert p.returncode==0
