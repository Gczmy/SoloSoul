from pathlib import Path
import ast,hashlib,json
w=Path(__file__).parent;p=w/'run-rf1122-backdrop-queue.py';text=p.read_text(encoding='utf8')
anchor="for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:";assert text.count(anchor)==1
text=text.replace(anchor,"for mode in ['dark-collapsed']:",1)
text=text.replace('success=len(rows)==4 and','success=len(rows)==1 and',1)
text=text.replace("save('cohorts-complete.json',dict(success=success,rows=rows,sourceUnchanged=True,fullMatrixAccepted=False,applicationMaterialAccepted=False,systemSettingsChanged=False))","save('dark-collapsed-followup.json',dict(subsetSuccess=success,originalFourCohortQueueAccepted=False,rows=rows,sourceUnchanged=True,fullMatrixAccepted=False,applicationMaterialAccepted=False,systemSettingsChanged=False))",1)
text=text.replace("print('Four-cohort queue terminal; actual all-cohort acceptance: '+str(success),flush=True)","print('Independent remaining cohort terminal; subset acceptance: '+str(success)+'; original four-cohort queue stays failed',flush=True)",1)
ast.parse(text);target=w/'run-rf1122-dark-followup.py'
with target.open('x',encoding='utf8') as f:f.write(text)
with (w/'rf1122-dark-followup-preparation.json').open('x',encoding='utf8') as f:json.dump(dict(originalSha256=hashlib.sha256(p.read_bytes()).hexdigest(),newSha256=hashlib.sha256(target.read_bytes()).hexdigest(),guardLogicChanged=False,originalFailurePreserved=True,remainingIndependentCohortOnly=True,fullFourCohortsAccepted=False),f,indent=2)
print('Remaining independent cohort prepared; original failed queue retained')
