from pathlib import Path
import datetime, hashlib, json, os, subprocess, time
w=Path(__file__).parent;s=w/'rf1122-native-build-20261011';root=w.parent.parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=load(s/'sources.json');assert len(manifest)==1834
def verify():
    assert all(sha(root/n)==h for n,h in manifest.items())
verify();env=os.environ.copy();env.update(TEMP=str(s),TMP=str(s))
rows=[]
for name,cmd in [
 ('verify-dark-expanded-partial',['node',str(w/'verify-rf1122-dark-two-bindings.mjs'),'--dark-expanded']),
 ('render-dark-expanded-partial',['C:/Python314/python.exe',str(w/'render-rf1122-dark-two-bindings.py'),'--dark-expanded']),
 ('verify-dark-expanded-sdk-cleanup',['node',str(w/'verify-rf1122-sdk-only-cleanup.mjs'),'dark-expanded']),
]:
    start=time.monotonic();verify()
    with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.run(cmd,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    verify();row=dict(name=name,command=cmd,exitCode=p.returncode,elapsedSeconds=time.monotonic()-start,sourceUnchanged=True,at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    with (s/(name+'.receipt.json')).open('x',encoding='utf8') as f:json.dump(row,f,indent=2)
    rows.append(row);print(name,'terminal',p.returncode,flush=True)
    if p.returncode!=0:break
raise SystemExit(0 if len(rows)==3 and all(r['exitCode']==0 for r in rows) else 1)
