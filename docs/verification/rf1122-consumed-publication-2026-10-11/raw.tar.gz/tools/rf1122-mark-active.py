from pathlib import Path
p=Path('D:/SoloSoul/docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md');text=p.read_text(encoding='utf8')
anchor='| 312 | [RF-1122](#rf-1122) | P2 | 原生验证 consumed 标记完整后独占发布 | 无（Windows实际补验发现） | [ ] 待执行 |'
assert text.count(anchor)==1 and text.count('进行中：0；待执行：7。')==1
text=text.replace(anchor,anchor.replace('[ ] 待执行','[~] 进行中'),1).replace('进行中：0；待执行：7。','进行中：1；待执行：6。',1)
p.write_text(text,encoding='utf8')
