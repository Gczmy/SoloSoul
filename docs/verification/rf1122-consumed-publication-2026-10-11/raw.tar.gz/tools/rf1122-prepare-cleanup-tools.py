from pathlib import Path
import ast,hashlib,json
w=Path(__file__).parent;rows={}
for original,target in [('prepare-after-picker-cleanup-plan.py','rf1122-prepare-cleanup-plan.py'),('cleanup-rf121-backdrop-after-picker-owned.ps1','rf1122-cleanup-owned.ps1')]:
    p=w/original;text=p.read_text(encoding='utf8')
    text=text.replace('rf121-backdrop-checks-after-picker-20261011','rf1122-native-build-20261011').replace('-after-picker-20261011','-rf1122-20261011').replace('rf121-backdrop-after-picker','rf1122-backdrop').replace('ss-rf121-backdrop-runtime-20261011','ss-rf1122-backdrop-runtime-20261011')
    if target.endswith('.py'):ast.parse(text)
    with (w/target).open('x',encoding='utf8') as f:f.write(text)
    rows[target]=dict(original=original,originalSha256=hashlib.sha256(p.read_bytes()).hexdigest(),newSha256=hashlib.sha256((w/target).read_bytes()).hexdigest())
with (w/'rf1122-cleanup-tools-prepared.json').open('x',encoding='utf8') as f:json.dump(dict(tools=rows,executed=False,exactTargetsRequired=96,fullFourCohortsRequired=True),f,indent=2)
print('Cleanup tools prepared; no plan or deletion executed')
