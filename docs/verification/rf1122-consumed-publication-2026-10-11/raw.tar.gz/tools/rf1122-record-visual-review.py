from pathlib import Path
import datetime,hashlib,json,sys
w=Path(__file__).parent;mode=sys.argv[1];assert mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']
c=w/('ss-rf121-composed-window-backdrop-'+mode+'-rf1122-20261011');load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
v=load(c/'validation.json');images=load(c/'rendered-captures.json');assert v['accepted'] and v['nativeSystemBackdropVerified'] and len(images)==3
for x in images:assert hashlib.sha256(Path(x['png']).read_bytes()).hexdigest()==x['pngSha256']
# Invoke only after all three PNGs in this cohort have actually been viewed.
result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),actualImagesInspected=3,images=[dict(path=x['png'],sha256=x['pngSha256']) for x in images],notes='三张本组截图已实际查看；核对内容、侧栏、顶部栏和卡片边界，瞬时通知叠层按原截图保留。',scope='Own foreground window in this specific theme/sidebar cohort only',fullMatrixAccepted=False,darkModeAndCaptionNativeGetterClaimed=False,systemSettingsChanged=False)
with (c/'visual-review.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2,ensure_ascii=False)
print('Actual visual review saved for '+mode,flush=True)
