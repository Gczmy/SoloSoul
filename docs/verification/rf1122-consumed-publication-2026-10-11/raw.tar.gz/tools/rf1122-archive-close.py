from pathlib import Path
import datetime,hashlib,io,json,re,subprocess,tarfile
r=Path('D:/SoloSoul');w=Path(__file__).parent
red=w/'rf1122-red-checks-20261011';green=w/'rf1122-green-checks-20261011';s=w/'rf1122-native-build-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2,ensure_ascii=False);f.write('\n')
sources=load(s/'sources.json');assert len(sources)==1834 and sources==load(green/'sources.json')
assert all(sha(r/n)==h for n,h in sources.items())
assert load(red/'publication-tests.receipt.json')['exitCode']==101
assert '1 passed; 2 failed; 0 ignored;' in (red/'publication-tests.stdout.log').read_text(encoding='utf8')
receipts={n:load(green/(n+'.receipt.json')) for n in ['workspace-fmt','native-clippy','native-tests','workspace-clippy','workspace-tests']}
assert all(v['exitCode']==0 and v['sourceUnchanged'] for v in receipts.values())
assert '132 passed; 0 failed; 0 ignored;' in (green/'native-tests.stdout.log').read_text(encoding='utf8')
totals=load(green/'workspace-totals.json');assert totals['passed']==1874 and totals['failed']==0 and totals['ignored']==3 and totals['allIgnoredAlsoPresentInPreviousUnchangedSourceRun']
assert load(s/'native-release-build.receipt.json')['exitCode']==0
parity=load(s/'build-manifest-newline-parity.json');assert not parity['rawReceiptSourceUnchanged'] and parity['normalizedBytesEqual'] and parity['parsedTomlEqual']
assert (s/'build-Cargo-before.toml').read_bytes()==(r/'tauri/src-tauri/Cargo.toml').read_bytes()
pkg=load(s/'runtime-package.json');assert sha(Path(pkg['exe']))==pkg['sha256'] and len(pkg['resources'])==94 and pkg['currentNativeTests']==132
for v in pkg['resources']:assert sha(Path(v['source']))==sha(Path(v['copy']))==v['sha256']
queue=load(s/'cohorts-complete.json');follow=load(s/'dark-collapsed-followup.json')
assert not queue['success'] and len(queue['rows'])==3 and not follow['subsetSuccess'] and not follow['originalFourCohortQueueAccepted']
captures=[]
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
    c=w/f'ss-rf121-composed-window-backdrop-{mode}-rf1122-20261011'
    assert load(c/'actual100.receipt.json')['exitCode']==0
    journey=load(c/'actual100/native-perf-sdk-journey-results.json');assert journey['success'] and len(journey['samples'])==3
    for i in [1,2,3]:
        marker=load(c/'actual100'/f'sample-{i:03}'/'native-perf-consumed.json');surface=load(c/f'surface-sample-{i:03}.json')
        assert surface['success'] and marker['runId']==surface['runId'] and marker['pid']==surface['pid']
        captures.append(dict(mode=mode,index=i,runId=surface['runId'],pid=surface['pid'],consumedSha256=sha(c/'actual100'/f'sample-{i:03}'/'native-perf-consumed.json'),surfaceSha256=sha(c/f'surface-sample-{i:03}.json')))
    if mode in ['baseline','light-collapsed']:
        v=load(c/'validation.json');assert v['accepted'] and len(v['samples'])==3 and v['nativeSystemBackdropVerified']
        assert load(c/'visual-review.json')['actualImagesInspected']==3
    else:
        assert load(s/f'verify-{mode}.receipt.json')['exitCode']==1
        assert '2 !== 1' in (s/f'verify-{mode}.stderr.log').read_text(encoding='utf8')
        v=load(c/'sdk-only-mixed-cleanup-validation.json');assert not v['accepted'] and v['cleanupOnly'] and len(v['samples'])==3
dark=w/'ss-rf121-composed-window-backdrop-dark-expanded-rf1122-20261011'
assert load(dark/'partial-two-bindings.json')['bindingSubsetVerified'] and load(dark/'partial-visual-review.json')['actualImagesInspected']==2
cleanup=load(w/'rf1122-mixed-cache-cleanup.json')
assert len(cleanup['removedCachePaths'])==96 and len(cleanup['applicationLogs'])==12 and len(cleanup['linksUnlinked'])==12
assert cleanup['matchingOwnedIdentitiesLive']==cleanup['processesTerminatedByThisTool']==0 and cleanup['preservedBytesVerified']
assert all(not Path(p).exists() for p in cleanup['removedCachePaths'])
for v in cleanup['preservedVaultAndRootFiles']:assert sha(Path(v['path']))==v['sha256']
for v in cleanup['applicationLogs']:assert sha(Path(v['copy']))==v['sha256']
base=load(s/'starting-state.json')['head'];assert base=='4130d10afb3becfff4b400dc91cf23c5685b66ad'
old_sources=load(w/'rf121-backdrop-checks-after-picker-20261011/sources.json')
assert sources.keys()==old_sources.keys()
changed=[n for n,h in sources.items() if old_sources[n]!=h]
assert sorted(changed)==['tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs']
git_changed=subprocess.run(['git','diff','--ignore-submodules','--name-only',base,'--','tauri'],cwd=r,check=True,capture_output=True).stdout.decode().splitlines()
assert sorted(git_changed)==sorted(changed)
save(s/'final-source-provenance.json',dict(base=base,sourceCount=1834,changedSources=changed,otherSourcesUnchanged=True,comparison='Git-normalized LF; current build raw bytes match frozen manifest',buildManifestNewlineOnly=parity,dependencyChange=False,readerRetryAdded=False))
files={};allowed={'.json','.log','.py','.mjs','.ps1','.rs','.toml','.lock','.png','.bgra','.md','.txt'}
def add(p,n):
    assert p.is_file() and not p.is_symlink() and not(p.lstat().st_file_attributes&0x400) and n not in files,n
    files[n]=p
def shallow(base,prefix):
    for p in base.iterdir():
        if p.is_file() and p.suffix in allowed:add(p,prefix+'/'+p.name)
for base_,prefix in [(red,'red'),(green,'green'),(s,'current-build')]:shallow(base_,prefix)
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
    c=w/f'ss-rf121-composed-window-backdrop-{mode}-rf1122-20261011'
    shallow(c,'windows/'+mode);shallow(c/'actual100','windows/'+mode+'/actual100')
    for i in [1,2,3]:shallow(c/'actual100'/f'sample-{i:03}','windows/'+mode+f'/actual100/sample-{i:03}')
for p in (w/'application-logs-rf1122-mixed').rglob('*'):
    if p.is_file():add(p,'application-logs/'+p.relative_to(w/'application-logs-rf1122-mixed').as_posix())
for p in w.iterdir():
    if p.is_file() and p.suffix in allowed and 'rf1122' in p.name:add(p,'tools/'+p.name)
# Freeze the existing dependency implementation used for exclusive Windows publication.
dep=r/'build/rf312-maintenance-20261009/cargo-home/registry/src/index.crates.io-1949cf8c6b5b557f/tempfile-3.27.0/src/file/imp/windows.rs'
add(dep,'existing-dependency/tempfile-3.27.0-windows.rs')
stem='rf1122-consumed-publication-2026-10-11';out=r/'docs/verification'/stem;out.mkdir(exist_ok=False)
(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf8');members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as t:
    for n,p in sorted(files.items()):
        b=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b));members.append(dict(path=n,size=len(b),sha256=hashlib.sha256(b).hexdigest()))
assert (out/'raw.tar.gz').stat().st_size<50_000_000
with tarfile.open(out/'raw.tar.gz','r:gz') as t:
    assert set(t.getnames())=={v['path'] for v in members}
    for v in members:
        b=t.extractfile(v['path']).read();assert len(b)==v['size'] and hashlib.sha256(b).hexdigest()==v['sha256']
save(out/'index.json',dict(task='RF-1122',archiveSha256=sha(out/'raw.tar.gz'),members=members,allMembersVerified=True,excluded=['executables','private Vault','models','caches','APK','JNI','private Android backup']))
save(r/'docs/verification'/(stem+'.json'),dict(task='RF-1122',status='complete',base=base,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceCount=1834,changedSources=changed,validation=dict(redExitCode=101,redPassed=1,redFailed=2,nativePassed=132,nativeFailed=0,nativeIgnored=0,workspace=totals,receipts=receipts,currentGuiBuildExitCode=0,buildSourceNewlineParity=parity,markerReadsCompleted=12,markerParseFailures=0,consumedCaptures=captures,completeIndependentWindowBindings=6,partialDarkBindings=[1,3],actualPngsInspected=8,originalFourCohortQueue=queue,remainingIndependentCohort=follow,darkAppearanceFailure='aggregate user_data_update_preference count 2 versus 1',uniqueExtraPreferenceWriterEstablished=False),cleanup=dict(identitiesChecked=cleanup['identitiesChecked'],removedCachePaths=96,linksUnlinked=12,logsPreserved=12,preservedFiles=len(cleanup['preservedVaultAndRootFiles']),preservedBytesVerified=True,processesTerminated=0),scope='Only optional Windows native-perf consumed marker publication; full appearance matrix not accepted',fullRF121Accepted=False,fullRF312Accepted=False,applicationMaterialAccepted=False,systemSettingsChanged=False,archive=dict(path=stem+'/raw.tar.gz',sha256=sha(out/'raw.tar.gz'),members=len(members),allMembersVerified=True)))
ledger=r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';text=ledger.read_text(encoding='utf8')
assert text.count('已关闭：**301 / 312**；实际修复（已关闭）：301；')==1
text=text.replace('> 最后更新：2026-10-11（RF-1121移动端主应用入口条件编译完成；完整跨平台矩阵仍待验证）','> 最后更新：2026-10-11（RF-1122原生验证标记完整后独占发布完成；深色场景偏好计数仍待调查）')
text=text.replace('已关闭：**301 / 312**；实际修复（已关闭）：301；','已关闭：**302 / 312**；实际修复（已关闭）：302；').replace('暂缓：0；进行中：1；待执行：6。','暂缓：0；进行中：0；待执行：6。')
start=text.index('- 当前处理：');end=text.index('\n',start)
text=text[:start]+'- 当前处理：RF-121深色场景额外偏好写入归因与剩余原生矩阵；RF-1122已单独完成，RF-112/121/312/1109和RF-122～127前置保持未完成。'+text[end:]
assert text.count('| 无（Windows实际补验发现） | [~] 进行中 |')==1
text=text.replace('| 无（Windows实际补验发现） | [~] 进行中 |','| 无（Windows实际补验发现） | [x] 完成 |')
text+='''

### RF-1122 consumed 标记发布执行记录（2026-10-11，完成）

- Windows当前深色原生样本实际读到半成品JSON，结束后原文件完整；旧失败随此前RF-121阶段提交保留。仅非默认native-perf的consumed文件改用已有tempfile 3.27.0：同目录完整序列化、换行和sync_all后persist_noclobber独占发布，不覆盖既有标记、不重用已消费样本，不添加依赖或读者重试。
- 确定性红灯1通过/2失败，绿灯覆盖序列化中不可见、序列化失败无残留及8个竞争生产者恰好一个完整获胜并拒绝覆盖。实际workspace格式、默认及native严格Clippy通过；完整native模块132通过/0失败/0忽略；默认workspace1874通过/0失败/3既有忽略，忽略名称与此前记录逐项核验。原硬链接回退警告及PDB命名警告保留，没有声明所有工具零警告。
- 当前GUI Release重新构建、1834份源码与94份资源SHA冻结。构建工具仅把Cargo.toml换行改为LF，原始receipt的sourceUnchanged=false保留；归一字节和解析TOML一致后恢复原始换行，构建与运行来源复核通过。源码相对4130d10af仅native_perf.rs及其测试改变。
- 新GUI四组各3次共12次SDK完整行程与consumed严格读取成功，0次JSON解析失败。浅色展开/折叠6份完整独立窗口绑定通过，深色展开1、3号2份独立部分绑定通过，8张PNG已实际查看。原四组队列及独立深色折叠补跑均失败：聚合偏好写入计数2而非1；原门禁、失败和未渲染样本保留，不称深色整组或完整RF-121/312验收。备份提醒路径与额外调用相符，仍未唯一证明来源，下一步单独归因。
- fresh CIM核验108个记录身份退出，精确清理96个本轮缓存和12个联接；540份Vault/根级原件及12份日志SHA保留，没有终止用户进程。仅公开测试根级诊断与像素归档，排除程序、模型、私有Vault及移动备份。[结构化证据](verification/rf1122-consumed-publication-2026-10-11.json)及原件索引逐成员长度/SHA回读通过。
- 仅本项独立本地提交（本提交，以RF-1122检索），不推送；302/312关闭，4待验证、6待执行。完整RF-112/121/312/1109、其他平台与RF-122～127前置保持未完成，整体goal继续active。
'''
ledger.write_text(text,encoding='utf8',newline='\n')
print(json.dumps(dict(members=len(members),archiveBytes=(out/'raw.tar.gz').stat().st_size,allMembersVerified=True,closed='302/312',fullRF121Accepted=False)))
