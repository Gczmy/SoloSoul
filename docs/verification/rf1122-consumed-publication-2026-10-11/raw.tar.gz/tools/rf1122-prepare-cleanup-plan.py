from pathlib import Path
import json
w=Path(__file__).parent;s=w/'rf1122-native-build-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert load(s/'cohorts-complete.json')['success']
groups=[]
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
    capture=w/('ss-rf121-composed-window-backdrop-'+mode+'-rf1122-20261011')
    receipt=load(capture/'actual100.receipt.json');validation=load(capture/'validation.json')
    assert receipt['exitCode']==0 and validation['accepted'] and len(validation['samples'])==3
    assert validation['nativeSystemBackdropVerified'] and not validation['fullMatrixAccepted']
    for sample in validation['samples']:
        assert sample['capture']['foregroundBefore'] is sample['capture']['foregroundAfter'] is sample['state']['focused'] is True
        expected=2 if sample['state']['material']=='mica' else 1
        assert sample['state']['material'] in ['mica','solid'] and sample['capture']['dwmSystemBackdropType']==expected
    groups.append(dict(label=mode,captureRoot=str(capture),terminal=True,samples=validation['samples']))
with (w/'rf1122-backdrop-cache-cleanup-plan.json').open('x',encoding='utf8') as f:
    json.dump(dict(cacheCleanupEligible=True,failedSamplesAccepted=False,fullMaterialMatrixAccepted=False,groups=groups),f,indent=2)
print('Twelve independent terminal samples eligible for 96 exact owned cache targets; no deletion performed')
