from pathlib import Path
import os,subprocess,time,json,hashlib,shutil
R=Path('D:/SoloSoul');S=Path(__file__).parent;B=S.parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert load(S/'checks.receipt.json')['sourcesUnchanged']
sources=load(S/'sources.json')
compiled=R/'build/rf312-maintenance-20261009/cargo-target/release/examples/perf_baseline.exe'
exe=S/'current-nonblank-media-generator.exe';assert not exe.exists();shutil.copyfile(compiled,exe)
generator={'path':str(exe),'sha256':sha(exe),'sourceHashes':sources,'buildExitCode':load(S/'release-generator.receipt.json')['exitCode']}
(S/'generator.json').write_text(json.dumps(generator,indent=2)+'\n',encoding='utf-8')
rows=[]
env=os.environ.copy();env.update(SOLOSOUL_SECURE='1',TEMP=str(S/'tmp'),TMP=str(S/'tmp'),PYTHONUTF8='1')
def snapshot(root):return {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
def run(label,args,wanted):
    assert sha(exe)==generator['sha256'] and all(sha(R/n)==h for n,h in sources.items())
    command=[str(exe),*args];began=time.monotonic()
    with (S/f'{label}.stdout.log').open('xb') as out,(S/f'{label}.stderr.log').open('xb') as err:
        p=subprocess.Popen(command,cwd=R/'tauri',env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
        (S/f'{label}.live.json').write_text(json.dumps({'pid':p.pid,'command':command})+'\n',encoding='utf-8')
        print(label,'live PID',p.pid,flush=True);code=p.wait()
    row={'label':label,'exitCode':code,'expectedExitCode':wanted,'command':command,'elapsedSeconds':time.monotonic()-began};rows.append(row)
    (S/f'{label}.receipt.json').write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
    assert code==wanted,label
    if wanted==0:
        candidates=[json.loads(line) for line in (S/f'{label}.stdout.log').read_text(encoding='utf-8').splitlines() if line.startswith('{')]
        assert len(candidates)==1
        result=candidates[0];assert result['success'] and result['nativeUiMeasured'] is False
        return result
    return None
proofs={}
for count in [100,5000]:
    host=S/f'host-vault{count}';android=S/f'android-vault{count}'
    assert not host.exists() and not android.exists()
    run(f'new-{count}-generate',['--media-fixture-output',str(host),'--objects',str(count)],0)
    before=snapshot(host)
    verified=run(f'new-{count}-host-verify',['--verify-media-fixture',str(host)],0)
    assert verified['verification']['allObjectContentsVerified']==count and snapshot(host)==before
    run(f'new-{count}-android-copy',['--copy-android-media-fixture',str(host),'--media-fixture-output',str(android)],0)
    after_copy=snapshot(android)
    verified=run(f'new-{count}-android-verify',['--verify-android-media-fixture',str(android)],0)
    assert verified['verification']['allObjectContentsVerified']==count and snapshot(android)==after_copy and snapshot(host)==before
    marker=load(android/'rf312-media-fixture.json');media=marker['media']
    assert media['baseFixture']['kdf']=={'memoryKiB':65536,'iterations':3,'parallelism':4}
    asset=next(a for a in media['publicAssets'] if a['fileName']=='scanned.pdf')
    assert asset['sha256']=='0a3cab3b67ca5390d4ca0b468b50b1c3c2a8b9c8220335356675f62df3a9d525' and asset['bytes']==5082
    proofs[str(count)]={'hostFiles':before,'androidFiles':after_copy,'allObjectsVerified':count,'allFourAssetBytesVerified':True,'newScanAsset':asset}
    for kind,root,flag in [('host',B/'rf312-media-fixtures-d-20261012'/f'vault{count}','--verify-media-fixture'),('android',B/'rf312-android-media-preparation-round2-20261012'/f'android-vault{count}','--verify-android-media-fixture')]:
        old=snapshot(root)
        run(f'old-{kind}-{count}-asset-rejection',[flag,str(root)],1)
        assert snapshot(root)==old
        proofs[str(count)][kind+'HistoricalSourceUnchanged']=True
result={'task':'RF-1136','passed':True,'rows':rows,'freshWhole1005000ProductionKdfSet':True,'fixtures':proofs,'historicalSourcesUnchangedAndOldAssetRejected':True,'nativeUiOrPerformanceAccepted':False}
(S/'new-fixture-preparation.receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print('Fresh100/5000 host and Android encrypted media verified; old blank asset contracts rejected, unchanged',flush=True)
