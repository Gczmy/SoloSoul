from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');B=Path(__file__).parent;F=B/'rf1136-nonblank-scanned-fixture-20261012'
old=B/'rf1135-android-native-pages-round3-20261012';S=B/'rf1136-android-nonblank-media-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert load(F/'new-fixture-preparation.receipt.json')['passed']
S.mkdir(exist_ok=False)
for name in ['AndroidMediaPerfInstrumentedTest.kt','media-native-driver.py','run-first-100-diagnostic.py']:
    raw=(old/name).read_text(encoding='utf-8').replace(old.name,S.name)
    (S/name).write_text(raw,encoding='utf-8',newline='\n')
inputs=load(old/'inputs.json');main_sources=load(B/'rf1135-android-attachment-temp-20261012/sources.json')
now={n:sha(R/n) for n in main_sources}
changed=[n for n in main_sources if main_sources[n]!=now[n]]
assert changed==['tauri/crates/solosoul-core/examples/perf_baseline/media.rs']
asset='tauri/crates/solosoul-core/examples/perf_baseline/fixtures/scanned.pdf';now[asset]=sha(R/asset)
assert sha(Path(inputs['release']['apk']['path']))==inputs['release']['apk']['sha256']
test=load(old/'current-test-apk.json');assert sha(Path(test['path']))==test['sha256']
assert sha(S/'AndroidMediaPerfInstrumentedTest.kt')==test['homeTestSourceSha256']
inputs['runtimeTest']=test;inputs['runtimeSourceFiles']=now
inputs['sourceParentHead']='2648eb864';inputs['sourceHasPendingRf1136FixtureChanges']=True
for count in [100,5000]:
    root=F/f'android-vault{count}'
    files={p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
    marker=load(root/'rf312-media-fixture.json')
    scan=next(a for a in marker['media']['publicAssets'] if a['fileName']=='scanned.pdf')
    assert scan['sha256']==now[asset]
    # Preserve the exact existing driver fixture shape, replacing only root/files.
    previous=inputs['fixedFixtures'][str(count)]
    inputs['fixedFixtures'][str(count)]={**previous,'root':str(root),'files':files,'marker':marker}
(S/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
(S/'binding.json').write_text(json.dumps({'sameRf1135ProductionMainApk':inputs['release']['apk'],'sameExistingNonblankProbeApk':test,'onlyRuntimeSourceDifference':changed,'newPerformanceOnlyAsset':asset,'exampleAndAssetNotCompiledIntoAndroidMain':True,'updatedSourceFiles':len(now),'nativeUiAccepted':False,'fullRF312Accepted':False},indent=2)+'\n',encoding='utf-8')
print(S)
