from pathlib import Path
import json,hashlib
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf1136-nonblank-scanned-fixture-20261012'
(S/'tmp').mkdir(exist_ok=True)
for name in ['run-checks-and-build.py','run-windows-consumer-checks.py']:
    raw=(B/'rf312-android-media-adapter-20261012'/name).read_text(encoding='utf-8')
    if name=='run-checks-and-build.py':
        needle="R/'tauri/crates/solosoul-core/tests/fixtures/scanned.pdf'"
        assert raw.count(needle)==1
        raw=raw.replace(needle,needle+",R/'tauri/crates/solosoul-core/examples/perf_baseline/fixtures/scanned.pdf'")
    (S/name).write_text(raw,encoding='utf-8',newline='\n')
# Source fixture bytes differ; historical fixtures remain immutable and must not
# be silently accepted by the updated exact-asset consumer contract.
print(S)
