from pathlib import Path
import json,hashlib,tarfile,io,importlib.util
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf1136-nonblank-scanned-fixture-20261012';N=B/'rf1136-android-nonblank-media-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert load(S/'checks.receipt.json')['sourcesUnchanged']
assert all(row['exitCode']==0 for row in load(S/'consumer-checks.receipt.json')['rows'])
assert load(S/'new-fixture-preparation.receipt.json')['passed']
helper=R/'tauri/scripts/android-home-native-regression.py';spec=importlib.util.spec_from_file_location('rf1136_restore_audit',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
runs={};audits=[]
for count in [100,5000]:
    d=N/f'first-{count}-diagnostic';receipt=load(N/f'first-{count}-diagnostic.receipt.json')
    assert receipt['exitCode']==0 and all(receipt[k] for k in ['passed','restored','originalApksRestored','ownedProbeRemoved','blurRestored','sourceInputsUnchanged'])
    native=load(d/'device-files/report.json');assert native['objectCount']==count and native['success'] and len(native['phases'])==10
    scan=native['nativePdf-scanned.pdf'];assert scan['knownPublicPlaintextVerified'] and scan['closedToOriginalAttachmentList']
    assert scan['plaintextSha256']=='0a3cab3b67ca5390d4ca0b468b50b1c3c2a8b9c8220335356675f62df3a9d525'
    assert scan['inkPixels']>100 and scan['windowPixels']['actualWindowPageDarkPixels']>100
    a=d/'private-data-before.tar';z=d/'private-data-restored.tar'
    before=m.inventory(a,require_empty=True);after=m.inventory(z);assert before==after
    audits.append({'objectCount':count,'entries':len(before),'allContentsLinksModesMatch':True,'beforeTarSha256':sha(a.read_bytes()),'afterTarSha256':sha(z.read_bytes())})
    runs[str(count)]={'receipt':receipt,'nativePdf':scan,'phases':native['phases'],'scope':'single functional diagnostic; no OCR/repeated full performance accepted'}
(S/'restoration-audit.json').write_text(json.dumps(audits,indent=2)+'\n',encoding='utf-8')
target=R/'docs/verification/rf1136-nonblank-scan-fixture-2026-10-12';target.mkdir(exist_ok=False)
members={}
for root in [S,N]:
    for p in root.rglob('*'):
        relative=p.relative_to(root)
        if any(n.startswith(('host-vault','android-vault')) or n in {'tmp','project'} for n in relative.parts):continue
        if not p.is_file() or p.suffix.lower() not in {'.json','.log','.py','.kt','.png'}:continue
        assert not p.is_symlink();members[root.name+'/'+relative.as_posix()]=p.read_bytes()
for name in ['create-rf1136-scanned-fixture.py','prepare-rf1136-checks.py','prepare-rf1136-native.py','archive-rf1136.py']:
    members['orchestration/'+name]=(B/name).read_bytes()
for name in ['tauri/crates/solosoul-core/examples/perf_baseline/media.rs','tauri/crates/solosoul-core/examples/perf_baseline/fixtures/scanned.pdf','tauri/crates/solosoul-core/examples/perf_baseline/fixtures/README.md']:
    members['validated-working-source/'+name]=(R/name).read_bytes()
archive=target/'raw.tar'
with tarfile.open(archive,'w') as out:
    for n,raw in sorted(members.items()):
        info=tarfile.TarInfo(n);info.size=len(raw);info.mode=0o644;out.addfile(info,io.BytesIO(raw))
index={'task':'RF-1136','archiveSha256':sha(archive.read_bytes()),'members':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())},'privateDataProgramsKeysAndDatabasesExcluded':True}
with tarfile.open(archive) as inp:
    assert {m.name for m in inp}==set(members)
    for n,v in index['members'].items():
        raw=inp.extractfile(n).read();assert len(raw)==v['bytes'] and sha(raw)==v['sha256']
(target/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
summary={'task':'RF-1136','status':'complete-awaiting-final-source-review','asset':load(S/'asset-proof.json'),'currentSourceChecks':load(S/'checks.receipt.json'),'sharedConsumerChecks':load(S/'consumer-checks.receipt.json'),'newDatasetPreparation':load(S/'new-fixture-preparation.receipt.json'),'nativeFunctionalRuns':runs,'restorationAudit':audits,'rawIndex':target.name+'/index.json','legacyBlankAssetAndHistoricalDatasetsUnchanged':True,'productionDefaultDependenciesAndAndroidMainUnchanged':True,'fullRF312Accepted':False,'pushed':False}
(R/'docs/verification/rf1136-nonblank-scan-fixture-2026-10-12.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print({'members':len(members),'archiveBytes':archive.stat().st_size,'native1005000FunctionalPassed':True,'restorationPairs':len(audits)})
