from pathlib import Path
import hashlib,json,subprocess
from PIL import Image
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.utils import ImageReader
from pypdf import PdfReader
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf1136-nonblank-scanned-fixture-20261012'
S.mkdir(exist_ok=False);(S/'tmp').mkdir()
source=R/'tauri/crates/solosoul-core/tests/fixtures/ocr_test.png'
blank=R/'tauri/crates/solosoul-core/tests/fixtures/scanned.pdf'
sha=lambda b:hashlib.sha256(b).hexdigest()
original={'png':sha(source.read_bytes()),'blankPdf':sha(blank.read_bytes())}
image=Image.open(source).convert('RGB');pixels=image.tobytes()
assert len(set(pixels))>1 and sum(v<100 for v in pixels)>100
output=R/'tauri/crates/solosoul-core/examples/perf_baseline/fixtures/scanned.pdf'
assert not output.exists();output.parent.mkdir(parents=True,exist_ok=True)
def create(path):
    canvas=Canvas(str(path),pagesize=(612,792),invariant=1,pageCompression=0)
    canvas.setTitle('RF-312 public synthetic scanned preview')
    canvas.setSubject('Raster-only public OCR image; no PDF text layer')
    width=540;height=width*image.height/image.width
    canvas.drawImage(ImageReader(image),36,(792-height)/2,width=width,height=height)
    canvas.showPage();canvas.save()
create(output);repeat=S/'determinism-repeat.pdf';create(repeat)
assert output.read_bytes()==repeat.read_bytes()
reader=PdfReader(output);assert len(reader.pages)==1
page=reader.pages[0];assert not page.extract_text().strip()
objects=page['/Resources']['/XObject'].get_object()
rasters=[o.get_object() for o in objects.values() if o.get_object()['/Subtype']=='/Image']
assert len(rasters)==1
raster=rasters[0];assert raster['/Width']==image.width and raster['/Height']==image.height
assert raster['/ColorSpace']=='/DeviceRGB' and raster['/BitsPerComponent']==8
assert raster.get_data()==pixels
assert sha(source.read_bytes())==original['png'] and sha(blank.read_bytes())==original['blankPdf']
proof={'task':'RF-1136','sourcePng':{'path':str(source),'sha256':original['png'],'width':image.width,'height':image.height,'rgbSha256':sha(pixels)},'legacyBlankPdfUnchangedSha256':original['blankPdf'],'output':{'path':str(output),'sha256':sha(output.read_bytes()),'bytes':output.stat().st_size},'exactDeterministicRegeneration':True,'pages':1,'imageXObjects':1,'textLayerEmpty':True,'decodedRasterEqualsSourceRgb':True,'nativeUiOrPerformanceAccepted':False}
(S/'asset-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof))
