from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1121-checks-20261011';android=root/'build/android-native-feasibility-20261010';desktop=root/'build/rf312-maintenance-20261009'
phase=sys.argv[1];assert phase in ['red','green'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text(encoding='utf8'))
original=load(checks/'registration.json')['sources'];parent=load(w/'rf1120-checks-20261011/sources.json');frozen={n:sha(root/n) for n in parent}
def save(n,v):
    with (checks/n).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
save(phase+'-sources.json',frozen)
for n in original:(checks/(phase+'-'+Path(n).parent.name+'-'+Path(n).name+'.executed')).write_bytes((root/n).read_bytes())
env=os.environ.copy();tool=android/'rustup/toolchains/1.96.0-x86_64-pc-windows-msvc/bin';ndk=android/'sdk/ndk/27.0.12077973/toolchains/llvm/prebuilt/windows-x86_64/bin'
env.update(TEMP=str(android/'tmp'),TMP=str(android/'tmp'),CARGO_HOME=str(android/'cargo-home'),CARGO_TARGET_DIR=str(android/'cargo-target'),CARGO_BUILD_JOBS='1',RUSTUP_HOME=str(android/'rustup'),RUSTUP_TOOLCHAIN='1.96.0',RUSTC=str(tool/'rustc.exe'),CARGO_TARGET_X86_64_LINUX_ANDROID_LINKER=str(ndk/'x86_64-linux-android28-clang.cmd'),CC_x86_64_linux_android=str(ndk/'x86_64-linux-android28-clang.cmd'),AR_x86_64_linux_android=str(ndk/'llvm-ar.exe'),ANDROID_HOME=str(android/'sdk'),ANDROID_SDK_ROOT=str(android/'sdk'),NDK_HOME=str(android/'sdk/ndk/27.0.12077973'),ANDROID_NDK_HOME=str(android/'sdk/ndk/27.0.12077973'),ORT_CACHE_DIR=str(android/'ort-cache'),RUSTFLAGS='-Clink-arg=-landroid -Clink-arg=-llog -Clink-arg=-lOpenSLES')
env['PATH']=str(tool)+';'+env.get('PATH','')
for n in ['PDFIUM_LIBRARY_PATH','TAURI_ANDROID_PROJECT_PATH','TAURI_CONFIG','CARGO_ENCODED_RUSTFLAGS','SOLOSOUL_REGISTRY_PUBKEY']:env.pop(n,None)
save(phase+'-android-toolchain.json',dict(rustc=str(tool/'rustc.exe'),rustcSha256=sha(tool/'rustc.exe'),cargoSha256=sha(tool/'cargo.exe'),linker=str(ndk/'x86_64-linux-android28-clang.cmd'),linkerSha256=sha(ndk/'x86_64-linux-android28-clang.cmd'),privateClippyInstalled=(tool/'cargo-clippy.exe').exists(),rustflags=env['RUSTFLAGS'],defaultFeatures=['custom-protocol'],nativePerfEnabled=False,apkBuilt=False))
def run(name,cmd,e):
    start=time.monotonic()
    with (checks/(name+'.stdout.log')).open('xb') as out,(checks/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=root/'tauri',env=e,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()));print(name,'PID',p.pid,flush=True);code=p.wait()
    changes=[n for n,h in frozen.items() if sha(root/n)!=h]
    save(name+'.receipt.json',dict(exitCode=code,pid=p.pid,command=cmd,elapsedSeconds=time.monotonic()-start,sourceUnchanged=not changes,changedSources=changes,sourceManifest=phase+'-sources.json',temp=e['TEMP'],targetDirectory=e['CARGO_TARGET_DIR']))
    print(name,'terminal',code,flush=True);assert not changes,'Compiled sources or generated inputs changed'
    return code
cmd=[str(tool/'cargo.exe'),'rustc','--locked','--offline','-p','solo_soul','--lib','--target','x86_64-linux-android','--','-D','warnings']
code=run(phase+'-android',cmd,env)
if phase=='red':
    text=(checks/'red-android.stderr.log').read_text(encoding='utf8');expected=['unused import: `Manager`','unused import: `tauri::Emitter`','unused variable: `app`','unused variable: `instance_name`','constant `MDNS_SERVICE_TYPE` is never used','constant `RECOVERY_MDNS_SERVICE_TYPE` is never used','function `advertise_recovery_mdns` is never used','function `poll_accessibility` is never used','function `setup_spawn_registry_refresh` is never used']
    assert code!=0 and all(n in text for n in expected),text[-5000:]
    print('Actual default Android main library reproduces all nine cfg warnings as errors',flush=True)
else:
    assert code==0
    denv=os.environ.copy();denv.update(TEMP=str(desktop/'tmp'),TMP=str(desktop/'tmp'),CARGO_HOME=str(desktop/'cargo-home'),CARGO_TARGET_DIR=str(desktop/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(desktop/'ort-cache'),PDFIUM_LIBRARY_PATH=str(root/'tauri/src-tauri/resources/pdfium/pdfium.dll'))
    denv['PATH']='C:/Program Files/Git/usr/bin;'+denv.get('PATH','')
    assert run('format',['cargo','fmt','--all','--','--check'],denv)==0
    assert run('windows-workspace-clippy',['cargo','clippy','--locked','--','-D','warnings'],denv)==0
    assert run('windows-workspace-tests',['cargo','test','--locked','--verbose'],denv)==0
    save('checks-complete.json',dict(success=True,sourceManifest='green-sources.json',androidStrictMainDefaultCompilation=True,androidClippy=False,iosCompilerExecuted=False,nativeUiAccepted=False))
    print('RF1121 complete check queue terminal',flush=True)
