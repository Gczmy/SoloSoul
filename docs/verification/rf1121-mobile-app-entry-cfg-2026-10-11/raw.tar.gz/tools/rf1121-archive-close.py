from pathlib import Path
import datetime,hashlib,io,json,re,tarfile
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1121-checks-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(checks/'checks-complete.json')['success']
red=load(checks/'red-android.receipt.json');assert red['exitCode']==101 and red['sourceUnchanged']
original=load(root/'build/android-native-feasibility-20261010/android-main-app-cfg-warnings.json')
expected=['unused import: `Manager`','unused import: `tauri::Emitter`','unused variable: `app`','unused variable: `instance_name`','constant `MDNS_SERVICE_TYPE` is never used','constant `RECOVERY_MDNS_SERVICE_TYPE` is never used','function `advertise_recovery_mdns` is never used','function `poll_accessibility` is never used','function `setup_spawn_registry_refresh` is never used']
log=(checks/'red-android.stderr.log').read_text(encoding='utf8');assert all(n in log for n in expected)
receipts={n:load(checks/(n+'.receipt.json')) for n in ['green-android','format','windows-workspace-clippy','windows-workspace-tests']}
assert all(v['exitCode']==0 and v['sourceUnchanged'] for v in receipts.values())
before=load(checks/'red-sources.json');after=load(checks/'green-sources.json');changes=sorted(n for n in before if before[n]!=after[n]);assert changes==sorted(original['sourceFiles'])
assert all(sha(root/n)==h for n,h in after.items())
for n in original['sourceFiles']:
    name=Path(n).parent.name+'-'+Path(n).name
    assert sha(checks/('red-'+name+'.executed'))==before[n]
    assert sha(checks/('green-'+name+'.executed'))==after[n]
    assert (checks/('red-'+name+'.executed')).read_bytes()==(checks/(name+'.before')).read_bytes()
    s=(root/n).read_text(encoding='utf8');base=(checks/(name+'.before')).read_text(encoding='utf8')
    if n.endswith('/recovery.rs'):
        s=s.replace('#[cfg(desktop)]\nuse tauri::Manager;\nuse tauri::{Emitter, State};','use tauri::{Emitter, Manager, State};')
        s=s.replace('        let mdns_instance_name =\n            advertise_recovery_mdns(&app, &info.fingerprint, &info.display_addr).await?;','        #[cfg(desktop)]\n        let mdns_instance_name =\n            advertise_recovery_mdns(&app, &info.fingerprint, &info.display_addr).await?;\n        #[cfg(not(desktop))]\n        let mdns_instance_name: Option<String> = None;')
        s=s.replace('            #[cfg(not(desktop))]\n            drop(instance_name);\n','')
    elif n.endswith('/discovery.rs'):
        s=s.replace('#[cfg(any(desktop, test))]\nconst MDNS_SERVICE_TYPE:','const MDNS_SERVICE_TYPE:').replace('#[cfg(desktop)]\nconst RECOVERY_MDNS_SERVICE_TYPE:','const RECOVERY_MDNS_SERVICE_TYPE:')
    elif n.endswith('/window.rs'):
        s=s.replace('#[cfg(not(any(target_os = "android", target_os = "ios")))]\npub(crate) fn poll_accessibility','pub(crate) fn poll_accessibility')
    else:
        s=s.replace('#[cfg(not(any(target_os = "android", target_os = "ios")))]\nuse tauri::Emitter;','use tauri::Emitter;').replace('#[cfg(not(any(target_os = "android", target_os = "ios")))]\nfn setup_spawn_registry_refresh','fn setup_spawn_registry_refresh')
    assert s==base,'Unexpected behavior or body change: '+n
text=(checks/'windows-workspace-tests.stdout.log').read_text(encoding='utf8')
counts=[dict(passed=int(a),failed=int(b),ignored=int(c),measured=int(d),filtered=int(e)) for a,b,c,d,e in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)]
assert counts and sum(n['passed'] for n in counts)>0 and all(n['failed']==n['filtered']==0 for n in counts)
required=['recovery_package_exports_to_temp_and_cleans_up','recovery_package_requires_unlocked_vault_and_distinct_password','test_mdns_constants_defined','test_mdns_service_type_matches_android_base','test_titlebar_color_deserialization']
for n in required:assert re.search(r'(?m)^test [\w:]*'+re.escape(n)+r' \.\.\. ok\s*$',text),n
save(checks/'source-provenance.json',dict(base=load(checks/'registration.json')['base'],sourceCount=len(after),changedSources=changes,otherSourcesUnchanged=True,redAndGreenExecutedBytesVerified=True,onlyPlatformCfgAndExistingFallbackUseChanged=True,commandSignaturesAndHelperBodiesUnchanged=True,existingProtocolTestsRetained=True))
stem='rf1121-mobile-app-entry-cfg-2026-10-11';out=root/'docs/verification'/stem;out.mkdir(exist_ok=False);(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf8')
files={}
def add(p,n):
    assert p.is_file() and not p.is_symlink() and not(p.lstat().st_file_attributes&0x400) and n not in files
    files[n]=p
for p in checks.rglob('*'):
    if p.is_file():add(p,'checks/'+p.relative_to(checks).as_posix())
for p in w.glob('rf1121-*.py'):add(p,'tools/'+p.name)
add(root/'build/android-native-feasibility-20261010/android-main-app-cfg-warnings.json','original-warning/android-main-app-cfg-warnings.json')
members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as t:
    for n,p in sorted(files.items()):
        data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data));members.append(dict(path=n,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
save(out/'index.json',dict(task='RF-1121',archiveSha256=sha(out/'raw.tar.gz'),members=members))
with tarfile.open(out/'raw.tar.gz','r:gz') as t:
    assert set(t.getnames())==set(m['path'] for m in members)
    for m in members:
        data=t.extractfile(m['path']).read();assert len(data)==m['size'] and hashlib.sha256(data).hexdigest()==m['sha256']
totals={n:sum(c[n] for c in counts) for n in counts[0]}
save(root/'docs/verification'/(stem+'.json'),dict(task='RF-1121',status='complete',base=load(checks/'registration.json')['base'],at=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceCount=len(after),changedSources=changes,validation=dict(redWarnings=expected,redExitCode=101,greenReceipts=receipts,workspaceTestGroups=counts,workspaceTestTotals=totals,requiredExistingCases=required,androidClippy=False,iosCompilerExecuted=False,apkBuilt=False,nativeUiAccepted=False),invariants=dict(signaturesUnchanged=True,desktopAndMobileMdnsHelperBodiesUnchanged=True,mobileNoneFallbackRetained=True,cancelStillClearsInstanceName=True,normalServiceTypeRetainedForTests=True,otherSourcesUnchanged=True),archive=dict(path=stem+'/raw.tar.gz',sha256=sha(out/'raw.tar.gz'),memberCount=len(members),allMembersVerified=True)))
ledger=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=ledger.read_text(encoding='utf8')
s=s.replace('> 最后更新：2026-10-11（RF-1120受管同步网络取消完成；完整跨平台矩阵仍待验证）','> 最后更新：2026-10-11（RF-1121移动端主应用入口条件编译完成；完整跨平台矩阵仍待验证）')
s=s.replace('已关闭：**300 / 311**；实际修复（已关闭）：300；','已关闭：**301 / 311**；实际修复（已关闭）：301；').replace('暂缓：0；进行中：1；待执行：6。','暂缓：0；进行中：0；待执行：6。').replace('RF-1119、RF-1120（','RF-1119、RF-1120、RF-1121（')
start=s.index('- 当前处理：');end=s.index('\n',start);s=s[:start]+'- 当前处理：无；RF-1121已独立完成，完整RF-121/312及其他平台前置仍未完成。'+s[end:]
s=s.replace('| 无（Android真实主应用9项警告） | [~] 进行中 |','| 无（Android真实主应用9项警告） | [x] 完成 |')
s+='''

### RF-1121 主应用移动端入口条件编译执行记录（2026-10-11，完成）

- 原4文件SHA与当前源码一致。真实Android默认功能主应用库严格rustc实际复现全部9项unused/dead_code错误；没有仅用旧警告记录替代本次红灯。D盘Rust1.96.0/NDK27、x86_64目标沿旧默认构建的3条Android链接flags，离线完整构建；依赖重建期间逐次核实同一队列和实际编译子进程，不因等待超时重启或提前改源码。
- Recovery的Manager导入使用既有desktop条件，启动调用已有平台选定广告helper，移动端仍返回None，命令注入AppHandle签名及helper业务体不变；取消仍take清空名称，移动端显式drop已取出的String。Discovery桌面常量跟随消费条件，正常类型额外保留test用途。Window辅助功能轮询及Setup后台注册表刷新/Emitter导入沿实际调用方的OS条件编译；共享初始化、桌面函数体和所有依赖不变。
- 真Android默认库严格rustc修复后通过；私有工具链无Clippy，不称Android Clippy。workspace格式、Windows默认workspace严格Clippy和完整现有Rust回归实际通过，保存各测试组/忽略项的真实计数；Recovery包导出/清理/密码门禁、Discovery协议一致性及标题栏反序列化用例均实际通过。未新写复述cfg实现的测试，未打包/安装APK或验收iOS、原生UI。
- 1834来源仅上述4份Rust文件变更；每轮执行前保存完整清单和实际4源码原字节，执行后完整回读来源。反向精确恢复仅cfg/既有移动回退调用/显式drop后与原文件归一换行一致，命令签名、helper体、已有协议测试与其他来源保持。
- [结构化证据](verification/rf1121-mobile-app-entry-cfg-2026-10-11.json)及[原件索引](verification/rf1121-mobile-app-entry-cfg-2026-10-11/index.json)已归档，全成员回读长度/SHA。仅本项独立本地提交（以RF-1121检索），不推送；301/311关闭、4待验证及6待执行，goal active。RF-112/121/312/1109、RF-122～127与完整跨平台运行矩阵仍未完成，继续推进可执行的Windows窗口状态/材质读回及Android原生补验。
'''
ledger.write_text(s,encoding='utf8',newline='\n')
print(json.dumps(dict(task='RF-1121',members=len(members),tests=totals,archiveSha256=sha(out/'raw.tar.gz'),changedSources=changes)),flush=True)
