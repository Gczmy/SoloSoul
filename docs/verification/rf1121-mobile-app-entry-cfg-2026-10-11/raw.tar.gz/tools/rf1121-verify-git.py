from pathlib import Path
import hashlib,io,json,re,subprocess,sys,tarfile
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1121-checks-20261011';ref=sys.argv[1];assert ref in ['staged','HEAD']
def blob(p):
    return subprocess.check_output(['git','show',(':'+p if ref=='staged' else 'HEAD:'+p)],cwd=root)
sha=lambda b:hashlib.sha256(b).hexdigest()
stem='docs/verification/rf1121-mobile-app-entry-cfg-2026-10-11';summary=json.loads(blob(stem+'.json'));index=json.loads(blob(stem+'/index.json'));raw=blob(stem+'/raw.tar.gz')
assert summary['task']=='RF-1121' and summary['status']=='complete'
assert sha(raw)==summary['archive']['sha256']==index['archiveSha256']
manifest=json.loads((checks/'green-sources.json').read_text(encoding='utf8'))
assert len(manifest)==1834 and all(sha((root/n).read_bytes())==h for n,h in manifest.items())
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
    assert set(t.getnames())=={m['path'] for m in index['members']}
    for m in index['members']:
        data=t.extractfile(m['path']).read();assert len(data)==m['size'] and sha(data)==m['sha256']
    assert json.loads(t.extractfile('checks/green-sources.json').read())==manifest
    for path in summary['changedSources']:
        name=Path(path).parent.name+'-'+Path(path).name
        compiled=t.extractfile('checks/green-'+name+'.executed').read()
        assert compiled==(root/path).read_bytes() and sha(compiled)==manifest[path]
        assert compiled.replace(b'\r\n',b'\n')==blob(path).replace(b'\r\n',b'\n')
validation=summary['validation'];assert validation['redExitCode']==101 and len(validation['redWarnings'])==9
assert all(v['exitCode']==0 and v['sourceUnchanged'] for v in validation['greenReceipts'].values())
assert validation['workspaceTestTotals']['passed']>0 and validation['workspaceTestTotals']['failed']==0
assert not validation['iosCompilerExecuted'] and not validation['nativeUiAccepted'] and not validation['apkBuilt']
ledger=blob('docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md').decode('utf8');rows=re.findall(r'^\| \d+ \| \[RF-[^\n]+$',ledger,re.M)
assert len(rows)==311 and sum('[x]' in row for row in rows)==301 and sum('[~]' in row for row in rows)==0 and sum('[!]' in row for row in rows)==4 and sum('[ ]' in row for row in rows)==6
assert len([row for row in rows if '[RF-1121]' in row and '[x]' in row])==1
allowed=set(summary['changedSources'])|{'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md',stem+'.json',stem+'/.gitattributes',stem+'/index.json',stem+'/raw.tar.gz'}
args=['git','-c','core.quotepath=false','diff','--cached','--name-only'] if ref=='staged' else ['git','-c','core.quotepath=false','diff-tree','--no-commit-id','--name-only','-r','HEAD']
actual=set(subprocess.check_output(args,cwd=root,text=True,encoding='utf8').splitlines());assert actual==allowed,(actual,allowed)
result=dict(ref=ref,sourceCount=len(manifest),archiveMembers=len(index['members']),allMembersVerified=True,compiledToWorkingRawEqual=True,gitComparedWithOnlyCRLFNormalization=True,counts=dict(total=311,closed=301,active=0,waiting=4,pending=6),workspaceTests=validation['workspaceTestTotals'],pathCount=len(allowed))
with (checks/('git-'+ref+'-verified.json')).open('x',encoding='utf8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result),flush=True)
