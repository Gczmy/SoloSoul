from pathlib import Path
import hashlib,json
root=Path('D:/SoloSoul');checks=Path(__file__).parent/'rf1121-checks-20261011';registration=json.loads((checks/'registration.json').read_text(encoding='utf8'))
assert json.loads((checks/'red-android.receipt.json').read_text())['exitCode']==101
red=(checks/'red-android.stderr.log').read_text(encoding='utf8')
for message in ['unused import: `Manager`','unused import: `tauri::Emitter`','unused variable: `app`','unused variable: `instance_name`','constant `MDNS_SERVICE_TYPE` is never used','constant `RECOVERY_MDNS_SERVICE_TYPE` is never used','function `advertise_recovery_mdns` is never used','function `poll_accessibility` is never used','function `setup_spawn_registry_refresh` is never used']:assert message in red,message
for name,h in registration['sources'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h
changes={}
def replace_once(s,old,new):
    assert s.count(old)==1,old
    return s.replace(old,new)
for name in registration['sources']:
    s=(root/name).read_text(encoding='utf8')
    if name.endswith('/recovery.rs'):
        s=replace_once(s,'use tauri::{Emitter, Manager, State};','#[cfg(desktop)]\nuse tauri::Manager;\nuse tauri::{Emitter, State};')
        s=replace_once(s,'        #[cfg(desktop)]\n        let mdns_instance_name =\n            advertise_recovery_mdns(&app, &info.fingerprint, &info.display_addr).await?;\n        #[cfg(not(desktop))]\n        let mdns_instance_name: Option<String> = None;','        let mdns_instance_name =\n            advertise_recovery_mdns(&app, &info.fingerprint, &info.display_addr).await?;')
        s=replace_once(s,'        }\n\n        if let Some(thread) = thread {','            #[cfg(not(desktop))]\n            drop(instance_name);\n        }\n\n        if let Some(thread) = thread {')
    elif name.endswith('/discovery.rs'):
        s=replace_once(s,'const MDNS_SERVICE_TYPE:','#[cfg(any(desktop, test))]\nconst MDNS_SERVICE_TYPE:')
        s=replace_once(s,'const RECOVERY_MDNS_SERVICE_TYPE:','#[cfg(desktop)]\nconst RECOVERY_MDNS_SERVICE_TYPE:')
    elif name.endswith('/window.rs'):
        s=replace_once(s,'pub(crate) fn poll_accessibility(app: &tauri::AppHandle) {','#[cfg(not(any(target_os = "android", target_os = "ios")))]\npub(crate) fn poll_accessibility(app: &tauri::AppHandle) {')
    else:
        assert name.endswith('/setup/mod.rs')
        s=replace_once(s,'use tauri::Emitter;','#[cfg(not(any(target_os = "android", target_os = "ios")))]\nuse tauri::Emitter;')
        s=replace_once(s,'fn setup_spawn_registry_refresh(app: &tauri::AppHandle) {','#[cfg(not(any(target_os = "android", target_os = "ios")))]\nfn setup_spawn_registry_refresh(app: &tauri::AppHandle) {')
    changes[name]=s
for name,s in changes.items():(root/name).write_text(s,encoding='utf8',newline='\n')
print('RF1121 four-file platform entry cfg patch applied; existing helper bodies/signatures retained',flush=True)
