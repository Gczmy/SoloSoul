from pathlib import Path
import datetime,hashlib,json,subprocess
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1121-checks-20261011';checks.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text(encoding='utf8'))
original=load(root/'build/android-native-feasibility-20261010/android-main-app-cfg-warnings.json')
assert all(sha(root/n)==h for n,h in original['sourceFiles'].items())
parent=load(w/'rf1120-checks-20261011/sources.json');assert all(sha(root/n)==h for n,h in parent.items())
for name in original['sourceFiles']:
    (checks/(Path(name).parent.name+'-'+Path(name).name+'.before')).write_bytes((root/name).read_bytes())
ledger=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=ledger.read_text(encoding='utf8');(checks/'ledger-before.md').write_bytes(ledger.read_bytes())
assert s.count('- 任务总数：**310**（P1：56；P2：253；P3：1）。')==1
s=s.replace('- 任务总数：**310**（P1：56；P2：253；P3：1）。','- 任务总数：**311**（P1：56；P2：254；P3：1）。').replace('已关闭：**300 / 310**','已关闭：**300 / 311**').replace('暂缓：0；进行中：0；待执行：6。','暂缓：0；进行中：1；待执行：6。')
start=s.index('- 当前处理：');end=s.index('\n',start);s=s[:start]+'- 当前处理：**RF-1121：主应用移动端编译沿调用者cfg保留Recovery回退及Discovery协议测试，清除9项桌面入口警告**。'+s[end:]
line='| 310 | [RF-1120](#rf-1120) | P1 | Windows同步网络中断及时退出阻塞读写 | 无（独立回环计时实测） | [x] 完成 |';assert s.count(line)==1
s=s.replace(line,line+'\n| 311 | [RF-1121](#rf-1121) | P2 | 主应用移动端条件编译与平台入口一致 | 无（Android真实主应用9项警告） | [~] 进行中 |')
marker='\n## 7. 每项执行记录模板';assert s.count(marker)==1
s=s.replace(marker,'''
### RF-1121

**主应用移动端条件编译与平台入口一致** · P2 · 来源：Android真实主应用编译的9项unused/dead_code警告

- **入口：**commands/recovery.rs、commands/discovery.rs、commands/window.rs和setup/mod.rs。
- **现状：**移动端未消费桌面导入/常量、辅助功能轮询及注册表刷新声明；Recovery已有None广告回退却不调用，命令注入AppHandle因此未使用；取消分支在移动端不消费已take的实例名称。原4文件SHA与当前源码一致。
- **执行：**导入/声明沿现有调用者平台cfg；Recovery调用已有平台选定广告helper并保持None移动回退、取消仍清空名称；协议常量保留跨平台测试用途。不屏蔽warning、不改命令签名、依赖或业务函数体。
- **验收：**真正Android x86_64主应用默认功能严格rustc修复前复现原9项、修复后通过；格式、Windows默认workspace严格Clippy与已有Rust测试，确认Recovery导出/清理、Discovery协议一致性和window相关回归。冻结全部来源、保存执行源码/红绿/退出码并独立本地提交；不构建安装APK、不声称iOS编译或跨平台UI矩阵完成。
'''+marker)
ledger.write_text(s,encoding='utf8',newline='\n')
(checks/'registration.json').write_text(json.dumps(dict(task='RF-1121',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),sources=original['sourceFiles'],sourceCount=len(parent),allOriginalWarningSourceHashesMatch=True),indent=2)+'\n',encoding='utf8')
print('Registered RF-1121: 300/311; one active issue',flush=True)
