from pathlib import Path
import datetime,json
w=Path(__file__).parent
s=(w/'verify-rf1115-native-surfaces.mjs').read_text()
old="assert(['--baseline','--scene'].includes(process.argv[2])&&process.argv.length===3);\nconst scene=process.argv[2]==='--scene';\nconst mode=scene?'collapsed':'baseline';"
assert old in s
s=s.replace(old,"assert(['--baseline','--light-collapsed','--dark-expanded','--dark-collapsed'].includes(process.argv[2])&&process.argv.length===3);\nconst mode=process.argv[2].slice(2);\nconst scene=mode==='light-collapsed',dark=mode.startsWith('dark-'),collapsed=mode.endsWith('collapsed');")
assert s.count('rf1115-checks-20261011')==2
s=s.replace('rf1115-checks-20261011','rf1116-checks-20261011').replace('ss-rf121-composed-window-rf1115-','ss-rf121-composed-window-rf1116-')
s=s.replace("assert.equal(before.state.theme,'light');assert.equal(before.state.expanded,!scene);","assert.equal(before.state.theme,dark?'dark':'light');assert.equal(before.state.expanded,!collapsed);")
s=s.replace('sourceFiles:1832','sourceFiles:1834')
s=s.replace("import {checkJourney, checkBound}","import {validateObserver,ipcDelta} from '../../tauri/scripts/native-perf-run.mjs';\nimport {checkJourney, checkBound}")
block=r'''
  if(dark){
    const req=await regular(path.join(dir,'native-perf-surface-appearance-request.json'),4096);
    assert.deepEqual(req,{...request,scope:'windows-native-appearance-scene-request',scene:mode});
    const prep=await regular(path.join(dir,'native-perf-surface-appearance-prepared.json'),4194304);
    const restore=await regular(path.join(dir,'native-perf-surface-appearance-restored.json'),4194304);
    const result=await regular(path.join(dir,'native-perf-surface-appearance-result.json'));
    exact(prep,['schemaVersion','scope','request','binding','initial','steps','originalPreference','performanceMetrics']);
    exact(restore,['schemaVersion','scope','request','binding','steps','originalPreference','preferenceVerified','performanceMetrics']);
    exact(result,['schemaVersion','scope','request','captureError','restoreError','success','callsBefore','callsAfter','performanceMetrics']);
    for(const [p,suffix] of [[prep,'prepared'],[restore,'restored'],[result,'result']]){
      assert.equal(p.schemaVersion,1);assert.equal(p.scope,'windows-native-appearance-'+suffix);
      assert.deepEqual(p.request,req);assert.equal(p.performanceMetrics,null);
    }
    assert.deepEqual(prep.binding,bound.binding);assert.deepEqual(restore.binding,bound.binding);
    assert(['light','system'].includes(prep.originalPreference));
    assert.equal(restore.originalPreference,prep.originalPreference);assert.equal(restore.preferenceVerified,true);
    assert.equal(result.success,true);assert.equal(result.captureError,null);assert.equal(result.restoreError,null);
    assert.deepEqual(native.lastProbe.inputTrust,{pointer:10,text:3,untrusted:0});
    const observers=new Map();let previousAt=native.lastProbe.atMs;
    const origin='http://tauri.localhost/';
    function appearance(p,action,theme,expanded,pointer,text,checked=null){
      exact(p,['schemaVersion','scope','action','href','timeOriginMs','atMs','theme','platform','expanded','viewport','focused','visibility','layout','settled','target','checked','radios','inputTrust','observer']);
      assert.equal(p.schemaVersion,1);assert.equal(p.scope,'windows-native-appearance-probe');
      assert.equal(p.action,action);
      assert.equal(p.href,['settings','toggle','done'].includes(action)?origin:action==='appearance'?origin+'settings':origin+'settings/appearance');
      assert.equal(p.timeOriginMs,bound.timeOriginMs);number(p.atMs,previousAt,300000);previousAt=p.atMs;
      assert.equal(p.theme,theme);assert.equal(p.platform,'windows');assert.equal(p.expanded,expanded);
      assert.deepEqual(p.viewport,before.state.viewport);assert.equal(p.focused,true);
      assert.equal(p.visibility,'visible');assert.equal(p.settled,true);
      assert(Array.isArray(p.layout)&&p.layout.length===3);
      p.layout.forEach(r=>{assert(Array.isArray(r)&&r.length===4);r.slice(0,2).forEach(v=>number(v,-16384,16384));r.slice(2).forEach(v=>number(v,1,16384));});
      if(action==='done')assert.equal(p.target,null);
      else{exact(p.target,['x','y','actionable']);assert.equal(p.target.actionable,true);number(p.target.x,0,p.viewport[0]-1);number(p.target.y,0,p.viewport[1]-1);}
      assert.deepEqual(p.inputTrust,{pointer,text,untrusted:0});assert.equal(p.checked,checked);
      assert.deepEqual(p.radios,checked===null?[]:['light','dark','system'].map(x=>x===checked));
      const o=p.observer;
      exact(o,['schemaVersion','scope','runId','valid','invalidReasons','total','observedCount','maxEvents','timeOriginMs','installedAtMs','commands']);
      assert.equal(o.schemaVersion,1);assert.equal(o.scope,'windows-native-tauri-invoke-observer');
      assert.equal(o.runId,owned.runId);assert.equal(o.valid,true);assert.deepEqual(o.invalidReasons,[]);
      assert.equal(o.maxEvents,16384);assert.equal(o.timeOriginMs,bound.timeOriginMs);
      number(o.installedAtMs,0,p.atMs);assert.equal(o.total,o.commands.length);assert.equal(o.observedCount,o.total);
      o.commands.forEach(c=>{exact(c,['command','atMs']);number(c.atMs,o.installedAtMs,p.atMs);});
      const n=validateObserver(o,owned.runId);assert.equal(n.valid,true);observers.set(p,n);
    }
    appearance(prep.initial,'settings','light',true,10,3);
    assert.equal(ipcDelta(validateObserver(native.lastProbe.observer,owned.runId),observers.get(prep.initial)).reason,null);
    assert.equal(prep.steps.length,collapsed?5:4);
    appearance(prep.steps[0],'appearance','light',true,11,3);
    appearance(prep.steps[1],'dark','light',true,12,3,prep.originalPreference);
    appearance(prep.steps[2],'home','dark',true,13,4,'dark');
    appearance(prep.steps[3],'toggle','dark',true,14,4);
    if(collapsed)appearance(prep.steps[4],'toggle','dark',false,15,4);
    assert.equal(restore.steps.length,collapsed?6:5);
    let offset=0,pointer=collapsed?15:14;
    if(collapsed){appearance(restore.steps[0],'toggle','dark',false,pointer++,4);offset=1;}
    appearance(restore.steps[offset],'settings','dark',true,pointer++,4);
    appearance(restore.steps[offset+1],'appearance','dark',true,pointer++,4);
    appearance(restore.steps[offset+2],'original','dark',true,pointer++,4,'dark');
    appearance(restore.steps[offset+3],'home','light',true,pointer++,5,prep.originalPreference);
    appearance(restore.steps[offset+4],'done','light',true,pointer,5);
    assert.deepEqual(restore.steps.at(-1).layout[0],prep.initial.layout[0]);
    assert.deepEqual(restore.steps.at(-1).viewport,prep.initial.viewport);
    assert(prep.steps.at(-1).atMs<=before.state.atMs&&restore.steps[0].atMs>=after.state.atMs);
    const sequence=[prep.initial,...prep.steps,...restore.steps];
    for(let i=1;i<sequence.length;i++)assert.equal(ipcDelta(observers.get(sequence[i-1]),observers.get(sequence[i])).reason,null);
    for(const [a,b] of [[prep.steps[1],prep.steps[2]],[restore.steps.at(-3),restore.steps.at(-2)]]){
      const delta=ipcDelta(observers.get(a),observers.get(b));
      assert.equal(delta.commands.find(c=>c.command==='user_data_update_preference')?.attempts,1);
    }
    assert.equal(result.callsAfter,native.calls.length);assert.equal(result.callsAfter-result.callsBefore,collapsed?48:40);
    assert(result.callsAfter<=128);
    if(collapsed)assert.equal(before.state.surfaces.navigation.rect[2],96);
  }else{
    await assert.rejects(lstat(path.join(dir,'native-perf-surface-appearance-request.json')),{code:'ENOENT'});
  }
'''
assert s.count("  const tag=before.state.theme+'-visible';")==1
s=s.replace("  const tag=before.state.theme+'-visible';",block+"  const tag=before.state.theme+'-visible';")
with (w/'verify-rf1116-native-surfaces.mjs').open('x',encoding='utf8',newline='\n') as f:f.write(s)
with (w/'rf1116-checks-20261011/verifier-preparation-note.json').open('x',encoding='utf8',newline='\n') as f:
    json.dump({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'previousPreparationFailure':'Literal occurrence guard expected 3 checks paths; verifier actually contains 2. No file or native run existed.','correctedExpectedOccurrences':2,'productSourceModified':False},f,indent=2)
