from pathlib import Path
import json
stage=Path(__file__).parent
groups=[]
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
    capture=stage/('ss-rf121-composed-window-rf1116-retry2-'+mode+'-20261011')
    load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
    receipt=load(capture/'actual100.receipt.json')
    validation=load(capture/'validation.json')
    assert receipt['exitCode']==0 and validation['accepted'] and len(validation['samples'])==3
    groups.append({'label':'retry2-'+mode,'captureRoot':str(capture),'terminal':True,'samples':validation['samples']})
for mode in ['baseline','light-collapsed','dark-expanded']:
    capture=stage/('ss-rf121-composed-window-rf1116-'+mode+'-20261011')
    receipt=load(capture/'actual100.receipt.json')
    validation=load(capture/('cleanup-validation.json' if mode=='dark-expanded' else 'validation.json'))
    assert receipt['exitCode']==0 and len(validation['samples'])==3
    if mode=='dark-expanded':
        assert validation['accepted'] is False and validation['cleanupOnly'] and validation['outerReaderFailurePreserved']
    else:assert validation['accepted']
    groups.append({'label':'original-'+mode,'captureRoot':str(capture),'terminal':True,'samples':validation['samples'],'outerReaderAccepted':mode!='dark-expanded'})
with (stage/'rf1116-cache-cleanup-plan.json').open('x',encoding='utf-8') as f:
    json.dump({'cacheCleanupEligible':True,'failedSamplesAccepted':False,'fullMaterialMatrixAccepted':False,'groups':groups},f,indent=2)
s=(stage/'cleanup-rf1115-owned.ps1').read_text()
s=s.replace('rf1115','rf1116').replace('RF-1115','RF-1116')
assert s.count('$validation.groups.Count -ne 2')==1
s=s.replace('$validation.groups.Count -ne 2','$validation.groups.Count -ne 7').replace('Two terminal verified owned groups','Seven terminal verified owned groups')
assert s.count('-ne 48')==2
s=s.replace('-ne 48','-ne 168').replace('forty-eight','one hundred sixty-eight')
with (stage/'cleanup-rf1116-owned.ps1').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Twenty-one terminal native samples verified for exact cleanup; original failed outer reader remains unaccepted')
