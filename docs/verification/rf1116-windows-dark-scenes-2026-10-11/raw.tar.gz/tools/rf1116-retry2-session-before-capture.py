"""Recheck only the caller session and desktop access; preserve older observations."""
from pathlib import Path
import ctypes,ctypes.wintypes as w,datetime,json,os
stage=Path(__file__).parent
k=ctypes.WinDLL('kernel32',use_last_error=True)
u=ctypes.WinDLL('user32',use_last_error=True)
a=ctypes.WinDLL('wtsapi32',use_last_error=True)
k.ProcessIdToSessionId.argtypes=[w.DWORD,ctypes.POINTER(w.DWORD)];k.ProcessIdToSessionId.restype=w.BOOL
k.WTSGetActiveConsoleSessionId.restype=w.DWORD
u.OpenInputDesktop.argtypes=[w.DWORD,w.BOOL,w.DWORD];u.OpenInputDesktop.restype=w.HANDLE
u.CloseDesktop.argtypes=[w.HANDLE];u.CloseDesktop.restype=w.BOOL
a.WTSQuerySessionInformationW.argtypes=[w.HANDLE,w.DWORD,ctypes.c_int,ctypes.POINTER(w.LPWSTR),ctypes.POINTER(w.DWORD)]
a.WTSQuerySessionInformationW.restype=w.BOOL;a.WTSFreeMemory.argtypes=[w.LPVOID]
session=w.DWORD();assert k.ProcessIdToSessionId(os.getpid(),ctypes.byref(session))
data={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'callerPid':os.getpid(),
      'callerSessionId':session.value,'activeConsoleSessionId':k.WTSGetActiveConsoleSessionId(),
      'userNamesRead':False,'pixelsRead':0,'inputEventsSent':0,'systemSettingsChanged':False}
buf=w.LPWSTR();size=w.DWORD()
if a.WTSQuerySessionInformationW(None,session.value,8,ctypes.byref(buf),ctypes.byref(size)):
    try:
        assert size.value==ctypes.sizeof(ctypes.c_int)
        value=ctypes.cast(buf,ctypes.POINTER(ctypes.c_int)).contents.value
        names=['Active','Connected','ConnectQuery','Shadow','Disconnected','Idle','Listen','Reset','Down','Init']
        assert value in range(len(names));data['connectionState']=value;data['connectionStateName']=names[value]
    finally:a.WTSFreeMemory(buf)
else:data['sessionQueryError']=ctypes.get_last_error()
desktop=u.OpenInputDesktop(0,False,1)
data['inputDesktopAvailable']=bool(desktop)
if desktop:assert u.CloseDesktop(desktop)
else:data['inputDesktopError']=ctypes.get_last_error()
with (stage/'rf1116-retry2-session-before-capture.json').open('x',encoding='utf-8',newline='\n') as out:out.write(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))
