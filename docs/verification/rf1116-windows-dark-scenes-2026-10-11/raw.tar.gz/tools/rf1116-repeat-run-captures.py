from pathlib import Path
import datetime, json, subprocess, sys, time
stage=Path(__file__).parent
checks=stage/'rf1116-checks-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert sys.argv[1:]==['--verified-new-build']
assert load(checks/'checks-complete.json')['success']
def run(name,command):
    start=time.monotonic()
    with (checks/(name+'.stdout.log')).open('xb') as out,(checks/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(command,cwd='D:/SoloSoul',stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        with (checks/(name+'.live.json')).open('x',encoding='utf-8') as f:json.dump({'pid':p.pid,'command':command},f,indent=2)
        print(name,'PID',p.pid,flush=True);code=p.wait()
    with (checks/(name+'.receipt.json')).open('x',encoding='utf-8') as f:
        json.dump({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':p.pid,'command':command,'exitCode':code,'elapsedSeconds':time.monotonic()-start},f,indent=2)
    assert code==0,(name,code)
run('repeat-session-before-capture',[sys.executable,'-X','utf8',str(stage/'rf1116-repeat-session-before-capture.py')])
session=load(stage/'rf1116-repeat-session-before-capture.json')
assert session['callerSessionId']==1 and session['connectionStateName']=='Active' and session['inputDesktopAvailable']
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
    option='--'+mode
    run('repeat-capture-'+mode,[sys.executable,'-X','utf8',str(stage/'run-rf1116-repeat-native-surfaces.py'),option])
    run('repeat-verify-'+mode,['node',str(stage/'verify-rf1116-repeat-native-surfaces.mjs'),option])
    run('repeat-render-'+mode,[sys.executable,'-X','utf8',str(stage/'render-rf1116-repeat-native-surfaces.py'),option])
print('Twelve complete real native journeys and exact state/pixel/restore gates terminal',flush=True)
