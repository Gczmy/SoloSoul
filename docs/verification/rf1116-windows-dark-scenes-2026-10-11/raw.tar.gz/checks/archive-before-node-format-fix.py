from pathlib import Path
import datetime,hashlib,io,json,re,shutil,tarfile
root=Path('D:/SoloSoul')
stage=Path(__file__).parent
checks=stage/'rf1116-checks-20261011'
out=root/'docs/verification/rf1116-windows-dark-scenes-2026-10-11'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
complete=load(checks/'checks-complete.json')
assert complete['success'] and complete['sourceUnchanged'] and complete['sourceCount']==1834
sources=load(checks/'sources.json')
assert len(sources)==1834
for name,digest in sources.items():assert sha(root/name)==digest,name
package=load(checks/'runtime-package.json')
assert sha(Path(package['exe']))==package['sha256']
assert len(package['resources'])==94
for item in package['resources']:assert sha(Path(item['source']))==sha(Path(item['copy']))==item['sha256']
cleanup=load(stage/'rf1116-cache-cleanup.json')
assert cleanup['preservedBytesVerified'] and cleanup['matchingOwnedIdentitiesLive']==0
assert cleanup['processesTerminatedByThisTool']==0 and len(cleanup['removedCachePaths'])==168
for item in cleanup['preservedVaultAndRootFiles']:assert sha(Path(item['path']))==item['sha256']
names=['format','prettier','javascript-syntax','node-native','clippy-native','tests-native','native-release-build']
receipts={name:load(checks/(name+'.receipt.json')) for name in names}
for name,receipt in receipts.items():assert receipt['exitCode']==0,name
counts=[{'passed':int(a),'failed':int(b),'ignored':int(c),'measured':int(d),'filtered':int(e)}
    for a,b,c,d,e in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',
    (checks/'tests-native.stdout.log').read_text(encoding='utf8'))]
assert len(counts)==1 and counts[0]['passed']==129 and counts[0]['failed']==0 and counts[0]['ignored']==0
node=(checks/'node-native.stdout.log').read_text(encoding='utf8')
assert '# pass 112' in node and '# fail 0' in node
parent=load(stage/'rf1115-checks-20261011/sources.json')
provenance=load(checks/'source-provenance.json')
changes=set(provenance['changed']);adds=set(provenance['added'])
assert set(parent).issubset(sources) and set(sources)-set(parent)==adds
assert {p for p in parent if parent[p]!=sources[p]}==changes
assert all(p.startswith('tauri/src-tauri/src/native_perf/') for p in changes|adds)
default_path=root/'docs/verification/rf1115-windows-sidebar-scenes-2026-10-11.json'
default=load(default_path);assert default['accepted']
assert sum(v['passed'] for name in ['tests-default','tests-default-remaining','tests-default-gui-doc'] for v in default['rustTestCounts'][name])==1871
for name in ['clippy-default','tests-default-remaining','tests-default-gui-doc']:assert default['checks'][name]['exitCode']==0
files={}
def add(p,name):
    assert name not in files and p.is_file() and not p.is_symlink()
    assert not (p.lstat().st_file_attributes&0x400)
    files[name]=p
for p in checks.iterdir():
    if p.is_file() and p.suffix in ['.json','.log','.md','.toml']:add(p,'checks/'+p.name)
for p in (checks/'capture-reader-before-fix').iterdir():add(p,'checks/capture-reader-before-fix/'+p.name)
for name in ['rf1116-run-checks.py','rf1116-session-user-reply.py','rf1116-session-user-reply.json',
    'rf1116-session-before-capture.py','rf1116-session-before-capture.json','rf1116-run-captures.py',
    'rf1116-prepare-verifier.py','run-rf1116-native-surfaces.py','verify-rf1116-native-surfaces.mjs',
    'render-rf1116-native-surfaces.py','rf1116-prepare-cleanup.py','cleanup-rf1116-owned.ps1',
    'rf1116-cache-cleanup-plan.json','rf1116-cache-cleanup-preflight.json','rf1116-cache-cleanup.json','rf1116-archive.py']:
    add(stage/name,'tools/'+name)
for name in ['rf1116-repeat-session-before-capture.py','rf1116-repeat-session-before-capture.json','rf1116-repeat-run-captures.py',
    'run-rf1116-repeat-native-surfaces.py','verify-rf1116-repeat-native-surfaces.mjs','render-rf1116-repeat-native-surfaces.py',
    'rf1116-retry2-session-before-capture.py','rf1116-retry2-session-before-capture.json','rf1116-retry2-run-captures.py',
    'run-rf1116-retry2-native-surfaces.py','verify-rf1116-retry2-native-surfaces.mjs','render-rf1116-retry2-native-surfaces.py',
    'verify-rf1116-failed-reader-for-cleanup.mjs']:
    add(stage/name,'tools/'+name)
for name in ['sdk_journey.rs','sdk_surface.rs','sdk_surface_appearance.rs','sdk_surface_appearance.js']:
    add(root/'tauri/src-tauri/src/native_perf'/name,'executed-source/'+name)
add(Path(package['helperSource']),'executed-helper/owned-window.rs')
add(default_path,'unchanged-default-evidence/'+default_path.name)
groups=[]
modes=['baseline','light-collapsed','dark-expanded','dark-collapsed']
for mode in modes:
    cap=stage/('ss-rf121-composed-window-rf1116-retry2-'+mode+'-20261011')
    validation=load(cap/'validation.json');review=load(cap/'visual-review.json')
    assert validation['accepted'] and len(validation['samples'])==3
    assert review['actualImagesInspected']==3 and review['fullMatrixAccepted'] is False
    assert load(cap/'actual100.receipt.json')['exitCode']==0
    for sample in validation['samples']:
        assert sample['state']['expanded'] is (not mode.endswith('collapsed'))
        assert sample['state']['theme']==('dark' if mode.startswith('dark-') else 'light')
    groups.append({'mode':mode,'actualCompleteJourneys':3,'actualCaptures':3,'validation':validation,'visualReview':review})
    for p in cap.iterdir():
        if p.is_file():add(p,mode+'/'+p.name)
    actual=cap/'actual100'
    for p in actual.iterdir():
        if p.is_file():add(p,mode+'/actual100/'+p.name)
        elif p.name in ['sample-001','sample-002','sample-003']:
            for leaf in p.iterdir():
                if leaf.is_file():add(leaf,mode+'/actual100/'+p.name+'/'+leaf.name)
initial=[]
for mode in ['baseline','light-collapsed','dark-expanded','repeat-baseline']:
    cap=stage/('ss-rf121-composed-window-rf1116-'+mode+'-20261011')
    outer=load(checks/('capture-'+mode+'.receipt.json' if mode!='repeat-baseline' else 'repeat-capture-baseline.receipt.json'))
    native=load(cap/'actual100/native-perf-sdk-journey-results.json')
    initial.append({'mode':mode,'outerExitCode':outer['exitCode'],'nativeGroupSuccess':native['success'],'samplesRequested':native['samplesRequested'],
        'samplesActuallyReported':len(native['samples']),'acceptanceTransferredToPrimary':False})
    for p in cap.iterdir():
        if p.is_file():add(p,'original-'+mode+'/'+p.name)
    for p in (cap/'actual100').iterdir():
        if p.is_file():add(p,'original-'+mode+'/actual100/'+p.name)
        elif p.name in ['sample-001','sample-002','sample-003']:
            for leaf in p.iterdir():
                if leaf.is_file():add(leaf,'original-'+mode+'/actual100/'+p.name+'/'+leaf.name)
assert initial[2]['outerExitCode']==1 and initial[2]['nativeGroupSuccess']
assert initial[3]['outerExitCode']==1 and not initial[3]['nativeGroupSuccess']
for p in (stage/'application-logs-rf1116').rglob('*'):
    if p.is_file():add(p,'application-logs/'+p.relative_to(stage/'application-logs-rf1116').as_posix())
out.mkdir(exist_ok=False)
(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf8')
standalone=[]
for mode in modes:
    cap=stage/('ss-rf121-composed-window-rf1116-retry2-'+mode+'-20261011')
    for row in load(cap/'rendered-captures.json'):
        p=Path(row['png']);assert sha(p)==row['pngSha256']
        target=out/(mode+'-sample-'+str(row['index']).zfill(3)+'.png')
        assert not target.exists();shutil.copy2(p,target);assert sha(target)==row['pngSha256']
        standalone.append({'path':target.relative_to(root).as_posix(),'sha256':row['pngSha256'],'mode':mode,'index':row['index']})
members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as archive:
    for name,p in sorted(files.items()):
        data=p.read_bytes();member=tarfile.TarInfo(name);member.size=len(data);member.mtime=int(p.stat().st_mtime)
        archive.addfile(member,io.BytesIO(data));members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(out/'raw.tar.gz','r:gz') as archive:
    assert archive.getnames()==[v['path'] for v in members]
    for v in members:
        data=archive.extractfile(v['path']).read()
        assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
index={'schemaVersion':1,'task':'RF-1116','archiveSha256':sha(out/'raw.tar.gz'),'archiveBytes':(out/'raw.tar.gz').stat().st_size,
    'members':members,'allMembersExtractedAndVerified':True,'excluded':['executables','DLLs','models','Vault entities','caches']}
with (out/'index.json').open('x',encoding='utf8',newline='\n') as f:json.dump(index,f,indent=2);f.write('\n')
report={'schemaVersion':1,'task':'RF-1116','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'accepted':True,
    'scope':'Windows owned real settings radio changes, stable dark expanded/collapsed frames and original preference/sidebar restore',
    'defaultProductionBuildChanged':False,'systemAppearanceModified':False,'sourceManifest':str(checks/'sources.json'),
    'sourceManifestSha256':sha(checks/'sources.json'),'sourceCount':1834,'sourceProvenance':provenance,'runtime':package,
    'checks':receipts,'rustTestCounts':counts,'nodeTests':112,
    'defaultWorkspaceEvidence':{'reused':True,'reason':'Only nondefault native_perf source changed; parent/current complete manifest comparison verified',
        'path':default_path.relative_to(root).as_posix(),'sha256':sha(default_path),'successfulTests':1871,'rerunThisTask':False},
    'groups':groups,'preservedOriginalCohorts':initial,'standalonePngs':standalone,'cleanup':cleanup,'rawArchive':out.relative_to(root).as_posix()+'/raw.tar.gz',
    'rawArchiveSha256':index['archiveSha256'],'rawMembers':len(members),'allRawMembersVerified':True,
    'nativeDwmAppearancePropertiesVerified':False,'performanceMetrics':None,'rf121Closed':False,
    'failedStartupCachesRetained':{'sample':'ss-rf121-composed-window-rf1116-repeat-baseline-20261011/actual100/sample-001',
        'reason':'Original unknown-descendant cleanup integrity incomplete; fresh checks exclude historical parent PID rows but do not prove every unrecorded descendant absent. Not deleted or accepted.'},
    'remaining':['DPI/resize','minimize/restore','transition sequences','long content','accessibility','other platforms']}
with out.with_suffix('.json').open('x',encoding='utf8',newline='\n') as f:json.dump(report,f,indent=2);f.write('\n')
print('Actual evidence archived and verified:',len(members),'members')
