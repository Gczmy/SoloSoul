import { createServer } from 'node:http';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { writeFile } from 'node:fs/promises';
const require = createRequire(new URL('../../../tauri/package.json', import.meta.url));
const { chromium } = require('@playwright/test');
const lf = 'window.cspProbe = true;\nwindow.cspValue = "public";\n';
const variants = { lf, crlf: lf.replaceAll('\n','\r\n'), cr: lf.replaceAll('\n','\r'),
  normalized: lf.replaceAll('\n','\r\n').replace(/\r\n?/g,'\n') };
const server = createServer((request,response) => {
  const name = request.url.slice(1);
  const script = variants[name];
  if (script === undefined) { response.writeHead(404); response.end(); return; }
  const hash = createHash('sha256').update(script).digest('base64');
  response.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':`default-src 'none'; script-src 'sha256-${hash}'`});
  response.end(`<html><head><script>${script}</script></head><body>Public CSP probe</body></html>`);
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser = await chromium.launch({channel:'chrome',headless:true});
const context = await browser.newContext();
const results = [];
try {
  for (const name of Object.keys(variants)) {
    const page = await context.newPage();
    const errors = [];
    page.on('console',message=>{if(message.type()==='error')errors.push(message.text());});
    await page.goto(`http://127.0.0.1:${server.address().port}/${name}`);
    const observed = await page.evaluate(()=>({executed:window.cspProbe===true,
      text:document.scripts[0].textContent,cr:document.scripts[0].textContent.includes('\r')}));
    const htmlHash = createHash('sha256').update(observed.text).digest('base64');
    const inputHash = createHash('sha256').update(variants[name]).digest('base64');
    results.push({name,executed:observed.executed,htmlContainsCR:observed.cr,inputHash,htmlHash,
                  hashEqual:inputHash===htmlHash,consoleErrors:errors});
    await page.close();
  }
  const accepted = results.every(row=>row.executed===(row.name==='lf'||row.name==='normalized'));
  await writeFile(new URL('./csp-line-ending-result.json',import.meta.url),JSON.stringify({accepted,results},null,2)+'\n');
  console.log(JSON.stringify({accepted,results:results.map(({name,executed,hashEqual})=>({name,executed,hashEqual}))}));
  if (!accepted) process.exitCode = 1;
} finally {
  await browser.close();
  await new Promise(resolve=>server.close(resolve));
}
