package com.solosoul.app

import android.app.Activity
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.widget.ImageView
import android.widget.TextView
import androidx.test.runner.lifecycle.ActivityLifecycleMonitorRegistry
import androidx.test.runner.lifecycle.Stage
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.view.KeyCharacterMap
import android.view.accessibility.AccessibilityNodeInfo
import android.view.PixelCopy
import android.os.Handler
import android.os.Looper
import android.os.Debug
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/** Fixed encrypted public datasets only. This proposal is not a native result.
 * Startup is Activity launch to usable password form and two committed frames:
 * it excludes runner/process launch and includes instrumentation overhead.
 * Memory is serial sampled main-process PSS, including this test runner.
 * Media/OCR, renderer memory, physical devices and other platforms stay pending.
 */
@RunWith(AndroidJUnit4::class)
class AndroidMediaPerfInstrumentedTest {
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val phases = JSONArray()
    private val touches = JSONArray()
    private val memory = JSONArray()
    private val sampling = AtomicBoolean(false)
    private val memoryFailure = AtomicReference<Throwable?>()
    private lateinit var evidence: File
    private lateinit var runId: String
    private var expectedAccount = ""
    private lateinit var report: JSONObject
    private var clockOrigin: Double? = null

    private fun webView(view: View): WebView? {
        if (view is WebView) return view
        if (view is ViewGroup) for (i in 0 until view.childCount) webView(view.getChildAt(i))?.let { return it }
        return null
    }

    private fun js(scenario: ActivityScenario<MainActivity>, expression: String): JSONObject {
        val done = CountDownLatch(1)
        var raw: String? = null
        scenario.onActivity { activity ->
            val view=webView(activity.window.decorView)
            if(view==null)done.countDown() else view.evaluateJavascript(expression) {
                raw = it; done.countDown()
            }
        }
        assertTrue("Actual target WebView must respond", done.await(3, TimeUnit.SECONDS))
        val parsed = JSONArray("[${raw ?: "null"}]").opt(0)
        return if (parsed is String && parsed.startsWith("{")) JSONObject(parsed) else JSONObject()
    }

    private fun waitFor(scenario: ActivityScenario<MainActivity>, expression: String,
                        began: Long = SystemClock.elapsedRealtimeNanos(),
                        predicate: (JSONObject) -> Boolean): JSONObject {
        var last = JSONObject()
        while (SystemClock.elapsedRealtimeNanos() - began < TimeUnit.SECONDS.toNanos(45)) {
            last = js(scenario, expression)
            if (predicate(last)) return last
            Thread.sleep(50)
        }
        throw AssertionError("Fixed public UI checkpoint unavailable: $last")
    }

    private fun painted(scenario:ActivityScenario<MainActivity>,budgetBegan:Long?=null) {
        val began=SystemClock.elapsedRealtimeNanos()
        val available=if(budgetBegan==null)TimeUnit.SECONDS.toNanos(10) else
            minOf(TimeUnit.SECONDS.toNanos(10),TimeUnit.SECONDS.toNanos(45)-(began-budgetBegan))
        val deadline=began+available
        val committed=CountDownLatch(1);var requested=false;var last=JSONObject()
        while(!requested && available>0 && SystemClock.elapsedRealtimeNanos()<deadline) {
            scenario.onActivity {activity ->
                val view=webView(activity.window.decorView)
                val resumed=ActivityLifecycleMonitorRegistry.getInstance().getLifecycleStageOf(activity)==Stage.RESUMED
                last=JSONObject().put("activity",activity.javaClass.name).put("resumed",resumed)
                    .put("attached",view?.isAttachedToWindow==true).put("shown",view?.isShown==true)
                    .put("focused",view?.hasWindowFocus()==true)
                if(resumed && view!=null && view.isAttachedToWindow && view.isShown && view.hasWindowFocus()) {
                    requested=true
                    view.postVisualStateCallback(SystemClock.elapsedRealtimeNanos(),object:WebView.VisualStateCallback() {
                        override fun onComplete(requestId:Long) {view.postOnAnimation {view.postOnAnimation {committed.countDown()}}}
                    })
                }
            }
            if(!requested)Thread.sleep(25)
        }
        val remaining=deadline-SystemClock.elapsedRealtimeNanos()
        val accepted=requested && remaining>0 && committed.await(remaining,TimeUnit.NANOSECONDS)
        val gates=report.optJSONArray("nativePaintReadiness")?:JSONArray().also {report.put("nativePaintReadiness",it)}
        gates.put(JSONObject().put("startedAtNs",began).put("finishedAtNs",SystemClock.elapsedRealtimeNanos())
            .put("availableNs",available).put("requested",requested).put("committed",accepted).put("state",last)
            .put("definition","exact resumed/attached/shown/focused Main WebView then real compositor/two frames; readiness and commit share original10s and enclosing45s budget"))
        assertTrue("Actual target focus and compositor must be ready within unchanged shared budget: $last",accepted)
    }

    private fun touchSnapshot(scenario: ActivityScenario<MainActivity>, selector: String): JSONObject =
        js(scenario, """(() => {
          const nodes=[...document.querySelectorAll(${JSONObject.quote(selector)})];
          const node=nodes.length===1?nodes[0]:null,r=node?.getBoundingClientRect();
          const x=r?r.x+r.width/2:null,y=r?r.y+r.height/2:null;
          const hit=r?document.elementFromPoint(x,y):null;
          return JSON.stringify({nodes:nodes.length,valid:!!node&&!node.disabled&&r.width>0&&r.height>0,
            x,y,width:r?.width,height:r?.height,viewportWidth:innerWidth,viewportHeight:innerHeight,
            visualViewportHeight:visualViewport?.height,visualViewportOffsetY:visualViewport?.offsetTop,
            hitIsTarget:!!hit&&(hit===node||node.contains(hit)),hitTag:hit?.tagName,
            hitInToast:!!hit?.closest('[data-toast-container]'),toastCount:document.querySelectorAll('[data-toast-container]').length,
            notificationHeight:document.querySelector('[data-shell-notifications]')?.getBoundingClientRect().height,
            path:location.pathname,search:location.search,
            frame:window.top===window,focused:document.hasFocus()});})()""")

    private fun readyTarget(scenario: ActivityScenario<MainActivity>, selector: String, began: Long): JSONObject {
        var prior:String?=null;var stableAt=0L;var stableFrames=0;var last=JSONObject()
        val fields=listOf("nodes","valid","x","y","width","height","viewportWidth","viewportHeight",
            "visualViewportHeight","visualViewportOffsetY","toastCount","notificationHeight","path","search","frame","focused","hitIsTarget","hitInToast")
        while(SystemClock.elapsedRealtimeNanos()-began<TimeUnit.SECONDS.toNanos(45)) {
            painted(scenario,began)
            last=touchSnapshot(scenario,selector)
            var nativeMatches=false
            scenario.onActivity { activity ->
                val view=requireNotNull(webView(activity.window.decorView))
                val viewportWidth=last.optDouble("viewportWidth",0.0)
                val viewportHeight=last.optDouble("viewportHeight",0.0)
                nativeMatches=viewportWidth>0 && viewportHeight>0 && view.hasWindowFocus() &&
                    kotlin.math.abs(view.height-view.width/viewportWidth*viewportHeight)<=2
            }
            val valid=last.optBoolean("valid") && last.optBoolean("frame") && last.optBoolean("focused") &&
                last.optBoolean("hitIsTarget") && !last.optBoolean("hitInToast") && nativeMatches
            val key=JSONArray(fields.map { last.opt(it) ?: JSONObject.NULL }).toString()
            val now=SystemClock.elapsedRealtimeNanos()
            if(!valid || key!=prior) { stableAt=now;stableFrames=0 }
            prior=if(valid)key else null
            if(valid) {
                stableFrames++
                if(stableFrames>=3 && now-stableAt>=TimeUnit.MILLISECONDS.toNanos(350)) {
                    return last.put("readinessMs",(now-began)/1_000_000.0).put("stableFrames",stableFrames)
                }
            }
            Thread.sleep(50)
        }
        throw AssertionError("Native target geometry/viewport/hit must settle within original budget: $last")
    }

    private fun touch(scenario: ActivityScenario<MainActivity>, selector: String,
                      began: Long = SystemClock.elapsedRealtimeNanos()) {
        val target=readyTarget(scenario,selector,began)
        val trace=JSONObject().put("selector",selector).put("before",target).put("nativeBeforeAtNs",SystemClock.elapsedRealtimeNanos())
        touches.put(trace);report.put("touches",touches)
        report.put("lastNativeTouchTarget",target)
        // Persist after dispatch: do not add file I/O between coordinate binding
        // and the single native touch pair.
        assertTrue("Actual fixed-target precondition: $target",target.getBoolean("valid") && target.getBoolean("frame") && target.getBoolean("focused"))
        scenario.onActivity { activity ->
            val view = requireNotNull(webView(activity.window.decorView))
            assertTrue(view.hasWindowFocus())
            trace.put("viewWidthPx",view.width).put("viewHeightPx",view.height)
                .put("nativeDispatchAtNs",SystemClock.elapsedRealtimeNanos())
            val scale=view.width/target.getDouble("viewportWidth")
            val x=(target.getDouble("x")*scale).toFloat()
            val y=(target.getDouble("y")*scale).toFloat()
            assertTrue(x>0 && y>0 && x<view.width && y<view.height)
            val down=SystemClock.uptimeMillis()
            for (action in listOf(MotionEvent.ACTION_DOWN,MotionEvent.ACTION_UP)) {
                val event=MotionEvent.obtain(down,SystemClock.uptimeMillis(),action,x,y,0)
                try { assertTrue(view.dispatchTouchEvent(event)) } finally { event.recycle() }
            }
        }
        trace.put("after",touchSnapshot(scenario,selector)).put("nativeAfterAtNs",SystemClock.elapsedRealtimeNanos())
        writeReport()
    }

    private fun captureScreenshot(scenario: ActivityScenario<MainActivity>, name: String) {
        val done=CountDownLatch(1);var bitmap:Bitmap?=null;var result=-1
        scenario.onActivity { activity ->
            val decor=activity.window.decorView
            bitmap=Bitmap.createBitmap(decor.width,decor.height,Bitmap.Config.ARGB_8888)
            PixelCopy.request(activity.window,requireNotNull(bitmap),{ code -> result=code;done.countDown() },Handler(Looper.getMainLooper()))
        }
        try {
            assertTrue("Diagnostic PixelCopy must finish",done.await(5,TimeUnit.SECONDS))
            assertEquals(PixelCopy.SUCCESS,result)
            File(evidence,"$name.png").outputStream().use { out -> assertTrue(requireNotNull(bitmap).compress(Bitmap.CompressFormat.PNG,100,out)) }
            report.put("lastScreenshot","$name.png")
        } finally { bitmap?.recycle() }
    }

    private fun typePublic(scenario: ActivityScenario<MainActivity>, selector: String, text: String) {
        require(text=="perf-baseline-only-password" || text=="needle")
        val began=SystemClock.elapsedRealtimeNanos()
        touch(scenario,selector,began)
        val expression="""JSON.stringify({focused:document.activeElement===document.querySelector(${JSONObject.quote(selector)}),
          empty:document.querySelector(${JSONObject.quote(selector)})?.value==='',
          activeTag:document.activeElement?.tagName,documentFocused:document.hasFocus()})"""
        val focus=waitFor(scenario,expression,began) {
            report.put("lastNativeInputFocus",it);writeReport()
            assertTrue("Public target must remain empty before native typing: $it",it.optBoolean("empty"))
            it.optBoolean("focused") && it.optBoolean("documentFocused")
        }
        assertTrue(focus.getBoolean("focused") && focus.getBoolean("empty"))
        instrumentation.sendStringSync(text)
        waitFor(scenario,"JSON.stringify({filled:document.querySelector(${JSONObject.quote(selector)})?.value===${JSONObject.quote(text)}})",began) { it.optBoolean("filled") }
    }

    private val page get() = """JSON.stringify({path:location.pathname,search:location.search,
      mounted:!!document.querySelector('#root>*'),startupGone:!document.querySelector('#startup-screen'),
      platform:document.documentElement.dataset.platform,
      home:!!document.querySelector('[data-testid="android-home"]'),
      count:document.querySelector('.android-overview-copy strong')?.textContent,
      password:!!document.querySelector('[data-login-method-region="password"] input'),
      enabled:!!document.querySelector('[data-login-password-submit]')&&!document.querySelector('[data-login-password-submit]').disabled,
      singleAccount:document.querySelectorAll('[data-login-account]').length===1 && !document.querySelector('[data-login-account] select'),
      publicAccountName:document.querySelector('[data-login-account] > div > div:first-child')?.textContent==='Performance Fixture',
      publicAccountId:document.querySelector('[data-login-account] > div > div:last-child')?.textContent===${JSONObject.quote(expectedAccount)},
      cards:document.querySelectorAll('[data-testid="workspace-object-card"]').length,
      firstPublicObject:[...document.querySelectorAll('[data-testid="workspace-object-card"]')].some(e=>e.textContent.includes('Record 00000000')),
      searchResults:document.querySelectorAll('[data-ui-card][role="button"]').length,
      publicSearch:document.querySelector('input')?.value==='needle',
      errors:document.querySelectorAll('[role="alert"]').length})"""

    private fun observer(scenario: ActivityScenario<MainActivity>, bind: Boolean = false): JSONObject {
        val root = js(scenario,"""(() => {
          const o=window.__SOLOSOUL_ANDROID_NATIVE_PERF__;
          const d=Object.getOwnPropertyDescriptor(window.__TAURI_INTERNALS__,'invoke');
          return JSON.stringify({mainFrame:window.top===window,frames:document.querySelectorAll('iframe,frame').length,
            invokeReadonly:d?.writable===false&&d?.configurable===false,
            snapshot:o?o.${if(bind) "bind('$runId')" else "snapshot()"}:null});})()""")
        assertTrue(root.getBoolean("mainFrame") && root.getBoolean("invokeReadonly"))
        assertEquals(0,root.getInt("frames"))
        val observed=root.getJSONObject("snapshot")
        assertEquals("android-native-ipc-transport-observer",observed.getString("scope"))
        assertEquals(runId,observed.getString("runId")); assertTrue(observed.getBoolean("valid"))
        assertEquals(0,observed.getJSONArray("invalidReasons").length())
        val origin=observed.getDouble("timeOriginMs")
        if(clockOrigin==null)clockOrigin=origin else assertEquals(clockOrigin!!,origin,0.0)
        assertEquals(observed.getInt("observedCount"),observed.getJSONArray("commands").length())
        val commands=observed.getJSONArray("commands")
        for(i in 0 until commands.length()) {
            val command=commands.getJSONObject(i)
            assertEquals(setOf("command","transport","atMs"),command.keys().asSequence().toSet())
            assertTrue(Regex("[A-Za-z0-9_.:|/-]{1,128}").matches(command.getString("command")))
            assertTrue(command.getString("transport") in setOf("android-java-bridge","android-channel-fetch"))
            assertTrue(command.getDouble("atMs")>=observed.getDouble("installedAtMs") && command.getDouble("atMs")<=observed.getDouble("atMs"))
        }
        return observed
    }

    private fun phase(scenario: ActivityScenario<MainActivity>, name: String, began: Long,
                      before: JSONObject?, action: () -> Unit) {
        val row=JSONObject().put("name",name).put("nativeStartedAtNs",began).put("success",false)
        phases.put(row)
        try {
            action();painted(scenario)
            val after=observer(scenario, before==null)
            val commands=after.getJSONArray("commands")
            val prefix=before?.getJSONArray("commands")
            if(prefix!=null) {
                assertTrue(commands.length()>=prefix.length())
                for(i in 0 until prefix.length()) assertEquals(prefix.getJSONObject(i).toString(),commands.getJSONObject(i).toString())
            }
            row.put("ipcStart",prefix?.length() ?: 0).put("ipcEnd",commands.length())
                .put("documentFromAtMs",before?.getDouble("atMs") ?: after.getDouble("installedAtMs"))
                .put("documentToAtMs",after.getDouble("atMs"))
                .put("transportAttempts",commands.length()-(prefix?.length() ?: 0))
                .put("observer",after).put("ui",js(scenario,page)).put("success",true)
        } catch(error: Throwable) {
            row.put("errorClass",error.javaClass.name)
            try {
                row.put("startupDiagnostics",js(scenario,"""(() => {
                  const d=window.__SOLOSOUL_STARTUP__?.diagnostic?.();
                  const internals=window.__TAURI_INTERNALS__;
                  const descriptor=internals&&Object.getOwnPropertyDescriptor(internals,'invoke');
                  const bridge=Object.getOwnPropertyDescriptor(window,'ipc');
                  const observer=window.__SOLOSOUL_ANDROID_NATIVE_PERF__;
                  return JSON.stringify({startup:d||null,
                    screenState:document.querySelector('#startup-screen')?.dataset.state||null,
                    screenReady:document.querySelector('#startup-screen')?.dataset.ready||null,
                    hasInternals:!!internals,invokeType:typeof internals?.invoke,
                    invokeReadonly:descriptor?.writable===false&&descriptor?.configurable===false,
                    hasBridge:!!window.ipc,postMessageType:typeof window.ipc?.postMessage,
                    bridgeWritable:bridge?.writable===true,bridgeConfigurable:bridge?.configurable===true,
                    observerPresent:!!observer,observerSnapshotType:typeof observer?.snapshot,
                    platform:window.__TAURI_OS_PLUGIN_INTERNALS__?.platform||null});})()"""))
            } catch(diagnostic:Throwable) { row.put("startupDiagnosticErrorClass",diagnostic.javaClass.name) }
            try {
                js(scenario,"""(() => {
                  const slot='__RF312_STARTUP_FAILURE_RPC__';
                  if(window[slot]) return JSON.stringify({started:false});
                  const result={done:false};window[slot]=result;
                  Promise.resolve().then(()=>window.__TAURI_INTERNALS__.invoke('check_has_account')).then(value=>{
                    result.done=true;result.resolved=true;result.valueType=typeof value;
                    if(typeof value==='boolean') result.hasAccount=value;
                  },error=>{
                    result.done=true;result.resolved=false;result.errorType=typeof error;
                    let text='unavailable';try{text=String(error);}catch{}
                    result.messageClass=/invoke.?key|token|password|secret/i.test(text)?'sensitive-marker':
                      /allow|denied|permission|forbidden/i.test(text)?'permission':
                      /not.*found|unknown.*command/i.test(text)?'unknown-command':'other';
                    if(result.messageClass!=='sensitive-marker')
                      result.message=text.slice(0,384).replace(/[a-f0-9]{32,}/gi,'[redacted]');
                  });return JSON.stringify({started:true});})()""")
                val diagnosticBegan=SystemClock.elapsedRealtime()
                var reply=JSONObject()
                while(SystemClock.elapsedRealtime()-diagnosticBegan<3000) {
                    reply=js(scenario,"JSON.stringify(window.__RF312_STARTUP_FAILURE_RPC__||{})")
                    if(reply.optBoolean("done")) break
                    Thread.sleep(100)
                }
                row.put("startupRpcDiagnostics",reply)
            } catch(diagnostic:Throwable) { row.put("startupRpcDiagnosticErrorClass",diagnostic.javaClass.name) }
            try {
                row.put("failureUi",js(scenario,page)).put("failureObserver",observer(scenario))
                captureScreenshot(scenario,"failure-$name")
            } catch(diagnostic:Throwable) { row.put("diagnosticErrorClass",diagnostic.javaClass.name) }
            throw error
        } finally {
            val end=SystemClock.elapsedRealtimeNanos()
            row.put("nativeFinishedAtNs",end).put("durationMs",(end-began)/1_000_000.0)
            writeReport()
        }
    }

    private fun writeReport() {
        report.put("phases",phases)
        synchronized(memory) { report.put("memorySamples",JSONArray(memory.toString())) }
        File(evidence,"report.json").writeText(report.toString(2))
    }

    private val mediaPage = """(() => {
      const p=document.querySelector('[data-testid="attachment-preview-overlay"]');
      const c=p?.querySelector('[data-testid="attachment-preview-content"]');
      const image=c?.querySelector('img');const embed=c?.querySelector('embed');
      return JSON.stringify({preview:!!p,knownAttachments:['ocr_test.png','text_only.pdf','scanned.pdf','preview.txt'].filter(n=>document.querySelector('input[type="checkbox"][aria-label="'+n+'"]')).length,
        imageLoaded:!!image&&image.complete&&image.naturalWidth>0&&image.naturalHeight>0,
        imageWidth:image?.naturalWidth,imageHeight:image?.naturalHeight,
        knownText:c?.querySelector('pre')?.textContent==='RF-312 public synthetic attachment preview.\nHello SoloSoul 1234567890.\n',
        pdfEmbed:!!embed,pdfData:embed?.getAttribute('src')?.startsWith('data:application/pdf'),
        previewError:!!p?.textContent.includes('Failed to load preview.'),
        contentRect:c?{x:c.getBoundingClientRect().x,y:c.getBoundingClientRect().y,width:c.getBoundingClientRect().width,height:c.getBoundingClientRect().height}:null});})()"""

    private fun mediaScreenshot(scenario: ActivityScenario<MainActivity>, name: String) {
        captureScreenshot(scenario,"diagnostic-$name")
        report.put("lastDiagnosticScreenshot","diagnostic-$name.png")
    }


    private fun resumedPdf(): Activity? {
        var result: Activity? = null
        instrumentation.runOnMainSync {
            val resumed=ActivityLifecycleMonitorRegistry.getInstance().getActivitiesInStage(Stage.RESUMED)
                .filter { it.javaClass.name=="com.solosoul.app.PdfPreviewActivity" }
            check(resumed.size<=1)
            result=resumed.singleOrNull()
        }
        return result
    }

    private fun pdfSnapshot(activity: Activity, fileName: String): JSONObject {
        val state=JSONObject()
        instrumentation.runOnMainSync {
            assertEquals("com.solosoul.app",activity.packageName)
            assertEquals(instrumentation.targetContext.applicationInfo.uid,activity.applicationInfo.uid)
            val decor=activity.window.decorView
            fun id(name:String)=activity.resources.getIdentifier(name,"id",activity.packageName).also { check(it!=0) }
            val view=activity.findViewById<ImageView>(id("pdfPageImage"))
            val bitmap=(view.drawable as? BitmapDrawable)?.bitmap
            state.put("activity",activity.javaClass.name).put("sameUid",true)
                .put("focused",decor.hasWindowFocus()).put("attached",decor.isAttachedToWindow)
                .put("titleMatches",activity.findViewById<TextView>(id("pdfTitle")).text.toString()==fileName)
                .put("pageInfo",activity.findViewById<TextView>(id("pdfPageInfo")).text.toString())
                .put("viewWidth",view.width).put("viewHeight",view.height)
                .put("shown",view.isShown).put("bitmapWidth",bitmap?.width?:0).put("bitmapHeight",bitmap?.height?:0)
            var ink=0;var light=0;var opaque=0
            if(bitmap!=null && !bitmap.isRecycled) {
                val pixels=IntArray(bitmap.width*bitmap.height)
                bitmap.getPixels(pixels,0,bitmap.width,0,0,bitmap.width,bitmap.height)
                for(p in pixels) {
                    if(Color.alpha(p)>0) {
                        opaque++
                        if(Color.red(p)<100 && Color.green(p)<100 && Color.blue(p)<100)ink++
                        if(Color.red(p)>240 && Color.green(p)>240 && Color.blue(p)>240)light++
                    }
                }
            }
            state.put("inkPixels",ink).put("lightPixels",light).put("nonTransparentPixels",opaque)
        }
        return state
    }

    private fun pdfScreenshot(activity:Activity,name:String): JSONObject {
        val frames=CountDownLatch(1)
        instrumentation.runOnMainSync {
            val decor=activity.window.decorView
            assertTrue(decor.isAttachedToWindow && decor.hasWindowFocus())
            decor.postOnAnimation { decor.postOnAnimation { frames.countDown() } }
        }
        assertTrue("Actual native PDF must commit two frames",frames.await(5,TimeUnit.SECONDS))
        val done=CountDownLatch(1);var code=-1;var capture:Bitmap?=null
        instrumentation.runOnMainSync {
            check(activity.window.decorView.hasWindowFocus())
            val view=activity.window.decorView
            capture=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888)
            PixelCopy.request(activity.window,requireNotNull(capture),{ result -> code=result;done.countDown() },Handler(Looper.getMainLooper()))
        }
        try {
            assertTrue(done.await(5,TimeUnit.SECONDS));assertEquals(PixelCopy.SUCCESS,code)
            File(evidence,"$name.png").outputStream().use { check(requireNotNull(capture).compress(Bitmap.CompressFormat.PNG,100,it)) }
            var proof=JSONObject()
            instrumentation.runOnMainSync {
                val view=activity.findViewById<ImageView>(activity.resources.getIdentifier("pdfPageImage","id",activity.packageName))
                val position=IntArray(2);view.getLocationInWindow(position)
                val bitmap=requireNotNull(capture);var dark=0;var light=0
                val left=position[0].coerceIn(0,bitmap.width);val top=position[1].coerceIn(0,bitmap.height)
                val right=(position[0]+view.width).coerceIn(0,bitmap.width);val bottom=(position[1]+view.height).coerceIn(0,bitmap.height)
                for(y in top until bottom)for(x in left until right) {
                    val p=bitmap.getPixel(x,y)
                    if(Color.red(p)<200&&Color.green(p)<200&&Color.blue(p)<200)dark++
                    if(Color.red(p)>240&&Color.green(p)>240&&Color.blue(p)>240)light++
                }
                proof=JSONObject().put("screenshot",name+".png").put("actualWindowPageDarkPixels",dark).put("actualWindowPageWhitePixels",light)
                    .put("left",left).put("top",top).put("right",right).put("bottom",bottom)
            }
            report.put("lastPdfWindowPixels",proof);writeReport()
            assertTrue("Actual displayed PDF page must contain text/image ink: $proof",proof.getInt("actualWindowPageDarkPixels")>100)
            assertTrue("Actual displayed PDF page must have a light background: $proof",proof.getInt("actualWindowPageWhitePixels")>100)
            return proof

        } finally { capture?.recycle() }
    }

    private fun nativePdfPreview(scenario:ActivityScenario<MainActivity>,fileName:String,plainSha:String) {
        touch(scenario,"button[aria-label='Attachment actions: $fileName']")
        waitFor(scenario,"JSON.stringify({menu:!!document.querySelector('.android-attachment-menu-actions')})") { it.optBoolean("menu") }
        touch(scenario,".android-attachment-menu-actions > button:first-child")
        val began=SystemClock.elapsedRealtimeNanos();var last=JSONObject();var target:Activity?=null
        while(SystemClock.elapsedRealtimeNanos()-began<TimeUnit.SECONDS.toNanos(45)) {
            val activity=resumedPdf()
            if(activity!=null) {
                last=pdfSnapshot(activity,fileName)
                if(last.optBoolean("focused") && last.optBoolean("attached") && last.optBoolean("shown") && last.optBoolean("titleMatches") &&
                    last.optString("pageInfo")==(if(fileName=="text_only.pdf") "1 / 2" else "1 / 1") && last.optInt("bitmapWidth")>100 && last.optInt("bitmapHeight")>100 &&
                    last.optInt("inkPixels")>100) {target=activity;break}
            } else {
                // Observe only the resumed original MainActivity; do not query a paused scenario.
                var mainResumed=false
                instrumentation.runOnMainSync {
                    mainResumed=ActivityLifecycleMonitorRegistry.getInstance().getActivitiesInStage(Stage.RESUMED)
                        .any { it.javaClass.name=="com.solosoul.app.MainActivity" }
                }
                if(mainResumed) {
                    val failure=js(scenario,"""JSON.stringify({knownOpenError:document.body.textContent.includes('Cannot open file.')||document.body.textContent.includes('无法打开文件'),knownFile:document.body.textContent.includes('${fileName}')})""")
                    if(failure.optBoolean("knownOpenError")) {
                        report.put("pdfOpenFailure",failure)
                        captureScreenshot(scenario,"failure-native-pdf-$fileName")
                        throw AssertionError("Product attachment_open rejected known public PDF: $fileName")
                    }
                }
            }
            Thread.sleep(50)
        }
        report.put("lastPdfSnapshot",last);writeReport()
        val activity=target?:throw AssertionError("Native PDF Activity did not display a nonempty page: $last")
        val path=activity.intent.getStringExtra("pdf_path")?:error("Missing product PDF path")
        val plain=File(path)
        check(plain.isFile)
        val actualSha=java.security.MessageDigest.getInstance("SHA-256").digest(plain.readBytes()).joinToString("") { "%02x".format(it.toInt() and 255) }
        assertEquals("Product decrypted PDF must be exact public fixture",plainSha,actualSha)
        last.put("plaintextSha256",actualSha).put("knownPublicPlaintextVerified",true)
        last.put("windowPixels",pdfScreenshot(activity,"diagnostic-native-$fileName"))
        instrumentation.runOnMainSync {
            val view=activity.findViewById<ImageView>(activity.resources.getIdentifier("pdfPageImage","id",activity.packageName))
            val bitmap=(view.drawable as BitmapDrawable).bitmap
            File(evidence,"diagnostic-bitmap-$fileName.png").outputStream().use { check(bitmap.compress(Bitmap.CompressFormat.PNG,100,it)) }
        }
        if(fileName=="text_only.pdf") {
            instrumentation.runOnMainSync {
                val button=activity.findViewById<View>(activity.resources.getIdentifier("pdfNextButton","id",activity.packageName))
                check(button.isShown && button.isEnabled && button.hasWindowFocus())
                val down=SystemClock.uptimeMillis();val pos=IntArray(2);button.getLocationInWindow(pos)
                for(action in listOf(MotionEvent.ACTION_DOWN,MotionEvent.ACTION_UP)) {
                    val event=MotionEvent.obtain(down,SystemClock.uptimeMillis(),action,pos[0]+button.width/2f,pos[1]+button.height/2f,0)
                    try { check(activity.window.decorView.dispatchTouchEvent(event)) } finally { event.recycle() }
                }
            }
            val beganNext=SystemClock.elapsedRealtimeNanos();var next=JSONObject()
            while(SystemClock.elapsedRealtimeNanos()-beganNext<TimeUnit.SECONDS.toNanos(45)) {
                next=pdfSnapshot(activity,fileName)
                if(next.optString("pageInfo")=="2 / 2" && next.optInt("inkPixels")>100)break
                Thread.sleep(50)
            }
            assertEquals("2 / 2",next.getString("pageInfo"))
            next.put("windowPixels",pdfScreenshot(activity,"diagnostic-native-second-$fileName"))
            last.put("secondPage",next)
        }
        instrumentation.runOnMainSync {
            val button=activity.findViewById<View>(activity.resources.getIdentifier("pdfCloseButton","id",activity.packageName))
            assertTrue(button.isShown && button.isEnabled && button.hasWindowFocus())
            val down=SystemClock.uptimeMillis();val decor=activity.window.decorView
            val pos=IntArray(2);button.getLocationInWindow(pos)
            val x=pos[0]+button.width/2f;val y=pos[1]+button.height/2f
            for(action in listOf(MotionEvent.ACTION_DOWN,MotionEvent.ACTION_UP)) {
                val event=MotionEvent.obtain(down,SystemClock.uptimeMillis(),action,x,y,0)
                try { check(decor.dispatchTouchEvent(event)) } finally { event.recycle() }
            }
        }
        val returnBegan=SystemClock.elapsedRealtimeNanos()
        while(resumedPdf()!=null && SystemClock.elapsedRealtimeNanos()-returnBegan<TimeUnit.SECONDS.toNanos(45))Thread.sleep(50)
        assertNull("Product close returns from exact PDF activity",resumedPdf())
        waitFor(scenario,mediaPage) { !it.optBoolean("preview") && it.optInt("knownAttachments")==4 }
        report.put("nativePdf-$fileName",last.put("closedToOriginalAttachmentList",true))
    }

    private val textPage = """(() => {
      const e=document.querySelector('[data-testid="attachment-preview-content"] pre');
      const s=e?getComputedStyle(e):null;const r=e?.getBoundingClientRect();
      return JSON.stringify({knownText:e?.textContent==='RF-312 public synthetic attachment preview.\nHello SoloSoul 1234567890.\n',
        foreground:s?.color,fontSize:s?.fontSize,opacity:s?.opacity,visibility:s?.visibility,
        viewportWidth:innerWidth,rect:r?{x:r.x,y:r.y,width:r.width,height:r.height}:null});})()"""

    private fun textPixels(scenario:ActivityScenario<MainActivity>,name:String,state:JSONObject):JSONObject {
        assertTrue(state.getBoolean("knownText"))
        val color=Regex("[0-9.]+").findAll(state.getString("foreground")).map { it.value.toDouble().toInt() }.toList()
        check(color.size>=3 && color.take(3).all { it in 0..255 })
        val rect=state.getJSONObject("rect")
        var scale=0.0;val position=IntArray(2)
        scenario.onActivity { activity ->
            val view=requireNotNull(webView(activity.window.decorView));check(view.isShown && view.hasWindowFocus())
            view.getLocationInWindow(position);scale=view.width/state.getDouble("viewportWidth")
        }
        val bitmap=requireNotNull(BitmapFactory.decodeFile(File(evidence,"$name.png").path))
        try {
            val left=(position[0]+rect.getDouble("x")*scale).toInt().coerceIn(0,bitmap.width)
            val top=(position[1]+rect.getDouble("y")*scale).toInt().coerceIn(0,bitmap.height)
            val right=(position[0]+(rect.getDouble("x")+rect.getDouble("width"))*scale).toInt().coerceIn(0,bitmap.width)
            val bottom=(position[1]+(rect.getDouble("y")+rect.getDouble("height"))*scale).toInt().coerceIn(0,bitmap.height)
            check(right>left && bottom>top)
            var near=0
            for(y in top until bottom)for(x in left until right) {
                val p=bitmap.getPixel(x,y)
                if(Color.alpha(p)>=200 && kotlin.math.abs(Color.red(p)-color[0])<=32 &&
                    kotlin.math.abs(Color.green(p)-color[1])<=32 && kotlin.math.abs(Color.blue(p)-color[2])<=32)near++
            }
            return JSONObject().put("screenshot",name+".png").put("knownText",true).put("nearForegroundPixels",near)
                .put("left",left).put("top",top).put("right",right).put("bottom",bottom).put("style",state)
        } finally { bitmap.recycle() }
    }

    private fun nativePickerNodes():List<AccessibilityNodeInfo> {
        val root=instrumentation.uiAutomation.rootInActiveWindow?:return emptyList()
        val pkg=root.packageName?.toString()
        if(pkg !in setOf("com.android.documentsui","com.google.android.documentsui"))return emptyList()
        val nodes=ArrayList<AccessibilityNodeInfo>();val queue=java.util.ArrayDeque<AccessibilityNodeInfo>();queue.add(root)
        while(queue.isNotEmpty()) {
            val node=queue.removeFirst();nodes.add(node);check(nodes.size<=2048)
            for(i in 0 until node.childCount)node.getChild(i)?.let {queue.add(it)}
        }
        return nodes
    }

    private fun pickerNodeMetadata(node:AccessibilityNodeInfo):JSONObject {
        val rect=Rect();node.getBoundsInScreen(rect)
        return JSONObject().put("class",node.className?.toString()).put("resourceId",node.viewIdResourceName)
            .put("clickable",node.isClickable).put("selected",node.isSelected).put("enabled",node.isEnabled)
            .put("bounds",JSONArray(listOf(rect.left,rect.top,rect.right,rect.bottom)))
            .put("actions",JSONArray(node.actionList.map {it.id}))
    }

    private fun pickerNodeParents(node:AccessibilityNodeInfo):JSONArray {
        val out=JSONArray();var parent=node.parent
        while(parent!=null && out.length()<5) {
            val current=parent;out.put(pickerNodeMetadata(current));parent=current.parent;current.recycle()
        }
        parent?.recycle();return out
    }

    private fun isPickerRootsListDescendant(node:AccessibilityNodeInfo):Boolean {
        var parent=node.parent;var depth=0
        try {
            while(parent!=null && depth++<6) {
                if(parent.viewIdResourceName?.endsWith("/roots_list")==true)return true
                val previous=parent;parent=previous.parent;previous.recycle()
            }
            return false
        }finally {parent?.recycle()}
    }

    private fun pickerMatch(kind:String,fileName:String):Rect? {
        val nodes=nativePickerNodes()
        try {
            val matches=nodes.filter { n -> n.isVisibleToUser && n.isEnabled && when(kind) {
                "file" -> !n.isEditable && n.viewIdResourceName?.endsWith("/preview_icon")!=true &&
                    (n.text?.toString()==fileName || n.contentDescription?.toString()?.contains(fileName)==true)
                "search" -> n.isClickable && (n.contentDescription?.toString()=="Search" || n.viewIdResourceName?.endsWith("/menu_search")==true)
                "roots" -> n.isClickable && n.contentDescription?.toString()=="Show roots"
                "downloads" -> !n.isEditable && n.text?.toString()=="Downloads" && n.viewIdResourceName=="android:id/title" && isPickerRootsListDescendant(n)
                "input" -> n.isEditable
                "focused-input" -> n.isEditable && n.isFocused
                else -> false
            } }
            val trace=JSONObject().put("kind",kind).put("documentsUiBound",nodes.isNotEmpty()).put("matchingKnownTarget",matches.size)
            trace.put("matchedKnownNodes",JSONArray(matches.map { n -> JSONObject().put("class",n.className?.toString())
                .put("resourceId",n.viewIdResourceName).put("editable",n.isEditable).put("clickable",n.isClickable)
                .put("exactFilenameInText",n.text?.toString()==fileName).put("knownFilenameInDescription",n.contentDescription?.toString()?.contains(fileName)==true)
                .put("node",pickerNodeMetadata(n)).put("parents",pickerNodeParents(n)) }))
            trace.put("editableClasses",JSONArray(nodes.filter {it.isEditable}.map {it.className?.toString()}))
                .put("focusedClasses",JSONArray(nodes.filter {it.isFocused}.map {it.className?.toString()}))
            report.put("lastNativePickerTarget",trace);writeReport()
            if(matches.size!=1)return null
            val bounds=Rect();matches.single().getBoundsInScreen(bounds)
            return bounds.takeIf { it.width()>0 && it.height()>0 }
        } finally { nodes.forEach {it.recycle()} }
    }

    private fun captureNativePicker(name:String) {
        val root=instrumentation.uiAutomation.rootInActiveWindow?:return
        try {
            check(root.packageName?.toString() in setOf("com.android.documentsui","com.google.android.documentsui"))
            val bitmap=requireNotNull(instrumentation.uiAutomation.takeScreenshot())
            try {File(evidence,name+".png").outputStream().use {check(bitmap.compress(Bitmap.CompressFormat.PNG,100,it))}}finally {bitmap.recycle()}
        } finally {root.recycle()}
    }

    private var pickerPointerMode="finger"

    private fun pickerEvent(down:Long,action:Int,target:Rect):MotionEvent {
        val properties=MotionEvent.PointerProperties().apply {
            id=0;toolType=if(pickerPointerMode=="finger")MotionEvent.TOOL_TYPE_FINGER else MotionEvent.TOOL_TYPE_UNKNOWN
        }
        val coordinates=MotionEvent.PointerCoords().apply {
            x=target.centerX().toFloat();y=target.centerY().toFloat();pressure=1f;size=1f
        }
        return MotionEvent.obtain(down,SystemClock.uptimeMillis(),action,1,arrayOf(properties),arrayOf(coordinates),
            0,0,1f,1f,0,0,android.view.InputDevice.SOURCE_TOUCHSCREEN,0)
    }

    private fun pickerTap(kind:String,fileName:String,began:Long):Long {
        var bounds:Rect?=null;var signature:String?=null;var stableSince=0L;var observations=0
        val gateStarted=SystemClock.elapsedRealtimeNanos()
        while(SystemClock.elapsedRealtimeNanos()-began<TimeUnit.SECONDS.toNanos(45)) {
            val current=pickerMatch(kind,fileName)
            if(current!=null) {
                val bitmap=requireNotNull(instrumentation.uiAutomation.takeScreenshot())
                val fingerprint=try {
                    check(current.left>=0 && current.top>=0 && current.right<=bitmap.width && current.bottom<=bitmap.height)
                    val hash=java.security.MessageDigest.getInstance("SHA-256")
                    for(y in current.top until current.bottom step 4)for(x in current.left until current.right step 4) {
                        val p=bitmap.getPixel(x,y)
                        hash.update(byteArrayOf((p ushr 24).toByte(),(p ushr 16).toByte(),(p ushr 8).toByte(),p.toByte()))
                    }
                    hash.digest().joinToString("") { "%02x".format(it.toInt() and 255) }
                }finally {bitmap.recycle()}
                val next="${current.flattenToString()}:$fingerprint"
                val now=SystemClock.elapsedRealtimeNanos()
                if(next!=signature) {signature=next;stableSince=now;observations=1}else observations++
                val fresh=pickerMatch(kind,fileName)
                if(fresh==current && observations>=3 && now-stableSince>=TimeUnit.MILLISECONDS.toNanos(350)) {
                    bounds=current
                    report.put("lastNativePickerReadiness",JSONObject().put("kind",kind).put("committedObservations",observations)
                        .put("stableMs",(now-stableSince)/1_000_000.0).put("gateMs",(now-gateStarted)/1_000_000.0)
                        .put("targetPixelsSha256",fingerprint).put("bounds",current.flattenToString())
                        .put("definition","same unique known target bounds and actual native screenshot target pixels, >=3 observations and >=350ms; within original45s budget"))
                    writeReport();break
                }
            }else {signature=null;observations=0}
            Thread.sleep(100)
        }
        if(bounds==null) {captureNativePicker("failure-picker-$kind");throw AssertionError("Known native document picker target unavailable: $kind")}
        val target=requireNotNull(bounds)
        if(kind=="file") {
            captureNativePicker("diagnostic-picker-known-file")
            bounds=pickerMatch(kind,fileName)
            check(bounds!=null && bounds==target)
        }
        val display=instrumentation.targetContext.resources.displayMetrics
        check(target.centerX() in 1 until display.widthPixels && target.centerY() in 1 until display.heightPixels)
        val oldEvent=MotionEvent.obtain(SystemClock.uptimeMillis(),SystemClock.uptimeMillis(),MotionEvent.ACTION_DOWN,
            target.centerX().toFloat(),target.centerY().toFloat(),0)
        oldEvent.source=android.view.InputDevice.SOURCE_TOUCHSCREEN
        try {
            report.put("legacySimpleMotionEvent",JSONObject().put("toolType",oldEvent.getToolType(0)).put("source",oldEvent.source)
                .put("pointerId",oldEvent.getPointerId(0)).put("pointerCount",oldEvent.pointerCount)
                .put("pressure",oldEvent.pressure).put("size",oldEvent.size).put("deviceId",oldEvent.deviceId))
        }finally {oldEvent.recycle()}
        val down=SystemClock.uptimeMillis();val selected=SystemClock.elapsedRealtimeNanos()
        val events=report.optJSONArray("nativePickerInputEvents")?:JSONArray().also {report.put("nativePickerInputEvents",it)}
        val pair=JSONArray()
        for(action in listOf(MotionEvent.ACTION_DOWN,MotionEvent.ACTION_UP)) {
            val event=pickerEvent(down,action,target)
            try {
                val injected=instrumentation.uiAutomation.injectInputEvent(event,true)
                val trace=JSONObject().put("kind",kind).put("action",action).put("injected",injected)
                    .put("x",event.x).put("y",event.y).put("downTime",event.downTime).put("eventTime",event.eventTime)
                    .put("source",event.source).put("toolType",event.getToolType(0)).put("pointerId",event.getPointerId(0))
                    .put("pointerCount",event.pointerCount).put("pressure",event.pressure).put("size",event.size).put("deviceId",event.deviceId)
                    .put("displayWidth",display.widthPixels).put("displayHeight",display.heightPixels)
                    .put("target",report.getJSONObject("lastNativePickerTarget")).put("readiness",report.getJSONObject("lastNativePickerReadiness"))
                pair.put(trace);events.put(trace);check(injected)
            }finally {event.recycle()}
            if(action==MotionEvent.ACTION_DOWN)Thread.sleep(100)
        }
        if(kind=="file")report.put("nativePickerFileAction",JSONObject()
            .put("action",if(pickerPointerMode=="finger")"NATIVE_FINGER_TAP" else "NATIVE_UNKNOWN_POINTER_TAP")
            .put("accepted",true).put("nativeAtNs",selected).put("pointerMode",pickerPointerMode).put("events",pair)
            .put("definition","one real native injected DOWN/UP coordinate pair on exact public file; explicit pointer tool type; no accessibility click, supplied URI or backend call"))
        // Persist only after UP: file I/O must not stretch the native press.
        writeReport()
        return selected
    }

    private fun choosePublicNativeImage(fileName:String):Long {
        val began=SystemClock.elapsedRealtimeNanos()
        if(pickerMatch("file",fileName)==null) {
            pickerTap("roots",fileName,began)
            pickerTap("downloads",fileName,began)
        }
        // Downloads navigation is asynchronous. Await the exact known file container
        // rather than branching on one observation made during the transition.
        return pickerTap("file",fileName,began)
    }

    private fun buttonWithPublicText(scenario:ActivityScenario<MainActivity>,text:String):String {
        require(text=="Select Image")
        val observed=waitFor(scenario,"""(() => {
          const found=[...document.querySelectorAll('button')].filter(e=>e.textContent.trim()===${JSONObject.quote(text)});
          const e=found.length===1?found[0]:null;const parts=[];
          for(let n=e;n&&n!==document.body;n=n.parentElement)parts.unshift(n.tagName.toLowerCase()+':nth-child('+([...n.parentElement.children].indexOf(n)+1)+')');
          return JSON.stringify({matches:found.length,enabled:!!e&&!e.disabled,selector:e?'body > '+parts.join(' > '):null});})()""") { it.optInt("matches")==1 && it.optBoolean("enabled") }
        return observed.getString("selector")
    }

    private val ocrVisiblePage = """(() => {
        const matches=[...document.querySelectorAll('div')].filter(e=>!e.children.length &&
          e.textContent.includes('Hello') && e.textContent.toLowerCase().includes('solosoul') && e.textContent.includes('1234567890'));
        const e=matches.length===1?matches[0]:null;const r=e?.getBoundingClientRect();const style=e?getComputedStyle(e):null;
        const nav=document.querySelector('.android-navigation')?.getBoundingClientRect();
        const x=innerWidth*.85,y=innerHeight*.6;const hit=document.elementFromPoint(x,y);
        return JSON.stringify({matches:matches.length,path:location.pathname,knownText:!!e,
          rect:r?{x:r.x,y:r.y,width:r.width,height:r.height}:null,
          visible:!!r&&r.y>=96&&r.bottom<=(nav?.top||innerHeight)-16,
          foreground:style?.color,fontSize:style?.fontSize,opacity:style?.opacity,visibility:style?.visibility,
          viewportWidth:innerWidth,viewportHeight:innerHeight,startX:x,startY:y,endY:innerHeight*.22,
          safeSwipeStart:!!hit&&!hit.closest('button,a,input,textarea,select,[role="button"]')});})()"""

    private fun inspectVisibleOcr(scenario:ActivityScenario<MainActivity>,began:Long) {
        var state=js(scenario,ocrVisiblePage);var gestures=0
        while(!state.optBoolean("visible") && gestures<8 && SystemClock.elapsedRealtimeNanos()-began<TimeUnit.SECONDS.toNanos(45)) {
            check(state.getInt("matches")==1 && state.getString("path")=="/ocr" && state.getBoolean("safeSwipeStart"))
            val before=state;val down=SystemClock.uptimeMillis()
            for(step in 0..11) {
                scenario.onActivity {activity ->
                    val view=requireNotNull(webView(activity.window.decorView));check(view.hasWindowFocus() && view.isShown)
                    val scale=view.width/before.getDouble("viewportWidth")
                    val x=(before.getDouble("startX")*scale).toFloat()
                    val y=((before.getDouble("startY")+(before.getDouble("endY")-before.getDouble("startY"))*step/11.0)*scale).toFloat()
                    check(x>0&&x<view.width&&y>0&&y<view.height)
                    val action=if(step==0)MotionEvent.ACTION_DOWN else if(step==11)MotionEvent.ACTION_UP else MotionEvent.ACTION_MOVE
                    val event=MotionEvent.obtain(down,SystemClock.uptimeMillis(),action,x,y,0);event.source=android.view.InputDevice.SOURCE_TOUCHSCREEN
                    try{check(view.dispatchTouchEvent(event))}finally{event.recycle()}
                }
                Thread.sleep(20)
            }
            gestures++;Thread.sleep(350);state=js(scenario,ocrVisiblePage)
            report.put("ocrScrollObservation",JSONObject().put("gestures",gestures).put("before",before).put("after",state));writeReport()
        }
        check(state.getBoolean("visible"));painted(scenario,began)
        captureScreenshot(scenario,"diagnostic-first-ocr-result-visible")
        state=js(scenario,ocrVisiblePage);check(state.getBoolean("visible"))
        val pixels=textPixels(scenario,"diagnostic-first-ocr-result-visible",state);check(pixels.getInt("nearForegroundPixels")>100)
        report.put("ocrWindowVisibility",pixels.put("nativeTouchScrollGestures",gestures)
            .put("definition","known corpus summary fully above fixed navigation; native touch scroll, compositor callback/two frames and actual foreground window pixels; manual review still required"))
            .put("ocrVisibleObservedAtNs",SystemClock.elapsedRealtimeNanos());writeReport()
    }

    private fun firstPublicOcr(scenario:ActivityScenario<MainActivity>,fileName:String) {
        check(fileName=="rf312-ocr-$runId.png")
        val before=observer(scenario)
        assertEquals("No previous OCR scan in this actual application process",0,(0 until before.getJSONArray("commands").length()).count {before.getJSONArray("commands").getJSONObject(it).getString("command")=="ocr_scan_image"})
        touch(scenario,".android-navigation a[href='/tools']")
        waitFor(scenario,page) {it.optString("path")=="/tools"}
        val index=js(scenario,"""JSON.stringify({index:[...document.querySelectorAll('.android-tool-grid > button')].findIndex(e=>e.querySelector('strong')?.textContent.includes('OCR'))})""").getInt("index")
        check(index>=0);touch(scenario,".android-tool-grid > button:nth-child(${index+1})")
        waitFor(scenario,page) {it.optString("path")=="/ocr"}
        touch(scenario,buttonWithPublicText(scenario,"Select Image"))
        val selectedAt=choosePublicNativeImage(fileName)
        report.put("ocrFileSelectionNativeAtNs",selectedAt)
        var mainReady=false
        while(SystemClock.elapsedRealtimeNanos()-selectedAt<TimeUnit.SECONDS.toNanos(45)) {
            instrumentation.runOnMainSync {
                mainReady=ActivityLifecycleMonitorRegistry.getInstance().getActivitiesInStage(Stage.RESUMED)
                    .any {it.javaClass.name=="com.solosoul.app.MainActivity" && it.window.decorView.hasWindowFocus()}
            }
            if(mainReady)break
            Thread.sleep(50)
        }
        if(!mainReady)captureNativePicker("failure-picker-after-file-click")
        check(mainReady)
        val result=waitFor(scenario,"""(() => {const text=document.body.textContent||'';return JSON.stringify({
          path:location.pathname,hello:text.includes('Hello'),soloSoul:text.toLowerCase().includes('solosoul'),digits:text.includes('1234567890'),
          imported:false,alerts:document.querySelectorAll('[role="alert"]').length});})()""",selectedAt) {
            it.optString("path")=="/ocr" && it.optBoolean("hello") && it.optBoolean("soloSoul") && it.optBoolean("digits")
        }
        val finished=SystemClock.elapsedRealtimeNanos()
        report.put("firstOcr",result.put("nativeFileSelectedAtNs",selectedAt).put("nativeResultObservedAtNs",finished)
          .put("fromFileSelectionMs",(finished-selectedAt)/1_000_000.0)
          .put("definition","native injected coordinate DOWN/UP with recorded tool type to actual known corpus in result DOM; includes picker result/IPC/decode/MLKit initialization and polling")
          .put("nativeSystemPickerUsed",true).put("firstActualOcrTransport",true).put("confidenceNotMeasured",true))
        painted(scenario,selectedAt);captureScreenshot(scenario,"diagnostic-first-ocr-result")
        inspectVisibleOcr(scenario,selectedAt)
        val after=observer(scenario)
        assertEquals(1,(0 until after.getJSONArray("commands").length()).count {after.getJSONArray("commands").getJSONObject(it).getString("command")=="ocr_scan_image"})
        touch(scenario,".android-navigation a[href='/']")
        waitFor(scenario,page) {it.optBoolean("home")}
    }

    @Test fun fixedMediaUiDiagnostic() {
        val args=InstrumentationRegistry.getArguments()
        pickerPointerMode=requireNotNull(args.getString("pickerPointerMode","finger"));check(pickerPointerMode in setOf("finger","unknown"))
        assertEquals("true",args.getString("privateDataBackedUp"))
        runId=requireNotNull(args.getString("observerRunId"));require(Regex("[a-f0-9]{32}").matches(runId))
        val count=requireNotNull(args.getString("objectCount")).toInt();require(count==100 || count==5000)
        val tag=requireNotNull(args.getString("evidenceTag"));require(tag=="rf312-media-$runId")
        val context=instrumentation.targetContext
        assertEquals("com.solosoul.app",context.packageName)
        assertFalse("Main app must be optimized non-debuggable Release",context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE!=0)
        val root=File(context.applicationInfo.dataDir)
        val config=File(root,"app_config.json")
        if(config.exists()) assertTrue("Fixed private fixture must not redirect to a SAF root",JSONObject(config.readText()).optString("saf_tree_uri").isBlank())
        val wrapper=JSONObject(File(root,"rf312-media-fixture.json").readText())
        assertEquals(1,wrapper.getInt("schemaVersion"))
        assertEquals("synthetic-android-media-vault-fixture",wrapper.getString("scope"))
        assertEquals("/data/user/0/com.solosoul.app",wrapper.getString("metadataVaultRoot"))
        val declared=File(wrapper.getString("metadataVaultRoot"))
        assertTrue(declared.isDirectory && root.isDirectory)
        assertEquals(root.canonicalFile,declared.canonicalFile)
        val actualStat=android.system.Os.stat(root.path)
        val declaredStat=android.system.Os.stat(declared.path)
        assertEquals(actualStat.st_dev,declaredStat.st_dev)
        assertEquals(actualStat.st_ino,declaredStat.st_ino)
        val media=wrapper.getJSONObject("media")
        assertEquals(2,media.getInt("schemaVersion"))
        assertEquals("obj_perf_00000000",media.getString("mediaObjectId"))
        assertEquals(4,media.getJSONArray("attachments").length())
        val closed=media.getJSONArray("closedFiles")
        for(i in 0 until closed.length()) {
            val row=closed.getJSONObject(i);val file=File(root,row.getString("relativePath"))
            assertTrue(file.canonicalPath.startsWith(root.canonicalPath+File.separator) && file.isFile)
            val hash=java.security.MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString("") { "%02x".format(it.toInt() and 255) }
            assertEquals(row.getString("sha256"),hash)
        }
        val marker=media.getJSONObject("baseFixture")
        assertEquals("synthetic-native-vault-fixture",marker.getString("scope"))
        assertEquals(count,marker.getInt("objectCount"));assertEquals("release",marker.getString("buildProfile"))
        val kdf=marker.getJSONObject("kdf")
        assertEquals(65536,kdf.getInt("memoryKiB"));assertEquals(3,kdf.getInt("iterations"));assertEquals(4,kdf.getInt("parallelism"))
        val account="acc_rf312_$count"
        expectedAccount=account
        val accounts=JSONArray(File(root,"accounts.json").readText())
        assertEquals(1,accounts.length());assertEquals(account,accounts.getJSONObject(0).getString("id"))
        assertEquals("Performance Fixture",accounts.getJSONObject(0).getString("name"))
        assertTrue(File(root,"$account/vault.db").isFile)
        for(file in root.walkTopDown()) if(file.name.startsWith("acc_")) assertEquals(account,file.name)
        evidence=File(requireNotNull(context.getExternalFilesDir(null)),tag).also { check(it.mkdir()) }
        report=JSONObject().put("schemaVersion",1).put("scope","android-native-fixed-media-ui-diagnostic")
            .put("measurementDiagnosticOnly",true)
            .put("pdfRenderingProven",false).put("nativePdfObserver","resumed exact product Activity, actual bitmap and window pixels; independent host visual review still required")
            .put("fullMediaOrPerformanceAccepted",false)
            .put("touchReadinessDefinition","three committed observations and >=350ms stable target/viewport/notification geometry; native bounds and DOM hit match; one native tap only; typing shares original45s budget")
            .put("runId",runId).put("processId",android.os.Process.myPid()).put("uid",android.os.Process.myUid())
            .put("objectCount",count).put("pickerPointerMode",pickerPointerMode).put("success",false)
            .put("fixtureSearchMatches",count/20).put("displayedSearchResults",minOf(count/20,50)).put("productionSearchResultLimit",50)
            .put("nativeClock","Android elapsedRealtimeNanos; not converted to document clock")
            .put("startupDefinition","Activity launch to usable production password form, focused own WebView and two frames; excludes runner/process launch")
            .put("inputMethod","target WebView native touch dispatch and Instrumentation.sendStringSync; includes instrumentation/polling/drawing overhead")
            .put("memoryDefinition","serial main-process PSS sampling including runner, not renderer memory or continuous peak")
            .put("ipcDefinition","actual transport sends from early observer, including startup/retries/channels; no request arguments or bodies")
            .put("unmeasured",JSONArray(listOf("repeated-full-journey","renderer-memory","process-cold-start","physical-device","other-platforms")))
        sampling.set(true)
        val worker=Thread {
            try {
                while(sampling.get()) {
                    val started=SystemClock.elapsedRealtimeNanos();val info=Debug.MemoryInfo();Debug.getMemoryInfo(info)
                    assertTrue("Actual main-process PSS must be available",info.totalPss>0)
                    synchronized(memory) {
                        check(memory.length()<1024)
                        memory.put(JSONObject().put("startedAtNs",started).put("finishedAtNs",SystemClock.elapsedRealtimeNanos()).put("pssBytes",info.totalPss.toLong()*1024))
                    }
                    Thread.sleep(1000)
                }
            } catch(error:Throwable) { memoryFailure.set(error) }
        }.also { it.start() }
        try {
            val began=SystemClock.elapsedRealtimeNanos()
            val scenario=ActivityScenario.launch(MainActivity::class.java)
            phase(scenario,"activity-startup",began,null) {
                waitFor(scenario,page,began) { it.optBoolean("mounted") && it.optBoolean("startupGone") && it.optString("platform")=="android" &&
                    it.optString("path")=="/login" && it.optBoolean("password") && it.optBoolean("enabled") &&
                    it.optBoolean("singleAccount") && it.optBoolean("publicAccountName") && it.optBoolean("publicAccountId") }
                scenario.onActivity { activity ->
                    val view=requireNotNull(webView(activity.window.decorView))
                    assertTrue("Only the shown target view in its already focused native window may receive focus",view.isAttachedToWindow && view.isShown && view.hasWindowFocus())
                    assertTrue("Target WebView must accept local input focus",view.requestFocus())
                }
                waitFor(scenario,"JSON.stringify({mainFrame:window.top===window,focused:document.hasFocus()})",began) {
                    it.optBoolean("mainFrame") && it.optBoolean("focused")
                }
            }
            fun measure(name:String,action:()->Unit) {
                val before=observer(scenario);phase(scenario,name,SystemClock.elapsedRealtimeNanos(),before,action)
            }
            fun unlock() {
                typePublic(scenario,"[data-login-method-region='password'] input","perf-baseline-only-password")
                touch(scenario,"[data-login-password-submit]")
                waitFor(scenario,page) { it.optBoolean("home") && it.optString("count")==count.toString() && it.optInt("errors")==0 }
            }
            measure("password-unlock") { unlock() }
            measure("first-ocr-user-flow") {firstPublicOcr(scenario,requireNotNull(args.getString("publicImageName")))}
            fun openWorkspace() {
                touch(scenario,".android-category:first-child > button:first-child")
                waitFor(scenario,page) { it.optString("path")=="/workspace" && it.optString("search")=="?section=identity" && it.optInt("errors")==0 }
                // The frozen fixture uses type=note, section=identity. Match the
                // existing Windows journey: enter identity then select All.
                touch(scenario,".android-chips > button:first-child")
                waitFor(scenario,page) { it.optString("path")=="/workspace" && it.optString("search")=="" && it.optInt("cards")==minOf(count,50) && it.optBoolean("firstPublicObject") && it.optInt("errors")==0 }
            }
            measure("workspace") {openWorkspace()}
            touch(scenario,".android-navigation a[href='/tools']")
            waitFor(scenario,page) {it.optString("path")=="/tools"}
            val searchIndex=js(scenario,"""JSON.stringify({index:[...document.querySelectorAll('.android-tool-grid > button')].findIndex(e=>e.querySelector('strong')?.textContent==='Search')})""").getInt("index")
            check(searchIndex>=0);touch(scenario,".android-tool-grid > button:nth-child(${searchIndex+1})")
            waitFor(scenario,page) {it.optString("path")=="/search"}
            measure("search-needle") {
                typePublic(scenario,"input","needle")
                waitFor(scenario,page) {it.optString("path")=="/search"&&it.optBoolean("publicSearch")&&it.optInt("searchResults")==minOf(count/20,50)&&it.optInt("errors")==0}
                var keyboardVisible=false
                scenario.onActivity {activity -> keyboardVisible=requireNotNull(ViewCompat.getRootWindowInsets(activity.window.decorView)).isVisible(WindowInsetsCompat.Type.ime())}
                if(keyboardVisible)instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK)
                waitFor(scenario,page) {it.optString("path")=="/search"&&it.optBoolean("publicSearch")&&it.optInt("searchResults")==minOf(count/20,50)}
                captureScreenshot(scenario,"diagnostic-search-results")
            }
            touch(scenario,".android-navigation a[href='/']")
            waitFor(scenario,page) {it.optBoolean("home")};openWorkspace()
            measure("attachments-open") {
                val row=js(scenario,"""JSON.stringify({index:[...document.querySelectorAll('.android-object-row')].findIndex(e=>e.querySelector('strong')?.textContent==='Record 00000000')})""")
                assertTrue(row.getInt("index")>=0)
                touch(scenario,".android-object-row:nth-child(${row.getInt("index")+1}) > .android-row-button")
                waitFor(scenario,"""JSON.stringify({detail:document.querySelector('[data-testid="object-detail-modal"]')?.textContent.includes('Record 00000000')})""") { it.optBoolean("detail") }
                touch(scenario,".android-object-detail-footer > button:first-child")
                waitFor(scenario,mediaPage) { it.optInt("knownAttachments")==4 }
                mediaScreenshot(scenario,"attachments")
            }
            fun preview(name:String) {
                touch(scenario,"button[aria-label='Attachment actions: $name']")
                waitFor(scenario,"""JSON.stringify({menu:!!document.querySelector('.android-attachment-menu-actions')})""") { it.optBoolean("menu") }
                touch(scenario,".android-attachment-menu-actions > button:first-child")
                waitFor(scenario,mediaPage) { it.optBoolean("preview") }
            }
            fun closePreview() {
                touch(scenario,"[data-testid='attachment-preview-overlay'] button[aria-label='Close']")
                waitFor(scenario,mediaPage) { !it.optBoolean("preview") && it.optInt("knownAttachments")==4 }
            }
            measure("image-preview") {
                preview("ocr_test.png")
                waitFor(scenario,mediaPage) { it.optBoolean("imageLoaded") && !it.optBoolean("previewError") }
                report.put("imagePreview",js(scenario,mediaPage));mediaScreenshot(scenario,"image-preview")
                closePreview()
            }
            measure("text-preview") {
                val beganText=SystemClock.elapsedRealtimeNanos()
                preview("preview.txt")
                waitFor(scenario,mediaPage,beganText) { it.optBoolean("knownText") && !it.optBoolean("previewError") }
                report.put("textPreview",js(scenario,mediaPage))
                // Match the previous immediate capture point: no extra style or
                // geometry query before PixelCopy. Analyze that saved PNG later.
                captureScreenshot(scenario,"diagnostic-text-before-commit")
                val before=textPixels(scenario,"diagnostic-text-before-commit",js(scenario,textPage))
                report.put("textBeforeCommit",before);writeReport()
                painted(scenario,beganText)
                captureScreenshot(scenario,"diagnostic-text-after-commit")
                val after=textPixels(scenario,"diagnostic-text-after-commit",js(scenario,textPage))
                report.put("textAfterCommit",after).put("textVisualCommitDefinition","actual WebView postVisualStateCallback plus two native frames within original45s budget")
                writeReport()
                assertTrue("Actual committed text region must contain visible foreground pixels: $after",after.getInt("nearForegroundPixels")>100)
                closePreview()
            }
            measure("pdf-text-native-diagnostic") {
                nativePdfPreview(scenario,"text_only.pdf",media.getJSONArray("publicAssets").let { assets ->
                    (0 until assets.length()).map { assets.getJSONObject(it) }.single { it.getString("fileName")=="text_only.pdf" }.getString("sha256") })
            }
            measure("pdf-scanned-native-diagnostic") {
                nativePdfPreview(scenario,"scanned.pdf",media.getJSONArray("publicAssets").let { assets ->
                    (0 until assets.length()).map { assets.getJSONObject(it) }.single { it.getString("fileName")=="scanned.pdf" }.getString("sha256") })
            }
            instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK)
            waitFor(scenario,mediaPage) { it.optInt("knownAttachments")==0 }
            touch(scenario,"[data-testid='object-detail-modal'] button[aria-label='Close']")
            waitFor(scenario,"""JSON.stringify({gone:!document.querySelector('[data-testid="object-detail-modal"]')})""") { it.optBoolean("gone") }
            measure("application-lock") {
                touch(scenario,"button[aria-label='Lock Vault']")
                waitFor(scenario,page) { it.optString("path")=="/login" && !it.optBoolean("home") && it.optBoolean("password") && it.optBoolean("enabled") }
            }
            measure("password-reunlock") { unlock() }
            assertEquals(12,phases.length());assertNull(memoryFailure.get())
            report.put("success",true)
        } catch(error:Throwable) {
            report.put("errorClass",error.javaClass.name);throw error
        } finally {
            sampling.set(false);worker.join(2000)
            if(worker.isAlive || memoryFailure.get()!=null) report.put("success",false).put("memoryError",true)
            report.put("memorySamplerExited",!worker.isAlive);writeReport()
            // Keep the owned activity alive until the external driver stops and
            // restores the target; ActivityScenario.close may stop the runner.
            assertFalse("Memory sampler must stop",worker.isAlive);assertNull(memoryFailure.get())
        }
    }
}
