from pathlib import Path
import datetime, json, subprocess, time

R = Path('D:/SoloSoul')
B = Path('D:/SoloSoul/build/android-native-feasibility-20261010')
S = Path('D:/SoloSoul/build/rf121-theme-binding-20261010/current-windows-native-20261014')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
pwsh = 'C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
original = load(B/'rf1145-fixed-api31-20261014/owned-processes-after-launch.json')
expected = [row for row in original if row['Name'] in ['emulator.exe','qemu-system-x86_64-headless.exe'] and
            '-avd SoloSoul_RF121_API31_20261010 -port 5586 ' in row.get('CommandLine','')]
assert len(expected) == 2
def identity(pid):
    text = subprocess.check_output([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json"],text=True)
    return json.loads(text) if text.strip() else None
current = []
for row in expected:
    live = identity(row['ProcessId'])
    assert live and all(live[key] == row[key] for key in ['Name','ProcessId','CommandLine'])
    expected_path = B/'sdk/emulator'/('emulator.exe' if row['Name']=='emulator.exe' else 'qemu/windows-x86_64/qemu-system-x86_64-headless.exe')
    assert live['ExecutablePath'] and Path(live['ExecutablePath']).resolve() == expected_path.resolve()
    assert row['ExecutablePath'] is None or row['ExecutablePath'] == live['ExecutablePath']
    assert datetime.datetime.fromisoformat(live['CreationDate']) == datetime.datetime.fromisoformat(row['CreationDate'])
    current.append(live)
adb = [str(B/'sdk/platform-tools/adb.exe'),'-H','localhost','-P','5049','-s','emulator-5586']
assert subprocess.check_output(adb+['emu','avd','name'],text=True).splitlines()[0] == 'SoloSoul_RF121_API31_20261010'
app = subprocess.run(adb+['shell','pidof','com.solosoul.app'],capture_output=True,text=True,timeout=10)
assert app.returncode == 1 and not app.stdout.strip()
assert load(B/'rf312-paired-local-sampling-overhead-20261014/cohort-terminal.json')['all20NativeJourneysPassed']
assert all(row['allOriginalStateRestored'] and row['restoreAudit']['entries']==216 for row in load(B/'rf312-paired-local-sampling-overhead-20261014/cohort-terminal.json')['outcomes'])
stop = subprocess.run(adb+['emu','kill'],capture_output=True,text=True,timeout=10)
receipt = dict(task='RF-312',scope='exact owned API31 emulator normal shutdown after verified restoration; private ADB retained',
               before=current,command=adb+['emu','kill'],exitCode=stop.returncode,stdout=stop.stdout,stderr=stop.stderr,
               noOwnedAppRunning=True,unrelatedProcessesStopped=False)
assert stop.returncode == 0
deadline = time.monotonic()+30
while time.monotonic() < deadline:
    after = [identity(row['ProcessId']) for row in expected]
    if all(row is None for row in after):
        break
    time.sleep(0.5)
receipt['oldPidsAbsentAfterNormalShutdown'] = all(row is None for row in after)
(S/'emulator-stop-for-build.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
assert receipt['oldPidsAbsentAfterNormalShutdown']
print('Exact owned API31 emulator and child stopped normally; private ADB retained; no unrelated process stopped')
