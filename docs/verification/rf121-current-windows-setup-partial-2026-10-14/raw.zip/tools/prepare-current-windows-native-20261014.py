from pathlib import Path
import datetime,hashlib,json,os,re,shutil,struct,subprocess,time

R=Path('D:/SoloSoul');W=Path(__file__).parent;B=R/'build/android-native-feasibility-20261010'
S=W/'current-windows-native-20261014';S.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='a7fbda801f50013b8364c756452f33f7efa96bfd'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
assert load(B/'rf312-paired-local-sampling-overhead-20261014/cohort-terminal.json')['all20NativeJourneysPassed']
sources=load(B/'rf1145-android-script-newlines-20261014/fixed-android/sources.json')
assert all(sha(R/n)==h for n,h in sources.items());save(S/'sources.json',sources)
frontend=load(B/'rf1145-android-script-newlines-20261014/fixed-android/frontend.json')
assert {p.relative_to(R/'tauri/dist').as_posix() for p in (R/'tauri/dist').rglob('*') if p.is_file()}==set(frontend['files'])
assert all(sha(R/'tauri/dist'/n)==row['sha256'] for n,row in frontend['files'].items());save(S/'frontend.json',frontend)
assert load(W/'current-native-desktop-preflight-20261014/result.json')['nativeInputDesktopPreconditionAvailable']

# Release RAM only by normal shutdown of the currently identified owned AVD.
stop=(B/'rf1145-android-script-newlines-20261014/stop-owned-current-avd.py').read_text(encoding='utf-8')
assert stop.count("S = B/'rf1145-android-script-newlines-20261014'")==1
stop=stop.replace("S = B/'rf1145-android-script-newlines-20261014'", "S = Path('D:/SoloSoul/build/rf121-theme-binding-20261010/current-windows-native-20261014')",1)
stop=stop.replace('rf312-current-api31-20261014/owned-processes-after-launch.json','rf1145-fixed-api31-20261014/owned-processes-after-launch.json')
old="assert len(load(S/'failure-restoration-audit.json')['rows']) == 3"
assert stop.count(old)==1
stop=stop.replace(old,"assert load(B/'rf312-paired-local-sampling-overhead-20261014/cohort-terminal.json')['all20NativeJourneysPassed']\nassert all(row['allOriginalStateRestored'] and row['restoreAudit']['entries']==216 for row in load(B/'rf312-paired-local-sampling-overhead-20261014/cohort-terminal.json')['outcomes'])")
path=S/'stop-owned-avd.py';path.write_text(stop,encoding='utf-8',newline='\n')
subprocess.run(['C:/Python314/python.exe',str(path)],cwd=R,check=True)

cache=R/'build/rf312-maintenance-20261009';env=os.environ.copy()
config=dict(identifier='com.solosoul.rf312perf',bundle=dict(active=False));save(S/'native-build-config.json',config)
env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),CARGO_HOME=str(cache/'cargo-home'),CARGO_TARGET_DIR=str(cache/'cargo-target'),
    CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(cache/'ort-cache'),PDFIUM_LIBRARY_PATH=str(R/'tauri/src-tauri/resources/pdfium/pdfium.dll'),
    PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',TAURI_CONFIG=json.dumps(config))
env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','')
for name in ['TAURI_ANDROID_PROJECT_PATH','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS','SOLOSOUL_REGISTRY_PUBKEY']:env.pop(name,None)
cargo='C:/Users/40299571/.cargo/bin/cargo.exe'
node='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
def frozen():
    assert all(sha(R/n)==h for n,h in sources.items())
    assert all(sha(R/'tauri/dist'/n)==row['sha256'] for n,row in frontend['files'].items())
for name,command in [
    ('native-node',[node,'--test','scripts/native-perf-run.test.mjs','scripts/native-perf-diagnose.test.mjs','scripts/native-perf-runtime.test.mjs','scripts/native-perf-sdk-cdp.test.mjs','scripts/native-perf-startup.test.mjs','src-tauri/src/native_perf/observer.node.test.mjs']),
    ('native-clippy',[cargo,'clippy','--locked','-p','solo_soul','--all-targets','--features','native-perf','--','-D','warnings']),
    ('native-tests',[cargo,'test','--locked','-p','solo_soul','--lib','--features','native-perf','native_perf::','--','--nocapture']),
    ('native-release',[cargo,'build','--locked','--release','-p','solo_soul','--bin','solo_soul','--features','native-perf']),
]:
    frozen();began=time.monotonic()
    with (S/(name+'.stdout.log')).open('xb') as out,(S/(name+'.stderr.log')).open('xb') as err:
        proc=subprocess.Popen(command,cwd=R/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(S/(name+'.live.json'),dict(pid=proc.pid,command=command,at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        print(name,'live PID',proc.pid,flush=True);code=proc.wait()
    changed=[n for n,h in sources.items() if sha(R/n)!=h]
    save(S/(name+'.receipt.json'),dict(exitCode=code,elapsedSeconds=time.monotonic()-began,sourceUnchanged=not changed,changedSources=changed,command=command))
    print(name,'exit',code,flush=True)
    if code or changed:
        print((S/(name+'.stderr.log')).read_text(encoding='utf-8',errors='replace')[-4000:],flush=True);raise SystemExit(code or 1)
    frozen()
runtime=S/'runtime/bin';runtime.mkdir(parents=True,exist_ok=False)
exe=runtime/'solo_soul.exe';shutil.copyfile(cache/'cargo-target/release/solo_soul.exe',exe)
data=exe.read_bytes();offset=struct.unpack_from('<I',data,0x3c)[0]
assert data[offset:offset+4]==b'PE\0\0' and struct.unpack_from('<H',data,offset+24+68)[0]==2
old=load(W/'rf1133-current-gui-build-20261012/runtime-package.json');resources=[]
for row in old['resources']:
    source=Path(row['source']);dest=runtime/Path(row['copy']).relative_to(Path(old['exe']).parent)
    assert dest.resolve().is_relative_to(runtime.resolve()) and source.is_file() and not source.is_symlink()
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest);assert sha(source)==sha(dest)
    resources.append(dict(source=str(source),copy=str(dest),sha256=sha(source)))
assert len(resources)==94
save(S/'runtime-package.json',dict(exe=str(exe),sha256=sha(exe),bytes=exe.stat().st_size,resources=resources,
    gitHead='a7fbda801f50013b8364c756452f33f7efa96bfd',sourceCount=len(sources),sourceManifestSha256=sha(S/'sources.json'),
    frontendManifestSha256=sha(S/'frontend.json'),windowsGuiSubsystem=2,currentNativeChecksPassed=True,
    sharedFormalSetupAppUsed=True,guiExecuted=False,nativeMaterialAccepted=False,goal='active'))
frozen();print('Current Windows native-perf package prepared; actual GUI/matrix acceptance still pending',flush=True)
