from pathlib import Path
import hashlib,json,re,zipfile
R=Path('D:/SoloSoul');W=Path(__file__).parent;B=W/'current-windows-native-retry1-20261014'
N='rf121-current-windows-setup-partial-2026-10-14';O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as out:json.dump(v,out,indent=2);out.write('\n')
sources=load(B/'sources.json');assert len(sources)==1983 and all(sha(R/n)==h for n,h in sources.items())
package=load(B/'runtime-package.json');assert sha(Path(package['exe']))==package['sha256']
assert len(package['resources'])==94 and all(sha(Path(x['source']))==sha(Path(x['copy']))==x['sha256'] for x in package['resources'])
for name in ['native-node','native-clippy','native-tests','native-release']:
    receipt=load(B/(name+'.receipt.json'));assert receipt['exitCode']==0 and receipt['sourceUnchanged']
node=(B/'native-node.stdout.log').read_text(encoding='utf-8');assert re.search(r'# pass 115\b',node) and re.search(r'# fail 0\b',node)
rust=(B/'native-tests.stdout.log').read_text(encoding='utf-8');assert '139 passed; 0 failed; 0 ignored;' in rust
groups=[];members={}
excluded={'vault','app-data','profile','webview','temp','models','plugins','runtime'}
def evidence(label,directory,recursive=True):
    if not directory.exists():return
    paths=directory.rglob('*') if recursive else directory.iterdir()
    for p in paths:
        rel=p.relative_to(directory)
        if any(x in excluded for x in rel.parts):continue
        if p.is_file() and p.suffix in ['.json','.log','.png','.bgra','.py','.mjs','.ps1','.toml','.rs']:
            assert not p.is_symlink() and not p.stat().st_file_attributes&0x400
            members[label+'/'+rel.as_posix()]=p
for label,suffix,matrix in [('namespace','current-windows-20261014','current-windows-surface-matrix-20261014'),
                          ('foreground','current-windows-retry1-20261014','current-windows-surface-matrix-retry1-20261014')]:
    C=W/('ss-rf121-composed-window-restore-baseline-'+suffix);S=W/matrix
    assert not load(S/'cohorts-complete.json')['accepted']
    capture=load(C/'capture-results.json');assert not capture['success'] and len(capture['samples'])==3
    journey=load(C/'actual100/native-perf-sdk-journey-results.json');assert len(journey['samples'])==3
    assert all(x['cleanupIntegrity']['complete'] for x in journey['samples'])
    groups.append(dict(label=label,matrixAccepted=False,driverExitCode=load(C/'actual100.receipt.json')['exitCode'],
        nativeJourneysAccepted=sum(x['success'] for x in journey['samples']),
        surfaceCapturesAccepted=sum(x['success'] for x in capture['samples']),
        samples=[dict(index=x['index'],nativeJourneyAccepted=x['success'],nativeError=x.get('error'),
            captureAccepted=capture['samples'][x['index']-1]['success'],captureError=capture['samples'][x['index']-1].get('error')) for x in journey['samples']]))
    evidence(label,C);evidence('matrix-'+label,S,False)
    runtime=load(S/'caption-runtime-package.json')
    assert sha(Path(runtime['exe']))==package['sha256']
    for key in ['helper','activation']:
        assert sha(Path(runtime[key+'Exe']))==runtime[key+'Sha256'] and sha(Path(runtime[key+'Source']))==runtime[key+'SourceSha256']
        members['helper-sources/'+Path(runtime[key+'Source']).name]=Path(runtime[key+'Source'])
    restore=load(S/'restore-helper.json');assert sha(Path(restore['exe']))==restore['sha256'] and sha(Path(restore['source']))==restore['sourceSha256']
    members['helper-sources/restore.rs']=Path(restore['source'])
assert [x['nativeJourneysAccepted'] for x in groups]==[3,2] and [x['surfaceCapturesAccepted'] for x in groups]==[0,2]
C=W/'ss-rf121-composed-window-restore-baseline-current-windows-retry1-20261014'
pics=load(C/'rendered-partial-diagnostics.json');assert len(pics)==2 and all(sha(Path(x['png']))==x['pngSha256'] for x in pics)
restore_failure=load(C/'actual100/sample-001/rf121-wgc-minimize-restore-owned.json')
assert restore_failure['geometryAndDpiPreserved'] and restore_failure['stylesPreserved'] and restore_failure['backdropPreserved']
assert not restore_failure['restoredVisibleNormalForeground'] and restore_failure['inputEventsSent']==0
hit=restore_failure['captionActivation']['refusedHitMetadata']
assert hit['hitRootEqualsTarget'] and hit['hitRootOwnerEqualsTarget'] and not hit['hitEqualsTarget']
assert hit['hit']['pid']==load(C/'actual100/sample-001/native-perf-sdk-journey-bound.json')['browserPid']
cleanup=load(W/'current-windows-failed-20261014-cache-cleanup.json')
assert cleanup['identitiesChecked']==54 and len(cleanup['removedCachePaths'])==48
assert cleanup['processesTerminatedByThisTool']==0 and cleanup['preservedBytesVerified']
assert all(not Path(p).exists() for p in cleanup['removedCachePaths'])
assert all(sha(Path(p['path']))==p['sha256'] for p in cleanup['preservedVaultAndRootFiles'])
evidence('build',B,False);evidence('build-first-stop-refusal',W/'current-windows-native-20261014',False)
evidence('preserved-application-logs',W/'application-logs-current-windows-failed-20261014')
for p in W.iterdir():
    if p.is_file() and ('current-windows' in p.name or 'current-native-desktop-preflight-20261014' in p.name) and p.suffix in ['.py','.mjs','.ps1','.json']:
        members['tools/'+p.name]=p
for name in ['window-restore-contract.mjs']:
    members['tools/'+name]=W/name
members['sources/native-perf-caption-hit-diagnostic.rs']=R/'tauri/scripts/native-perf-caption-hit-diagnostic.rs'
assert not O.exists();O.mkdir();rows=[]
with zipfile.ZipFile(O/'raw.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in sorted(members.items()):
        data=p.read_bytes();z.writestr(n,data);rows.append(dict(member=n,source=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(O/'raw.zip') as z:
    assert z.testzip() is None and len(z.infolist())==len(rows)
    for row in rows:
        data=z.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',dict(task='RF-121',members=rows,allLengthsSha256AndCrcVerified=True,privateDataExecutablesResourcesCachesExcluded=True))
(O/'.gitattributes').write_text('raw.zip -text\n',encoding='utf-8',newline='\n')
result=dict(task='RF-121',fullTaskAccepted=False,goal='active',sourceHead=package['gitHead'],sourceCount=len(sources),
    runtimeSha256=package['sha256'],resourceCount=94,frontendOutputCount=38,sharedFormalSetupAppUsed=True,
    checks=dict(nodePassed=115,nodeFailed=0,nativeRustPassed=139,nativeRustFailed=0,nativeRustIgnored=0,nativeClippyExitCode=0,nativeReleaseExitCode=0),
    groups=groups,fullFourCohortMatrixAccepted=False,unexecutedScenes=['light-collapsed','dark-expanded','dark-collapsed'],
    actualOwnedScreenshotsVisuallyInspected=[dict(index=x['index'],sha256=x['pngSha256'],integratedHeaderAndThreeCaptionIconsVisible=True,
        lightExpandedNavigationAndContentCardPartitionVisible=True,otherWindowPixelsObserved=False,fullMatrixAccepted=False) for x in pics],
    originalStrictGuardsBudgetsAndFailuresPreserved=True,productSourceModified=False,
    refusedRestoration=dict(geometryDpiStylesBackdropPreserved=True,foregroundNotRestored=True,inputEventsSent=0,
        observedHitBelongsToBoundBrowser=True,observedRootAndRootOwnerMatchHeldMainWindow=True,atomicChildOwnershipNotAccepted=True),
    cleanup=dict(identitiesChecked=54,cachePathsRemoved=48,linksUnlinked=len(cleanup['linksUnlinked']),
        preservedFiles=len(cleanup['preservedVaultAndRootFiles']),bytesVerified=True,processesTerminatedByCleanupTool=0),
    pending='Wait for user foreground preparation, then rerun the original complete four-cohort matrix. Do not accept subsets or broaden child-HWND guards from transient diagnostics alone.',
    unacceptedScope=['cross-process persistent window-state restore','complete native material/accessibility matrix','other platforms','performance'],
    archive=dict(path=N+'/raw.zip',members=len(rows),bytes=(O/'raw.zip').stat().st_size,sha256=sha(O/'raw.zip'),allLengthsSha256AndCrcVerified=True))
put(R/'docs/verification'/(N+'.json'),result)
print(json.dumps(dict(task='RF-121',fullMatrixAccepted=False,members=len(rows),nativeJourneysAccepted=5,surfaceCapturesAccepted=2,cleanupPaths=48)))
