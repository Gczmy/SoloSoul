from pathlib import Path
import ctypes,ctypes.wintypes as w,datetime,json,os

stage=Path(__file__).parent/'current-native-desktop-preflight-20261014';stage.mkdir(exist_ok=False)
k=ctypes.WinDLL('kernel32',use_last_error=True);u=ctypes.WinDLL('user32',use_last_error=True);a=ctypes.WinDLL('wtsapi32',use_last_error=True)
k.ProcessIdToSessionId.argtypes=[w.DWORD,ctypes.POINTER(w.DWORD)];k.ProcessIdToSessionId.restype=w.BOOL
u.OpenInputDesktop.argtypes=[w.DWORD,w.BOOL,w.DWORD];u.OpenInputDesktop.restype=w.HANDLE
u.CloseDesktop.argtypes=[w.HANDLE];u.CloseDesktop.restype=w.BOOL
u.GetUserObjectInformationW.argtypes=[w.HANDLE,ctypes.c_int,w.LPVOID,w.DWORD,ctypes.POINTER(w.DWORD)];u.GetUserObjectInformationW.restype=w.BOOL
a.WTSQuerySessionInformationW.argtypes=[w.HANDLE,w.DWORD,ctypes.c_int,ctypes.POINTER(w.LPWSTR),ctypes.POINTER(w.DWORD)]
a.WTSQuerySessionInformationW.restype=w.BOOL;a.WTSFreeMemory.argtypes=[w.LPVOID]
session=w.DWORD();assert k.ProcessIdToSessionId(os.getpid(),ctypes.byref(session))
data=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),callerPid=os.getpid(),callerSessionId=session.value,
    userNamesRead=False,pixelsRead=0,inputEventsSent=0,systemSettingsChanged=False)
buf=w.LPWSTR();size=w.DWORD()
assert a.WTSQuerySessionInformationW(None,session.value,8,ctypes.byref(buf),ctypes.byref(size))
try:
    assert size.value==ctypes.sizeof(ctypes.c_int)
    state=ctypes.cast(buf,ctypes.POINTER(ctypes.c_int)).contents.value
    names=['Active','Connected','ConnectQuery','Shadow','Disconnected','Idle','Listen','Reset','Down','Init']
    assert 0<=state<len(names);data.update(connectionState=state,connectionStateName=names[state])
finally:a.WTSFreeMemory(buf)
desktop=u.OpenInputDesktop(0,False,1);data['inputDesktopAvailable']=bool(desktop)
if desktop:
    try:
        name=ctypes.create_unicode_buffer(256);needed=w.DWORD()
        assert u.GetUserObjectInformationW(desktop,2,name,ctypes.sizeof(name),ctypes.byref(needed))
        data['inputDesktopName']=name.value
    finally:assert u.CloseDesktop(desktop)
else:data['inputDesktopError']=ctypes.get_last_error()
data['nativeInputDesktopPreconditionAvailable']=state==0 and bool(desktop) and data.get('inputDesktopName')=='Default'
(stage/'result.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data),flush=True)
