from pathlib import Path
import hashlib,json
W=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prefix='current-windows-failed-20261014'
groups=[]
for label,suffix in [('namespace','current-windows-20261014'),('foreground','current-windows-retry1-20261014')]:
    C=W/('ss-rf121-composed-window-restore-baseline-'+suffix)
    receipt=load(C/'actual100.receipt.json')
    assert all(receipt[k] for k in ['sourceUnchanged','resourcesUnchanged','originalFixtureUnchanged'])
    capture=load(C/'capture-results.json');assert not capture['success']
    journey=load(C/'actual100/native-perf-sdk-journey-results.json')
    assert len(journey['samples'])==3 and not journey['interrupted']
    samples=[]
    for row in journey['samples']:
        assert row['cleanupIntegrity']['complete']
        P=C/'actual100'/f"sample-{row['index']:03}"
        owned=load(P/'native-perf-owned.json');consumed=load(P/'native-perf-consumed.json')
        assert owned==row['owned'] and consumed['pid']==row['processId'] and consumed['runId']==owned['runId']
        assert Path(owned['root']).samefile(P)
        processes=row['beforeSnapshot']['processes']+row['afterSnapshot']['processes']
        identities=[{'pid':p['pid'],'creationMs':p['creationMs']} for p in processes]
        assert len(identities)>=9
        samples.append(dict(index=row['index'],runId=owned['runId'],pid=row['processId'],recordedIdentities=identities))
    groups.append(dict(label=label,captureRoot=str(C),terminal=True,samples=samples,
        terminalReceiptSha256=sha(C/'actual100.receipt.json'),acceptanceEvidencePresent=False))
plan=dict(cacheCleanupEligible=True,failedSamplesAccepted=False,groups=groups,plannedExactCacheTargets=48,freshCimRequired=True)
with (W/(prefix+'-cache-cleanup-plan.json')).open('x',encoding='utf-8') as out:json.dump(plan,out,indent=2)
source=(W/'rf1133-cleanup-owned.ps1').read_text(encoding='utf-8')
for a,b in [('rf1133-cache-cleanup',prefix+'-cache-cleanup'),('groups.Count -ne 4','groups.Count -ne 2'),
            ('Four terminal owned groups required','Two terminal owned groups required'),('Count -ne 96','Count -ne 48'),
            ('Exact 96 owned cache paths required','Exact 48 owned cache paths required'),
            ('application-logs-rf1133','application-logs-'+prefix),("task='RF-1133'","task='RF-121'")]:
    source=source.replace(a,b)
old="$taskExecutables = @('D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\ss-rf1133-current-gui-runtime-20261012\\bin\\solo_soul.exe')"
assert source.count(old)==1
source=source.replace(old,"$taskExecutables = @('D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\current-windows-native-retry1-20261014\\runtime\\bin\\solo_soul.exe','D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\ss-rf121-current-gui-runtime-20261014\\bin\\solo_soul.exe')")
with (W/(prefix+'-cleanup-owned.ps1')).open('x',encoding='utf-8') as out:out.write(source)
print('Two terminal failed matrices remain rejected; 48 exact owned cache paths prepared for fresh identity/path checks')
