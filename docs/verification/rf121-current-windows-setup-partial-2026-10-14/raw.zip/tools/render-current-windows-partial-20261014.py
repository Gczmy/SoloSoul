from pathlib import Path
import hashlib,json
from PIL import Image
W=Path(__file__).parent
C=W/'ss-rf121-composed-window-restore-baseline-current-windows-retry1-20261014'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
capture=load(C/'capture-results.json');assert not capture['success']
rows=[]
for sample in capture['samples']:
    if not sample['success']:continue
    P=C/'actual100'/f"sample-{sample['index']:03}"
    before=load(P/'native-perf-surface-before.json');after=load(P/'native-perf-surface-after.json')
    bound=load(P/'native-perf-sdk-journey-bound.json');owned=load(P/'native-perf-owned.json')
    assert before['binding']==after['binding']==bound['binding']
    assert before['request']==after['request'] and before['request']['runId']==bound['runId']==owned['runId']
    a,b=dict(before['state']),dict(after['state']);ta,tb=a.pop('atMs'),b.pop('atMs')
    assert a==b and tb>=ta and after['stable'] and a['focused'] and a['visibility']=='visible'
    proof=load(P/'rf121-wgc-light-visible.json');raw_path=P/proof['pixelFile']
    assert proof['runId']==owned['runId'] and proof['pid']==bound['pid']==sample['pid']
    assert proof['otherWindowsCaptured']==0 and sha(raw_path)==sample['pixelSha256']==after['pixelSha256']
    assert sha(P/'native-perf-surface-before.json')==sample['beforeSha256']==after['beforeSha256']
    raw=raw_path.read_bytes();assert len(raw)==proof['width']*proof['height']*4==proof['bytes']
    rgba=bytearray(len(raw));rgba[0::4],rgba[1::4],rgba[2::4],rgba[3::4]=raw[2::4],raw[1::4],raw[0::4],raw[3::4]
    image=Image.frombytes('RGBa',(proof['width'],proof['height']),bytes(rgba)).convert('RGBA')
    dest=C/f"diagnostic-partial-sample-{sample['index']:03}.png"
    with dest.open('xb') as out:image.save(out,format='PNG')
    rows.append(dict(index=sample['index'],png=str(dest),pngSha256=sha(dest),rawSha256=sha(raw_path),
        stateAndPixelBindingVerified=True,fullMatrixAccepted=False,manualVisualReviewComplete=False))
assert len(rows)==2
with (C/'rendered-partial-diagnostics.json').open('x',encoding='utf-8') as out:json.dump(rows,out,indent=2)
print('Two actual successful captures rendered for diagnosis only; failed three-sample group remains rejected')
