from pathlib import Path
import hashlib,json,re

R=Path('D:/SoloSoul');W=Path(__file__).parent
B=W/'current-windows-native-retry1-20261014';S=W/'current-windows-surface-matrix-20261014'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert load(B/'native-release.receipt.json')['exitCode']==0
assert load(B/'native-clippy.receipt.json')['exitCode']==0 and load(B/'native-tests.receipt.json')['exitCode']==0
native=load(B/'runtime-package.json');assert not native['guiExecuted'] and sha(Path(native['exe']))==native['sha256']
sources=load(B/'sources.json');assert all(sha(R/n)==h for n,h in sources.items())
for row in native['resources']:assert sha(Path(row['source']))==sha(Path(row['copy']))==row['sha256']
counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (B/'native-tests.stdout.log').read_text(encoding='utf-8'))
assert len(counts)==1 and counts[0][1:]==('0','0')
old=load(W/'rf1133-native-matrix-20261012/caption-runtime-package.json')
package=dict(old,**native,currentNativeTests=int(counts[0][0]),applicationMaterialAccepted=False,helperMetadataVersion=3)
for prefix in ['helper','activation']:
    assert sha(Path(package[prefix+'Exe']))==package[prefix+'Sha256']
    assert sha(Path(package[prefix+'Source']))==package[prefix+'SourceSha256']
restore=load(W/'rf1133-native-matrix-20261012/restore-helper.json')
assert sha(Path(restore['exe']))==restore['sha256'] and sha(Path(restore['source']))==restore['sourceSha256']
S.mkdir(exist_ok=False)
def save(n,v):
    with (S/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
save('sources.json',sources);save('caption-runtime-package.json',package);save('restore-helper.json',restore)
files=[('run-rf1133-current.py','run-current-windows-surface-20261014.py'),
       ('verify-rf1133-current.mjs','verify-current-windows-surface-20261014.mjs'),
       ('render-rf1133-current.py','render-current-windows-surface-20261014.py'),
       ('run-rf1133-current-cohorts.py','run-current-windows-surface-cohorts-20261014.py'),
       ('rf1133-current-session-preflight.py','current-windows-surface-session-preflight-20261014.py')]
mapping=[('rf1133-native-matrix-20261012',S.name),('rf1133-current-20261012','current-windows-20261014'),
         ("'rf1133-current-session-'+mode+'.py'","'current-windows-surface-session-'+mode+'-20261014.py'"),*files]
tools={};derivation=[]
for oldname,newname in files:
    before=(W/oldname).read_text(encoding='utf-8');after=before
    for a,b in mapping:after=after.replace(a,b)
    # Correct metadata counts only; all native assertions and budgets remain.
    after=after.replace('sourceFiles:1839',f'sourceFiles:{len(sources)}')
    target=W/newname;assert not target.exists()
    if target.suffix=='.py':compile(after,str(target),'exec')
    target.write_text(after,encoding='utf-8',newline='\n')
    tools[target.relative_to(R).as_posix()]=sha(target)
    derivation.append(dict(original=str(W/oldname),originalSha256=sha(W/oldname),generated=str(target),generatedSha256=sha(target)))
for name in ['window-restore-contract.mjs']:
    tools[(W/name).relative_to(R).as_posix()]=sha(W/name)
for row in [package,restore]:
    for name in ['helperSource','activationSource','source']:
        if name in row:tools[Path(row[name]).relative_to(R).as_posix()]=sha(Path(row[name]))
save('tools.json',tools)
save('preparation.json',dict(task='RF-121',purpose='current integrated-titlebar frontend with shared formal setup, four themes/sidebar cohorts, three complete journeys each',
    runtimeSha256=native['sha256'],nativeTests=int(counts[0][0]),sourceCount=len(sources),derivation=derivation,replacements=mapping,
    originalUiActionsAndNativeIdentityRestoreBindingsAndBudgetsPreserved=True,oldResultsNotOverwritten=True,
    systemAppearanceOrPrivacyChanged=False,fullRF121Accepted=False,performanceAccepted=False,goal='active'))
print('Current frozen Windows four-cohort matrix prepared; no GUI acceptance claimed yet')
