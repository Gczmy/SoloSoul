from pathlib import Path
import hashlib,json

W=Path(__file__).parent;source=W/'prepare-current-windows-native-20261014.py'
code=source.read_text(encoding='utf-8')
assert code.count("S=W/'current-windows-native-20261014'")==1
code=code.replace("S=W/'current-windows-native-20261014'","S=W/'current-windows-native-retry1-20261014'",1)
code=code.replace('rf121-theme-binding-20261010/current-windows-native-20261014','rf121-theme-binding-20261010/current-windows-native-retry1-20261014')
marker="path=S/'stop-owned-avd.py';path.write_text(stop,encoding='utf-8',newline='\\n')"
assert code.count(marker)==1
extra='''stop=stop.replace('Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine','Select-Object Name,ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine')
stop=stop.replace('assert len(expected) == 2',"""assert len(expected) == 1 and expected[0]['Name'] == 'emulator.exe'
parent = expected[0]
raw_child = subprocess.check_output([pwsh, '-NoProfile', '-Command', \"ConvertTo-Json -InputObject @(Get-CimInstance Win32_Process -Filter 'ParentProcessId = 2188' | Where-Object { $_.Name -eq 'qemu-system-x86_64-headless.exe' } | Select-Object Name,ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine)\"], text=True)
children=json.loads(raw_child)
assert parent['ProcessId']==2188 and len(children)==1
child=children[0]
assert child['ParentProcessId']==parent['ProcessId']
assert Path(child['ExecutablePath']).resolve()==(B/'sdk/emulator/qemu/windows-x86_64/qemu-system-x86_64-headless.exe').resolve()
assert child['CommandLine'].split(' -avd ',1)[1]==parent['CommandLine'].split(' -avd ',1)[1]
delta=(datetime.datetime.fromisoformat(child['CreationDate'])-datetime.datetime.fromisoformat(parent['CreationDate'])).total_seconds()
assert 0<=delta<=10
expected.append(child)
\"\"\")
'''
code=code.replace(marker,extra+marker,1)
target=W/'prepare-current-windows-native-retry1-generated-20261014.py';assert not target.exists()
compile(code,str(target),'exec');target.write_text(code,encoding='utf-8',newline='\n')
proof=dict(originalSourceSha256=hashlib.sha256(source.read_bytes()).hexdigest(),generatedSha256=hashlib.sha256(target.read_bytes()).hexdigest(),
    changes='new exclusive stage; QEMU child absent in early snapshot is identified through current exact parent, birth interval, SDK path and full AVD arguments',
    originalNoAppAndAllRestorationAndNormalShutdownGuardsRetained=True,unrelatedProcessesStopped=False)
(W/'current-windows-native-retry1-source-proof-20261014.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
exec(compile(code,str(target),'exec'),{'__file__':str(target),'__name__':'__main__'})
