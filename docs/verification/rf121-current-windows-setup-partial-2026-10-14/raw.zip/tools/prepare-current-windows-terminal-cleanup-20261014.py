from pathlib import Path
import hashlib

W = Path(__file__).parent
source = W / 'prepare-rf1133-terminal-cleanup-20261012.py'
before = source.read_text(encoding='utf-8')
after = before.replace('rf1133-native-matrix-20261012', 'current-windows-surface-matrix-20261014')
after = after.replace('rf1133-current-20261012', 'current-windows-20261014')
after = after.replace("prefix='rf1133'", "prefix='current-windows-surface-20261014'")
after = after.replace('application-logs-rf1133', 'application-logs-current-windows-surface-20261014')
after = after.replace('ss-rf1133-current-gui-runtime-20261012', 'current-windows-native-retry1-20261014/runtime')
after = after.replace("task='RF-1133'", "task='RF-121'")
after = after.replace('coherent native caption/content/appbar/card theme', 'coherent integrated header/content/card theme')
# Run this preparer only after all twelve rendered images have actually been inspected.
compile(after, str(source), 'exec')
print('cleanup-preparer derivation', hashlib.sha256(before.encode()).hexdigest(), hashlib.sha256(after.encode()).hexdigest(), flush=True)
exec(compile(after, str(source), 'exec'), {'__file__': str(source), '__name__': '__main__'})
