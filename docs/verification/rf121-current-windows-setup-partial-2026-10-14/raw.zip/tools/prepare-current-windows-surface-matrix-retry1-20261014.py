from pathlib import Path
import hashlib, json, shutil

W = Path(__file__).parent
original = W / 'prepare-current-windows-surface-matrix-20261014.py'
before = original.read_text(encoding='utf-8')
after = before.replace("S=W/'current-windows-surface-matrix-20261014'", "S=W/'current-windows-surface-matrix-retry1-20261014'")
after = after.replace("'current-windows-20261014'", "'current-windows-retry1-20261014'")
for stem in ['run-current-windows-surface', 'verify-current-windows-surface', 'render-current-windows-surface',
             'run-current-windows-surface-cohorts', 'current-windows-surface-session-preflight']:
    after = after.replace(stem+'-20261014.', stem+'-retry1-20261014.')
after = after.replace("'current-windows-surface-session-'+mode+'-20261014.py'", "'current-windows-surface-session-'+mode+'-retry1-20261014.py'")
anchor = "for row in native['resources']:assert sha(Path(row['source']))==sha(Path(row['copy']))==row['sha256']"
assert after.count(anchor) == 1
after = after.replace(anchor, anchor + '''
# Honor the unchanged compiled helpers' explicit temporary EXE namespace.
original_runtime = Path(native['exe']).parent
runtime = W/'ss-rf121-current-gui-runtime-20261014/bin'
assert runtime.resolve().is_relative_to(W.resolve()) and not runtime.parent.exists()
runtime.mkdir(parents=True, exist_ok=False)
copy = runtime/'solo_soul.exe'
shutil.copyfile(Path(native['exe']), copy)
assert sha(copy) == native['sha256']
resources = []
for row in native['resources']:
    dest = runtime/Path(row['copy']).relative_to(original_runtime)
    assert dest.resolve().is_relative_to(runtime.resolve())
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(Path(row['copy']), dest)
    assert sha(dest) == sha(Path(row['source'])) == row['sha256']
    resources.append(dict(row, copy=str(dest)))
native = dict(native, exe=str(copy), resources=resources, runtimeRelocationByteIdentical=True)
''')
compile(after, str(original), 'exec')
after = after.replace('import hashlib,json,re', 'import hashlib,json,re,shutil')
generated = W/'prepare-current-windows-surface-matrix-retry1-generated-20261014.py'
with generated.open('x', encoding='utf-8', newline='\n') as out:
    out.write(after)
print('Preserved failed matrix; retry changes only executable copy and independent evidence paths', flush=True)
exec(compile(after, str(generated), 'exec'), {'__file__':str(generated), '__name__':'__main__'})
