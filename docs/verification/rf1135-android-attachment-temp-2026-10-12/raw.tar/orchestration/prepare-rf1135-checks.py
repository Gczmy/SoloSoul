from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf1135-android-attachment-temp-20261012'
S.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((B/'rf312-android-media-native-round5-20261012/inputs.json').read_text())['runtimeSourceFiles']
sources={name:sha(R/name) for name in old}
changed=[n for n in old if sources[n]!=old[n]]
assert set(changed)=={'tauri/src-tauri/src/commands/attachment/mod.rs','tauri/src-tauri/src/commands/attachment/share.rs','tauri/src-tauri/src/commands/attachment/tests.rs'}
(S/'sources.json').write_text(json.dumps(sources,indent=2)+'\n',encoding='utf-8')
(S/'changes.json').write_text(json.dumps({'task':'RF-1135','changed':changed,'dependenciesUnchanged':True,'defaultFeaturesUnchanged':True,'scope':'Android open/share private temp base; desktop base retained'},indent=2)+'\n',encoding='utf-8')
android=(B/'build-rf312-early-observer-android-release-20261012.py').read_text(encoding='utf-8')
android=android.replace("S=B/'rf312-early-observer-implementation-20261012'","S=B/'rf1135-android-attachment-temp-20261012'")
android=android.replace("A=S/'android-release-build-round2'","A=S/'android-release-build'")
(B/'build-rf1135-android-release.py').write_text(android,encoding='utf-8',newline='\n')
package=(B/'package-rf312-early-observer-release-20261012.py').read_text(encoding='utf-8')
package=package.replace("I=B/'rf312-early-observer-implementation-20261012'","I=B/'rf1135-android-attachment-temp-20261012'")
package=package.replace("I/'android-release-build-round5/library.json'","I/'android-release-build/library.json'").replace("I/'android-release-build-round5/receipt.json'","I/'android-release-build/receipt.json'")
package=package.replace("S=I/'android-release-package-round2'","S=I/'android-release-package'")
(B/'package-rf1135-android-release.py').write_text(package,encoding='utf-8',newline='\n')
windows=(B/'run-rf312-early-observer-windows-checks-20261012.py').read_text(encoding='utf-8')
windows=windows.replace("S=B/'rf312-early-observer-implementation-20261012'","S=B/'rf1135-android-attachment-temp-20261012'")
windows=windows.replace("W=S/'windows-checks-round2'","W=S/'windows-checks'")
windows=windows.replace("run('observer-node',['node','--test','src-tauri/src/android_native_perf/observer.node.test.mjs'])\n",'')
windows=windows.replace("'clippy','--locked','--offline','--','-D'","'clippy','--locked','--offline','-p','solo_soul','--lib','--','-D'")
windows=windows.replace("'test','--locked','--offline','--verbose'","'test','--locked','--offline','-p','solo_soul','--lib','commands::attachment::tests','--','--test-threads=1'")
(B/'run-rf1135-windows-checks.py').write_text(windows,encoding='utf-8',newline='\n')
print(S)
