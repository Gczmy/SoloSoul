from pathlib import Path
import json,re
B=Path(__file__).parent;F=B/'rf1135-android-attachment-temp-20261012'
old=B/'rf312-android-media-native-round4-20261012';previous=B/'rf1135-android-media-native-20261012'
S=B/'rf1135-android-native-pages-round2-20261012';S.mkdir(exist_ok=False)
assert json.loads((previous/'first-100-diagnostic.receipt.json').read_text())['restored']
R=Path('D:/SoloSoul')
for name,pages in [('text_only.pdf',2),('scanned.pdf',1)]:
    raw=(R/'tauri/crates/solosoul-core/tests/fixtures'/name).read_bytes()
    assert re.findall(rb'/Count\s+(\d+)',raw)==[str(pages).encode()]
source=(old/'AndroidMediaPerfInstrumentedTest.kt').read_text(encoding='utf-8')
source=source.replace('if(Color.alpha(p)>=250) {','if(Color.alpha(p)>0) {')
source=source.replace('last.optString("pageInfo")=="1 / 1"','last.optString("pageInfo")==if(fileName=="text_only.pdf") "1 / 2" else "1 / 1"')
source=source.replace('last.optInt("inkPixels")>100 && last.optInt("lightPixels")>100','last.optInt("inkPixels")>100')
source=source.replace('private fun pdfScreenshot(activity:Activity,name:String) {','private fun pdfScreenshot(activity:Activity,name:String): JSONObject {')
needle='''            File(evidence,"$name.png").outputStream().use { check(requireNotNull(capture).compress(Bitmap.CompressFormat.PNG,100,it)) }'''
assert source.count(needle)==1
source=source.replace(needle,needle+'''
            var proof=JSONObject()
            instrumentation.runOnMainSync {
                val view=activity.findViewById<ImageView>(activity.resources.getIdentifier("pdfPageImage","id",activity.packageName))
                val position=IntArray(2);view.getLocationInWindow(position)
                val bitmap=requireNotNull(capture);var dark=0;var light=0
                val left=position[0].coerceIn(0,bitmap.width);val top=position[1].coerceIn(0,bitmap.height)
                val right=(position[0]+view.width).coerceIn(0,bitmap.width);val bottom=(position[1]+view.height).coerceIn(0,bitmap.height)
                for(y in top until bottom)for(x in left until right) {
                    val p=bitmap.getPixel(x,y)
                    if(Color.red(p)<200&&Color.green(p)<200&&Color.blue(p)<200)dark++
                    if(Color.red(p)>240&&Color.green(p)>240&&Color.blue(p)>240)light++
                }
                proof=JSONObject().put("screenshot",name+".png").put("actualWindowPageDarkPixels",dark).put("actualWindowPageWhitePixels",light)
                    .put("left",left).put("top",top).put("right",right).put("bottom",bottom)
            }
            report.put("lastPdfWindowPixels",proof);writeReport()
            assertTrue("Actual displayed PDF page must contain text/image ink: $proof",proof.getInt("actualWindowPageDarkPixels")>100)
            assertTrue("Actual displayed PDF page must have a light background: $proof",proof.getInt("actualWindowPageWhitePixels")>100)
            return proof
''')
source=source.replace('pdfScreenshot(activity,"diagnostic-native-$fileName")','last.put("windowPixels",pdfScreenshot(activity,"diagnostic-native-$fileName"))')
needle='''            val button=activity.findViewById<View>(activity.resources.getIdentifier("pdfCloseButton","id",activity.packageName))'''
assert source.count(needle)==1
source=source.replace(needle,'''        }
        if(fileName=="text_only.pdf") {
            instrumentation.runOnMainSync {
                val button=activity.findViewById<View>(activity.resources.getIdentifier("pdfNextButton","id",activity.packageName))
                check(button.isShown && button.isEnabled && button.hasWindowFocus())
                val down=SystemClock.uptimeMillis();val pos=IntArray(2);button.getLocationInWindow(pos)
                for(action in listOf(MotionEvent.ACTION_DOWN,MotionEvent.ACTION_UP)) {
                    val event=MotionEvent.obtain(down,SystemClock.uptimeMillis(),action,pos[0]+button.width/2f,pos[1]+button.height/2f,0)
                    try { check(activity.window.decorView.dispatchTouchEvent(event)) } finally { event.recycle() }
                }
            }
            val beganNext=SystemClock.elapsedRealtimeNanos();var next=JSONObject()
            while(SystemClock.elapsedRealtimeNanos()-beganNext<TimeUnit.SECONDS.toNanos(45)) {
                next=pdfSnapshot(activity,fileName)
                if(next.optString("pageInfo")=="2 / 2" && next.optInt("inkPixels")>100)break
                Thread.sleep(50)
            }
            assertEquals("2 / 2",next.getString("pageInfo"))
            next.put("windowPixels",pdfScreenshot(activity,"diagnostic-native-second-$fileName"))
            last.put("secondPage",next)
        }
        instrumentation.runOnMainSync {
'''+needle)
(S/'AndroidMediaPerfInstrumentedTest.kt').write_text(source,encoding='utf-8',newline='\n')
(S/'current-runtime-sources.json').write_bytes((F/'sources.json').read_bytes())
for name in ['media-native-driver.py','run-first-100-diagnostic.py']:
    raw=(previous/name).read_text(encoding='utf-8').replace(previous.name,S.name)
    if name=='media-native-driver.py':
        raw=raw.replace("proof.get('pageInfo')=='1 / 1'","proof.get('pageInfo')==('1 / 2' if name=='text_only.pdf' else '1 / 1')")
        raw=raw.replace("proof.get('lightPixels',0)>100", "proof.get('windowPixels',{}).get('actualWindowPageWhitePixels',0)>100 and proof.get('windowPixels',{}).get('actualWindowPageDarkPixels',0)>100")
        raw=raw.replace("    phases=evidence.get('phases',[])","    if evidence.get('nativePdf-text_only.pdf',{}).get('secondPage',{}).get('pageInfo')!='2 / 2':raise RuntimeError('Actual native second PDF page required')\n    phases=evidence.get('phases',[])")
    (S/name).write_text(raw,encoding='utf-8',newline='\n')
inputs=json.loads((previous/'inputs.json').read_text());(S/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
builder=(B/'build-rf312-android-media-probe-round4-20261012.py').read_text(encoding='utf-8').replace(old.name,S.name)
needle="'tauri/crates/solosoul-core/examples/perf_baseline/media.rs'}"
assert builder.count(needle)==1
builder=builder.replace(needle,"'tauri/crates/solosoul-core/examples/perf_baseline/media.rs','tauri/src-tauri/src/commands/attachment/mod.rs','tauri/src-tauri/src/commands/attachment/share.rs','tauri/src-tauri/src/commands/attachment/tests.rs'}")
(B/'build-rf1135-pages-probe.py').write_text(builder,encoding='utf-8',newline='\n')
print(S)
