from pathlib import Path
import importlib.util,json,hashlib,tarfile,io
R=Path('D:/SoloSoul'); B=Path(__file__).parent; F=B/'rf1135-android-attachment-temp-20261012'
P=B/'rf1135-android-native-pages-round4-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
receipt=load(P/'first-100-diagnostic.receipt.json')
assert receipt['exitCode']==0 and all(receipt[n] for n in ['passed','restored','originalApksRestored','ownedProbeRemoved','blurRestored','sourceInputsUnchanged'])
native=load(P/'first-100-diagnostic/device-files/report.json')
assert native['success'] and len(native['phases'])==10 and all(n['success'] for n in native['phases'])
for n in ['workspace-fmt','workspace-clippy','workspace-tests']:assert load(F/'windows-checks'/f'{n}.receipt.json')['exitCode']==0
assert '29 passed; 0 failed; 0 ignored' in (F/'windows-checks/workspace-tests.stdout.log').read_text()
helper=R/'tauri/scripts/android-home-native-regression.py';spec=importlib.util.spec_from_file_location('rf1135_inventory',helper);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
names=['rf312-android-media-native-proposal-20261012','rf312-android-media-native-round2-20261012','rf312-android-media-native-round3-20261012','rf312-android-media-native-round4-20261012','rf312-android-media-native-round5-20261012',F.name,'rf1135-android-media-native-20261012','rf1135-android-native-pages-round2-20261012','rf1135-android-native-pages-round3-20261012',P.name]
audit=[]
for name in names:
    d=B/name/'first-100-diagnostic'
    if not (d/'private-data-before.tar').exists():continue
    a=d/'private-data-before.tar';z=d/'private-data-restored.tar'
    x=m.inventory(a,require_empty=True);y=m.inventory(z);assert x==y and len(x)==216
    audit.append({'run':name,'entries':216,'allContentsLinksModesMatch':True,'beforeSha256':sha(a.read_bytes()),'afterSha256':sha(z.read_bytes())})
(F/'complete-restoration-audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
target=R/'docs/verification/rf1135-android-attachment-temp-2026-10-12';target.mkdir(exist_ok=False)
members={}
for name in names:
    root=B/name
    for p in root.rglob('*'):
        relative=p.relative_to(root)
        if any(n in {'project','jni','.gradle'} for n in relative.parts) or not p.is_file():continue
        if p.suffix.lower() not in {'.json','.log','.py','.kt','.rs','.png'}:continue
        if p.is_symlink():raise RuntimeError('Unexpected source symlink')
        members[name+'/'+relative.as_posix()]=p.read_bytes()
for name in ['prepare-rf1135-checks.py','build-rf1135-android-release.py','package-rf1135-android-release.py','run-rf1135-windows-checks.py','prepare-rf1135-native.py','prepare-rf1135-pages-round2.py','prepare-rf1135-pages-round3.py','prepare-rf1135-pages-round4.py','build-rf1135-pages-probe.py','build-rf1135-pages-probe-round3.py','build-rf1135-pages-probe-round4.py','archive-rf1135-results.py']:
    members['orchestration/'+name]=(B/name).read_bytes()
sources=load(F/'sources.json')
for name in load(F/'changes.json')['changed']:
    raw=(R/name).read_bytes();assert sha(raw)==sources[name];members['validated-working-source/'+name]=raw
archive=target/'raw.tar'
with tarfile.open(archive,'w') as out:
    for name,raw in sorted(members.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;out.addfile(info,io.BytesIO(raw))
index={'schemaVersion':1,'task':'RF-1135','archive':'raw.tar','archiveSha256':sha(archive.read_bytes()),'members':{n:{'bytes':len(v),'sha256':sha(v)} for n,v in sorted(members.items())},'privateDataProgramsKeysAndDatabasesExcluded':True}
with tarfile.open(archive) as inp:
    assert {n.name for n in inp}==set(members)
    for n,proof in index['members'].items():
        raw=inp.extractfile(n).read();assert len(raw)==proof['bytes'] and sha(raw)==proof['sha256']
(target/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
summary={'schemaVersion':1,'task':'RF-1135','status':'native-complete-awaiting-independent-image-review','sourceParentHead':'98dac44bd338d4fce6ca7eca3977ebdce119b8d1','validatedSourceHashes':{n:sources[n] for n in load(F/'changes.json')['changed']},'hostChecks':{'fmt':0,'strictClippy':0,'attachmentTests':{'passed':29,'failed':0,'ignored':0,'filtered':763}},'optimizedAndroidBuild':load(F/'android-release-build/receipt.json'),'nativeRun':receipt,'nativeScope':'100 public synthetic objects; functional diagnostic only','nativePdf':{n:native['nativePdf-'+n] for n in ['text_only.pdf','scanned.pdf']},'restorationAudit':audit,'rawIndex':target.name+'/index.json','fullRF312Accepted':False,'pushed':False}
(R/'docs/verification/rf1135-android-attachment-temp-2026-10-12.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'members':len(members),'archiveBytes':archive.stat().st_size,'nativePhases':len(native['phases']),'restoredPairs':len(audit)}))
