from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,time,zipfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;I=B/'rf1135-android-attachment-temp-20261012'
S=I/'android-release-package';S.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
sources=load(I/'sources.json');library=load(I/'android-release-build/library.json')
assert load(I/'android-release-build/receipt.json')['exitCode']==0
assert library['actualCargoReleaseBuilt'] and library['earlyObserverMarkersPresent']
old=load(B/'rf312-android-release-build-20261012/input-proof.json')
original=load(B/'rf312-android-release-native-20261012/inputs.json')
lib=Path(library['copy']);assert sha(lib)==library['sha256']
originalJni=R/'tauri/src-tauri/gen/android/app/src/main/jniLibs/x86_64/libsolo_soul.so'
originalJniSha=sha(originalJni)
jni=S/'jni/x86_64/libsolo_soul.so';jni.parent.mkdir(parents=True);shutil.copyfile(lib,jni)
assets=B/'current-apks-rf1121-20261011/packaging-assets'
def frozen():
    assert all(sha(R/n)==h for n,h in sources.items())
    assert all(sha(assets/n)==h for n,h in old['mobilePackagingAssets'].items())
    assert sha(lib)==sha(jni)==library['sha256']
    assert sha(originalJni)==originalJniSha
    for row in [original['release']['apk'],original['originalDebug'],original['originalTest']]:
        assert sha(Path(row.get('path',row.get('copy'))))==row['sha256']
frozen()
init=S/'package.init.gradle'
init.write_text("""gradle.beforeProject { project ->
  project.pluginManager.withPlugin('com.android.application') {
    def android = project.extensions.getByName('android')
    android.sourceSets.getByName('main').assets.setSrcDirs([project.file('"""+assets.as_posix()+"""')])
    android.sourceSets.getByName('main').jniLibs.setSrcDirs([project.file('"""+(S/'jni').as_posix()+"""')])
    project.extensions.getByName('androidComponents').finalizeDsl { extension ->
      extension.buildTypes.getByName('release').signingConfig = null
    }
  }
}
""",encoding='utf-8',newline='\n')
jdk=Path('C:/Users/40299571/ss-android/jdk');sdk=B/'sdk';g=R/'tauri/src-tauri/gen/android'
env=os.environ.copy();env.update(JAVA_HOME=str(jdk),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),
    NDK_HOME=str(sdk/'ndk/27.0.12077973'),ANDROID_NDK_HOME=str(sdk/'ndk/27.0.12077973'),
    ANDROID_USER_HOME=str(B/'android-user'),RUSTUP_HOME=str(B/'rustup'),RUSTUP_TOOLCHAIN='1.96.0',
    CARGO_HOME=str(B/'cargo-home'),CARGO_TARGET_DIR=str(B/'cargo-target'),CARGO_BUILD_JOBS='1',
    CARGO_NET_OFFLINE='true',GRADLE_USER_HOME=str(B/'gradle-home'),TEMP=str(B/'tmp'),TMP=str(B/'tmp'),
    JAVA_TOOL_OPTIONS=f'-Duser.home={B/"java-home"} -Djava.io.tmpdir={B/"tmp"}')
for key in ['ANDROID_SDK_HOME','SOLOSOUL_RF312_ANDROID_BUILD_OFFLINE','PDFIUM_LIBRARY_PATH',
            'SOLOSOUL_KEYSTORE_PATH','SOLOSOUL_KEYSTORE_PASSWORD','SOLOSOUL_KEY_ALIAS','SOLOSOUL_KEY_PASSWORD',
            'SOLOSOUL_REGISTRY_PUBKEY','GITHUB_RUN_NUMBER']:env.pop(key,None)
env['PATH']=str(jdk/'bin')+';'+env.get('PATH','')
def run(label,command,expected=0):
    frozen();began=time.monotonic();unix=time.time()
    with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(command,cwd=g,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,
            creationflags=subprocess.CREATE_NO_WINDOW)
        save(S/(label+'.live.json'),{'pid':p.pid,'command':command,'startedUnixSeconds':unix})
        print(label,'live PID',p.pid,flush=True);code=p.wait()
    frozen();save(S/(label+'.receipt.json'),{'exitCode':code,'command':command,
        'elapsedSeconds':time.monotonic()-began,'sourceAndOriginalApksUnchanged':True,
        'generatedDebugJniUnchanged':True})
    assert code==expected,(label,code)
    print(label,'exit',code,flush=True)
    return unix,(S/(label+'.stdout.log')).read_text(encoding='utf-8')
nm=sdk/'ndk/27.0.12077973/toolchains/llvm/prebuilt/windows-x86_64/bin/llvm-nm.exe'
defaultLib=B/'rf312-android-release-build-20261012/release-libsolo_soul.so'
assert sha(defaultLib)=='fc37bde0578b82825df7790bf362be41339043a85b938119d72667d382b5071b'
_,before=run('default-jni-exports',[str(nm),'-D','--defined-only',str(defaultLib)])
_,after=run('observer-jni-exports',[str(nm),'-D','--defined-only',str(lib)])
def jni_exports(text):
    return sorted(line.split()[-1] for line in text.splitlines() if line.split() and
                  (line.split()[-1].startswith('Java_') or line.split()[-1]=='JNI_OnLoad'))
prior=jni_exports(before);current=jni_exports(after)
assert prior and current==prior,(prior,current)
save(S/'jni-exports.json',{'default':prior,'observer':current,'exactNativeEntryNamesPreserved':True})
start,_=run('release-gradle-package',['cmd.exe','/d','/c',str(g/'gradlew.bat'),':app:assembleX86_64Release',
    '-x',':app:rustBuildX86_64Release','--init-script',str(init),'--offline','--no-daemon','--max-workers','2'])
root=g/'app/build/outputs/apk/x86_64/release'
apks=list(root.glob('*.apk'));assert len(apks)==1 and apks[0].stat().st_mtime>=start-2
apk=S/'app-x86_64-release-unsigned.apk';shutil.copyfile(apks[0],apk)
stripped=g/'app/build/intermediates/stripped_native_libs/x86_64Release/stripX86_64ReleaseDebugSymbols/out/lib/x86_64/libsolo_soul.so'
strippedSha=sha(stripped)
with zipfile.ZipFile(apk) as z:
    natives=[n for n in z.namelist() if n.startswith('lib/') and n.endswith('.so')]
    assert natives and all(n.startswith('lib/x86_64/') for n in natives)
    data=z.read('lib/x86_64/libsolo_soul.so')
    assert hashlib.sha256(data).hexdigest()==strippedSha
    assert b'android-native-ipc-transport-observer' in data and b'__SOLOSOUL_ANDROID_NATIVE_PERF__' in data
_,badging=run('release-badging',[str(sdk/'build-tools/35.0.0/aapt2.exe'),'dump','badging',str(apk)])
assert "package: name='com.solosoul.app'" in badging and "native-code: 'x86_64'" in badging
assert 'application-debuggable' not in badging
assert "minSdkVersion:'28'" in badging and "targetSdkVersion:'36'" in badging
signer=load(B/'rf312-android-release-build-20261012/internal-test-signer.json');key=Path(signer['keyFile'])
assert sha(key)==signer['keyFileSha256'] and signer['existingTestApkCertificateMatches']
tool=[str(jdk/'bin/java.exe'),'-jar',str(sdk/'build-tools/35.0.0/lib/apksigner.jar')]
run('unsigned-check',tool+['verify','--verbose',str(apk)],expected=1)
signed=S/'app-x86_64-release-early-observer-internal-validation.apk'
run('internal-test-sign',tool+['sign','--ks',str(key),'--ks-key-alias','androiddebugkey',
    '--ks-pass','pass:android','--key-pass','pass:android','--out',str(signed),str(apk)])
_,cert=run('internal-test-signature',tool+['verify','--verbose','--print-certs',str(signed)])
assert re.findall(r'certificate SHA-256 digest: (\S+)',cert)==[signer['certificateSha256']]
with zipfile.ZipFile(apk) as a,zipfile.ZipFile(signed) as z:
    assert all(hashlib.sha256(z.read(n)).hexdigest()==hashlib.sha256(a.read(n)).hexdigest()
        for n in a.namelist() if not n.endswith('/'))
    extra=set(z.namelist())-set(a.namelist())
    assert all(n.endswith('/') or re.fullmatch(r'META-INF/(?:MANIFEST\.MF|[^/]+\.(?:SF|RSA|DSA|EC))',n) for n in extra)
assert sha(key)==signer['keyFileSha256'];frozen()
save(S/'package-verification.json',{'acceptedPackagePreparation':True,'apk':{
    'path':str(signed),'sha256':sha(signed),'bytes':signed.stat().st_size},
    'certificateSha256':signer['certificateSha256'],'abi':'x86_64','applicationDebuggable':False,
    'minSdk':28,'targetSdk':36,'scope':'non-default Android early IPC transport measurement Release',
    'library':library,'packagedStrippedLibrarySha256':strippedSha,'observerMarkersPresent':True,
    'jniExportsUnchanged':True,'productionSigningNotUsed':True,'onlyExistingTestCertificateUsed':True,
    'generatedDebugJniUnchanged':True,'sourceAndOriginalApksUnchanged':True,
    'codeAndAssetsUnchangedBySigning':True,'nativeRuntimeAccepted':False,'fullRF312Accepted':False,
    'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print('Optional observer Release APK prepared; original packages/JNI preserved; native acceptance still required',flush=True)
