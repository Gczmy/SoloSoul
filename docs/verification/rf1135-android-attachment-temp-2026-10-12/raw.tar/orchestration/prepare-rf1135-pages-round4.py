from pathlib import Path
import json,re,zlib,hashlib
B=Path(__file__).parent;old=B/'rf1135-android-native-pages-round3-20261012';S=B/'rf1135-android-native-pages-round4-20261012'
assert json.loads((old/'first-100-diagnostic.receipt.json').read_text())['restored']
pdf=Path('D:/SoloSoul/tauri/crates/solosoul-core/tests/fixtures/scanned.pdf').read_bytes()
decoded=[]
for match in re.finditer(rb'stream\r?\n(.*?)\r?\nendstream',pdf,re.S):
    try:decoded.append(zlib.decompress(match.group(1)))
    except zlib.error:pass
assert any(raw==b'\xff'*40000 for raw in decoded)
S.mkdir(exist_ok=False)
(S/'blank-scanned-fixture-proof.json').write_text(json.dumps({'fileSha256':hashlib.sha256(pdf).hexdigest(),'decodedImagePixels':40000,'allSamples':255,'nativeReferenceObservedAllWhite':True,'nonblankScanRenderingProven':False},indent=2)+'\n',encoding='utf-8')
for name in ['AndroidMediaPerfInstrumentedTest.kt','current-runtime-sources.json','inputs.json','media-native-driver.py','run-first-100-diagnostic.py']:
    raw=(old/name).read_text(encoding='utf-8').replace(old.name,S.name)
    if name.endswith('.kt'):
        raw=raw.replace('last.optInt("inkPixels")>100)', '(last.optInt("inkPixels")>100 || (fileName=="scanned.pdf" && last.optInt("lightPixels")==last.optInt("bitmapWidth")*last.optInt("bitmapHeight"))))')
        needle='''            assertTrue("Actual displayed PDF page must contain text/image ink: $proof",proof.getInt("actualWindowPageDarkPixels")>100)'''
        assert raw.count(needle)==1
        raw=raw.replace(needle,'''            val blankFixture=activity.findViewById<TextView>(activity.resources.getIdentifier("pdfTitle","id",activity.packageName)).text.toString()=="scanned.pdf"
            if(blankFixture) {
                val area=(proof.getInt("right")-proof.getInt("left"))*(proof.getInt("bottom")-proof.getInt("top"))
                assertEquals("Known blank fixture must have no invented ink",0,proof.getInt("actualWindowPageDarkPixels"))
                assertTrue(proof.getInt("actualWindowPageWhitePixels")>=area*0.999)
                proof.put("knownBlankFixture",true).put("nonblankScanRenderingProven",false)
            } else assertTrue("Actual displayed PDF page must contain text ink: $proof",proof.getInt("actualWindowPageDarkPixels")>100)''')
        raw=raw.replace('last.put("plaintextSha256",actualSha)', 'last.put("knownBlankFixture",fileName=="scanned.pdf").put("plaintextSha256",actualSha)')
    if name=='media-native-driver.py':
        raw=raw.replace("proof.get('inkPixels',0)>100", "(proof.get('inkPixels',0)>100 if name=='text_only.pdf' else proof.get('knownBlankFixture') is True and proof.get('lightPixels',0)==proof.get('bitmapWidth',0)*proof.get('bitmapHeight',0))")
        raw=raw.replace("proof.get('windowPixels',{}).get('actualWindowPageDarkPixels',0)>100", "(proof.get('windowPixels',{}).get('actualWindowPageDarkPixels',0)>100 if name=='text_only.pdf' else proof.get('windowPixels',{}).get('actualWindowPageDarkPixels')==0 and proof.get('windowPixels',{}).get('knownBlankFixture') is True)")
    (S/name).write_text(raw,encoding='utf-8',newline='\n')
builder=(B/'build-rf1135-pages-probe-round3.py').read_text(encoding='utf-8').replace(old.name,S.name)
(B/'build-rf1135-pages-probe-round4.py').write_text(builder,encoding='utf-8',newline='\n')
print(S)
