from pathlib import Path
import json
B=Path(__file__).parent;old=B/'rf1135-android-native-pages-round2-20261012';S=B/'rf1135-android-native-pages-round3-20261012'
assert json.loads((old/'probe-build.receipt.json').read_text())['exitCode']==1
S.mkdir(exist_ok=False)
for name in ['AndroidMediaPerfInstrumentedTest.kt','current-runtime-sources.json','inputs.json','media-native-driver.py','run-first-100-diagnostic.py']:
    raw=(old/name).read_text(encoding='utf-8').replace(old.name,S.name)
    if name.endswith('.kt'):
        raw=raw.replace('==if(fileName=="text_only.pdf") "1 / 2" else "1 / 1"','==(if(fileName=="text_only.pdf") "1 / 2" else "1 / 1")')
        raw=raw.replace('.put("opaquePixels",opaque)','.put("nonTransparentPixels",opaque)')
        needle='''        val done=CountDownLatch(1);var code=-1;var capture:Bitmap?=null'''
        assert raw.count(needle)==1
        raw=raw.replace(needle,'''        val frames=CountDownLatch(1)
        instrumentation.runOnMainSync {
            val decor=activity.window.decorView
            assertTrue(decor.isAttachedToWindow && decor.hasWindowFocus())
            decor.postOnAnimation { decor.postOnAnimation { frames.countDown() } }
        }
        assertTrue("Actual native PDF must commit two frames",frames.await(5,TimeUnit.SECONDS))
'''+needle)
    (S/name).write_text(raw,encoding='utf-8',newline='\n')
raw=(B/'build-rf1135-pages-probe.py').read_text(encoding='utf-8').replace(old.name,S.name)
(B/'build-rf1135-pages-probe-round3.py').write_text(raw,encoding='utf-8',newline='\n')
print(S)
