from pathlib import Path
import json,hashlib
R=Path('D:/SoloSoul'); B=Path(__file__).parent; F=B/'rf1135-android-attachment-temp-20261012'
S=B/'rf1135-android-media-native-20261012';old=B/'rf312-android-media-native-round4-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert load(F/'android-release-build/receipt.json')['exitCode']==0
package=load(F/'android-release-package/package-verification.json')
assert package['acceptedPackagePreparation'] and not package['applicationDebuggable'] and package['sourceAndOriginalApksUnchanged']
assert hashlib.sha256(Path(package['apk']['path']).read_bytes()).hexdigest()==package['apk']['sha256']
S.mkdir(exist_ok=False)
for name in ['AndroidMediaPerfInstrumentedTest.kt','media-native-driver.py','run-first-100-diagnostic.py']:
    raw=(old/name).read_text(encoding='utf-8').replace(old.name,S.name)
    (S/name).write_text(raw,encoding='utf-8',newline='\n')
inputs=load(old/'inputs.json')
inputs['runtimeSourceFiles']=load(F/'sources.json')
inputs['release']=package
inputs.pop('sourceHead',None)
inputs['sourceParentHead']='98dac44bd338d4fce6ca7eca3977ebdce119b8d1'
inputs['sourceHasPendingRf1135Changes']=True
inputs['runtimeTest']=load(old/'current-test-apk.json')
# Independent probe bytecode remains exact round4; no failure-only JS producer.
assert hashlib.sha256((S/'AndroidMediaPerfInstrumentedTest.kt').read_bytes()).hexdigest()==inputs['runtimeTest']['homeTestSourceSha256']
(S/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
(S/'source-binding.json').write_text(json.dumps({'main':package['apk'],'mainSources':inputs['runtimeSourceFiles'],'probe':inputs['runtimeTest'],'additionalJsProducer':False,'scope':'native functional regression for RF-1135; not full RF-312 acceptance'},indent=2)+'\n',encoding='utf-8')
print(S)
