use std::{env, fs, io};
extern "C" { fn getuid() -> u32; }
fn main() {
    let name=env::args().nth(1).expect("unique diagnostic name");
    assert!(name.starts_with("rf312-temp-probe-") && name.len()==49);
    assert!(name[17..].bytes().all(|b|b.is_ascii_hexdigit()));
    let root=env::temp_dir();
    let uid=unsafe {getuid()};
    println!("scope=independent-android-uid-temp-directory-diagnostic");
    println!("uid={uid}");
    println!("TMPDIR={:?}",env::var_os("TMPDIR"));
    println!("temp_dir={}",root.display());
    let destination=root.join(name);
    match fs::create_dir(&destination) {
        Ok(())=> { fs::remove_dir(&destination).unwrap();println!("created_then_removed=true"); }
        Err(error)=> {
            println!("error_kind={:?}",error.kind());
            println!("os_error={:?}",error.raw_os_error());
            assert_eq!(error.kind(),io::ErrorKind::PermissionDenied);
        }
    }
}
