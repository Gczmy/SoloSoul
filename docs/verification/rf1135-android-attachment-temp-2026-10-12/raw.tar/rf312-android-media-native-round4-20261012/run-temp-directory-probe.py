from pathlib import Path
import os,subprocess,uuid,json,hashlib
S=Path(__file__).parent; B=S.parent
env=os.environ.copy();env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049')
adb=[str(B/'sdk/platform-tools/adb.exe'),'-s','emulator-5586']
rows=[]
def run(args):
    p=subprocess.run(adb+args,env=env,capture_output=True,timeout=30)
    rows.append({'command':args,'exitCode':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')})
    return p
local=S/'temp-directory-probe';sha=hashlib.sha256(local.read_bytes()).hexdigest()
assert run(['shell','getprop','ro.build.version.sdk']).stdout.strip()==b'31'
assert run(['shell','run-as','com.solosoul.app','id','-u']).stdout.strip()==b'10105'
name='rf312-temp-probe-'+uuid.uuid4().hex
remote='/data/local/tmp/'+name
try:
    assert run(['push',str(local),remote]).returncode==0
    assert run(['shell','sha256sum',remote]).stdout.decode().split()==[sha,remote]
    assert run(['shell','chmod','755',remote]).returncode==0
    result=run(['shell','run-as','com.solosoul.app',remote,name])
    (S/'temp-directory-native.stdout.log').write_bytes(result.stdout)
    (S/'temp-directory-native.stderr.log').write_bytes(result.stderr)
finally:
    cleanup=run(['shell','rm',remote]);assert cleanup.returncode==0
    (S/'temp-directory-native.json').write_text(json.dumps({'scope':'independent-Android-31-app-UID-Rust-temp-directory','sourceSha256':hashlib.sha256((S/'temp-directory-probe.rs').read_bytes()).hexdigest(),'binarySha256':sha,'commands':rows,'productInvokeNotExecuted':True,'doesNotReplaceProductNativeJourney':True,'ownedRemoteRemoved':True},indent=2)+'\n',encoding='utf-8')
print(result.stdout.decode(errors='replace'));print('exitCode',result.returncode)
assert result.returncode==0
assert b'uid=10105' in result.stdout and b'TMPDIR=None' in result.stdout and b'temp_dir=/data/local/tmp' in result.stdout and b'error_kind=PermissionDenied' in result.stdout
