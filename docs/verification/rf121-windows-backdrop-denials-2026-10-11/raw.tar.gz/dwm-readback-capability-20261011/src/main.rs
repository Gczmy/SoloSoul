use serde_json::json;
use windows::core::w;
use windows::Win32::Foundation::HWND;
use windows::Win32::Graphics::Dwm::{
    DwmGetWindowAttribute, DwmSetWindowAttribute, DWMSBT_MAINWINDOW,
    DWMWA_SYSTEMBACKDROP_TYPE, DWM_SYSTEMBACKDROP_TYPE,
};
use windows::Win32::UI::WindowsAndMessaging::{
    CreateWindowExW, DestroyWindow, GetWindowThreadProcessId, IsWindowVisible,
    WINDOW_EX_STYLE, WS_OVERLAPPEDWINDOW,
};

struct OwnedWindow(Option<HWND>);
impl Drop for OwnedWindow {
    fn drop(&mut self) {
        if let Some(hwnd) = self.0.take() {
            unsafe { let _ = DestroyWindow(hwnd); }
        }
    }
}
fn readback(hwnd: HWND) -> windows::core::Result<DWM_SYSTEMBACKDROP_TYPE> {
    let mut value = DWM_SYSTEMBACKDROP_TYPE::default();
    unsafe {
        DwmGetWindowAttribute(
            hwnd, DWMWA_SYSTEMBACKDROP_TYPE,
            (&mut value as *mut DWM_SYSTEMBACKDROP_TYPE).cast(),
            std::mem::size_of::<DWM_SYSTEMBACKDROP_TYPE>() as u32,
        )?;
    }
    Ok(value)
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let hwnd = unsafe {
        CreateWindowExW(
            WINDOW_EX_STYLE::default(), w!("STATIC"), w!("RF121 owned hidden backdrop capability"),
            WS_OVERLAPPEDWINDOW, 0, 0, 320, 240, None, None, None, None,
        )?
    };
    let mut owner = OwnedWindow(Some(hwnd));
    let mut pid = 0;
    assert_ne!(unsafe { GetWindowThreadProcessId(hwnd, Some(&mut pid)) }, 0);
    assert_eq!(pid, std::process::id());
    assert!(!unsafe { IsWindowVisible(hwnd) }.as_bool());
    let original = readback(hwnd)?;
    unsafe {
        DwmSetWindowAttribute(
            hwnd, DWMWA_SYSTEMBACKDROP_TYPE,
            (&DWMSBT_MAINWINDOW as *const DWM_SYSTEMBACKDROP_TYPE).cast(),
            std::mem::size_of::<DWM_SYSTEMBACKDROP_TYPE>() as u32,
        )?;
    }
    let observed = readback(hwnd)?;
    assert_eq!(observed, DWMSBT_MAINWINDOW);
    unsafe {
        DwmSetWindowAttribute(
            hwnd, DWMWA_SYSTEMBACKDROP_TYPE,
            (&original as *const DWM_SYSTEMBACKDROP_TYPE).cast(),
            std::mem::size_of::<DWM_SYSTEMBACKDROP_TYPE>() as u32,
        )?;
    }
    let restored = readback(hwnd)?;
    assert_eq!(restored, original);
    assert!(!unsafe { IsWindowVisible(hwnd) }.as_bool());
    assert_ne!(unsafe { GetWindowThreadProcessId(hwnd, Some(&mut pid)) }, 0);
    assert_eq!(pid, std::process::id());
    unsafe { DestroyWindow(hwnd)?; }
    owner.0 = None;
    println!("{}", json!({
        "scope":"Own newly created hidden STATIC window; capability only",
        "pid":pid,"attribute":38,"original":original.0,
        "expected":DWMSBT_MAINWINDOW.0,"observed":observed.0,"restored":restored.0,
        "documentedGetterWorked":true,"hiddenWindowDestroyed":true,
        "existingApplicationWindowsTouched":0,"pixelsRead":0,"inputEventsSent":0,
        "systemSettingsChanged":false,"productMaterialAccepted":false,
        "darkModeOrCaptionColorReadbackClaimed":false,
    }));
    Ok(())
}
