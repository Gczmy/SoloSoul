from pathlib import Path
import ast,hashlib,json,subprocess
w=Path(__file__).parent;stage=w/'helper-backdrop-reader-candidate-20261011'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text(encoding='utf8'))
prepared=load(stage/'drivers-prepared.json');backup=stage/'drivers-before-foreground-guard';backup.mkdir(exist_ok=False)
observed=w/'ss-rf121-composed-window-rf1116-retry2-baseline-20261011/actual100/sample-001'
state_path=observed/'native-perf-surface-before.json';frame_path=observed/'rf121-wgc-light-visible.json'
state=load(state_path)['state'];frame=load(frame_path)
assert state['focused'] is True and frame['foregroundBefore'] is False and frame['foregroundAfter'] is False
files={n:w/n for n in prepared['candidates']}
for n,f in files.items():
    assert sha(f)==prepared['candidates'][n];(backup/n).write_bytes(f.read_bytes())
def once(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
py=next(f for f in files.values() if f.suffix=='.py');js=next(f for f in files.values() if f.suffix=='.mjs')
p=once(py.read_text(encoding='utf8'),"                assert proof['dwmSystemBackdropType'] == expected_backdrop","                assert proof['dwmSystemBackdropType'] == expected_backdrop\n                assert proof['foregroundBefore'] is state['focused']\n                assert proof['foregroundAfter'] is state['focused']")
j=once(js.read_text(encoding='utf8'),"  assert.equal(typeof captured.foregroundBefore,'boolean');","  assert.equal(typeof captured.foregroundBefore,'boolean');\n  assert.equal(captured.foregroundBefore,before.state.focused);\n  assert.equal(captured.foregroundAfter,after.state.focused);") if "  assert.equal(typeof captured.foregroundBefore,'boolean');" in js.read_text(encoding='utf8') else once(js.read_text(encoding='utf8'),"assert.equal(typeof captured.foregroundBefore,'boolean');","assert.equal(typeof captured.foregroundBefore,'boolean');\n  assert.equal(captured.foregroundBefore,before.state.focused);\n  assert.equal(captured.foregroundAfter,after.state.focused);")
py.write_text(p,encoding='utf8',newline='\n');js.write_text(j,encoding='utf8',newline='\n');ast.parse(p)
result=subprocess.run(['node','--check',str(js)],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
(stage/'foreground-guard-node-check.stdout.log').write_bytes(result.stdout);(stage/'foreground-guard-node-check.stderr.log').write_bytes(result.stderr);assert result.returncode==0
record=dict(scope='Historical foreground inconsistency; candidate guards only',historical=dict(statePath=str(state_path),stateSha256=sha(state_path),framePath=str(frame_path),frameSha256=sha(frame_path),domFocused=state['focused'],nativeForegroundBefore=frame['foregroundBefore'],nativeForegroundAfter=frame['foregroundAfter'],fullMatrixWasAccepted=False),priorCandidates=prepared['candidates'],currentCandidates={n:sha(f) for n,f in files.items()},priorBytesPreserved=True,pythonSyntaxValid=True,nodeSyntaxExitCode=result.returncode,applicationExecuted=False,nativeUiAccepted=False,nextRequirement='Verify owned native foreground before publishing surface request; activate only the held owned window, preserve failure if OS refuses')
with (stage/'foreground-guard-prepared.json').open('x',encoding='utf8',newline='\n') as out:json.dump(record,out,indent=2);out.write('\n')
print('Candidate foreground coherence guards added; historical bytes preserved; application activation remains pending',flush=True)
