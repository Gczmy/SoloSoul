import assert from 'node:assert/strict';
import {readFile,writeFile,lstat,realpath} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {checkJourney,checkBound} from '../../tauri/scripts/native-perf-sdk-journey.mjs';
import {describeAuthAttribution} from '../../tauri/scripts/native-perf-auth-contract.mjs';
import {checkMaintenanceAdmission} from '../../tauri/scripts/native-perf-maintenance-contract.mjs';
const stage=path.dirname(fileURLToPath(import.meta.url)),root=path.resolve(stage,'../..');
const mode=process.argv[2];assert(['baseline','light-collapsed','dark-expanded','dark-collapsed'].includes(mode)&&process.argv.length===3);const count='100';
const group=path.join(stage,`ss-rf121-composed-window-backdrop-${mode}-20261011`),output=path.join(group,'actual100');
const load=async p=>JSON.parse((await readFile(p,'utf8')).replace(/^\uFEFF/,''));
const sha=async p=>createHash('sha256').update(await readFile(p)).digest('hex');
const regular=async(p,max=4194304)=>{const s=await lstat(p);assert(s.isFile()&&!s.isSymbolicLink()&&s.size<=max);assert.equal((await realpath(p)).toLowerCase(),p.toLowerCase());return load(p);};
const inputs=await load(path.join(group,'input-proof.json')),pkg=inputs.runtime;
assert.equal(await sha(pkg.exe),pkg.sha256);
for(const i of pkg.resources){assert.equal(await sha(i.source),i.sha256);assert.equal(await sha(i.copy),i.sha256);}
for(const [p,h] of Object.entries(await load(path.join(stage,'rf121-backdrop-checks-20261011/sources.json'))))assert.equal(await sha(path.join(root,p)),h);
for(const [p,h] of Object.entries(inputs.fixtureFiles))assert.equal(await sha(path.join(inputs.fixture,p)),h);
const receipt=await load(path.join(group,'actual100.receipt.json'));assert.equal(receipt.exitCode,0);assert(receipt.sourceUnchanged&&receipt.originalFixtureUnchanged&&receipt.resourcesUnchanged);
const journey=await load(path.join(output,'native-perf-sdk-journey-results.json')),authGroup=await load(path.join(output,'native-perf-auth-attribution-results.json'));
assert(journey.success&&journey.sourceUnchanged&&!journey.interrupted&&authGroup.success);
assert.equal(journey.exeSha256,pkg.sha256);assert.equal(journey.fixture.objectCount,Number(count));assert.equal(journey.samplesRequested,3);assert.equal(journey.memoryIntervalMs,null);
assert.deepEqual(journey.samples.map(s=>s.index),[1,2,3]);assert.equal(authGroup.samples.length,3);assert.equal(authGroup.performanceMetrics,null);
const samples=[];
for(const s of journey.samples){
 const dir=path.join(output,`sample-${String(s.index).padStart(3,'0')}`);assert.equal(s.root.toLowerCase(),dir.toLowerCase());assert(s.success&&s.cleanupIntegrity.complete);
 assert.deepEqual(await regular(path.join(output,`sample-${String(s.index).padStart(3,'0')}.json`)),s);
 const owned=await regular(path.join(dir,'native-perf-owned.json')),bound=await regular(path.join(dir,'native-perf-sdk-journey-bound.json'));
 assert.deepEqual(owned,s.owned);assert.deepEqual(bound,s.bound);checkBound(bound,owned,s.processId,bound.port);
 const native=await regular(path.join(dir,'native-perf-sdk-journey.json'));assert.deepEqual(native,s.nativeProof);checkJourney(native,owned,bound,journey.fixture,false);
 const auth=await regular(path.join(dir,'native-perf-auth-attribution.json')),flows=describeAuthAttribution(auth,owned,bound).frontend.flows;
 assert.equal(flows.length,2);assert(flows.every(f=>f.outcome==='finished'));
 const maintenance=checkMaintenanceAdmission(await regular(path.join(dir,'native-perf-maintenance-admission.json')),auth,owned,bound);
 const identity=await regular(path.join(dir,'surface-identity.json'));
 const activation=await regular(path.join(dir,'rf121-wgc-activate-owned.json'));
 assert.equal(activation.schemaVersion,1);assert.equal(activation.scope,'rf121-owned-window-foreground');
 assert.equal(activation.pid,bound.pid);assert.equal(activation.runId,owned.runId);assert.equal(activation.creationMs,identity.creationMs);
 assert.equal(activation.tag,'activate-owned');assert.equal(activation.foregroundBefore,false);assert.equal(activation.foregroundAfter,false);
 assert.equal(activation.apiReturned,false);assert.equal(activation.requested,true);
 assert.equal(activation.heldProcessAndWindowIdentityVerifiedBeforeAndAfter,true);
 assert.equal(activation.inputEventsSent,0);assert.equal(activation.pixelsRead,0);assert.equal(activation.otherWindowsActivated,0);
 assert.equal(activation.systemSettingsChanged,false);assert.equal(activation.applicationMaterialAccepted,false);
 const ar=await regular(path.join(dir,'surface-activation.receipt.json'));assert.equal(ar.exitCode,1);
 assert.deepEqual(ar.command,[pkg.activationExe,dir,String(bound.pid),String(identity.creationMs),pkg.exe,'activate-owned']);
 assert.deepEqual(JSON.parse(await readFile(path.join(dir,'surface-activation.stdout.log'),'utf8')),activation);
 for(const absent of ['native-perf-surface-request.json','native-perf-surface-before.json','native-perf-surface-after.json','native-perf-surface-scene-request.json','native-perf-surface-appearance-request.json','rf121-wgc-light-visible.bgra','rf121-wgc-dark-visible.bgra']){
   let missing=false;try{await lstat(path.join(dir,absent));}catch(e){assert.equal(e.code,'ENOENT');missing=true;}assert(missing);
 }

 // The public snapshot projects root/unknown checks into reason and workingSetBytes;
 // it does not expose the raw PowerShell rootVerified/unverifiedDescendants fields.
 for(const snapshot of [s.beforeSnapshot,s.afterSnapshot]){assert.equal(snapshot.reason,null);assert(Number.isFinite(snapshot.workingSetBytes)&&snapshot.workingSetBytes>0);assert(snapshot.processCount>1&&snapshot.userDataDirectoryMatches&&snapshot.browserDataFilesystem.valid);}
 assert.equal(s.cleanup.unverifiedDescendants,false);
 const recordedIdentities=[...s.beforeSnapshot.processes,...s.afterSnapshot.processes].map(p=>({pid:p.pid,creationMs:p.creationMs}));
 assert(recordedIdentities.every(p=>Number.isInteger(p.pid)&&Number.isFinite(p.creationMs)));
 samples.push({index:s.index,runId:owned.runId,pid:bound.pid,browserPid:bound.browserPid,recordedIdentities,maintenance,success:true,phaseNames:s.phases.map(p=>p.name),inputTrust:native.lastProbe.inputTrust,protocolCalls:native.calls});
}
assert.equal(new Set(samples.map(s=>s.runId)).size,3);
await writeFile(path.join(group,'journeys-only-cleanup-validation.json'),JSON.stringify({task:'RF-121',accepted:false,cleanupOnly:true,journeysOnlyAccepted:true,foregroundActivationAccepted:false,materialAccepted:false,requestedAppearanceScenesExecuted:false,pixelsRead:0,diagnosticOnly:true,performanceMetrics:null,fullRF121Accepted:false,fullRF312Accepted:false,objectCount:Number(count),samples},null,2)+'\n',{flag:'wx'});
console.log('Three actual default journeys and foreground-denial diagnostics verified for cleanup only; no requested appearance scene or material accepted:',mode);
