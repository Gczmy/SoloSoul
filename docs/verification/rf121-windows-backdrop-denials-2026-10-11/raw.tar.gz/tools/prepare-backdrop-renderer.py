from pathlib import Path
import ast
p=Path(__file__).parent
s=(p/'round5-render-surface-captures.py').read_text(encoding='utf8')
a="assert sys.argv[1:] in [['--round', '5']]"
b="assert len(sys.argv)==2 and sys.argv[1] in ['--baseline','--light-collapsed','--dark-expanded','--dark-collapsed']"
assert s.count(a)==1;s=s.replace(a,b)
a="stage = Path(__file__).parent / ('ss-rf121-composed-window-current' if not sys.argv[1:] else 'ss-rf121-composed-window-current-round' + sys.argv[2])"
b="stage = Path(__file__).parent / ('ss-rf121-composed-window-backdrop-' + sys.argv[1][2:] + '-20261011')"
assert s.count(a)==1;s=s.replace(a,b);ast.parse(s)
with (p/'render-rf121-backdrop-captures.py').open('x',encoding='utf8',newline='\n') as f:f.write(s)
print('Four-mode renderer prepared; no captures rendered yet')
