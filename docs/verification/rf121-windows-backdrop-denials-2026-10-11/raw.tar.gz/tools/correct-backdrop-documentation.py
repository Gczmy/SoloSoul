from pathlib import Path
import json
r=Path('D:/SoloSoul');w=Path(__file__).parent;s=w/'rf121-backdrop-checks-20261011'
p=r/'docs/verification/RF-121-windows-theme-binding.md'
sources=json.loads((s/'sources.json').read_text(encoding='utf8'))
assert p.relative_to(r).as_posix() not in sources
old=p.read_bytes()
with (s/'historical-theme-binding-doc.before.md').open('xb') as f:f.write(old)
text=old.decode('utf8').replace('\r\n','\n')
a='九份实际前快照均为 Windows light/mica。这里的 mica 是 DOM 材质状态，不是原生属性读回或视觉验收。微软 [DWMWINDOWATTRIBUTE 文档](https://learn.microsoft.com/en-us/windows/win32/api/dwmapi/ne-dwmapi-dwmwindowattribute)将深色、标题栏颜色、系统背景类型列为设置属性；当前工具不把未文档化的 getter 当作能力前提。这三项记 null，nativeAppearanceVerified=false。原 PID/birth/EXE、唯一窗口、几何、前台状态、DPI 和像素守卫保留。旧工具、固定 D 盘工具和明确读取能力的工具分别保存。'
b='九份实际前快照均为 Windows light/mica。这里的 mica 是 DOM 材质状态，不是原生属性读回或视觉验收。原轮工具将深色、标题栏颜色和系统背景类型三项记 null，nativeAppearanceVerified=false；其实际失败及能力口径保留。2026-10-11 更正：微软 [DWMWINDOWATTRIBUTE 文档](https://learn.microsoft.com/en-us/windows/win32/api/dwmapi/ne-dwmapi-dwmwindowattribute)明确允许用 DwmGetWindowAttribute 读取 DWMWA_SYSTEMBACKDROP_TYPE，要求 Windows 11 Build 22621 起；深色及标题栏颜色仍按文档的设置属性处理。独立隐藏自有窗口能力探针已实际完成背景类型的读取、设置和恢复，但不能据此追溯认定旧应用截图已验证原生 Mica。原 PID/birth/EXE、唯一窗口、几何、前台状态、DPI 和像素守卫保留。原工具和原件保持，新读取工具需绑定当前构建后单独验证。'
assert text.count(a)==1;text=text.replace(a,b)
p.write_text(text,encoding='utf8',newline='\n')
print('Documented backdrop getter corrected; historical failures and acceptance scope retained')
