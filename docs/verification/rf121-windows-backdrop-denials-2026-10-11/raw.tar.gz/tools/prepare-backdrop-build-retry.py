from pathlib import Path
import ast,json
w=Path(__file__).parent;s=w/'rf121-backdrop-checks-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf8'))
old=load(s/'native-contract-tests.receipt.json');assert old['exitCode']==101 and old['sourceUnchanged']
log=(s/'native-contract-tests.stdout.log').read_text(encoding='utf8');err=(s/'native-contract-tests.stderr.log').read_text(encoding='utf8')
assert '115 passed; 14 failed; 0 ignored;' in log and 'could not create the isolated test junction' in err and 'startup exit query failed' in err
source=(w/'run-backdrop-current-build.py').read_text(encoding='utf8')
def once(a,b):
    global source
    assert source.count(a)==1,a;source=source.replace(a,b)
once('s.mkdir(exist_ok=False)','assert s.is_dir()')
once("save('sources.json',sources)","assert load(s/'sources.json')==sources")
once("save('session-before-build.json',result)","save('session-before-retry-build.json',result)")
once("save('starting-state.json',dict(","save('retry1-starting-state.json',dict(")
once("code,changed=run('native-clippy',['cargo','clippy','--locked','--features','native-perf','--all-targets','--','-D','warnings'],denv);assert code==0 and not changed", "original_clippy=load(s/'native-clippy.receipt.json');assert original_clippy['exitCode']==0 and original_clippy['sourceUnchanged'];print('Reuse unchanged successful current-source native Clippy; preserve original failed native test run',flush=True)")
source=source.replace("'native-contract-tests'","'native-contract-tests-retry1'").replace("'native-contract-tests.stdout.log'","'native-contract-tests-retry1.stdout.log'").replace("'native-contract-totals.json'","'native-contract-totals-retry1.json'")
once("guiExecuted=False,applicationMaterialAccepted=False)","guiExecuted=False,applicationMaterialAccepted=False,nativeContractTestsReceipt='native-contract-tests-retry1.receipt.json',priorFailedNativeTestsPreserved=True)")
ast.parse(source)
with (w/'run-backdrop-current-build-retry1.py').open('x',encoding='utf8',newline='\n') as f:f.write(source)
capture=w/'run-backdrop-captures.py';oldcapture=capture.read_bytes()
with (s/'capture-queue-before-test-retry.py').open('xb') as f:f.write(oldcapture)
t=oldcapture.decode();a="for n in ['native-clippy','native-contract-tests','native-release-build']:assert load(s/(n+'.receipt.json'))['exitCode']==0"
b="for n in ['native-clippy','native-release-build']:assert load(s/(n+'.receipt.json'))['exitCode']==0\nassert load(s/package['nativeContractTestsReceipt'])['exitCode']==0\nassert package['priorFailedNativeTestsPreserved'] and load(s/'native-contract-tests.receipt.json')['exitCode']==101"
assert t.count(a)==1;t=t.replace(a,b);ast.parse(t);capture.write_text(t,encoding='utf8',newline='\n')
with (s/'retry-preparation.json').open('x',encoding='utf8') as f:json.dump(dict(originalTests=dict(passed=115,failed=14,ignored=0),originalReceiptKept=True,productSourcesModified=False,allOriginal129TestsWillRerun=True,successfulClippyNotRepeated=True,scope='Run full native Windows tests with required junction, atomic publication and CIM capabilities'),f,indent=2)
print('Preserved failing 129-test run; complete unchanged suite retry and configured GUI build prepared')
