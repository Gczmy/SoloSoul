"""Read only caller desktop/station identity and foreground PID; no titles/pixels."""
from pathlib import Path
import ctypes,ctypes.wintypes as wt,datetime,json,os
w=Path(__file__).parent;u=ctypes.WinDLL('user32',use_last_error=True);k=ctypes.WinDLL('kernel32',use_last_error=True)
k.GetCurrentThreadId.restype=wt.DWORD
u.GetProcessWindowStation.restype=wt.HANDLE;u.GetThreadDesktop.argtypes=[wt.DWORD];u.GetThreadDesktop.restype=wt.HANDLE
u.OpenInputDesktop.argtypes=[wt.DWORD,wt.BOOL,wt.DWORD];u.OpenInputDesktop.restype=wt.HANDLE;u.CloseDesktop.argtypes=[wt.HANDLE];u.CloseDesktop.restype=wt.BOOL
u.GetUserObjectInformationW.argtypes=[wt.HANDLE,ctypes.c_int,wt.LPVOID,wt.DWORD,ctypes.POINTER(wt.DWORD)];u.GetUserObjectInformationW.restype=wt.BOOL
u.GetForegroundWindow.restype=wt.HWND;u.GetWindowThreadProcessId.argtypes=[wt.HWND,ctypes.POINTER(wt.DWORD)];u.GetWindowThreadProcessId.restype=wt.DWORD
def name(h):
    if not h:return dict(available=False,error=ctypes.get_last_error())
    b=ctypes.create_unicode_buffer(1024);needed=wt.DWORD()
    ok=u.GetUserObjectInformationW(h,2,b,ctypes.sizeof(b),ctypes.byref(needed))
    return dict(available=bool(ok),name=b.value if ok else None,error=None if ok else ctypes.get_last_error())
caller=u.GetThreadDesktop(k.GetCurrentThreadId());station=u.GetProcessWindowStation();desktop=u.OpenInputDesktop(0,False,1)
result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),callerPid=os.getpid(),callerDesktop=name(caller),callerWindowStation=name(station),inputDesktop=name(desktop),pixelsRead=0,inputEventsSent=0,userNamesOrWindowTitlesRead=False,systemSettingsChanged=False)
if desktop:assert u.CloseDesktop(desktop)
hwnd=u.GetForegroundWindow();pid=wt.DWORD();tid=u.GetWindowThreadProcessId(hwnd,ctypes.byref(pid)) if hwnd else 0
result['foreground']=dict(hwnd=int(hwnd or 0),pid=pid.value,threadId=tid)
path=w/('current-desktop-identity-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.json')
with path.open('x',encoding='utf8') as f:json.dump(result,f,indent=2)
print(json.dumps(result),flush=True)
