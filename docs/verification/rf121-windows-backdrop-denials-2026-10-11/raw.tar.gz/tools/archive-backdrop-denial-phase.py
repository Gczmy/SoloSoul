"""Archive actual failure evidence without granting appearance acceptance."""
from pathlib import Path
import datetime,hashlib,io,json,tarfile
r=Path('D:/SoloSoul');w=Path(__file__).parent;s=w/'rf121-backdrop-checks-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
sources=load(s/'sources.json');assert len(sources)==1834 and all(sha(r/n)==h for n,h in sources.items())
package=load(s/'runtime-package.json');assert sha(Path(package['exe']))==package['sha256'] and len(package['resources'])==94
for v in package['resources']:assert sha(Path(v['source']))==sha(Path(v['copy']))==v['sha256']
assert load(s/'cohorts-complete.json')['success'] is False
receipts={n:load(s/(n+'.receipt.json')) for n in ['native-clippy','native-contract-tests','native-contract-tests-retry1','native-release-build']}
assert receipts['native-contract-tests']['exitCode']==101
assert '115 passed; 14 failed; 0 ignored;' in (s/'native-contract-tests.stdout.log').read_text(encoding='utf8')
assert all(receipts[n]['exitCode']==0 for n in ['native-clippy','native-contract-tests-retry1','native-release-build'])
assert load(s/'native-contract-totals-retry1.json')==dict(passed=129,failed=0,ignored=0)
cleanup=load(w/'rf121-backdrop-denied-cache-cleanup.json')
assert cleanup['preservedBytesVerified'] and cleanup['matchingOwnedIdentitiesLive']==cleanup['processesTerminatedByThisTool']==0 and len(cleanup['removedCachePaths'])==96
for v in cleanup['preservedVaultAndRootFiles']:assert sha(Path(v['path']))==v['sha256']
for v in cleanup['applicationLogs']:assert sha(Path(v['copy']))==v['sha256']
assert all(not Path(p).exists() for p in cleanup['removedCachePaths'])
capability=load(w/'dwm-readback-capability-20261011/result.json');assert capability['exitCode']==0 and capability['actual']['documentedGetterWorked']
h=w/'helper-backdrop-reader-candidate-20261011'
for n in ['candidate-format','candidate-clippy','candidate-tests']:assert load(h/(n+'.receipt.json'))['exitCode']==0
assert (h/'candidate-tests.stdout.log').read_text(encoding='utf8').count('6 passed; 0 failed; 0 ignored;')==2
files={};allowed={'.json','.log','.py','.mjs','.rs','.toml','.lock','.ps1','.md','.txt'}
def add(p,n):
    assert p.is_file() and not p.is_symlink() and not(p.lstat().st_file_attributes&0x400) and n not in files,n
    assert p.suffix in allowed,p
    files[n]=p
def group(path,name):
    for p in path.rglob('*'):
        if p.is_file() and p.suffix in allowed:add(p,name+'/'+p.relative_to(path).as_posix())
group(s,'checks')
for name in ['helper-backdrop-reader-candidate-20261011','dwm-readback-capability-20261011','rf121-fs-capability-sandbox-20261011','rf121-fs-capability-unrestricted-20261011','owned-caption-capability-20261011','application-logs-rf121-backdrop']:group(w/name,name)
for patterns in ['*backdrop*.py','*backdrop*.mjs','*foreground*.py','*denial*.py','*desktop-identity*.py','current-desktop-identity*.json']:
    for p in w.glob(patterns):
        if 'tools/'+p.name not in files:add(p,'tools/'+p.name)
for name in ['dwm-readback-capability.rs','dwm-readback-capability.py','probe-sdk-filesystem-capability.py','probe-owned-caption-activation.py','cleanup-rf121-backdrop-denied-owned.ps1','rf121-backdrop-denied-cache-cleanup-plan.json','rf121-backdrop-denied-cache-cleanup-preflight.json','rf121-backdrop-denied-cache-cleanup.json','verify-backdrop-foreground-denial-for-cleanup.mjs']:
    if 'tools/'+name not in files:add(w/name,'tools/'+name)
groups=[]
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
    cap=w/('ss-rf121-composed-window-backdrop-'+mode+'-20261011');v=load(cap/'journeys-only-cleanup-validation.json')
    assert v['accepted'] is False and v['journeysOnlyAccepted'] and v['cleanupOnly'] and len(v['samples'])==3
    assert v['foregroundActivationAccepted'] is v['materialAccepted'] is v['requestedAppearanceScenesExecuted'] is False and v['pixelsRead']==0
    for p in cap.iterdir():
        if p.is_file():add(p,mode+'/'+p.name)
    for p in (cap/'actual100').iterdir():
        if p.is_file():add(p,mode+'/actual100/'+p.name)
        elif p.name in ['sample-001','sample-002','sample-003']:
            for leaf in p.iterdir():
                if leaf.is_file():add(leaf,mode+'/actual100/'+p.name+'/'+leaf.name)
    groups.append({'mode':mode,'validation':v,'actualNormalJourneysPassed':3,'foregroundActivationsDenied':3,'requestedScenesExecuted':0})
stem='rf121-windows-backdrop-denials-2026-10-11';out=r/'docs/verification'/stem;out.mkdir(exist_ok=False)
(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf8')
members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as t:
    for n,p in sorted(files.items()):
        data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data));members.append({'path':n,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(out/'raw.tar.gz','r:gz') as t:
    assert set(t.getnames())=={v['path'] for v in members}
    for v in members:
        data=t.extractfile(v['path']).read();assert len(data)==v['size'] and hashlib.sha256(data).hexdigest()==v['sha256']
archive={'path':stem+'/raw.tar.gz','sha256':sha(out/'raw.tar.gz'),'members':len(members),'allMembersVerified':True}
save(out/'index.json',{'task':'RF-121','archiveSha256':archive['sha256'],'members':members,'allMembersVerified':True,'unexecutedSuccessOnlyTools':['archive-backdrop-foreground.py','render-rf121-backdrop-captures.py','cleanup-rf121-backdrop-owned.ps1'],'excluded':['executables','models','physical Vault files','caches']})
save(r/'docs/verification'/(stem+'.json'),{'task':'RF-121','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Current GUI build, documented host capability and actual foreground denials','sourceCount':len(sources),'sourceManifestSha256':sha(s/'sources.json'),'runtime':package,'checks':receipts,'originalNativeTests':{'passed':115,'failed':14,'ignored':0},'nativeRetryTests':{'passed':129,'failed':0,'ignored':0},'helperTests':{'passed':12,'failed':0,'ignored':0},'capability':capability,'groups':groups,'cleanup':cleanup,'archive':archive,'normalSdkJourneysPassed':12,'foregroundActivationsDenied':12,'requestedAppearanceScenesExecuted':0,'pixelsRead':0,'applicationMaterialAccepted':False,'fullRF121Accepted':False,'fullRF312Accepted':False,'systemSettingsChanged':False,'desktopRoute':'WinSta0/Default, session 1 Active','observedForegroundProcess':'PickerHost.exe','uniqueRootCauseEstablished':False,'productSourceChanged':False})
print(json.dumps({'archive':archive,'journeysPassed':12,'foregroundDenied':12,'materialAccepted':False}),flush=True)
