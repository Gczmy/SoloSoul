from pathlib import Path
import ast,hashlib,json,os,subprocess
w=Path(__file__).parent;stage=w/'helper-backdrop-reader-candidate-20261011'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old_py=w/'run-rf1116-retry2-native-surfaces.py';old_js=w/'verify-rf1116-retry2-native-surfaces.mjs'
original={p.name:sha(p) for p in [old_py,old_js]}
def once(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
def paths(s):
    assert 'rf1116-checks-20261011' in s and 'rf1116-retry2-' in s
    return s.replace('rf1116-checks-20261011','rf121-backdrop-checks-20261011').replace('rf1116-retry2-','backdrop-')
p=paths(old_py.read_text(encoding='utf8'))
p=once(p,"package = load(stage / 'rf121-backdrop-checks-20261011/runtime-package.json')","package = load(stage / 'rf121-backdrop-checks-20261011/runtime-package.json')\nassert package['helperMetadataVersion'] == 3")
p=once(p,"                if package.get('helperMetadataVersion') == 2:\n                    assert proof['nativeAppearanceVerified'] is False and proof['dwmAppearanceReadback'] == 'no-documented-getters'\n                    assert all(proof[k] is None for k in ['dwmDarkMode', 'dwmCaptionColor', 'dwmSystemBackdropType'])",'''                assert proof['nativeAppearanceVerified'] is False
                assert proof['dwmAppearanceReadback'] == 'documented-system-backdrop-only'
                assert proof['dwmDarkMode'] is None and proof['dwmCaptionColor'] is None
                readback = proof['dwmSystemBackdropReadback']
                assert set(readback) == {'attribute', 'before', 'after', 'stable'}
                assert type(readback['attribute']) is int and readback['attribute'] == 38
                assert readback['stable'] is True and readback['before'] == readback['after']
                expected_backdrop = 2 if state['material'] == 'mica' else 1
                for observed in [readback['before'], readback['after']]:
                    assert set(observed) == {'ok', 'value', 'errorHresult'}
                    assert observed['ok'] is True and observed['errorHresult'] is None
                    assert type(observed['value']) is int and observed['value'] == expected_backdrop
                assert type(proof['dwmSystemBackdropType']) is int
                assert proof['dwmSystemBackdropType'] == expected_backdrop''')
p=once(p,"'nativeDwmThemeMatchesDom': None if package.get('helperMetadataVersion') == 2 else proof['dwmDarkMode'] == (state['theme'] == 'dark'),","'nativeDwmThemeMatchesDom': None,")
p=once(p,"'nativeAppearancePropertiesVerified': package.get('helperMetadataVersion') != 2,","'nativeAppearancePropertiesVerified': False, 'nativeSystemBackdropVerified': True,")
j=paths(old_js.read_text(encoding='utf8'))
j=once(j,'const pkg=inputs.runtime;','const pkg=inputs.runtime;\nassert.equal(pkg.helperMetadataVersion,3);')
a=j.index('  if(pkg.helperMetadataVersion===2){');b=j.index('  assert.equal(captured.pixelFile',a)
j=j[:a]+'''  assert.equal(captured.nativeAppearanceVerified,false);
  assert.equal(captured.dwmAppearanceReadback,'documented-system-backdrop-only');
  assert.equal(captured.dwmDarkMode,null);assert.equal(captured.dwmCaptionColor,null);
  const readback=captured.dwmSystemBackdropReadback;
  exact(readback,['attribute','before','after','stable']);assert.equal(readback.attribute,38);
  assert.equal(readback.stable,true);assert.deepEqual(readback.before,readback.after);
  const expectedBackdrop=before.state.material==='mica'?2:1;
  for(const observed of [readback.before,readback.after]){
    exact(observed,['ok','value','errorHresult']);assert.equal(observed.ok,true);
    assert.equal(observed.errorHresult,null);assert.equal(observed.value,expectedBackdrop);
  }
  assert.equal(captured.dwmSystemBackdropType,expectedBackdrop);
'''+j[b:]
j=once(j,"scope:'windows-owned-theme-state-capture-binding'","scope:'windows-owned-backdrop-state-capture-binding'")
j=once(j,'nativeAppearancePropertiesVerified:pkg.helperMetadataVersion!==2','nativeAppearancePropertiesVerified:false,nativeSystemBackdropVerified:true')
out_py=w/'run-rf121-backdrop-native-surfaces-candidate.py';out_js=w/'verify-rf121-backdrop-native-surfaces-candidate.mjs'
for f,text in [(out_py,p),(out_js,j)]:
    with f.open('x',encoding='utf8',newline='\n') as out:out.write(text)
ast.parse(p)
checked=subprocess.run(['node','--check',str(out_js)],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
(stage/'driver-node-check.stdout.log').write_bytes(checked.stdout);(stage/'driver-node-check.stderr.log').write_bytes(checked.stderr)
assert checked.returncode==0
assert all(sha(w/n)==h for n,h in original.items())
with (stage/'drivers-prepared.json').open('x',encoding='utf8',newline='\n') as out:
    json.dump(dict(scope='Candidate drivers; syntax checks only, no application executed',originalDrivers=original,originalDriversUnchanged=True,candidates={out_py.name:sha(out_py),out_js.name:sha(out_js)},pythonSyntaxValid=True,nodeSyntaxExitCode=checked.returncode,metadataVersion=3,requiresCurrentRuntimePackage=True,sourceDirectory='rf121-backdrop-checks-20261011',samplePrefix='ss-rf121-composed-window-backdrop-',nativeUiAccepted=False),out,indent=2);out.write('\n')
print('Metadata-v3 candidate drivers prepared; originals unchanged; no runtime acceptance',flush=True)
