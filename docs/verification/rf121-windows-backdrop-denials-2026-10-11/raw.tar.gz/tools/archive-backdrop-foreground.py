"""Archive only independently verified cohorts; full RF-121 remains incomplete."""
from pathlib import Path
import datetime,hashlib,io,json,shutil,tarfile
r=Path('D:/SoloSoul');w=Path(__file__).parent;s=w/'rf121-backdrop-checks-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(s/'cohorts-complete.json')['success']
sources=load(s/'sources.json');assert len(sources)==1834 and sources==load(w/'rf1121-checks-20261011/green-sources.json')
assert all(sha(r/n)==h for n,h in sources.items())
package=load(s/'runtime-package.json');assert sha(Path(package['exe']))==package['sha256'] and len(package['resources'])==94
for v in package['resources']:assert sha(Path(v['source']))==sha(Path(v['copy']))==v['sha256']
receipts={n:load(s/(n+'.receipt.json')) for n in ['native-clippy','native-contract-tests','native-contract-tests-retry1','native-release-build']}
assert receipts['native-contract-tests']['exitCode']==101 and receipts['native-contract-tests']['sourceUnchanged']
assert all(receipts[n]['exitCode']==0 for n in ['native-clippy','native-contract-tests-retry1','native-release-build'])
assert load(s/'native-contract-totals-retry1.json')==dict(passed=129,failed=0,ignored=0)
assert '115 passed; 14 failed; 0 ignored;' in (s/'native-contract-tests.stdout.log').read_text(encoding='utf8')
cleanup=load(w/'rf121-backdrop-cache-cleanup.json')
assert cleanup['preservedBytesVerified'] and cleanup['matchingOwnedIdentitiesLive']==cleanup['processesTerminatedByThisTool']==0
for v in cleanup['preservedVaultAndRootFiles']:assert sha(Path(v['path']))==v['sha256']
capability=load(w/'dwm-readback-capability-20261011/result.json');assert capability['exitCode']==0 and capability['actual']['documentedGetterWorked']
files={}
def add(p,n):
    assert p.is_file() and not p.is_symlink() and not(p.lstat().st_file_attributes&0x400) and n not in files,n
    files[n]=p
for p in s.rglob('*'):
    if p.is_file():add(p,'checks/'+p.relative_to(s).as_posix())
for group in ['helper-backdrop-reader-candidate-20261011','dwm-readback-capability-20261011','rf121-fs-capability-sandbox-20261011','rf121-fs-capability-unrestricted-20261011','application-logs-rf121-backdrop']:
    for p in (w/group).rglob('*'):
        if p.is_file():
            assert p.suffix not in ['.exe','.dll','.pdb','.lib','.onnx'],p
            add(p,group+'/'+p.relative_to(w/group).as_posix())
for pattern in ['*backdrop*.py','*backdrop*.mjs','*foreground*.py']:
    for p in w.glob(pattern):
        if 'tools/'+p.name not in files:add(p,'tools/'+p.name)
for name in ['dwm-readback-capability.rs','dwm-readback-capability.py','probe-sdk-filesystem-capability.py','cleanup-rf121-backdrop-owned.ps1','rf121-backdrop-cache-cleanup-plan.json','rf121-backdrop-cache-cleanup-preflight.json','rf121-backdrop-cache-cleanup.json']:
    add(w/name,'tools/'+name)
groups=[]
stem='rf121-windows-backdrop-foreground-2026-10-11';out=r/'docs/verification'/stem;out.mkdir(exist_ok=False);(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf8')
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
    cap=w/('ss-rf121-composed-window-backdrop-'+mode+'-20261011');validation=load(cap/'validation.json');review=load(cap/'visual-review.json')
    assert validation['accepted'] and validation['nativeSystemBackdropVerified'] and not validation['fullMatrixAccepted'] and len(validation['samples'])==3
    assert review['actualImagesInspected']==3 and review['fullMatrixAccepted'] is False
    for sample in validation['samples']:
        state=sample['state'];frame=sample['capture'];assert state['focused'] is frame['foregroundBefore'] is frame['foregroundAfter'] is True
        assert state['theme']==('dark' if mode.startswith('dark-') else 'light') and state['expanded'] is (not mode.endswith('collapsed'))
        assert frame['dwmSystemBackdropType']==(2 if state['material']=='mica' else 1)
    for p in cap.iterdir():
        if p.is_file():add(p,mode+'/'+p.name)
    for p in (cap/'actual100').iterdir():
        if p.is_file():add(p,mode+'/actual100/'+p.name)
        elif p.name in ['sample-001','sample-002','sample-003']:
            for leaf in p.iterdir():
                if leaf.is_file():add(leaf,mode+'/actual100/'+p.name+'/'+leaf.name)
    images=[]
    for v in load(cap/'rendered-captures.json'):
        p=Path(v['png']);assert sha(p)==v['pngSha256'];dest=out/(mode+'-sample-'+str(v['index']).zfill(3)+'.png');shutil.copy2(p,dest);assert sha(dest)==v['pngSha256'];images.append(dict(path=dest.relative_to(r).as_posix(),sha256=sha(dest)))
    groups.append(dict(mode=mode,validation=validation,visualReview=review,images=images))
members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as t:
    for n,p in sorted(files.items()):
        data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data));members.append(dict(path=n,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(out/'raw.tar.gz','r:gz') as t:
    assert set(t.getnames())=={v['path'] for v in members}
    for v in members:
        data=t.extractfile(v['path']).read();assert len(data)==v['size'] and hashlib.sha256(data).hexdigest()==v['sha256']
save(out/'index.json',dict(task='RF-121',archiveSha256=sha(out/'raw.tar.gz'),members=members,allMembersVerified=True,excluded=['executables','models','physical Vault entities','caches']))
save(r/'docs/verification'/(stem+'.json'),dict(task='RF-121',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),acceptedSubset=True,scope='Current Windows source, owned foreground window and documented backdrop getter, four homepage theme/sidebar cohorts',fullMatrixAccepted=False,applicationMaterialAccepted=False,otherPlatformAcceptance=False,systemSettingsChanged=False,sourceCount=len(sources),sourceManifestSha256=sha(s/'sources.json'),runtime=package,checks=receipts,originalNativeTests=dict(passed=115,failed=14,ignored=0),successfulNativeTests=dict(passed=129,failed=0,ignored=0),helperTests=dict(passed=12,failed=0,ignored=0),capability=capability,groups=groups,cleanup=cleanup,archive=dict(path=stem+'/raw.tar.gz',sha256=sha(out/'raw.tar.gz'),members=len(members),allMembersVerified=True)))
print(json.dumps(dict(task='RF-121',members=len(members),actualJourneys=12,actualForegroundBackdropsVerified=12,fullMatrixAccepted=False)),flush=True)
