from pathlib import Path
import datetime,json,subprocess,time
w=Path(__file__).parent;s=w/'rf121-backdrop-checks-20261011'
for mode in ['light-collapsed','dark-expanded','dark-collapsed']:
    start=time.monotonic();cmd=['node',str(w/'verify-backdrop-foreground-denial-for-cleanup.mjs'),mode]
    with (s/('denial-reader-'+mode+'.stdout.log')).open('xb') as out,(s/('denial-reader-'+mode+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW);code=p.wait()
    with (s/('denial-reader-'+mode+'.receipt.json')).open('x',encoding='utf8') as f:json.dump(dict(command=cmd,exitCode=code,pid=p.pid,elapsedSeconds=time.monotonic()-start,at=datetime.datetime.now(datetime.timezone.utc).isoformat()),f,indent=2)
    print(mode,code,flush=True);assert code==0
print('Twelve default journeys and all twelve foreground denials independently checked; zero appearance scenes or pixel/material acceptance')
