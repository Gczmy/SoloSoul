from pathlib import Path
import ast
w=Path(__file__).parent
s=(w/'cleanup-rf1116-owned.ps1').read_text(encoding='utf8').replace('rf1116','rf121-backdrop').replace('RF-1116','RF-121')
def once(a,b):
    global s
    assert s.count(a)==1,a;s=s.replace(a,b)
once('$validation.groups.Count -ne 7','$validation.groups.Count -ne 4')
once('Seven terminal verified owned groups','Four terminal independently verified owned groups')
assert s.count('-ne 168')==2;s=s.replace('-ne 168','-ne 96').replace('one hundred sixty-eight','ninety-six')
assert 'ss-rf121-backdrop-runtime-20261011' in s
a='$liveHelpers = @(Get-CimInstance Win32_Process -Filter "Name = \'rf121-wgc-owned-window.exe\'" | Where-Object ExecutablePath -EQ \'D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\helper-target-readable\\debug\\rf121-wgc-owned-window.exe\')'
b='$taskHelperExecutables = @(\'D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\helper-target-readable\\debug\\rf121-wgc-backdrop-candidate.exe\',\'D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\helper-target-readable\\debug\\rf121-owned-foreground-candidate.exe\')\n$liveHelpers = @(Get-CimInstance Win32_Process -Filter "Name = \'rf121-wgc-backdrop-candidate.exe\' OR Name = \'rf121-owned-foreground-candidate.exe\'" | Where-Object { $_.ExecutablePath -in $taskHelperExecutables })'
once(a,b)
with (w/'cleanup-rf121-backdrop-owned.ps1').open('x',encoding='utf8',newline='\n') as f:f.write(s)
p='''from pathlib import Path
import json
w=Path(__file__).parent;s=w/'rf121-backdrop-checks-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert load(s/'cohorts-complete.json')['success']
groups=[]
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
    capture=w/('ss-rf121-composed-window-backdrop-'+mode+'-20261011')
    receipt=load(capture/'actual100.receipt.json');validation=load(capture/'validation.json')
    assert receipt['exitCode']==0 and validation['accepted'] and len(validation['samples'])==3
    assert validation['nativeSystemBackdropVerified'] and not validation['fullMatrixAccepted']
    for sample in validation['samples']:
        assert sample['capture']['foregroundBefore'] is sample['capture']['foregroundAfter'] is sample['state']['focused'] is True
        assert sample['capture']['dwmSystemBackdropType']==2 and sample['state']['material']=='mica'
    groups.append(dict(label=mode,captureRoot=str(capture),terminal=True,samples=validation['samples']))
with (w/'rf121-backdrop-cache-cleanup-plan.json').open('x',encoding='utf8') as f:
    json.dump(dict(cacheCleanupEligible=True,failedSamplesAccepted=False,fullMaterialMatrixAccepted=False,groups=groups),f,indent=2)
print('Twelve independent terminal samples eligible for 96 exact owned cache targets; no deletion performed')
'''
ast.parse(p)
with (w/'prepare-backdrop-cleanup-plan.py').open('x',encoding='utf8',newline='\n') as f:f.write(p)
print('Cleanup tools prepared only; no plan, files or processes removed')
