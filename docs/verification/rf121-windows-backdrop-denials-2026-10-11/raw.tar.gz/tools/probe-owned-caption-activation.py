"""Own temporary STATIC window, native-caption hit only; no foreign clicks/settings."""
from pathlib import Path
import ctypes,ctypes.wintypes as t,datetime,json,os,time
w=Path(__file__).parent;s=w/'owned-caption-capability-20261011';s.mkdir(exist_ok=False)
u=ctypes.WinDLL('user32',use_last_error=True);k=ctypes.WinDLL('kernel32',use_last_error=True)
k.GetModuleHandleW.argtypes=[t.LPCWSTR];k.GetModuleHandleW.restype=t.HMODULE
u.CreateWindowExW.argtypes=[t.DWORD,t.LPCWSTR,t.LPCWSTR,t.DWORD,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,t.HWND,t.HMENU,t.HINSTANCE,t.LPVOID];u.CreateWindowExW.restype=t.HWND
u.DestroyWindow.argtypes=[t.HWND];u.DestroyWindow.restype=t.BOOL;u.ShowWindow.argtypes=[t.HWND,ctypes.c_int];u.ShowWindow.restype=t.BOOL
u.SetForegroundWindow.argtypes=[t.HWND];u.SetForegroundWindow.restype=t.BOOL;u.GetForegroundWindow.restype=t.HWND
u.SetWindowPos.argtypes=[t.HWND,t.HWND,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int,t.UINT];u.SetWindowPos.restype=t.BOOL
u.GetWindowRect.argtypes=[t.HWND,ctypes.POINTER(t.RECT)];u.GetWindowRect.restype=t.BOOL
u.GetWindowThreadProcessId.argtypes=[t.HWND,ctypes.POINTER(t.DWORD)];u.GetWindowThreadProcessId.restype=t.DWORD
u.WindowFromPoint.argtypes=[t.POINT];u.WindowFromPoint.restype=t.HWND
u.SendMessageW.argtypes=[t.HWND,t.UINT,t.WPARAM,t.LPARAM];u.SendMessageW.restype=t.LPARAM
u.GetCursorPos.argtypes=[ctypes.POINTER(t.POINT)];u.GetCursorPos.restype=t.BOOL
u.SetCursorPos.argtypes=[ctypes.c_int,ctypes.c_int];u.SetCursorPos.restype=t.BOOL
u.PeekMessageW.argtypes=[ctypes.POINTER(t.MSG),t.HWND,t.UINT,t.UINT,t.UINT];u.PeekMessageW.restype=t.BOOL
u.TranslateMessage.argtypes=[ctypes.POINTER(t.MSG)];u.DispatchMessageW.argtypes=[ctypes.POINTER(t.MSG)];u.DispatchMessageW.restype=t.LPARAM
class Mouse(ctypes.Structure):_fields_=[('dx',t.LONG),('dy',t.LONG),('data',t.DWORD),('flags',t.DWORD),('time',t.DWORD),('extra',ctypes.c_size_t)]
class Input(ctypes.Structure):_fields_=[('kind',t.DWORD),('mouse',Mouse)]
assert ctypes.sizeof(Input)==40
u.SendInput.argtypes=[t.UINT,ctypes.POINTER(Input),ctypes.c_int];u.SendInput.restype=t.UINT
hwnd=u.CreateWindowExW(0x40000,'STATIC','RF-121 owned caption capability',0x00CF0000,160,100,400,260,None,None,k.GetModuleHandleW(None),None);assert hwnd
pid=t.DWORD();u.GetWindowThreadProcessId(hwnd,ctypes.byref(pid));assert pid.value==os.getpid()
result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),hwnd=int(hwnd),scope='Only newly created own temporary STATIC window',inputEventsSent=0,foreignWindowClicks=0,pixelsRead=0,systemSettingsChanged=False,applicationMaterialAccepted=False)
try:
    u.ShowWindow(hwnd,4);result['foregroundInitially']=u.GetForegroundWindow()==hwnd
    result['setForegroundReturned']=bool(u.SetForegroundWindow(hwnd))
    result['foregroundAfterApi']=u.GetForegroundWindow()==hwnd
    if not result['foregroundAfterApi']:
        assert u.SetWindowPos(hwnd,None,0,0,0,0,0x0001|0x0002|0x0010)
        rect=t.RECT();assert u.GetWindowRect(hwnd,ctypes.byref(rect));point=t.POINT((rect.left+rect.right)//2,rect.top+18)
        assert u.WindowFromPoint(point)==hwnd,'Refuse click on another window'
        packed=(point.x&0xffff)|((point.y&0xffff)<<16);hit=int(u.SendMessageW(hwnd,0x84,0,packed));result['nativeHitTest']=hit
        assert hit==2,'Refuse non-caption hit'
        original=t.POINT();assert u.GetCursorPos(ctypes.byref(original));assert u.SetCursorPos(point.x,point.y)
        try:
            assert u.WindowFromPoint(point)==hwnd and u.SendMessageW(hwnd,0x84,0,packed)==2
            inputs=(Input*2)(Input(0,Mouse(0,0,0,2,0,0)),Input(0,Mouse(0,0,0,4,0,0)))
            sent=int(u.SendInput(2,inputs,ctypes.sizeof(Input)));result['inputEventsSent']=sent
            if sent==1:
                release=Input(0,Mouse(0,0,0,4,0,0));result['extraReleaseEventsSent']=int(u.SendInput(1,ctypes.byref(release),ctypes.sizeof(Input)))
            assert sent==2,'Native input not fully inserted'
            end=time.monotonic()+2
            while time.monotonic()<end:
                msg=t.MSG()
                while u.PeekMessageW(ctypes.byref(msg),None,0,0,1):u.TranslateMessage(ctypes.byref(msg));u.DispatchMessageW(ctypes.byref(msg))
                if u.GetForegroundWindow()==hwnd:break
                time.sleep(.01)
        finally:
            actual=t.POINT();assert u.GetCursorPos(ctypes.byref(actual));result['cursorRestored']=False
            if (actual.x,actual.y)==(point.x,point.y):result['cursorRestored']=bool(u.SetCursorPos(original.x,original.y))
    result['foregroundAfter']=u.GetForegroundWindow()==hwnd
except Exception as e:result['error']=str(e)
finally:
    assert u.DestroyWindow(hwnd);result['ownWindowDestroyed']=True
    with (s/'result.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2)
    print(json.dumps(result),flush=True)
raise SystemExit(0 if result.get('foregroundAfter') else 1)
