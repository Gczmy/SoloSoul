from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
root=Path('D:/SoloSoul');w=Path(__file__).parent;stage=w/'dwm-readback-capability-20261011';stage.mkdir(exist_ok=False);src=stage/'src';src.mkdir()
old=w/'helper-d-root-readable';hash=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={n:hash(old/n) for n in ['Cargo.toml','Cargo.lock','src/bin/owned-window.rs']}
manifest=(old/'Cargo.toml').read_text(encoding='utf8');manifest=manifest[:manifest.index('[[bin]]')]+'''[[bin]]
name = "rf121-dwm-readback-capability"
path = "src/main.rs"
'''
(stage/'Cargo.toml').write_text(manifest,encoding='utf8',newline='\n');shutil.copyfile(old/'Cargo.lock',stage/'Cargo.lock');shutil.copyfile(w/'dwm-readback-capability.rs',src/'main.rs')
env=os.environ.copy();desktop=root/'build/rf312-maintenance-20261009';env.update(TEMP=str(desktop/'tmp'),TMP=str(desktop/'tmp'),CARGO_HOME=str(desktop/'cargo-home'),CARGO_TARGET_DIR=str(w/'helper-target-readable'),CARGO_BUILD_JOBS='1')
env.pop('PDFIUM_LIBRARY_PATH',None)
def save(n,v):
    with (stage/n).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def run(n,cmd):
    start=time.monotonic()
    with (stage/(n+'.stdout.log')).open('xb') as out,(stage/(n+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=stage,env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
        save(n+'.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()));print(n,'PID',p.pid,flush=True);code=p.wait()
    assert all(hash(old/n)==h for n,h in before.items())
    save(n+'.receipt.json',dict(exitCode=code,pid=p.pid,command=cmd,elapsedSeconds=time.monotonic()-start,originalWgcHelperUnchanged=True))
    return code
assert run('compile',['cargo','build','--locked','--offline','--bin','rf121-dwm-readback-capability'])==0
exe=w/'helper-target-readable/debug/rf121-dwm-readback-capability.exe'
code=run('capability',[str(exe)])
data=dict(scope='Host documented getter capability; not application verification',exitCode=code,binarySha256=hash(exe),sourceSha256=hash(src/'main.rs'),originalHelperHashes=before,originalHelperUnchanged=True,productSourceChanged=False,productUiAcceptance=False,primaryReferences=['https://learn.microsoft.com/en-us/windows/win32/api/dwmapi/ne-dwmapi-dwmwindowattribute','https://learn.microsoft.com/en-us/windows/win32/api/dwmapi/ne-dwmapi-dwm_systembackdrop_type'])
if code==0:data['actual']=json.loads((stage/'capability.stdout.log').read_text(encoding='utf8'))
save('result.json',data);print(json.dumps(data),flush=True)
