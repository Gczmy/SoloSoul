from pathlib import Path
import ast,hashlib,json,subprocess
w=Path(__file__).parent;stage=w/'helper-backdrop-reader-candidate-20261011';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text(encoding='utf8'))
prior=load(stage/'foreground-guard-prepared.json');helper=load(stage/'foreground-helper-prepared.json')
assert sha(Path(helper['source']))==helper['sourceSha256'] and sha(Path(helper['exe']))==helper['binarySha256']
backup=stage/'drivers-before-activation-integration';backup.mkdir(exist_ok=False)
files={n:w/n for n in prior['currentCandidates']}
for n,f in files.items():assert sha(f)==prior['currentCandidates'][n];(backup/n).write_bytes(f.read_bytes())
def once(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
py=next(f for f in files.values() if f.suffix=='.py');js=next(f for f in files.values() if f.suffix=='.mjs');p=py.read_text(encoding='utf8');j=js.read_text(encoding='utf8')
p=once(p,"exe, helper = Path(package['exe']), Path(package['helperExe'])","exe, helper = Path(package['exe']), Path(package['helperExe'])\nactivation_helper = Path(package['activationExe'])")
p=once(p,"    assert sha(exe) == package['sha256'] and sha(helper) == package['helperSha256']","    assert sha(exe) == package['sha256'] and sha(helper) == package['helperSha256']\n    assert sha(activation_helper) == package['activationSha256']\n    assert sha(Path(package['activationSource'])) == package['activationSourceSha256']")
a=p.index('                # CIM reads only this consumed, bound');b=p.index('                before_path = wait_file(',a);identity=p[a:b];p=p[:a]+p[b:]
activation='''                activation_args = [str(activation_helper), str(sample), str(pid), str(owner['creationMs']), str(exe), 'activate-owned']
                activation_began = time.monotonic()
                activated = subprocess.run(activation_args, cwd=stage, env=env, capture_output=True,
                                           creationflags=subprocess.CREATE_NO_WINDOW, timeout=25)
                for name, data in [('stdout', activated.stdout), ('stderr', activated.stderr)]:
                    with (sample / ('surface-activation.' + name + '.log')).open('xb') as log: log.write(data)
                save(sample / 'surface-activation.receipt.json', {'at': now(), 'command': activation_args,
                     'exitCode': activated.returncode, 'elapsedSeconds': time.monotonic() - activation_began})
                assert activated.returncode == 0, 'Owned native foreground activation refused'
                foreground = ordinary(sample / 'rf121-wgc-activate-owned.json', 262144)
                assert foreground == json.loads(activated.stdout.decode('utf-8-sig'))
                assert foreground['schemaVersion'] == 1 and foreground['scope'] == 'rf121-owned-window-foreground'
                assert foreground['runId'] == run_id and foreground['pid'] == pid
                assert foreground['creationMs'] == owner['creationMs'] and foreground['tag'] == 'activate-owned'
                assert foreground['foregroundAfter'] is True
                assert foreground['heldProcessAndWindowIdentityVerifiedBeforeAndAfter'] is True
                assert foreground['pixelsRead'] == foreground['inputEventsSent'] == foreground['otherWindowsActivated'] == 0
                assert foreground['systemSettingsChanged'] is False and foreground['applicationMaterialAccepted'] is False
'''
p=once(p,"                request = {'schemaVersion': 1, 'scope': 'windows-native-surface-request',",identity+activation+"                request = {'schemaVersion': 1, 'scope': 'windows-native-surface-request',")
p=once(p,"                assert proof['scope'] == 'rf121-owned-window-wgc-frame'","                assert proof['scope'] == 'rf121-owned-window-wgc-frame'\n                assert proof['hwnd'] == foreground['hwnd']")
j=once(j,'assert.equal(await sha(pkg.exe),pkg.sha256);assert.equal(await sha(pkg.helperExe),pkg.helperSha256);','assert.equal(await sha(pkg.exe),pkg.sha256);assert.equal(await sha(pkg.helperExe),pkg.helperSha256);\nassert.equal(await sha(pkg.activationExe),pkg.activationSha256);\nassert.equal(await sha(pkg.activationSource),pkg.activationSourceSha256);')
guard='''  const activation=await regular(path.join(dir,'rf121-wgc-activate-owned.json'));
  const activationReceipt=await regular(path.join(dir,'surface-activation.receipt.json'));
  exact(activation,['schemaVersion','scope','runId','pid','creationMs','hwnd','tag','foregroundBefore','foregroundAfter','requested','apiReturned','elapsedMilliseconds','heldProcessAndWindowIdentityVerifiedBeforeAndAfter','pixelsRead','inputEventsSent','systemSettingsChanged','applicationMaterialAccepted','otherWindowsActivated']);
  assert.equal(activationReceipt.exitCode,0);
  assert.deepEqual(activationReceipt.command,[pkg.activationExe,dir,String(bound.pid),String(owner.creationMs),pkg.exe,'activate-owned']);
  assert.deepEqual(await regular(path.join(dir,'surface-activation.stdout.log')),activation);
  assert.equal(activation.schemaVersion,1);assert.equal(activation.scope,'rf121-owned-window-foreground');
  assert.equal(activation.runId,owned.runId);assert.equal(activation.pid,bound.pid);
  assert.equal(activation.creationMs,owner.creationMs);assert.equal(activation.hwnd,captured.hwnd);
  assert.equal(activation.tag,'activate-owned');assert.equal(activation.foregroundAfter,true);
  assert.equal(typeof activation.foregroundBefore,'boolean');assert.equal(activation.requested,!activation.foregroundBefore);
  if(activation.requested)assert.equal(typeof activation.apiReturned,'boolean');else assert.equal(activation.apiReturned,null);
  number(activation.elapsedMilliseconds,0,25000);
  assert.equal(activation.heldProcessAndWindowIdentityVerifiedBeforeAndAfter,true);
  for(const key of ['pixelsRead','inputEventsSent','otherWindowsActivated'])assert.equal(activation[key],0);
  for(const key of ['systemSettingsChanged','applicationMaterialAccepted'])assert.equal(activation[key],false);
'''
j=once(j,'  assert.equal(captured.schemaVersion,pkg.helperMetadataVersion??1);',guard+'  assert.equal(captured.schemaVersion,pkg.helperMetadataVersion??1);')
py.write_text(p,encoding='utf8',newline='\n');js.write_text(j,encoding='utf8',newline='\n');ast.parse(p)
result=subprocess.run(['node','--check',str(js)],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
(stage/'activation-driver-node-check.stdout.log').write_bytes(result.stdout);(stage/'activation-driver-node-check.stderr.log').write_bytes(result.stderr);assert result.returncode==0
with (stage/'activation-drivers-prepared.json').open('x',encoding='utf8',newline='\n') as out:
    json.dump(dict(scope='Foreground preparation before surface request; candidate syntax only',priorCandidates=prior['currentCandidates'],currentCandidates={n:sha(f) for n,f in files.items()},priorBytesPreserved=True,pythonSyntaxValid=True,nodeSyntaxExitCode=result.returncode,activationBeforeSurfaceRequest=True,sameActivatedAndCapturedHwndRequired=True,activationBinaryAndSourceProvenanceRequired=True,requiresFreshRuntimePackage=True,applicationExecuted=False,nativeUiAccepted=False),out,indent=2);out.write('\n')
print('Candidate activation handshake integrated; no application run or acceptance claimed',flush=True)
