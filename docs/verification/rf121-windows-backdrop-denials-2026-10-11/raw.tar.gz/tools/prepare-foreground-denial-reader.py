from pathlib import Path
import subprocess
w=Path(__file__).parent;s=w/'rf121-backdrop-checks-20261011'
t=(w/'verify-rf1117-journeys.mjs').read_text(encoding='utf8')
def once(a,b):
    global t
    assert t.count(a)==1,a;t=t.replace(a,b)
once("const count=process.argv[2];assert(['100','5000'].includes(count)&&process.argv.length===3);","const mode=process.argv[2];assert(['baseline','light-collapsed','dark-expanded','dark-collapsed'].includes(mode)&&process.argv.length===3);const count='100';")
once('`ss-rf1117-owned-journeys-${count}-20261011`','`ss-rf121-composed-window-backdrop-${mode}-20261011`')
once("'rf1117-checks-20261011/sources.json'","'rf121-backdrop-checks-20261011/sources.json'")
once(" const maintenance=checkMaintenanceAdmission(await regular(path.join(dir,'native-perf-maintenance-admission.json')),auth,owned,bound);", """ const maintenance=checkMaintenanceAdmission(await regular(path.join(dir,'native-perf-maintenance-admission.json')),auth,owned,bound);
 const identity=await regular(path.join(dir,'surface-identity.json'));
 const activation=await regular(path.join(dir,'rf121-wgc-activate-owned.json'));
 assert.equal(activation.schemaVersion,1);assert.equal(activation.scope,'rf121-owned-window-foreground');
 assert.equal(activation.pid,bound.pid);assert.equal(activation.runId,owned.runId);assert.equal(activation.creationMs,identity.creationMs);
 assert.equal(activation.tag,'activate-owned');assert.equal(activation.foregroundBefore,false);assert.equal(activation.foregroundAfter,false);
 assert.equal(activation.apiReturned,false);assert.equal(activation.requested,true);
 assert.equal(activation.heldProcessAndWindowIdentityVerifiedBeforeAndAfter,true);
 assert.equal(activation.inputEventsSent,0);assert.equal(activation.pixelsRead,0);assert.equal(activation.otherWindowsActivated,0);
 assert.equal(activation.systemSettingsChanged,false);assert.equal(activation.applicationMaterialAccepted,false);
 const ar=await regular(path.join(dir,'surface-activation.receipt.json'));assert.equal(ar.exitCode,1);
 assert.deepEqual(ar.command,[pkg.activationExe,dir,String(bound.pid),String(identity.creationMs),pkg.exe,'activate-owned']);
 assert.deepEqual(JSON.parse(await readFile(path.join(dir,'surface-activation.stdout.log'),'utf8')),activation);
 for(const absent of ['native-perf-surface-request.json','native-perf-surface-before.json','native-perf-surface-after.json','native-perf-surface-scene-request.json','native-perf-surface-appearance-request.json','rf121-wgc-light-visible.bgra','rf121-wgc-dark-visible.bgra']){
   let missing=false;try{await lstat(path.join(dir,absent));}catch(e){assert.equal(e.code,'ENOENT');missing=true;}assert(missing);
 }
""")
once("path.join(group,'validation.json')","path.join(group,'journeys-only-cleanup-validation.json')")
once("{task:'RF-1117',accepted:true,diagnosticOnly:true,performanceMetrics:null,fullRF121Accepted:false,fullRF312Accepted:false,objectCount:Number(count),samples}","{task:'RF-121',accepted:false,cleanupOnly:true,journeysOnlyAccepted:true,foregroundActivationAccepted:false,materialAccepted:false,requestedAppearanceScenesExecuted:false,pixelsRead:0,diagnosticOnly:true,performanceMetrics:null,fullRF121Accepted:false,fullRF312Accepted:false,objectCount:Number(count),samples}")
once("console.log('Three complete native/auth/maintenance journeys and strict ownership independently verified:',count);","console.log('Three actual default journeys and foreground-denial diagnostics verified for cleanup only; no requested appearance scene or material accepted:',mode);")
p=w/'verify-backdrop-foreground-denial-for-cleanup.mjs'
with p.open('x',encoding='utf8',newline='\n') as f:f.write(t)
result=subprocess.run(['node','--check',str(p)],capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
(s/'denial-reader-syntax.stdout.log').write_bytes(result.stdout);(s/'denial-reader-syntax.stderr.log').write_bytes(result.stderr)
assert result.returncode==0
print('Independent original-failure/default-journey reader prepared; no foreground/material failure changed')
