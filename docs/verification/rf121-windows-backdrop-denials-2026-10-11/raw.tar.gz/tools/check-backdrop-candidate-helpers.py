from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path('D:/SoloSoul');w=Path(__file__).parent;s=w/'helper-backdrop-reader-candidate-20261011';cache=root/'build/rf312-maintenance-20261009'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[s/'Cargo.toml',s/'Cargo.lock',s/'src/main.rs',s/'src/activate.rs',w/'helper-target-readable/debug/rf121-wgc-backdrop-candidate.exe',w/'helper-target-readable/debug/rf121-owned-foreground-candidate.exe']
frozen={str(p):sha(p) for p in paths}
env=os.environ.copy();env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),CARGO_HOME=str(cache/'cargo-home'),CARGO_TARGET_DIR=str(w/'helper-target-readable'),CARGO_BUILD_JOBS='1');env.pop('PDFIUM_LIBRARY_PATH',None)
def save(n,v):
    with (s/n).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
save('candidate-check-inputs.json',frozen)
for n,cmd in [('candidate-format',['cargo','fmt','--all','--','--check']),('candidate-clippy',['cargo','clippy','--locked','--offline','--all-targets','--','-D','warnings']),('candidate-tests',['cargo','test','--locked','--offline','--all-targets'])]:
    start=time.monotonic()
    with (s/(n+'.stdout.log')).open('xb') as out,(s/(n+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=s,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(n+'.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()));print(n,'PID',p.pid,flush=True);code=p.wait()
    same=all(sha(Path(n))==h for n,h in frozen.items())
    save(n+'.receipt.json',dict(exitCode=code,pid=p.pid,command=cmd,elapsedSeconds=time.monotonic()-start,inputsAndBinariesUnchanged=same))
    print(n,'terminal',code,flush=True);assert code==0 and same
print('Both candidate helpers existing tests/strict Clippy/format passed. No runtime activation/capture acceptance.',flush=True)
