from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
root=Path('D:/SoloSoul');w=Path(__file__).parent;old=w/'helper-d-root-readable';stage=w/'helper-backdrop-reader-candidate-20261011'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={n:sha(old/n) for n in ['Cargo.toml','Cargo.lock','src/bin/owned-window.rs']}
assert before['src/bin/owned-window.rs']=='fed4fddcbbd0bc415d3e09e97f2f2c24648487f631b86f92563794314f96e2de'
def change(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
s=(old/'src/bin/owned-window.rs').read_text(encoding='utf8')
s=change(s,'Dwm::{DwmGetWindowAttribute, DWMWA_CLOAKED, DWMWA_EXTENDED_FRAME_BOUNDS},','Dwm::{DwmGetWindowAttribute, DWMWA_CLOAKED, DWMWA_EXTENDED_FRAME_BOUNDS, DWMWA_SYSTEMBACKDROP_TYPE},')
helper='''fn read_system_backdrop(hwnd: HWND) -> Outcome<Value> {
    let mut value = 0u32;
    // HWND is held and verified by the caller; only this documented getter is used.
    let result = unsafe {
        DwmGetWindowAttribute(
            hwnd,
            DWMWA_SYSTEMBACKDROP_TYPE,
            (&mut value as *mut u32).cast(),
            std::mem::size_of::<u32>() as u32,
        )
    };
    match result {
        Ok(()) => {
            require(value <= 4, "unknown-system-backdrop-type")?;
            Ok(json!({"ok":true,"value":value,"errorHresult":null}))
        }
        Err(error) => Ok(json!({"ok":false,"value":null,"errorHresult":error.code().0})),
    }
}

'''
s=change(s,'fn nullable_frame(\n',helper+'fn nullable_frame(\n')
s=change(s,'    require(dpi_before > 0, "owned-window-dpi-required")?;','    require(dpi_before > 0, "owned-window-dpi-required")?;\n    verify_process(handle.0, &exe, birth_ms)?;\n    let backdrop_before = read_system_backdrop(hwnd)?;')
s=change(s,'    let proof = json!({"nativeAppearanceVerified":false,','    let backdrop_after = read_system_backdrop(hwnd)?;\n    require(backdrop_before == backdrop_after, "system-backdrop-changed-during-capture")?;\n    let proof = json!({"nativeAppearanceVerified":false,')
s=change(s,'"dwmAppearanceReadback":"no-documented-getters"','"dwmAppearanceReadback":"documented-system-backdrop-only"')
s=change(s,'"schemaVersion":2','"schemaVersion":3')
s=change(s,'"dwmSystemBackdropType":null','"dwmSystemBackdropType":backdrop_before["value"],"dwmSystemBackdropReadback":{"attribute":38,"before":backdrop_before,"after":backdrop_after,"stable":true}')
stage.mkdir(exist_ok=False);(stage/'src').mkdir();(stage/'src/main.rs').write_text(s,encoding='utf8',newline='\n')
manifest=(old/'Cargo.toml').read_text(encoding='utf8');manifest=manifest[:manifest.index('[[bin]]')]+'''[[bin]]
name = "rf121-wgc-backdrop-candidate"
path = "src/main.rs"
'''
(stage/'Cargo.toml').write_text(manifest,encoding='utf8',newline='\n');shutil.copyfile(old/'Cargo.lock',stage/'Cargo.lock')
def save(n,v):
    with (stage/n).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
env=os.environ.copy();desktop=root/'build/rf312-maintenance-20261009';env.update(TEMP=str(desktop/'tmp'),TMP=str(desktop/'tmp'),CARGO_HOME=str(desktop/'cargo-home'),CARGO_TARGET_DIR=str(w/'helper-target-readable'),CARGO_BUILD_JOBS='1');env.pop('PDFIUM_LIBRARY_PATH',None)
def run(n,cmd):
    start=time.monotonic()
    with (stage/(n+'.stdout.log')).open('xb') as out,(stage/(n+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=stage,env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
        save(n+'.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()));print(n,'PID',p.pid,flush=True);code=p.wait()
    assert all(sha(old/n)==h for n,h in before.items())
    save(n+'.receipt.json',dict(exitCode=code,pid=p.pid,command=cmd,elapsedSeconds=time.monotonic()-start,originalHelperUnchanged=True));assert code==0
run('format',['rustfmt','--edition','2021',str(stage/'src/main.rs')])
run('compile',['cargo','build','--locked','--offline','--bin','rf121-wgc-backdrop-candidate'])
exe=w/'helper-target-readable/debug/rf121-wgc-backdrop-candidate.exe'
save('prepared.json',dict(scope='Independent metadata-v3 candidate; compile-only preparation',metadataVersion=3,originalHelperHashes=before,originalHelperUnchanged=True,sourceSha256=sha(stage/'src/main.rs'),binarySha256=sha(exe),exe=str(exe),getterAttribute=38,beforeAndAfterGetter=True,rejectValueChanges=True,unsupportedErrorRecorded=True,darkModeAndCaptionRemainNull=True,productSourceChanged=False,nativeApplicationExecuted=False,nativeUiAccepted=False,requiresFreshApplicationBuildAndUpdatedReaders=True))
print('Independent backdrop candidate compiled; no application or window verification claimed',flush=True)
