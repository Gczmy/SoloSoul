from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
w=Path(__file__).parent;root=Path('D:/SoloSoul');stage=w/'helper-backdrop-reader-candidate-20261011';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
capture=stage/'src/main.rs';prepared=json.loads((stage/'prepared.json').read_text(encoding='utf8'));assert sha(capture)==prepared['sourceSha256']
before=capture.read_text(encoding='utf8');s=before
def once(s,a,b):
    assert s.count(a)==1,a
    return s.replace(a,b)
s=once(s,'GetWindowRect, GetWindowThreadProcessId, IsIconic, IsWindowVisible, GA_ROOTOWNER,','GetWindowRect, GetWindowThreadProcessId, IsIconic, IsWindowVisible, SetForegroundWindow, GA_ROOTOWNER,')
s=once(s,'            "light-visible",','            "activate-owned",\n            "light-visible",')
s=once(s,'    let raw_path = root.join(format!("rf121-wgc-{tag}.bgra"));','    require(tag == "activate-owned", "only-owned-foreground-activation-tag-allowed")?;\n    let raw_path = root.join(format!("rf121-wgc-{tag}.bgra"));')
branch='''    if tag == "activate-owned" {
        verify_process(handle.0, &exe, birth_ms)?;
        verify_hwnd(hwnd, pid)?;
        let before = unsafe { GetForegroundWindow() } == hwnd;
        let began = Instant::now();
        // Only the held, selected application window can receive this request.
        let api_returned = if before { None } else {
            Some(unsafe { SetForegroundWindow(hwnd) }.as_bool())
        };
        while unsafe { GetForegroundWindow() } != hwnd && began.elapsed() < Duration::from_secs(2) {
            verify_process(handle.0, &exe, birth_ms)?;
            verify_hwnd(hwnd, pid)?;
            std::thread::sleep(Duration::from_millis(10));
        }
        verify_process(handle.0, &exe, birth_ms)?;
        verify_hwnd(hwnd, pid)?;
        let after = unsafe { GetForegroundWindow() } == hwnd;
        let proof = json!({"schemaVersion":1,"scope":"rf121-owned-window-foreground","runId":run,"pid":pid,"creationMs":birth_ms,"hwnd":hwnd.0 as usize,"tag":tag,"foregroundBefore":before,"foregroundAfter":after,"requested":!before,"apiReturned":api_returned,"elapsedMilliseconds":began.elapsed().as_secs_f64()*1000.0,"heldProcessAndWindowIdentityVerifiedBeforeAndAfter":true,"pixelsRead":0,"inputEventsSent":0,"systemSettingsChanged":false,"applicationMaterialAccepted":false,"otherWindowsActivated":0});
        save_new(&json_path, &serde_json::to_vec_pretty(&proof)?)?;
        println!("{}", proof);
        require(after, "owned-window-not-foreground-after-request")?;
        return Ok(());
    }
'''
s=once(s,'    let (mut outer, mut client, mut bounds) = (RECT::default(), RECT::default(), RECT::default());',branch+'    let (mut outer, mut client, mut bounds) = (RECT::default(), RECT::default(), RECT::default());')
source=stage/'src/activate.rs';source.write_text(s,encoding='utf8',newline='\n');manifest=stage/'Cargo.toml';mf=manifest.read_bytes();(stage/'Cargo-before-foreground-bin.toml').write_bytes(mf)
with manifest.open('a',encoding='utf8',newline='\n') as f:f.write('\n[[bin]]\nname = "rf121-owned-foreground-candidate"\npath = "src/activate.rs"\n')
desktop=root/'build/rf312-maintenance-20261009';env=os.environ.copy();env.update(TEMP=str(desktop/'tmp'),TMP=str(desktop/'tmp'),CARGO_HOME=str(desktop/'cargo-home'),CARGO_TARGET_DIR=str(w/'helper-target-readable'),CARGO_BUILD_JOBS='1');env.pop('PDFIUM_LIBRARY_PATH',None)
def save(n,v):
    with (stage/n).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def run(n,cmd):
    start=time.monotonic()
    with (stage/(n+'.stdout.log')).open('xb') as out,(stage/(n+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=stage,env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
        save(n+'.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()));print(n,'PID',p.pid,flush=True);code=p.wait()
    assert sha(capture)==prepared['sourceSha256']
    save(n+'.receipt.json',dict(exitCode=code,command=cmd,pid=p.pid,elapsedSeconds=time.monotonic()-start,captureSourceUnchanged=True));assert code==0
run('foreground-format',['rustfmt','--edition','2021',str(source)])
frozen={str(p.relative_to(stage)):sha(p) for p in [source,capture,manifest,stage/'Cargo.lock']};save('foreground-compile-sources.json',frozen)
run('foreground-compile',['cargo','build','--locked','--offline','--bin','rf121-owned-foreground-candidate'])
assert all(sha(stage/n)==h for n,h in frozen.items())
exe=w/'helper-target-readable/debug/rf121-owned-foreground-candidate.exe'
assert sha(Path(prepared['exe']))==prepared['binarySha256']
save('foreground-helper-prepared.json',dict(scope='Owned foreground companion compile-only preparation',source=str(source),sourceSha256=sha(source),exe=str(exe),binarySha256=sha(exe),captureHelperSourceAndBinaryUnchanged=True,compileInputsUnchanged=True,onlyHeldPidBirthExeAndUniqueVisibleMainWindowAllowed=True,requestsOnlyOwnedForeground=True,refusesWhenOsDoesNotActivate=True,pixelsRead=0,inputEventsSent=0,applicationExecuted=False,nativeUiAccepted=False,requiresDriverActivationBeforeSurfaceRequest=True))
print('Owned foreground companion compiled; actual application activation remains pending',flush=True)
