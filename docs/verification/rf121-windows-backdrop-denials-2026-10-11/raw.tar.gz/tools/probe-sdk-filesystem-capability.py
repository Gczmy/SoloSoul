"""Compare only self-created junction/hardlink capability; no application data."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
w=Path(__file__).parent;phase=sys.argv[1];assert phase in ['sandbox','unrestricted']
s=w/('rf121-fs-capability-'+phase+'-20261011');s.mkdir(exist_ok=False)
assert s.resolve().is_relative_to(w.resolve())
for p in [s,*s.parents]:assert not (p.lstat().st_file_attributes&0x400),p
data=b'RF-121 self-created public capability bytes\n';source=s/'source.txt';source.write_bytes(data);linked=s/'linked.txt';target=s/'target';target.mkdir();junction=s/'junction'
result=dict(phase=phase,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),scope='Only newly created D-drive task files',applicationDataRead=False,pixelsRead=0,systemSettingsChanged=False,testcaseRootCauseClaimed=False)
try:
    os.link(source,linked)
    assert linked.read_bytes()==source.read_bytes()==data and linked.stat().st_ino==source.stat().st_ino
    result['hardlink']=dict(available=True,win32Error=None,sameFileIdentity=True)
except OSError as e:result['hardlink']=dict(available=False,win32Error=e.winerror,error=str(e))
cmd=['cmd.exe','/d','/c','mklink','/J',str(junction),str(target)]
p=subprocess.run(cmd,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
(s/'junction.stdout.log').write_bytes(p.stdout);(s/'junction.stderr.log').write_bytes(p.stderr)
result['junction']=dict(available=p.returncode==0,exitCode=p.returncode,command=cmd)
if p.returncode==0:
    assert junction.is_junction() and junction.resolve()==target.resolve()
    os.rmdir(junction);assert target.is_dir() and not junction.exists()
else:assert not junction.exists()
if linked.exists():assert linked.read_bytes()==data;linked.unlink()
assert source.read_bytes()==data;source.unlink();target.rmdir()
result['temporaryTestArtifactsRemoved']=True;result['scriptSha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
with (s/'result.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2)
print(json.dumps(result),flush=True)
