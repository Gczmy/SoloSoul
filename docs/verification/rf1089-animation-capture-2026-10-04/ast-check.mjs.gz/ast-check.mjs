import ts from 'file:///C:/Users/40299571/SoloSoul/tauri/node_modules/typescript/lib/typescript.js';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const before=readFileSync(new URL('./source-before.ts',import.meta.url),'utf8');
const after=readFileSync('C:/Users/40299571/SoloSoul/tauri/e2e/sidebar-tools.spec.ts','utf8');
function callback(source){
 const file=ts.createSourceFile('case.ts',source,ts.ScriptTarget.Latest,true);let found;
 function visit(node){
  if(ts.isFunctionDeclaration(node)&&node.name?.text==='sampleMenuSweep') {
   function inner(value){
    if(ts.isCallExpression(value)&&ts.isPropertyAccessExpression(value.expression)&&value.expression.name.text==='evaluate'){
     const a=value.arguments[0];if(ts.isArrowFunction(a)&&a.modifiers?.some(m=>m.kind===ts.SyntaxKind.AsyncKeyword))found=a;
    }
    ts.forEachChild(value,inner);
   }
   inner(node);
  }
  ts.forEachChild(node,visit);
 }
 visit(file);if(!found)throw Error('Original real sampler not found');
 function encode(node){let children=[];ts.forEachChild(node,c=>{children.push(encode(c));});return {kind:node.kind,text:ts.isIdentifier(node)||ts.isLiteralExpression(node)?node.text:undefined,children};}
 return JSON.stringify(encode(found));
}
const a=callback(before),b=callback(after);if(a!==b)throw Error('Real sampler AST changed');
const result={equal:true,method:'Original sampleMenuSweep async evaluate callback AST; only transition capture and readiness added outside',sha256:createHash('sha256').update(a).digest('hex')};
writeFileSync(new URL('./sampler-ast-check.json',import.meta.url),JSON.stringify(result,null,2)+'\n');process.stdout.write(JSON.stringify(result)+'\n');
