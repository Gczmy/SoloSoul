import pathlib,subprocess,json,os,time,sys
R=pathlib.Path(r'C:\Users\40299571\SoloSoul');T=pathlib.Path(__file__).parent;mode=sys.argv[1]
N=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf1088-related-target-20261004\node22\node-v22.23.3-win-x64');env=dict(os.environ);env['PATH']=str(N)+os.pathsep+env['PATH'];env['CI']='1';env['SOLOSOUL_E2E_CHANNEL']='msedge';env['TAURI_DEV_HOST']='localhost';env['TAURI_DEV_HMR_PORT']='20112'
base=[str(N/'node.exe'),'node_modules/@playwright/test/cli.js','test','e2e/sidebar-tools.spec.ts','--project=chromium','--project=mobile','--config',str(T/'playwright.config.mjs')]
if mode in ['negative','positive']:commands=[('web-'+mode,base+['--grep','macos 展开侧栏工具沿底边','--retries=0'])]
elif mode=='web':commands=[('web-full',base)]
else:raise SystemExit('Unknown mode')
checks=[]
for name,args in commands:
 start=time.monotonic()
 with (T/(name+'.log')).open('wb') as out:p=subprocess.Popen(args,cwd=R/'tauri',env=env,stdout=out,stderr=subprocess.STDOUT);rc=p.wait()
 checks.append({'name':name,'args':args,'exit':rc,'seconds':time.monotonic()-start,'owned_pid':p.pid});(T/(mode+'-checks.json')).write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8');print(name,rc,round(time.monotonic()-start,2),flush=True)
 if rc:sys.exit(rc)
