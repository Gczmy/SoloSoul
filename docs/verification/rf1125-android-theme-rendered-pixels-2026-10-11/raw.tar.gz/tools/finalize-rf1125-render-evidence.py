from pathlib import Path
import datetime, hashlib, importlib.util, io, json, tarfile

r = Path('D:/SoloSoul')
b = Path(__file__).parent.resolve()
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))

def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def save(p, value):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

proof = load(b/'rf1125-theme-render-test-build-20261011/source-and-checks-proof.json')
art = load(b/'rf1125-theme-render-test-build-20261011/current-apks.json')
assert proof['themeAcceptanceBodyAnd45SecondBudgetUnchanged']
assert proof['originalLightDarkLightCommandsUnchanged'] and proof['productionSourcesUnchanged']
assert proof['unit'] == dict(tests=10, failures=0, errors=0, skipped=0)
assert len(art['sourceFiles']) == 1837
assert all(sha(r/n) == h for n,h in art['sourceFiles'].items())
assert all(sha(Path(v['copy'])) == v['sha256'] for v in art['files'])
spec = importlib.util.spec_from_file_location('home', r/'tauri/scripts/android-home-native-regression.py')
home = importlib.util.module_from_spec(spec)
spec.loader.exec_module(home)
observations, targets, pairs = [], [], []

def add(p):
    assert p.is_file() and p.resolve().is_relative_to(b)
    q = p
    while q != r.parent:
        assert not q.is_symlink() and not (q.lstat().st_file_attributes & 0x400), q
        q = q.parent
    targets.append(dict(path=str(p.resolve()), bytes=p.stat().st_size, sha256=sha(p)))

for api in [31,35]:
    c = b/f'api{api}-theme-rf1125-20261011'
    v = load(c/'verification.json')
    pixels = load(c/'pixel-verification.json')
    stop = load(b/f'api{api}-host-rf1125-20261011/stop.receipt.json')
    visual = load(c/'visual-review.json')
    assert v['diagnosticComplete'] and len(v['results']) == 2
    assert pixels['verifiedFrames'] == (2 if api == 31 else 6)
    assert pixels['adversarialRejected'] == 6
    assert pixels['accepted'] is (api == 35)
    assert stop['settingsRestored'] and stop['ownedProcessExited'] and stop['dedicatedPortsFree'] and stop['noForceTermination']
    assert visual['actualImagesInspected'] == (2 if api == 31 else 6)
    for image in visual['images']:
        assert sha(Path(image['path'])) == image['sha256']
    for row in v['results']:
        assert row['restored'] and row['externalRestored'] and row['settingsRestored'] and row['sourcesAndApksUnchanged']
        assert row['nativePassed'] is (api == 35)
        d = c/row['mode']
        raw = load(d/'theme-diagnostics.json')
        assert raw['runId'] == row['runId']
        if api == 35:
            home.verify_native((d/'instrumentation.stdout.log').read_text(encoding='utf-8-sig'), 'systemThemeFollowsLightDarkLight')
        else:
            assert raw['records'][1]['result'] == 'timeout' and not raw['records'][1]['darkMedia']
        before, after = d/'private-data-before.tar', d/'private-data-restored.tar'
        inventory = home.inventory(before, require_empty=True)
        assert inventory == home.inventory(after, require_empty=True)
        pairs.append(dict(directory=str(d), entries=len(inventory), contentsLinksAndModesMatched=True))
        add(before); add(after)
        for name,digest in load(d/'external-before.json').items():
            assert name in ['rf201-system.json','rf201-system-light.png','rf201-system-dark.png','rf201-system-light-again.png']
            p = d/'external-before'/name
            assert sha(p) == digest
            add(p)
        observations.append(dict(api=api, mode=row['mode'], nativePassed=row['nativePassed'], runId=row['runId'], records=raw['records']))

stem = 'rf1125-android-theme-rendered-pixels-2026-10-11'
dst = r/'docs/verification'/stem
dst.mkdir(exist_ok=False)
(dst/'.gitattributes').write_text('* -text -diff\n', encoding='ascii', newline='\n')
entries = {}
for name in ['rf1125-theme-render-test-build-20261011', 'api31-host-rf1125-20261011', 'api35-host-rf1125-20261011', 'api31-theme-rf1125-20261011', 'api35-theme-rf1125-20261011']:
    for p in (b/name).rglob('*'):
        if not p.is_file() or 'external-before' in p.relative_to(b/name).parts or p.suffix in ('.apk','.tar'):
            continue
        assert not p.is_symlink() and not (p.lstat().st_file_attributes & 0x400)
        entries['raw/'+p.relative_to(b).as_posix()] = p
for name in ['prepare-rf1125-current.py', 'build-rf1125-theme-render-test.py', 'boot-rf1125-api31-host.py', 'boot-rf1125-api35-host.py', 'continue-rf1125-api31-boot.py', 'run-rf1125-theme-render-api31-continued.py', 'stop-rf1125-api31-continued.py', 'prepare-rf1125-driver.py', 'run-rf1125-theme-render.py', 'stop-rf1125-owned-emulator.py', 'verify-rf1125-rendered-pixels.py', 'finalize-rf1125-render-evidence.py']:
    entries['tools/'+name] = b/name
path = 'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt'
entries['tools/cleanup-rf1125-owned.ps1'] = b/'cleanup-rf1125-owned.ps1'
entries['tools/verify-rf1125-git.py'] = b/'verify-rf1125-git.py'
entries['raw/rf1125-source-preflight-failure-and-recovery.json'] = b/'rf1125-source-preflight-failure-and-recovery.json'
entries['raw/rf1125-cargo-before-line-ending-recovery.toml'] = b/'rf1125-cargo-before-line-ending-recovery.toml'
entries['final-source/'+path] = r/path
entries['references/android-home-native-regression.py'] = r/'tauri/scripts/android-home-native-regression.py'
entries['references/rf1124-diagnostics.json'] = r/'docs/verification/rf1124-android-theme-diagnostics-2026-10-11.json'
for p in (b/'rf1124-theme-diagnostic-test-build-20261011/unit-test-xml').glob('*.xml'):
    entries['references/reused-unit-xml/'+p.name] = p
members = []
archive = dst/'raw.tar.gz'
with archive.open('xb') as out, tarfile.open(fileobj=out, mode='w:gz') as tf:
    for name,p in sorted(entries.items()):
        data = p.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        tf.addfile(info,io.BytesIO(data))
        members.append(dict(path=name, size=len(data), sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(archive, 'r:gz') as tf:
    assert len(tf.getmembers()) == len(members) and set(tf.getnames()) == set(entries)
    for row in members:
        m = tf.getmember(row['path'])
        assert m.isfile() and not m.issym() and not m.islnk()
        data = tf.extractfile(m).read()
        assert len(data) == row['size'] and hashlib.sha256(data).hexdigest() == row['sha256']
save(dst/'index.json', dict(archiveSha256=sha(archive), members=members, allMembersReread=True, excluded=['APKs','JNI','private TARs','previous external contents']))
save(r/'docs/verification'/f'{stem}.json', dict(task='RF-1125', base=proof['base'], status='render-capture-verification-complete', checks=proof, artifacts=art['files'], observations=observations, sourcePath=path, finalSourceSha256=sha(r/path), nativeThemeTests=dict(api35Passed=2, api35Failed=0, api31Passed=0, api31Failed=2, skipped=0), verifiedFrames=8, verifiedPixels=16, adversarialRejectedPerApi=6, productionThemeFixed=False, fullRF121Accepted=False, fullRF312Accepted=False, physicalDeviceAccepted=False, performanceAccepted=False, scope='Actual bootstrap opaque card pixels only; legacy dark media failure retained', originalFailuresRetained=True, priorStartupNativeSourceClaimWithdrawn=True, archive=dict(path=archive.relative_to(r).as_posix(), sha256=sha(archive), members=len(members)), ledgerClosed=False, commitCreated=False, at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
assert len(targets) == len({x['path'] for x in targets}) == 24
save(b/'rf1125-owned-cleanup-plan.json', dict(task='RF-1125', root=str(b), targets=targets, privatePairs=pairs, archiveSha256=sha(archive), privateFilesRestored=True, emulatorsExited=True))
print(json.dumps(dict(archiveMembers=len(members), sha256=sha(archive), temporaryFiles=len(targets), verifiedFrames=8, verifiedPixels=16)))
