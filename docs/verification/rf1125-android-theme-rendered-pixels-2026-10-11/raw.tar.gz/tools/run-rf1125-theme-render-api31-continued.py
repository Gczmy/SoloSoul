"""Run the original one-method theme contract; diagnostics never turn failures green."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, re, subprocess, sys, time, uuid
r = Path('D:/SoloSoul'); b = Path(__file__).parent.resolve()
api = int(sys.argv[1]); assert api in (31, 35)
stage = b / f'api{api}-theme-rf1125-20261011'; stage.mkdir(exist_ok=False)
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, v):
    with p.open('x', encoding='utf-8', newline='\n') as f: json.dump(v, f, indent=2)
spec = importlib.util.spec_from_file_location('native_home', r/'tauri/scripts/android-home-native-regression.py')
home = importlib.util.module_from_spec(spec); spec.loader.exec_module(home)
artifacts = load(b/'rf1125-theme-render-test-build-20261011/current-apks.json')
assert artifacts['accepted'] and not artifacts['deviceAcceptance'] and len(artifacts['sourceFiles']) == 1837
files = {v['kind']: v for v in artifacts['files']}
def verify_sources():
    for name, digest in artifacts['sourceFiles'].items(): assert sha(r/name) == digest, name
    for row in files.values(): assert sha(Path(row['copy'])) == row['sha256']
verify_sources()
boot_dir = b/f'api{api}-host-rf1125-20261011'
boot = load(boot_dir/'boot-continued.receipt.json'); assert boot['booted'] and boot['avdConfigUnchanged']
owned = [x for x in load(boot_dir/'owned-processes-after-launch.json') if x['ProcessId'] == boot['pid']]
assert len(owned) == 1
pwsh = 'C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
def identity():
    command = f"Get-CimInstance Win32_Process -Filter 'ProcessId = {boot['pid']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3"
    p = subprocess.run([pwsh, '-NoProfile', '-Command', command], check=True, capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW)
    live = json.loads(p.stdout)
    for key in ['Name','ProcessId','ExecutablePath','CommandLine']: assert live[key] == owned[0][key], key
    assert datetime.datetime.fromisoformat(live['CreationDate']) == datetime.datetime.fromisoformat(owned[0]['CreationDate'])
    return live
save(stage/'owned-identity.json', identity())
env = os.environ.copy(); env.update({'ANDROID_ADB_SERVER_PORT':'5049', 'ADB_SERVER_SOCKET':'tcp:localhost:5049', 'TEMP':str(b/'tmp'), 'TMP':str(b/'tmp')})
adb = str(b/'sdk/platform-tools/adb.exe'); serial = 'emulator-5586'
avd = 'SoloSoul_RF121_API31_20261010' if api == 31 else 'SoloSoul_RF121_20261010'
APP = 'com.solosoul.app'; external = f'/sdcard/Android/data/{APP}/files'
def call(args, check=True, **kwargs):
    p = subprocess.run([adb,'-H','localhost','-P','5049','-s',serial,*args], env=env, timeout=180,
        creationflags=subprocess.CREATE_NO_WINDOW, **kwargs)
    if check and p.returncode != 0: raise RuntimeError(f'adb {args[0]} exit {p.returncode}')
    return p
def read(args): return call(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout.decode().strip()
def device():
    assert read(['get-state']) == 'device' and read(['shell','getprop','sys.boot_completed']) == '1'
    assert read(['emu','avd','name']).splitlines()[0] == avd
    assert read(['shell','getprop','ro.build.version.sdk']) == str(api)
    assert read(['shell','getprop','ro.product.cpu.abi']) == 'x86_64'
def settings(): return {'night':read(['shell','cmd','uimode','night']), 'blur':read(['shell','settings','get','global','disable_window_blurs'])}
device()
save(stage/'input-proof.json', {'api':api, 'serial':serial, 'avd':avd, 'sources':artifacts['sourceFiles'], 'files':artifacts['files'],
    'instrumentationSourceSha256':sha(r/'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt'),
    'driverDependencySha256':sha(r/'tauri/scripts/android-home-native-regression.py'), 'mainApkRebuilt':False,
    'method':'systemThemeFollowsLightDarkLight', 'budgetSeconds':45, 'newRenderBudgetSeconds':10, 'pixelTolerance':6, 'partialDiagnosticsAreNotNativePass':True, 'fullRF121Accepted':False})
results = []
for mode in ['supported','fallback']:
    verify_sources(); identity(); device()
    c = stage/mode; c.mkdir(exist_ok=False)
    before_settings = settings(); old_night = home.night_mode(before_settings['night'])
    run = uuid.uuid4().hex; row = {'mode':mode, 'runId':run, 'nativePassed':False, 'restored':False, 'settingsBefore':before_settings}
    call(['shell','am','force-stop',APP], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    root_mode = read(['shell','run-as',APP,'stat','-c','%a','.']); assert re.fullmatch('[0-7]{3,4}', root_mode)
    backup = c/'private-data-before.tar'
    def archive(path):
        with path.open('xb') as f:
            os.chmod(path,0o600); call(['exec-out','run-as',APP,'tar','-cf','-','.'],stdout=f,stderr=subprocess.PIPE)
    archive(backup); before = home.inventory(backup, require_empty=True)
    row['privateBeforeEntries'] = len(before); row['privateBeforeSha256'] = sha(backup)
    previous_external = {}
    for name in ['rf201-system.json','rf201-system-light.png','rf201-system-dark.png','rf201-system-light-again.png']:
        p = call(['exec-out','cat',external+'/'+name], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if p.returncode == 0:
            previous_external[name] = p.stdout
            target = c/'external-before'/name; target.parent.mkdir(exist_ok=True); target.write_bytes(p.stdout)
        else: assert b'No such file or directory' in p.stderr, p.stderr
    save(c/'external-before.json', {name:hashlib.sha256(data).hexdigest() for name,data in previous_external.items()})
    try:
        call(['shell','settings','put','global','disable_window_blurs','1' if mode == 'fallback' else '0'],stdout=subprocess.PIPE)
        for kind in ['main','test']: call(['install','-r',files[kind]['copy']],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (c/'provider-before.log').write_text(read(['shell','dumpsys','webviewupdate']),encoding='utf-8')
        command = ['shell','am','instrument','-w','-r','-e','waitForActivitiesToComplete','false','-e','glassMode',mode,
            '-e','themeDiagnosticRun',run,'-e','class','com.solosoul.app.AndroidThemeInstrumentedTest#systemThemeFollowsLightDarkLight',
            'com.solosoul.app.test/androidx.test.runner.AndroidJUnitRunner']
        save(c/'command.json', command); print(f'API{api} {mode} original theme test run {run}',flush=True)
        began = time.monotonic(); p = call(command,check=False,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (c/'instrumentation.stdout.log').write_bytes(p.stdout); (c/'instrumentation.stderr.log').write_bytes(p.stderr)
        row.update({'adbExitCode':p.returncode,'elapsedSeconds':time.monotonic()-began})
        try:
            assert p.returncode == 0; home.verify_native(p.stdout.decode(errors='replace'),'systemThemeFollowsLightDarkLight'); row['nativePassed'] = True
        except Exception as error: row['nativeFailure'] = str(error)
        p = call(['exec-out','cat',external+f'/rf1124-{run}.json'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        (c/'theme-diagnostics.json').write_bytes(p.stdout)
        observed = json.loads(p.stdout); assert observed['schema'] == 1 and observed['runId'] == run and observed['preset'] == 'system'
        assert 1 <= len(observed['records']) <= 3 # Partial failed draw diagnostics never count as native acceptance
        for record in observed['records']:
            assert record['native']['api'] == api and record['native']['providerPackage'] and record['native']['providerVersion']
        row['diagnosticCollected'] = True
        for record in observed['records']:
            if record.get('result') == 'timeout': continue
            label = record['stage']; assert label in ['system-light','system-dark','system-light-again']
            if 'captureAtNs' not in record.get('renderCapture', {}):
                assert not row['nativePassed']; row.setdefault('failedBeforeImage', []).append(label); continue
            p = call(['exec-out','cat',external+f'/rf201-{label}-{run}.png'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            assert p.stdout.startswith(b'\x89PNG\r\n\x1a\n'); (c/f'{label}.png').write_bytes(p.stdout)
        if not row['nativePassed']:
            (c/'failure.png').write_bytes(call(['exec-out','screencap','-p'],stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout)
    except Exception as error: row['error'] = str(error)
    finally:
        try:
            identity(); device(); call(['shell','am','force-stop',APP],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            names = read(['shell','run-as',APP,'ls','-A']).splitlines()
            assert all(re.fullmatch('[A-Za-z0-9_.-]+',name) and name not in ('.','..') for name in names)
            if names: call(['shell','run-as',APP,'rm','-rf','--',*names],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            remote = f'/data/local/tmp/rf1124-{run}-private-backup.tar'
            call(['push',str(backup),remote],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            call(['shell','chmod','644',remote],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            call(['shell','run-as',APP,'tar','-xpf',remote],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            call(['shell','run-as',APP,'chmod',root_mode,'.'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            restored = c/'private-data-restored.tar'; archive(restored)
            assert before == home.inventory(restored,require_empty=True)
            assert read(['shell','run-as',APP,'stat','-c','%a','.']) == root_mode
            call(['shell','rm',remote],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            row['restored'] = True
            for name in ['rf201-system.json','rf201-system-light.png','rf201-system-dark.png','rf201-system-light-again.png']:
                p = call(['exec-out','cat',external+'/'+name],check=False,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                assert (p.returncode == 0 and p.stdout == previous_external[name]) if name in previous_external else (p.returncode != 0 and b'No such file or directory' in p.stderr)
            call(['shell','rm','-f',external+f'/rf1124-{run}.json'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            for label in ['system-light','system-dark','system-light-again']:
                call(['shell','rm','-f',external+f'/rf201-{label}-{run}.png'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            row['externalRestored'] = True
        except Exception as error: row['restoreError'] = str(error)
        try:
            call(['shell','cmd','uimode','night',old_night],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            blur = before_settings['blur']; call(['shell','settings', 'delete' if blur=='null' else 'put','global','disable_window_blurs',*([] if blur=='null' else [blur])],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            row['settingsAfter'] = settings(); row['settingsRestored'] = row['settingsAfter'] == before_settings
            assert row['settingsRestored']
        except Exception as error: row['settingsRestoreError'] = str(error)
        verify_sources(); row['sourcesAndApksUnchanged'] = True
        row['diagnosticEligible'] = bool(row.get('diagnosticCollected') and row['restored'] and row.get('externalRestored') and row.get('settingsRestored') and not any(row.get(k) for k in ['error','restoreError','settingsRestoreError']))
        save(c/'receipt.json',row); results.append(row); print(f'API{api} {mode} native={row["nativePassed"]}; diagnostic={row["diagnosticEligible"]}; restored={row["restored"]}',flush=True)
    if not row['diagnosticEligible']: break
complete = len(results)==2 and all(row['diagnosticEligible'] for row in results)
save(stage/'verification.json',{'api':api,'results':results,'diagnosticComplete':complete,'nativePassed':complete and all(row['nativePassed'] for row in results),
    'fullRF121Accepted':False,'privateArchivesExcludedFromPublicEvidence':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
raise SystemExit(0 if complete else 1)
