from pathlib import Path
import datetime,json,os,socket,subprocess,sys,time
b=Path(__file__).parent.resolve(); api=int(sys.argv[1]); assert api in (31,35)
s=b/f'api{api}-host-rf1125-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
v=load(b/f'api{api}-theme-rf1125-20261011/verification.json')
assert v['diagnosticComplete'] and len(v['results'])==2 and all(row['restored'] and row['settingsRestored'] and row['externalRestored'] for row in v['results'])
boot=load(s/'boot-continued.receipt.json'); owned=[x for x in load(s/'owned-processes-after-launch.json') if x['ProcessId']==boot['pid']]; assert len(owned)==1; owned=owned[0]
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
def identity():
    p=subprocess.run([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {owned['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3"],check=True,capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    return json.loads(p.stdout) if p.stdout.strip() else None
live=identity(); assert live
for key in ['Name','ProcessId','ExecutablePath','CommandLine']: assert live[key]==owned[key],key
assert datetime.datetime.fromisoformat(live['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
env=os.environ.copy(); env.update({'ANDROID_ADB_SERVER_PORT':'5049','ADB_SERVER_SOCKET':'tcp:localhost:5049','TEMP':str(b/'tmp'),'TMP':str(b/'tmp')})
def read(args):
    p=subprocess.run([str(b/'sdk/platform-tools/adb.exe'),'-H','localhost','-P','5049','-s','emulator-5586',*args],env=env,check=True,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW); return p.stdout.strip()
avd='SoloSoul_RF121_API31_20261010' if api==31 else 'SoloSoul_RF121_20261010'
assert read(['emu','avd','name']).splitlines()[0]==avd
settings={'blur':read(['shell','settings','get','global','disable_window_blurs']),'night':read(['shell','cmd','uimode','night'])}
assert settings==boot['settingsBeforeTests']
result={'api':api,'identity':live,'settingsRestored':True,'settings':settings,'noForceTermination':True,'stopResponse':read(['emu','kill'])}
deadline=time.monotonic()+40
while identity() is not None:
    assert time.monotonic()<deadline; time.sleep(1)
for port in [5586,5587]:
    with socket.socket() as sock: sock.bind(('127.0.0.1',port))
result.update({'ownedProcessExited':True,'dedicatedPortsFree':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
with (s/'stop.receipt.json').open('x',encoding='utf-8') as f: json.dump(result,f,indent=2)
print(f'API{api} original settings confirmed; exact owned emulator gracefully exited',flush=True)
