from pathlib import Path
import datetime,json,os,subprocess,time
b=Path(__file__).parent.resolve();s=b/'api31-host-rf1125-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
first=load(s/'boot.receipt.json');assert first['booted'] is False and first['avdConfigUnchanged']
owned=[v for v in load(s/'owned-processes-after-launch.json') if v['ProcessId']==first['pid']];assert len(owned)==1;owned=owned[0]
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
p=subprocess.run([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {first['pid']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json"],capture_output=True,text=True,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
live=json.loads(p.stdout)
assert all(live[k]==owned[k] for k in ['Name','ProcessId','ExecutablePath','CommandLine'])
assert datetime.datetime.fromisoformat(live['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
env=os.environ.copy();env.update(ADB_SERVER_SOCKET='tcp:localhost:5049',TEMP=str(b/'tmp'),TMP=str(b/'tmp'))
def read(args):
 p=subprocess.run([str(b/'sdk/platform-tools/adb.exe'),'-H','localhost','-P','5049','-s','emulator-5586',*args],env=env,capture_output=True,text=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
 return p.returncode,p.stdout.strip()
attempts=[];start=time.monotonic();booted=False
while time.monotonic()-start<480:
 code,value=read(['shell','getprop','sys.boot_completed']);attempts.append(dict(exitCode=code,value=value,elapsed=time.monotonic()-start))
 if code==0 and value=='1':booted=True;break
 time.sleep(3)
result=dict(first,booted=booted,continuationAttempts=attempts,originalBootTimeoutRetained=True,originalThemeBudgetUnchanged=True,ownedProcessIdentity=live,at=datetime.datetime.now(datetime.timezone.utc).isoformat())
if booted:
 assert read(['emu','avd','name'])[1].splitlines()[0]=='SoloSoul_RF121_API31_20261010'
 assert read(['shell','getprop','ro.build.version.sdk'])==(0,'31')
 assert read(['shell','getprop','ro.product.cpu.abi'])==(0,'x86_64')
 result['settingsBeforeTests']=dict(blur=read(['shell','settings','get','global','disable_window_blurs'])[1],night=read(['shell','cmd','uimode','night'])[1])
 for label,args in [('surfaceflinger',['shell','dumpsys','SurfaceFlinger']),('webview',['shell','dumpsys','webviewupdate'])]:
  code,value=read(args);assert code==0;(s/(label+'.log')).write_text(value,encoding='utf-8')
with (s/'boot-continued.receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
print('Same owned API31 boot continuation terminal: '+str(booted),flush=True)
raise SystemExit(0 if booted else 1)
