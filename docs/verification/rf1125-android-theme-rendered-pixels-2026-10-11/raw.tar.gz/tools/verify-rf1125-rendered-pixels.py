"""Independently read actual encoded PNG pixels; partial/failed native runs cannot pass."""
from pathlib import Path
import copy,hashlib,importlib.util,json,math,re,sys
from PIL import Image,__version__ as pillow_version
r=Path('D:/SoloSoul');b=Path(__file__).parent.resolve()
spec=importlib.util.spec_from_file_location('home',r/'tauri/scripts/android-home-native-regression.py');home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def verify_record(record,image):
    f=record['renderCapture'];assert f['visualCallback'] is True and f['nextDrawCompleted'] is True and f['pixelMatched'] is True
    assert type(f['requestId']) is int and f['callbackRequestId']==f['requestId']
    assert f['requestId']<=f['callbackAtNs']<=f['drawAtNs']<=f['captureAtNs']
    fresh=f['stateAtCapture'];a=record['native'];n=fresh['native'];render=fresh['render']
    assert a['webViewIdentity']==n['webViewIdentity']==f['webViewIdentity'] and a['processId']==n['processId'] and a['processId']>0
    for key in ['attached','shown','windowFocused','hardwareAccelerated']:assert a[key] is n[key] is True,key
    for key in ['platform','theme','background','surface','foreground','accent','materialInk','darkMedia','statusBarLight','navigationBarLight','mounted','startupGone']:
        assert record[key]==fresh[key],key
    assert fresh['mounted'] is fresh['startupGone'] is True and render['path']=='/bootstrap' and render['cardFound'] is True
    assert render['viewportScale']==1 and render['viewportOffsetX']==render['viewportOffsetY']==0
    assert re.fullmatch('#[0-9a-f]{6}',record['surface'])
    expected=[int(record['surface'][i:i+2],16) for i in (1,3,5)]
    match=re.fullmatch(r'rgb\((\d+),\s*(\d+),\s*(\d+)\)',render['cardBackground']);assert match
    assert [int(match[i]) for i in (1,2,3)]==expected
    ratio=f['cssToPixelRatio'];assert type(ratio) in (int,float) and math.isfinite(ratio) and 0<ratio<=8
    assert abs(f['webViewWidth']-render['viewportWidth']*ratio)<0.001 and f['webViewHeight']>0
    assert len(render['points'])==len(f['pixels'])==2 and render['points'][0]['x']!=render['points'][1]['x']
    with Image.open(image) as png:
        assert png.format=='PNG' and png.size==(f['imageWidth'],f['imageHeight'])
        rgba=png.convert('RGBA');summary=[]
        for point,pixel in zip(render['points'],f['pixels']):
            assert point['hitsCard'] is True and point['x']>=0 and point['y']>=0
            x=f['screenX']+int(point['x']*ratio);y=f['screenY']+int(point['y']*ratio)
            assert 0<=x<png.width and 0<=y<png.height and (x,y)==(pixel['x'],pixel['y'])
            actual=rgba.getpixel((x,y));assert actual[3]==255
            assert list(actual[:3])==pixel['actualRgb'] and pixel['expectedRgb']==expected and pixel['matched'] is True
            assert all(abs(a-e)<=6 for a,e in zip(actual[:3],expected))
            summary.append(dict(x=x,y=y,actualRgb=list(actual[:3]),expectedRgb=expected))
        return dict(stage=record['stage'],processId=n['processId'],webViewIdentity=n['webViewIdentity'],
            provider=n['providerVersion'],pixels=summary,imageSha256=hashlib.sha256(image.read_bytes()).hexdigest())
def verify(api):
    c=b/f'api{api}-theme-rf1125-20261011';v=load(c/'verification.json')
    assert v['diagnosticComplete'] and len(v['results'])==2
    groups=[];first=None;first_image=None
    for row in v['results']:
        assert row['restored'] and row['externalRestored'] and row['settingsRestored'] and row['sourcesAndApksUnchanged']
        directory=c/row['mode'];data=load(directory/'theme-diagnostics.json')
        assert data['schema']==1 and data['runId']==row['runId'] and data['preset']=='system'
        records=data['records'];assert [x['stage'] for x in records]==(['system-light','system-dark','system-light-again'] if api==35 else ['system-light','system-dark'])
        if api==35:
            assert row['nativePassed'];home.verify_native((directory/'instrumentation.stdout.log').read_text(encoding='utf-8-sig'),'systemThemeFollowsLightDarkLight')
        else:
            assert not row['nativePassed'] and records[1]['result']=='timeout' and not records[1]['darkMedia'] and records[1]['theme']=='light'
            assert records[1]['native']['nightMode']==2 and records[1]['native']['activityNight']==32 and records[1]['native']['androidLightTheme'] is False
        samples=[]
        for index,record in enumerate(records):
            if record.get('result')=='timeout':continue
            dark=(index==1);assert record['native']['api']==api and record['theme']==('dark' if dark else 'light') and record['darkMedia'] is dark
            assert record['surface']==('#2a2620' if dark else '#fdfcf9')
            image=directory/(record['stage']+'.png');samples.append(verify_record(record,image))
            if first is None:first=record;first_image=image
        groups.append(dict(mode=row['mode'],nativePassed=row['nativePassed'],samples=samples))
    # These adversarial cases exercise actual event/pixel/identity guards against a real accepted frame.
    mutations=[lambda x:x['renderCapture'].__setitem__('callbackRequestId',0),
        lambda x:x['renderCapture'].__setitem__('nextDrawCompleted',False),
        lambda x:x['renderCapture']['stateAtCapture']['native'].__setitem__('webViewIdentity',0),
        lambda x:x['renderCapture']['pixels'][0].__setitem__('actualRgb',[0,0,0]),
        lambda x:x['renderCapture']['stateAtCapture']['render']['points'][0].__setitem__('x',1e6),
        lambda x:x.__setitem__('surface','#000000')]
    for mutate in mutations:
        changed=copy.deepcopy(first);mutate(changed)
        try:verify_record(changed,first_image)
        except (AssertionError,KeyError,ValueError):pass
        else:raise AssertionError('Adversarial frame incorrectly accepted')
    result=dict(api=api,accepted=api==35,diagnosticOnly=api==31,groups=groups,
        verifiedFrames=sum(len(x['samples']) for x in groups),adversarialRejected=len(mutations),
        pillowVersion=pillow_version,productionThemeFixed=False,fullRF121Accepted=False,fullRF312Accepted=False)
    with (c/'pixel-verification.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
    print(json.dumps(dict(api=api,accepted=result['accepted'],diagnosticOnly=result['diagnosticOnly'],verifiedFrames=result['verifiedFrames'],adversarialRejected=len(mutations))))
if __name__=='__main__':verify(int(sys.argv[1]))
