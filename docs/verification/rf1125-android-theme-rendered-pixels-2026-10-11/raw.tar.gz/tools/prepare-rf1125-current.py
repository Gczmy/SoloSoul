from pathlib import Path
import ast,hashlib,json
r=Path('D:/SoloSoul');b=Path(__file__).parent.resolve()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
art=load(b/'rf1124-theme-diagnostic-test-build-retry1-20261011/current-apks.json')
test='tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt'
assert len(art['sourceFiles'])==1837
changed=[name for name,digest in art['sourceFiles'].items() if hashlib.sha256((r/name).read_bytes()).hexdigest()!=digest]
assert changed==[test],changed
p=r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=p.read_text(encoding='utf-8-sig');assert 'RF-1125' not in s
s=s.replace('304 / 314','304 / 315').replace('进行中：0；待执行：6。','进行中：1；待执行：6。')
s=s.replace('RF-1124（RF-904','RF-1124、RF-1125（RF-904')
s=s.replace('- 当前处理：RF-121 Android绘制/截图同步核查与旧WebView主题传递修复准备；RF-1124诊断独立完成，完整平台前置保持未完成。',
    '- 当前处理：RF-1125 Android主题截图绑定实际绘制与卡片像素；RF-1124提交e6c55233b，完整平台前置保持未完成。')
old='| 314 | [RF-1124](#rf-1124) | P2 | Android系统主题失败记录原生配置及WebView状态 | 无（API31主题切换失败缺少分层证据） | [x] 完成 |'
assert s.count(old)==1;s=s.replace(old,old+'\n| 315 | [RF-1125](#rf-1125) | P2 | Android主题截图绑定真实WebView绘制与卡片像素 | [RF-1124](#rf-1124) | [~] 进行中 |')
card='''### RF-1125

**Android主题截图绑定真实WebView绘制与卡片像素** · P2 · 来源：RF-1124状态读回与截图不一致

- **入口：**AndroidThemeInstrumentedTest，仅androidTest；前置RF-1124已提交。
- **现状：**原截图只等待UIAutomation空闲，API35状态dark但截图仍浅色，首次画面有启动标志；来源尚未唯一确立，不称产品主题已修复。
- **执行：**同一附着/可见/焦点WebView实际visual callback和其后onDraw完成后捕获；重新读取真实主题、CSS卡片背景/点几何及进程/视图身份，映射到原生截图并按现有不透明卡片像素容差6核对两个无遮挡内点。失败保留状态和PNG，不修改媒体查询、主题或生产资源。
- **验收：**原45秒主题预算、原色板/媒体/系统栏及切换命令不变；Kotlin编译/既有单元、最终APK与1837源SHA；专用API35双模式真实状态+像素，API31复核首次截图和原媒体失败；完整私有与设置恢复、原件归档、独立本地提交，不推送。截图通过仅覆盖实际bootstrap不透明卡片，不代替完整材质/平台矩阵。

'''
s=s.replace('## 7. 每项执行记录模板',card+'## 7. 每项执行记录模板');p.write_text(s,encoding='utf-8',newline='\n')
s=(b/'build-rf1124-theme-diagnostic-test-retry1.py').read_text(encoding='utf-8-sig')
s=s.replace("original = load(base / 'current-apks-rf1121-20261011/current-apks.json')","original = load(base / 'rf1124-theme-diagnostic-test-build-retry1-20261011/current-apks.json')")
s=s.replace("sources = load(root / 'build/rf121-theme-binding-20261010/rf1123-checks-retry2-20261011/sources.json').copy()","sources = original['sourceFiles'].copy()")
s=s.replace('rf1124-theme-diagnostic-test-build-retry1-20261011\'\n','rf1125-theme-render-test-build-20261011\'\n')
s=s.replace("sha(base / 'current-apks-rf1121-20261011/current-apks.json')","sha(base / 'rf1124-theme-diagnostic-test-build-retry1-20261011/current-apks.json')")
s=s.replace('RF1124 native-theme diagnostic instrumentation','RF1125 real draw and card-pixel theme instrumentation')
assert "stage = base / 'rf1125-theme-render-test-build-20261011'" in s
ast.parse(s)
with (b/'build-rf1125-theme-render-test.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
for api,source in [(35,'boot-rf1124-api35-host-retry1.py'),(31,'boot-rf1124-api31-host.py')]:
    s=(b/source).read_text(encoding='utf-8-sig')
    s=s.replace('api35-host-rf1124-retry1-20261011','api35-host-rf1125-20261011').replace('api31-host-rf1124-20261011','api31-host-rf1125-20261011')
    ast.parse(s)
    with (b/f'boot-rf1125-api{api}-host.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('RF1125 registered; one Android test source changed; final APK builder and exact dedicated boot helpers prepared')
