from pathlib import Path
import ast
b=Path(__file__).parent
s=(b/'run-rf1124-theme-diagnostics-retry1-api35.py').read_text(encoding='utf-8-sig')
s=s.replace('api{api}-theme-rf1124-retry1-20261011','api{api}-theme-rf1125-20261011')
s=s.replace('rf1124-theme-diagnostic-test-build-retry1-20261011','rf1125-theme-render-test-build-20261011')
s=s.replace("boot_dir = b/(f'api{api}-host-rf1124-20261011' if api==31 else 'api35-host-rf1124-retry1-20261011')", "boot_dir = b/f'api{api}-host-rf1125-20261011'")
s=s.replace("assert 2 <= len(observed['records']) <= 3", "assert 1 <= len(observed['records']) <= 3 # Partial failed draw diagnostics never count as native acceptance")
anchor="            p = call(['exec-out','cat',external+f'/rf201-{label}-{run}.png'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)"
assert s.count(anchor)==1
s=s.replace(anchor,"            if 'captureAtNs' not in record.get('renderCapture', {}):\n                assert not row['nativePassed']; row.setdefault('failedBeforeImage', []).append(label); continue\n"+anchor)
s=s.replace("'method':'systemThemeFollowsLightDarkLight', 'budgetSeconds':45", "'method':'systemThemeFollowsLightDarkLight', 'budgetSeconds':45, 'newRenderBudgetSeconds':10, 'pixelTolerance':6, 'partialDiagnosticsAreNotNativePass':True")
ast.parse(s)
with (b/'run-rf1125-theme-render.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(b/'stop-rf1124-owned-emulator-retry1-api35.py').read_text(encoding='utf-8-sig')
s=s.replace("s=b/(f'api{api}-host-rf1124-20261011' if api==31 else 'api35-host-rf1124-retry1-20261011')", "s=b/f'api{api}-host-rf1125-20261011'")
s=s.replace('api{api}-theme-rf1124-retry1-20261011','api{api}-theme-rf1125-20261011');ast.parse(s)
with (b/'stop-rf1125-owned-emulator.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Native outcome still uses original exact one-test reader; failing draw records stay diagnostic-only')
