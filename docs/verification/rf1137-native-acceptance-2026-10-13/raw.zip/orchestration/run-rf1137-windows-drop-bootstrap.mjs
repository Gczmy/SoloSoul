import assert from 'node:assert/strict';
import {readFile, lstat, realpath, mkdir, rename} from 'node:fs/promises';
import path from 'node:path';
import {setTimeout as pause} from 'node:timers/promises';
import {sha256,newJson,validateFixtureManifest,preparedManifest,unusedPort,startChild,OwnedProcess,deadline,cleanupOutcome} from '../tauri/scripts/native-perf-run.mjs';
import {checkBound,checkJourney} from '../tauri/scripts/native-perf-sdk-journey.mjs';
import {checkConsumed,selectDiagnosticIdentities} from '../tauri/scripts/native-perf-diagnose.mjs';
const R='D:/SoloSoul', S=path.join(R,'build/rf1137-current-windows-20261012');
const root=path.join(S,'ss-rf1137-public-drag-run');
const fixture=path.join(R,'build/rf312-maintenance-20261009/fixtures/vault100');
async function load(file,max=1024*1024){
 const stat=await lstat(file);assert(stat.isFile()&&!stat.isSymbolicLink()&&stat.size<=max);
 assert.equal((await realpath(file)).toLowerCase(),file.toLowerCase());
 return JSON.parse((await readFile(file,'utf8')).replace(/^\uFEFF/,''));
}
const pkg=await load(path.join(S,'runtime-package.json'));
const sources=await load(path.join(S,'sources.json'));
const fixtureManifest=validateFixtureManifest(await load(path.join(fixture,'rf312-fixture.json')));
const fixtureFiles={};
async function collect(dir){
 const {readdir}=await import('node:fs/promises');
 for(const entry of await readdir(dir,{withFileTypes:true})){
  assert(!entry.isSymbolicLink());const file=path.join(dir,entry.name);
  if(entry.isDirectory())await collect(file);else fixtureFiles[path.relative(fixture,file)]=await sha256(file);
 }
}
await collect(fixture);
async function frozen(){
 assert.equal(await sha256(pkg.exe),pkg.sha256);
 for(const [n,h] of Object.entries(sources))assert.equal(await sha256(path.join(R,n)),h,n);
 for(const row of pkg.resources)assert.equal(await sha256(row.copy),row.sha256);
 for(const [n,h] of Object.entries(fixtureFiles))assert.equal(await sha256(path.join(fixture,n)),h);
}
await frozen();
const environment={...process.env};delete environment.SOLOSOUL_REGISTRY_PUBKEY;
let owner,launch;
const record={task:'RF-1137',scope:'Windows public fixture bootstrap for real OS file drop',
 head:pkg.head,exeSha256:pkg.sha256,root,fixtureFiles,startedAt:new Date().toISOString(),
 nativeDragDropAccepted:false,performanceAccepted:false,otherTasksRemainPaused:true};
try{
 const prep=startChild(pkg.exe,['--native-perf-prepare',root,'--fixture',fixture],environment);
 record.prepare=await deadline(prep.completion,120000,'Public fixture preparation');assert.equal(record.prepare.exitCode,0);
 const owned=preparedManifest(await load(path.join(root,'native-perf-owned.json')),root,fixtureManifest,fixture);
 const port=await unusedPort(),at=Date.now();
 launch=startChild(pkg.exe,['--native-perf-root',root,'--native-perf-port',String(port),'--native-perf-journey','sdk-input'],environment);
 assert(launch.child.pid);owner=new OwnedProcess(launch.child,pkg.exe,at,owned.webview);
 async function wait(name,ms){
  const end=Date.now()+ms,file=path.join(root,name);
  while(Date.now()<end){
   assert.equal(launch.child.exitCode,null,'Owned GUI exited');
   try{return await load(file);}catch(error){if(error.code!=='ENOENT')throw error;}
   await pause(30);
  }
  throw Error('Timed out waiting for '+name);
 }
 const bound=checkBound(await wait('native-perf-sdk-journey-bound.json',65000),owned,launch.child.pid,port);
 const before=selectDiagnosticIdentities(owner,await owner.sample());assert.equal(before[1].pid,bound.browserPid);
 record.identitiesBefore=before;record.bound=bound;
 record.consumed=checkConsumed(await load(path.join(root,'native-perf-consumed.json')),owned,launch.child.pid,port);
 const authorization={schemaVersion:1,scope:'windows-native-sdk-ui-input-authorized',runId:owned.runId,pid:launch.child.pid,browserPid:bound.browserPid};
 await newJson(path.join(root,'.native-perf-sdk-journey-authorized.tmp'),authorization);
 await rename(path.join(root,'.native-perf-sdk-journey-authorized.tmp'),path.join(root,'native-perf-sdk-journey-authorized.json'));
 record.bootstrapJourney=checkJourney(await wait('native-perf-sdk-journey.json',300000),owned,bound,fixtureManifest);
 record.identitiesAfter=selectDiagnosticIdentities(owner,await owner.sample());
 assert.deepEqual(record.identitiesAfter,record.identitiesBefore);await frozen();
 await newJson(path.join(S,'drop-ui-ready.json'),{pid:launch.child.pid,runId:owned.runId,root,
 exe:pkg.exe,identities:record.identitiesAfter,publicFixtureUnlockedByExistingSdkJourney:true,
 actualNativeFileDropStillRequired:true});
 await newJson(path.join(S,'bootstrap-result.json'),record);
 console.log('Public fixture GUI ready for actual OS file drag; owned PID',launch.child.pid);
 const end=Date.now()+30*60*1000;
 while(Date.now()<end&&launch.child.exitCode===null){
  try{
   const close=await load(path.join(S,'close-owned-gui.json'),1024);
   assert.deepEqual(close,{action:'close-owned-gui',runId:owned.runId});break;
  }catch(error){if(error.code!=='ENOENT')throw error;}
  await pause(500);
 }
}catch(error){
 await newJson(path.join(S,'bootstrap-error.json'),{message:String(error.message),at:new Date().toISOString(),nativeAccepted:false});
 process.exitCode=1;
}finally{
 if(owner){
  const cleanup=await owner.cleanup();const exit=await deadline(launch.completion,20000,'Owned GUI cleanup exit');
  const outcome=cleanupOutcome(cleanup,exit);await newJson(path.join(S,'owned-gui-cleanup.json'),{cleanup,exit,outcome});
  if(!outcome.complete)process.exitCode=1;
 }
 await frozen();
}
