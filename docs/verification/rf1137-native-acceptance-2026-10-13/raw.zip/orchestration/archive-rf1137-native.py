from pathlib import Path
import hashlib, json, zipfile

R = Path('D:/SoloSoul')
B = R/'build/android-native-feasibility-20261010'
S = B/'rf1137-native-acceptance-round2-20261012'
W = R/'build/rf1137-current-windows-20261012'
D = R/'docs/verification/rf1137-native-acceptance-2026-10-13'
D.mkdir(exist_ok=True)
members = {}
allowed = {'.json', '.log', '.png', '.jpg', '.txt', '.xml', '.py', '.kt', '.mjs', '.gradle'}

def add_tree(root, prefix, recursive=True):
    for p in sorted(root.rglob('*') if recursive else root.iterdir()):
        if p.is_file() and p.suffix in allowed:
            assert not p.is_symlink()
            members[prefix+'/'+p.relative_to(root).as_posix()] = p

add_tree(S, 'android-current')
add_tree(W, 'windows-build', False)
add_tree(W/'attempt2', 'windows-attempt2', False)
add_tree(W/'attempt3', 'windows-attempt3', False)
for attempt in ('attempt2','attempt3'):
    for n in ('native-perf-owned.json', 'native-perf-consumed.json',
              'native-perf-sdk-journey-bound.json', 'native-perf-sdk-journey.json',
              'native-perf-sdk-journey-authorized.json'):
        p = W/attempt/'ss-rf1137-public-drag-run'/n
        assert p.is_file()
        members['windows-'+attempt+'/public-bootstrap/'+n] = p
    p = W/attempt/'public-app.log'
    members['windows-'+attempt+'/public-bootstrap/app.log'] = p
for n in ('prepare-rf1137-native-round2.py', 'prepare-rf1137-native-round2-generated.py',
          'build-rf1137-round2-android-release.py', 'package-rf1137-round2-android-release.py',
          'prepare-rf1137-current-journeys.py', 'cleanup-rf1137-private-backups.py',
          'summarize-rf1137-android.py'):
    p = B/n
    if p.is_file(): members['orchestration/'+n] = p
for n in ('build-rf1137-current-windows.py', 'run-rf1137-windows-drop-bootstrap.mjs',
          'run-rf1137-windows-drop-bootstrap-attempt2.mjs', 'run-rf1137-windows-drop-bootstrap-attempt3.mjs',
          'finalize-rf1137-windows-acceptance.py', 'finalize-rf1137-native-docs.py',
          'verify-rf1137-doc-evidence.py', 'archive-rf1137-native.py'):
    members['orchestration/'+n] = R/'build'/n
for p in sorted((W/'public-drag').glob('*.txt')):
    members['public-drag/'+p.name] = p
p = B/'rf1137-native-acceptance-20261012/android-ci-disabled.png'
members['ci/android-ci-disabled.png'] = p

archive = D/'raw.zip'
index = {}
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n,p in sorted(members.items()):
        data = p.read_bytes()
        z.writestr(n,data)
        index[n] = {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()}
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert sorted(z.namelist()) == sorted(index)
    for n,row in index.items():
        data = z.read(n)
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
record = {'task':'RF-1137', 'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
          'members':index, 'excluded':'Vault/runtime directories, private/public TARs, binaries, APKs, signing keys, caches'}
(D/'index.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'members':len(index),'archiveBytes':archive.stat().st_size,'sha256':record['archiveSha256']}))
