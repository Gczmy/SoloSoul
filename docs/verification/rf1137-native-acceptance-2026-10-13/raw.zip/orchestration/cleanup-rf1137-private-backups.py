from pathlib import Path
import hashlib,importlib.util,json,sys
R=Path('D:/SoloSoul');S=Path(__file__).parent/'rf1137-native-acceptance-round2-20261012'
assert len(sys.argv)==2 and sys.argv[1] in ('100','5000')
count=sys.argv[1];P=S/('first-'+count+'-diagnostic')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
report=load(P/'report.json');receipt=load(S/('first-'+count+'-diagnostic.receipt.json'))
assert receipt['exitCode']==0 and receipt['passed'] and receipt['restored']
for key in ('passed','nativePassed','restored','originalApksRestored','ownedProbeRemoved','blurRestored','ownedPublicOcrInputRemoved','frozenInputsUnchanged'):
 assert report[key] is True,key
assert report['originalInstalledPackages']==report['restoredInstalledPackages']
assert report['restoreVerification']=={'entries':216,'allFileContentsLinksAndModesMatch':True}
spec=importlib.util.spec_from_file_location('restore',R/'tauri/scripts/android-home-native-regression.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
before=P/'private-data-before.tar';after=P/'private-data-restored.tar'
for p in (before,after):
 assert p.resolve().is_relative_to(S.resolve()) and p.is_file() and not p.is_symlink()
 assert not (p.stat().st_file_attributes&0x400)
a=helper.inventory(before,require_empty=True);b=helper.inventory(after,require_empty=True)
assert a==b and len(a)==216
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(before)==report['backup']['sha256']
rows=[{'file':p.name,'sha256':sha(p),'bytes':p.stat().st_size} for p in (before,after)]
result={'count':int(count),'privateContentsNotPublished':True,'entries':216,
 'allFileContentsLinksAndModesEqual':True,'reportAndOriginalPackagesRestored':True,'files':rows,'removed':False}
target=S/('private-backup-cleanup-'+count+'.json');assert not target.exists()
target.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
for p in (before,after):p.unlink()
assert not before.exists() and not after.exists();result['removed']=True
target.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Compared216entries and original package/UIDs;removed exactly two local private TARs for',count)
