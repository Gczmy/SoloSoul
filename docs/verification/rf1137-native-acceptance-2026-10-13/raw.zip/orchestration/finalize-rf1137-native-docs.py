from pathlib import Path
import json
R=Path('D:/SoloSoul');D=R/'docs/verification/rf1137-native-acceptance-2026-10-13'
W=R/'build/rf1137-current-windows-20261012'
windows=json.loads((W/'attempt3/windows-acceptance-summary.json').read_text())
assert windows['accepted'] and windows['ownedGuiCleanupComplete']
result=json.loads((D/'result.json').read_text())
result.update(closed=True,windows=windows,mergeRecommendation='native acceptance complete; assess latest pushed head CI and remote merge state separately')
(D/'result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
(D/'.gitattributes').write_text('*.json -text whitespace=cr-at-eol\n*.zip binary\n',encoding='utf-8')
p=R/'docs/verification/RF-1137-shared-window-drag-drop.md';text=p.read_text(encoding='utf-8')
first=text.index('\n\n')+2;end=text.index('\n\n',first)
text=text[:first]+'当前 Android 原生与 Windows 真实文件拖放验收均已通过，RF-1137 完成。Windows 首轮测试目录错误和一次闲置锁定的过程保留，最终成功结果绑定独立公开测试窗口。'+text[end:]
text=text.replace('修正后的手动结果仍待确认，不将准备成功或订阅计数变化视为桌面拖放通过。','当时修正后的手动结果尚待确认；其后用户纠正此前成功答复为未完成，公开测试窗口因闲置锁定。保留旧窗口记录并清理后，第三次独立窗口用既有 SDK 行程解锁，夹具直接准备在其 Documents 内。最终成功结果见下文。',1)
text=text.replace('当前分支可与 main 无冲突合并，但 RF-1137 桌面验收仍未通过，暂不建议合并。','当时分支与 main 无冲突，但桌面验收尚缺，因此未执行合并；补齐验收后的合并条件另按最新推送提交及 CI 核验。',1)
text+='''

最终 Windows 验收（2026-10-13）：用户手动完成真实资源管理器拖放，A 文件到 `obj_perf_00000000`，按首页→Identity→Clear 的指引后 B 文件到 `obj_perf_00000001`。用户报告两次成功；页面切换序列属于手动步骤，未另行采集其过程事件。代理随后在实际应用核验两张卡片各 Attachments (1)、各 Active (1)，名称分别为 `rf1137-native-drop-a.txt` / `rf1137-native-drop-b.txt`、原始大小各43字节，两个实际预览正文分别显示公开夹具 A / B。首页全局附件数2，磁盘仅两个附件副本，物理目录分别归属上述对象，没有重复或串对象；两份源文件字节和SHA保持。

最终窗口 runId `925912a09dd04985b345d134ec33479e`、PID11368，当前 Release EXE SHA `a7ffc0217f226460cf56081bc7224f96c941e04d000d3eb5eee92c9b2219b9e8`；结束时1963源码及94资源摘要再次一致。既有 OwnedProcess 仅清理本窗口及核验身份的子进程，bootstrap实际退出0；验收专用资源管理器已关闭，原 This PC 窗口保留。Android完整行程、Windows真实拖放和现有完整前端/覆盖率回归共同满足 RF-1137 关闭条件，320/331关闭。其他任务和goal继续暂停，RF-312完整性能范围不变，本提交不执行合并。
'''
p.write_text(text,encoding='utf-8')
p=R/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';text=p.read_text(encoding='utf-8')
text=text.replace('**319 / 331**；实际修复（已关闭）：319；排除：0；待验证/阻塞：6（RF-112、RF-121、RF-312、RF-1109、RF-1128、RF-1137）','**320 / 331**；实际修复（已关闭）：320；排除：0；待验证/阻塞：5（RF-112、RF-121、RF-312、RF-1109、RF-1128）',1)
text=text.replace('[!] Android已验；Windows夹具位置修正后待重试','[x] 完成',1)
start=text.index('### RF-1137\n');end=text.index('### RF-1138\n',start);section=text[start:end];status=section.index('- **状态：**')
section=section[:status]+'''- **状态：**完成。当前源码 `01f78fdb1` 的 Android 100/5000 Release原生完整12阶段各一组退出0，全部事件listen/unlisten均35/25，原包/UID/216项私有数据/系统值恢复并删除四份私有TAR。Windows真实拖放由用户完成，两个目标各1个附件、43字节源文件、文件名和实际预览正文分别正确，全局附件数2、物理文件仅两份且对象归属正确，源摘要不变。初次外部夹具被隔离白名单拒绝及闲置锁定过程保留；修正夹具到owned Documents后最终通过，产品和权限策略不变。最终源码1963/资源94摘要一致，owned GUI/bootstrap和专用Explorer清理通过，原Explorer保留。当前源码的前端覆盖率/生产浏览器和PR五项CI已通过；推送后最新head CI另行核验，不执行合并。详见[记录与原件](verification/RF-1137-shared-window-drag-drop.md)。其他任务及goal暂停，RF-312完整性能范围保持。

'''
text=text[:start]+section+text[end:]
start=text.index('- 当前处理：');end=text.index('\n',start)
text=text[:start]+'''- 当前处理：PR #5已创建，RF-1140/1141分别修复、验证、提交推送，运行源码五项CI全部成功。RF-1137当前Android及Windows真实文件拖放、归属/预览/恢复/清理验收通过，本次独立补齐证据提交后推送并检查最新head CI与合并条件。320/331关闭；不执行合并，其他任务及goal继续暂停。'''+text[end:]
text+='''

### RF-1137 原生验收收尾（2026-10-13，完成）

- 用户纠正中间成功答复为未完成，旧公开窗口闲置锁定；保留原失败和准备记录，身份校验清理旧窗口。第三次独立公开SDK窗口解锁，文件直接准备在其Documents内，路径白名单和产品源码未变。用户最终手动两次均成功，代理实际核验两个目标各1附件、名称和43字节大小、两个正确正文预览、全局总数2、仅两份落库文件及对象归属、源摘要不变；页面切换过程属于用户按指引手动操作，未另行采集过程事件。
- 最终1963源码/94资源/EXE摘要一致，owned GUI及其子进程清理完整、wrapper实际退出0，专用Explorer关闭，原Explorer保留；Android原生完整两组及恢复证据已补齐。[结构化结果和公开原件](verification/RF-1137-shared-window-drag-drop.md)逐长度/SHA回读，排除Vault、TAR、程序、APK和签名密钥。
- 仅RF-1137验收收尾独立提交；320/331关闭、5待验证、6待执行。按本次明确授权推送并检查最新PR #5 CI，再评估合并条件；其他任务和goal继续暂停，不执行合并。
'''
p.write_text(text,encoding='utf-8')
print('RF-1137 native acceptance closed; other tasks remain paused')
