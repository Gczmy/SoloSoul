from pathlib import Path
import datetime,hashlib,json,os,shutil,struct,subprocess,time
R=Path('D:/SoloSoul'); W=R/'build/rf121-theme-binding-20261010'
B=R/'build/android-native-feasibility-20261010'
I=B/'rf1137-native-acceptance-round2-20261012'
S=R/'build/rf1137-current-windows-20261012';S.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=load(I/'sources.json');frontend=load(I/'frontend.json')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head==load(I/'starting-state.json')['head']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
def save(n,v):
 with (S/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
def frozen():
 assert all(sha(R/n)==h for n,h in sources.items())
 dist=R/'tauri/dist'
 assert {p.relative_to(dist).as_posix() for p in dist.rglob('*') if p.is_file()}==set(frontend['files'])
 assert all(sha(dist/n)==h['sha256'] for n,h in frontend['files'].items())
frozen();save('sources.json',sources);save('frontend.json',frontend)
C=R/'build/rf312-maintenance-20261009'
env=os.environ.copy();env.update(TEMP=str(C/'tmp'),TMP=str(C/'tmp'),CARGO_HOME=str(C/'cargo-home'),
 CARGO_TARGET_DIR=str(C/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(C/'ort-cache'),
 TAURI_CONFIG=json.dumps(load(R/'tauri/src-tauri/tauri.native-perf.conf.json')),PYTHONUTF8='1')
for k in ['PDFIUM_LIBRARY_PATH','TAURI_ANDROID_PROJECT_PATH','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:env.pop(k,None)
command=['cargo','build','--locked','--offline','-p','solo_soul','--bin','solo_soul','--release','--features','native-perf']
save('input-proof.json',{'head':head,'sources':sources,'frontend':frontend,'command':command,
 'config':json.loads(env['TAURI_CONFIG']),'freshFrontendBuild':False,
 'frontendReuse':'exact RF-1139 production build; CI fixes only move a Rust trait import and isolate tests',
 'otherTasksRemainPaused':True,'nativeDragDropAccepted':False})
began=time.monotonic()
with (S/'build.stdout.log').open('xb') as out,(S/'build.stderr.log').open('xb') as err:
 child=subprocess.Popen(command,cwd=R/'tauri',env=env,stdout=out,stderr=err,
  stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
 save('build.live.json',{'pid':child.pid,'command':command,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 print('RF-1137 Windows Release live PID',child.pid,flush=True);code=child.wait()
save('build.receipt.json',{'exitCode':code,'seconds':time.monotonic()-began});frozen();assert code==0
runtime=S/'bin';runtime.mkdir();exe=runtime/'solo_soul.exe';shutil.copy2(C/'cargo-target/release/solo_soul.exe',exe)
data=exe.read_bytes();pe=struct.unpack_from('<I',data,0x3c)[0]
assert data[pe:pe+4]==b'PE\0\0' and struct.unpack_from('<H',data,pe+24+68)[0]==2
for marker in (b'--native-perf-prepare',b'windows-native-perf-owned',b'windows-native-perf-consumed'):
 assert marker in data
old=load(W/'rf1129-native-build-20261011/runtime-package.json');rows=[];oldExe=Path(old['exe'])
for row in old['resources']:
 source=Path(row['source']);assert sha(source)==row['sha256']
 target=runtime/Path(row['copy']).relative_to(oldExe.parent)
 assert target.resolve().is_relative_to(runtime.resolve())
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target);assert sha(target)==row['sha256']
 rows.append({'source':str(source),'copy':str(target),'sha256':row['sha256']})
assert len(rows)==94
save('runtime-package.json',{'head':head,'exe':str(exe),'sha256':sha(exe),'bytes':len(data),
 'resources':rows,'sourceManifestSha256':sha(S/'sources.json'),'frontendManifestSha256':sha(S/'frontend.json'),
 'nativeDragDropAccepted':False})
frozen();print('Current frozen Windows diagnostic Release and94resources verified; real drag still required',flush=True)
