from pathlib import Path
import hashlib,json,zipfile,re
R=Path('D:/SoloSoul')
D=R/'docs/verification/rf1137-native-acceptance-2026-10-13'
index=json.loads((D/'index.json').read_text(encoding='utf-8'))
assert hashlib.sha256((D/'raw.zip').read_bytes()).hexdigest()==index['archiveSha256']
with zipfile.ZipFile(D/'raw.zip') as z:
    assert z.testzip() is None
    assert sorted(z.namelist())==sorted(index['members'])
    for name,row in index['members'].items():
        b=z.read(name)
        assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],name
        assert Path(name).suffix not in ('.tar','.apk','.so','.exe','.db','.key')
    a=json.loads(z.read('android-current/android-acceptance-summary.json'))
    assert a['head']=='01f78fdb1d964e27805f19eaa85ee9acbe88cb2d'
    for group in a['groups']:
        assert group['all12PhasesPassed'] and group['originalPackageUidAnd216EntriesRestored']
        assert group['privateTarsRemoved'] and (group['listen'],group['unlisten'])==(35,25)
    assert len(a['groups'])==2 and not a['performanceBenchmarkAccepted']
    w=json.loads(z.read('windows-attempt3/windows-acceptance-summary.json'))
    assert w['accepted'] and w['ownedGuiCleanupComplete'] and w['globalActiveAttachments']==2
    assert w['sourceFilesUnchanged'] and w['noDuplicateOrCrossObjectUploadObserved']
    assert len(w['attachments'])==2
    for n,row in enumerate(w['attachments']):
        assert row['objectId']==f'obj_perf_{n:08d}' and row['activeAttachments']==1
        assert row['sourceBytes']==43 and row['previewMatchesPublicText']
result=json.loads((D/'result.json').read_text(encoding='utf-8'))
assert result['closed'] and result['windows']['accepted'] and result['otherTasksAndGoalRemainPaused']
for document in ('docs/verification/RF-1137-shared-window-drag-drop.md',):
    p=R/document
    for target in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
        if not target.startswith(('http:', 'https:', '#')):
            assert (p.parent/target.split('#')[0]).exists(),target
print(json.dumps({'archiveMembersVerified':len(index['members']),'androidGroupsVerified':2,'windowsNativeAccepted':True,'linksVerified':True}))
