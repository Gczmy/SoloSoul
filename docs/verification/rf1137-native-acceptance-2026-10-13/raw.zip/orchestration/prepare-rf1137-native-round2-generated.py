from pathlib import Path
import hashlib,json,subprocess

R=Path('D:/SoloSoul'); B=Path(__file__).parent
S=B/'rf1137-native-acceptance-round2-20261012'; S.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='01f78fdb1d964e27805f19eaa85ee9acbe88cb2d'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
old=load(B/'rf312-first-ocr-probe-round15-20261012/inputs.json')['runtimeSourceFiles']
names=set(old)
names.update(n.decode() for n in subprocess.check_output(['git','ls-files','-z','--','tauri','solosoul_cli'],cwd=R).split(b'\0') if n)
assert all((R/n).is_file() for n in names)
sources={n:sha(R/n) for n in sorted(names)}
(S/'sources.json').write_text(json.dumps(sources,indent=2)+'\n',encoding='utf-8')
dist=R/'tauri/dist'
frontend={'gitHead':head,'files':{p.relative_to(dist).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(dist.rglob('*')) if p.is_file()}}
assert frontend['files'] and any(b'tauri://drag-' in p.read_bytes() for p in dist.glob('assets/*.js'))
assert sha(R/'tauri/src/lib/windowDragDrop.ts')==load(R/'docs/verification/rf1139-drag-drop-recovery-2026-10-12/result.json')['sources']['tauri/src/lib/windowDragDrop.ts']['worktreeSha256']
(S/'frontend.json').write_text(json.dumps(frontend,indent=2)+'\n',encoding='utf-8')
(S/'starting-state.json').write_text(json.dumps({'task':'RF-1137','head':head,'sourceCount':len(sources),'frontendCount':len(frontend['files']),'changesFromPriorRuntimeSources':[n for n,h in old.items() if sources[n]!=h],'newRuntimeSources':sorted(names-set(old)),'otherTasksRemainPaused':True,'pr':5},indent=2)+'\n',encoding='utf-8')
guard="""
frontend=load(S/'frontend.json')
def frozen_frontend():
    root=R/'tauri/dist'
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    assert actual==set(frontend['files'])
    for n,row in frontend['files'].items():
        assert sha(root/n)==row['sha256'] and (root/n).stat().st_size==row['bytes'],n
frozen_frontend()
"""
code=(B/'build-rf1135-android-release.py').read_text(encoding='utf-8')
assert code.count("S=B/'rf1135-android-attachment-temp-20261012'")==1
code=code.replace("S=B/'rf1135-android-attachment-temp-20261012'","S=B/'rf1137-native-acceptance-round2-20261012'",1)
anchor='sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()\n'
assert code.count(anchor)==1
code=code.replace(anchor,anchor+guard,1)
code=code.replace("{'sources':sources,'command':command", "{'sources':sources,'frontend':frontend,'command':command",1)
code=code.replace("changed=[n for n,h in sources.items()", "frozen_frontend()\nchanged=[n for n,h in sources.items()",1)
script=B/'build-rf1137-round2-android-release.py'; assert not script.exists();script.write_text(code,encoding='utf-8',newline='\n')
code=(B/'package-rf1135-android-release.py').read_text(encoding='utf-8')
assert code.count("I=B/'rf1135-android-attachment-temp-20261012'")==1
code=code.replace("I=B/'rf1135-android-attachment-temp-20261012'","I=B/'rf1137-native-acceptance-round2-20261012'",1)
package_guard=guard.replace("S/'frontend.json'","I/'frontend.json'")
assert code.count(anchor)==1;code=code.replace(anchor,anchor+package_guard,1)
code=code.replace('def frozen():\n','def frozen():\n    frozen_frontend()\n',1)
code=code.replace("'library':library,'packagedStrippedLibrarySha256'", "'frontend':frontend,'library':library,'packagedStrippedLibrarySha256'",1)
script=B/'package-rf1137-round2-android-release.py';assert not script.exists();script.write_text(code,encoding='utf-8',newline='\n')
print('Frozen RF-1137 native inputs:',len(sources),'source files;',len(frontend['files']),'current frontend outputs')
