from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');W=R/'build/rf1137-current-windows-20261012';A=W/'attempt3'
ready=json.loads((A/'drop-ui-ready.json').read_text())
root=Path(ready['root']); sources=json.loads((W/'sources.json').read_text())
pkg=json.loads((W/'runtime-package.json').read_text())
for name,expected in sources.items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==expected,name
assert hashlib.sha256(Path(pkg['exe']).read_bytes()).hexdigest()==pkg['sha256']
for row in pkg['resources']:assert hashlib.sha256(Path(row['copy']).read_bytes()).hexdigest()==row['sha256']
assert json.loads((A/'owned-gui-cleanup.json').read_text())['outcome']['complete']
assert 'Attachments 2 Manage' in (A/'home-global-attachment-count.ax.txt').read_text()
cards=(A/'after-two-manual-drops.ax.txt').read_text()
for n in (0,1):assert f'Record {n:08d} note History Attachments (1)' in cards
assert cards.count('button Attachments (1) Description: Attachments')==2
rows=[]
all_storage=sorted((root/'vault/attachments').rglob('*.txt'))
assert len(all_storage)==2
for n,letter in enumerate(('a','b')):
    name=f'rf1137-native-drop-{letter}.txt'
    original=W/'public-drag'/name;source=root/'profile/Documents/public-drag'/name
    assert source.read_bytes()==original.read_bytes()
    assert len(source.read_bytes())==43
    matches=[p for p in all_storage if p.name==name]
    assert len(matches)==1 and matches[0].parent.parent.name==f'obj_perf_{n:08d}'
    preview=(A/f'object{n}-preview-{letter}.ax.txt').read_text()
    assert f'RF-1137 public native file drag fixture {letter.upper()}.' in preview
    panel=(A/f'object{n}-attachments-{letter}.ax.txt').read_text()
    assert 'Active (1)' in panel and name in panel
    rows.append({'objectId':f'obj_perf_{n:08d}','fileName':name,'activeAttachments':1,
                 'sourceBytes':43,'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                 'previewMatchesPublicText':True,'storagePath':str(matches[0]),
                 'storedBytes':matches[0].stat().st_size,'storedSha256':hashlib.sha256(matches[0].read_bytes()).hexdigest()})
summary={'task':'RF-1137','head':pkg['head'],'runId':ready['runId'],'pid':ready['pid'],
         'exeSha256':pkg['sha256'],'sourcesVerified':len(sources),'resourcesVerified':len(pkg['resources']),
         'nativeDropPerformedBy':'human user; both successful drops reported in this chat',
         'sequence':'A to object0; Home/Identity/Clear; B to object1, instructed and manually performed; transition not separately instrumented',
         'accepted':True,'attachments':rows,'globalActiveAttachments':2,'noDuplicateOrCrossObjectUploadObserved':True,
         'sourceFilesUnchanged':True,'ownedGuiCleanupComplete':True,'bootstrapWrapperExitCode':0,
         'originalExplorerPreserved':True,'ownedExplorerClosed':True,
         'firstAttempt':'two failures retained: external fixture was outside existing native-perf FS base',
         'correction':'same public file bytes placed under owned profile/Documents; product and FS policy unchanged',
         'intermediateRetry':'user corrected previous successful reply to not completed; old GUI was idle-locked, preserved then closed; fresh public SDK fixture unlocked',
         'otherTasksAndGoalRemainPaused':True,'performanceBenchmarkAccepted':False}
(A/'windows-acceptance-summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'accepted':True,'globalAttachments':2,'sourcesVerified':len(sources),'resourcesVerified':len(pkg['resources'])}))
