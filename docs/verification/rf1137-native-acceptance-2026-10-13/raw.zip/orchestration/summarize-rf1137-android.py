from pathlib import Path
from collections import Counter
import hashlib,importlib.util,json
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf1137-native-acceptance-round2-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('finger',S/'verify-finger-readiness.py')
finger=importlib.util.module_from_spec(spec);spec.loader.exec_module(finger)
package=load(S/'android-release-package/package-verification.json');rows=[]
expected=['activity-startup','password-unlock','first-ocr-user-flow','workspace','search-needle','attachments-open','image-preview','text-preview','pdf-text-native-diagnostic','pdf-scanned-native-diagnostic','application-lock','password-reunlock']
for count in ('100','5000'):
 P=S/('first-'+count+'-diagnostic');report=load(P/'report.json')
 assert all(report[k] is True for k in ('passed','nativePassed','restored','originalApksRestored','ownedProbeRemoved','blurRestored','ownedPublicOcrInputRemoved','frozenInputsUnchanged'))
 assert report['releaseInstalledPackage']['sha256']==package['apk']['sha256']
 assert report['originalInstalledPackages']==report['restoredInstalledPackages']
 evidence=report['fixedVaultEvidence'];assert evidence['objectCount']==int(count)
 assert [p['name'] for p in evidence['phases']]==expected and all(p['success'] for p in evidence['phases'])
 readiness=finger.verify(evidence)
 phases=[]
 for phase in evidence['phases']:
  obs=phase['observer'];assert obs['valid'] and not obs['invalidReasons'] and obs['observedCount']==len(obs['commands'])
  commands=obs['commands'][phase['ipcStart']:phase['ipcEnd']]
  assert len(commands)==phase['transportAttempts']
  names=Counter(c['command'] for c in commands)
  phases.append({'name':phase['name'],'listen':names['plugin:event|listen'],'unlisten':names['plugin:event|unlisten']})
 commands=evidence['phases'][-1]['observer']['commands'];names=Counter(c['command'] for c in commands)
 cleanup=load(S/('private-backup-cleanup-'+count+'.json'));assert cleanup['removed'] and cleanup['allFileContentsLinksAndModesEqual']
 assert not list(P.glob('*private*.tar'))
 rows.append({'objectCount':int(count),'all12PhasesPassed':True,'actualNativeFingerAndReadiness':readiness,
  'listen':names['plugin:event|listen'],'unlisten':names['plugin:event|unlisten'],'ipcTotal':len(commands),
  'priorCompleteJourneyListen':435,'priorCompleteJourneyUnlisten':425,'phases':phases,
  'originalPackageUidAnd216EntriesRestored':True,'privateTarsRemoved':True,
  'hostReportSha256':sha(P/'report.json'),'deviceReportSha256':sha(P/'device-files/report.json')})
assert all(row['listen']==35 and row['unlisten']==25 for row in rows)
summary={'task':'RF-1137','head':load(S/'starting-state.json')['head'],'apk':package['apk'],
 'sourceManifestSha256':sha(S/'sources.json'),'frontendManifestSha256':sha(S/'frontend.json'),
 'groups':rows,'listenerCountScope':'all event IPC attempts;event names and arguments not captured;do not attribute every call to drag-drop',
 'currentSamplesPerGroup':1,'priorBaseline':'RF-312 existing ten complete journeys;five per100/5000',
 'performanceBenchmarkAccepted':False,'desktopRealDragStillRequired':True,'otherTasksRemainPaused':True}
target=S/'android-acceptance-summary.json';assert not target.exists()
target.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Both12phase current native journeys passed;35listen/25unlisten each;216entries/packageUID restored;four privateTARs removed')
