from pathlib import Path
import hashlib,json,shutil,subprocess
B=Path(__file__).parent;R=Path('D:/SoloSoul');S=B/'rf1137-native-acceptance-round2-20261012'
old=B/'rf312-first-ocr-probe-round15-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=load(S/'sources.json');assert all(sha(R/n)==h for n,h in sources.items())
package=load(S/'android-release-package/package-verification.json')
assert package['acceptedPackagePreparation'] and sha(Path(package['apk']['path']))==package['apk']['sha256']
inputs=load(old/'inputs.json');originalTest=dict(inputs['runtimeTest'])
assert sha(Path(originalTest['path']))==originalTest['sha256']
assert sha(old/'AndroidMediaPerfInstrumentedTest.kt')==originalTest['homeTestSourceSha256']
for n in ('AndroidMediaPerfInstrumentedTest.kt','media-native-driver.py','verify-finger-readiness.py'):
 assert not (S/n).exists();shutil.copyfile(old/n,S/n)
inputs.update(runtimeSourceFiles=sources,release=package,releaseBuildInputSha256=sha(S/'android-release-build/input-proof.json'),
 sourceParentHead=load(S/'starting-state.json')['head'],scope='RF-1137 current optimized Android functional and subscription acceptance; other tasks paused')
assert inputs['runtimeTest']==originalTest
(S/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8',newline='\n')
(S/'test-probe-reuse.json').write_text(json.dumps({'sameIndependentTestApkBytes':True,'testProbe':originalTest,
 'sameInstrumentedTestSourceBytes':True,'mainActivityAndNativeLibrariesNotPackagedInTest':True,
 'freshMainReleaseApk':package['apk'],'newTestBuildClaimed':False},indent=2)+'\n',encoding='utf-8',newline='\n')
for count in ('100','5000'):
 code=(old/('run-first-'+count+'-diagnostic.py')).read_text(encoding='utf-8')
 assert code.count("S=B/'rf312-first-ocr-probe-round15-20261012'")==1
 code=code.replace("S=B/'rf312-first-ocr-probe-round15-20261012'", "S=B/'rf1137-native-acceptance-round2-20261012'",1)
 target=S/('run-first-'+count+'-diagnostic.py');assert not target.exists();target.write_text(code,encoding='utf-8',newline='\n')
print('Fresh main APK/current1963sources;independent byte-identical probe reused;100/5000launchers prepared')
