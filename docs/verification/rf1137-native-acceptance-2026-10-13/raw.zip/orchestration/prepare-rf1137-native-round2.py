from pathlib import Path
import json,subprocess
B=Path(__file__).parent;R=Path('D:/SoloSoul')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head!='33fc34af4aa52cb9dddeadd2dba9ed773c28d965'
subjects=subprocess.check_output(['git','log','-2','--format=%s'],cwd=R,text=True)
assert '[RF-1140]' in subjects and '[RF-1141]' in subjects,subjects
code=(B/'prepare-rf1137-native-acceptance.py').read_text(encoding='utf-8')
assert code.count("assert head=='33fc34af4aa52cb9dddeadd2dba9ed773c28d965'")==1
code=code.replace("assert head=='33fc34af4aa52cb9dddeadd2dba9ed773c28d965'",'assert head=='+repr(head),1)
code=code.replace('rf1137-native-acceptance-20261012','rf1137-native-acceptance-round2-20261012')
code=code.replace('build-rf1137-android-release.py','build-rf1137-round2-android-release.py')
code=code.replace('package-rf1137-android-release.py','package-rf1137-round2-android-release.py')
script=B/'prepare-rf1137-native-round2-generated.py';assert not script.exists()
script.write_text(code,encoding='utf-8',newline='\n')
exec(compile(code,str(script),'exec'),{'__file__':str(script),'__name__':'__main__'})
S=B/'rf1137-native-acceptance-round2-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
previous=load(B/'rf1137-native-acceptance-20261012/frontend.json')
current=load(S/'frontend.json');assert current['files']==previous['files']
changed=subprocess.check_output(['git','diff','--name-only',
 '33fc34af4aa52cb9dddeadd2dba9ed773c28d965..HEAD','--','tauri/src'],cwd=R,text=True).splitlines()
assert changed==['tauri/src/components/onboarding/OnboardingDialog.test.tsx'],changed
current.update(frontendReused=True,frontendSourceRevision='33fc34af4aa52cb9dddeadd2dba9ed773c28d965',
 validatedAgainstHead=head,frontendProductionSourcesUnchanged=True,
 onlyChangedFrontendInputExcludedFromProduction=changed)
(S/'frontend.json').write_text(json.dumps(current,indent=2)+'\n',encoding='utf-8')
