import copy, json
from pathlib import Path

S = Path(__file__).parent
load = lambda p: json.loads(p.read_text(encoding='utf-8'))

def verify(evidence):
    action = evidence.get('nativePickerFileAction', {})
    events = action.get('events', [])
    if action.get('action') != 'NATIVE_FINGER_TAP' or len(events) != 2 or [e.get('action') for e in events] != [0, 1]:
        raise RuntimeError('One real native DOWN/UP finger pair required')
    for event in events:
        if (event.get('injected') is not True or any(type(event.get(k)) is not int for k in ['action', 'source', 'toolType', 'pointerId', 'pointerCount'])
                or event['source'] != 4098 or event['toolType'] != 1 or event['pointerId'] != 0 or event['pointerCount'] != 1):
            raise RuntimeError('Exact native touchscreen finger properties required')
    gates = evidence.get('nativePaintReadiness', [])
    if not gates:
        raise RuntimeError('Actual native paint readiness records required')
    for gate in gates:
        state = gate.get('state', {})
        if (gate.get('requested') is not True or gate.get('committed') is not True
                or state.get('activity') != 'com.solosoul.app.MainActivity'
                or any(state.get(k) is not True for k in ['resumed', 'attached', 'shown', 'focused'])):
            raise RuntimeError('Exact resumed attached shown focused Main and commit required')
        a, b, budget = gate.get('startedAtNs'), gate.get('finishedAtNs'), gate.get('availableNs')
        if any(type(x) is not int for x in [a, b, budget]) or not 0 <= b - a <= budget <= 10_000_000_000:
            raise RuntimeError('Original shared native paint deadline required')
    return {'gates': len(gates), 'maximumReadinessAndCommitMs': max((g['finishedAtNs'] - g['startedAtNs']) / 1e6 for g in gates)}

if __name__ == '__main__':
    evidence = load(S / 'first-100-diagnostic/device-files/report.json')
    actual = verify(evidence)
    cases = [('missing-commit', lambda v: v['nativePaintReadiness'][0].update(committed=False), 'Exact resumed attached shown focused Main and commit required'),
             ('missing-focus', lambda v: v['nativePaintReadiness'][0]['state'].update(focused=False), 'Exact resumed attached shown focused Main and commit required'),
             ('wrong-activity', lambda v: v['nativePaintReadiness'][0]['state'].update(activity='com.solosoul.app.PdfPreviewActivity'), 'Exact resumed attached shown focused Main and commit required'),
             ('deadline-overrun', lambda v: v['nativePaintReadiness'][0].update(finishedAtNs=v['nativePaintReadiness'][0]['startedAtNs'] + v['nativePaintReadiness'][0]['availableNs'] + 1), 'Original shared native paint deadline required'),
             ('unknown-pointer', lambda v: v['nativePickerFileAction']['events'][0].update(toolType=0), 'Exact native touchscreen finger properties required'),
             ('boolean-pointer-type', lambda v: v['nativePickerFileAction']['events'][0].update(toolType=True), 'Exact native touchscreen finger properties required')]
    results = []
    for name, mutate, expected in cases:
        value = copy.deepcopy(evidence)
        mutate(value)
        try:
            verify(value)
        except RuntimeError as error:
            assert str(error) == expected
            results.append({'case': name, 'rejected': True, 'error': str(error)})
        else:
            raise AssertionError(name)
    output = {'actual100ReportAccepted': True, 'readiness': actual, 'negativeCases': results, 'originalReportsUnchanged': True}
    (S / 'finger-readiness-verifier-checks.json').write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8')
    print('Actual finger/readiness records accepted; six invalid evidence cases rejected')
