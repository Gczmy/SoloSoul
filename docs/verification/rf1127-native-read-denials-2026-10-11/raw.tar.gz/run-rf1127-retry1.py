"""Three complete, isolated public-vault journeys with owned WGC/state handshakes.

This does not change system appearance or accept a full RF-121 material matrix.
All writes are exclusive; failed runs remain available for independent review.
"""
from pathlib import Path
import datetime, hashlib, json, math, os, re, subprocess, sys, threading, time, traceback, uuid

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
modes=['baseline','light-collapsed','dark-expanded','dark-collapsed']
assert len(sys.argv)==2 and sys.argv[1] in ['--'+v for v in modes]
mode=sys.argv[1][2:]
scene=mode!='baseline'
dark=mode.startswith('dark-')
collapsed=mode.endswith('collapsed')
capture_stage = stage / ('ss-rf121-composed-window-restore-' + mode + '-settled-retry1-20261011')
output = capture_stage / 'actual100'
fixture = root / 'build/rf312-maintenance-20261009/fixtures/vault100'
pwsh = Path('C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(value, indent=2) + '\n')

def atomic_new(path, value):
    temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    save(temporary, value)
    try:
        os.link(temporary, path)  # Atomic create, refuses existing target.
    finally:
        temporary.unlink()

def ordinary(path, maximum):
    stat = path.lstat()
    assert path.is_file() and not path.is_symlink() and not (stat.st_file_attributes & 0x400), path
    assert stat.st_size <= maximum, path
    return load(path)

package = load(stage / 'rf1127-settlement-retry1-20261011/caption-runtime-package.json')
assert package['helperMetadataVersion'] == 3
exe, helper = Path(package['exe']), Path(package['helperExe'])
activation_helper = Path(package['activationExe'])
restore_package = load(stage / 'rf1127-settlement-retry1-20261011/restore-helper.json')
restore_helper = Path(restore_package['exe'])
sources = load(stage / 'rf1127-settlement-retry1-20261011/sources.json')
fixture_hashes = {str(p.relative_to(fixture)): sha(p) for p in fixture.rglob('*') if p.is_file()}

def verify_inputs():
    assert sha(restore_helper) == restore_package['sha256']
    assert sha(Path(restore_package['source'])) == restore_package['sourceSha256']
    assert sha(exe) == package['sha256'] and sha(helper) == package['helperSha256']
    assert sha(activation_helper) == package['activationSha256']
    assert sha(Path(package['activationSource'])) == package['activationSourceSha256']
    assert sha(Path(package.get('helperSource', str(stage / 'helper/src/bin/owned-window.rs')))) == package['helperSourceSha256']
    for name, digest in sources.items():
        assert sha(root / name) == digest, name
    for item in package['resources']:
        assert sha(Path(item['copy'])) == item['sha256']
        assert sha(Path(item['source'])) == item['sha256']
    assert fixture_hashes == {str(p.relative_to(fixture)): sha(p) for p in fixture.rglob('*') if p.is_file()}

verify_inputs()
capture_stage.mkdir(exist_ok=False)
save(capture_stage / 'input-proof.json', {'at': now(), 'runtime': package,
     'sourceManifestSha256': sha(stage / 'rf1127-settlement-retry1-20261011/sources.json'), 'fixture': str(fixture),
     'driverSha256': sha(Path(__file__)),
     'fixtureFiles': fixture_hashes, 'diagnosticOnly': True, 'applicationMaterialAccepted': False,
     'performanceMetrics': None, 'systemAppearanceModified': False, 'samplesRequested': 3})
env = os.environ.copy()
env.update({'TEMP': str(stage), 'TMP': str(stage)})
env['PATH'] = 'C:/Program Files/Git/usr/bin;' + env.get('PATH', '')
env.pop('PDFIUM_LIBRARY_PATH', None)
command = ['node', 'scripts/native-perf-auth-attribution.mjs', '--exe', str(exe),
           '--fixture', str(fixture), '--output', str(output), '--samples', '3']
results = []
began = time.monotonic()

with (capture_stage / 'actual100.stdout.log').open('xb') as stdout, (capture_stage / 'actual100.stderr.log').open('xb') as stderr:
    process = subprocess.Popen(command, cwd=root / 'tauri', env=env, stdout=stdout, stderr=stderr)
    save(capture_stage / 'actual100.live.json', {'at': now(), 'pid': process.pid, 'command': command})
    print('Three-sample surface capture driver live PID ' + str(process.pid), flush=True)

    def wait_file(path, deadline):
        while not path.exists():
            if process.poll() is not None:
                raise RuntimeError('Journey driver exited before ' + path.name)
            if time.monotonic() > deadline:
                raise TimeoutError('Waiting for ' + path.name)
            time.sleep(.01)
        return path

    def watch():
        for index in range(1, 4):
            sample = output / ('sample-' + str(index).zfill(3))
            result = {'index': index, 'root': str(sample), 'success': False,
                      'diagnosticOnly': True, 'performanceMetrics': None}
            results.append(result)
            try:
                deadline = time.monotonic() + 450
                consumed = ordinary(wait_file(sample / 'native-perf-consumed.json', deadline), 262144)
                owned = ordinary(sample / 'native-perf-owned.json', 262144)
                bound = ordinary(wait_file(sample / 'native-perf-sdk-journey-bound.json', deadline), 262144)
                pid, run_id = consumed['pid'], owned['runId']
                assert type(pid) is int and pid > 0 and re.fullmatch('[0-9a-f]{32}', run_id)
                assert consumed['scope'] == 'windows-native-perf-consumed'
                assert bound['scope'] == 'windows-native-sdk-ui-bound'
                assert consumed['runId'] == bound['runId'] == run_id and bound['pid'] == pid
                assert Path(consumed['root']).samefile(sample), 'Consumed root is a different filesystem directory'
                assert Path(bound['root']).samefile(sample), 'Bound root is a different filesystem directory'
                # CIM reads only this consumed, bound application's identity, with no visible console.
                query = f"$taskProcess=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}' -Property ProcessId,CreationDate,ExecutablePath; if($null -eq $taskProcess -or $null -eq $taskProcess.CreationDate -or [string]::IsNullOrEmpty($taskProcess.ExecutablePath)){{throw 'Incomplete owned process identity'}}; [ordered]@{{pid=[int]$taskProcess.ProcessId;creationMs=([DateTimeOffset]$taskProcess.CreationDate.ToUniversalTime()).ToUnixTimeMilliseconds();exe=[string]$taskProcess.ExecutablePath}} | ConvertTo-Json -Compress"
                identity = subprocess.run([str(pwsh), '-NoLogo', '-NoProfile', '-Command', query],
                                          capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW, timeout=25)
                for name, data in [('stdout', identity.stdout), ('stderr', identity.stderr)]:
                    with (sample / ('surface-identity.' + name + '.log')).open('xb') as log: log.write(data)
                assert identity.returncode == 0, 'Owned identity query failed'
                owner = json.loads(identity.stdout.decode('utf-8-sig'))
                assert owner['pid'] == pid and Path(owner['exe']).samefile(exe), 'Owned process image differs from frozen GUI'
                assert type(owner['creationMs']) is int and owner['creationMs'] > 0
                save(sample / 'surface-identity.json', owner)
                activation_args = [str(activation_helper), str(sample), str(pid), str(owner['creationMs']), str(exe), 'activate-owned']
                activation_began = time.monotonic()
                activated = subprocess.run(activation_args, cwd=stage, env=env, capture_output=True,
                                           creationflags=subprocess.CREATE_NO_WINDOW, timeout=25)
                for name, data in [('stdout', activated.stdout), ('stderr', activated.stderr)]:
                    with (sample / ('surface-activation.' + name + '.log')).open('xb') as log: log.write(data)
                save(sample / 'surface-activation.receipt.json', {'at': now(), 'command': activation_args,
                     'exitCode': activated.returncode, 'elapsedSeconds': time.monotonic() - activation_began})
                assert activated.returncode == 0, 'Owned native foreground activation refused'
                foreground = ordinary(sample / 'rf121-wgc-activate-owned.json', 262144)
                assert foreground == json.loads(activated.stdout.decode('utf-8-sig'))
                assert foreground['schemaVersion'] == 1 and foreground['scope'] == 'rf121-owned-window-foreground-with-caption'
                assert foreground['runId'] == run_id and foreground['pid'] == pid
                assert foreground['creationMs'] == owner['creationMs'] and foreground['tag'] == 'activate-owned'
                assert foreground['foregroundAfter'] is True
                assert foreground['heldProcessAndWindowIdentityVerifiedBeforeAndAfter'] is True
                assert foreground['pixelsRead'] == foreground['otherWindowsActivated'] == 0
                caption=foreground['captionActivation']; assert caption['error'] is None and caption['extraReleaseEventsSent']==0
                assert foreground['inputEventsSent']==caption['inputEventsSent'] in (0,2)
                if caption['attempted']: assert caption['nativeHitTest']==2 and caption['inputEventsSent']==2 and caption['cursorRestored'] and not caption['cursorMovedByUser']
                assert foreground['systemSettingsChanged'] is False and foreground['applicationMaterialAccepted'] is False
                request = {'schemaVersion': 1, 'scope': 'windows-native-surface-request',
                           'runId': run_id, 'pid': pid, 'browserPid': bound['browserPid'], 'token': uuid.uuid4().hex}
                if dark:
                    atomic_new(sample / 'native-perf-surface-appearance-request.json', dict(request, scope='windows-native-appearance-scene-request', scene=mode))
                elif collapsed:
                    atomic_new(sample / 'native-perf-surface-scene-request.json', dict(request, scope='windows-native-sidebar-scene-request', scene='light-collapsed'))
                atomic_new(sample / 'native-perf-surface-request.json', request)
                before_path = wait_file(sample / 'native-perf-surface-before.json', deadline)
                before = ordinary(before_path, 262144)
                assert before['request'] == request and before['scope'] == 'windows-native-surface-before'
                state = before['state']
                assert state['theme'] == ('dark' if dark else 'light') and state['platform'] == 'windows'
                assert state['expanded'] is (not collapsed)
                tag = state['theme'] + '-visible'
                args = [str(helper), str(sample), str(pid), str(owner['creationMs']), str(exe), tag]
                restore_args = [str(restore_helper),str(sample),str(pid),str(owner['creationMs']),str(exe),'minimize-restore-owned']
                restore_began = time.monotonic()
                lifecycle = subprocess.run(restore_args,cwd=stage,env=env,capture_output=True,
                                           creationflags=subprocess.CREATE_NO_WINDOW,timeout=6)
                for name,data in [('stdout',lifecycle.stdout),('stderr',lifecycle.stderr)]:
                    with (sample / ('surface-minimize-restore.'+name+'.log')).open('xb') as log:log.write(data)
                save(sample / 'surface-minimize-restore.receipt.json',{'command':restore_args,'exitCode':lifecycle.returncode,
                    'elapsedSeconds':time.monotonic()-restore_began,'originalSurfaceBudgetUnchanged':True})
                assert lifecycle.returncode == 0,lifecycle.stderr.decode('utf-8',errors='replace')
                restore_proof = ordinary(sample / 'rf121-wgc-minimize-restore-owned.json',262144)
                assert restore_proof == json.loads(lifecycle.stdout.decode('utf-8-sig'))
                assert restore_proof['schemaVersion']==1 and restore_proof['scope']=='rf121-owned-window-minimize-restore'
                assert restore_proof['runId']==run_id and restore_proof['pid']==pid and restore_proof['creationMs']==owner['creationMs']
                assert restore_proof['hwnd']==foreground['hwnd'] and restore_proof['tag']=='minimize-restore-owned'
                assert restore_proof['minimizedObserved'] and restore_proof['minimizeError'] is None
                assert restore_proof['restoredVisibleNormalForeground'] and restore_proof['heldProcessAndWindowIdentityVerifiedBeforeAndAfter']
                assert restore_proof['geometryAndDpiPreserved'] and restore_proof['stylesPreserved'] and restore_proof['backdropPreserved']
                assert restore_proof['before']==restore_proof['after']
                assert restore_proof['before']['systemBackdrop']['ok'] and restore_proof['before']['systemBackdrop']['value']==(2 if state['material']=='mica' else 1)
                assert restore_proof['pixelsRead']==restore_proof['otherWindowsModified']==0
                caption=restore_proof['captionActivation']; assert caption['error'] is None
                assert restore_proof['inputEventsSent']==caption['inputEventsSent'] in (0,2)
                assert caption['extraReleaseEventsSent']==0
                if caption['attempted']: assert caption['nativeHitTest']==2 and caption['inputEventsSent']==2 and caption['cursorRestored'] and not caption['cursorMovedByUser']

                assert restore_proof['systemSettingsChanged'] is False and restore_proof['fullMaterialMatrixAccepted'] is False
                capture_began = time.monotonic()
                captured = subprocess.run(args, cwd=stage, env=env, capture_output=True,
                                          creationflags=subprocess.CREATE_NO_WINDOW, timeout=25)
                for name, data in [('stdout', captured.stdout), ('stderr', captured.stderr)]:
                    with (sample / ('surface-capture.' + name + '.log')).open('xb') as log: log.write(data)
                receipt = {'at': now(), 'command': args, 'exitCode': captured.returncode,
                           'elapsedSeconds': time.monotonic() - capture_began, 'tagFromActualDomTheme': True}
                save(sample / 'surface-capture.receipt.json', receipt)
                assert captured.returncode == 0, captured.stderr.decode('utf-8', errors='replace')
                proof = ordinary(sample / ('rf121-wgc-' + tag + '.json'), 262144)
                assert proof == json.loads(captured.stdout.decode('utf-8-sig'))
                assert proof['scope'] == 'rf121-owned-window-wgc-frame'
                assert proof['hwnd'] == foreground['hwnd']
                assert proof['schemaVersion'] == package.get('helperMetadataVersion', 1)
                assert proof['nativeAppearanceVerified'] is False
                assert proof['dwmAppearanceReadback'] == 'documented-system-backdrop-only'
                assert proof['dwmDarkMode'] is None and proof['dwmCaptionColor'] is None
                readback = proof['dwmSystemBackdropReadback']
                assert set(readback) == {'attribute', 'before', 'after', 'stable'}
                assert type(readback['attribute']) is int and readback['attribute'] == 38
                assert readback['stable'] is True and readback['before'] == readback['after']
                expected_backdrop = 2 if state['material'] == 'mica' else 1
                for observed in [readback['before'], readback['after']]:
                    assert set(observed) == {'ok', 'value', 'errorHresult'}
                    assert observed['ok'] is True and observed['errorHresult'] is None
                    assert type(observed['value']) is int and observed['value'] == expected_backdrop
                assert type(proof['dwmSystemBackdropType']) is int
                assert proof['dwmSystemBackdropType'] == expected_backdrop
                assert proof['foregroundBefore'] is state['focused']
                assert proof['foregroundAfter'] is state['focused']
                assert proof['runId'] == run_id and proof['pid'] == pid and proof['creationMs'] == owner['creationMs']
                assert proof['otherWindowsCaptured'] == 0 and proof['applicationMaterialAccepted'] is False
                pixels = sample / ('rf121-wgc-' + tag + '.bgra')
                assert pixels.stat().st_size == proof['bytes'] == proof['width'] * proof['height'] * 4
                ack = dict(request, scope='windows-native-surface-done', beforeSha256=sha(before_path), pixelSha256=sha(pixels))
                atomic_new(sample / 'native-perf-surface-done.json', ack)
                after = ordinary(wait_file(sample / 'native-perf-surface-after.json', deadline), 262144)
                assert after['scope'] == 'windows-native-surface-after' and after['request'] == request
                assert after['binding'] == before['binding'] == bound['binding']
                assert after['beforeSha256'] == ack['beforeSha256'] and after['pixelSha256'] == ack['pixelSha256']
                assert after['stable'] is True and after['applicationMaterialAccepted'] is False
                assert after['performanceMetrics'] is None
                a, b = dict(before['state']), dict(after['state'])
                ta, tb = a.pop('atMs'), b.pop('atMs')
                assert all(type(v) in [int, float] and math.isfinite(v) for v in [ta, tb]) and tb >= ta
                assert a == b and a['timeOriginMs'] == bound['timeOriginMs']
                if dark:
                    prepared = ordinary(wait_file(sample / 'native-perf-surface-appearance-prepared.json', deadline), 4194304)
                    restored = ordinary(wait_file(sample / 'native-perf-surface-appearance-restored.json', deadline), 4194304)
                    complete = ordinary(wait_file(sample / 'native-perf-surface-appearance-result.json', deadline), 262144)
                    assert complete['success'] and complete['captureError'] is None and complete['restoreError'] is None
                    assert restored['steps'][-1]['expanded'] and restored['steps'][-1]['theme'] == 'light'
                    assert restored['steps'][-1]['href'] == 'http://tauri.localhost/'
                    assert restored['preferenceVerified'] and restored['originalPreference'] == prepared['originalPreference']
                    assert 0 <= complete['callsBefore'] < complete['callsAfter'] <= 128
                elif collapsed:
                    restored = ordinary(wait_file(sample / 'native-perf-surface-scene-restored.json', deadline), 262144)
                    complete = ordinary(wait_file(sample / 'native-perf-surface-scene-result.json', deadline), 262144)
                    assert complete['success'] and complete['captureError'] is None and complete['restoreError'] is None
                    assert restored['restored']['expanded'] and restored['restored']['theme'] == 'light'
                result.update({'success': True, 'runId': run_id, 'pid': pid, 'theme': state['theme'],
                               'beforeSha256': ack['beforeSha256'], 'pixelSha256': ack['pixelSha256'],
                               'nativeDwmThemeMatchesDom': None,
                               'nativeAppearancePropertiesVerified': False, 'nativeSystemBackdropVerified': True,
                               'foreground': proof['foregroundBefore'], 'ownedWindowDpi': proof['ownedWindowDpi']})
                print('Sample ' + str(index) + ' captured with stable actual ' + state['theme'] + ' theme', flush=True)
            except Exception as error:
                result.update({'errorCategory': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc(), 'errno': getattr(error, 'errno', None), 'winerror': getattr(error, 'winerror', None)})
                # Do not terminate foreign processes or restart an in-flight original journey.
                print('Sample ' + str(index) + ' capture failed: ' + str(error), flush=True)
            finally:
                save(capture_stage / ('surface-sample-' + str(index).zfill(3) + '.json'), result)

    watcher = threading.Thread(target=watch)
    watcher.start()
    code = process.wait()
    watcher.join()

verify_inputs()
save(capture_stage / 'actual100.receipt.json', {'at': now(), 'command': command, 'pid': process.pid,
     'exitCode': code, 'elapsedSeconds': time.monotonic() - began, 'sourceUnchanged': True,
     'resourcesUnchanged': True, 'originalFixtureUnchanged': True, 'pdfiumOverrideInherited': False})
accepted = code == 0 and len(results) == 3 and all(item['success'] for item in results)
save(capture_stage / 'capture-results.json', {'schemaVersion': 1, 'scope': 'rf121-three-owned-surface-bindings',
     'success': accepted, 'samples': results, 'diagnosticOnly': True,
     'applicationMaterialAccepted': False, 'performanceMetrics': None})
print('Journey exit ' + str(code) + '; all three state/capture bindings accepted: ' + str(accepted), flush=True)
raise SystemExit(0 if accepted else 1)
