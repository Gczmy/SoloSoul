from pathlib import Path
import json,hashlib,tarfile,io,shutil,os
R=Path('D:/SoloSoul');W=Path(__file__).parent.resolve();S=W/'rf1127-settlement-retry1-20261011'
NAME='rf1127-native-settlement-2026-10-11';OUT=R/'docs/verification'/NAME
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
assert not OUT.exists()
queue=load(S/'cohorts-complete.json');assert queue['accepted'] and len(queue['rows'])==4
cleanup=load(W/'rf1127-cache-cleanup.json');assert len(cleanup['removedCachePaths'])==192 and cleanup['preservedBytesVerified']
assert cleanup['matchingOwnedIdentitiesLive']==cleanup['processesTerminatedByThisTool']==0
assert all(not os.path.lexists(p) for p in cleanup['removedCachePaths'])
OUT.mkdir();visual=[];groups=[];intervals=[]
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
 g=W/('ss-rf121-composed-window-restore-'+mode+'-settled-retry1-20261011')
 v=load(g/'validation.json');assert v['accepted'] and len(v['samples'])==3
 assert v['fullMatrixAccepted']==False and v['performanceMetrics'] is None
 intervals+=v['preferenceIntervals'];groups.append({'scene':mode,'samples':3,'captureExitCode':0,'readerExitCode':0,'rendererExitCode':0,'verificationSha256':sha((g/'validation.json').read_bytes())})
 p=g/'surface-sample-001.png';shutil.copyfile(p,OUT/(mode+'.png'))
 visual.append({'scene':mode,'source':str(p),'sha256':sha(p.read_bytes()),'humanReviewed':True,'scope':'one actual restored endpoint per group; no transient-flash or complete material claim'})
assert len(intervals)==12
put(S/'visual-review.json',{'frames':visual,'humanReviewedFrames':4,'remainingEightFramesHumanReviewed':False,'fullMaterialAccepted':False})
members={};allowed={'.json','.log','.bgra','.png','.py','.mjs','.ps1'}
def add(p,n=None):
 assert p.is_file() and not(p.stat().st_file_attributes&0x400)
 assert p.suffix in allowed
 name=n or p.relative_to(W).as_posix();assert name not in members;members[name]=p
def files(d):
 assert d.is_dir() and not(d.stat().st_file_attributes&0x400)
 for p in d.iterdir():
  if p.is_file() and p.suffix in allowed:add(p)
files(S);files(W/'rf1127-settlement-20261011')
for label,mode,suffix in [(round+'-'+mode,mode,suffix) for round,suffix in [('initial','settled-20261011'),('retry1','settled-retry1-20261011')] for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']]:
 g=W/('ss-rf121-composed-window-restore-'+mode+'-'+suffix);files(g);files(g/'actual100')
 for i in range(1,4):
  files(g/'actual100'/f'sample-{i:03}')
  files(W/'application-logs-rf1127-settled'/label/'100'/f'sample-{i:03}')
for p in W.iterdir():
 if p.is_file() and p.suffix in allowed and 'rf1127' in p.name:add(p)
for n in ['native-perf-preference-contract.mjs','native-perf-preference.node.test.mjs','native-perf-run.mjs','native-perf-sdk-journey.mjs','native-perf-auth-contract.mjs','native-perf-maintenance-contract.mjs']:
 add(R/'tauri/scripts'/n,'repository/tauri/scripts/'+n)
add(W/'window-restore-contract.mjs')
for n in ['index.json']:
 add(R/'docs/verification/rf1127-preference-settlement-2026-10-11'/n,'prior-implementation/'+n)
for n in ['sources.json','runtime-package.json']:
 add(W/'rf1123-native-build-20261011'/n)
rows=[]
with tarfile.open(OUT/'raw.tar.gz','w:gz',compresslevel=6) as tar:
 for n,p in sorted(members.items()):
  d=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(d);i.mode=0o644;tar.addfile(i,io.BytesIO(d));rows.append({'member':n,'source':str(p),'bytes':len(d),'sha256':sha(d)})
with tarfile.open(OUT/'raw.tar.gz') as tar:
 assert len(tar.getmembers())==len(rows)
 for x in rows:
  d=tar.extractfile(x['member']).read();assert len(d)==x['bytes'] and sha(d)==x['sha256']
put(OUT/'index.json',{'task':'RF-1127','members':rows,'allMembersReadbackVerified':True,'fullRF121Accepted':False,'excluded':['physical Vault','EXE/DLL/models','profile/WebView/cache trees']})
shutil.copyfile(W/'rf1127-cache-cleanup.json',OUT/'cleanup.json')
(OUT/'.gitattributes').write_text('raw.tar.gz -text\n*.png -text\n',encoding='utf-8')
put(R/'docs/verification'/(NAME+'.json'),{'task':'RF-1127','accepted':True,'scope':'target-theme-and-later-background-completion-contract-with-12-native-window-restorations',
 'sourceHead':'d6b470cfe','implementationCommit':'d6b470cfe','productionApplicationChanged':False,'guiRebuilt':False,
 'guiSha256':'d77e575287c7d18f6124a7aa42cfa56f0ba20625d8b00309c1e7d2c07355da74','sourceFiles':1837,'resourceFiles':94,'groups':groups,
 'nativeJourneysPassed':12,'nativeWindowCapturesPassed':12,'preferenceIntervals':intervals,
 'intervalsWithTwoTransportAttempts':sum(x['transportAttempts']==2 for x in intervals),
 'intervalsOriginallyNotAllCompleted':sum(not x['backend']['interval']['allCompleted'] for x in intervals),
 'strictOriginalContractUnchanged':True,'originalRunningSnapshotsPreserved':True,'priorFailedGroupsRetained':True,
 'visualReview':visual,'remainingEightFramesHumanReviewed':False,'dpi':96,'nativeSystemBackdropGetter38':2,
 'initialMatrixAccepted':False,'initialFailure':'dark-collapsed sample001: PermissionError reading consumed marker; later file readable; unique cause unproven',
 'fullFourGroupsRepeated':True,'initialSuccessfulSubsetUsedForFinalAcceptance':False,'failureReadRetriesIntroduced':False,
 'cleanup':{'pathsRemoved':192,'identitiesChecked':cleanup['identitiesChecked'],'processesTerminated':0,'preservedBytesVerified':True},
 'userApplicationControlled':False,'fullRF121Accepted':False,'performanceAccepted':False,'otherPlatformsAccepted':False,
 'archive':{'path':NAME+'/raw.tar.gz','members':len(rows),'bytes':(OUT/'raw.tar.gz').stat().st_size,'sha256':sha((OUT/'raw.tar.gz').read_bytes()),'allMembersReadbackVerified':True},
 'ledgerClosed':False,'commitCreated':False})
print(json.dumps({'members':len(rows),'nativePassed':12,'preferenceIntervals':12,'fullRF121Accepted':False}))
