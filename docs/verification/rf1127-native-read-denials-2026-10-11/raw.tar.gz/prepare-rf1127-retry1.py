from pathlib import Path
import json,hashlib,shutil
W=Path(__file__).parent.resolve();old=W/'rf1127-settlement-20261011';S=W/'rf1127-settlement-retry1-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert load(old/'cohorts-complete.json')['accepted']==False
assert not S.exists();S.mkdir()
for n in ['sources.json','caption-runtime-package.json','restore-helper.json','windows-build-reuse-proof.json']:
 shutil.copyfile(old/n,S/n)
tools={}
for source,target in [('run-rf1127-settled.py','run-rf1127-retry1.py'),('verify-rf1127-settled.mjs','verify-rf1127-retry1.mjs'),('render-rf1127-settled.py','render-rf1127-retry1.py'),('run-rf1127-cohorts.py','run-rf1127-cohorts-retry1.py')]:
 text=(W/source).read_text(encoding='utf-8')
 text=text.replace('rf1127-settlement-20261011','rf1127-settlement-retry1-20261011').replace('-settled-20261011','-settled-retry1-20261011')
 for a,b in [('run-rf1127-settled.py','run-rf1127-retry1.py'),('verify-rf1127-settled.mjs','verify-rf1127-retry1.mjs'),('render-rf1127-settled.py','render-rf1127-retry1.py')]:text=text.replace(a,b)
 if source=='run-rf1127-settled.py':
  needle="'traceback': traceback.format_exc()"
  assert needle in text
  text=text.replace(needle,"'traceback': traceback.format_exc(), 'errno': getattr(error, 'errno', None), 'winerror': getattr(error, 'winerror', None)")
 if source=='run-rf1127-cohorts.py':
  text=text.replace('rf1127-session-preflight.py','rf1127-session-preflight-retry1.py').replace("'rf1127-session-'+mode+'.py'","'rf1127-session-retry1-'+mode+'.py'")
 p=W/target;p.write_text(text,encoding='utf-8');tools[str(p.relative_to(W.parent.parent))]=sha(p)
p=W/'rf1127-session-preflight-retry1.py'
p.write_text((W/'rf1127-session-preflight.py').read_text(encoding='utf-8').replace('rf1127-settlement-20261011','rf1127-settlement-retry1-20261011'),encoding='utf-8')
for p in [p,W/'window-restore-contract.mjs',Path(__file__)]:tools[str(p.relative_to(W.parent.parent))]=sha(p)
(S/'tools.json').write_text(json.dumps(tools,indent=2)+'\n',encoding='utf-8')
(S/'retry-provenance.json').write_text(json.dumps({'originalMatrixAccepted':False,'originalMatrixSha256':sha(old/'cohorts-complete.json'),'fullFourGroupsRerun':True,'applicationAndFixtureUnchanged':True,'readerAcceptanceUnchanged':True,'captureBudgetsUnchanged':True,'onlyExtraFailureDiagnostics':['errno','winerror'],'noFailedSampleReclassified':True},indent=2)+'\n',encoding='utf-8')
print('Fresh complete four-group matrix prepared; old failure preserved; no retry-on-read or budget change')
