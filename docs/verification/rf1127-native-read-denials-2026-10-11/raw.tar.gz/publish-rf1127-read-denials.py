from pathlib import Path
import json,hashlib,tarfile,io,shutil,os
R=Path('D:/SoloSoul');W=Path(__file__).parent.resolve();N='rf1127-native-read-denials-2026-10-11';O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
assert not O.exists();c=load(W/'rf1127-cache-cleanup.json');assert c['matchingOwnedIdentitiesLive']==c['processesTerminatedByThisTool']==0
assert len(c['removedCachePaths'])==192 and c['preservedBytesVerified'] and all(not os.path.lexists(p) for p in c['removedCachePaths'])
O.mkdir();members={};allowed={'.json','.log','.py','.mjs','.ps1','.png','.bgra'}
def add(p,n=None):
 assert p.is_file() and not(p.stat().st_file_attributes&0x400) and p.suffix in allowed
 n=n or p.relative_to(W).as_posix();assert n not in members;members[n]=p
def files(d):
 assert d.is_dir() and not(d.stat().st_file_attributes&0x400)
 for p in d.iterdir():
  if p.is_file() and p.suffix in allowed:add(p)
groups=[];captures=0;denials=[]
for round,suffix,stage in [('initial','settled-20261011','rf1127-settlement-20261011'),('retry1','settled-retry1-20261011','rf1127-settlement-retry1-20261011')]:
 assert not load(W/stage/'cohorts-complete.json')['accepted'];files(W/stage)
 for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
  g=W/('ss-rf121-composed-window-restore-'+mode+'-'+suffix);files(g);files(g/'actual100')
  assert load(g/'actual100.receipt.json')['exitCode']==0
  result=load(g/'capture-results.json');captures+=sum(x['success'] for x in result['samples'])
  for x in result['samples']:
   if not x['success']:denials.append({'round':round,'scene':mode,'sample':x['index'],'category':x['errorCategory'],'errno':x.get('errno'),'winerror':x.get('winerror'),'error':x['error']})
  groups.append({'round':round,'scene':mode,'defaultJourneysPassed':3,'captureGroupAccepted':result['success'],'primaryReaderAccepted':(g/'validation.json').is_file()})
  for i in range(1,4):
   files(g/'actual100'/f'sample-{i:03}');files(W/'application-logs-rf1127-settled'/(round+'-'+mode)/'100'/f'sample-{i:03}')
visual=[]
for mode in ['baseline','light-collapsed','dark-expanded']:
 p=W/('ss-rf121-composed-window-restore-'+mode+'-settled-retry1-20261011')/'surface-sample-001.png'
 shutil.copyfile(p,O/(mode+'.png'));visual.append({'source':str(p),'sha256':sha(p.read_bytes()),'humanReviewed':True,'scope':'one actual restored endpoint from retry1; whole matrix remains failed'})
put(W/'rf1127-settlement-retry1-20261011/visual-review-read-denials.json',{'finalRoundFramesReviewed':visual,'otherFramesNotClaimedHumanReviewed':True,'darkCollapsedRenderedAndReviewed':False})
add(W/'rf1127-settlement-retry1-20261011/visual-review-read-denials.json')
for p in W.iterdir():
 if p.is_file() and p.suffix in allowed and 'rf1127' in p.name:add(p)
for n in ['native-perf-preference-contract.mjs','native-perf-preference.node.test.mjs','native-perf-run.mjs','native-perf-sdk-journey.mjs','native-perf-auth-contract.mjs','native-perf-maintenance-contract.mjs']:
 add(R/'tauri/scripts'/n,'repository/tauri/scripts/'+n)
add(W/'window-restore-contract.mjs');add(W/'probe-rf1128-sharing.py');add(R/'build/rf1128-owned-json-sharing-20261011/probe.json','rf1128-isolated-probe/probe.json')
for n in ['sources.json','runtime-package.json']:add(W/'rf1123-native-build-20261011'/n)
rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as t:
 for n,p in sorted(members.items()):
  d=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(d);i.mode=0o644;t.addfile(i,io.BytesIO(d));rows.append({'member':n,'source':str(p),'bytes':len(d),'sha256':sha(d)})
with tarfile.open(O/'raw.tar.gz') as t:
 assert len(t.getmembers())==len(rows)
 for x in rows:
  b=t.extractfile(x['member']).read();assert len(b)==x['bytes'] and sha(b)==x['sha256']
put(O/'index.json',{'task':'RF-1127','members':rows,'allMembersReadbackVerified':True,'accepted':False,'excluded':['physicalVault','EXE/DLL/models','cache trees'],
 'plannedPositiveToolsNotExecuted':['publish-rf1127-native.py','update-rf1127-completion-ledger.py']})
shutil.copyfile(W/'rf1127-cache-cleanup.json',O/'cleanup.json');(O/'.gitattributes').write_text('raw.tar.gz -text\n*.png -text\n',encoding='utf-8')
assert len(denials)==2 and captures==22
put(R/'docs/verification'/(N+'.json'),{'task':'RF-1127','accepted':False,'status':'two-full-matrices-rejected-by-consumed-marker-read-permissions',
 'sourceHead':'d6b470cfe','productionApplicationChanged':False,'guiRecompiled':False,'sourceFiles':1837,'resourceFiles':94,
 'defaultNativeJourneysPassed':24,'successfulCaptureSamples':22,'completeSurfaceGroupsPassed':6,'samplesInThoseCompleteGroups':18,
 'groups':groups,'denials':denials,'failedSamplesReclassified':False,'failedMatricesRemainRejected':True,'successfulSubsetUsedToAcceptMatrix':False,
 'readRetriesIntroduced':False,'budgetsChanged':False,'originalMarkerLaterReadable':True,'uniqueCauseOfOriginalErrorsProven':False,
 'isolatedSharingProbe':load(R/'build/rf1128-owned-json-sharing-20261011/probe.json'),'nextTask':'RF-1128',
 'visualReview':visual,'fullRF121Accepted':False,'performanceAccepted':False,'cleanup':{'pathsRemoved':192,'identitiesChecked':c['identitiesChecked'],'linksUnlinked':len(c['linksUnlinked']),'preservedFiles':len(c['preservedVaultAndRootFiles']),'processesTerminated':0,'preservedBytesVerified':True},
 'archive':{'path':N+'/raw.tar.gz','members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha((O/'raw.tar.gz').read_bytes()),'allMembersReadbackVerified':True},
 'ledgerClosed':False,'commitCreated':False})
print(json.dumps({'members':len(rows),'accepted':False,'nativeDefaultPassed':24,'surfaceCaptured':22,'denials':2}))
