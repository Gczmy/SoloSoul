from pathlib import Path
import json,re
R=Path('D:/SoloSoul');name='rf1127-native-settlement-2026-10-11'
v=json.loads((R/'docs/verification'/(name+'.json')).read_text(encoding='utf-8'))
assert v['accepted'] and v['nativeJourneysPassed']==12 and v['cleanup']['pathsRemoved']==192
members=v['archive']['members']
p=R/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=p.read_text(encoding='utf-8')
old='待验证/阻塞：5（RF-112、RF-121、RF-312、RF-1109、RF-1127）；暂缓：0；进行中：0；待执行：6。'
assert old in s
s=s.replace(old,'待验证/阻塞：4（RF-112、RF-121、RF-312、RF-1109）；暂缓：0；进行中：0；待执行：6。',1)
s=s.replace('已关闭：**306 / 317**；实际修复（已关闭）：306','已关闭：**307 / 317**；实际修复（已关闭）：307',1)
s=re.sub(r'^> 最后更新：.*$', '> 最后更新：2026-10-11（RF-1127原生后续完成合同四组完整复跑通过；307/317关闭）',s,count=1,flags=re.M)
s=re.sub(r'^- 当前处理：.*$', '- 当前处理：RF-1127代码提交后，新的四组各3次完整原生行程及恢复/偏好/窗口像素独立核验通过，原失败与192个精确缓存清理均归档。下一步继续RF-121 Windows缩放、辅助功能和长内容原生矩阵；macOS及API35首页WebGL仍缺必需环境，RF-122～127前置未解除。',s,count=1,flags=re.M)
s=s.replace('| [RF-1123](#rf-1123) | [!] 待原生验证 |','| [RF-1123](#rf-1123) | [x] 完成 |',1)
s+='''

### RF-1127 当前原生矩阵补验（2026-10-11，完成）

- 用户重新连接后，会话1实际Active且输入桌面可用，goal恢复active。使用d6b470cfe合同与同一冻结GUI，1837来源、94资源及公开100对象夹具逐字核验；只改外部Node合同/测试，应用未重编译，原严格合同及业务路径不变，不重复已通过且未受影响的Node/Rust/前端检查。
- 首轮浅色展开/折叠、深色展开三个完整分组各3次通过。深色折叠sample001在首次读consumed标记时PermissionError，sample002/003采集成功，整组及首轮矩阵仍失败。原12次默认行程均exit0，不能把默认流程通过当成该外观组通过；第一次采集未保留winerror，之后标记可读而不足以确定唯一根因。
- 在新目录重跑完整四组各3次，没有拼接首轮成功子集、覆盖旧失败、增加文件读取重试或放宽原预算；只追加失败errno/winerror诊断。最终12次完整原生行程、独立读者和渲染全部exit0，主题/原Light偏好与展开状态恢复、同文档/前台/HWND/几何/96 DPI/getter38值2及WGC像素/前后SHA绑定完成。6份深色行程的12个主题区间用新有限合同独立核验：主题恰1且原检查点已完成，原传输与原后端增量一致，后续完整ID前缀不可变及原区间全部请求完成；后来新增写入不补齐原计数。首轮实际两份区间transport2中theme1+backup-reminder1已证明分类有效；早期running在前轮历史合同证据核验，原件和原严格拒绝保持。
- 实际查看最终四组各sample001，共4张PNG：首页文案、卡片和导航可见，恢复后端点未空白。其余8帧按独立状态/原像素绑定，未称人工逐图查看。没有证明过渡无闪烁、其他DPI、长内容、辅助功能或完整材质，RF-121及性能、多端前置保持。
- 两轮共8个terminal分组的精确身份与自有冻结EXE/helper重新核对退出后，清理192个精确缓存，原件/Vault及24份日志逐字保留；未终止进程，用户原应用未控制。原失败组保持拒绝，仅最终完整重跑矩阵作本项关闭依据。
'''+f'- [结构化验收](verification/{name}.json)、[{members}份原件索引](verification/{name}/index.json)和[清理回执](verification/{name}/cleanup.json)全部归档成员长度/SHA回读通过，包含两轮全部原件、当前合同/独立读者/源冻结、失败诊断和精确清理，排除实体Vault、二进制、模型和缓存。归档时ledgerClosed/commitCreated=false为时点事实，后续台账及提交回读另验。代码提交d6b470cfe，本阶段本地独立证据提交、不推送。307/317关闭，4待验证、6待执行；goal active，下一步Windows缩放/辅助功能矩阵可继续，不关闭RF-121/312或放行RF-122～127。\n'
p.write_text(s,encoding='utf-8')
for doc in ['docs/performance/RF-121-preference-write-attribution.md','docs/verification/RF-121-windows-theme-binding.md']:
 q=R/doc
 with q.open('a',encoding='utf-8') as f:
  f.write(f'\n\n2026-10-11 RF-1127原生补验完成：同一GUI在新目录完整重跑浅/深色、展开/折叠四组各3次，目标区间分类与后续完成、窗口恢复及实际像素全部独立通过。首轮深色折叠的consumed读取PermissionError、整组失败和其成功子集均保留，未用于最终矩阵；没有增加读取重试或放宽预算。两轮192个精确缓存已清理，未终止进程。仅人工查看最终四组首帧，共4张；完整RF-121材质、缩放、辅助功能及性能仍未验收。见[新原生记录]({"../verification/" if "/performance/" in doc else ""}{name}.json)及[原件索引]({"../verification/" if "/performance/" in doc else ""}{name}/index.json)。\n')
print('RF-1127 complete;307/317 closed; RF-121 matrix remains pending')
