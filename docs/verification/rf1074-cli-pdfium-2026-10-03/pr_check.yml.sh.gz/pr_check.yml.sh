bash scripts/download-pdfium.sh
test -s src-tauri/resources/pdfium/libpdfium.so
echo "PDFIUM_LIBRARY_PATH=$PWD/src-tauri/resources/pdfium/libpdfium.so" >> "$GITHUB_ENV"
