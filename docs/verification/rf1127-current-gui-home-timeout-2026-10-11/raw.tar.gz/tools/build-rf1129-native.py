from pathlib import Path
import hashlib,json,os,shutil,struct,subprocess,time,tomllib
R=Path('D:/SoloSoul');W=Path(__file__).parent; checks=W/'rf1129-transition-diagnostics-20261011';S=W/'rf1129-native-build-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert load(checks/'checks-complete.json')['success'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()
sources=load(checks/'sources.json');assert all(sha(R/n)==h for n,h in sources.items())
S.mkdir(exist_ok=False)
def save(n,v):
 with (S/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
save('sources.json',sources);save('starting-state.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'sourceCount':len(sources),'scope':'build current diagnostic-only native-perf GUI; no runtime acceptance'})
cache=R/'build/rf312-maintenance-20261009';env=os.environ.copy();env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),CARGO_HOME=str(cache/'cargo-home'),CARGO_TARGET_DIR=str(cache/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(cache/'ort-cache'),npm_config_cache=str(cache/'npm-cache'),PYTHONDONTWRITEBYTECODE='1')
env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','')
for n in ['PDFIUM_LIBRARY_PATH','TAURI_CONFIG','TAURI_ANDROID_PROJECT_PATH','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS']:env.pop(n,None)
manifest=R/'tauri/src-tauri/Cargo.toml';original=manifest.read_bytes();(S/'Cargo.before.toml').write_bytes(original)
configuration=load(R/'tauri/src-tauri/tauri.native-perf.conf.json')
configuration['build']['beforeBuildCommand']+=' && C:/Python314/python.exe D:/SoloSoul/build/rf121-theme-binding-20261010/freeze-rf1129-dist.py'
save('native-build.conf.json',configuration)
command=['npm.cmd','run','tauri','--','build','--config',str(S/'native-build.conf.json'),'--features','native-perf','--no-bundle','--ci']
began=time.monotonic()
with (S/'build.stdout.log').open('xb') as out,(S/'build.stderr.log').open('xb') as err:
 child=subprocess.Popen(command,cwd=R/'tauri',env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
 save('build.live.json',{'pid':child.pid,'command':command});print('Current native build live PID',child.pid,flush=True);code=child.wait()
changed=[n for n,h in sources.items() if sha(R/n)!=h];after=manifest.read_bytes();(S/'Cargo.after.toml').write_bytes(after)
save('build.receipt.json',{'command':command,'pid':child.pid,'exitCode':code,'elapsedSeconds':time.monotonic()-began,'sourceUnchanged':not changed,'changedSources':changed})
if changed:
 assert changed==['tauri/src-tauri/Cargo.toml'] and original.replace(b'\r\n',b'\n')==after.replace(b'\r\n',b'\n') and tomllib.loads(original.decode())==tomllib.loads(after.decode())
 save('manifest-newline-parity.json',{'normalizedBytesEqual':True,'parsedTomlEqual':True,'action':'restore original newline bytes only; original build receipt retained'});manifest.write_bytes(original)
assert code==0 and all(sha(R/n)==h for n,h in sources.items())
dist=load(S/'dist-build-inputs.json');root=R/'tauri/dist'
assert {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}=={row['path'] for row in dist['files']}
for row in dist['files']:
 path=root/row['path'];assert not(path.stat().st_file_attributes&0x400) and path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
save('dist-input-stability.json',{'allGeneratedFrontendInputsUnchangedDuringRustBuild':True,'files':len(dist['files']),'manifestSha256':sha(S/'dist-build-inputs.json')})
runtime=W/'ss-rf1129-diagnostic-runtime-20261011/bin';runtime.mkdir(parents=True,exist_ok=False);exe=runtime/'solo_soul.exe';shutil.copy2(cache/'cargo-target/release/solo_soul.exe',exe)
data=exe.read_bytes();offset=struct.unpack_from('<I',data,0x3c)[0];assert data[offset:offset+4]==b'PE\0\0' and struct.unpack_from('<H',data,offset+24+68)[0]==2
assert b'rejectedTransitions' in data and b'windows-native-appearance-result' in data
package=load(W/'rf1128-shared-reader-20261011/caption-runtime-package.json');oldExe=Path(package['exe']);assert sha(exe)!=package['sha256'];rows=[]
for item in package['resources']:
 source=Path(item['source']);copy=runtime/Path(item['copy']).relative_to(oldExe.parent)
 assert copy.resolve().is_relative_to(runtime.resolve()) and sha(source)==item['sha256']
 copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,copy);assert sha(copy)==item['sha256'];rows.append({'source':str(source),'copy':str(copy),'sha256':item['sha256']})
assert len(rows)==94
package.update(exe=str(exe),sha256=sha(exe),bytes=len(data),resources=rows,sourceManifestSha256=sha(S/'sources.json'),gitHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),currentNativeTests=137,guiExecuted=False,applicationMaterialAccepted=False)
save('runtime-package.json',package)
assert all(sha(R/n)==h for n,h in sources.items());print('Current diagnostic GUI frozen with94 resources; no runtime acceptance',flush=True)
