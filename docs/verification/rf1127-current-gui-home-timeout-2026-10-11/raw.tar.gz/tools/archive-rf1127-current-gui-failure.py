from pathlib import Path
import hashlib,io,json,tarfile
R=Path('D:/SoloSoul');W=Path(__file__).parent;B=W/'rf1129-native-build-20261011';S=W/'rf1129-native-matrix-20261011'
C=W/'ss-rf121-composed-window-restore-baseline-diagnostic-20261011'
N='rf1127-current-gui-home-timeout-2026-10-11';O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
assert not load(S/'cohorts-complete.json')['accepted']
journey=load(C/'actual100/native-perf-sdk-journey-results.json');assert len(journey['samples'])==3
assert [x['success'] for x in journey['samples']]==[False,True,True]
first=load(C/'actual100/sample-001/native-perf-sdk-journey.json')
assert first['failedStep']=='home' and first['reason']=='probe-timeout'
assert all(x['cleanupIntegrity']['complete'] for x in journey['samples'])
cleanup=load(W/'rf1129-native-cache-cleanup.json')
assert cleanup['preservedBytesVerified'] and cleanup['processesTerminatedByThisTool']==0
assert len(cleanup['removedCachePaths'])==24 and len(cleanup['linksUnlinked'])==3
sources=load(S/'sources.json');assert len(sources)==1839 and all(sha(R/n)==h for n,h in sources.items())
assert load(B/'build.receipt.json')['exitCode']==0
assert load(B/'manifest-newline-parity.json')['parsedTomlEqual']
assert load(B/'dist-input-stability.json')['allGeneratedFrontendInputsUnchangedDuringRustBuild']
assert not O.exists();O.mkdir();members={}
for label,root in [('build',B),('matrix',S)]:
    for p in root.iterdir():
        if p.is_file() and p.suffix in ['.json','.log','.toml']:members[label+'/'+p.name]=p
excluded={'vault','app-data','profile','webview','temp','models','plugins'}
for p in C.rglob('*'):
    rel=p.relative_to(C)
    if any(x in excluded for x in rel.parts):continue
    if p.is_file() and p.suffix in ['.json','.log','.bgra']:members['capture/'+rel.as_posix()]=p
for p in (W/'application-logs-rf1129-diagnostic').rglob('*'):
    if p.is_file():members['application-logs/'+p.relative_to(W/'application-logs-rf1129-diagnostic').as_posix()]=p
tools=['build-rf1129-native.py','freeze-rf1129-dist.py','prepare-rf1129-native-matrix.py',
       'run-rf1129-diagnostic.py','verify-rf1129-diagnostic.mjs','render-rf1129-diagnostic.py',
       'run-rf1129-cohorts.py','rf1129-session-preflight.py','rf1129-session-baseline.py',
       'prepare-rf1129-terminal-cleanup.py','rf1129-cleanup-owned.ps1',
       'archive-rf1127-current-gui-failure.py','window-restore-contract.mjs',
       'rf1129-native-cache-cleanup-plan.json','rf1129-native-cache-cleanup-preflight.json','rf1129-native-cache-cleanup.json']
for n in tools:members['tools/'+n]=W/n
for n in ['tauri/src-tauri/src/native_perf/sdk_surface_appearance.rs',
          'tauri/scripts/native-perf-owned-json.py','tauri/scripts/native-perf-preference-contract.mjs',
          'tauri/scripts/native-perf-sdk-journey.mjs']:
    members['sources/'+n]=R/n
rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as archive:
    for name,p in sorted(members.items()):
        assert not(p.stat().st_file_attributes&0x400)
        data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
        archive.addfile(info,io.BytesIO(data));rows.append({'member':name,'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(O/'raw.tar.gz') as archive:
    assert len(archive.getmembers())==len(rows)
    for row in rows:
        data=archive.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',{'task':'RF-1127','allMembersReadbackVerified':True,'members':rows,
                   'unusedPreparedTools':['verify-rf1129-diagnostic.mjs','render-rf1129-diagnostic.py'],
                   'physicalVaultExecutablesModelsAndCachesExcluded':True})
(O/'.gitattributes').write_text('raw.tar.gz -text\n',encoding='utf-8')
put(R/'docs/verification'/(N+'.json'),{'task':'RF-1127','sourceHead':'41fc4d15cbc546699ad416e75d10766704456787',
    'accepted':False,'newGuiBuilt':True,'exeSha256':journey['exeSha256'],'sources':len(sources),
    'buildReceipt':load(B/'build.receipt.json'),'manifestNewlineParity':load(B/'manifest-newline-parity.json'),
    'generatedFrontendInputStability':load(B/'dist-input-stability.json'),'runtimeResources':94,
    'requestedCohorts':4,'executedCohorts':1,'sdkJourneysPassed':2,'sdkJourneysFailed':1,
    'windowCapturesAccepted':0,'readerRuns':0,'rendererRuns':0,'failedStep':'home','reason':'probe-timeout',
    'firstLastGoodProbeStep':first['lastProbe']['step'],'failureCauseResolved':False,
    'appearanceTransitionDiagnosticReached':False,'cleanupIdentities':cleanup['identitiesChecked'],
    'exactCachesRemoved':len(cleanup['removedCachePaths']),'junctionsUnlinked':len(cleanup['linksUnlinked']),
    'vaultAndRootProofFilesPreserved':len(cleanup['preservedVaultAndRootFiles']),
    'applicationLogCopies':len(cleanup['applicationLogs']),'cleanupProcessesTerminated':0,
    'fullRF121Accepted':False,'RF1128Accepted':False,'performanceAccepted':False,
    'archive':{'path':N+'/raw.tar.gz','members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,
               'sha256':sha(O/'raw.tar.gz'),'allMembersReadbackVerified':True}})
print(json.dumps({'accepted':False,'members':len(rows),'sdkPassed':2,'sdkFailed':1,'acceptedCaptures':0,'cleanupCacheTargets':24}))
