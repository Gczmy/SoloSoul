from pathlib import Path
import hashlib,json
W=Path(__file__).parent.resolve();S=W/'rf1129-native-matrix-console-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
done=load(S/'cohorts-complete.json')
assert not done['accepted'] and len(done['rows'])==1 and done['rows'][0]['scene']=='baseline'
c=W/'ss-rf121-composed-window-restore-baseline-diagnostic-console-20261012'
receipt=load(c/'actual100.receipt.json')
assert receipt['exitCode']==0 and receipt['sourceUnchanged'] and receipt['resourcesUnchanged'] and receipt['originalFixtureUnchanged']
journey=load(c/'actual100/native-perf-sdk-journey-results.json')
assert not journey['interrupted'] and len(journey['samples'])==3
samples=[]
for row in journey['samples']:
    assert row['cleanupIntegrity']['complete']
    root=c/'actual100'/f"sample-{row['index']:03}"
    owned=load(root/'native-perf-owned.json');consumed=load(root/'native-perf-consumed.json')
    assert owned==row['owned'] and owned['runId']==consumed['runId'] and consumed['pid']==row['processId']
    assert Path(owned['root']).samefile(root) and owned['identifier']=='com.solosoul.rf312perf.'+owned['runId']
    processes=row.get('beforeSnapshot',{}).get('processes',[])+row.get('afterSnapshot',{}).get('processes',[])
    identities=[{'pid':p['pid'],'creationMs':p['creationMs']} for p in processes]
    assert len(identities)>=9
    samples.append({'index':row['index'],'runId':owned['runId'],'pid':row['processId'],'recordedIdentities':identities})
group={'label':'baseline','captureRoot':str(c),'terminal':True,'samples':samples,
       'terminalReceiptSha256':sha(c/'actual100.receipt.json'),'acceptanceEvidencePresent':False}
with (W/'rf1129-console-cache-cleanup-plan.json').open('x',encoding='utf-8') as f:
    json.dump({'cacheCleanupEligible':True,'failedSamplesAccepted':False,'groups':[group],
               'plannedExactCacheTargets':24,'freshCimRequired':True},f,indent=2)
text=(W/'rf1128-cleanup-owned.ps1').read_text(encoding='utf-8')
text=text.replace('rf1128-cache-cleanup','rf1129-console-cache-cleanup')
text=text.replace('groups.Count -ne 4','groups.Count -ne 1')
text=text.replace('Four terminal owned groups required; failed matrix remains rejected','One terminal owned group required; failed matrix remains rejected')
text=text.replace('Count -ne 96','Count -ne 24').replace('Exact 96 owned cache paths required','Exact 24 owned cache paths required')
text=text.replace('ss-rf1123-backdrop-runtime-20261011','ss-rf1129-diagnostic-runtime-20261011')
text=text.replace('application-logs-rf1128-shared','application-logs-rf1129-diagnostic-console')
text=text.replace("task='RF-1128'","task='RF-1127'")
with (W/'rf1129-console-cleanup-owned.ps1').open('x',encoding='utf-8') as f:f.write(text)
print('One failed terminal group: exact24 owned cache targets; no acceptance override')
