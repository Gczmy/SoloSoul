from pathlib import Path
import json,subprocess,time,sys
stage=Path(__file__).parent
cwd='C:/Users/40299571/SoloSoul/tauri'
checks=[('typescript',['node','node_modules/typescript/bin/tsc','--noEmit']),('lint',['node','node_modules/eslint/bin/eslint.js','src','--ext','.ts,.tsx']),('frontend-full',['npm.cmd','run','test']),('format',['node','node_modules/prettier/bin/prettier.cjs','--check','src/stores/authStore.ts','src/pages/auth/useLoginUnlockFlows.tsx','src/pages/auth/useLoginUnlockFlows.lifecycle.test.tsx']),('markdown',['node','scripts/check-markdown-chunk-boundary.mjs'])]
for name,command in checks:
 print('START '+name,flush=True)
 start=time.time()
 with (stage/(name+'.log')).open('wb') as log:
  r=subprocess.run(command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 result={'command':command,'cwd':cwd,'exitCode':r.returncode,'elapsedSeconds':time.time()-start}
 (stage/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(result),flush=True)
 if r.returncode:
  print((stage/(name+'.log')).read_text(encoding='utf-8',errors='replace')[-4000:],flush=True)
  sys.exit(r.returncode)
print('All checks completed',flush=True)
