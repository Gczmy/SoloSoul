import { act, renderHook } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { invoke } from '@tauri-apps/api/core';
import { LAST_ACCOUNT_KEY, useAuthStore } from '@/stores/authStore';
import { useLoginUnlockFlows } from './useLoginUnlockFlows';

const { navigate } = vi.hoisted(() => ({ navigate: vi.fn() }));
vi.mock('react-router-dom', async (original) => ({
  ...(await original<typeof import('react-router-dom')>()),
  useNavigate: () => navigate,
}));
function deferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (error: unknown) => void;
  const promise = new Promise<T>((yes, no) => {
    resolve = yes;
    reject = no;
  });
  return { promise, resolve, reject };
}
const accountA = { id: 'acc-a', name: 'Account A' };
const accountB = { id: 'acc-b', name: 'Account B' };
function renderFlow() {
  return renderHook(
    ({ accountId }) =>
      useLoginUnlockFlows({
        selectedAccountId: accountId,
        fromExisting: false,
        bioLockout: false,
        biometryTypeRaw: 'touchId',
        setLoginMethod: vi.fn(),
        setBioLockout: vi.fn(),
        setPinAvailable: vi.fn(),
      }),
    { initialProps: { accountId: accountA.id }, wrapper: MemoryRouter },
  );
}

describe('RF-1099 unlock request lifecycle', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.mocked(invoke).mockReset().mockResolvedValue(undefined);
    navigate.mockClear();
    localStorage.clear();
    useAuthStore.setState({
      isAuthenticated: false,
      isLoading: false,
      currentAccount: null,
      accounts: [accountA, accountB],
      hasAccount: true,
      error: null,
    });
  });
  afterEach(() => {
    vi.clearAllTimers();
    vi.useRealTimers();
  });

  it.each(['pin', 'biometric'] as const)(
    '%s cannot restore authentication after lock',
    async (method) => {
      const response = deferred<unknown>();
      vi.mocked(invoke).mockImplementation(
        (command) =>
          (command === 'pin_unlock' || command === 'biometric_unlock'
            ? response.promise
            : Promise.resolve(
                command === 'vault_list_accounts' ? [accountA, accountB] : undefined,
              )) as ReturnType<typeof invoke>,
      );
      const { result } = renderFlow();
      let pending!: Promise<void>;
      act(() => {
        pending =
          method === 'pin'
            ? result.current.handlePinComplete('123456')
            : result.current.handleBiometricUnlock();
      });
      await act(async () => useAuthStore.getState().lock());
      await act(async () => {
        response.resolve(method === 'pin' ? accountA : undefined);
        await pending;
      });
      expect(useAuthStore.getState().isAuthenticated).toBe(false);
      expect(useAuthStore.getState().currentAccount).toBeNull();
      expect(localStorage.getItem(LAST_ACCOUNT_KEY)).toBeNull();
      expect(navigate).not.toHaveBeenCalled();
    },
  );
});
