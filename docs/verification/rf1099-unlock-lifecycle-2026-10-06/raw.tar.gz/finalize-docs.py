from pathlib import Path
import json,hashlib,re,datetime
root=Path("C:/Users/40299571/SoloSoul")
stage=Path(__file__).parent
stem="rf1099-unlock-lifecycle-2026-10-06"
checks={name:json.loads((stage/(name+".json")).read_text(encoding="utf-8")) for name in ["typescript","lint","frontend-full","format","markdown"]}
assert all(r["exitCode"] == 0 for r in checks.values())
hashes=json.loads((stage/"final-source-hashes.json").read_text(encoding="utf-8"))
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in hashes.items())
full=(stage/"frontend-full.log").read_text(encoding="utf-8",errors="replace")
match=re.search(r"Test Files\s+(\d+) passed.*?Tests\s+(\d+) passed",full,re.S)
assert match, "Missing actual Vitest summary"
files,tests=map(int,match.groups())
assert re.search(r"(?:#|ℹ) pass 215\b",full) and re.search(r"(?:#|ℹ) fail 0\b",full) and re.search(r"(?:#|ℹ) skipped 1\b",full)
baseline=json.loads((stage/"baseline.json").read_text(encoding="utf-8"))
for p,name in [("tauri/src/stores/authStore.ts","authStore.ts.before"),("tauri/src/pages/auth/useLoginUnlockFlows.tsx","useLoginUnlockFlows.tsx.before")]:
 assert hashlib.sha256((stage/name).read_bytes()).hexdigest()==baseline["sourceSha256"][p]
master={"schemaVersion":1,"task":"RF-1099","baseCommit":baseline["head"],"createdAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"frontend account/page ownership of password, PIN and biometric unlock attempts","sourceSha256":hashes,"initialRed":json.loads((stage/"red.json").read_text(encoding="utf-8")),"navigationRed":json.loads((stage/"navigation-red.json").read_text(encoding="utf-8")),"targeted":json.loads((stage/"targeted-complete.json").read_text(encoding="utf-8")),"checks":checks,"vitest":{"filesPassed":files,"testsPassed":tests,"lifecycleCases":50,"failed":0},"node":{"passed":215,"failed":0,"existingSkipped":1},"existingLintWarnings":1,"preservedFailures":["Initial two PIN/biometric late-success failures (exit 1)","Four test assertions incorrectly assumed the unlock clock would remain unchanged after a legitimate new password login; corrected to snapshot the current clock before old settlement (exit 1 preserved)","Five lifecycle-boundary failures in the additional six-case selection (exit 1): successful navigation cancelled safety refresh, late refresh result/error after lock, old password callback clearing the new error, old-account callback sending unlock"],"draftChecks":"The earlier full frontend pass is archived as draft; final results above bind the final three source hashes.","boundaries":["Does not cancel already-issued native authentication commands or close OS authentication prompts","Hook mocks do not verify native credentials, keychain or hardware authentication","Does not establish the root cause of the previous native home timeout","Rust, CLI and native material inputs unchanged"],"rawEvidenceIndex":stem+"/index.json"}
verification=root/"docs/verification"
(verification/(stem+".json")).write_text(json.dumps(master,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
md=f"""# RF-1099 登录请求生命周期验证

PIN 和生物识别等待解锁时，锁定后的旧成功结果曾恢复前端认证。两项真实 hook 红测失败、exit 1。三种登录方式现在共享可复核、可取消的认证请求身份；账户切换、页面卸载和新认证使尚未完成的旧解锁失效。迟到成功和失败不更新认证、最近账户、解锁时钟、导航、提醒、错误或新请求的等待显示，同方法同步重复提交只发送一次。

成功密码认证提交后释放页面所有权，正常导航继续完成已有目录的安全标志复位和刷新。刷新仍复核认证请求，锁定后的迟到列表或错误不回填。保留的旧账户或已卸载页面回调不能发起认证或清除新页面错误。新增六项边界测试的五个失败已实际复现并修复，原日志保留。

新增 50 项生命周期回归；相关五文件定向测试 89 项通过。最终完整 Vitest **{files} 文件/{tests} 项**通过，Node **215 通过、0 失败、1 既有跳过**；TypeScript、Lint、改动文件格式和文档边界检查 exit 0。Lint 保留未修改 syncStore.ts 的 1 条既有 unused-event 警告。先前四个解锁时钟断言错误已修正为比较旧响应完成前后的当前时钟，未放松认证状态断言；中间完整检查记录作为 draft 保留，最终检查绑定三份最终源码 SHA。

取消仅约束前端结果提交，不取消已发送的原生认证命令或关闭系统提示框。真实 hook 配合 IPC mock 的证据不等同于原生凭证和硬件验收，也不确定旧首页超时根因。Rust、CLI 和平台材质未改，RF-112/121/312 与 RF-122～127 前置仍未完成。

[命令与退出码]({stem}.json)、[原件索引]({stem}/index.json)记录修改前源码、红测、修正前失败、draft 与最终完整检查、最终源码和哈希。raw.tar.gz 逐成员核对长度与 SHA；不含正式账户、Vault、EXE、DLL、模型或原生缓存。
"""
(verification/"RF-1099-unlock-lifecycle.md").write_text(md,encoding="utf-8",newline="\n")
p=root/"docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md"
s=p.read_text(encoding="utf-8-sig")
s=s.replace("最后更新：2026-10-06（RF-1098 认证迟到结果修复）","最后更新：2026-10-06（RF-1099 登录请求生命周期修复）")
s=s.replace("已关闭：**279 / 289**；实际修复（已关闭）：279；","已关闭：**280 / 289**；实际修复（已关闭）：280；")
s=s.replace("进行中：1（RF-1099）；待执行：6。","进行中：0；待执行：6。")
s=s.replace("- 当前处理：**RF-1099 登录请求须受账户选择和页面生命周期约束；PIN/生物识别锁定后迟到成功的2项红测均复现。RF-112/121/312及RF-122～127前置保持未完成**。","- 当前处理：**RF-1099 已关闭；下一本地项为 RF-312 认证/首页超时复测及 RF-121 Windows 主题、折叠、缩放和恢复矩阵。RF-112/121/312及RF-122～127前置保持未完成**。")
s=s.replace("| 289 | [RF-1099](#rf-1099) | P1 | 登录请求受账户与页面生命周期约束 | 无（RF-1098后续链路复核） | [~] 进行中 |","| 289 | [RF-1099](#rf-1099) | P1 | 登录请求受账户与页面生命周期约束 | 无（RF-1098后续链路复核） | [x] 完成 |")
s+=f"""
### RF-1099 登录请求生命周期修复（2026-10-06）

- PIN/生物识别锁定后迟到成功的原两项红测 exit1；三种登录方式共享认证请求，账户选择和页面卸载取消未完成解锁。新请求、锁定/退出后旧结果不更新认证、导航、最近账户、解锁时钟、提醒或错误/loading；同方法同步重入不重复发送。
- 追加边界红测六项中五项失败、exit1：正常导航取消安全刷新、锁定后刷新成功/失败回填、旧密码回调清错、旧账户回调发起认证。成功密码认证释放页面所有权，安全刷新保留全局请求校验；旧回调在发起前核对当前页面/账户。原失败均归档。
- 最终完整F实际exit0：Vitest {files}文件/{tests}项、Node215通过/0失败/1既有跳过；TypeScript/Lint/格式/文档边界通过，保留1条既有unused-event警告。50项新增生命周期回归及相关89项定向通过。首次四项时钟假设错误已修正，draft完整检查与最终源码检查分别保留，不把前一版本通过充作最终验收。
- [验证记录](verification/RF-1099-unlock-lifecycle.md)、[实际回执](verification/{stem}.json)、[原件索引](verification/{stem}/index.json)绑定源码SHA；canonical状态管理规范同步。按RF-1099独立本地提交，不推送；280/289关闭、3待验证、6待执行。
- 本项仅前端结果保护，不取消原生命令或验证硬件凭证，不作为旧首页超时根因。RF-112/121/312及RF-122～127前置保持，整体goal继续active。
"""
p.write_text(s,encoding="utf-8",newline="\n")
print(json.dumps({"files":files,"tests":tests,"status":"docs prepared; final DOC and archive pending"}))
