from pathlib import Path
import subprocess,json,time,sys
stage=Path(__file__).parent
name=sys.argv[1]
command=['node','node_modules/vitest/vitest.mjs','run',*sys.argv[2:]]
start=time.time()
r=subprocess.run(command,cwd='C:/Users/40299571/SoloSoul/tauri',stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(stage/(name+'.log')).write_bytes(r.stdout)
(stage/(name+'.json')).write_text(json.dumps({'command':command,'exitCode':r.returncode,'elapsedSeconds':time.time()-start},indent=2)+'\n',encoding='utf-8')
print(r.stdout.decode('utf-8',errors='replace')[-4500:]);print('actual exitCode:',r.returncode)
