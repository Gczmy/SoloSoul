import pathlib,subprocess,json,os,time,sys
R=pathlib.Path(r'C:\Users\40299571\SoloSoul');T=pathlib.Path(__file__).parent;mode=sys.argv[1];env=dict(os.environ);env['CI']='1';env['SOLOSOUL_E2E_CHANNEL']='msedge';env['TAURI_DEV_HOST']='localhost';env['TAURI_DEV_HMR_PORT']='20102'
base=['node','node_modules/@playwright/test/cli.js','test','e2e/sidebar-tools.spec.ts','e2e/object-ruler.spec.ts','--project=chromium','--project=mobile','--config',str(T/'playwright.config.mjs')]
if mode=='negative':commands=[('web-negative',base+['--grep','RF1088','--retries=0'])]
elif mode=='positive':commands=[('web-positive',base+['--grep','RF1088','--retries=0'])]
elif mode=='web':commands=[('web-full',base)]
elif mode=='f-serial':commands=[('full-frontend-serial',['npm.cmd','run','test','--','--maxWorkers','2'])]
elif mode=='f-node22-exact':
 runtime=json.loads((T/'node22-runtime.json').read_text());nodeDir=T/'node22'/runtime['file'].removesuffix('.zip');env['PATH']=str(nodeDir)+os.pathsep+env['PATH'];commands=[('node22-exact-version',[str(nodeDir/'node.exe'),'--version']),('full-frontend-node22-exact',[str(nodeDir/'node.exe'),str(nodeDir/'node_modules/npm/bin/npm-cli.js'),'run','test','--','--maxWorkers','2'])]
elif mode=='f':commands=[('format',['node','node_modules/prettier/bin/prettier.cjs','--check','src/components/layout/TopFunctionBar.tsx','src/components/workspace/WorkspaceObjectRuler.tsx','e2e/sidebar-tools.spec.ts','e2e/object-ruler.spec.ts']),('tsc',['node','node_modules/typescript/bin/tsc','--noEmit']),('lint',['npm.cmd','run','lint']),('full-frontend',['npm.cmd','run','test','--','--maxWorkers','2'])]
else:raise SystemExit('Unknown mode')
checks=[]
for name,args in commands:
 start=time.monotonic()
 with (T/(name+'.log')).open('wb') as out:p=subprocess.Popen(args,cwd=R/'tauri',env=env,stdout=out,stderr=subprocess.STDOUT);rc=p.wait()
 checks.append({'name':name,'args':args,'exit':rc,'seconds':time.monotonic()-start,'owned_pid':p.pid});(T/(mode+'-checks.json')).write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8');print(name,rc,round(time.monotonic()-start,2),flush=True)
 if rc:sys.exit(rc)
