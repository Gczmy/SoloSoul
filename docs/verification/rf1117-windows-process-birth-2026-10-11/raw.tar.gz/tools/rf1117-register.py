from pathlib import Path
import datetime,hashlib,json
root=Path('D:/SoloSoul');w=Path(__file__).parent;stage=w/'rf1117-checks-20261011'
stage.mkdir(exist_ok=False)
p=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';raw=p.read_bytes();(stage/'ledger-before.md').write_bytes(raw)
s=raw.decode('utf8');eol='\r\n' if '\r\n' in s else '\n'
old='- 任务总数：**306**（P1：55；P2：250；P3：1）。'
assert s.count(old)==1;s=s.replace(old,'- 任务总数：**307**（P1：55；P2：251；P3：1）。')
s=s.replace('- 已关闭：**296 / 306**；','- 已关闭：**296 / 307**；',1)
s=s.replace('暂缓：0；进行中：0；待执行：6。','暂缓：0；进行中：1；待执行：6。',1)
s=s.replace('RF-1115、RF-1116（RF-904','RF-1115、RF-1116、RF-1117（RF-904',1)
old='- 当前处理：**无；RF-1116已完成，继续复核本地可执行项；完整RF-121保持未完成**。'
assert s.count(old)==1;s=s.replace(old,'- 当前处理：**RF-1117：进程快照在身份字段缺失前排除出生时间早于已核验父进程的历史候选；完整RF-121/312保持未完成**。')
row='| 306 | [RF-1116](#rf-1116) | P2 | 补齐受控原生主题切换与原偏好恢复验证入口 | 无（RF-121深色补验的固定设置路由缺口） | [x] 完成 |'
assert s.count(row)==1;s=s.replace(row,row+eol+'| 307 | [RF-1117](#rf-1117) | P2 | 排除历史父PID复用下不可读旧子进程的快照误判 | 无（RF-1116启动门禁失败归因） | [~] 进行中 |')
card='''### RF-1117

**排除历史父PID复用下不可读旧子进程的快照误判** · P2 · 来源：RF-1116启动身份门禁失败

- **入口：**`tauri/scripts/native-perf-run.mjs`的固定PowerShell进程发现循环及其真实脚本块回归；仅非默认诊断驱动，不修改GUI/Rust/生产依赖。
- **现状：**当前循环先调用Identity，缺少ExecutablePath便将候选计为未知后代，之后才对完整身份比对父子出生时间。RF-1116失败应用PID860的新实例下，fresh CIM发现parentPID860的820/996实际出生于更早日期；旧父PID历史记录可触发错误拒绝，不意味着它们属于当前应用。原失败及未知后代缺口仍保留，不能靠放宽门禁关闭。
- **执行：**先用可用的CreationDate排除早于已核验父进程的候选，再执行原身份/刷新/内存/清理规则。不查询其命令行、不读取内存、不纳入终止集合；未知出生时间、等时/较新的不可读后代仍拒绝，原fresh查询预算保持。
- **验收：**生产PowerShell发现块的可重现红/绿覆盖普通及连续采样、旧候选缺路径和完整路径、父PID复用的后代链、有效当前链、缺出生时间与当前不可读后代；原Node门禁及memory回归、格式/语法检查。Rust/frontend/EXE未变时验证源码/二进制来源，不重编未受影响的Rust；新驱动100/5000各三次完整原生行程及身份清理核验。保留原失败、可靠样本精确清理和独立提交，不推送、不关闭完整RF-121/312。

'''
marker='## 7. 每项执行记录模板';assert s.count(marker)==1
s=s.replace(marker,card.replace('\n',eol)+marker,1)
p.write_bytes(s.encode('utf8'))
for name in ['tauri/scripts/native-perf-run.mjs','tauri/scripts/native-perf-run.test.mjs']:
    data=(root/name).read_bytes();(stage/Path(name).name).write_bytes(data)
with (stage/'registration.json').open('x',encoding='utf8',newline='\n') as f:
    json.dump({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task':'RF-1117','baseCommit':'095bfd221','sourceHashes':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['tauri/scripts/native-perf-run.mjs','tauri/scripts/native-perf-run.test.mjs']}},f,indent=2);f.write('\n')
print('RF1117 registered: 296/307, one active, four waiting, six pending')
