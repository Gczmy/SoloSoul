from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path('D:/SoloSoul');stage=Path(__file__).parent/'rf1117-checks-20261011'
env=os.environ.copy();env.update(TEMP=str(root/'build/rf312-maintenance-20261009/tmp'),TMP=str(root/'build/rf312-maintenance-20261009/tmp'))
command=['node','--test','--test-name-pattern=actual.*discovery','scripts/native-perf-run.test.mjs']
sources={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['tauri/scripts/native-perf-run.mjs','tauri/scripts/native-perf-run.test.mjs']}
(stage/'red-test-source.mjs').write_bytes((root/'tauri/scripts/native-perf-run.test.mjs').read_bytes())
with (stage/'red-discovery.stdout.log').open('xb') as out,(stage/'red-discovery.stderr.log').open('xb') as err:
    started=time.monotonic();p=subprocess.Popen(command,cwd=root/'tauri',env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    print('Controlled discovery red regression PID',p.pid,flush=True);code=p.wait()
with (stage/'red-discovery.receipt.json').open('x',encoding='utf8',newline='\n') as f:
    json.dump({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':p.pid,'command':command,'exitCode':code,'elapsedSeconds':time.monotonic()-started,'sourceHashes':sources,'preparationFailure':'First PowerShell redirect used ../../build from tauri, resolved outside repository; Out-File failed before Node executed. Corrected to absolute D paths and reliable subprocess exit recording.'},f,indent=2);f.write('\n')
print('Actual red exit:',code,flush=True)
print((stage/'red-discovery.stdout.log').read_text(),flush=True)
raise SystemExit(code)
