from pathlib import Path
import json
w=Path(__file__).parent;load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
groups=[]
for count in [100,5000]:
    group=w/f'ss-rf1117-owned-journeys-{count}-20261011'
    receipt=load(group/'actual100.receipt.json');v=load(group/'validation.json')
    assert receipt['exitCode']==0 and v['accepted'] and len(v['samples'])==3
    assert load(group/'verify.receipt.json')['exitCode']==0
    groups.append({'label':str(count),'captureRoot':str(group),'terminal':True,'samples':v['samples']})
with (w/'rf1117-cache-cleanup-plan.json').open('x',encoding='utf8') as f:json.dump({'cacheCleanupEligible':True,'failedSamplesAccepted':False,'groups':groups},f,indent=2)
s=(w/'cleanup-rf1115-owned.ps1').read_text().replace('rf1115','rf1117').replace('RF-1115','RF-1117')
s=s.replace('ss-rf1117-runtime-20261011','ss-rf1116-runtime-20261011')
with (w/'cleanup-rf1117-owned.ps1').open('x',encoding='utf8',newline='\n') as f:f.write(s)
print('Six accepted terminal samples eligible for exact 48-path cache cleanup; prior failed sample retained')
