from pathlib import Path
import datetime,hashlib,io,json,re,tarfile
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1117-checks-20261011'
stem='rf1117-windows-process-birth-2026-10-11';out=root/'docs/verification'/stem
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(checks/'checks-complete.json')['success']
sources=load(checks/'sources.json')
for p,h in sources.items():assert sha(root/p)==h,p
checksNames=['green-discovery','prettier','run-syntax','test-syntax','node-native','node-memory']
receipts={name:load(checks/(name+'.receipt.json')) for name in checksNames}
assert all(v['exitCode']==0 and v['sourceUnchanged'] for v in receipts.values())
def nodeCounts(name,expected):
    text=(checks/(name+'.stdout.log')).read_text(encoding='utf8')
    values={k:int(re.findall(r'(?m)^ℹ '+k+r' (\d+)\s*$',text)[0]) for k in ['tests','pass','fail','cancelled','skipped','todo']}
    assert values['tests']==values['pass']==expected
    assert all(values[k]==0 for k in ['fail','cancelled','skipped','todo'])
    return values
counts={n:nodeCounts(n,c) for n,c in [('green-discovery',3),('node-native',115),('node-memory',14)]}
red=load(checks/'red-corrected-discovery.receipt.json');assert red['exitCode']==1
text=(checks/'red-corrected-discovery.stdout.log').read_text()
for k,v in [('tests',3),('pass',1),('fail',2),('cancelled',0),('skipped',0),('todo',0)]:assert re.findall(r'(?m)^ℹ '+k+r' (\d+)\s*$',text)==[str(v)]
assert text.count('true !== false')==2
pkg=load(checks/'runtime-reuse-proof.json')['runtime'];assert sha(Path(pkg['exe']))==pkg['sha256']
for i in pkg['resources']:assert sha(Path(i['source']))==sha(Path(i['copy']))==i['sha256']
cleanup=load(w/'rf1117-cache-cleanup.json');assert cleanup['matchingOwnedIdentitiesLive']==0 and cleanup['processesTerminatedByThisTool']==0 and cleanup['preservedBytesVerified']
assert len(cleanup['removedCachePaths'])==48
for i in cleanup['preservedVaultAndRootFiles']:assert sha(Path(i['path']))==i['sha256']
files={}
def add(p,name):
    assert name not in files and p.is_file() and not p.is_symlink() and not(p.lstat().st_file_attributes&0x400),p
    files[name]=p
for p in checks.iterdir():
    if p.is_file():add(p,'checks/'+p.name)
tools=['rf1117-register.py','rf1117-run-red.py','rf1117-run-red-corrected.py','rf1117-run-checks.py','rf1117-run-journeys.py','verify-rf1117-journeys.mjs','rf1117-session-before-journeys.py','rf1117-session-before-journeys.json','rf1117-prepare-cleanup.py','cleanup-rf1117-owned.ps1','rf1117-cache-cleanup-plan.json','rf1117-cache-cleanup-preflight.json','rf1117-cache-cleanup.json','rf1117-archive.py']
for n in tools:add(w/n,'tools/'+n)
for n in ['native-perf-run.mjs','native-perf-run.test.mjs']:add(root/'tauri/scripts'/n,'executed-source/'+n)
for n in ['failed-repeat-process-recheck.json','startup-ownership-failure-review.json']:add(w/'rf1116-checks-20261011'/n,'previous-failure-attribution/'+n)
groups=[]
for count in [100,5000]:
    group=w/f'ss-rf1117-owned-journeys-{count}-20261011';v=load(group/'validation.json')
    assert v['accepted'] and len(v['samples'])==3 and load(group/'actual100.receipt.json')['exitCode']==0
    inputs=load(group/'input-proof.json')
    for p,h in inputs['fixtureFiles'].items():assert sha(Path(inputs['fixture'])/p)==h
    groups.append(v)
    for p in group.iterdir():
        if p.is_file():add(p,f'{count}/'+p.name)
    actual=group/'actual100'
    for p in actual.iterdir():
        if p.is_file():add(p,f'{count}/actual100/'+p.name)
        elif p.name in ['sample-001','sample-002','sample-003']:
            for leaf in p.iterdir():
                if leaf.is_file():add(leaf,f'{count}/actual100/'+p.name+'/'+leaf.name)
logs=w/'application-logs-rf1117'
if logs.exists():
    for p in logs.rglob('*'):
        if p.is_file():add(p,'application-logs/'+p.relative_to(logs).as_posix())
out.mkdir(exist_ok=False);(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf8')
members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as tar:
    for name,p in sorted(files.items()):
        data=p.read_bytes();member=tarfile.TarInfo(name);member.size=len(data);member.mtime=int(p.stat().st_mtime)
        tar.addfile(member,io.BytesIO(data));members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(out/'raw.tar.gz','r:gz') as tar:
    assert tar.getnames()==[v['path'] for v in members]
    for v in members:
        data=tar.extractfile(v['path']).read();assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
index={'task':'RF-1117','archiveSha256':sha(out/'raw.tar.gz'),'archiveBytes':(out/'raw.tar.gz').stat().st_size,'members':members,'allMembersReadbackVerified':True}
save(out/'index.json',index)
result={'task':'RF-1117','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'accepted':True,'baseCommit':'095bfd221','sourceCount':len(sources),'sourceChanges':load(checks/'runtime-reuse-proof.json')['changedSources'],'checks':receipts,'testCounts':counts,'controlledOldCodeRed':{'tests':3,'passed':1,'failed':2,'actualAlgorithmFailure':'old-unreadable sets unverifiedDescendants true despite birth before verified parent'},'binaryRebuilt':False,'exeSha256':pkg['sha256'],'runtimeResourcesUnchanged':len(pkg['resources']),'groups':groups,'cleanup':{'identitiesChecked':cleanup['identitiesChecked'],'pathsRemoved':len(cleanup['removedCachePaths']),'linksUnlinked':len(cleanup['linksUnlinked']),'preservedFiles':len(cleanup['preservedVaultAndRootFiles']),'terminatedByCleanupTool':0},'archive':index,'priorFailedSampleAccepted':False,'priorFailedSampleCachesDeleted':False,'fullRF121Accepted':False,'fullRF312Accepted':False,'otherPlatformsAccepted':False,'performanceMetrics':None,'preparationCorrections':['Initial relative output redirection failed before Node ran; retained in receipt.','Initial test fixture emitted PowerShell first-use progress on stderr; suppressed progress only in controlled fixture. Real old-code red was subsequently two algorithm failures and one pass.','Before verifier execution, actual projected snapshot schema was checked; replaced nonexistent raw fields with reason/memory/UDF/filesystem checks and cleanup unknown-descendant gate. Original prepared verifier retained.']}
save(root/'docs/verification'/(stem+'.json'),result)
print('Archived and reread',len(members),'raw members;',index['archiveBytes'],'bytes; six complete journeys verified')
