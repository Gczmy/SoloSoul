from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path('D:/SoloSoul');w=Path(__file__).parent;stage=w/'rf1117-checks-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,v):
    with (stage/name).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
old=load(w/'rf1116-checks-20261011/sources.json')
current={p:sha(root/p) for p in old}
changed=[p for p in old if old[p]!=current[p]]
assert set(changed)=={'tauri/scripts/native-perf-run.mjs','tauri/scripts/native-perf-run.test.mjs'},changed
save('sources.json',current)
package=load(w/'rf1116-checks-20261011/runtime-package.json')
assert sha(Path(package['exe']))==package['sha256']
for item in package['resources']:
    assert sha(Path(item['source']))==sha(Path(item['copy']))==item['sha256']
save('runtime-reuse-proof.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':'095bfd221','changedSources':changed,'runtimeSourceCount':len(old),'binaryInputsUnchanged':True,'binaryRebuilt':False,'resourcesUnchanged':True,'parentManifestSha256':sha(w/'rf1116-checks-20261011/sources.json'),'runtime':package})
for p in changed:(stage/Path(p).name).with_suffix('.executed.mjs').write_bytes((root/p).read_bytes())
env=os.environ.copy();cache=root/'build/rf312-maintenance-20261009'
env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),npm_config_cache=str(cache/'npm-cache'))
def verify():assert current=={p:sha(root/p) for p in old},'Source changed during checks'
def run(name,cmd):
    verify();start=time.monotonic()
    with (stage/(name+'.stdout.log')).open('xb') as out,(stage/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=root/'tauri',env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',{'pid':p.pid,'command':cmd});print(name,'PID',p.pid,flush=True);code=p.wait()
    verify();save(name+'.receipt.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code,'pid':p.pid,'command':cmd,'elapsedSeconds':time.monotonic()-start,'sourceUnchanged':True,'sourceManifestSha256':sha(stage/'sources.json')})
    assert code==0,(name,code)
run('green-discovery',['node','--test','--test-name-pattern=actual.*discovery','scripts/native-perf-run.test.mjs'])
run('prettier',['node','node_modules/prettier/bin/prettier.cjs','--check','scripts/native-perf-run.mjs','scripts/native-perf-run.test.mjs'])
run('run-syntax',['node','--check','scripts/native-perf-run.mjs'])
run('test-syntax',['node','--check','scripts/native-perf-run.test.mjs'])
run('node-native',['npm.cmd','run','test:native-perf'])
run('node-memory',['node','--test','scripts/native-perf-memory.test.mjs'])
save('checks-complete.json',{'success':True,'sourceUnchanged':True,'sourceCount':len(current),'changedSources':changed})
print('RF-1117 targeted and full Node checks terminal',flush=True)
