from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1117-checks-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(checks/'checks-complete.json')['success']
sources=load(checks/'sources.json');pkg=load(checks/'runtime-reuse-proof.json')['runtime']
env=os.environ.copy();env.update(TEMP=str(w),TMP=str(w));env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','');env.pop('PDFIUM_LIBRARY_PATH',None)
def verify():
    assert sources=={p:sha(root/p) for p in sources}
    assert sha(Path(pkg['exe']))==pkg['sha256']
    for i in pkg['resources']:assert sha(Path(i['source']))==sha(Path(i['copy']))==i['sha256']
sessionScript=(w/'rf1116-retry2-session-before-capture.py').read_text().replace('rf1116-retry2-session-before-capture.json','rf1117-session-before-journeys.json')
sessionPath=w/'rf1117-session-before-journeys.py';sessionPath.write_text(sessionScript,encoding='utf8')
p=subprocess.run([sys.executable,'-X','utf8',str(sessionPath)],capture_output=True)
save(checks/'session-probe.receipt.json',{'exitCode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()});assert p.returncode==0
session=load(w/'rf1117-session-before-journeys.json');assert session['callerSessionId']==1 and session['connectionStateName']=='Active' and session['inputDesktopAvailable'],session
print('Fresh session 1 Active and input desktop accessible',flush=True)
for count in [100,5000]:
    verify();group=w/f'ss-rf1117-owned-journeys-{count}-20261011';group.mkdir(exist_ok=False)
    fixture=root/f'build/rf312-maintenance-20261009/fixtures/vault{count}'
    before={str(p.relative_to(fixture)):sha(p) for p in fixture.rglob('*') if p.is_file()}
    save(group/'input-proof.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtime':pkg,'fixture':str(fixture),'fixtureFiles':before,'sourceManifestSha256':sha(checks/'sources.json'),'driverSha256':sha(Path(__file__)),'diagnosticOnly':True,'performanceMetrics':None,'samplesRequested':3,'binaryRebuilt':False})
    cmd=['node','scripts/native-perf-auth-attribution.mjs','--exe',pkg['exe'],'--fixture',str(fixture),'--output',str(group/'actual100'),'--samples','3'];start=time.monotonic()
    with (group/'actual100.stdout.log').open('xb') as out,(group/'actual100.stderr.log').open('xb') as err:
        p=subprocess.Popen(cmd,cwd=root/'tauri',env=env,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(group/'actual100.live.json',{'pid':p.pid,'command':cmd});print(count,'objects three native journeys PID',p.pid,flush=True);code=p.wait()
    verify();unchanged=before=={str(p.relative_to(fixture)):sha(p) for p in fixture.rglob('*') if p.is_file()}
    save(group/'actual100.receipt.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code,'pid':p.pid,'command':cmd,'elapsedSeconds':time.monotonic()-start,'sourceUnchanged':True,'originalFixtureUnchanged':unchanged,'resourcesUnchanged':True,'pdfiumOverrideInherited':False})
    assert code==0 and unchanged,(count,code)
    cmd=['node',str(w/'verify-rf1117-journeys.mjs'),str(count)]
    p=subprocess.run(cmd,cwd=root,env=env,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
    (group/'verify.stdout.log').write_bytes(p.stdout);(group/'verify.stderr.log').write_bytes(p.stderr)
    save(group/'verify.receipt.json',{'command':cmd,'exitCode':p.returncode});assert p.returncode==0,p.stderr.decode()
    print(p.stdout.decode(),flush=True)
print('Six complete owned native journeys terminal',flush=True)
