from pathlib import Path
import datetime,json,os,subprocess,sys,time
R=Path('D:/SoloSoul');S=Path(__file__).parent
label=sys.argv[1];commands={
 'routes-red':['node','--test','scripts/native-perf-auth-attribution.test.mjs'],
 'routes-green':['node','--test','scripts/native-perf-auth-attribution.test.mjs','scripts/native-perf-maintenance.test.mjs','scripts/native-perf-ocr.test.mjs'],
 'full-node':['node','scripts/run-node-tests.mjs'],
 'prettier':['node','node_modules/prettier/bin/prettier.cjs','--check','scripts/native-perf-auth-contract.mjs','scripts/native-perf-auth-attribution.test.mjs'],
 'prettier-write':['node','node_modules/prettier/bin/prettier.cjs','--write','scripts/native-perf-auth-contract.mjs','scripts/native-perf-auth-attribution.test.mjs'],
 'prettier-final':['node','node_modules/prettier/bin/prettier.cjs','--check','scripts/native-perf-auth-contract.mjs','scripts/native-perf-auth-attribution.test.mjs'],
}
assert label in commands
env=os.environ.copy();tmp=S/'tmp';tmp.mkdir(exist_ok=True)
env.update(TEMP=str(tmp),TMP=str(tmp),PYTHONUTF8='1');began=time.monotonic();cmd=commands[label]
with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
    process=subprocess.Popen(cmd,cwd=R/'tauri',env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
    with (S/(label+'.live.json')).open('x',encoding='utf-8',newline='\n') as target:
        json.dump(dict(command=cmd,pid=process.pid,at=datetime.datetime.now(datetime.timezone.utc).isoformat()),target,indent=2);target.write('\n')
    print(label,'live PID',process.pid,flush=True);code=process.wait()
with (S/(label+'.receipt.json')).open('x',encoding='utf-8',newline='\n') as target:
    json.dump(dict(command=cmd,exitCode=code,elapsedSeconds=time.monotonic()-began),target,indent=2);target.write('\n')
print(label,'exit',code,flush=True);raise SystemExit(code)
