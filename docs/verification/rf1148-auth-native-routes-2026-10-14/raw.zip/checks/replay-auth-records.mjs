import assert from 'node:assert/strict';
import { readFile, writeFile, lstat, realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { checkBound } from '../../tauri/scripts/native-perf-sdk-journey.mjs';
import { normalizeWindowsPath } from '../../tauri/scripts/native-perf-run.mjs';
import { describeAuthAttribution } from '../../tauri/scripts/native-perf-auth-contract.mjs';
import { describeAuthAttribution as oldDescribe } from './before-native-perf-auth-contract.mjs';
import { checkMaintenanceAdmission } from '../../tauri/scripts/native-perf-maintenance-contract.mjs';
const repo='D:/SoloSoul', stage=path.join(repo,'build/rf1148-auth-native-routes-20261014');
const json=async file=>JSON.parse((await readFile(file,'utf8')).replace(/^\uFEFF/,''));
const hash=async file=>createHash('sha256').update(await readFile(file)).digest('hex');
const index=await json(path.join(repo,'docs/verification/rf1147-ocr-picker-settlement-2026-10-14/index.json'));
const archived=new Map(index.members.map(row=>[normalizeWindowsPath(row.source),row]));
const readArchived=async file=>{
  const row=archived.get(normalizeWindowsPath(file));assert.ok(row,file);
  const stat=await lstat(file);assert.ok(stat.isFile()&&!stat.isSymbolicLink());
  assert.equal(normalizeWindowsPath(await realpath(file)),normalizeWindowsPath(file));
  assert.equal(stat.size,row.bytes);assert.equal(await hash(file),row.sha256);
  return json(file);
};
const before=await json(path.join(stage,'sources-before.json'));
assert.equal(await hash(path.join(repo,'tauri/scripts/native-perf-run.mjs')),before['tauri/scripts/native-perf-run.mjs']);
const differences=[];
for(const [name,sha] of Object.entries(before)) if(await hash(path.join(repo,name))!==sha) differences.push(name);
assert.deepEqual(differences.sort(),['tauri/scripts/native-perf-auth-attribution.test.mjs','tauri/scripts/native-perf-auth-contract.mjs']);
const runtime=await json(path.join(stage,'runtime.json'));
assert.equal(await hash(runtime.exe),runtime.sha256);
for(const row of runtime.resources){assert.equal(await hash(row.source),row.sha256);assert.equal(await hash(row.copy),row.sha256);}
const cohorts=[
 ['rf1146-native-ocr-20261014',100],['rf312-ocr-readonly-controls-20261014',100],
 ['rf312-ocr-readonly-controls-retry1-20261014',100],['rf1147-ocr-acceptance-20261014',100],
 ['rf1147-ocr-acceptance-retry1-20261014',100],['rf1147-ocr-acceptance-retry1-20261014',5000],
];
const records=[];let present=0,missing=0,oldRejected=0,oldAccepted=0,homeTimeouts=0;
for(const [name,objects] of cohorts){
  const root=path.join(repo,'build',name,`samples${objects}`);
  const report=await readArchived(path.join(root,'native-perf-sdk-journey-results.json'));
  assert.equal(report.samples.length,3);
  for(const sample of report.samples){
    const sampleRoot=path.join(root,`sample-${String(sample.index).padStart(3,'0')}`);
    const owned=await readArchived(path.join(sampleRoot,'native-perf-owned.json'));
    assert.deepEqual(owned,sample.owned);
    const bound=checkBound(await readArchived(path.join(sampleRoot,'native-perf-sdk-journey-bound.json')),owned,sample.processId,sample.port);
    assert.deepEqual(bound,sample.bound);
    const authFile=path.join(sampleRoot,'native-perf-auth-attribution.json');
    if(!archived.has(normalizeWindowsPath(authFile))){
      assert.equal(sample.success,false);assert.equal(sample.nativeProof.reason,'ocr-picker-controls-changed');
      missing++;records.push({stage:name,objects,index:sample.index,journeySuccess:false,
        nativeReason:sample.nativeProof.reason,authDiagnosticPublished:false,authDiagnosticAccepted:false});continue;
    }
    const raw=await readArchived(authFile);
    let oldError=null;try{oldDescribe(raw,owned,bound);oldAccepted++;}catch(error){oldError=error.message;oldRejected++;}
    if(sample.success){assert.equal(oldError,'Authentication attribution document rejected');assert.equal(raw.binding.source,'http://tauri.localhost/ocr');}
    else{
      assert.equal(oldError,null);assert.equal(sample.nativeProof.reason,'probe-timeout');
      assert.equal(sample.nativeProof.failedStep,'home');assert.equal(raw.frontend.flows.length,0);homeTimeouts++;
    }
    const diagnostic=describeAuthAttribution(raw,owned,bound);
    const maintenance=await readArchived(path.join(sampleRoot,'native-perf-maintenance-admission.json'));
    checkMaintenanceAdmission(maintenance,raw,owned,bound);
    for(const mutate of [v=>v.pid++,v=>v.timeOriginMs++,v=>v.binding.loaderId='foreign',
      v=>v.binding.mainFrameId='foreign',v=>v.binding.navigationEvents++,
      v=>v.binding.source='http://tauri.localhost/ocr?other=1',
      v=>v.binding.source='http://tauri.localhost:1234/ocr',
      v=>v.binding.source='http://foreign.localhost/ocr']){
      const changed=structuredClone(raw);mutate(changed);assert.throws(()=>describeAuthAttribution(changed,owned,bound));
    }
    present++;records.push({stage:name,objects,index:sample.index,journeySuccess:sample.success,
      nativeReason:sample.nativeProof.reason,authDiagnosticPublished:true,authDiagnosticAccepted:true,
      oldConsumerAccepted:oldError===null,oldConsumerError:oldError,
      source:raw.binding.source,authFlows:raw.frontend.flows.length,
      maintenanceFailures:maintenance.failures.length,diagnostic,
      rawArtifactsMatchCommittedRf1147Index:true});
  }
}
assert.equal(records.length,18);assert.equal(present,11);assert.equal(missing,7);
assert.equal(oldRejected,10);assert.equal(oldAccepted,1);assert.equal(homeTimeouts,1);
await writeFile(path.join(stage,'independent-auth-replay.json'),JSON.stringify({task:'RF-1148',accepted:true,
  nativeGuiRunsAdded:0,totalPreservedJourneys:18,publishedAuthDiagnostics:present,
  unpublishedOnOriginalPickerRefusals:missing,oldConsumerActualRejectedOcrRecords:oldRejected,
  oldConsumerAcceptedLoginTimeoutRecords:oldAccepted,allPublishedAuthAndMaintenanceDiagnosticsAccepted:true,
  actualRecordIdentityDocumentClockAndUnknownRouteMutationsRejected:true,
  runtimeAnd94ResourcesUnchanged:true,changedSources:differences,
  originalHomeTimeoutUnfixed:true,originalJourneyFailuresUnchanged:true,
  performanceMetrics:null,fullRF312Accepted:false,records},null,2)+'\n',{flag:'wx'});
process.stdout.write(`RF-1148 replay: ${present} real auth/maintenance records accepted; ${oldRejected} actual old /ocr refusals reproduced; ${missing} original unavailable diagnostics kept unavailable\n`);
