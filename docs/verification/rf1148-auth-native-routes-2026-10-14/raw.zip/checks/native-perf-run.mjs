// Exact original normalizer used by the byte-preserved old auth consumer.
export { normalizeWindowsPath } from '../../tauri/scripts/native-perf-run.mjs';
