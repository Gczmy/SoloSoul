from pathlib import Path
import hashlib,json,re,zipfile
R=Path('D:/SoloSoul');S=Path(__file__).parent;name='rf1148-auth-native-routes-2026-10-14';O=R/'docs/verification'/name
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as out:json.dump(v,out,indent=2);out.write('\n')
replay=load(S/'independent-auth-replay.json');assert replay['accepted'] and replay['publishedAuthDiagnostics']==11
assert replay['oldConsumerActualRejectedOcrRecords']==10 and replay['unpublishedOnOriginalPickerRefusals']==7
assert load(S/'routes-red.receipt.json')['exitCode']==1
for label in ['routes-green','full-node','prettier-final']:assert load(S/(label+'.receipt.json'))['exitCode']==0
def counts(label):
    text=(S/(label+'.stdout.log')).read_text(encoding='utf-8')
    result={k:int(re.search(r'ℹ '+k+r' (\d+)',text).group(1)) for k in ['tests','pass','fail','skipped']}
    return result
assert counts('routes-red')==dict(tests=10,**{'pass':8,'fail':2,'skipped':0})
assert counts('routes-green')==dict(tests=21,**{'pass':21,'fail':0,'skipped':0})
assert counts('full-node')==dict(tests=263,**{'pass':262,'fail':0,'skipped':1})
old=(S/'before-native-perf-auth-contract.mjs').read_text(encoding='utf-8').replace('\r\n','\n')
new=(R/'tauri/scripts/native-perf-auth-contract.mjs').read_text(encoding='utf-8').replace('\r\n','\n')
old=old.replace("      'http://tauri.localhost/search',", "      'http://tauri.localhost/workspace',\n      'http://tauri.localhost/workspace?section=identity',\n      'http://tauri.localhost/search',\n      'http://tauri.localhost/settings/attachments',\n      'http://tauri.localhost/ocr',")
assert old==new
before=load(S/'sources-before.json');after={n:sha(R/n) for n in before}
changed=[n for n,h in before.items() if after[n]!=h]
assert set(changed)=={'tauri/scripts/native-perf-auth-contract.mjs','tauri/scripts/native-perf-auth-attribution.test.mjs'}
put(S/'sources-after.json',after)
pkg=load(S/'runtime.json');assert sha(Path(pkg['exe']))==pkg['sha256']
assert all(sha(Path(row['source']))==sha(Path(row['copy']))==row['sha256'] for row in pkg['resources'])
front=load(R/'build/rf1147-ocr-picker-settlement-20261014/frontend.json');assert all(sha(R/'tauri/dist'/n)==v['sha256'] for n,v in front['files'].items())
base=load(R/'docs/verification/rf1147-ocr-picker-settlement-2026-10-14.json')
raw=R/'docs/verification/rf1147-ocr-picker-settlement-2026-10-14/raw.zip';assert sha(raw)==base['archive']['sha256']
with zipfile.ZipFile(raw) as z:assert z.testzip() is None
members={'checks/'+p.name:p for p in S.iterdir() if p.is_file() and p.suffix in ['.py','.mjs','.json','.log']}
for n in ['tauri/scripts/native-perf-auth-contract.mjs','tauri/scripts/native-perf-auth-attribution.test.mjs',
    'tauri/src-tauri/src/native_perf/sdk_journey.rs','tauri/scripts/native-perf-maintenance-contract.mjs']:
    members['sources/'+n]=R/n
O.mkdir(exist_ok=False);rows=[]
with zipfile.ZipFile(O/'raw.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
    for n,p in sorted(members.items()):
        data=p.read_bytes();z.writestr(n,data);rows.append(dict(member=n,source=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with zipfile.ZipFile(O/'raw.zip') as z:
    assert z.testzip() is None
    for row in rows:
        data=z.read(row['member']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',dict(task='RF-1148',members=rows,allLengthsSha256AndCrcVerified=True,
    programsVaultsCachesAndPrivateDataExcluded=True))
(O/'.gitattributes').write_text('raw.zip -text\n',encoding='utf-8',newline='\n')
put(O.with_suffix('.json'),dict(task='RF-1148',accepted=True,sourceHeadBeforeFix='0d3d3e818d432c07c94745fb7e66e5f9caed919a',
    changedSources=changed,fourExactCurrentSdkRoutesAdded=True,historicalObjectsRecordCompatibilityPreserved=True,
    schemaIdentityDocumentEventsClockPayloadAndDurationGuardsNormalizedBytesUnchanged=True,
    red=counts('routes-red'),targeted=counts('routes-green'),fullNode=counts('full-node'),prettierExitCode=0,
    realAuthDiagnosticsAccepted=11,oldConsumerActualOcrRefusalsReproduced=10,unpublishedDiagnosticsRemainUnavailable=7,
    nativeGuiRunsAdded=0,currentGuiNotRebuilt=True,runtimeSha256=pkg['sha256'],compiled1983InputsDifferOnlyTwoExternalNodeFiles=True,
    frontend38AndResources94Unchanged=True,originalHomeTimeoutNotClaimedFixed=True,originalJourneyFailuresUnchanged=True,
    performanceMetrics=None,fullRF312Accepted=False,goal='active',
    replay=replay,referencedNativeArchive=dict(path='rf1147-ocr-picker-settlement-2026-10-14/raw.zip',sha256=sha(raw),allLengthsSha256AndCrcVerified=True),
    archive=dict(path=name+'/raw.zip',members=len(rows),bytes=(O/'raw.zip').stat().st_size,sha256=sha(O/'raw.zip'),allLengthsSha256AndCrcVerified=True)))
p=R/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';t=p.read_text(encoding='utf-8')
old='- 已关闭：**326 / 338**；实际修复（已关闭）：326；排除：0；待验证/阻塞：5（RF-112、RF-121、RF-312、RF-1109、RF-1128）；暂缓：0；进行中：1；待执行：6。'
assert t.count(old)==1;t=t.replace(old,old.replace('326 / 338','327 / 338').replace('已关闭）：326','已关闭）：327').replace('进行中：1','进行中：0'),1)
row='| 338 | [RF-1148](#rf-1148) | P2 | 认证诊断外部消费者与当前SDK固定路由一致 | RF-1147原生OCR记录及独立Node拒绝；RF-1147独立提交后实施 | [~] 进行中 |'
assert t.count(row)==1;t=t.replace(row,row.replace('[~] 进行中','[x] 完成'),1)
start=t.index('- 当前处理：');end=t.index('\n',start)
t=t[:start]+'- 当前处理：RF-1148已验收，准备独立提交；继续当前Windows PDF原生预览及RF-312本地范围。具体证据推送及RF-121前台准备仍待回复，goal active。'+t[end:]
start=t.index('> 最后更新：');end=t.index('\n',start)
t=t[:start]+'> 最后更新：2026-10-14（RF-1147初始控件稳定及六次OCR、RF-1148外部认证固定路由复核完成；完整主题矩阵及具体证据推送待回复）'+t[end:]
t+='\n\n### RF-1148 执行记录（2026-10-14，完成）\n\n'
t+='- 只增加四个明确的当前SDK固定URL：workspace、固定Identity query、attachments和ocr，保留已接受的旧objects记录格式；没有使用prefix/任意query匹配，schema/身份/main frame/loader/navigation/事件/timeOrigin/私密字段/阶段及预算守卫的其余LF归一字节不变。默认客户端、Rust、前端、依赖、权限和SDK输入不改。\n'
t+='- 三个新的正向/未知路径及变造文档回归在旧消费者上8通过/2失败，修复后认证/维护/OCR定向21通过；完整Node262通过、0失败、1既有文件symlink权限跳过，未改变OS权限。修改的两个文件格式检查最终exit0，初次格式拒绝及实际格式化记录保留，不重跑无关Rust/前端/GUI。\n'
t+='- RF-1147原件索引逐SHA/长度复核的18次保留行程中，11份实际已发布认证/维护诊断全部通过新消费者；旧消费者真实拒绝其中10份/ocr，仍接受一份/login首页超时。对实际记录变造PID、时钟、frame/loader、事件、query/port/foreign origin均拒绝。7次原选择器拒绝未发布认证记录，保持不可用；原失败、空整组统计及首页未发login的事实不改写，不制造GUI样本或声称认证/首页缺陷修复。\n'
t+=f'- 同一GUI`{pkg["sha256"][:12]}`、94资源、38前端产物保持，1983清单只变化两个外部Node文件。[结构化关闭](verification/{name}.json)及[{len(rows)}成员索引](verification/{name}/index.json)长度/SHA/ZIP CRC回读通过，引用448成员RF-1147原生包，不含程序/Vault/缓存。仅RF-1148关闭，累计327/338；原5待验证/6前置待执行保持，goal active，继续当前PDF等本地验证。独立本地提交，具体证据推送仍待授权。\n'
p.write_text(t,encoding='utf-8',newline='\n')
print(json.dumps(dict(task='RF-1148',accepted=True,fullNode=counts('full-node'),nativeRecordsAccepted=11,members=len(rows),closed='327/338')))
