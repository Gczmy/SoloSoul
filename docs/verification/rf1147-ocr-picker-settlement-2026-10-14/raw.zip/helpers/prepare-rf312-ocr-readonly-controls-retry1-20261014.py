from pathlib import Path
import json
R=Path('D:/SoloSoul');T=R/'build';S=T/'rf312-ocr-readonly-controls-retry1-20261014';S.mkdir(exist_ok=False)
p=json.loads((T/'rf312-ocr-readonly-controls-20261014/input-proof.json').read_text(encoding='utf-8'))
with (S/'input-proof.json').open('x',encoding='utf-8') as out:json.dump(p,out,indent=2)
text=(T/'run-rf312-ocr-readonly-controls-20261014.py').read_text(encoding='utf-8')
text=text.replace('rf312-ocr-readonly-controls-20261014','rf312-ocr-readonly-controls-retry1-20261014')
text=text.replace('rf312-ocr-readonly-controls-session-','rf312-ocr-readonly-controls-retry1-session-')
target=T/'run-rf312-ocr-readonly-controls-retry1-20261014.py';compile(text,str(target),'exec')
with target.open('x',encoding='utf-8',newline='\n') as out:out.write(text)
print('same-file ownership guard normalized; old watcher denial retained, GUI/actions/budget unchanged')
