from pathlib import Path
import json
R=Path('D:/SoloSoul');T=R/'build';S=T/'rf312-ocr-readonly-controls-20261014';S.mkdir(exist_ok=False)
p=json.loads((T/'rf1146-native-ocr-20261014/input-proof.json').read_text(encoding='utf-8'))
p['fixtures']=[p['fixtures'][0]];p['scope']='same original100 OCR3 journey with external bounded read-only control observations; not performance baseline'
with (S/'input-proof.json').open('x',encoding='utf-8') as out:json.dump(p,out,indent=2)
text=(T/'run-rf1146-native-media-ocr-20261014.py').read_text(encoding='utf-8')
text=text.replace("S=T/f'rf1146-native-{mode}-20261014'", "S=T/'rf312-ocr-readonly-controls-20261014'")
text=text.replace('rf1146-native-{mode}-20261014/session-before-', 'rf312-ocr-readonly-controls-20261014/session-before-')
text=text.replace('rf1146-native-{mode}-session-{size}-20261014','rf312-ocr-readonly-controls-session-{size}-20261014')
anchor='    began=time.monotonic()'
assert text.count(anchor)==1
insert="""    watcher_command=['C:/Python314/python.exe',str(T/'watch-owned-ocr-controls-20261014.py'),str(S)]
    watcher_stdout=(S/'watcher.stdout.log').open('xb');watcher_stderr=(S/'watcher.stderr.log').open('xb')
    watcher=subprocess.Popen(watcher_command,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=watcher_stdout,stderr=watcher_stderr,creationflags=subprocess.CREATE_NO_WINDOW)
    save('watcher.live.json',dict(pid=watcher.pid,command=watcher_command,inputEventsSent=0,pixelsRead=0,windowTextRead=False))
"""
text=text.replace(anchor,insert+anchor)
anchor='    verify()\n    result=load(output/'
assert text.count(anchor)==1
text=text.replace(anchor,"    watcher_code=watcher.wait(timeout=20);watcher_stdout.close();watcher_stderr.close()\n    save('watcher.receipt.json',dict(exitCode=watcher_code,command=watcher_command,readOnly=True,nativeGuardOrBudgetsChanged=False))\n"+anchor)
target=T/'run-rf312-ocr-readonly-controls-20261014.py';compile(text,str(target),'exec')
with target.open('x',encoding='utf-8',newline='\n') as out:out.write(text)
print('Original100/3 OCR actions and budgets retained; only external readonly metadata observer added')
