"""Read only one frozen synthetic app's published picker HWNDs; no text/input."""
from pathlib import Path
import ctypes,ctypes.wintypes as w,hashlib,importlib.util,json,os,sys,time
R=Path('D:/SoloSoul');S=Path(sys.argv[1]).resolve();P=S/'samples100'
assert S.is_relative_to((R/'build').resolve())
spec=importlib.util.spec_from_file_location('owned_json',R/'tauri/scripts/native-perf-owned-json.py')
owned_json=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned_json)
read=lambda p:owned_json.read_owned_json(p,262144)
proof=json.loads((S/'input-proof.json').read_text(encoding='utf-8-sig'))
exe=Path(proof['runtime']['exe']).resolve()
assert hashlib.sha256(exe.read_bytes()).hexdigest()==proof['runtime']['sha256']
k=ctypes.WinDLL('kernel32',use_last_error=True);u=ctypes.WinDLL('user32',use_last_error=True)
def api(lib,name,args,result):
    f=getattr(lib,name);f.argtypes=args;f.restype=result;return f
open_process=api(k,'OpenProcess',[w.DWORD,w.BOOL,w.DWORD],w.HANDLE)
close=api(k,'CloseHandle',[w.HANDLE],w.BOOL)
wait=api(k,'WaitForSingleObject',[w.HANDLE,w.DWORD],w.DWORD)
image=api(k,'QueryFullProcessImageNameW',[w.HANDLE,w.DWORD,w.LPWSTR,ctypes.POINTER(w.DWORD)],w.BOOL)
times=api(k,'GetProcessTimes',[w.HANDLE,*([ctypes.POINTER(w.FILETIME)]*4)],w.BOOL)
is_window=api(u,'IsWindow',[w.HWND],w.BOOL)
thread_pid=api(u,'GetWindowThreadProcessId',[w.HWND,ctypes.POINTER(w.DWORD)],w.DWORD)
ancestor=api(u,'GetAncestor',[w.HWND,w.UINT],w.HWND)
window=api(u,'GetWindow',[w.HWND,w.UINT],w.HWND)
foreground=api(u,'GetForegroundWindow',[],w.HWND)
visible=api(u,'IsWindowVisible',[w.HWND],w.BOOL)
parent=api(u,'GetParent',[w.HWND],w.HWND)
style=api(u,'GetWindowLongW',[w.HWND,ctypes.c_int],w.LONG)
ctrl_id=api(u,'GetDlgCtrlID',[w.HWND],ctypes.c_int)
get_class=api(u,'GetClassNameW',[w.HWND,w.LPWSTR,ctypes.c_int],ctypes.c_int)
callback_type=ctypes.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
enumerate_children=api(u,'EnumChildWindows',[w.HWND,callback_type,w.LPARAM],w.BOOL)
def require(value,label):
    if not value:raise RuntimeError(label)
def pid(h):
    value=w.DWORD();t=thread_pid(h,ctypes.byref(value));require(t and value.value,'window pid unavailable');return value.value
def cls(h):
    s=ctypes.create_unicode_buffer(64);n=get_class(h,s,64);require(0<n<63,'class unavailable');return s.value
def process_identity(handle):
    require(wait(handle,0)==258,'held process exited')
    buf=ctypes.create_unicode_buffer(32768);size=w.DWORD(32768)
    require(image(handle,0,buf,ctypes.byref(size)),'process image unavailable')
    require(Path(buf.value).samefile(exe),'process image differs')
    values=[w.FILETIME() for _ in range(4)]
    require(times(handle,*[ctypes.byref(x) for x in values]),'process creation unavailable')
    return (values[0].dwHighDateTime<<32)|values[0].dwLowDateTime
def identity(owner,main,dialog):
    require(is_window(main) and is_window(dialog),'picker/window no longer live')
    require(pid(main)==pid(dialog)==owner,'picker process differs')
    require(cls(dialog)=='#32770' and window(dialog,4)==main,'direct picker owner differs')
def snapshot(owner,dialog,h):
    require(is_window(h) and pid(h)==owner and ancestor(h,2)==dialog,'child ownership differs')
    p=parent(h);require(p,'child parent unavailable')
    s=style(h,-16)&0xffffffff;c=cls(h)
    result=dict(hwnd=int(h),parent=int(p),**{'class':c},id=ctrl_id(h),visible=bool(visible(h)),enabled=not bool(s&0x08000000),password=c=='Edit' and bool(s&0x20))
    require(is_window(h) and pid(h)==owner and ancestor(h,2)==dialog,'child changed during observation')
    return result
def tree(owner,dialog):
    handles=[];errors=[]
    @callback_type
    def collect(h,_):
        if pid(h)!=owner or len(handles)>=128:errors.append('budget/ownership refusal');return False
        handles.append(int(h));return True
    enumerate_children(dialog,collect,0);require(not errors and handles,'controls unavailable/over budget')
    return [snapshot(owner,dialog,h) for h in handles]
def difference(expected,observed):
    a={x['hwnd']:x for x in expected};b={x['hwnd']:x for x in observed}
    return dict(added=[b[h] for h in b.keys()-a.keys()],removed=[a[h] for h in a.keys()-b.keys()],
        changed=[dict(hwnd=h,fields={key:dict(expected=a[h][key],observed=b[h][key]) for key in a[h] if a[h][key]!=b[h][key]}) for h in a.keys()&b.keys() if a[h]!=b[h]],
        orderChanged=[x['hwnd'] for x in expected]!=[x['hwnd'] for x in observed])
rows=[];deadline=time.monotonic()+300
for index in range(1,4):
    sample=P/f'sample-{index:03}';target=sample/'native-perf-ocr-picker-structure.json'
    while not target.exists():
        if (P/'native-perf-sdk-journey-results.json').exists() or time.monotonic()>deadline:break
        time.sleep(.01)
    if not target.exists():rows.append(dict(index=index,pickerStructureMissing=True));continue
    held=None;row=dict(index=index,observations=[],inputEventsSent=0,windowTextRead=False,pixelsRead=0,atomicIdentityOrInputAuthority=False)
    try:
        initial=read(target);owned=read(sample/'native-perf-owned.json');consumed=read(sample/'native-perf-consumed.json');bound=read(sample/'native-perf-sdk-journey-bound.json')
        owner=int(initial['pid']);main=int(initial['mainHwnd']);dialog=int(initial['dialogHwnd'])
        require(initial['scope']=='owned-ocr-native-file-picker-structure' and initial['schemaVersion']==1,'structure scope invalid')
        require(owner==consumed['pid']==bound['pid'] and owned['runId']==consumed['runId']==bound['runId'],'run/pid binding differs')
        require(Path(owned['root']).samefile(sample),'owned root differs')
        for ancestor_path in [sample,*sample.parents]:
            require(not ancestor_path.lstat().st_file_attributes&0x400,'owned root ancestor is reparse')
            if ancestor_path==S:break
        held=open_process(0x1000|0x100000,False,owner);require(held,'cannot hold process identity')
        birth=process_identity(held);identity(owner,main,dialog)
        row.update(pid=owner,runId=owned['runId'],creationTicks=birth,initial=initial)
        previous=None;began=time.monotonic()
        while time.monotonic()-began<15:
            require(process_identity(held)==birth,'held process identity changed');identity(owner,main,dialog)
            actual=tree(owner,dialog);identity(owner,main,dialog);require(process_identity(held)==birth,'held process changed')
            state=dict(controls=actual,foregroundEqualsDialog=ancestor(foreground(),2)==dialog)
            if state!=previous:
                row['observations'].append(dict(hostMonotonicNs=time.perf_counter_ns(),**state,difference=difference(initial['controls'],actual)))
                previous=state
            if (sample/'native-perf-sdk-journey.json').exists():break
            time.sleep(.01)
    except Exception as e:row['observationStoppedReason']=str(e)
    finally:
        if held:require(close(held),'process handle close failed')
        with (S/f'picker-readonly-sample-{index:03}.json').open('x',encoding='utf-8') as out:json.dump(row,out,indent=2)
        rows.append(dict(index=index,observations=len(row['observations']),stopped=row.get('observationStoppedReason')))
        print('readonly picker',index,rows[-1],flush=True)
with (S/'picker-readonly-terminal.json').open('x',encoding='utf-8') as out:json.dump(dict(rows=rows,inputEventsSent=0,windowTextRead=False,pixelsRead=0,performanceAccepted=False,diagnosticOnly=True),out,indent=2)
