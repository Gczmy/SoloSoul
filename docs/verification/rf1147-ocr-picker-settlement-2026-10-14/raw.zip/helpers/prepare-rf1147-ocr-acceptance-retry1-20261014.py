from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');T=R/'build';B=T/'rf1147-ocr-picker-settlement-20261014';S=T/'rf1147-ocr-acceptance-retry1-20261014'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pkg=load(B/'runtime-package.json');assert sha(Path(pkg['exe']))==pkg['sha256']
assert load(B/'native-release.receipt.json')['exitCode']==0 and load(B/'native-tests.receipt.json')['exitCode']==0
sources=load(B/'sources.json');assert all(sha(R/n)==h for n,h in sources.items())
assert all(sha(Path(x['source']))==sha(Path(x['copy']))==x['sha256'] for x in pkg['resources'])
proof=load(T/'rf1146-native-ocr-20261014/input-proof.json')
proof.update(runtime=pkg,sources=sources,validationHead='1ba71e8506f6ea25ad7e18e9dad6bf18d943a15d',sourceHasUncommittedRf1147Fix=True)
proof.pop('originalNativeSdkBudgetAndInputAndReadinessContractsPreserved',None)
proof['initialWholeTreeSettlementWithinOriginal25SecondBudgetAdded']=True
proof['originalOwnershipMessageAndInputChecksPreserved']=True
proof['diagnosticObserversAdded']=False
for fixture in proof['fixtures']:
    p=Path(fixture['path']);assert {f.relative_to(p).as_posix():sha(f) for f in p.rglob('*') if f.is_file()}==fixture['files']
S.mkdir(exist_ok=False)
with (S/'input-proof.json').open('x',encoding='utf-8',newline='\n') as out:json.dump(proof,out,indent=2);out.write('\n')
runner=(T/'run-rf1146-native-media-ocr-20261014.py').read_text(encoding='utf-8')
runner=runner.replace("S=T/f'rf1146-native-{mode}-20261014'", "S=T/'rf1147-ocr-acceptance-retry1-20261014'")
runner=runner.replace('rf1146-native-{mode}-20261014/session-before-','rf1147-ocr-acceptance-retry1-20261014/session-before-')
runner=runner.replace('rf1146-native-{mode}-session-{size}-20261014','rf1147-ocr-acceptance-session-{size}-20261014')
p=T/'run-rf1147-ocr-acceptance-retry1-20261014.py';compile(runner,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as out:out.write(runner)
print('New frozen GUI original OCR100/5000 each3 full acceptance prepared; no external observer or changed input sequence')
