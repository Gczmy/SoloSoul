from pathlib import Path
import datetime, hashlib, importlib.util, json, math, os, re, socket, subprocess, time
from PIL import Image
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf1132-card-high-contrast-native-20261012'
H=B/'api31-host-rf1132-20261012';D=B/'rf1132-card-high-contrast-build-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
spec=importlib.util.spec_from_file_location('home',R/'tauri/scripts/android-home-native-regression.py');home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
v=load(S/'result.json');assert v['passed'] and len(v['cases'])==5
inputs=load(D/'current-apks.json')
assert all(sha(R/n)==h for n,h in inputs['sourceFiles'].items())
assert all(sha(Path(r['copy']))==r['sha256'] for r in inputs['files'])
assert home.inventory(S/'private-before.tar',True)==home.inventory(S/'private-restored.tar',True)
assert load(S/'private-before-inventory.json')==load(S/'private-restored-inventory.json')
assert v['privateRestored']['entries']==216 and v['finalSystem']==v['originalSystem']
pixels=[];ratios=[]
def lum(css):
    m=re.fullmatch(r'rgb\((\d+),\s*(\d+),\s*(\d+)\)',css);assert m
    c=[int(x)/255 for x in m.groups()]
    return sum(w*(x/12.92 if x<=0.04045 else ((x+0.055)/1.055)**2.4) for w,x in zip([0.2126,0.7152,0.0722],c))
for case in v['cases']:
    C=S/case['name'];raw=(C/'native.log').read_text(encoding='utf-8')
    if case['negativeControl']:
        assert case['strictSuccessReaderRejected'] and case['expectedAssertionRejected']
        assert 'Tests run: 1,  Failures: 1' in raw and 'expected:<true> but was:<false>' in raw
        try: home.verify_native(raw,'lightAndDarkHighTextContrastCardsRenderWithoutOverflow')
        except RuntimeError: pass
        else: raise AssertionError('Negative control accepted')
        continue
    enabled=case['enabled'];prefix='rf121-hc' if enabled else 'rf121'
    home.verify_native(raw,'lightAndDarkHighTextContrastCardsRenderWithoutOverflow' if enabled else 'lightAndDarkCardsRenderWithoutOverflow')
    rows=load(C/(prefix+'-android-card-surfaces.json'));assert len(rows)==2
    for row in rows:
        assert row['appearance']['highContrast'] is enabled and not row['pageOverflow'] and not row.get('error')
        if enabled: assert row['nativeHighTextContrast']['rawBeforeAndAfter']=='1' and row['nativeHighTextContrast']['enabled'] is True
        for card,pixel in zip(row['cards'],row['nativePixels']):
            assert card['visible'] and not card['overflow'] and card['expectedBackground']==card['background']
            path=C/f"{prefix}-card-{row['theme']}-{card['surface']}.png"
            with Image.open(path) as im:
                rgb=list(im.convert('RGB').getpixel((pixel['pixelX'],pixel['pixelY'])))
                assert rgb==pixel['pixelRgb']
                expected=[int(x) for x in re.fullmatch(r'rgb\((\d+),\s*(\d+),\s*(\d+)\)',pixel['expectedBackground']).groups()]
                assert all(abs(a-b)<=6 for a,b in zip(rgb,expected))
                pixels.append({'case':case['name'],'theme':row['theme'],'surface':card['surface'],'file':str(path),
                               'sha256':sha(path),'width':im.width,'height':im.height,'actual':rgb,'expected':expected})
            if enabled:
                a,b=sorted([lum(card['color']),lum(card['background'])]);ratio=(b+.05)/(a+.05)
                assert ratio>=4.5 and math.isclose(ratio,card['textContrastRatio'],abs_tol=1e-12)
                ratios.append(ratio)
assert len(pixels)==16 and len(ratios)==8
commands=load(S/'commands.json');assert all(c['exitCode']==0 for c in commands)
assert len([c for c in commands if c['args'][:3]==['shell','am','instrument']])==5
kt='tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidCardSurfaceInstrumentedTest.kt'
old=(B/'rf1132-card-high-contrast-20261012/AndroidCardSurfaceInstrumentedTest.kt.before').read_text(encoding='utf-8')
current=(R/kt).read_text(encoding='utf-8')
marker='    @Test fun sharedThemeLiquidRendersAndRecoversWithoutContinuousDrawing()';assert old[old.index(marker):]==current[current.index(marker):]
build={}
for name in ['kotlin-unit-tests','test-build','test-badging','test-signature','main-existing-signature']:
    receipt=load(D/(name+'.receipt.json'));assert receipt['exitCode']==0;build[name]=receipt
assert ':app:compileX86_64DebugAndroidTestKotlin' in (D/'test-build.stdout.log').read_text(encoding='utf-8')
assert ':app:compileX86_64DebugAndroidTestKotlin UP-TO-DATE' not in (D/'test-build.stdout.log').read_text(encoding='utf-8')
verification={'accepted':True,'observedNativeDriverExitCode':0,'positiveNativeTests':4,'expectedNegativeAssertions':1,
              'skipped':0,'pixels':pixels,'computedTextContrastRatios':ratios,'minimumComputedTextContrast':min(ratios),
              'privateAndSystemRestored':True,'all216PrivateEntriesExact':True,'sourceInputCount':len(inputs['sourceFiles']),
              'productionSourcesChanged':False,'independentLiquidTestSourceUnchanged':True,'actualKotlinInstrumentationCompile':True,
              'unitTaskUpToDateNotFreshRun':True,'retainedUnitXmlTests':10,'buildReceipts':build,
              'all16PngsPixelReadbackVerified':True,'allPngsHumanReviewed':False,
              'humanReviewedImages':['normal-supported/rf121-card-light-default.png','hc-supported/rf121-hc-card-light-default.png','hc-fallback/rf121-hc-card-dark-floating.png'],
              'actualRenderedTextPixelsFullyValidated':False,'fullApplicationAccessibilityAccepted':False,'fullRF121Accepted':False}
put(S/'independent-validation.json',verification)
owned=next(x for x in load(H/'owned-processes-after-launch.json') if x['ProcessId']==27820)
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
def identity():
    p=subprocess.run([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {owned['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3"],check=True,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
    return json.loads(p.stdout) if p.stdout.strip() else None
live=identity();assert live
for key in ['Name','ProcessId','ExecutablePath','CommandLine']:assert live[key]==owned[key],key
assert datetime.datetime.fromisoformat(live['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
env=os.environ.copy();env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',TEMP=str(B/'tmp'),TMP=str(B/'tmp'))
def read(args):
    return subprocess.run([str(B/'sdk/platform-tools/adb.exe'),'-H','localhost','-P','5049','-s','emulator-5586',*args],env=env,check=True,capture_output=True,text=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW).stdout.strip()
assert read(['emu','avd','name']).splitlines()[0]=='SoloSoul_RF121_API31_20261010'
raw={'contrast':read(['shell','settings','get','secure','high_text_contrast_enabled']),
     'blur':read(['shell','settings','get','global','disable_window_blurs']),
     'font':read(['shell','settings','get','system','font_scale']),
     'animations':read(['shell','settings','get','global','animator_duration_scale']),
     'night':read(['shell','cmd','uimode','night']),
     'effectiveFont':home.activity_font_scale(read(['shell','dumpsys','activity','processes']))}
assert raw==v['originalSystem']
stopped={'identity':live,'originalSystemStillExact':True,'settings':raw,'noForceTermination':True,'response':read(['emu','kill'])}
deadline=time.monotonic()+40
while identity() is not None:
    assert time.monotonic()<deadline;time.sleep(1)
for port in [5586,5587]:
    with socket.socket() as sock:sock.bind(('127.0.0.1',port))
stopped.update(ownedProcessExited=True,dedicatedPortsFree=True,at=datetime.datetime.now(datetime.timezone.utc).isoformat())
put(H/'rf1132-stop.receipt.json',stopped)
print('RF1132 independently accepted: 4 native passes + 1 expected rejection, 16 PNG probes, 8 text ratios; exact emulator gracefully exited',flush=True)
