from pathlib import Path
import hashlib, importlib.util, json, os, re, subprocess, sys, time, uuid

R = Path('D:/SoloSoul')
B = Path(__file__).parent
S = B / 'rf1132-card-high-contrast-native-20261012'
S.mkdir(exist_ok=False)
APP = 'com.solosoul.app'
SERIAL = 'emulator-5586'
AVD = 'SoloSoul_RF121_API31_20261010'
ADB = B / 'sdk/platform-tools/adb.exe'
env = os.environ.copy()
env.update(ANDROID_ADB_SERVER_PORT='5049', ADB_SERVER_SOCKET='tcp:localhost:5049',
           TEMP=str(B/'tmp'), TMP=str(B/'tmp'), PYTHONUTF8='1')
spec = importlib.util.spec_from_file_location('home', R/'tauri/scripts/android-home-native-regression.py')
home = importlib.util.module_from_spec(spec)
spec.loader.exec_module(home)
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs = load(B/'rf1132-card-high-contrast-build-20261012/current-apks.json')
report = {'passed': False, 'scope': 'real Android high-text-contrast setting bound to standalone production Card',
          'fullApplicationAccessibilityAccepted': False, 'windowsForcedColorsAccepted': False,
          'cases': [], 'sourceFiles': inputs['sourceFiles'], 'apkFiles': inputs['files']}
commands = []
original = None
before = None
remote_backup = None
backup = S/'private-before.tar'
restored = S/'private-restored.tar'

def save(path, obj):
    path.write_text(json.dumps(obj, indent=2), encoding='utf-8', newline='\n')

def frozen():
    assert all(sha(R/n) == h for n,h in inputs['sourceFiles'].items()), 'Source changed'
    assert all(sha(Path(row['copy'])) == row['sha256'] for row in inputs['files']), 'APK changed'

def run(*args, timeout=60, check=True, binary=False):
    cmd = [str(ADB), '-s', SERIAL, *args]
    start = time.monotonic()
    p = subprocess.run(cmd, env=env, stdin=subprocess.DEVNULL, capture_output=True,
                       timeout=timeout, creationflags=subprocess.CREATE_NO_WINDOW)
    commands.append({'args': list(args), 'exitCode': p.returncode,
                     'elapsedSeconds': time.monotonic()-start,
                     'stdoutSha256': hashlib.sha256(p.stdout).hexdigest(),
                     'stderr': p.stderr.decode('utf-8',errors='replace')})
    if check and p.returncode: raise RuntimeError(f'ADB failed: {args}; {p.stderr!r}')
    return p.stdout if binary else p.stdout.decode('utf-8').strip()

def setting(space, key): return run('shell','settings','get',space,key)

def system_state():
    return {'contrast': setting('secure','high_text_contrast_enabled'),
            'blur': setting('global','disable_window_blurs'),
            'font': setting('system','font_scale'),
            'animations': setting('global','animator_duration_scale'),
            'night': run('shell','cmd','uimode','night'),
            'effectiveFont': home.activity_font_scale(run('shell','dumpsys','activity','processes'))}

def restore_setting(space,key,value):
    run('shell','settings','delete' if value=='null' else 'put',space,key,
        *([] if value=='null' else [value]))
    assert setting(space,key)==value, f'Exact setting restoration failed: {key}'

def archive(path):
    path.write_bytes(run('exec-out','run-as',APP,'tar','-cf','-','.',binary=True))
    os.chmod(path,0o600)
    return home.inventory(path,require_empty=True)

def validate_cards(path, enabled):
    rows = load(path)
    assert len(rows)==2 and [x['theme'] for x in rows]==['light','dark']
    for row in rows:
        assert not row.get('error') and not row['pageOverflow']
        assert row['appearance']['highContrast'] is enabled
        assert len(row['cards'])==2 and len(row['nativePixels'])==2
        if enabled:
            native=row['nativeHighTextContrast']
            assert native['source']=='android.provider.Settings.Secure'
            assert native['rawBeforeAndAfter']=='1' and native['enabled'] is True
            assert native['windowsForcedColorsAcceptance'] is False
        for card, pixel in zip(row['cards'],row['nativePixels']):
            assert card['visible'] and not card['overflow'] and card['color']!=card['background']
            assert pixel['expectedBackground']==pixel['background']
            rgb=re.fullmatch(r'rgb\((\d+),\s*(\d+),\s*(\d+)\)',pixel['background'])
            assert rgb and all(abs(a-int(b))<=6 for a,b in zip(pixel['pixelRgb'],rgb.groups()))
            if enabled: assert card['textContrastRatio']>=4.5
    return {'themes':2,'surfacesPerTheme':2,'nativePixelChecks':4,'overflowChecks':4,
            'actualHighTextContrast':enabled,
            'textRatios': [c['textContrastRatio'] for r in rows for c in r['cards']] if enabled else []}

try:
    frozen()
    assert run('get-state')=='device'
    assert run('emu','avd','name').splitlines()[0]==AVD
    assert run('shell','getprop','ro.build.version.sdk')=='31'
    assert run('shell','getprop','ro.product.cpu.abi')=='x86_64'
    original=system_state()
    assert original['contrast'] in ('null','0','1') and original['blur'] in ('null','0','1')
    assert original['animations']=='null' or float(original['animations'])>0
    run('shell','am','force-stop',APP)
    root_mode=run('shell','run-as',APP,'stat','-c','%a','.')
    assert re.fullmatch(r'[0-7]{3,4}',root_mode)
    before=archive(backup)
    report.update(originalSystem=original,privateBefore={'sha256':sha(backup),'entries':len(before),'rootMode':root_mode})
    save(S/'private-before-inventory.json',before)
    for row in inputs['files']:
        text=run('install','-r',row['copy'],timeout=180)
        assert 'Success' in text
    default='lightAndDarkCardsRenderWithoutOverflow'
    hc='lightAndDarkHighTextContrastCardsRenderWithoutOverflow'
    for name,mode,enabled,negative in [
        ('normal-supported','supported',False,False),
        ('normal-fallback','fallback',False,False),
        ('hc-wrong-system-rejected','supported',False,True),
        ('hc-supported','supported',True,False),
        ('hc-fallback','fallback',True,False),
    ]:
        frozen()
        C=S/name;C.mkdir()
        case={'name':name,'mode':mode,'enabled':enabled,'negativeControl':negative,'passed':False}
        report['cases'].append(case)
        run('shell','settings','put','secure','high_text_contrast_enabled','1' if enabled else '0')
        run('shell','settings','put','global','disable_window_blurs','1' if mode=='fallback' else '0')
        assert setting('secure','high_text_contrast_enabled')==('1' if enabled else '0')
        assert setting('global','disable_window_blurs')==('1' if mode=='fallback' else '0')
        (C/'accessibility.log').write_text(run('shell','dumpsys','accessibility'),encoding='utf-8',newline='\n')
        method=hc if enabled or negative else default
        run('shell','am','force-stop',APP)
        raw=run('shell','am','instrument','-w','-r','-e','class',
                f'{APP}.AndroidCardSurfaceInstrumentedTest#{method}',
                APP+'.test/androidx.test.runner.AndroidJUnitRunner',timeout=90)
        (C/'native.log').write_text(raw,encoding='utf-8',newline='\n')
        if negative:
            try: home.verify_native(raw,method)
            except RuntimeError: case['strictSuccessReaderRejected']=True
            else: raise AssertionError('Wrong native mode was accepted')
            statuses=[int(n) for n in re.findall(r'^INSTRUMENTATION_STATUS_CODE:\s*(-?\d+)\s*$',raw,re.M)]
            assert statuses==[1,-2] and 'Tests run: 1,  Failures: 1' in raw
            assert 'Actual Android system contrast must match the explicit lane' in raw
            assert 'java.lang.AssertionError' in raw and 'Process crashed' not in raw
            case['expectedAssertionRejected']=True
        else:
            home.verify_native(raw,method)
            prefix='rf121-hc' if enabled else 'rf121'
            names=[f'{prefix}-android-card-surfaces.json']
            names += [f'{prefix}-card-{theme}-dom.json' for theme in ('light','dark')]
            names += [f'{prefix}-card-{theme}-{surface}.png' for theme in ('light','dark') for surface in ('default','floating')]
            for filename in names:
                run('pull',f'/sdcard/Android/data/{APP}/files/{filename}',str(C/filename))
            case['validation']=validate_cards(C/names[0],enabled)
            case['nativePassed']=True
        assert setting('secure','high_text_contrast_enabled')==('1' if enabled else '0')
        frozen();case['passed']=True;save(C/'case.json',case)
        save(S/'progress.json',report)
        print(name,'PASS',flush=True)
except Exception as error:
    report['error']=repr(error)
    print('RF1132 failed:',repr(error),flush=True)
finally:
    try:
        if before is not None:
            run('shell','am','force-stop',APP)
            names=run('shell','run-as',APP,'ls','-A').splitlines()
            assert all(re.fullmatch(r'[A-Za-z0-9_.-]+',n) and n not in ('.','..') for n in names)
            if names: run('shell','run-as',APP,'rm','-rf','--',*names)
            remote_backup='/data/local/tmp/rf1132-backup-'+uuid.uuid4().hex+'.tar'
            run('push',str(backup),remote_backup)
            run('shell','chmod','644',remote_backup)
            run('shell','run-as',APP,'tar','-xpf',remote_backup)
            run('shell','run-as',APP,'chmod',root_mode,'.')
            after=archive(restored)
            save(S/'private-restored-inventory.json',after)
            assert before==after, 'Private contents/links/modes changed'
            assert run('shell','run-as',APP,'stat','-c','%a','.')==root_mode
            run('shell','rm',remote_backup)
            report['privateRestored']={'allContentsLinksModesExact':True,'rootModeExact':True,'entries':len(after),
                                       'restoredTarSha256':sha(restored)}
    except Exception as error: report['privateRestoreError']=repr(error)
    try:
        if original is not None:
            restore_setting('secure','high_text_contrast_enabled',original['contrast'])
            restore_setting('global','disable_window_blurs',original['blur'])
            actual=system_state();report['finalSystem']=actual
            assert actual==original, 'Original system settings/configuration differ'
            assert system_state()==original, 'System settings changed after readback'
            report['systemRestored']=True
    except Exception as error: report['systemRestoreError']=repr(error)
    try: frozen();report['sourceAndApkInputsUnchanged']=True
    except Exception as error: report['sourceError']=repr(error)
    report['passed']=bool(len(report['cases'])==5 and all(c['passed'] for c in report['cases'])
                          and report.get('privateRestored') and report.get('systemRestored')
                          and report.get('sourceAndApkInputsUnchanged')
                          and not any(k.endswith('Error') or k=='error' for k in report))
    save(S/'commands.json',commands);save(S/'result.json',report)
    print('RF1132 final',report['passed'],'restored',bool(report.get('privateRestored')),report.get('systemRestored'),flush=True)
sys.exit(0 if report['passed'] else 1)
