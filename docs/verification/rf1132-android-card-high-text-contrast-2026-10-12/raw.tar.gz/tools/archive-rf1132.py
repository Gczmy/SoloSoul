from pathlib import Path
import hashlib, io, json, tarfile
R=Path('D:/SoloSoul');B=Path(__file__).parent
N='rf1132-android-card-high-text-contrast-2026-10-12';O=R/'docs/verification'/N
S=B/'rf1132-card-high-contrast-native-20261012';D=B/'rf1132-card-high-contrast-build-20261012';H=B/'api31-host-rf1132-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
v=load(S/'independent-validation.json');assert v['accepted'] and len(v['pixels'])==16
result=load(S/'result.json');assert result['passed']
stop=load(H/'rf1132-stop.receipt.json');assert stop['ownedProcessExited'] and stop['originalSystemStillExact'] and stop['dedicatedPortsFree']
inputs=load(D/'current-apks.json');assert all(sha(R/n)==h for n,h in inputs['sourceFiles'].items())
assert all(sha(Path(row['copy']))==row['sha256'] for row in inputs['files'])
failures={'nativeDriverObservedExitCode':0,'independentVerifierObservedExitCodes':[1,1,0],
          'initialVerifierError':'ValueError: substring not found',
          'initialVerifierReason':'ASCII FE2 colon marker differed from fullwidth colon in existing source comment',
          'attemptedShellCorrectionError':'SyntaxError: ( was never closed; file unchanged',
          'secondVerifierError':'same ValueError: substring not found',
          'readonlyInspectionError':'cp1252 stdout could not print Chinese comment; no code or device mutation',
          'correctedVerifierOnlyAsciiSourceMarkerChanged':True,'nativeTestsRerunAfterVerifierFix':False,
          'expectedWrongSystemNativeFailureRetained':True,'unexpectedNativeFailures':0,
          'deviceDataAndSettingsHadRestoredBeforeAllVerifierCalls':True}
put(S/'observed-tool-outcomes.json',failures)
assert not O.exists();O.mkdir();members={}
for prefix,parent in [('native',S),('build',D),('boot',H),('before',B/'rf1132-card-high-contrast-20261012')]:
 for p in parent.rglob('*'):
  if p.is_file() and p.suffix in ('.json','.log','.png','.xml','.before'):
   assert not(p.stat().st_file_attributes&0x400)
   members[prefix+'/'+p.relative_to(parent).as_posix()]=p
for name in ['run-rf1132-card-high-contrast.py','build-rf1132-card-high-contrast.py','boot-rf1132-api31-host.py','verify-stop-rf1132.py','verify-stop-rf1132.py.first-rejected','archive-rf1132.py']:
 members['tools/'+name]=B/name
for name in ['tauri/native-regression/card-surfaces/README.md','tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidCardSurfaceInstrumentedTest.kt']:
 members['sources/'+name]=R/name
rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as archive:
 for name,p in sorted(members.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  archive.addfile(info,io.BytesIO(data));rows.append({'member':name,'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(O/'raw.tar.gz') as archive:
 assert len(archive.getmembers())==len(rows)
 for row in rows:
  data=archive.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',{'task':'RF-1132','members':rows,'allMembersReadbackVerified':True,'privateTarsAndApksExcluded':True})
(O/'.gitattributes').write_text('raw.tar.gz -text\n*.json text eol=lf\n',encoding='utf-8',newline='\n')
cleanup=[{'path':str(S/name),'sha256':sha(S/name),'bytes':(S/name).stat().st_size} for name in ['private-before.tar','private-restored.tar']]
put(B/'rf1132-private-cleanup-plan.json',{'ownedStage':str(S),'files':cleanup,'requiresPublishedArchiveReadback':True,'requiresOwnedEmulatorExited':True})
summary={'task':'RF-1132','sourceHead':'3b69f0bf1','accepted':True,
         'scope':'standalone production Android Card native high-text-contrast fixture; no production application code changed',
         'device':{'api':31,'abi':'x86_64','avd':'SoloSoul_RF121_API31_20261010','gpu':'host','adbPort':5049},
         'nativeTestsPassed':4,'expectedWrongSystemAssertionFailures':1,'unexpectedNativeFailures':0,'nativeSkipped':0,
         'nativePixelChecks':16,'computedTextContrastChecks':8,'minimumComputedTextContrast':v['minimumComputedTextContrast'],
         'allPrivateContentsLinksModesExact':True,'privateEntries':216,'allSystemSettingsExact':True,
         'originalSystem':result['originalSystem'],'finalSystem':result['finalSystem'],
         'newTestApkSha256':next(x['sha256'] for x in inputs['files'] if x['kind']=='test'),
         'originalMainApkSha256':inputs['mainApkSha256'],'originalMainApkByteUnchanged':True,
         'currentSourceFiles':len(inputs['sourceFiles']),'originalMainBuildSourcesDifferAt':list(inputs['sourceDifferences']),
         'actualKotlinInstrumentationCompile':True,'unitTaskUpToDateNotFreshRun':True,'retainedUnitXmlTests':10,
         'independentValidation':v,'toolOutcomes':failures,'ownedEmulatorGracefullyExited':True,
         'fullApplicationAccessibilityAccepted':False,'fullRF121Accepted':False,'RF312Accepted':False,'windowsForcedColorsAccepted':False,
         'cleanupPendingExactLocalTarCopies':2,'archive':{'path':N+'/raw.tar.gz','members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha(O/'raw.tar.gz'),'allMembersReadbackVerified':True}}
put(R/'docs/verification'/(N+'.json'),summary)
print(json.dumps({'accepted':True,'members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'cleanupExactFiles':2}))
