from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf1132-card-high-contrast-build-20261012';S.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=load(B/'rf1126-legacy-theme-build-20261011/current-apks.json')
current={n:sha(R/n) for n in old['sourceFiles']}
diff={n:{'originalSha256':h,'currentSha256':current[n]} for n,h in old['sourceFiles'].items() if current[n]!=h}
expected={'tauri/native-regression/card-surfaces/README.md','tauri/scripts/android-home-native-regression.py','tauri/scripts/test_android_home_native_regression.py','tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidCardSurfaceInstrumentedTest.kt','tauri/src-tauri/src/native_perf/sdk_surface_appearance.rs','tauri/scripts/native-perf-preference-contract.mjs','tauri/scripts/native-perf-preference.node.test.mjs'}
assert set(diff)==expected
def save(n,v):
 with (S/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2)
def verify():
 assert all(sha(R/n)==h for n,h in current.items())
 assert all(sha(Path(row['copy']))==row['sha256'] for row in old['files'])
verify();save('sources.json',current);save('input-proof.json',{'oldBuildSourceFiles':old['sourceFiles'],'currentTestBuildSources':current,'differences':diff,'mainProductCodeChanged':False,'newCompiledChange':'AndroidCardSurfaceInstrumentedTest.kt','nonApkChangesDocumentedSeparately':True})
g=R/'tauri/src-tauri/gen/android';jdk=Path('C:/Users/40299571/ss-android/jdk');sdk=B/'sdk'
env=os.environ.copy();env.update(JAVA_HOME=str(jdk),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),NDK_HOME=str(sdk/'ndk/27.0.12077973'),ANDROID_NDK_HOME=str(sdk/'ndk/27.0.12077973'),ANDROID_USER_HOME=str(B/'android-user'),ANDROID_EMULATOR_HOME=str(B/'android-user'),ANDROID_AVD_HOME=str(B/'avd'),ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',RUSTUP_HOME=str(B/'rustup'),RUSTUP_TOOLCHAIN='1.96.0',CARGO_HOME=str(B/'cargo-home'),CARGO_TARGET_DIR=str(B/'cargo-target'),CARGO_BUILD_JOBS='1',GRADLE_USER_HOME=str(B/'gradle-home'),ORT_CACHE_DIR=str(B/'ort-cache'),TEMP=str(B/'tmp'),TMP=str(B/'tmp'),JAVA_TOOL_OPTIONS=f'-Duser.home={B/"java-home"} -Djava.io.tmpdir={B/"tmp"}')
for key in ['ANDROID_SDK_HOME','PDFIUM_LIBRARY_PATH','SOLOSOUL_KEYSTORE_PATH','SOLOSOUL_KEYSTORE_PASSWORD','SOLOSOUL_KEY_ALIAS','SOLOSOUL_KEY_PASSWORD','SOLOSOUL_REGISTRY_PUBKEY']:env.pop(key,None)
env['PATH']=str(jdk/'bin')+';'+env.get('PATH','')
def run(n,cmd,cwd=g):
 verify();start=time.monotonic()
 with (S/(n+'.stdout.log')).open('xb') as out,(S/(n+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  save(n+'.live.json',{'pid':p.pid,'command':cmd});print(n,'PID',p.pid,flush=True);code=p.wait()
 verify();save(n+'.receipt.json',{'exitCode':code,'command':cmd,'elapsedSeconds':time.monotonic()-start,'sourcesUnchanged':True});print(n,'exit',code,flush=True);assert code==0
def gradle(task):return ['cmd.exe','/d','/c',str(g/'gradlew.bat'),task,'-x',':app:rustBuildX86_64Debug','--init-script',str(B/'current-apks-rf1121-20261011/private-packaging-assets.init.gradle'),'--offline','--no-daemon','--max-workers','2']
run('kotlin-unit-tests',gradle(':app:testX86_64DebugUnitTest'))
(S/'unit-test-xml').mkdir()
for p in (g/'app/build/test-results/testX86_64DebugUnitTest').glob('*.xml'):shutil.copyfile(p,S/'unit-test-xml'/p.name)
run('test-build',gradle(':app:assembleX86_64DebugAndroidTest'))
source=g/'app/build/outputs/apk/androidTest/x86_64/debug/app-x86_64-debug-androidTest.apk';copy=S/source.name;shutil.copyfile(source,copy)
run('test-badging',[str(sdk/'build-tools/35.0.0/aapt2.exe'),'dump','badging',str(copy)],S)
assert "package: name='com.solosoul.app.test'" in (S/'test-badging.stdout.log').read_text(encoding='utf-8')
run('test-signature',[str(jdk/'bin/java.exe'),'-jar',str(sdk/'build-tools/35.0.0/lib/apksigner.jar'),'verify','--verbose','--print-certs',str(copy)],S)
main=next(x for x in old['files'] if x['kind']=='main')
run('main-existing-signature',[str(jdk/'bin/java.exe'),'-jar',str(sdk/'build-tools/35.0.0/lib/apksigner.jar'),'verify','--verbose','--print-certs',main['copy']],S)
import re
cert=lambda p:re.findall(r'certificate SHA-256 digest: (\S+)',p.read_text(encoding='utf-8'))
assert cert(S/'main-existing-signature.stdout.log')==cert(S/'test-signature.stdout.log') and len(cert(S/'test-signature.stdout.log'))==1
files=[main,{'kind':'test','source':str(source),'copy':str(copy),'sha256':sha(copy),'bytes':copy.stat().st_size}]
save('current-apks.json',{'accepted':True,'files':files,'sourceFiles':current,'originalMainBuildSourceFiles':old['sourceFiles'],'sourceDifferences':diff,'mainApkByteUnchanged':True,'mainApkSha256':main['sha256'],'newTestApkOnly':True,'rustRebuilt':False,'defaultProductRebuilt':False,'deviceAcceptance':False,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print('RF1132 test APK built and signer/package verified; original main APK remains byte-identical',flush=True)
