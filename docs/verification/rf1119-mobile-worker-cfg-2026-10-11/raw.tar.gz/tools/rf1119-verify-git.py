from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile
root=Path('D:/SoloSoul');w=Path(__file__).parent;ref=sys.argv[1];assert ref in ['staged','HEAD']
stem='docs/verification/rf1119-mobile-worker-cfg-2026-10-11';sha=lambda b:hashlib.sha256(b).hexdigest()
def blob(p):return subprocess.check_output(['git','show',(':'+p if ref=='staged' else 'HEAD:'+p)],cwd=root)
index=json.loads(blob(stem+'/index.json'));archive=blob(stem+'/raw.tar.gz')
assert sha(archive)==index['archiveSha256'] and len(archive)==index['archiveBytes']
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as t:
    assert t.getnames()==[v['path'] for v in index['members']]
    for v in index['members']:
        b=t.extractfile(v['path']).read();assert len(b)==v['bytes'] and sha(b)==v['sha256']
    p='tauri/crates/solosoul-sync/src/workers.rs';executed=t.extractfile('executed-source/workers.rs').read()
    assert executed==(root/p).read_bytes();assert blob(p)==executed.replace(b'\r\n',b'\n')
    manifest=json.loads(t.extractfile('checks/sources.json').read());assert all(sha((root/p).read_bytes())==h for p,h in manifest.items())
summary=json.loads(blob(stem+'.json'));assert summary['accepted'] and summary['archive']==index
report=blob('docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md').decode();assert '已关闭：**299 / 309**' in report
v={'ref':ref,'membersVerified':len(index['members']),'workingBytesEqualExecuted':True,'gitRawBytesEqualExecuted':blob('tauri/crates/solosoul-sync/src/workers.rs')==executed,'gitLFNormalizedBytesEqualExecuted':True,'allSourceHashesCurrent':True,'archiveSha256':index['archiveSha256'],'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()}
label=sys.argv[2] if len(sys.argv)==3 else ref
assert label in ['staged','HEAD','pre-amend','post-amend']
with (w/('rf1119-'+label+'-verification.json')).open('x',encoding='utf8') as f:json.dump(v,f,indent=2)
print(json.dumps(v,indent=2))
