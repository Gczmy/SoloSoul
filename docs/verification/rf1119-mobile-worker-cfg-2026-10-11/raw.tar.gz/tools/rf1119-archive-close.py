from pathlib import Path
import datetime,hashlib,io,json,re,tarfile
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1119-checks-20261011';source=root/'tauri/crates/solosoul-sync/src/workers.rs'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(checks/'checks-complete.json')['success']
red=load(checks/'red-android.receipt.json');assert red['exitCode']!=0
oldLog=(checks/'red-android.stderr.log').read_text(encoding='utf8')
for message in ['methods `reopen` and `wait_stopping` are never used','method `is_finished` is never used']:assert message in oldLog
names=['green-android','format','windows-clippy','windows-sync-tests'];receipts={n:load(checks/(n+'.receipt.json')) for n in names}
assert all(v['exitCode']==0 and v['sourceUnchanged'] for v in receipts.values())
newLog=(checks/'green-android.stderr.log').read_text(encoding='utf8');assert 'never used' not in newLog
testLog=(checks/'windows-sync-tests.stdout.log').read_text(encoding='utf8')
counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',testLog)
assert len(counts)==1 and int(counts[0][0])>0 and counts[0][1:]==('0','0','0','0'),counts
required=['completed_stop_releases_listener_before_same_manager_restart','cancelled_direct_manager_stop_keeps_independent_join_and_restart_waits_for_it','disable_waits_real_worker_while_status_queries_remain_reachable','cancelled_disable_awaiter_keeps_independent_cleanup_and_next_wait_joins_it','reenable_cannot_overtake_cancelled_old_disable_cleanup','service_drop_after_cancelled_disable_keeps_root_until_actual_worker_and_cleanup_exit']
for name in required:assert re.search(r'(?m)^test [\w:]*'+re.escape(name)+r' \.\.\. ok\s*$',testLog),name
before=(checks/'workers-before.rs').read_bytes().replace(b'\r\n',b'\n');after=source.read_bytes().replace(b'\r\n',b'\n')
attribute=b'    #[cfg(not(any(target_os = "android", target_os = "ios")))]\n'
expected=before
for signature in [b'    pub(crate) fn reopen(',b'    pub(crate) async fn wait_stopping(',b'    fn is_finished(']:
    assert expected.count(signature)==1;expected=expected.replace(signature,attribute+signature)
assert expected==after,'Only three matching cfg attributes may change'
parent=load(w/'rf1118-checks-20261011/sources.json');current={p:sha(root/p) for p in parent}
changed=[p for p,h in parent.items() if current[p]!=h];assert changed==['tauri/crates/solosoul-sync/src/workers.rs'],changed
save(checks/'sources.json',current)
save(checks/'source-provenance.json',{'base':'20ea216e9','sourceCount':len(parent),'changedSources':changed,'allOtherSourcesUnchanged':True,'onlyThreeDesktopCfgAttributesChanged':True,'afterSha256':sha(source)})
stem='rf1119-mobile-worker-cfg-2026-10-11';out=root/'docs/verification'/stem;out.mkdir(exist_ok=False)
(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf8')
files={}
def add(p,name):
    assert p.is_file() and not p.is_symlink() and not(p.lstat().st_file_attributes&0x400) and name not in files
    files[name]=p
for p in checks.iterdir():
    if p.is_file():add(p,'checks/'+p.name)
for n in ['rf1119-register.py','rf1119-run-checks.py','rf1119-archive-close.py','rf1119-verify-git.py']:add(w/n,'tools/'+n)
add(root/'build/android-native-feasibility-20261010/android-sync-desktop-method-warnings.json','original-warning/android-sync-desktop-method-warnings.json')
add(source,'executed-source/workers.rs')
members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as t:
    for n,p in sorted(files.items()):
        b=p.read_bytes();m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b));members.append({'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(out/'raw.tar.gz','r:gz') as t:
    assert t.getnames()==[v['path'] for v in members]
    for v in members:
        b=t.extractfile(v['path']).read();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
index={'task':'RF-1119','archiveSha256':sha(out/'raw.tar.gz'),'archiveBytes':(out/'raw.tar.gz').stat().st_size,'members':members,'allMembersReadbackVerified':True}
save(out/'index.json',index)
testCounts=dict(zip(['passed','failed','ignored','measured','filtered'],map(int,counts[0])))
summary={'task':'RF-1119','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'accepted':True,'baseCommit':'20ea216e9','sourceChanges':changed,'sourceCount':len(current),'afterSha256':sha(source),'androidCompilerTarget':'x86_64-linux-android','androidStrictCompiler':'rustc -D warnings','androidClippyExecuted':False,'windowsClippyExecuted':True,'windowsFullSyncLibraryTestCounts':testCounts,'requiredExistingRaceRegressionsPassed':required,'red':red,'checks':receipts,'methodBodiesUnchanged':True,'sharedMobileStopAndJoinUnchanged':True,'dependenciesChanged':False,'iosCompilerExecuted':False,'apkBuiltOrInstalled':False,'nativeUiAcceptance':False,'fullRF121Accepted':False,'fullRF312Accepted':False,'gitSourceComparison':'Raw executed bytes retained; Git canonical text compared after CRLF-to-LF normalization only','archive':index}
summary['testDurationObservation']={'fullGroupSeconds':186.92,'networkInterruptTestReportedOver60Seconds':'network_interrupt_unblocks_real_socket_but_wait_still_joins_worker has been running for over 60 seconds' in testLog,'singleTestDurationMeasured':False,'causeEstablished':False,'subsequentLocalInvestigationNeeded':True}
save(root/'docs/verification'/(stem+'.json'),summary)
p=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=p.read_text(encoding='utf8')
assert s.count('已关闭：**298 / 309**；实际修复（已关闭）：298；')==1
s=s.replace('已关闭：**298 / 309**；实际修复（已关闭）：298；','已关闭：**299 / 309**；实际修复（已关闭）：299；').replace('暂缓：0；进行中：1；待执行：6。','暂缓：0；进行中：0；待执行：6。')
start=s.index('- 当前处理：');end=s.index('\n',start);s=s[:start]+'- 当前处理：无；RF-1119已独立完成，完整RF-121/312及其他平台前置保持未完成。'+s[end:]
start=s.index('> 最后更新：');end=s.index('\n',start);s=s[:start]+'> 最后更新：2026-10-11（RF-1119移动端同步worker条件编译完成；完整跨平台矩阵仍待验证）'+s[end:]
line='| 309 | [RF-1119](#rf-1119) | P2 | 移动端不编译桌面worker重新开放与收尾等待方法 | 无（实际Android dead_code警告） | [~] 进行中 |';assert s.count(line)==1;s=s.replace(line,line.replace('[~] 进行中','[x] 完成'))
pos=s.index('\n## 7. 每项执行记录模板',s.index('### RF-1119'));s=s[:pos]+f'\n- **结果：**真实Android严格编译先复现三个桌面方法dead_code两条错误、增加与manager一致的cfg后通过；Windows完整Sync库Clippy与{testCounts["passed"]}项现有测试均通过，6项指定停止/取消/join/重启竞态回归实际通过，0失败/忽略/过滤。源码仅新增3条cfg属性，共享移动逻辑与方法体未变。\n'+s[pos:]
s+=f'''

### RF-1119 同步worker移动端条件编译执行记录（2026-10-11，完成）

- 重新核验当前源代码与调用关系：reopen、wait_stopping仅由桌面cfg的manager调用，StopCompletion.is_finished仅供reopen；测试中的JoinHandle.is_finished为不同方法。Android真目标严格rustc当前源码实际报告这三个方法dead_code的两条错误；仅对三条私有方法增加与manager一致的`cfg(not(any(target_os = "android", target_os = "ios")))`，未更改方法体、移动端共享begin_stop/close/wait或completion.wait，也未屏蔽警告和修改依赖。
- D盘既有Rust1.96.0/NDK27，对x86_64-linux-android运行Sync `cargo rustc --locked --offline ... -- -D warnings`，先红后绿。私有Android工具链无Clippy，本项不将严格rustc称为Android Clippy。Windows完整Sync库严格Clippy、workspace格式及全库现有{testCounts['passed']}项单元测试通过，0失败/忽略/过滤；六项指定取消/停止/join/重新启用/manager重启回归实际通过，没有新增只复述cfg实现的测试。
- 1834份源码相对20ea216e9仅workers.rs改动，归一CRLF后精确证明只新增3条匹配的cfg属性。记录实际编译源码原字节，Git按标准LF转换后比较完整内容；不声称CRLF与LF raw字节相等。未构建/安装APK，未验收iOS或原生UI，完整RF-121/312及其他平台前置保持。
- 完整测试运行186.92秒，network_interrupt_unblocks_real_socket_but_wait_still_joins_worker曾由harness报告运行超过60秒，最终通过；只有组时长与该下界，未测单例精确时长，尚不能归因于本次cfg或确认为网络中断缺陷。stderr中的rf905 injected worker panic为已有异常注入用例，源代码与passed状态已核对。后续需要隔离复测慢用例；本项通过不代表网络停止时延已验收。
- [结构化证据](verification/{stem}.json)、[{len(members)}份原件索引](verification/{stem}/index.json)和原警告/真实红绿/工具链SHA/完整测试日志已归档，全成员回读长度与SHA通过。仅本项独立本地提交（以RF-1119检索），不推送。299/309关闭、4待验证及6待执行；goal active，后续可推进Android应用入口桌面逻辑cfg警告与Windows原生补验。
'''
p.write_text(s,encoding='utf8',newline='\n')
print('RF-1119 closed;',testCounts,';',len(members),'raw members verified')
