from pathlib import Path
import datetime,hashlib,json
root=Path('D:/SoloSoul');w=Path(__file__).parent;stage=w/'rf1119-checks-20261011';stage.mkdir(exist_ok=False)
p=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=p.read_text(encoding='utf8');(stage/'ledger-before.md').write_bytes(p.read_bytes())
source=root/'tauri/crates/solosoul-sync/src/workers.rs';(stage/'workers-before.rs').write_bytes(source.read_bytes())
assert s.count('- 任务总数：**308**（P1：55；P2：252；P3：1）。')==1
s=s.replace('- 任务总数：**308**（P1：55；P2：252；P3：1）。','- 任务总数：**309**（P1：55；P2：253；P3：1）。')
assert s.count('已关闭：**298 / 308**；实际修复（已关闭）：298；')==1
s=s.replace('已关闭：**298 / 308**','已关闭：**298 / 309**').replace('暂缓：0；进行中：0；待执行：6。','暂缓：0；进行中：1；待执行：6。')
start=s.index('- 当前处理：');end=s.index('\n',start);s=s[:start]+'- 当前处理：**RF-1119：同步worker三个仅桌面消费的私有方法沿用manager平台cfg，保留移动端共享停止/等待实现**。'+s[end:]
s=s.replace('RF-1117、RF-1118（','RF-1117、RF-1118、RF-1119（')
line='| 308 | [RF-1118](#rf-1118) | P2 | 移动端不再构造仅桌面消费的进程锁路径 | 无（Android实编译unused variable警告） | [x] 完成 |';assert s.count(line)==1
s=s.replace(line,line+'\n| 309 | [RF-1119](#rf-1119) | P2 | 移动端不编译桌面worker重新开放与收尾等待方法 | 无（实际Android dead_code警告） | [~] 进行中 |')
marker='\n## 7. 每项执行记录模板';assert s.count(marker)==1
s=s.replace(marker,'''
### RF-1119

**移动端不编译桌面worker重新开放与收尾等待方法** · P2 · 来源：实际Android同步模块dead_code警告

- **入口：**`tauri/crates/solosoul-sync/src/workers.rs`的reopen、wait_stopping及StopCompletion.is_finished。
- **现状：**前两方法仅由桌面cfg manager调用，第三方法仅供reopen；移动端编译产生两条dead_code警告。begin_stop、close、wait、completion.wait及移动端生命周期需要保持。
- **执行：**三条私有方法使用与manager相同的桌面cfg；不改方法体、共享停止/join、移动端策略或任何依赖。
- **验收：**真Android x86_64目标严格rustc编译修复前复现两条unused方法错误、修复后通过；Windows完整Sync库严格Clippy、格式及全库现有测试，重点确认取消stop、join、重新启用、manager重启等已有竞态回归实际通过。无新增复述实现测试，无APK/界面验收声明；iOS仅源级同cfg，不称本机编译。保留原警告/红绿/执行源码和工具证据，独立本地提交不推送。
'''+marker)
p.write_text(s,encoding='utf8',newline='\n')
(stage/'registration.json').write_text(json.dumps({'task':'RF-1119','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':'20ea216e9','source':str(source),'beforeSha256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf8')
# Retain the proven D-drive toolchain driver, adapting only this crate and validation scope.
r=(w/'rf1118-run-checks.py').read_text()
r=r.replace('rf1118','rf1119').replace('tauri/crates/solosoul-core/src/process_lock.rs','tauri/crates/solosoul-sync/src/workers.rs').replace('solosoul-core','solosoul-sync')
r=r.replace("'unused variable: `lock_path`' in text","'methods `reopen` and `wait_stopping` are never used' in text and 'method `is_finished` is never used' in text")
r=r.replace('lock_path failure','desktop-only worker method failures')
r=r.replace("'windows-lock-tests'","'windows-sync-tests'").replace("'--lib','process_lock::','--','--nocapture'","'--lib','--','--nocapture'")
r=r.replace("'defaultLockPolicyUnchanged':True","'sharedMobileStopAndJoinUnchanged':True").replace('Windows lock regression','Windows synchronization regression')
(w/'rf1119-run-checks.py').write_text(r,encoding='utf8',newline='\n')
print('Registered RF-1119: 298/309; one active issue')
