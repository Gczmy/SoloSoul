from pathlib import Path
import hashlib,io,json,tarfile
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1119-checks-20261011';stem='rf1119-mobile-worker-cfg-2026-10-11';out=root/'docs/verification'/stem
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=load(out/'index.json');source=load(checks/'sources.json')
assert all(sha(root/p)==h for p,h in source.items())
for ref in ['staged','head']:
    v=load(checks/('first-'+ref+'-verification.json'));assert v['membersVerified']==34 and v['archiveSha256']==old['archiveSha256'] and v['allSourceHashesCurrent'] and v['gitLFNormalizedBytesEqualExecuted']
note={'firstCommit':'50219b6cdf984b0c699765cf5617112fce1f61c2','initialStagedVerificationReturnedRunningSession':81437,'commitStartedBeforeThatSessionWasPolledTerminal':True,'stagedVerificationEventuallyExitCode':0,'independentFirstHeadVerificationExitCode':0,'originalArchiveMembers':34,'originalArchiveSha256':old['archiveSha256'],'productSourcesChanged':False,'testsRerun':False,'repair':'Amend only this local unpushed commit with explicit ordering record; await full fresh staged terminal success before amend, then independently verify final HEAD.'}
(checks/'git-verification-order-review.json').write_text(json.dumps(note,indent=2)+'\n',encoding='utf8')
files={}
def add(p,n):
    assert p.is_file() and not p.is_symlink() and not(p.lstat().st_file_attributes&0x400) and n not in files;files[n]=p
for p in checks.iterdir():
    if p.is_file():add(p,'checks/'+p.name)
for n in ['rf1119-register.py','rf1119-run-checks.py','rf1119-archive-close.py','rf1119-verify-git.py','rf1119-refresh-order-proof.py']:add(w/n,'tools/'+n)
add(root/'build/android-native-feasibility-20261010/android-sync-desktop-method-warnings.json','original-warning/android-sync-desktop-method-warnings.json')
add(root/'tauri/crates/solosoul-sync/src/workers.rs','executed-source/workers.rs')
members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as t:
    for n,p in sorted(files.items()):
        b=p.read_bytes();m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b));members.append({'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(out/'raw.tar.gz','r:gz') as t:
    assert t.getnames()==[v['path'] for v in members]
    for v in members:
        b=t.extractfile(v['path']).read();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
index={'task':'RF-1119','archiveSha256':sha(out/'raw.tar.gz'),'archiveBytes':(out/'raw.tar.gz').stat().st_size,'members':members,'allMembersReadbackVerified':True}
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf8')
p=root/'docs/verification'/(stem+'.json');summary=load(p);summary['archive']=index;summary['verificationOrderingReview']=note;p.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
p=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=p.read_text(encoding='utf8');oldLabel='[34份原件索引](verification/'+stem+'/index.json)';assert s.count(oldLabel)==1
s=s.replace(oldLabel,'['+str(len(members))+'份原件索引](verification/'+stem+'/index.json)')
s+='\n- RF-1119 Git顺序复核：首次暂存核验工具返回运行会话81437后，提交50219b6cd先于该会话的终态轮询；其完整源码清单回读在提交后结束。原归档逐成员/源码清单已在提交前核验，随后首次staged及独立HEAD均返回0，源码未变。保留两份实际回读结果与原校验工具，补记此顺序偏差；仅修订同一未推送本地提交，修订前等待新的完整暂存核验实际返回0，修订后再独立回读最终HEAD。未改产品源码或重复测试。\n'
p.write_text(s,encoding='utf8',newline='\n')
print('Ordering review preserved;',len(members),'members reread; product sources unchanged')
