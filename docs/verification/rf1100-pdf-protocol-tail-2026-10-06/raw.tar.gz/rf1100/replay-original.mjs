import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { checkPdfFirstPage } from 'file:///C:/Users/40299571/SoloSoul/tauri/scripts/native-perf-pdf-preview-contract.mjs';
import { inspectPdfPixels } from 'file:///C:/Users/40299571/SoloSoul/tauri/scripts/native-perf-pdf-pixels.mjs';
const old='C:/Users/40299571/AppData/Local/Temp/ss-rf312-auth-refresh-20261006';
const current='C:/Users/40299571/AppData/Local/Temp/ss-rf1100-pdf-call-tail-20261006';
const load=async p=>JSON.parse((await fs.readFile(p,'utf8')).replace(/^\uFEFF/,''));
const rows=[];
for (const name of ['pdf100','pdf5000']) {
 const report=await load(path.join(old,name,'native-perf-sdk-journey-results.json'));
 for (const sample of report.samples) {
  const proof=await load(path.join(sample.root,'native-perf-sdk-journey.json'));
  if (!proof.success) {rows.push({group:name,index:sample.index,nativeSuccess:false,reason:proof.reason,notReclassified:true});continue;}
  checkPdfFirstPage(proof,sample.owned,sample.bound,report.fixture);
  for (const shot of proof.pdfPreview.samples) {
   const bytes=await fs.readFile(path.join(sample.root,shot.fileName));
   if(bytes.length!==shot.bytes||createHash('sha256').update(bytes).digest('hex')!==shot.sha256)throw Error('Screenshot bytes or SHA differs');
   const pixels=inspectPdfPixels(bytes);
   for(const key of ['width','height','darkPixels','maskSha256','matches'])if(pixels[key]!==shot[key])throw Error('Independent screenshot replay differs');
  }
  rows.push({group:name,index:sample.index,nativeSuccess:true,strictProofAccepted:true,screenshots:proof.pdfPreview.samples.length,originalDriverError:sample.error,originalGroupExitUnchanged:true});
 }
}
if(rows.filter(x=>x.strictProofAccepted).length!==5||rows.filter(x=>!x.nativeSuccess).length!==1)throw Error('Original sample set changed');
await fs.writeFile(path.join(current,'original-replay-v2.json'),JSON.stringify({rows,originalGroupsStillFailed:true,performanceMetrics:null},null,2)+'\n',{flag:'wx'});
console.log('Five original strict proofs and all screenshots accepted; original home failure and both original failed group exits preserved');
