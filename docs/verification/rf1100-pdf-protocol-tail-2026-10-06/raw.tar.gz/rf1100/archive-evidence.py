from pathlib import Path
import hashlib,json,tarfile,subprocess,time
s=Path(__file__).parent;r=Path('C:/Users/40299571/SoloSoul');old=Path('C:/Users/40299571/AppData/Local/Temp/ss-rf312-auth-refresh-20261006')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=load(s/'baseline.json')
for rel,h in b['allOtherTrackedTauriInputs'].items():assert sha(r/rel)==h,'Unrelated tracked input changed: '+rel
print('Verified '+str(len(b['allOtherTrackedTauriInputs']))+' unrelated tracked Tauri inputs',flush=True)
git=['git','-C',str(r),'-c','safe.directory=C:/Users/40299571/SoloSoul','-c','core.autocrlf=false','-c','core.safecrlf=false']
assert subprocess.check_output(git+['rev-parse','HEAD'],text=True).strip()==b['baseCommit']
assert subprocess.check_output(git+['rev-parse','refs/stash'],text=True).strip()==b['stash']
sg=['git','-C',str(r/'SoloSoul_plugin_market'),'-c','safe.directory=C:/Users/40299571/SoloSoul/SoloSoul_plugin_market']
assert subprocess.check_output(sg+['rev-parse','HEAD'],text=True).strip()==b['submodule']
assert not subprocess.check_output(sg+['status','--porcelain'],text=True).strip()
allowed={'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md','docs/performance/RF-312-native-pdf-first-page.md','tauri/scripts/native-perf-pdf-preview-contract.mjs','tauri/scripts/native-perf-pdf-preview.test.mjs'}
changed=set(subprocess.check_output(git+['diff','--name-only'],text=True).splitlines());assert changed==allowed,changed
record=load(r/'docs/verification/rf1100-pdf-protocol-tail-2026-10-06.json')
assert all(sha(r/p)==h for p,h in record['sourceSha256'].items())
package=load(s/'new-runtime-package.json');assert sha(Path(package['exe']))==package['sha256']
assert all(sha(Path(x['source']))==x['sha256']==sha(Path(x['copy'])) for x in package['resources'])
(s/'final-input-check.json').write_text(json.dumps({'otherTrackedTauriInputsVerified':len(b['allOtherTrackedTauriInputs']),'changedTrackedPaths':sorted(changed),'head':b['baseCommit'],'stash':b['stash'],'submodule':b['submodule'],'submoduleClean':True,'currentExeAnd94ResourceHashesVerified':True,'sourceEvidenceHashesVerified':True},indent=2)+'\n',encoding='utf-8')
items={}
def add(p,prefix,root):
 assert p.is_file() and not p.is_symlink();name=prefix+'/'+p.relative_to(root).as_posix();assert name not in items;items[name]=p
for root,prefix,groups in [(old,'original-auth-refresh',['auth100','auth5000','pdf100','pdf5000']),(s,'rf1100',['pdf100','pdf5000'])]:
 for p in root.iterdir():
  if p.is_file():add(p,prefix,root)
 for group in groups:
  for p in (root/group).iterdir():
   if p.is_file():add(p,prefix,root)
  for sample in (root/group).glob('sample-*'):
   if sample.is_dir():
    for p in sample.iterdir():
     if p.is_file():
      assert p.suffix in ['.json','.png'];add(p,prefix,root)
 if root==s:
  for sub in ['before','preserved-logs']:
   for p in (root/sub).rglob('*'):
    if p.is_file():add(p,prefix,root)
dest=r/'docs/verification/rf1100-pdf-protocol-tail-2026-10-06';assert not dest.exists();dest.mkdir()
rows=[]
for name,p in sorted(items.items()):
 assert not Path(name).is_absolute() and '..' not in Path(name).parts
 rows.append({'member':name,'bytes':p.stat().st_size,'sha256':sha(p),'originalPath':str(p)})
archive=dest/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for row in rows:t.add(items[row['member']],arcname=row['member'],recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(rows)
 for row in rows:
  member=t.getmember(row['member']);assert member.isfile() and member.size==row['bytes'];data=t.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==row['sha256']
index={'schemaVersion':1,'task':'RF-1100','archive':'raw.tar.gz','archiveBytes':archive.stat().st_size,'archiveSha256':sha(archive),'memberCount':len(rows),'allMembersDecodedAndShaVerified':True,'excludes':['EXE','DLL','models','Vault entity files','cache trees'],'members':rows}
(dest/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Archived and independently decoded '+str(len(rows))+' exact original members; no Vault/binary/cache entities',flush=True)
