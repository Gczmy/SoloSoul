from pathlib import Path
import json,subprocess,time,datetime,hashlib,os,sys
s=Path(__file__).parent;r=Path('C:/Users/40299571/SoloSoul');old=Path('C:/Users/40299571/AppData/Local/Temp/ss-rf312-auth-refresh-20261006')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def new(name,v):
 p=s/name;assert not p.exists(),name;p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
checkpoint=load(old/'build-checkpoint.json');exe=Path(checkpoint['exe']);assert sha(exe)==checkpoint['sha256']
checkpoint=load(s/'new-runtime-package.json');exe=Path(checkpoint['exe']);assert sha(exe)==checkpoint['sha256']
receipts=[]
for group,count in [('pdf100',100),('pdf5000',5000)]:
 assert sha(exe)==checkpoint['sha256']
 for row in checkpoint['resources']:assert sha(Path(row['source']))==row['sha256']==sha(Path(row['copy']))
 cmd=['node','scripts/native-perf-pdf-preview.mjs','--exe',str(exe),'--fixture','C:/Users/40299571/AppData/Local/Temp/ss-rf312-media-20261005/vault'+str(count),'--output',str(s/group),'--samples','3']
 assert not (s/group).exists();start=time.monotonic()
 env=os.environ.copy();env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','');env.pop('PDFIUM_LIBRARY_PATH',None)
 with (s/(group+'.stdout.log')).open('xb') as out,(s/(group+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,cwd=r/'tauri',env=env,stdout=out,stderr=err)
  new(group+'.live.json',{'command':cmd,'pid':p.pid,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()});print(group+' live PID '+str(p.pid),flush=True);code=p.wait()
 receipt={'command':cmd,'exitCode':code,'elapsedSeconds':time.monotonic()-start};new(group+'.receipt.json',receipt);receipts.append(receipt);print(group+' terminal exit '+str(code),flush=True)
 report=load(s/group/'native-perf-sdk-journey-results.json');assert report['sourceUnchanged'] and len(report['samples'])==3
 assert all(x['cleanupIntegrity']['complete'] for x in report['samples']),'Owned cleanup failed; no further group launched'
new('native-completed.json',{'allTwoGroupsExecuted':True,'receipts':receipts,'allCommandsSucceeded':all(x['exitCode']==0 for x in receipts),'originalFailuresPreserved':True,'sameExeAndNativeGuardBudgets':True})
sys.exit(0 if all(x['exitCode']==0 for x in receipts) else 1)
