from pathlib import Path
import subprocess,json,time,datetime,sys
s=Path(__file__).parent;r=Path('C:/Users/40299571/SoloSoul/tauri')
package=json.loads((r/'package.json').read_text(encoding='utf-8-sig'))
full=package['scripts']['test:node'].split('node --test ',1)[1].split()
commands=[('targeted',['node','--test','scripts/native-perf-pdf-preview.test.mjs']),('native-node-full',['node','--test',*full]),('format',['node','node_modules/prettier/bin/prettier.cjs','--check','scripts/native-perf-pdf-preview-contract.mjs','scripts/native-perf-pdf-preview.test.mjs'])]
failed=False
for name,cmd in commands:
 start=time.monotonic()
 with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,cwd=r,stdout=out,stderr=err);code=p.wait()
 receipt={'command':cmd,'exitCode':code,'elapsedSeconds':time.monotonic()-start,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (s/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
 print(name+' exit '+str(code),flush=True);failed |= code!=0
sys.exit(1 if failed else 0)
