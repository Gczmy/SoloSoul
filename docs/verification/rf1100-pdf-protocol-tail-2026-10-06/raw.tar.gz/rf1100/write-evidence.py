from pathlib import Path
import json,hashlib,datetime,re,subprocess
s=Path(__file__).parent;r=Path('C:/Users/40299571/SoloSoul');old=Path('C:/Users/40299571/AppData/Local/Temp/ss-rf312-auth-refresh-20261006')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert load(s/'native-node-required.receipt.json')['exitCode']==0
assert load(s/'targeted.receipt.json')['exitCode']==0
assert load(s/'preservation-after-cache.json')['complete']
original=[]
for group in ['auth100','auth5000','pdf100','pdf5000']:
 report=load(old/group/'native-perf-sdk-journey-results.json');assert report['sourceUnchanged'] and len(report['samples'])==3
 original.append({'group':group,'exitCode':load(old/(group+'.receipt.json'))['exitCode'],'success':report['success'],'allSamplesPreserved':True,'samples':[{'index':x['index'],'success':x['success'],'reason':x.get('nativeProof',{}).get('reason'),'failedStep':x.get('nativeProof',{}).get('failedStep'),'driverError':x.get('error')} for x in report['samples']]})
original_home=[]
for group,index in [('auth5000',2),('pdf100',3)]:
 a=load(old/group/f'sample-{index:03d}'/'native-perf-auth-attribution.json')
 attempts=[x for x in a['backend']['attempts'] if x['kind']=='login'];assert len(attempts)==1
 stages=attempts[0]['stages'];assert [(x['name'],x['outcome']) for x in stages]==[('root-read','completed'),('maintenance-admission','interrupted')]
 original_home.append({'group':group,'index':index,'frontendValid':a['frontend']['valid'],'backendValid':a['backend']['valid'],'loginOutcome':attempts[0]['outcome'],'stages':stages,'kdfNotEntered':True,'actualActiveWorkerNotIdentified':True})
fresh=[]
for group in ['pdf100','pdf5000']:
 report=load(s/group/'native-perf-sdk-journey-results.json');assert report['sourceUnchanged'] and len(report['samples'])==3
 fresh.append({'group':group,'exitCode':load(s/(group+'.receipt.json'))['exitCode'],'success':report['success'],'samples':[{'index':x['index'],'success':x['success'],'reason':x.get('nativeProof',{}).get('reason'),'failedStep':x.get('nativeProof',{}).get('failedStep'),'driverError':x.get('error')} for x in report['samples']],'summary':report['summary'],'cleanupComplete':all(x['cleanupIntegrity']['complete'] for x in report['samples'])})
assert fresh[0]['exitCode']==1 and [x['success'] for x in fresh[0]['samples']]==[True,False,True]
assert fresh[1]['exitCode']==0 and all(x['success'] for x in fresh[1]['samples'])
a=load(s/'pdf100/sample-002/native-perf-auth-attribution.json');j=load(s/'pdf100/sample-002/native-perf-sdk-journey.json')
assert not a['frontend']['flows'] and not [x for x in a['backend']['attempts'] if x['kind']=='login']
assert j['timeoutDiagnostic']['probe']['inputTrust']['text']==0
new_home={'group':'pdf100','index':2,'reason':'probe-timeout','step':'home','frontendFlows':0,'backendLoginAttempts':0,'trustedTextEvents':0,'sdkInsertTextCalls':j['calls'].count('Input.insertText'),'notSameCauseAsMaintenanceAdmissionWithoutEvidence':True,'noPasswordValueRead':True}
cache=[]
for root,groups in [(old,['auth100','auth5000','pdf100','pdf5000']),(s,['pdf100','pdf5000'])]:
 for group in groups:
  v=load(root/(group+'-cache-cleanup.json'));assert v['complete'] and v['processesTerminated']==0
  cache.append({'stage':root.name,'group':group,'verifiedRows':len(v['verifiedIdentities']),'removedCachePaths':len(v['removedCachePaths']),'unlinkedPrivateEntries':len(v['unlinkedCacheEntries']),'missingCachePaths':len(v['alreadyAbsentCachePaths']),'receiptSha256':sha(root/(group+'-cache-cleanup.json'))})
sources=['tauri/scripts/native-perf-pdf-preview-contract.mjs','tauri/scripts/native-perf-pdf-preview.test.mjs','tauri/src-tauri/src/native_perf/sdk_journey.rs']
record={'schemaVersion':1,'task':'RF-1100','baseCommit':load(s/'baseline.json')['baseCommit'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'nondefault PDF first-page verifier exact final auth-snapshot/frame-tree calls','taskComplete':True,'wholeGoalComplete':False,'sourceSha256':{x:sha(r/x) for x in sources},'nativeBuild':{'exeSha256':load(s/'new-runtime-package.json')['sha256'],'bytes':load(s/'new-runtime-package.json')['bytes'],'originalBuildReceipt':load(old/'release.receipt.json'),'unchangedNativeExeBytes':True,'resources':94,'currentSourceFreeze':load(s/'current-source.json'),'earlierRustCliChecksReusedNotRerun':load(old/'checks-reuse-review.json')},'red':load(s/'red.receipt.json'),'targeted':load(s/'targeted.receipt.json'),'fullNode':{'actualFinal':load(s/'native-node-required.receipt.json'),'tests':217,'passed':216,'failed':0,'existingPermissionSkipped':1,'earlierFailuresPreserved':[load(s/'native-node-full.receipt.json'),load(s/'native-node-final.receipt.json')],'timeoutBudgetsUnchanged':True,'permissionCausalityNotProvenByUnpairedRepeats':True},'format':load(s/'format.receipt.json'),'originalGroups':original,'originalPdfStrictReplay':load(s/'original-replay-v2.json'),'originalHomeFailures':original_home,'freshPdfGroups':fresh,'freshHomeFailure':new_home,'resourcePreflightFailure':load(s/'native-resource-preflight-failure.json'),'cacheCleanup':{'groups':cache,'verifiedRows':sum(x['verifiedRows'] for x in cache),'removedCachePaths':sum(x['removedCachePaths'] for x in cache),'unlinkedPrivateEntries':sum(x['unlinkedPrivateEntries'] for x in cache),'preservation':load(s/'preservation-after-cache.json')},'temporaryHelperAuthoringFailuresDocumented':True,'ordinaryAuthReviewPdfPathScopeNotRelaxed':True,'notVerified':['active maintenance worker attribution','new no-trusted-text failure cause','RF-112 isolated macOS lock recovery','RF-121 complete native material matrix','RF-312 complete baseline and other platforms','RF-122 through RF-127 prerequisites']}
file=r/'docs/verification/rf1100-pdf-protocol-tail-2026-10-06.json';assert not file.exists();file.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
doc=r/'docs/verification/RF-1100-pdf-protocol-tail.md';assert not doc.exists()
doc.write_text('''# RF-1100 PDF截图调用尾序修复

本项修复非默认性能校验器对当前SDK行程的误拒绝。原生PDF截图与关闭守卫完成后，行程还读取认证快照并验证主frame/loader；旧Node校验器未计入末尾的`Runtime.evaluate`、`Page.getFrameTree`。现在仍逐项比较完整尾序，包含这两个固定调用，不允许任意追加、丢弃或重排守卫。

## 验证结果

- 原始两档PDF组共五份原生成功证明被旧校验器拒绝；修改后的严格离线复核通过，并独立校验全部截图的字节数、SHA、PNG尺寸和固定文字区域。原组退出码均为1，旧100组的首页失败仍保留，没有改记为通过。
- 修复前红测8项中3项失败：完整证明误拒绝、缺少认证守卫误接受、暂态子frame后稳定截图误拒绝。修复后8项通过，七种遗漏/交换/重复/额外调用仍拒绝。
- 完整固定Node入口最终217项：216通过、0失败、1项既有符号链接权限skip。两次默认沙箱运行各有一个既有PowerShell子进程超时；与此前F检查一致的子进程权限下完整通过，测试和15秒预算均未改。失败日志保留；非配对重复运行不证明权限是超时原因。
- 同一EXE重新运行两档各三次完整原生组：5000组3/3、exit0；100组2/3、exit1。新100组失败停在首页，前后端登录尝试均为0、可信文本事件为0，虽然SDK记录了一次`Input.insertText`；尚未证明输入焦点、布局变化或应用认证的根因。
- EXE SHA为`b2f05a723d6af33cbd5ff6f6d307dffda734c7706ec4396083f966fa1010cdab`，103582208字节。旧临时包预检发现94资源中91份缺失，新组尚未启动即拒绝；独立新包从当前仓库复制全部94份并核验相同SHA，EXE字节保持。缺失原因未确定。原生Rust、React、依赖未改，不重复其已匹配检查。

## RF-312保留的独立失败

当前原始普通5000组sample002和PDF100组sample003，认证记录均显示`root-read`完成后`maintenance-admission`中断，未进入KDF。OCR模型安装源码没有该目录activity准入；更新源偏好会在网络等待期间保留activity，是下一步候选，但本次未辨认真实活跃worker，不能把候选当成已确认原因。新增无可信文本的首页超时另行归因。

临时认证审查器只支持普通行程的四种应用路径，对PDF结束后的`/settings/attachments`拒绝仅表明其审查范围不匹配；未放宽该契约，也不将这个拒绝归因到应用认证失败。实际PDF准入继续由原生和PDF专用校验器判断。

## 保全与边界

18个隔离实例全部终止后，fresh CIM重新检查170条PID/birth或辅助PID状态；只清理120个精确缓存目录和6个私有链接，缓存工具未终止额外进程。247份根级证明、204份Vault文件和18份日志副本前后逐字节核对，Vault不在删除清单。临时驱动的命令解析、Windows扩展路径比较和缺少保全清单等拒绝均记录，拒绝阶段未删除缓存。

[结构化证据](rf1100-pdf-protocol-tail-2026-10-06.json)绑定源码、真实退出码、成功和失败；[原件索引](rf1100-pdf-protocol-tail-2026-10-06/index.json)与`raw.tar.gz`保存原始命令日志、证明、公开截图和检查。原件不包含EXE、DLL、模型、Vault实体或缓存；这些实体保留在隔离临时目录，按SHA复核。没有以离线复核或成功子集替代失败整组性能。

RF-1100关闭，RF-112/121/312与RF-122～127前置保持；累计281/290。按本项独立本地提交，不推送，整体目标仍未完成。
''',encoding='utf-8',newline='\n')
p=r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';text=p.read_text(encoding='utf-8-sig');text=text.replace('最后更新：2026-10-06（RF-1099 登录请求生命周期修复）','最后更新：2026-10-06（RF-1100 PDF截图调用尾序修复）',1).replace('已关闭：**280 / 290**；实际修复（已关闭）：280','已关闭：**281 / 290**；实际修复（已关闭）：281',1).replace('暂缓：0；进行中：1；待执行：6','暂缓：0；进行中：0；待执行：6',1)
a=text.index('- 当前处理：');b=text.index('\n',a);text=text[:a]+'- 当前处理：**RF-1100已关闭；恢复RF-312维护准入及无可信文本的首页失败归因，随后RF-121 Windows主题、折叠、缩放和恢复矩阵；RF-112/121/312及RF-122～127前置保持未完成**。'+text[b:]
text=text.replace('| 290 | [RF-1100](#rf-1100) | P2 | PDF截图校验匹配实际认证诊断尾序 | 无（RF-312当前原生组误拒绝） | [~] 进行中 |','| 290 | [RF-1100](#rf-1100) | P2 | PDF截图校验匹配实际认证诊断尾序 | 无（RF-312当前原生组误拒绝） | [x] 完成 |',1)
text+='''

### RF-1100 PDF截图调用尾序修复（2026-10-06）

- 当前EXE在PDF关闭后读取认证快照及主frame树，旧Node尾序漏掉固定两次调用，五份原生成功证明被误拒绝。红测8项中3失败；补齐精确尾序后8项通过，七种损坏/遗漏/交换/重复守卫仍拒绝，不放宽截图、身份、128调用及原时限。
- 原始四组真实退出码0/1/1/1与全部12样本保留；两份首页失败停在维护准入、KDF未进入，实际活跃worker仍待归因。五份PDF严格离线证明及截图字节/SHA/PNG复核通过，不把旧组改记为成功。
- 新独立包与同EXE两档各三次：5000组3/3、exit0；100组2/3、exit1，失败样本无前后端登录尝试、可信文本0，不能归为维护准入或忽略。旧包91资源缺失的预检拒绝完整保留，新包94份当前源资源核验SHA；原生/React/依赖未改。
- 完整Node最终216通过/0失败/1既有权限skip；两轮默认沙箱的不同PowerShell子进程超时保留，实际成功运行沿用此前子进程权限，15秒预算和源码不改。格式、DOC/统计/差异检查及所有原件逐成员归档复核。
- fresh CIM复查170条身份/辅助PID，清理120个精确缓存和6链接；247证明、204 Vault和18日志副本前后字节一致，缓存工具未终止额外进程。临时作者/路径预检错误保留。
- [验证记录](verification/RF-1100-pdf-protocol-tail.md)、[实际证据](verification/rf1100-pdf-protocol-tail-2026-10-06.json)和[原件索引](verification/rf1100-pdf-protocol-tail-2026-10-06/index.json)绑定源码。按RF-1100独立本地提交，不推送；281/290关闭、3待验证、6待执行。RF-112/121/312及RF-122～127前置保持，整体goal继续active。
'''
p.write_text(text,encoding='utf-8',newline='\n')
p=r/'docs/performance/RF-312-native-pdf-first-page.md';text=p.read_text(encoding='utf-8-sig');text+='''

## 2026-10-06 当前EXE复验与RF-1100

认证诊断加入SDK行程后，当前PDF Node校验器漏记其最后两次固定调用，导致五份原生成功证明被误拒绝。RF-1100补齐精确尾序并保留全部截图守卫；原失败组及退出码不改写。相同EXE的新5000完整组3/3、exit0；100组2/3、exit1，失败样本的前后端登录尝试与可信文本均为0，整组指标保持null，独立归因输入送达。原始两份维护准入中断的首页失败同样保留，不混淆两类失败。

完整[修复与检查](../verification/RF-1100-pdf-protocol-tail.md)和[原始证据](../verification/rf1100-pdf-protocol-tail-2026-10-06.json)可复核。该非默认校验工具修复不覆盖一般PDF、睡眠、其他平台或RF-312整体验收；保持原128调用及50秒阶段/300秒行程预算。
''';p.write_text(text,encoding='utf-8',newline='\n')
print('Wrote RF-1100 evidence and task closure; RF-312 independent failed groups remain failed',flush=True)
