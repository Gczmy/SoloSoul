from pathlib import Path
import json,hashlib,shutil,datetime,os
s=Path(__file__).parent;old=Path('C:/Users/40299571/AppData/Local/Temp/ss-rf312-auth-refresh-20261006')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def norm(p):
 value=str(p);prefix=chr(92)*2+'?'+chr(92)
 return os.path.normcase(os.path.abspath(value[4:] if value.startswith(prefix) else value))
assert load(s/'native-completed.json')['allTwoGroupsExecuted']
plans=[(old,g) for g in ['auth100','auth5000','pdf100','pdf5000']]+[(s,g) for g in ['pdf100','pdf5000']]
records=[]
for stage,group in plans:
 report=load(stage/group/'native-perf-sdk-journey-results.json');assert report['sourceUnchanged'] and len(report['samples'])==3
 identities={};cleanup_pids=set()
 def walk(v):
  if isinstance(v,dict):
   if isinstance(v.get('pid'),int) and isinstance(v.get('creationMs'),int) and v.get('executableName') in ['solo_soul.exe','msedgewebview2.exe']:
    key=(v['pid'],v['creationMs']);identities[key]={k:v[k] for k in ['pid','creationMs','executableName']}
   for child in v.values():walk(child)
  elif isinstance(v,list):
   for child in v:walk(child)
 for sample in report['samples']:
  assert sample['cleanupIntegrity']['complete'] and sample['ownedProcessExit']['exitCode'] is not None
  root=stage/group/f"sample-{sample['index']:03d}";assert Path(sample['root']).resolve()==root.resolve()
  own=load(root/'native-perf-owned.json');assert norm(own['root'])==norm(sample['root']) and norm(own['vault'])==norm(root/'vault')
  walk(sample)
  for row in sample['cleanup']['cleanup']:cleanup_pids.add(row['pid'])
  proofs={p.name:sha(p) for p in root.iterdir() if p.is_file()}
  vault={}
  for p in (root/'vault').rglob('*'):
   assert not p.is_symlink(),'Unexpected Vault symlink'
   if p.is_file():vault[p.relative_to(root/'vault').as_posix()]=sha(p)
  logs={}
  logroot=root/'app-data/logs'
  if logroot.exists():
   for p in logroot.rglob('*'):
    assert not p.is_symlink()
    if p.is_file():
     target=s/'preserved-logs'/stage.name/group/root.name/p.relative_to(logroot);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);assert sha(p)==sha(target);logs[str(target.relative_to(s))]=sha(target)
  records.append({'stage':str(stage),'group':group,'root':str(root),'proofs':proofs,'vault':vault,'logs':logs})
 extra=sorted(cleanup_pids-{key[0] for key in identities})
 scope={'exe':report['preflight']['exe'] if isinstance(report.get('preflight'),dict) and 'exe' in report['preflight'] else str(stage/'bin/solo_soul.exe'),'identities':list(identities.values()),'additionalCleanupPids':extra}
 p=stage/(group+'-identity-scope.json');assert not p.exists();p.write_text(json.dumps(scope,indent=2)+'\n',encoding='utf-8')
p=s/'preservation-before-cache.json';assert not p.exists();p.write_text(json.dumps({'records':records,'plans':[(str(a),b) for a,b in plans]},ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print('Preserved 18 owned Vault/proof scopes and logs; generated exact PID/birth scopes',flush=True)
