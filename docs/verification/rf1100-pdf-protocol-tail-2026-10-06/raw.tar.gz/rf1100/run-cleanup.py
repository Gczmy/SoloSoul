from pathlib import Path
import subprocess,json,time,sys,hashlib
s=Path(__file__).parent;load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
plan=load(s/'preservation-before-cache.json');failed=False
for stage,group in plan['plans']:
 name=Path(stage).name+'-'+group;cmd=['C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe','-NoLogo','-NoProfile','-NonInteractive','-File',str(s/'cleanup-terminal-groups.ps1'),'-StageRoot',stage,'-GroupName',group];t=time.monotonic()
 with (s/(name+'-cleanup.stdout.log')).open('xb') as out,(s/(name+'-cleanup.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,stdout=out,stderr=err);code=p.wait()
 (s/(name+'-cleanup.receipt.json')).write_text(json.dumps({'command':cmd,'exitCode':code,'elapsedSeconds':time.monotonic()-t},indent=2)+'\n',encoding='utf-8');print(name+' cache cleanup exit '+str(code),flush=True)
 if code:failed=True;break
if failed:sys.exit(1)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();proofs=0;vault=0;logs=0
for row in plan['records']:
 root=Path(row['root'])
 for name,h in row['proofs'].items():assert sha(root/name)==h;proofs+=1
 for name,h in row['vault'].items():assert sha(root/'vault'/name)==h;vault+=1
 for name,h in row['logs'].items():assert sha(s/name)==h;logs+=1
 assert sorted(p.relative_to(root/'vault').as_posix() for p in (root/'vault').rglob('*') if p.is_file())==sorted(row['vault'])
(s/'preservation-after-cache.json').write_text(json.dumps({'complete':True,'roots':len(plan['records']),'proofFilesByteUnchanged':proofs,'vaultFilesByteUnchanged':vault,'logCopiesVerified':logs,'cacheToolProcessesTerminated':0},indent=2)+'\n',encoding='utf-8');print('All original and fresh Vault/proof/log bytes verified after cache cleanup',flush=True)
