from pathlib import Path
import os,time,subprocess,json,datetime,sys
s=Path(__file__).parent;r=Path("C:/Users/40299571/SoloSoul")
cmd=["npm.cmd","run","tauri","--","build","--config","src-tauri/tauri.native-perf.conf.json","--features","native-perf","--no-bundle","--ci"]
env=os.environ.copy();env["PATH"]="C:/Program Files/Git/usr/bin;"+env.get("PATH","");env["CARGO_BUILD_JOBS"]="2";env.pop("PDFIUM_LIBRARY_PATH",None)
start=time.monotonic()
with (s/"release.stdout.log").open("xb") as out,(s/"release.stderr.log").open("xb") as err:
 p=subprocess.Popen(cmd,cwd=r/"tauri",env=env,stdout=out,stderr=err)
 (s/"release.live.json").write_text(json.dumps({"command":cmd,"pid":p.pid,"at":datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+"\n",encoding="utf-8")
 print("Release build started; PID "+str(p.pid),flush=True);code=p.wait()
 (s/"release.receipt.json").write_text(json.dumps({"command":cmd,"pid":p.pid,"exitCode":code,"elapsedSeconds":time.monotonic()-start,"pdfiumOverrideRemoved":True,"jobs":2},indent=2)+"\n",encoding="utf-8")
 print("Release build terminal; exit "+str(code),flush=True)
 if code: print((s/"release.stderr.log").read_text(encoding="utf-8",errors="replace")[-4000:],flush=True)
 sys.exit(code)
