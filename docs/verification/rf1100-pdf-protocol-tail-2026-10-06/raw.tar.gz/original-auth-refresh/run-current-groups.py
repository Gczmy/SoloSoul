from pathlib import Path
import subprocess,json,hashlib,shutil,time,os,datetime,sys
s=Path(__file__).parent;r=Path("C:/Users/40299571/SoloSoul")
load=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def new(name,value):
 p=s/name;assert not p.exists(),name;p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
assert load(s/"release.receipt.json")["exitCode"]==0
freeze=load(s/"source-freeze.json")
def verify():
 assert all(sha(r/p)==h for p,h in freeze["files"].items()),"Frozen tracked inputs changed"
 assert subprocess.check_output(["git","-C",str(r),"-c","safe.directory=C:/Users/40299571/SoloSoul","rev-parse","HEAD"],text=True).strip()==freeze["head"]
verify()
bin=s/"bin";assert not bin.exists();bin.mkdir()
old=load(Path("C:/Users/40299571/AppData/Local/Temp/ss-rf1097-permission-outcomes-v2-20261006/resource-freeze.json"))["records"]
resources=[]
for row in old:
 if not row["relativePath"].startswith("bin/"):continue
 relative=Path(row["relativePath"]).relative_to("bin")
 if relative.parts[0]=="SoloSoul_plugin_market":source=r/"tauri/src-tauri/resources-desktop"/relative
 else:source=r/"tauri/src-tauri/resources"/relative
 assert source.is_file() and not source.is_symlink() and sha(source)==row["sha256"],str(source)
 target=bin/relative;assert target.resolve().is_relative_to(bin.resolve());target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
 assert sha(target)==row["sha256"]
 resources.append({"source":str(source),"copy":str(target),"sha256":row["sha256"]})
assert len(resources)==94
source=r/"tauri/target/release/solo_soul.exe";target=bin/source.name;shutil.copy2(source,target)
exe=target.read_bytes();pe=int.from_bytes(exe[60:64],"little")
assert exe[pe:pe+4]==b"PE\0\0" and int.from_bytes(exe[pe+24+68:pe+24+70],"little")==2
markers=["windows-native-sdk-ui-journey-requested","windows-native-auth-attribution","windows-native-permission-commands"]
assert all(token.encode() in exe for token in markers)
dist={p.relative_to(r/"tauri/dist").as_posix():sha(p) for p in sorted((r/"tauri/dist").rglob("*")) if p.is_file()}
new("build-checkpoint.json",{"exe":str(target),"sha256":sha(target),"bytes":len(exe),"peSubsystem":"Windows GUI","sourceFreezeSha256":sha(s/"source-freeze.json"),"frontendDist":dist,"resources":resources,"usesCurrentLoginLifecycleFixes":True})
plans=[("auth100",100,"native-perf-auth-attribution.mjs","solosoul-rf312-native-fixtures-20260930"),("auth5000",5000,"native-perf-auth-attribution.mjs","solosoul-rf312-native-fixtures-20260930"),("pdf100",100,"native-perf-pdf-preview.mjs","ss-rf312-media-20261005"),("pdf5000",5000,"native-perf-pdf-preview.mjs","ss-rf312-media-20261005")]
new("group-plan.json",{"groups":plans,"samplesPerWholeGroup":3,"includesOriginalPdfHomeTimeoutJourney":True,"originalSdk128CallAndPhase50sRun300sLimitsUnchanged":True,"oldFailureRootCauseNotAssumed":True})
env=os.environ.copy();env["PATH"]="C:/Program Files/Git/usr/bin;"+env.get("PATH","");env.pop("PDFIUM_LIBRARY_PATH",None)
receipts=[]
for group,count,driver,parent in plans:
 verify();assert sha(target)==load(s/"build-checkpoint.json")["sha256"]
 for row in resources:assert sha(Path(row["source"]))==row["sha256"]==sha(Path(row["copy"]))
 fixture=Path("C:/Users/40299571/AppData/Local/Temp")/parent/("vault"+str(count));output=s/group;assert not output.exists()
 cmd=["node","scripts/"+driver,"--exe",str(target),"--fixture",str(fixture),"--output",str(output),"--samples","3"]
 start=time.monotonic()
 with (s/(group+".stdout.log")).open("xb") as out,(s/(group+".stderr.log")).open("xb") as err:
  p=subprocess.Popen(cmd,cwd=r/"tauri",env=env,stdout=out,stderr=err)
  new(group+".live.json",{"command":cmd,"pid":p.pid,"at":datetime.datetime.now(datetime.timezone.utc).isoformat()})
  print("Started whole "+group+" PID "+str(p.pid),flush=True);code=p.wait()
 receipt={"group":group,"command":cmd,"exitCode":code,"elapsedSeconds":time.monotonic()-start,"pid":p.pid};new(group+".receipt.json",receipt);receipts.append(receipt);print(group+" terminal exit "+str(code),flush=True)
 verify()
 report=load(output/"native-perf-sdk-journey-results.json")
 assert report["sourceUnchanged"] is True
 if any(sample.get("cleanupIncomplete") for sample in report["samples"]):
  new("group-stop.json",{"group":group,"reason":"owned cleanup integrity failed; no later groups launched"});sys.exit(1)
new("groups-completed.json",{"receipts":receipts,"allCommandsSucceeded":all(v["exitCode"]==0 for v in receipts),"allFourGroupsExecuted":True,"oldFailurePreserved":True,"currentSourceFreezeVerified":True})
print("All planned groups terminal; explicit artifact review remains required",flush=True)
sys.exit(0 if all(v["exitCode"]==0 for v in receipts) else 1)
