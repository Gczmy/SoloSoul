import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import { pathToFileURL, fileURLToPath } from 'node:url';
const root='C:/Users/40299571/SoloSoul';
const stage=path.dirname(fileURLToPath(import.meta.url));
const {describeAuthAttribution}=await import(pathToFileURL(root+'/tauri/scripts/native-perf-auth-contract.mjs'));
const read=async p=>JSON.parse(await fs.readFile(p,'utf8'));
const result={task:'RF-312',scope:'current-whole-group-auth-and-home-review',diagnosticOnly:true,performanceMetrics:null,groups:[],allGroupsAccepted:false};
for(const name of ['auth100','auth5000','pdf100','pdf5000']) {
 const folder=path.join(stage,name), report=await read(path.join(folder,'native-perf-sdk-journey-results.json'));
 assert.equal(report.samplesRequested,3);assert.equal(report.sourceUnchanged,true);
 assert.equal(report.samples.length,3);
 const group={name,driverSuccess:report.success,scope:report.scope,samples:[]};
 for(const sample of report.samples) {
  const expected=path.join(folder,'sample-'+String(sample.index).padStart(3,'0'));
  assert.equal(path.resolve(sample.root).toLowerCase(),path.resolve(expected).toLowerCase());
  const row={index:sample.index,journeySuccess:sample.success,reason:sample.nativeProof?.reason??sample.error??null,failedStep:sample.nativeProof?.failedStep??null,traceAccepted:false};
  try {
   const trace=await read(path.join(expected,'native-perf-auth-attribution.json'));
   const derived=describeAuthAttribution(trace,sample.owned,sample.bound);
   row.flows=derived.frontend.flows;row.backend=derived.backend.attempts;row.commandPairing=derived.serialCommandPairing;
   row.traceAccepted=true;
   if(sample.success) {
    assert.equal(row.flows.length,2);assert.ok(row.flows.every(f=>f.outcome==='finished'));
    const logins=row.backend.filter(a=>a.kind==='login');assert.equal(logins.length,2);assert.ok(logins.every(a=>a.outcome==='completed'));
    const pair=row.commandPairing.find(p=>p.command==='login');assert.equal(pair.paired,true);assert.equal(pair.pairs.length,2);
    const required=['account-manifest-serialize','account-directory-create','account-directory-permission','account-manifest-atomic-write','account-manifest-permission'];
    for(const login of logins) {
     const children=login.stages.filter(s=>required.includes(s.name));assert.deepEqual(children.map(s=>s.name),required);assert.ok(children.every(s=>s.outcome==='completed'));
    }
   }
  } catch(error) { row.traceAccepted=false;row.traceError=String(error); }
  group.samples.push(row);
 }
 group.accepted=group.driverSuccess&&group.samples.every(s=>s.journeySuccess&&s.traceAccepted);
 result.groups.push(group);
}
result.allGroupsAccepted=result.groups.every(g=>g.accepted);
await fs.writeFile(path.join(stage,'current-groups-review.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({allGroupsAccepted:result.allGroupsAccepted,groups:result.groups.map(g=>({name:g.name,accepted:g.accepted,samples:g.samples.map(s=>({index:s.index,journeySuccess:s.journeySuccess,traceAccepted:s.traceAccepted,reason:s.reason,failedStep:s.failedStep,traceError:s.traceError}))}))}));
process.exitCode=result.allGroupsAccepted?0:1;
