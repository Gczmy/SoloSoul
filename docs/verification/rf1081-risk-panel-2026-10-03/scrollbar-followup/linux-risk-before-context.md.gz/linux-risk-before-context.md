# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: android-touch-targets.spec.ts >> Android risk actions keep complete words and touch targets at 320px
- Location: e2e/android-touch-targets.spec.ts:247:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 515.3125
Received: 459.3125
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - generic [ref=e5]:
      - button "Back" [ref=e6] [cursor=pointer]:
        - img [ref=e7]
      - heading "AI & LLM Config" [level=1] [ref=e9]
    - button "Lock Vault" [ref=e11] [cursor=pointer]:
      - img [ref=e12]
  - navigation "Main navigation" [ref=e16]:
    - link "Home" [ref=e17] [cursor=pointer]:
      - /url: /
      - img [ref=e19]
      - generic [ref=e22]: Home
    - link "Objects" [ref=e23] [cursor=pointer]:
      - /url: /workspace
      - img [ref=e25]
      - generic [ref=e29]: Objects
    - link "Tools" [ref=e30] [cursor=pointer]:
      - /url: /tools
      - img [ref=e32]
      - generic [ref=e36]: Tools
    - link "Settings" [ref=e37] [cursor=pointer]:
      - /url: /settings
      - img [ref=e39]
      - generic [ref=e42]: Settings
  - main [ref=e44]:
    - generic [ref=e45]:
      - paragraph [ref=e47]: ⚠ AI chat is off by default. Review the service address and data scope before enabling it.
      - generic [ref=e48]:
        - heading "AI Features" [level=3] [ref=e49]
        - generic [ref=e50] [cursor=pointer]:
          - generic [ref=e51]:
            - checkbox "AI Chat" [active] [ref=e52]
            - generic:
              - img
          - text: AI Chat
      - generic [ref=e53]:
        - heading "System Prompt (Context Injection)" [level=3] [ref=e54]
        - generic [ref=e55] [cursor=pointer]:
          - generic [ref=e56]:
            - checkbox "Attach public object information, selected preferences, app information and help excerpts" [checked] [ref=e57]
            - generic:
              - img
          - text: Attach public object information, selected preferences, app information and help excerpts
        - paragraph [ref=e58]: Automatically attaches public object names, types and public fields; it does not filter your messages or history.
      - generic [ref=e59]:
        - heading "AI Service Providers" [level=3] [ref=e60]
        - button "Add Custom Provider" [ref=e61] [cursor=pointer]:
          - img [ref=e62]
          - text: Add Custom Provider
      - generic [ref=e63]:
        - heading "Knowledge Base Index" [level=3] [ref=e64]
        - paragraph [ref=e65]: Checking embedding support...
        - button "Rebuild Knowledge Base" [ref=e66] [cursor=pointer]
      - button "Usage Statistics View LLM Token usage and conversation statistics ›" [ref=e67] [cursor=pointer]:
        - generic [ref=e68]:
          - generic [ref=e69]:
            - img [ref=e70]
            - generic [ref=e72]:
              - text: Usage Statistics
              - generic [ref=e73]: View LLM Token usage and conversation statistics
          - generic [ref=e74]: ›
      - generic [ref=e76]:
        - heading "⚠ Enable AI Features" [level=3] [ref=e77]:
          - generic [ref=e78]: ⚠
          - text: Enable AI Features
        - paragraph [ref=e79]: Your configured AI service may process data off-device.
        - list [ref=e80]:
          - listitem [ref=e81]: Messages and history are sent without filtering sensitive text.
          - listitem [ref=e82]: Automatic context adds public object info, preferences, app info and help without reconfirmation.
          - listitem [ref=e83]: Embedding may send queries or help excerpts unless using an installed local model.
          - listitem [ref=e84]: Review the service’s data policy. Authentication keys may be sent. Disabling AI cannot recall requests.
        - generic [ref=e85] [cursor=pointer]:
          - generic [ref=e86]:
            - checkbox "I understand the risks and want to proceed" [ref=e87]
            - generic:
              - img
          - text: I understand the risks and want to proceed
        - generic [ref=e88]:
          - button "Cancel" [ref=e89] [cursor=pointer]
          - button "Enable AI Features" [disabled] [ref=e90]
```

# Test source

```ts
  175 |           animations: 'disabled',
  176 |         });
  177 |       }
  178 |     }
  179 |     await test.info().attach('touch-target-audit', {
  180 |       body: JSON.stringify(report, null, 2),
  181 |       contentType: 'application/json',
  182 |     });
  183 |     if (process.env.SOLOSOUL_TOUCH_AUDIT) {
  184 |       console.log(
  185 |         JSON.stringify(
  186 |           report.filter(
  187 |             (r) => r.small.length || r.clipped.length || r.textOverflow.length || r.error,
  188 |           ),
  189 |         ),
  190 |       );
  191 |     } else {
  192 |       expect(
  193 |         report.filter(
  194 |           (r) => r.small.length || r.clipped.length || r.textOverflow.length || r.error,
  195 |         ),
  196 |       ).toEqual([]);
  197 |     }
  198 |   });
  199 | 
  200 | test('Android security switch label and Space each toggle once with a 48px target', async ({
  201 |   page,
  202 | }) => {
  203 |   await page.setViewportSize({ width: 390, height: 844 });
  204 |   await navigate(page, '/settings/security');
  205 |   const input = page.getByRole('switch', { name: 'Lock on Background' });
  206 |   const label = page.locator('[data-ui-switch]').filter({ has: input });
  207 |   const bounds = await label.boundingBox();
  208 |   expect(bounds).not.toBeNull();
  209 |   expect(bounds!.width).toBeGreaterThanOrEqual(48);
  210 |   expect(bounds!.height).toBeGreaterThanOrEqual(48);
  211 |   const initial = await input.isChecked();
  212 |   await label.click();
  213 |   await expect.poll(() => input.isChecked()).toBe(!initial);
  214 |   await input.focus();
  215 |   await page.keyboard.press('Space');
  216 |   await expect.poll(() => input.isChecked()).toBe(initial);
  217 | });
  218 | 
  219 | test('Android login controls do not cover the password text', async ({ page }) => {
  220 |   await page.setViewportSize({ width: 320, height: 844 });
  221 |   await page.goto('/login');
  222 |   const password = page.locator('.interactive-password-field');
  223 |   await password.locator('input').fill('EXAMPLE-PASSWORD');
  224 |   await expect(password.getByRole('button')).toHaveCount(2);
  225 |   expect(
  226 |     await password.evaluate((field) => {
  227 |       const input = field.querySelector('input')!;
  228 |       const rect = input.getBoundingClientRect();
  229 |       const textEnd = rect.right - parseFloat(getComputedStyle(input).paddingRight);
  230 |       const buttons = [...field.querySelectorAll('button')].map((button) =>
  231 |         button.getBoundingClientRect(),
  232 |       );
  233 |       return (
  234 |         buttons.every(
  235 |           (button) =>
  236 |             button.width >= 48 &&
  237 |             button.height >= 48 &&
  238 |             button.left >= textEnd &&
  239 |             button.right <= rect.right,
  240 |         ) && buttons[0].right <= buttons[1].left
  241 |       );
  242 |     }),
  243 |   ).toBe(true);
  244 |   await page.screenshot({ path: test.info().outputPath('login-320.png'), animations: 'disabled' });
  245 | });
  246 | 
  247 | test('Android risk actions keep complete words and touch targets at 320px', async ({ page }) => {
  248 |   await page.setViewportSize({ width: 320, height: 568 });
  249 |   await navigate(page, '/settings/llm');
  250 |   await page.locator('label').filter({ hasText: 'AI Chat' }).click();
  251 |   const risk = page.locator('[data-macos-glass-backdrop]');
  252 |   await expect(risk).toBeVisible();
  253 |   const panel = risk.locator('[data-macos-glass="panel"]');
  254 |   const panelBox = await panel.boundingBox();
  255 |   expect(panelBox).not.toBeNull();
  256 |   expect(panelBox!.y).toBeGreaterThanOrEqual(0);
  257 |   expect(panelBox!.y + panelBox!.height).toBeLessThanOrEqual(568);
  258 |   const cancel = risk.getByRole('button', { name: 'Cancel', exact: true });
  259 |   const enable = risk.getByRole('button', { name: 'Enable AI Features', exact: true });
  260 |   expect(
  261 |     await cancel.evaluate((element) => {
  262 |       const range = document.createRange();
  263 |       range.selectNodeContents(element);
  264 |       return range.getClientRects().length;
  265 |     }),
  266 |   ).toBe(1);
  267 |   for (const button of [cancel, enable]) {
  268 |     const box = await button.boundingBox();
  269 |     expect(box).not.toBeNull();
  270 |     expect(box!.width).toBeGreaterThanOrEqual(48);
  271 |     expect(box!.height).toBeGreaterThanOrEqual(48);
  272 |     expect(box!.x).toBeGreaterThanOrEqual(0);
  273 |     expect(box!.x + box!.width).toBeLessThanOrEqual(320);
  274 |   }
> 275 |   expect((await cancel.boundingBox())!.y).toBe((await enable.boundingBox())!.y);
      |                                           ^ Error: expect(received).toBe(expected) // Object.is equality
  276 |   await page.screenshot({ path: test.info().outputPath('risk-320.png'), animations: 'disabled' });
  277 | });
  278 | 
  279 | for (const viewport of [
  280 |   { width: 320, height: 400 },
  281 |   { width: 640, height: 320 },
  282 | ])
  283 |   test(`Android risk actions remain reachable at ${viewport.width}x${viewport.height}`, async ({
  284 |     page,
  285 |   }) => {
  286 |     await page.setViewportSize(viewport);
  287 |     await navigate(page, '/settings/llm');
  288 |     const feature = page.locator('label').filter({ hasText: 'AI Chat' });
  289 |     await feature.click();
  290 |     const risk = page.locator('[data-macos-glass-backdrop]');
  291 |     const panel = risk.locator('[data-macos-glass="panel"]');
  292 |     await expect(panel).toBeVisible();
  293 |     const bounds = await panel.boundingBox();
  294 |     expect(bounds!.y).toBeGreaterThanOrEqual(16);
  295 |     expect(bounds!.y + bounds!.height).toBeLessThanOrEqual(viewport.height - 16);
  296 |     expect(await panel.evaluate((element) => element.scrollHeight > element.clientHeight)).toBe(
  297 |       true,
  298 |     );
  299 |     const enable = risk.getByRole('button', { name: 'Enable AI Features', exact: true });
  300 |     await expect(enable).toBeDisabled();
  301 |     await risk.getByRole('button', { name: 'Cancel', exact: true }).click();
  302 |     await expect(risk).toBeHidden();
  303 |     await feature.click();
  304 |     await expect(enable).toBeDisabled();
  305 |     await risk.getByRole('checkbox').check();
  306 |     await expect(enable).toBeEnabled();
  307 |     await enable.click();
  308 |     await expect(risk).toBeHidden();
  309 |     await expect(feature.getByRole('checkbox')).toBeChecked();
  310 |   });
  311 | 
  312 | test('Android template and data dialogs keep actions reachable on narrow screens', async ({
  313 |   page,
  314 | }) => {
  315 |   await page.setViewportSize({ width: 320, height: 844 });
  316 |   await navigate(page, '/settings/templates');
  317 |   await page.getByRole('button', { name: 'New Template', exact: true }).click();
  318 |   const dialog = page.getByRole('dialog');
  319 |   await expect(dialog).toBeVisible();
  320 |   await dialog.getByRole('button', { name: /Icon/ }).click();
  321 |   const grid = dialog.locator('.template-icon-grid');
  322 |   await expect(grid).toBeVisible();
  323 |   expect(
  324 |     await grid.evaluate((element) => {
  325 |       const rect = element.getBoundingClientRect();
  326 |       return (
  327 |         rect.left >= 16 &&
  328 |         rect.right <= innerWidth - 16 &&
  329 |         element.scrollWidth <= element.clientWidth &&
  330 |         [...element.querySelectorAll('button')].every(
  331 |           (button) => button.offsetWidth >= 48 && button.offsetHeight >= 48,
  332 |         )
  333 |       );
  334 |     }),
  335 |   ).toBe(true);
  336 |   await page.screenshot({
  337 |     path: test.info().outputPath('template-icons-320.png'),
  338 |     animations: 'disabled',
  339 |   });
  340 |   await dialog.getByRole('button', { name: 'Cancel', exact: true }).click();
  341 |   await navigate(page, '/settings/data');
  342 |   await page.getByRole('button', { name: 'View breakdown', exact: true }).click();
  343 |   const breakdown = page
  344 |     .locator('[data-macos-glass="panel"]')
  345 |     .filter({ has: page.getByRole('heading', { name: 'Storage Breakdown', exact: true }) })
  346 |     .last();
  347 |   await expect(breakdown).toBeVisible();
  348 |   const bounds = await breakdown.boundingBox();
  349 |   expect(bounds!.x).toBeGreaterThanOrEqual(16);
  350 |   expect(bounds!.x + bounds!.width).toBeLessThanOrEqual(304);
  351 | });
  352 | 
  353 | test('Android attachment expansion keeps compact arrows and a full-row touch target', async ({
  354 |   page,
  355 | }) => {
  356 |   await page.setViewportSize({ width: 320, height: 844 });
  357 |   await page.evaluate(() => {
  358 |     const mocks = (window as unknown as { __E2E_MOCKS__: Record<string, unknown> }).__E2E_MOCKS__;
  359 |     mocks.attachment_list_all = () => ({
  360 |       pages: [
  361 |         {
  362 |           pageName: 'Travel',
  363 |           objects: [
  364 |             {
  365 |               objectId: 'travel',
  366 |               objectName: 'Travel documents',
  367 |               attachments: [
  368 |                 {
  369 |                   id: 'long-report',
  370 |                   objectId: 'travel',
  371 |                   fileName: 'Very long travel report with detailed itinerary and receipts.pdf',
  372 |                   description: 'A detailed description of all the documents in this attachment.',
  373 |                   tags: ['Travel', 'Receipts', 'Report', 'Itinerary', 'Flight'],
  374 |                   mimeType: 'application/pdf',
  375 |                   sizeBytes: 1024,
```