from pathlib import Path
import json,hashlib,tarfile,io,subprocess,re,collections,difflib,datetime
root=Path('D:/SoloSoul');base=root/'build/android-native-feasibility-20261010';load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
slug='rf1112-preview-reminder-lifetime-2026-10-10';out=root/'docs/verification'/slug;assert not out.exists()
proof=load(base/'rf1112-preview-fresh-reminder-test-build5/current-apks.json');original=load(base/'rf1111-home-pixel-test-build2/current-apks.json');home='tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidHomeInstrumentedTest.kt'
assert [n for n,d in original['sourceFiles'].items() if sha(root/n)!=d]==[home]
for n,d in proof['sourceFiles'].items():assert sha(root/n)==d,n
for row in proof['files']:assert sha(Path(row['copy']))==row['sha256']
assert next(x['sha256'] for x in proof['files'] if x['kind']=='main')==next(x['sha256'] for x in original['files'] if x['kind']=='main')
final=load(base/'rf1112-api31-preview-fresh-reminder-round5/verification.json');assert final['accepted'] and len(final['results'])==2
native=[]
for mode in ['supported','fallback']:
 row=next(x for x in final['results'] if x['mode']==mode);assert row['exitCode']==0 and row['accepted'] and row['restored']
 r=load(base/'rf1112-api31-preview-fresh-reminder-round5'/('previews-'+mode)/'device-files/report.json');assert len(r['records'])==29
 assert len(r['previewReminderRenewals'])==4 and [x['unlockAttempt'] for x in r['previewReminderRenewals']]==[2,3,4,5]
 assert len(r['unlockAttempts'])==5 and all(x['result']=='home' for x in r['unlockAttempts'])
 assert not any(x['stage'].startswith('failure') for x in r['records'])
 rows=[x for x in r['records'] if x['stage'].startswith(('file-preview-text-','file-preview-image-','photo-album-','photo-viewer-','nonempty-attachments-','attachments-after-back-','preview-returned-detail-'))]
 assert len(rows)==16
 for x in rows:
  if x.get('kind')=='text':assert x['textInkPixels']>=20
  if x.get('notificationKind') in ['backup','saved']:assert x['notificationPresentAtCapture']
 native.append({'mode':mode,'result':row,'stages':29,'realPasswordUnlocks':5,'freshBackupReminders':4,'previews':[{'stage':x['stage'],'textInkPixels':x.get('textInkPixels'),'notificationKind':x.get('notificationKind'),'notificationPresentAtCapture':x.get('notificationPresentAtCapture')} for x in rows]})
for name in ['test-build','test-badging','test-signature']:assert load(base/'rf1112-preview-fresh-reminder-test-build5'/(name+'.receipt.json'))['exitCode']==0
red=[]
for folder in ['rf1112-api31-preview-diagnostic-round1','rf1112-api31-preview-fresh-reminder-round2','rf1112-api31-preview-fresh-reminder-round3','rf1112-api31-preview-fresh-reminder-round4']:
 v=load(base/folder/'verification.json');assert not v['accepted'] and all(x['restored'] for x in v['results']);red.append({'run':folder,'results':v['results']})
diagnostic=load(base/'rf1112-api31-preview-diagnostic-round1/previews-supported/device-files/report.json');d=next(x for x in diagnostic['records'] if x['stage']=='failure-preview-text-pixels')
assert d['backupReminder'] and not d['afterScreenshot']['backupReminder'] and d['textInkPixels']==0
assert d['textRect']['y']-d['afterScreenshot']['textRect']['y']==75.75
beforeArchive=root/'docs/verification/rf1111-home-pixel-colors-2026-10-10/raw.tar.gz'
with tarfile.open(beforeArchive) as tf:before=tf.extractfile('sources/after-home.kt').read()
assert hashlib.sha256(before).hexdigest()==original['sourceFiles'][home]
after=(root/home).read_bytes();oldText=before.decode().replace('\r\n','\n');newText=after.decode().replace('\r\n','\n')
start='        js(scenario, """(() => {window.fe2InsetsReminder={pending:true};';end='        val portrait = captureInsets(scenario,"safe-home-portrait",login=false)'
oldBody=oldText[oldText.index(start):oldText.index(end,oldText.index(start))].strip()
helperStart=newText.index('    private fun renewPublicBackupReminder(');a=newText.index(start,helperStart);b=newText.index('\n    }\n',a)
assert oldBody==newText[a:b].strip(), 'Original insets setup must be unchanged when extracted'
out.mkdir();(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf-8',newline='\n');blobs={}
for folder in ['rf1112-preview-diagnostic-test-build1','rf1112-preview-fresh-reminder-test-build2','rf1112-preview-fresh-reminder-test-build3','rf1112-preview-fresh-reminder-test-build4','rf1112-preview-fresh-reminder-test-build5','rf1112-api31-preview-diagnostic-round1','rf1112-api31-preview-fresh-reminder-round2','rf1112-api31-preview-fresh-reminder-round3','rf1112-api31-preview-fresh-reminder-round4','rf1112-api31-preview-fresh-reminder-round5']:
 for p in (base/folder).rglob('*'):
  if p.is_file() and p.suffix in {'.json','.png','.xml','.log'}:blobs[(Path(folder)/p.relative_to(base/folder)).as_posix()]=p.read_bytes()
for p in base.glob('*rf1112*.py'):blobs['drivers/'+p.name]=p.read_bytes()
blobs['drivers/verify-session-20261010-after-preview-fixes.json']=(base/'verify-session-20261010-after-preview-fixes.json').read_bytes()
blobs['sources/before-home.kt']=before;blobs['sources/after-home.kt']=after;blobs['sources/external-runner.py']=(root/'tauri/scripts/android-home-native-regression.py').read_bytes()
archive=out/'raw.tar.gz';members=[]
with tarfile.open(archive,'w:gz',compresslevel=9) as tf:
 for name,data in sorted(blobs.items()):
  assert '..' not in Path(name).parts and not name.startswith('/')
  info=tarfile.TarInfo(name);info.size=len(data);tf.addfile(info,io.BytesIO(data));members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive) as tf:
 assert len(tf.getmembers())==len(members)
 for row in members:assert hashlib.sha256(tf.extractfile(row['path']).read()).hexdigest()==row['sha256']
index={'members':members,'count':len(members),'archiveSha256':sha(archive),'readBackVerified':True,'privateBackupTarFilesIncluded':False,'apkFilesIncluded':False};(out/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
record={'task':'RF-1112','accepted':True,'scope':'Fresh real reminder fixtures for API31 native previews; product unchanged','cause':{'oldTextY':d['textRect']['y'],'afterExpiryTextY':d['afterScreenshot']['textRect']['y'],'shiftCssPx':75.75,'oldFrameInkPixels':0},'previousFailures':red,'finalNative':native,'fullApi31PreviewsAccepted':True,'physicalDeviceAcceptance':False,'RF121Complete':False,'RF1109Complete':False,'insetsFixtureExtractionBodyUnchanged':True,'originalExternalRunnerUnchanged':True,'sourceFiles':proof['sourceFiles'],'apkFiles':proof['files'],'archiveIndexSha256':sha(out/'index.json'),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'docs/verification'/(slug+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=p.read_text(encoding='utf-8');s=s.replace('**291 / 302**；实际修复（已关闭）：291','**292 / 302**；实际修复（已关闭）：292').replace('暂缓：0；进行中：1；待执行：6。','暂缓：0；进行中：0；待执行：6。')
s=s.replace('| 302 | [RF-1112](#rf-1112) | P2 | 排查修复API31解密文本预览原生像素检查失败 | 无（RF-1111继续执行完整previews发现） | [~] 进行中 |','| 302 | [RF-1112](#rf-1112) | P2 | 排查修复API31解密文本预览原生像素检查失败 | 无（RF-1111继续执行完整previews发现） | [x] 完成 |')
s=re.sub(r'^- 当前处理：.*$', '- 当前处理：**RF-1111/1112已完成；API31完整previews双模糊环境各29阶段、严格原生/外部验收均exit0。最新会话1Active且输入桌面可用，继续Windows剩余原生场景和Android首页/冷启动；RF-1109与RF-112/121/312及RF-122～127前置保持未完成**。',s,flags=re.M)
s=re.sub(r'^> 最后更新：.*$', '> 最后更新：2026-10-10（RF-1111/1112完成，API31完整previews双环境通过；会话1桌面可用，整体原生矩阵仍待验证）',s,count=1,flags=re.M)
s+='''
### RF-1112 真实提醒生命周期下的完整预览验收（2026-10-10）

- 支持组失败诊断证明：实际检查帧使用提醒存在时文本Y=497 CSS px，截图后8秒提醒自然到期、文本移至Y=421.25，旧区域像素为0；降级诊断轮随后在图片场景直接命中“截图时真实通知必须仍存在”。生产文本显示正常，失败来自多个预览共用同一限时提醒的夹具生命周期。
- 复用既有仅公开账户提醒时间落盘、真实锁定与主密码解锁的设置逻辑，为深色附件、文本、图片与相册四个场景分别产生新的生产提醒；计时、通知存在要求、像素/颜色/命中/安全区门槛、实际截图和45秒等待上限均保持。原insets设置逻辑提取到共享辅助方法后逐文本核对相同；生产源码、主APK及外部严格驱动逐字不变。
- 首次修复轮因重新打开附件后未等加密列表实际加载，双组仍exit1；补实际文件入口就绪条件。下一轮原生均OK(1 test)，但新增4个诊断阶段破坏严格29阶段序列，外部仍exit1；改为独立元数据，保留外部阶段校验。下一轮严格驱动还拒绝提前采样未进入预览层的提醒及旧/新提醒并存；增加与原严格条件相同的提醒就绪等待，旧提醒自然到期后再产生下一轮提醒，保存通知也在旧备份提醒自然到期后触发，再完整复跑。所有原失败、真实退出码、对应来源和截图保留，不拼接局部结果。
- 最终API31/WebView91支持/降级完整previews均原生OK(1 test)，严格外部驱动与恢复验收均exit0；各29阶段、16个非空预览/返回阶段、5次真实主密码解锁及4次独立真实备份提醒，两种主题的文本/图片/相册/查看器、真实保存通知和Android系统返回均通过。5轮实际测试APK编译、badging、签名均exit0，主APK逐字保持。
- 各轮完整私有内容/链接/权限、模糊/夜间/字体设置均恢复，专用AVD身份及1830项当前来源和APK哈希核验。只覆盖专用模拟器API31完整previews，物理设备、API35 WebGL、首页baseline/cold及完整多平台矩阵未据此关闭；会话1最新仍Active/输入桌面可访问。
- [结构化证据](verification/rf1112-preview-reminder-lifetime-2026-10-10.json)及[原件索引](verification/rf1112-preview-reminder-lifetime-2026-10-10/index.json)逐成员回读验证；不归档私有备份TAR或APK。本项独立本地提交、不推送，292/302关闭、4待验证、6待执行；整体goal保持active。
''';p.write_text(s,encoding='utf-8',newline='\n')
start='### Android私有设备就绪与生成文件核对（2026-10-10）';end='### RF-1108 Android卡片截图等待原生绘制（2026-10-10）';assert s.count(start)==s.count(end)==1;desired=s[:s.index(start)]+s[s.index(end):]
rows=[r for r in desired.splitlines() if re.match(r'^\| \d+ \| \[RF-\d+\]',r)];assert len(rows)==302 and collections.Counter(re.search(r'\[([x!~ ])\]',r).group(1) for r in rows)=={'x':292,'!':4,' ':6}
name=p.relative_to(root).as_posix();head=subprocess.run(['git','show','HEAD:'+name],cwd=root,capture_output=True,check=True).stdout.decode();assert subprocess.run(['git','diff','--cached','--name-only'],cwd=root,capture_output=True,check=True).stdout==b''
patch=''.join(difflib.unified_diff(head.splitlines(True),desired.splitlines(True),fromfile='a/'+name,tofile='b/'+name));(base/'rf1112-report-stage.patch').write_text(patch,encoding='utf-8',newline='\n');subprocess.run(['git','apply','--cached','--whitespace=error','-'],cwd=root,input=patch.encode(),check=True)
subprocess.run(['git','add','--',home,f'docs/verification/{slug}.json'],cwd=root,check=True);subprocess.run(['git','add','-f','--',str(out.relative_to(root))],cwd=root,check=True)
expected={f'docs/verification/{slug}/'+p.name:sha(p) for p in out.iterdir() if p.is_file()};expected[home]=sha(root/home);expected[f'docs/verification/{slug}.json']=sha(root/'docs/verification'/(slug+'.json'))
names=subprocess.run(['git','diff','--cached','--name-only','-z'],cwd=root,capture_output=True,check=True).stdout.decode().strip('\0').split('\0');assert set(names)==set(expected)|{name}
for n,d in expected.items():assert hashlib.sha256(subprocess.run(['git','show',':'+n],cwd=root,capture_output=True,check=True).stdout).hexdigest()==d,n
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True);print(json.dumps({'taskAccepted':True,'completeApi31Previews':True,'rawMembers':len(members),'stagedFiles':len(names),'stagesPerMode':29,'privateDataRestored':True}))
