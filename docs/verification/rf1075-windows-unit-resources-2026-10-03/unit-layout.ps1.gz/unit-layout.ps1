$fixtureDirectory = Join-Path $PWD 'src-tauri/resources/models/pp-ocr-v6-small'
if (Test-Path -LiteralPath $fixtureDirectory) {
  throw 'Expected a fresh unit-test resource directory; refusing to overwrite real models'
}
New-Item -ItemType Directory -Path $fixtureDirectory | Out-Null
Set-Content -LiteralPath (Join-Path $fixtureDirectory 'UNIT_TEST_FIXTURE.txt') -Encoding utf8 -Value 'CI unit-test resource layout only. No OCR model. Never package this fixture.'
