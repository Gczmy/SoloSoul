from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,time
R=Path('D:/SoloSoul'); W=Path(__file__).parent; S=W/'rf1129-transition-diagnostics-20261011'; S.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig')); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cache=R/'build/rf312-maintenance-20261009'
env=os.environ.copy(); env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),CARGO_HOME=str(cache/'cargo-home'),CARGO_TARGET_DIR=str(cache/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(cache/'ort-cache'),PDFIUM_LIBRARY_PATH=str(R/'tauri/src-tauri/resources/pdfium/pdfium.dll'),PYTHONDONTWRITEBYTECODE='1')
env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','')
for name in ['TAURI_CONFIG','TAURI_ANDROID_PROJECT_PATH','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS']:env.pop(name,None)
def save(n,v):
 with (S/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2); f.write('\n')
sources=None
def run(name,command):
 if sources is not None:assert all(sha(R/n)==h for n,h in sources.items())
 began=time.monotonic()
 with (S/(name+'.stdout.log')).open('xb') as out,(S/(name+'.stderr.log')).open('xb') as err:
  child=subprocess.Popen(command,cwd=R/'tauri',env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
  save(name+'.live.json',{'pid':child.pid,'command':command}); print(name,'live',child.pid,flush=True); code=child.wait()
 changed=[] if sources is None else [n for n,h in sources.items() if sha(R/n)!=h]
 save(name+'.receipt.json',{'command':command,'exitCode':code,'elapsedSeconds':time.monotonic()-began,'sourceFreezeApplicable':sources is not None,'sourceUnchanged':not changed,'changedSources':changed,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 print(name,'terminal',code,flush=True); assert code==0 and not changed
run('format-rust',['cargo','fmt','--all'])
names=load(W/'rf1128-shared-reader-20261011/sources.json')
sources={n:sha(R/n) for n in names}; save('sources.json',sources)
path='tauri/src-tauri/src/native_perf/sdk_surface_appearance.rs'
baseline=subprocess.check_output(['git','show','2261e6341:'+path],cwd=R)
(S/'sdk_surface_appearance.before.rs').write_bytes(baseline)
(S/'sdk_surface_appearance.after.rs').write_bytes((R/path).read_bytes())
def function(text,start,end):return text.split(start,1)[1].split(end,1)[0]
before=baseline.decode().replace('\r\n','\n'); after=(R/path).read_text()
assert function(before,'fn transition(', '\nasync fn click(')==function(after,'fn transition(','\nfn checked_transition(')
assert function(before,'fn probe(', '\nstruct Spec')==function(after,'fn probe(','\nstruct Spec')
save('strict-source-proof.json',{'transitionAndProbeBodiesUnchanged':True,'baseline':'2261e6341','defaultModuleCfgUnchanged':True,'applicationRecompiled':False,'noNewNativeFailureReproductionClaimed':True})
for name,command in [
 ('workspace-fmt',['cargo','fmt','--all','--check']),
 ('native-tests',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','native_perf::','--','--nocapture']),
 ('native-clippy',['cargo','clippy','--locked','-p','solo_soul','--all-targets','--features','native-perf','--','-D','warnings']),
 ('workspace-clippy',['cargo','clippy','--locked','--','-D','warnings']),
 ('workspace-tests',['cargo','test','--locked','--verbose']),
]:run(name,command)
text=(S/'native-tests.stdout.log').read_text(); assert '137 passed; 0 failed; 0 ignored;' in text
assert 'rejected_transition_retains_the_original_pair_and_error_without_accepting_it ... ok' in text
text=(S/'workspace-tests.stdout.log').read_text(); counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)
assert counts and all(int(b)==int(e)==0 for a,b,c,d,e in counts)
totals={'passed':sum(int(a) for a,b,c,d,e in counts),'failed':sum(int(b) for a,b,c,d,e in counts),'ignored':sum(int(c) for a,b,c,d,e in counts),'ignoredNames':re.findall(r'^test (.*?) \.\.\. ignored.*$',text,re.M)}
save('workspace-totals.json',totals)
save('checks-complete.json',{'success':True,'nativeTests':137,'sources':len(sources),'workspace':totals,'defaultProductionCodeChanged':False,'newGuiExecuted':False})
print('RF1129 all checks completed; no new GUI or failure reproduction claimed',flush=True)
