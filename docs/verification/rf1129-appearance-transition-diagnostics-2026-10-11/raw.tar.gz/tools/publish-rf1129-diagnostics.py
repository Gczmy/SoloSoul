from pathlib import Path
import hashlib,io,json,tarfile
R=Path('D:/SoloSoul'); W=Path(__file__).parent; S=W/'rf1129-transition-diagnostics-20261011'; N='rf1129-appearance-transition-diagnostics-2026-10-11'; O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig')); sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
done=load(S/'checks-complete.json'); assert done['success'] and done['nativeTests']==137 and not done['newGuiExecuted']
before=load(W/'rf1128-shared-reader-20261011/sources.json'); current=load(S/'sources.json')
assert [n for n in before if before[n]!=current[n]]==['tauri/src-tauri/src/native_perf/sdk_surface_appearance.rs']
assert all(sha((R/n).read_bytes())==h for n,h in current.items())
assert done['workspace']['ignoredNames']==load(W/'rf1123-checks-retry2-20261011/workspace-totals.json')['ignoredNames']
proof=load(S/'strict-source-proof.json'); proof['onlyChangedFrozenSource']='tauri/src-tauri/src/native_perf/sdk_surface_appearance.rs'; proof['cfgProof']='lib.rs and native_perf module wiring match the frozen RF1128 input SHA exactly'
proof['sourceManifestExcludesGeneratedDist']=True
proof['generatedDistBeforeAfterEqualityClaimedForThisCheckRun']=False
put(S/'strict-source-proof-complete.json',proof)
assert not O.exists(); O.mkdir(); members={}
for p in S.iterdir():
 if p.is_file() and p.suffix in ['.rs','.json','.log']:members[p.name]=p
for name in ['run-rf1129-checks.py','publish-rf1129-diagnostics.py','register-rf1129.py','recover-rf1129-log-summary.py','rf1129-session-user-reconnected.py']:members['tools/'+name]=W/name
rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as archive:
 for name,p in sorted(members.items()):
  assert not(p.stat().st_file_attributes&0x400)
  data=p.read_bytes(); info=tarfile.TarInfo(name);info.size=len(data); info.mode=0o644
  archive.addfile(info,io.BytesIO(data)); rows.append({'member':name,'source':str(p),'bytes':len(data),'sha256':sha(data)})
with tarfile.open(O/'raw.tar.gz') as archive:
 assert len(archive.getmembers())==len(rows)
 for row in rows:
  data=archive.extractfile(row['member']).read();assert len(data)==row['bytes'] and sha(data)==row['sha256']
put(O/'index.json',{'task':'RF-1129','allMembersReadbackVerified':True,'members':rows,'newNativeGuiReproductionClaimed':False})
(O/'.gitattributes').write_text('raw.tar.gz -text\n',encoding='utf-8')
checks={name:load(S/(name+'.receipt.json')) for name in ['workspace-fmt','native-tests','native-clippy','workspace-clippy','workspace-tests']}
assert all(v['exitCode']==0 and v['sourceUnchanged'] for v in checks.values())
put(R/'docs/verification'/(N+'.json'),{'task':'RF-1129','baseline':'2261e6341','scope':'diagnostic-only; preserve strict rejection and observed pair','accepted':True,'checks':checks,'nativeTests':137,'postprocessing':load(S/'postprocessing-recovery.json'),'defaultWorkspace':done['workspace'],'sources':len(current),'sourceProof':proof,'sameGenericErrorsReturned':True,'successResultSchemaUnchanged':True,'maximumRejectedPairs':2,'noAdditionalInputOrRetries':True,'newNativeGuiExecuted':False,'originalFailureCauseResolved':False,'RF1127Accepted':False,'RF1128Accepted':False,'fullRF121Accepted':False,'performanceAccepted':False,'archive':{'path':N+'/raw.tar.gz','members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha((O/'raw.tar.gz').read_bytes()),'allMembersReadbackVerified':True}})
print(json.dumps({'acceptedDiagnosticOnly':True,'members':len(rows),'nativeTests':137,'workspace':done['workspace']}))
