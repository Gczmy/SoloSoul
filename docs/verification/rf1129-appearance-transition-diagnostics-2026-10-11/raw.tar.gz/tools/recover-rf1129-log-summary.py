from pathlib import Path
import datetime,hashlib,json,re
R=Path('D:/SoloSoul');W=Path(__file__).parent;S=W/'rf1129-transition-diagnostics-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):
    with (S/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
assert not (S/'checks-complete.json').exists()
sources=load(S/'sources.json');assert all(sha(R/n)==h for n,h in sources.items())
for n in ['workspace-fmt','native-tests','native-clippy','workspace-clippy','workspace-tests']:
    p=load(S/(n+'.receipt.json'));assert p['exitCode']==0 and p['sourceUnchanged']
native=(S/'native-tests.stdout.log').read_text(encoding='utf-8')
assert '137 passed; 0 failed; 0 ignored;' in native
assert 'rejected_transition_retains_the_original_pair_and_error_without_accepting_it ... ok' in native
text=(S/'workspace-tests.stdout.log').read_text(encoding='utf-8')
rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)
assert len(rows)==25 and all(int(b)==int(e)==0 for a,b,c,d,e in rows)
assert not re.search(r'^test .* \.\.\. FAILED$',text,re.M)
totals={'passed':sum(int(a) for a,b,c,d,e in rows),'failed':sum(int(b) for a,b,c,d,e in rows),
        'ignored':sum(int(c) for a,b,c,d,e in rows),
        'ignoredNames':re.findall(r'^test (.*?) \.\.\. ignored.*$',text,re.M)}
assert totals==load(W/'rf1123-checks-retry2-20261011/workspace-totals.json')
post={'originalQueueExitCode':1,'cargoWorkspaceTestExitCode':0,
      'originalFailure':"UnicodeDecodeError: 'charmap' codec can't decode byte 0x8d in position 736368: character maps to <undefined>",
      'originalScript':str(W/'run-rf1129-checks.py'),'originalScriptSha256':sha(W/'run-rf1129-checks.py'),
      'originalScriptPreserved':True,'rawLogsPreserved':True,
      'recovery':'strict UTF-8 decode of the same completed logs; no command rerun',
      'testCommandsRerun':0,'completedResultGroups':len(rows),
      'stdoutSha256':sha(S/'workspace-tests.stdout.log'),
      'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
save('postprocessing-recovery.json',post);save('workspace-totals.json',totals)
save('checks-complete.json',{'success':True,'nativeTests':137,'sources':len(sources),
      'workspace':totals,'defaultProductionCodeChanged':False,'newGuiExecuted':False,
      'originalQueueExitCode':1,'postprocessingRecovered':True,'testCommandsRerun':0})
print(json.dumps({'qualityChecksPassed':True,'nativeTests':137,'workspace':totals,'originalQueueExitCode':1,'postprocessingRecovered':True}))
