from pathlib import Path
p=Path('D:/SoloSoul/docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md'); text=p.read_text(encoding='utf-8')
text=text.replace('任务总数：**318**（P1：56；P2：261；P3：1）','任务总数：**319**（P1：56；P2：262；P3：1）')
text=text.replace('已关闭：**306 / 318**','已关闭：**306 / 319**')
text=text.replace('暂缓：0；进行中：0；待执行：6。原计划','暂缓：0；进行中：1；待执行：6。原计划')
text=text.replace('RF-1127、RF-1128（RF-904','RF-1127、RF-1128、RF-1129（RF-904')
anchor='| 318 | [RF-1128](#rf-1128)'
line=next(v for v in text.splitlines() if v.startswith(anchor))
text=text.replace(line,line+'\n| 319 | [RF-1129](#rf-1129) | P2 | 原生外观恢复拒绝保留实际前后状态 | 无（RF-1128真实恢复失败缺少诊断） | [~] 进行中 |')
anchor='## 7. 每项执行记录模板'
card='''### RF-1129

**原生外观恢复拒绝保留实际前后状态** · P2 · 来源：RF-1128深色折叠sample001真实恢复失败

- **入口：**仅非默认 Windows `native-perf` 的 `native_perf/sdk_surface_appearance.rs`。
- **证据：**原件 captureError=null、restoreError=appearance-scene-transition-invalid；现有结果没有被拒绝的before/after，不足以区分严格transition各条件。旧失败不能唯一归因输入、路由、尺寸或侧栏状态。
- **执行：**在已验证的固定scene探针被原transition拒绝时，仅记录阶段、步骤序号、原始错误与原始前后探针，加入既有失败结果；prepare失败后的恢复仍按原预算运行，最多各保留一对。成功结果形状保持，原transition/probe/输入/恢复预算、身份和权限合同均不修改；不增加操作或读错误重试。生产默认构建不包含该模块。
- **验收：**有意义的回归证明真实transition拒绝仍返回同错误且前后观测不改写，成功不生成拒绝项，IPC拒绝也保留原错误；非默认native-perf完整定向测试、严格Clippy及默认Rust必要检查通过，源与日志归档、单项本地提交。此项只补诊断，不声称新GUI已复现失败或关闭RF-1127/RF-1128、完整RF-121/性能矩阵；下一轮须从当前源重建GUI才能用新观测验收。

'''
assert text.count(anchor)==1; text=text.replace(anchor,card+anchor)
text=text.replace('- 当前处理：RF-1128已实现','- 当前处理：RF-1129正在补齐原生外观恢复失败前后状态；RF-1128已实现',1)
p.write_text(text,encoding='utf-8',newline='\n');print('Registered RF1129 diagnostic-only;319total;1in-progress')
