from pathlib import Path
import subprocess,json,datetime,time,os,sys
s=Path(__file__).parent;env=os.environ.copy();env['CARGO_BUILD_JOBS']='1'
cmd=['cargo','build','--offline','--manifest-path',str(s/'Cargo.toml')]
t=time.monotonic()
with (s/'build.stdout.log').open('xb') as out,(s/'build.stderr.log').open('xb') as err:
 p=subprocess.Popen(cmd,cwd=s,env=env,stdout=out,stderr=err)
 (s/'build.live.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':p.pid,'command':cmd},indent=2)+'\n',encoding='utf-8');print('Started isolated offline WGC capability build PID '+str(p.pid),flush=True);rc=p.wait()
(s/'build.receipt.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':rc,'command':cmd,'elapsedSeconds':time.monotonic()-t},indent=2)+'\n',encoding='utf-8')
if rc:sys.exit(rc)
cmd=[str(s/'target/debug/rf121-wgc-capability-probe.exe')];t=time.monotonic();result=subprocess.run(cmd,cwd=s,capture_output=True)
(s/'probe.stdout.log').write_bytes(result.stdout);(s/'probe.stderr.log').write_bytes(result.stderr)
(s/'probe.receipt.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'command':cmd,'elapsedSeconds':time.monotonic()-t},indent=2)+'\n',encoding='utf-8')
if result.returncode:sys.exit(result.returncode)
v=json.loads(result.stdout.decode('utf-8-sig'));assert v['scope']=='temporary-windows-graphics-capture-capability' and v['windowsOrPixelsRead']==0 and not v['captureSessionStarted']
(s/'capability-result.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print(json.dumps(v),flush=True)
