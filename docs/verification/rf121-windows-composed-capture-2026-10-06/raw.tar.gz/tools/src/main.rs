use windows::{
    core::{factory, Interface},
    Graphics::{
        Capture::{Direct3D11CaptureFramePool, GraphicsCaptureItem, GraphicsCaptureSession},
        DirectX::{Direct3D11::IDirect3DDevice, DirectXPixelFormat},
        SizeInt32,
    },
    Win32::{
        Foundation::HMODULE,
        Graphics::{
            Direct3D::D3D_DRIVER_TYPE_HARDWARE,
            Direct3D11::{
                D3D11CreateDevice, ID3D11Device, D3D11_CREATE_DEVICE_BGRA_SUPPORT,
                D3D11_SDK_VERSION,
            },
            Dxgi::IDXGIDevice,
        },
        System::WinRT::{
            Direct3D11::CreateDirect3D11DeviceFromDXGIDevice,
            Graphics::Capture::IGraphicsCaptureItemInterop, RoInitialize, RO_INIT_MULTITHREADED,
        },
    },
};

fn main() -> windows::core::Result<()> {
    // 本临时探针只检查能力；没有创建capture item，也不读取任何窗口像素。
    unsafe {
        RoInitialize(RO_INIT_MULTITHREADED)?;
    }
    let supported = GraphicsCaptureSession::IsSupported()?;
    let _interop: IGraphicsCaptureItemInterop =
        factory::<GraphicsCaptureItem, IGraphicsCaptureItemInterop>()?;
    let mut device: Option<ID3D11Device> = None;
    unsafe {
        D3D11CreateDevice(
            None,
            D3D_DRIVER_TYPE_HARDWARE,
            HMODULE::default(),
            D3D11_CREATE_DEVICE_BGRA_SUPPORT,
            None,
            D3D11_SDK_VERSION,
            Some(&mut device),
            None,
            None,
        )?;
    }
    let dxgi: IDXGIDevice = device.unwrap().cast()?;
    let winrt: IDirect3DDevice = unsafe { CreateDirect3D11DeviceFromDXGIDevice(&dxgi)?.cast()? };
    let pool = Direct3D11CaptureFramePool::CreateFreeThreaded(
        &winrt,
        DirectXPixelFormat::B8G8R8A8UIntNormalized,
        1,
        SizeInt32 {
            Width: 64,
            Height: 64,
        },
    )?;
    pool.Close()?;
    println!(
        "{}",
        serde_json::json!({
            "schemaVersion":1, "scope":"temporary-windows-graphics-capture-capability",
            "graphicsCaptureSupported":supported, "interopFactoryAvailable":true,
            "hardwareD3D11DeviceCreated":true, "freeThreadedFramePoolCreatedAndClosed":true,
            "captureSessionStarted":false, "windowsOrPixelsRead":0,
            "applicationMaterialAccepted":false, "productionDependenciesChanged":false
        })
    );
    Ok(())
}
