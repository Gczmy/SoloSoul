from pathlib import Path
import json,hashlib,tarfile,gzip,io,datetime,subprocess,struct,zlib,shutil,sys
r=Path(r'C:\Users\40299571\SoloSoul');b=Path(r'C:\Users\40299571\AppData\Local\Temp');s=b/'ss-rf121-wgc-feasibility-20261006';paired=b/'ss-rf1097-permission-outcomes-v2-20261006';load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
previous=load(s/'before-report-git-preservation.json');git=['git','-C',str(r),'-c','safe.directory=C:/Users/40299571/SoloSoul','-c','core.autocrlf=false','-c','core.safecrlf=false']
def read(args):
 q=subprocess.run(git+args,capture_output=True);assert q.returncode==0;return q.stdout.decode('utf-8-sig').strip()
assert read(['status','--porcelain=v1'])=='' and read(['rev-parse','HEAD'])==previous['head'] and read(['stash','list','--format=%H'])==previous['stash']
assert load(s/'composed-window-cleanup-result.json')['success']
assert all(sha(r/p)==h for p,h in load(paired/'source-freeze.json')['files'].items())
checks=load(s/'capture-build-round5.receipt.json');assert checks['exitCode']==0 and [v['name'] for v in checks['checks']]==['fmt','tests','clippy','build'] and all(v['exitCode']==0 for v in checks['checks'])
assert '4 passed; 0 failed; 0 ignored' in (s/'capture-round5-tests.stdout.log').read_text(encoding='utf-8-sig')
root=b/'ss-rf121-composed-window-round5-20261006';sample=root/'actual100/sample-001';capture=load(root/'capture.receipt.json');proof=load(sample/'rf121-wgc-light-visible.json');owned=load(sample/'native-perf-owned.json');consumed=load(sample/'native-perf-consumed.json')
assert capture['exitCode']==0 and proof==capture['proof'] and proof['pid']==consumed['pid'] and proof['runId']==owned['runId']==consumed['runId'] and proof['heldProcessAndWindowIdentityVerifiedBeforeAndAfter'] and proof['otherWindowsCaptured']==0 and not proof['applicationMaterialAccepted']
assert proof['width']==1030 and proof['height']==781 and proof['dwmSystemBackdropType']==2
assert sha(Path(capture['command'][0]))==load(root/'plan.json')['captureHelperSha256']
assert sha(Path(capture['command'][4]))==load(paired/'build-checkpoint.json')['sha256']
raw=(sample/proof['pixelFile']).read_bytes();png=(sample/'rf121-wgc-light-visible.png').read_bytes();conversion=load(sample/'rf121-png-conversion.json');assert len(raw)==proof['bytes']==1030*781*4 and sha(sample/proof['pixelFile'])==conversion['bgraSha256'] and sha(sample/'rf121-wgc-light-visible.png')==conversion['pngSha256']
# 校验PNG每块CRC和像素转换；不使用截图成功替代主题或材质矩阵。
assert png[:8]==b'\x89PNG\r\n\x1a\n';cursor=8;compressed=b'';ihdr=None
while cursor<len(png):
 length=struct.unpack('>I',png[cursor:cursor+4])[0];tag=png[cursor+4:cursor+8];body=png[cursor+8:cursor+8+length];crc=struct.unpack('>I',png[cursor+8+length:cursor+12+length])[0];assert zlib.crc32(tag+body)&0xffffffff==crc
 if tag==b'IHDR':ihdr=struct.unpack('>IIBBBBB',body)
 if tag==b'IDAT':compressed+=body
 cursor+=12+length
assert cursor==len(png) and ihdr==(1030,781,8,6,0,0,0)
expected=bytearray(raw);expected[0::4]=raw[2::4];expected[2::4]=raw[0::4]
for i in range(0,len(expected),4):
 a=expected[i+3]
 if 0<a<255:
  for c in range(3):expected[i+c]=min(255,(expected[i+c]*255+a//2)//a)
assert zlib.decompress(compressed)==b''.join(b'\0'+expected[y*1030*4:(y+1)*1030*4] for y in range(781))
groups=[];totals={'identities':0,'caches':0,'links':0,'logs':0,'preservedFiles':0,'vaultFiles':0}
for i in (2,3,4,5):
 q=b/f'ss-rf121-composed-window-round{i}-20261006';gui=load(q/'actual100.receipt.json');result=load(q/'actual100/native-perf-sdk-journey-results.json');cleanup=load(q/'actual100-cache-cleanup.json');freeze=load(q/'before-cache-file-freeze.json')['files'];assert gui['exitCode']==0 and result['success'] and result['sourceUnchanged'] and len(result['samples'])==3 and all(v['success'] and v['cleanupIntegrity']['complete'] for v in result['samples']) and all(sha(q/p)==h for p,h in freeze.items())
 for k,key in [('identities','verifiedIdentities'),('caches','removedCachePaths'),('links','unlinkedCacheEntries'),('logs','preservedLogs')]:totals[k]+=len(cleanup[key])
 totals['preservedFiles']+=len(freeze);totals['vaultFiles']+=sum('vault' in Path(p).parts for p in freeze);assert cleanup['complete'] and cleanup['processesTerminated']==0
 groups.append({'stage':q.name,'wholeSamples':3,'driverExitCode':0,'captureExitCode':load(q/'capture.receipt.json')['exitCode'],'performanceAccepted':False})
# 仅收录指定代码、证明和像素文件；排除target、可执行文件、DLL、缓存、Vault与模型。
allowed={'.py','.ps1','.rs','.toml','.lock','.json','.log','.bgra','.png'};entries={}
def add(p,name):
 assert p.is_file() and not p.is_symlink() and not p.is_junction() and p.suffix in allowed and p.stat().st_size<=64*1024*1024 and '..' not in Path(name).parts
 assert name not in entries;entries[name]=p.read_bytes()
for p in sorted(s.iterdir()):
 if p.is_file() and p.suffix in allowed:add(p,'tools/'+p.name)
for p in sorted((s/'src').rglob('*')):
 if p.is_file():add(p,'tools/src/'+p.relative_to(s/'src').as_posix())
for i in (None,2,3,4,5):
 q=b/('ss-rf121-composed-window-20261006' if i is None else f'ss-rf121-composed-window-round{i}-20261006');label='attempt1' if i is None else f'round{i}'
 for p in sorted(q.iterdir()):
  if p.is_file() and p.suffix in allowed:add(p,label+'/'+p.name)
 if (q/'actual100').is_dir():
  for p in sorted((q/'actual100').iterdir()):
   if p.is_file() and p.suffix in allowed:add(p,label+'/actual100/'+p.name)
   elif p.is_dir() and p.name in ['sample-001','sample-002','sample-003']:
    for f in sorted(p.iterdir()):
     if f.is_file() and f.suffix in allowed and (f.name.startswith('native-perf-') or f.name.startswith('rf121-')):add(f,label+'/actual100/'+p.name+'/'+f.name)
    logs=p/'preserved-app-logs'
    if logs.is_dir():
     for f in sorted(logs.rglob('*')):
      if f.is_file():add(f,label+'/actual100/'+p.name+'/preserved-app-logs/'+f.relative_to(logs).as_posix())
archive=io.BytesIO()
with tarfile.open(fileobj=archive,mode='w',format=tarfile.USTAR_FORMAT) as tf:
 for name,data in sorted(entries.items()):
  item=tarfile.TarInfo(name);item.size=len(data);item.mtime=0;item.mode=0o600;tf.addfile(item,io.BytesIO(data))
packed=gzip.compress(archive.getvalue(),compresslevel=9,mtime=0)
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tf:
 assert tf.getnames()==sorted(entries)
 for item in tf:
  assert item.isfile() and tf.extractfile(item).read()==entries[item.name]
stem='rf121-windows-composed-capture-2026-10-06';dest=r/'docs/verification'/stem;assert not dest.exists();dest.mkdir()
(dest/'raw.tar.gz').write_bytes(packed);(dest/'owned-home.png').write_bytes(png)
index={'schemaVersion':1,'scope':'rf121-composed-capture-byte-preserved-raw-evidence','archive':'raw.tar.gz','archiveSha256':hashlib.sha256(packed).hexdigest(),'archiveBytes':len(packed),'entryCount':len(entries),'entries':[{'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for n,data in sorted(entries.items())],'excluded':['target','EXEs','DLLs','models','Vault physical files','cache trees'],'allArchiveEntriesDecodedAndVerified':True}
(dest/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
evidence={'schemaVersion':1,'task':'RF-121','scope':'windows-actual-owned-composed-window-capture-feasibility','at':now(),'sourceHead':previous['head'],'captureMechanismVerified':True,'fullRf121Accepted':False,'productionSourceAndDependenciesChanged':False,'performanceMetrics':None,'fixture':'fixed-public-100-object-Vault','actualGuiExeSha256':load(paired/'build-checkpoint.json')['sha256'],'helperExeSha256':sha(Path(capture['command'][0])),'helperSourceSha256':sha(s/'src/bin/owned-window.rs'),'nativeDriverGroups':groups,'actualFrame':proof,'pngConversion':conversion,'visualInspection':{'method':'view_image','visibleComponents':['native title bar and caption buttons','actual Sidebar','actual content AppBar','actual Home Card/CardGrid'],'observedScene':'Home','workspaceMarkerOnlyTriggeredCaptureNotFrameSceneProof':True,'foregroundStatusRecorded':False,'domThemeAndPaletteRecorded':False},'checks':checks['checks'],'helperTests':{'passed':4,'failed':0,'ignored':0},'cleanup':totals,'cacheCleanupProcessesTerminated':0,'rawIndex':stem+'/index.json','screenshot':stem+'/owned-home.png','rawEntriesDecodedAndVerified':len(entries),'remaining':['explicit DOM/native theme and palette identity','foreground/active state','dark/collapsed/resized/restored actual-window matrix','transient black-frame series','isolated accessibility and remaining platform matrix'],'priorFailuresPreserved':['initial temporary helper compile import failure','sample count preflight failure; no GUI','round2 unique-visible selection failure','round3 two visible owned windows selection failure','round4 HRESULT(0) first-frame retrieval failure','nullable-edit authoring assertion; no source write'],'pushed':False}
(r/'docs/verification'/f'{stem}.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
md=f'''# RF-121 Windows 真实应用完整窗口截图入口

本阶段取得一张1030×781的真实SoloSoul首页截图，包括原生标题栏和按钮、生产Sidebar、内容AppBar及Home Card/CardGrid。与此前仅含WebView的PNG相比，现在具有窗口完整画面；DWM回读SYSTEMBACKDROP_TYPE=2。**这只完成截图入口验证，RF-121仍待验证**：单帧、未知前台状态及未绑定DOM主题/色板不能替代完整材质矩阵。

![公开100对象隔离应用首页](./{stem}/owned-home.png)

## 两处临时工具修正

原工具要求同一进程仅有一个可见顶层窗口。实际记录8个所属窗口、2个可见窗口：主窗口客户区1028×749，另一个16×16辅助窗口客户区0×0，带TOOLWINDOW/NOACTIVATE。依据生产配置的decorations/resizable及真实窗口属性，改为仅选唯一的可见、未最小化、未cloaked、root-owner、caption/sysmenu/thickframe、APPWINDOW、非tool/noactivate且客户区为正的主窗口；缺少或多个主候选仍失败。仅对已校验PID/创建时间/EXE的窗口采集详细状态和像素。

首轮主窗口定位通过后，取帧返回HRESULT(0)错误。官方[TryGetNextFrame接口](https://learn.microsoft.com/en-us/uwp/api/windows.graphics.capture.direct3d11captureframepool.trygetnextframe)允许空帧池返回null，windows 0.61.3生成绑定将nullable结果投射为非Option。临时工具改用同一SDK vtable的HRESULT和nullable输出，成功空值只等待、实际失败仍拒绝，五秒预算保持。固定阶段日志证明最终实际收到帧。

捕获使用CreateForWindow及FreeThreaded frame pool、硬件D3D11、BGRA8；仅复制ContentSize范围，捕获前后核验保留的进程句柄、HWND、几何及style。没有读取其他窗口像素、改系统主题/辅助功能或打开正式账户。临时独立Cargo项目使用已缓存SDK，生产Cargo清单和锁文件未改。

## 实际结果与边界

- 原公开100对象驱动保持至少3次、SDK 128调用上限和原50秒阶段/300秒行程预算。四组各3次完整行程均driver exit0；round2/3截图选择失败，round4取帧失败，round5截图exit0。附加截图使这些组仅作诊断，performanceMetrics=null，不作为新性能基线，也不选成功子集代替整组。
- 截图标签light-visible只是文件标签；workspace阶段完成触发截图，实际图像为Home，不能把触发标记当成捕获时路由或主题证明。未记录前台状态、DOM主题和色板；不能据此判定活动Mica颜色、所有文字对比度或恢复无黑帧。
- 临时工具4项测试通过、0失败/忽略，格式、严格all-targets Clippy、构建exit0。空帧和真实错误、辅助窗口、缺失/歧义主窗口及隐藏/minimized/cloaked/无效字段拒绝均覆盖。生产输入{len(load(paired/'source-freeze.json')['files'])}个文件SHA保持，未重复未受影响的F/R/CLI检查。
- BGRA原件逐字节保留；PNG仅用于查看，部分alpha反预乘有舍入，不声称PNG可还原原始BGRA。PNG块CRC、尺寸、解压像素与转换算法均实际核验。
- fresh CIM复核{totals['identities']}个记录身份已退出；只清理{totals['caches']}个核验缓存路径、解除{totals['links']}个私有链接，保留{totals['vaultFiles']}个Vault文件、全部证明/截图及{totals['logs']}份日志，缓存工具未终止进程。原preflight、编译、选择和取帧失败均保留。

## 复核与下一步

[结构化证据](./{stem}.json)绑定GUI/helper EXE SHA、源码、真实检查和窗口身份；[原件索引](./{stem}/index.json)列出{len(entries)}份逐字节原件，单独归档于raw.tar.gz。归档已逐成员解压核验SHA/长度；不含EXE、DLL、模型、Vault实体文件和缓存。原件中的tools/Cargo.toml、Cargo.lock、src/bin/owned-window.rs可在独立临时目录重建工具；原固定路径和owned marker守卫必须保留，不能对正式账户执行。构建命令、五参数调用和退出码均在原始receipt中。

后续在同一隔离应用中绑定实际主题/色板及前台状态，补浅深色、折叠、缩放、隐藏/最小化恢复的稳定帧和黑帧序列。高对比矩阵仍需可恢复的隔离会话，macOS/Android剩余验收保持未完成。RF-112/121/312、RF-122～127前置及278/287关闭数保持；独立本地提交，不推送，整体goal继续active。
'''
(r/'docs/verification/RF-121-windows-composed-capture.md').write_text(md,encoding='utf-8',newline='\n')
p=r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';report=p.read_text(encoding='utf-8-sig');old='> 最后更新：2026-10-06（RF-1097 Windows权限命令无窗口启动修复完成）';assert old in report;report=report.replace(old,'> 最后更新：2026-10-06（RF-121 Windows真实应用完整窗口截图入口补证）',1)
old='- 当前处理：**RF-1097本机真实GUI权限/性能对照已验收；下一本地项为RF-312首页超时诊断及RF-121 Windows完整窗口合成。RF-112/121/312及RF-122～127前置保持未完成**。';assert old in report;report=report.replace(old,'- 当前处理：**RF-121 Windows真实应用完整窗口截图入口已验证；下一本地项为实际主题/前台状态与折叠/恢复矩阵，以及RF-312首页超时诊断。RF-112/121/312及RF-122～127前置保持未完成**。',1)
report+=f'''\n### RF-121 Windows真实应用完整窗口截图入口补证（2026-10-06）

- 基线0b45c839，生产源码/依赖保持。独立临时WGC工具先遇到唯一可见窗口拒绝；实际同PID有8窗口、2可见，其中16×16辅助窗口客户区为零。主候选按生产decorations/resizable等属性限定，仍要求唯一并验证保留进程句柄、PID/创建时间/EXE、HWND及捕获前后几何/style。
- 主窗口选择通过后保留HRESULT(0)取帧失败；依据官方nullable返回契约处理空帧等待，不忽略真实失败、不延长五秒预算。最终实际收到1030×781的单窗口合成帧，标题栏/按钮、真实Sidebar/AppBar/Home卡片可见，DWM材质回读2。前台状态与DOM主题/色板未绑定；标签及workspace触发标记不当作主题/捕获路由证明。
- 原三次完整行程和SDK/时限门禁保持；round2/3/4/5共12次完整driver行程exit0，但仅最后一次截图exit0。所有组仅诊断、performanceMetrics=null，旧失败不删除、不拼成功子集。独立工具4测试/严格Clippy/格式/构建通过，未重复不受影响的生产检查。
- fresh CIM复核{totals['identities']}个身份退出，清理{totals['caches']}个精确缓存并解除{totals['links']}链接；{totals['vaultFiles']}个Vault文件、{totals['logs']}日志及全部证明/截图保持。PNG转换有部分alpha舍入，原BGRA逐字节保留。工具未终止进程。
- [口径与截图](verification/RF-121-windows-composed-capture.md)、[结构化证据](verification/{stem}.json)和[{len(entries)}份原件索引](verification/{stem}/index.json)归档。下一步绑定实际主题/色板/前台状态，补浅深色、折叠、缩放和恢复帧矩阵；单帧不替代瞬间黑帧、辅助功能或多端验收。
- 按RF-121阶段独立本地提交，不推送；278/287关闭、3待验证、6待执行保持，RF-112/121/312与RF-122～127前置不解除，goal继续active。
'''
p.write_text(report,encoding='utf-8',newline='\n')
(s/'final-document-result.json').write_text(json.dumps({'at':now(),'success':True,'rawEntries':len(entries),'rawArchiveBytes':len(packed),'pixelCrcAndConvertedRowsVerified':True,'productionSourceFreezeVerified':True,'fullRf121Accepted':False,'committed':False,'pushed':False,'paths':['docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md','docs/verification/RF-121-windows-composed-capture.md','docs/verification/'+stem+'.json','docs/verification/'+stem+'/index.json','docs/verification/'+stem+'/raw.tar.gz','docs/verification/'+stem+'/owned-home.png']},indent=2)+'\n',encoding='utf-8',newline='\n')
print(f'Prepared RF-121 documents, screenshot and {len(entries)} verified raw members; final review and local commit remain')
