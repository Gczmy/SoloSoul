from pathlib import Path
import json,tarfile,gzip,io,hashlib,datetime
r=Path(r'C:\Users\40299571\SoloSoul');b=Path(r'C:\Users\40299571\AppData\Local\Temp');s=b/'ss-rf121-wgc-feasibility-20261006';stem='rf121-windows-composed-capture-2026-10-06';dest=r/'docs/verification'/stem;load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda data:hashlib.sha256(data).hexdigest()
old=(dest/'raw.tar.gz').read_bytes();assert not (s/'raw-archive-before-vault-scope-correction.tar.gz').exists();(s/'raw-archive-before-vault-scope-correction.tar.gz').write_bytes(old)
entries={}
with tarfile.open(fileobj=io.BytesIO(old),mode='r:gz') as tf:
 for item in tf:assert item.isfile();entries[item.name]=tf.extractfile(item).read()
new_files=[(s/'vault-preservation-scope-correction.json','tools/vault-preservation-scope-correction.json'),(Path(__file__),'tools/correct-composed-document-scope.py')]
for i in (2,3,4,5):new_files.append((b/f'ss-rf121-composed-window-round{i}-20261006/vault-after-cache-verification.json',f'round{i}/vault-after-cache-verification.json'))
for path,name in new_files:assert name not in entries;entries[name]=path.read_bytes()
data=io.BytesIO()
with tarfile.open(fileobj=data,mode='w',format=tarfile.USTAR_FORMAT) as tf:
 for name,body in sorted(entries.items()):item=tarfile.TarInfo(name);item.size=len(body);item.mode=0o600;item.mtime=0;tf.addfile(item,io.BytesIO(body))
packed=gzip.compress(data.getvalue(),compresslevel=9,mtime=0)
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tf:
 assert tf.getnames()==sorted(entries)
 for item in tf:assert item.isfile() and tf.extractfile(item).read()==entries[item.name]
(dest/'raw.tar.gz').write_bytes(packed)
index=load(dest/'index.json');index.update({'archiveSha256':sha(packed),'archiveBytes':len(packed),'entryCount':len(entries),'entries':[{'path':n,'bytes':len(v),'sha256':sha(v)} for n,v in sorted(entries.items())],'previousDraftArchiveSha256':sha(old),'scopeCorrection':'Vault traversal before cleanup had no entries; only root evidence was compared before/after. New elevated after-only Vault measurement retained.'});(dest/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
count=sum(load(b/f'ss-rf121-composed-window-round{i}-20261006/vault-after-cache-verification.json')['actualFileCount'] for i in (2,3,4,5));assert count==108
p=r/'docs/verification'/f'{stem}.json';v=load(p);v['cleanup'].pop('vaultFiles');v['cleanup'].update({'vaultFilesAfterCleanup':count,'rootEvidenceFilesComparedBeforeAndAfter':175,'vaultHashesComparedBeforeAndAfter':False});v['rawEntriesDecodedAndVerified']=len(entries);v['vaultPreservationScopeCorrection']='Earlier cleanup wrapper field mentioned Vault but freeze actually contained only root evidence. Protected Vault is excluded from delete targets; after-only hashes now recorded.';p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=r/'docs/verification/RF-121-windows-composed-capture.md';v=p.read_text(encoding='utf-8-sig');v=v.replace('保留0个Vault文件、全部证明/截图及12份日志','175个根级证明/截图文件通过前后哈希比对；Vault不在删除清单，清理后核对108个文件及哈希；未取得清理前Vault哈希，不能声称其前后逐字节比对；12份日志另行保留');v=v.replace('360份逐字节原件',str(len(entries))+'份逐字节原件');p.write_text(v,encoding='utf-8',newline='\n')
p=r/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';v=p.read_text(encoding='utf-8-sig');v=v.replace('0个Vault文件、12日志及全部证明/截图保持。PNG转换','175个根级证明/截图文件前后哈希一致，12日志保持；Vault未列入删除目标，清理后核对108文件及哈希，未取得清理前Vault哈希。PNG转换');v=v.replace('[360份原件索引](verification/'+stem+'/index.json)','['+str(len(entries))+'份原件索引](verification/'+stem+'/index.json)');p.write_text(v,encoding='utf-8',newline='\n')
p=r/'docs/design_map/10_跨平台视觉规范与主题系统.md';v=p.read_text(encoding='utf-8-sig');old='仅WebView像素，标题栏合成颜色/辅助功能/兼容回退完整矩阵待验；当前路径不使用 Acrylic';assert old in v;v=v.replace(old,'此前仅WebView像素；[2026-10-06真实应用WGC补证](../verification/RF-121-windows-composed-capture.md)取得包含原生标题栏、实际Sidebar/AppBar/Home卡片的单帧。前台状态/DOM主题色板未绑定，完整标题栏颜色/辅助功能/兼容回退矩阵仍待验；当前路径不使用 Acrylic',1);p.write_text(v,encoding='utf-8',newline='\n')
p=r/'docs/design_map/27_平台能力契约.md';v=p.read_text(encoding='utf-8-sig');old='不是完整Sidebar/AppBar或DWM标题栏像素；高对比度/减少透明度完整矩阵仍待RF-121';assert old in v;v=v.replace(old,'此前独立Card仅含WebView；[2026-10-06真实应用WGC单帧入口](../verification/RF-121-windows-composed-capture.md)已包含标题栏及实际Sidebar/AppBar/Home卡片，尚未绑定前台状态与DOM主题色板；多场景/高对比度/减少透明度完整矩阵仍待RF-121',1);p.write_text(v,encoding='utf-8',newline='\n')
p=s/'final-document-result.json';v=load(p);v.update({'rawEntries':len(entries),'rawArchiveBytes':len(packed),'vaultPreservationScopeCorrected':True,'vaultAfterOnlyFiles':count});v['paths']+=['docs/design_map/10_跨平台视觉规范与主题系统.md','docs/design_map/27_平台能力契约.md'];p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
print(f'Corrected preservation scope, updated two canonical specs, and verified {len(entries)} archive members')
