from pathlib import Path
import subprocess,json,time,datetime,hashlib,threading,sys,os
sys.stdout.reconfigure(encoding='utf-8')
r=Path(r'C:\Users\40299571\SoloSoul');paired=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf1097-permission-outcomes-v2-20261006');tools=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf121-wgc-feasibility-20261006');s=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf121-composed-window-round2-20261006');assert not s.exists();s.mkdir()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
pwsh=r'C:\Users\40299571\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe'
build=load(paired/'build-checkpoint.json');exe=Path(build['exe']);capture=tools/'target/debug/rf121-wgc-owned-window.exe';assert sha(exe)==build['sha256'] and load(tools/'capture-build-round2.receipt.json')['exitCode']==0
assert all(sha(r/p)==h for p,h in load(paired/'source-freeze.json')['files'].items())
(s/'source-freeze.json').write_bytes((paired/'source-freeze.json').read_bytes());(s/'plan.json').write_text(json.dumps({'at':now(),'task':'RF-121','head':'0b45c83924cef614c4e149392cd95993aca94a0a','scope':'actual-owned-public-application-composed-window-capture-diagnostic','diagnosticOnly':True,'applicationMaterialAccepted':False,'performanceMetrics':None,'fixedNativeSdkDriverAndBudgetsUnchanged':True,'actualGuiExeSha256':sha(exe),'captureHelperSha256':sha(capture),'ownedRoot':str(s),'otherWindowsAllowed':False,'systemThemeOrAccessibilitySettingsModified':False},indent=2)+'\n',encoding='utf-8',newline='\n')
output=s/'actual100';sample=output/'sample-001';env=os.environ.copy();env['PATH']=r'C:\Program Files\Git\usr\bin;'+env.get('PATH','');env.pop('PDFIUM_LIBRARY_PATH',None)
command=['node','scripts/native-perf-auth-attribution.mjs','--exe',str(exe),'--fixture',r'C:\Users\40299571\AppData\Local\Temp\solosoul-rf312-native-fixtures-20260930\vault100','--output',str(output),'--samples','3']
started=time.monotonic()
with (s/'actual100.stdout.log').open('xb') as out,(s/'actual100.stderr.log').open('xb') as err:
 process=subprocess.Popen(command,cwd=r/'tauri',env=env,stdout=out,stderr=err)
 (s/'actual100.live.json').write_text(json.dumps({'at':now(),'pid':process.pid,'command':command,'diagnosticOnly':True},indent=2)+'\n',encoding='utf-8')
 print('Started three-sample actual owned application screenshot diagnostic PID '+str(process.pid),flush=True)
 capture_result={};state={'done':False}
 def capture_once():
  try:
   deadline=time.monotonic()+300
   while not (sample/'native-perf-consumed.json').exists():
    if process.poll() is not None or time.monotonic()>deadline:raise RuntimeError('actual-consumed-marker-not-observed')
    time.sleep(.01)
   consumed=load(sample/'native-perf-consumed.json');pid=consumed['pid'];assert type(pid) is int and pid>0
   query=f"$taskProcess=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}' -Property ProcessId,CreationDate,ExecutablePath; if($null -eq $taskProcess -or $null -eq $taskProcess.CreationDate -or [string]::IsNullOrEmpty($taskProcess.ExecutablePath)){{throw 'Incomplete owned process identity'}}; [ordered]@{{pid=[int]$taskProcess.ProcessId;creationMs=([DateTimeOffset]$taskProcess.CreationDate.ToUniversalTime()).ToUnixTimeMilliseconds();exe=[string]$taskProcess.ExecutablePath}} | ConvertTo-Json -Compress"
   identity=subprocess.run([pwsh,'-NoLogo','-NoProfile','-Command',query],capture_output=True);(s/'identity-query.stdout.log').write_bytes(identity.stdout);(s/'identity-query.stderr.log').write_bytes(identity.stderr);assert identity.returncode==0
   owner=json.loads(identity.stdout.decode('utf-8-sig'));assert owner['pid']==pid and Path(owner['exe']).resolve()==exe.resolve();(s/'owned-process-identity.json').write_text(json.dumps(owner,indent=2)+'\n',encoding='utf-8')
   while not (sample/'native-perf-sdk-phase-03.json').exists():
    if process.poll() is not None or time.monotonic()>deadline:raise RuntimeError('actual-workspace-phase-not-observed')
    time.sleep(.01)
   phase=load(sample/'native-perf-sdk-phase-03.json');assert phase['success'] and phase['name']=='workspace'
   tag='light-visible' # 仅固定产物标签，不作为已验证的主题结论。
   args=[str(capture),str(sample),str(pid),str(owner['creationMs']),str(exe),tag];begin=time.monotonic()
   captured=subprocess.run(args,cwd=tools,capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW)
   (s/'capture.stdout.log').write_bytes(captured.stdout);(s/'capture.stderr.log').write_bytes(captured.stderr)
   capture_result.update({'at':now(),'command':args,'exitCode':captured.returncode,'elapsedSeconds':time.monotonic()-begin,'actualPhaseMarker':'workspace','captureDiagnosticOnly':True,'tagIsUnverifiedThemeLabel':True,'performanceMetrics':None})
   if captured.returncode==0:
    proof=json.loads(captured.stdout.decode('utf-8-sig'));assert proof['scope']=='rf121-owned-window-wgc-frame' and not proof['applicationMaterialAccepted'] and proof['pid']==pid and proof['otherWindowsCaptured']==0
    capture_result['proof']=proof
  except Exception as exc:capture_result.update({'at':now(),'exitCode':1,'errorCategory':type(exc).__name__,'captureDiagnosticOnly':True,'performanceMetrics':None})
  finally:state['done']=True
 thread=threading.Thread(target=capture_once);thread.start();rc=process.wait();thread.join()
(s/'actual100.receipt.json').write_text(json.dumps({'at':now(),'exitCode':rc,'command':command,'elapsedSeconds':time.monotonic()-started,'performanceAccepted':False,'captureDiagnosticOnly':True},indent=2)+'\n',encoding='utf-8');(s/'capture.receipt.json').write_text(json.dumps(capture_result,indent=2)+'\n',encoding='utf-8')
assert all(sha(r/p)==h for p,h in load(s/'source-freeze.json')['files'].items()) and sha(exe)==build['sha256']
print('Actual three-sample UI driver exit '+str(rc)+'; owned whole-window capture exit '+str(capture_result.get('exitCode')),flush=True);sys.exit(rc or capture_result.get('exitCode',1))