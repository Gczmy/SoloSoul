from pathlib import Path
import shutil,json,datetime,hashlib,ast
s=Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf121-wgc-feasibility-20261006');load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert load(s/'capture-build.receipt.json')['exitCode']==101
p=s/'src/bin/owned-window.rs';before=p.read_text(encoding='utf-8');assert before.count('SYNCHRONIZE')==2
backup=s/'owned-window.authoring-v1.rs';assert not backup.exists();shutil.copy2(p,backup)
after=before.replace('SYNCHRONIZE','PROCESS_SYNCHRONIZE').replace('GetClientRect, ClientToScreen','GetClientRect').replace('Dxgi::IDXGIDevice,','Dxgi::{IDXGIDevice, Common::DXGI_FORMAT_B8G8R8A8_UNORM}, Gdi::ClientToScreen,').replace('desc.SampleDesc.Count==1','desc.SampleDesc.Count==1 && desc.Format==DXGI_FORMAT_B8G8R8A8_UNORM')
p.write_text(after,encoding='utf-8',newline='\n')
manifest=s/'Cargo.toml';prior=manifest.read_text(encoding='utf-8');shutil.copy2(manifest,s/'capture-Cargo.authoring-v1.toml');manifest.write_text(prior.replace('"Win32_Graphics_Dwm",','"Win32_Graphics_Dwm", "Win32_Graphics_Gdi",',1),encoding='utf-8',newline='\n')
runner=(s/'build-owned-capture.py').read_text(encoding='utf-8').replace('capture-build','capture-build-round2');ast.parse(runner);(s/'build-owned-capture-round2.py').write_text(runner,encoding='utf-8',newline='\n')
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'firstActualCompileExitCode':101,'correctedSdkNamespaces':['PROCESS_SYNCHRONIZE','Win32.Graphics.Gdi.ClientToScreen'],'capturePixelFormatExplicitlyVerified':True,'productionSourcesOrDependenciesChanged':False,'captureNotYetExecuted':True,'sourceSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'manifestSha256':hashlib.sha256(manifest.read_bytes()).hexdigest()}
(s/'capture-authoring-correction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n');print('Preserved first build and corrected temporary SDK imports')