from pathlib import Path

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
text = (root / 'build/rf312-home-memory-20261010/cleanup-owned.ps1').read_text()
changes = [
    (r"'D:\SoloSoul\build\rf312-home-memory-20261010'", r"'D:\SoloSoul\build\rf121-theme-binding-20261010\ss-rf121-composed-window-current'"),
    ('validation.groups.Count -ne 2', 'validation.samples.Count -ne 3'),
    ('validation.groups.samples.recordedIdentities', 'validation.samples.recordedIdentities'),
    ('identities.Count -lt 20', 'identities.Count -lt 6'),
    (r"'D:\SoloSoul\build\rf1104-update-preferences-20261010\bin\solo_soul.exe'", r"'D:\SoloSoul\build\rf121-theme-binding-20261010\ss-rf121-runtime\bin\solo_soul.exe'"),
    ('foreach ($group in $validation.groups)', 'foreach ($group in @([pscustomobject]@{complete=$true;samples=$validation.samples}))'),
    ('group.samples.Count -ne 5', 'group.samples.Count -ne 3'),
    ("('samples' + $group.objects)", "'actual100'"),
    ("'application-logs\\' + $group.objects + '\\sample-'", "'application-logs\\100\\sample-'"),
    ('targets.Count -ne 80 -or @($targets | Sort-Object -Unique).Count -ne 80', 'targets.Count -ne 24 -or @($targets | Sort-Object -Unique).Count -ne 24'),
    ('Exact eighty owned cache paths required', 'Exact twenty-four owned cache paths required'),
    ("task='RF-312'", "task='RF-121'"),
]
for before, after in changes:
    assert text.count(before) == 1, (before, text.count(before))
    text = text.replace(before, after)
with (stage / 'cleanup-surface-owned.ps1').open('x', encoding='utf-8', newline='\n') as out:
    out.write(text)
print('Prepared exact-three-sample cleanup; not executed')
