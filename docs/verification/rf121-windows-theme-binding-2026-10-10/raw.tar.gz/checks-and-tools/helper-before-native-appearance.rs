use serde_json::{json, Value};
use std::{
    env, fs,
    io::Write,
    os::windows::fs::MetadataExt,
    path::{Path, PathBuf},
    time::{Duration, Instant},
};
use windows::Win32::UI::HiDpi::GetDpiForWindow;
use windows::{
    core::{factory, Interface, BOOL, PWSTR},
    Graphics::{
        Capture::{
            Direct3D11CaptureFrame, Direct3D11CaptureFramePool, GraphicsCaptureItem,
            GraphicsCaptureSession,
        },
        DirectX::{Direct3D11::IDirect3DDevice, DirectXPixelFormat},
    },
    Win32::{
        Foundation::{
            CloseHandle, FILETIME, HANDLE, HMODULE, HWND, LPARAM, POINT, RECT, WAIT_TIMEOUT,
        },
        Graphics::{
            Direct3D::D3D_DRIVER_TYPE_HARDWARE,
            Direct3D11::*,
            Dwm::{
                DwmGetWindowAttribute, DWMWA_CLOAKED, DWMWA_EXTENDED_FRAME_BOUNDS,
                DWMWA_SYSTEMBACKDROP_TYPE,
            },
            Dxgi::{Common::DXGI_FORMAT_B8G8R8A8_UNORM, IDXGIDevice},
            Gdi::ClientToScreen,
        },
        System::{
            Threading::{
                GetProcessTimes, OpenProcess, QueryFullProcessImageNameW, WaitForSingleObject,
                PROCESS_NAME_WIN32, PROCESS_QUERY_LIMITED_INFORMATION, PROCESS_SYNCHRONIZE,
            },
            WinRT::{
                Direct3D11::{CreateDirect3D11DeviceFromDXGIDevice, IDirect3DDxgiInterfaceAccess},
                Graphics::Capture::IGraphicsCaptureItemInterop,
                RoInitialize, RO_INIT_MULTITHREADED,
            },
        },
        UI::WindowsAndMessaging::{
            EnumWindows, GetAncestor, GetClientRect, GetForegroundWindow, GetWindowLongPtrW,
            GetWindowRect, GetWindowThreadProcessId, IsIconic, IsWindowVisible, GA_ROOTOWNER,
            GWL_EXSTYLE, GWL_STYLE, WS_CAPTION, WS_CHILD, WS_EX_APPWINDOW, WS_EX_NOACTIVATE,
            WS_EX_TOOLWINDOW, WS_POPUP, WS_SYSMENU, WS_THICKFRAME,
        },
    },
};
type Outcome<T> = Result<T, Box<dyn std::error::Error>>;
fn require(ok: bool, message: &'static str) -> Outcome<()> {
    if ok {
        Ok(())
    } else {
        Err(message.into())
    }
}
fn ordinary(p: &Path, directory: bool) -> Outcome<()> {
    let m = fs::symlink_metadata(p)?;
    require(
        m.file_attributes() & 0x400 == 0 && m.is_dir() == directory && (directory || m.is_file()),
        "ordinary-owned-path-required",
    )
}
fn read(p: &Path) -> Outcome<Value> {
    ordinary(p, false)?;
    require(
        fs::metadata(p)?.len() <= 262144,
        "bounded-owner-marker-required",
    )?;
    Ok(serde_json::from_slice(&fs::read(p)?)?)
}
fn normalized(p: &Path) -> Outcome<String> {
    let text = p.canonicalize()?.to_string_lossy().into_owned();
    Ok(text
        .strip_prefix(r"\\?\")
        .unwrap_or(&text)
        .to_ascii_lowercase())
}
fn same(p: &Path, q: &Path) -> Outcome<bool> {
    Ok(normalized(p)? == normalized(q)?)
}
struct Held(HANDLE);
impl Drop for Held {
    fn drop(&mut self) {
        unsafe {
            let _ = CloseHandle(self.0);
        }
    }
}
fn verify_process(handle: HANDLE, expected_exe: &Path, birth_ms: u64) -> Outcome<()> {
    require(
        unsafe { WaitForSingleObject(handle, 0) } == WAIT_TIMEOUT,
        "owned-process-not-live",
    )?;
    let (mut birth, mut exit, mut kernel, mut user) = (
        FILETIME::default(),
        FILETIME::default(),
        FILETIME::default(),
        FILETIME::default(),
    );
    unsafe {
        GetProcessTimes(handle, &mut birth, &mut exit, &mut kernel, &mut user)?;
    }
    let ticks = ((birth.dwHighDateTime as u64) << 32) | birth.dwLowDateTime as u64;
    require(
        ticks / 10000 - 11644473600000 == birth_ms,
        "owned-process-birth-mismatch",
    )?;
    let mut name = vec![0u16; 32768];
    let mut len = name.len() as u32;
    unsafe {
        QueryFullProcessImageNameW(
            handle,
            PROCESS_NAME_WIN32,
            PWSTR(name.as_mut_ptr()),
            &mut len,
        )?;
    }
    require(
        same(
            Path::new(&String::from_utf16(&name[..len as usize])?),
            expected_exe,
        )?,
        "owned-process-exe-mismatch",
    )
}
struct Windows {
    pid: u32,
    values: Vec<HWND>,
}
unsafe extern "system" fn each(hwnd: HWND, param: LPARAM) -> BOOL {
    let state = unsafe { &mut *(param.0 as *mut Windows) };
    let mut pid = 0;
    unsafe {
        GetWindowThreadProcessId(hwnd, Some(&mut pid));
    }
    if pid == state.pid {
        state.values.push(hwnd);
    }
    BOOL(1)
}
fn verify_hwnd(hwnd: HWND, pid: u32) -> Outcome<()> {
    let mut actual = 0;
    unsafe {
        GetWindowThreadProcessId(hwnd, Some(&mut actual));
    }
    require(
        actual == pid
            && unsafe { IsWindowVisible(hwnd) }.as_bool()
            && !unsafe { IsIconic(hwnd) }.as_bool(),
        "owned-window-identity-or-visibility-changed",
    )?;
    let mut cloaked = 0u32;
    unsafe {
        DwmGetWindowAttribute(hwnd, DWMWA_CLOAKED, (&mut cloaked as *mut u32).cast(), 4)?;
    }
    require(cloaked == 0, "owned-window-cloaked")
}
fn nullable_frame(
    status: windows::core::HRESULT,
    raw: *mut std::ffi::c_void,
) -> windows::core::Result<Option<Direct3D11CaptureFrame>> {
    status.ok()?;
    if raw.is_null() {
        Ok(None)
    } else {
        Ok(Some(unsafe { Direct3D11CaptureFrame::from_raw(raw) }))
    }
}
fn next_frame(
    pool: &Direct3D11CaptureFramePool,
) -> windows::core::Result<Option<Direct3D11CaptureFrame>> {
    let mut raw = std::ptr::null_mut();
    let status =
        unsafe { (Interface::vtable(pool).TryGetNextFrame)(Interface::as_raw(pool), &mut raw) };
    nullable_frame(status, raw)
}
fn main_candidate(v: &Value) -> bool {
    let Some(style) = v["style"].as_u64() else {
        return false;
    };
    let Some(ex) = v["exStyle"].as_u64() else {
        return false;
    };
    let required = (WS_CAPTION.0 | WS_THICKFRAME.0 | WS_SYSMENU.0) as u64;
    let forbidden = (WS_CHILD.0 | WS_POPUP.0) as u64;
    let forbidden_ex = (WS_EX_TOOLWINDOW.0 | WS_EX_NOACTIVATE.0) as u64;
    let client = v["clientRect"].as_array();
    v["visible"] == true
        && v["iconic"] == false
        && v["cloaked"].as_u64() == Some(0)
        && v["hwnd"]
            .as_u64()
            .is_some_and(|hwnd| hwnd > 0 && v["rootOwnerHwnd"].as_u64() == Some(hwnd))
        && style & required == required
        && style & forbidden == 0
        && ex & WS_EX_APPWINDOW.0 as u64 != 0
        && ex & forbidden_ex == 0
        && client.is_some_and(|r| {
            r.len() == 4
                && r[0].as_i64() == Some(0)
                && r[1].as_i64() == Some(0)
                && r[2].as_i64().is_some_and(|w| w > 0 && w <= 16384)
                && r[3].as_i64().is_some_and(|h| h > 0 && h <= 16384)
        })
}
fn select_main(inventory: &[Value]) -> Outcome<usize> {
    let candidates: Vec<usize> = inventory
        .iter()
        .enumerate()
        .filter_map(|(i, v)| main_candidate(v).then_some(i))
        .collect();
    require(
        candidates.len() == 1,
        "one-visible-owned-decorated-main-window-required",
    )?;
    Ok(candidates[0])
}
fn rect(r: RECT) -> [i32; 4] {
    [r.left, r.top, r.right, r.bottom]
}
fn save_new(p: &Path, body: &[u8]) -> Outcome<()> {
    let mut f = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(p)?;
    f.write_all(body)?;
    f.flush()?;
    Ok(())
}
fn main() -> Outcome<()> {
    let args: Vec<String> = env::args().skip(1).collect();
    require(args.len() == 5, "root-pid-birth-exe-fixed-tag-required")?;
    let root = PathBuf::from(&args[0]);
    ordinary(&root, true)?;
    let temp = PathBuf::from(r"C:\Users\40299571\AppData\Local\Temp");
    let canonical = root.canonicalize()?;
    let canonical_temp = temp.canonicalize()?;
    let rel = canonical.strip_prefix(&canonical_temp)?;
    let first = rel
        .components()
        .next()
        .ok_or("owned-stage-required")?
        .as_os_str()
        .to_string_lossy();
    require(
        first.starts_with("ss-rf121-composed-window-"),
        "only-rf121-owned-temporary-stage-allowed",
    )?;
    let mut ancestor = root.as_path();
    while !same(ancestor, &temp)? {
        ordinary(ancestor, true)?;
        ancestor = ancestor.parent().ok_or("owned-stage-ancestor-required")?;
    }
    let pid: u32 = args[1].parse()?;
    let birth_ms: u64 = args[2].parse()?;
    let exe = PathBuf::from(&args[3]);
    ordinary(&exe, false)?;
    require(
        normalized(&exe)?.starts_with(&(normalized(&temp)? + "\\ss-rf")),
        "only-frozen-owned-temporary-exe-allowed",
    )?;
    let tag = &args[4];
    require(
        [
            "light-visible",
            "dark-visible",
            "light-restored",
            "dark-restored",
            "light-collapsed",
            "dark-collapsed",
            "light-resized",
            "dark-resized",
        ]
        .contains(&tag.as_str()),
        "fixed-capture-tag-required",
    )?;
    let raw_path = root.join(format!("rf121-wgc-{tag}.bgra"));
    let json_path = root.join(format!("rf121-wgc-{tag}.json"));
    require(
        !raw_path.exists() && !json_path.exists(),
        "refuse-overwrite-capture",
    )?;
    let owned = read(&root.join("native-perf-owned.json"))?;
    let consumed = read(&root.join("native-perf-consumed.json"))?;
    let run = owned["runId"].as_str().ok_or("owned-run-required")?;
    require(
        run.len() == 32
            && run.bytes().all(|b| b.is_ascii_hexdigit())
            && owned["schemaVersion"] == 1
            && owned["scope"] == "windows-native-perf-owned"
            && owned["nativePerfFeature"] == true,
        "owned-marker-invalid",
    )?;
    require(
        same(
            Path::new(owned["root"].as_str().ok_or("owned-root-required")?),
            &root,
        )? && consumed["schemaVersion"] == 1
            && consumed["scope"] == "windows-native-perf-consumed"
            && consumed["runId"] == run
            && consumed["pid"] == pid
            && same(
                Path::new(consumed["root"].as_str().ok_or("consumed-root-required")?),
                &root,
            )?,
        "actual-consumed-process-binding-required",
    )?;
    let handle = Held(unsafe {
        OpenProcess(
            PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_SYNCHRONIZE,
            false,
            pid,
        )?
    });
    verify_process(handle.0, &exe, birth_ms)?;
    let mut windows = Windows {
        pid,
        values: Vec::new(),
    };
    unsafe {
        EnumWindows(Some(each), LPARAM((&mut windows as *mut Windows) as isize))?;
    }
    require(
        windows.values.len() <= 64,
        "bounded-owned-window-inventory-required",
    )?;
    let inventory:Vec<Value>=windows.values.iter().map(|hwnd| {
        let (mut client,mut outer)=(RECT::default(),RECT::default());let mut cloaked=0u32;
        let client_ok=unsafe { GetClientRect(*hwnd,&mut client) }.is_ok();
        let outer_ok=unsafe { GetWindowRect(*hwnd,&mut outer) }.is_ok();
        let cloak=unsafe { DwmGetWindowAttribute(*hwnd,DWMWA_CLOAKED,(&mut cloaked as *mut u32).cast(),4) };
        json!({"hwnd":hwnd.0 as usize,"visible":unsafe { IsWindowVisible(*hwnd) }.as_bool(),"iconic":unsafe { IsIconic(*hwnd) }.as_bool(),"style":unsafe { GetWindowLongPtrW(*hwnd,GWL_STYLE) } as u64,"exStyle":unsafe { GetWindowLongPtrW(*hwnd,GWL_EXSTYLE) } as u64,"rootOwnerHwnd":unsafe { GetAncestor(*hwnd,GA_ROOTOWNER) }.0 as usize,"clientRect":if client_ok { Some(rect(client)) } else { None },"windowRect":if outer_ok { Some(rect(outer)) } else { None },"cloaked":if cloak.is_ok() { Some(cloaked) } else { None },"dwmQueryError":cloak.err().map(|e|e.code().0)})
    }).collect();
    verify_process(handle.0, &exe, birth_ms)?;
    let visible: Vec<HWND> = windows
        .values
        .iter()
        .copied()
        .filter(|hwnd| unsafe { IsWindowVisible(*hwnd) }.as_bool())
        .collect();
    let window_inventory = json!({"schemaVersion":1,"scope":"rf121-owned-process-window-inventory","runId":run,"pid":pid,"creationMs":birth_ms,"windowCount":inventory.len(),"visibleWindowCount":visible.len(),"windows":&inventory,"heldProcessIdentityVerifiedBeforeAndAfter":true,"otherProcessWindowsInspected":0,"pixelsRead":0});
    save_new(
        &root.join(format!("rf121-window-inventory-{tag}.json")),
        &serde_json::to_vec_pretty(&window_inventory)?,
    )?;
    let selected = select_main(&inventory)?;
    let hwnd = windows.values[selected];
    verify_hwnd(hwnd, pid)?;
    let selected_style = unsafe { GetWindowLongPtrW(hwnd, GWL_STYLE) };
    let selected_ex_style = unsafe { GetWindowLongPtrW(hwnd, GWL_EXSTYLE) };
    require(
        selected_style as u64
            == inventory[selected]["style"]
                .as_u64()
                .ok_or("selected-window-style-required")?
            && selected_ex_style as u64
                == inventory[selected]["exStyle"]
                    .as_u64()
                    .ok_or("selected-window-ex-style-required")?,
        "selected-window-style-changed",
    )?;
    let (mut outer, mut client, mut bounds) = (RECT::default(), RECT::default(), RECT::default());
    let mut origin = POINT::default();
    let mut backdrop = 0u32;
    let foreground_before = unsafe { GetForegroundWindow() } == hwnd;
    let dpi_before = unsafe { GetDpiForWindow(hwnd) };
    require(dpi_before > 0, "owned-window-dpi-required")?;
    unsafe {
        GetWindowRect(hwnd, &mut outer)?;
        GetClientRect(hwnd, &mut client)?;
        require(
            ClientToScreen(hwnd, &mut origin).as_bool(),
            "client-screen-origin-failed",
        )?;
        DwmGetWindowAttribute(
            hwnd,
            DWMWA_EXTENDED_FRAME_BOUNDS,
            (&mut bounds as *mut RECT).cast(),
            std::mem::size_of::<RECT>() as u32,
        )?;
        DwmGetWindowAttribute(
            hwnd,
            DWMWA_SYSTEMBACKDROP_TYPE,
            (&mut backdrop as *mut u32).cast(),
            4,
        )?;
        RoInitialize(RO_INIT_MULTITHREADED)?;
    }
    require(
        GraphicsCaptureSession::IsSupported()?,
        "graphics-capture-not-supported",
    )?;
    eprintln!("stage: capture-item");
    let interop: IGraphicsCaptureItemInterop =
        factory::<GraphicsCaptureItem, IGraphicsCaptureItemInterop>()?;
    let item: GraphicsCaptureItem = unsafe { interop.CreateForWindow(hwnd)? };
    let size = item.Size()?;
    require(
        size.Width > 0
            && size.Height > 0
            && (size.Width as u64) * (size.Height as u64) * 4 <= 64 * 1024 * 1024,
        "bounded-positive-capture-size-required",
    )?;
    eprintln!("stage: hardware-device");
    let (mut device, mut context) = (None::<ID3D11Device>, None::<ID3D11DeviceContext>);
    unsafe {
        D3D11CreateDevice(
            None,
            D3D_DRIVER_TYPE_HARDWARE,
            HMODULE::default(),
            D3D11_CREATE_DEVICE_BGRA_SUPPORT,
            None,
            D3D11_SDK_VERSION,
            Some(&mut device),
            None,
            Some(&mut context),
        )?;
    }
    let device = device.ok_or("hardware-device-required")?;
    let context = context.ok_or("hardware-context-required")?;
    let dxgi: IDXGIDevice = device.cast()?;
    let winrt: IDirect3DDevice = unsafe { CreateDirect3D11DeviceFromDXGIDevice(&dxgi)?.cast()? };
    let pool = Direct3D11CaptureFramePool::CreateFreeThreaded(
        &winrt,
        DirectXPixelFormat::B8G8R8A8UIntNormalized,
        1,
        size,
    )?;
    let session = pool.CreateCaptureSession(&item)?;
    session.SetIsCursorCaptureEnabled(false)?;
    session.StartCapture()?;
    eprintln!("stage: waiting-for-frame");
    let started = Instant::now();
    let frame = loop {
        verify_process(handle.0, &exe, birth_ms)?;
        verify_hwnd(hwnd, pid)?;
        match next_frame(&pool) {
            Ok(Some(frame)) => break frame,
            Ok(None) if started.elapsed() < Duration::from_secs(5) => {
                std::thread::sleep(Duration::from_millis(10))
            }
            Ok(None) => return Err("owned-capture-frame-timeout".into()),
            Err(e) => return Err(e.into()),
        }
    };
    eprintln!("stage: frame-received");
    let content = frame.ContentSize()?;
    require(content == size, "window-resized-during-capture")?;
    let ticks = frame.SystemRelativeTime()?.Duration;
    let access: IDirect3DDxgiInterfaceAccess = frame.Surface()?.cast()?;
    let texture: ID3D11Texture2D = unsafe { access.GetInterface()? };
    let mut desc = D3D11_TEXTURE2D_DESC::default();
    unsafe {
        texture.GetDesc(&mut desc);
    }
    require(
        desc.Width >= content.Width as u32
            && desc.Height >= content.Height as u32
            && desc.SampleDesc.Count == 1
            && desc.Format == DXGI_FORMAT_B8G8R8A8_UNORM,
        "capture-texture-size-or-samples-invalid",
    )?;
    desc.Usage = D3D11_USAGE_STAGING;
    desc.BindFlags = 0;
    desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ.0 as u32;
    desc.MiscFlags = 0;
    let mut staging = None;
    unsafe {
        device.CreateTexture2D(&desc, None, Some(&mut staging))?;
    }
    let staging = staging.ok_or("staging-texture-required")?;
    unsafe {
        context.CopyResource(&staging, &texture);
    }
    let mut mapped = D3D11_MAPPED_SUBRESOURCE::default();
    unsafe {
        context.Map(&staging, 0, D3D11_MAP_READ, 0, Some(&mut mapped))?;
    }
    let row_bytes = content.Width as usize * 4;
    let mut bytes = Vec::with_capacity(row_bytes * content.Height as usize);
    let mapping_ok = !mapped.pData.is_null() && mapped.RowPitch as usize >= row_bytes;
    if mapping_ok {
        for row in 0..content.Height as usize {
            bytes.extend_from_slice(unsafe {
                std::slice::from_raw_parts(
                    (mapped.pData as *const u8).add(row * mapped.RowPitch as usize),
                    row_bytes,
                )
            });
        }
    }
    unsafe {
        context.Unmap(&staging, 0);
    }
    require(mapping_ok, "invalid-mapped-frame")?;
    drop(texture);
    drop(access);
    frame.Close()?;
    session.Close()?;
    pool.Close()?;
    verify_process(handle.0, &exe, birth_ms)?;
    verify_hwnd(hwnd, pid)?;
    let mut final_outer = RECT::default();
    unsafe {
        GetWindowRect(hwnd, &mut final_outer)?;
    }
    require(
        rect(final_outer) == rect(outer),
        "window-moved-during-capture",
    )?;
    require(
        unsafe { GetWindowLongPtrW(hwnd, GWL_STYLE) } == selected_style
            && unsafe { GetWindowLongPtrW(hwnd, GWL_EXSTYLE) } == selected_ex_style,
        "window-style-changed-during-capture",
    )?;
    let foreground_after = unsafe { GetForegroundWindow() } == hwnd;
    let dpi_after = unsafe { GetDpiForWindow(hwnd) };
    require(
        foreground_after == foreground_before && dpi_after == dpi_before,
        "window-focus-or-dpi-changed-during-capture",
    )?;
    let proof = json!({"foregroundBefore":foreground_before,"foregroundAfter":foreground_after,"ownedWindowDpi":dpi_before,"schemaVersion":1,"scope":"rf121-owned-window-wgc-frame","runId":run,"pid":pid,"creationMs":birth_ms,"hwnd":hwnd.0 as usize,"tag":tag,"captureMethod":"Windows.Graphics.Capture.CreateForWindow","selectionRule":"unique-visible-uncloaked-root-owner-caption-sysmenu-resizable-appwindow-positive-client","ownedWindowCount":inventory.len(),"visibleOwnedWindowCount":visible.len(),"selectedWindowStyle":selected_style,"selectedWindowExStyle":selected_ex_style,"frameClockScope":"Windows-QPC","frameSystemRelativeTime100ns":ticks,"width":content.Width,"height":content.Height,"pixelFormat":"BGRA8-premultiplied","bytes":bytes.len(),"windowRect":rect(outer),"clientRect":rect(client),"clientOriginScreen":[origin.x,origin.y],"dwmExtendedFrameBounds":rect(bounds),"dwmSystemBackdropType":backdrop,"heldProcessAndWindowIdentityVerifiedBeforeAndAfter":true,"pixelFile":raw_path.file_name().unwrap().to_string_lossy(),"applicationMaterialAccepted":false,"otherWindowsCaptured":0});
    save_new(&raw_path, &bytes)?;
    save_new(&json_path, &serde_json::to_vec_pretty(&proof)?)?;
    println!("{}", proof);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn actual_api_empty_pool_is_none_and_errors_remain_errors() {
        assert!(
            nullable_frame(windows::core::HRESULT(0), std::ptr::null_mut())
                .unwrap()
                .is_none()
        );
        let code = windows::core::HRESULT(0x80004003u32 as i32);
        assert_eq!(
            nullable_frame(code, std::ptr::null_mut())
                .unwrap_err()
                .code(),
            code
        );
    }
    fn main_window() -> Value {
        json!({"hwnd":1,"rootOwnerHwnd":1,"visible":true,"iconic":false,"cloaked":0,"style":349110272u64,"exStyle":262416u64,"clientRect":[0,0,1028,749]})
    }
    fn observed_auxiliary() -> Value {
        json!({"hwnd":2,"rootOwnerHwnd":2,"visible":true,"iconic":false,"cloaked":0,"style":2483027968u64,"exStyle":134742176u64,"clientRect":[0,0,0,0]})
    }
    #[test]
    fn actual_two_visible_shapes_select_only_main() {
        assert_eq!(
            select_main(&[main_window(), observed_auxiliary()]).unwrap(),
            0
        );
        assert_eq!(
            select_main(&[observed_auxiliary(), main_window()]).unwrap(),
            1
        );
    }
    #[test]
    fn missing_or_two_application_windows_are_rejected() {
        assert!(select_main(&[observed_auxiliary()]).is_err());
        assert!(select_main(&[main_window(), main_window()]).is_err());
        assert!(select_main(&[]).is_err());
    }
    #[test]
    fn unsafe_or_nonvisible_shapes_are_rejected() {
        for (key, value) in [
            ("visible", json!(false)),
            ("iconic", json!(true)),
            ("cloaked", json!(1)),
            ("cloaked", Value::Null),
            ("rootOwnerHwnd", json!(2)),
            ("hwnd", json!(0)),
            ("style", json!(2483027968u64)),
            ("exStyle", json!(134742176u64)),
            ("clientRect", json!([0, 0, 0, 0])),
            ("clientRect", json!([0, 0, 16385, 749])),
            ("style", json!("349110272")),
        ] {
            let mut v = main_window();
            v[key] = value;
            assert!(select_main(&[v]).is_err(), "{key}");
        }
    }
}
