"""Wait on this actual build handle, then execute the prepared native capture gates.

This is an in-flight local job, not a recurring task; no cache deletion or commit is automatic.
"""
from pathlib import Path
import ctypes, ctypes.wintypes as w, datetime, hashlib, json, os, subprocess, sys, time

stage = Path(__file__).parent
root = Path('D:/SoloSoul')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def save(name, value):
    with (stage / name).open('x', encoding='utf-8', newline='\n') as out:
        out.write(json.dumps(value, indent=2) + '\n')

live = load(stage / 'native-release-build.live.json')
assert live['command'] == ['npm.cmd','run','tauri','--','build','--config','src-tauri/tauri.native-perf.conf.json','--features','native-perf','--no-bundle','--ci']
save('after-build.live.json', {'pid': os.getpid(), 'at': now(), 'waitsForBuildPid': live['pid'],
     'commands': ['run-surface-captures.py', 'verify-surface-captures.mjs', 'render-surface-captures.py']})
started = time.monotonic()
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [w.DWORD,w.BOOL,w.DWORD]; kernel.OpenProcess.restype = w.HANDLE
kernel.GetProcessTimes.argtypes = [w.HANDLE,ctypes.POINTER(w.FILETIME),ctypes.POINTER(w.FILETIME),ctypes.POINTER(w.FILETIME),ctypes.POINTER(w.FILETIME)]
kernel.GetProcessTimes.restype = w.BOOL
kernel.QueryFullProcessImageNameW.argtypes = [w.HANDLE,w.DWORD,w.LPWSTR,ctypes.POINTER(w.DWORD)]
kernel.QueryFullProcessImageNameW.restype = w.BOOL
kernel.WaitForSingleObject.argtypes = [w.HANDLE,w.DWORD]; kernel.WaitForSingleObject.restype = w.DWORD
kernel.CloseHandle.argtypes = [w.HANDLE]; kernel.CloseHandle.restype = w.BOOL
handle = kernel.OpenProcess(0x00100000 | 0x1000, False, live['pid'])
wait_identity = {'pid': live['pid']}
if handle:
    try:
        creation, end, system, user = (w.FILETIME() for _ in range(4))
        assert kernel.GetProcessTimes(handle,ctypes.byref(creation),ctypes.byref(end),ctypes.byref(system),ctypes.byref(user))
        birth_ms = ((creation.dwHighDateTime << 32) | creation.dwLowDateTime) / 10000 - 11644473600000
        expected_ms = datetime.datetime.fromisoformat(live['at']).timestamp() * 1000
        assert abs(birth_ms - expected_ms) < 2000, 'Build PID was reused'
        buffer, size = ctypes.create_unicode_buffer(32768), w.DWORD(32768)
        assert kernel.QueryFullProcessImageNameW(handle,0,buffer,ctypes.byref(size))
        assert Path(buffer.value).resolve() == Path(os.environ['SystemRoot']) / 'System32/cmd.exe'
        wait_identity.update({'creationMs': birth_ms, 'exe': buffer.value, 'heldHandle': True})
        save('after-build-wait-identity.json', wait_identity)
        print('Waiting on verified current build process handle ' + str(live['pid']), flush=True)
        while True:
            status = kernel.WaitForSingleObject(handle,1000)
            if status == 0: break
            assert status == 258, 'Build wait failed'
    finally:
        kernel.CloseHandle(handle)
else:
    assert (stage / 'native-release-build.receipt.json').exists(), 'Build handle unavailable without terminal receipt'

deadline = time.monotonic() + 90
while not (stage / 'runtime-package.json').exists():
    if (stage / 'native-release-build.receipt.json').exists():
        assert load(stage / 'native-release-build.receipt.json')['exitCode'] == 0, 'Native build failed'
    assert time.monotonic() < deadline, 'Build did not finish runtime freezing'
    time.sleep(.1)
assert load(stage / 'native-release-build.receipt.json')['exitCode'] == 0
package = load(stage / 'runtime-package.json')
assert sha(Path(package['exe'])) == package['sha256']
assert sha(Path(package['helperExe'])) == package['helperSha256']
for name, digest in load(stage / 'sources-applied.json').items():
    assert sha(root / name) == digest, name
jobs = [
    ('surface-captures', [sys.executable,'-X','utf8',str(stage / 'run-surface-captures.py')]),
    ('surface-independent-validation', ['node',str(stage / 'verify-surface-captures.mjs')]),
    ('surface-render', [sys.executable,'-X','utf8',str(stage / 'render-surface-captures.py')]),
]
code = 0
for name, command in jobs:
    begin = time.monotonic()
    with (stage / (name + '.stdout.log')).open('xb') as stdout, (stage / (name + '.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen(command,cwd=root,stdout=stdout,stderr=stderr)
        save(name + '.live.json', {'pid':child.pid,'at':now(),'command':command})
        print(name + ' live PID ' + str(child.pid),flush=True)
        code = child.wait()
    save(name + '.receipt.json', {'pid':child.pid,'at':now(),'command':command,'exitCode':code,'elapsedSeconds':time.monotonic()-begin})
    print(name + ' terminal exit ' + str(code),flush=True)
    if code: break
save('after-build.receipt.json', {'at':now(),'exitCode':code,'elapsedSeconds':time.monotonic()-started,
     'performanceMetrics':None,'applicationMaterialAccepted':False,'cacheDeletionPerformed':False,'commitCreated':False})
raise SystemExit(code)
