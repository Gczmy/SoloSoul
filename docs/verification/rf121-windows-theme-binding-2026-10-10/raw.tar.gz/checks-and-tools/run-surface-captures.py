"""Three complete, isolated public-vault journeys with owned WGC/state handshakes.

This does not change system appearance or accept a full RF-121 material matrix.
All writes are exclusive; failed runs remain available for independent review.
"""
from pathlib import Path
import datetime, hashlib, json, math, os, re, subprocess, sys, threading, time, traceback, uuid

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
assert sys.argv[1:] in [[], ['--round', '2'], ['--round', '3'], ['--round', '4']], 'Only the four fixed capture rounds are allowed'
capture_stage = stage / ('ss-rf121-composed-window-current' if not sys.argv[1:] else 'ss-rf121-composed-window-current-round' + sys.argv[2])
output = capture_stage / 'actual100'
fixture = root / 'build/rf312-maintenance-20261009/fixtures/vault100'
pwsh = Path('C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as f:
        f.write(json.dumps(value, indent=2) + '\n')

def atomic_new(path, value):
    temporary = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    save(temporary, value)
    try:
        os.link(temporary, path)  # Atomic create, refuses existing target.
    finally:
        temporary.unlink()

def ordinary(path, maximum):
    stat = path.lstat()
    assert path.is_file() and not path.is_symlink() and not (stat.st_file_attributes & 0x400), path
    assert stat.st_size <= maximum, path
    return load(path)

package = load(stage / ('runtime-package-readable.json' if sys.argv[1:] == ['--round', '4'] else 'runtime-package-d-root.json' if sys.argv[1:] == ['--round', '3'] else 'runtime-package.json'))
exe, helper = Path(package['exe']), Path(package['helperExe'])
sources = load(stage / 'sources-applied.json')
fixture_hashes = {str(p.relative_to(fixture)): sha(p) for p in fixture.rglob('*') if p.is_file()}

def verify_inputs():
    assert sha(exe) == package['sha256'] and sha(helper) == package['helperSha256']
    assert sha(Path(package.get('helperSource', str(stage / 'helper/src/bin/owned-window.rs')))) == package['helperSourceSha256']
    for name, digest in sources.items():
        assert sha(root / name) == digest, name
    for item in package['resources']:
        assert sha(Path(item['copy'])) == item['sha256']
        assert sha(Path(item['source'])) == item['sha256']
    assert fixture_hashes == {str(p.relative_to(fixture)): sha(p) for p in fixture.rglob('*') if p.is_file()}

verify_inputs()
capture_stage.mkdir(exist_ok=False)
save(capture_stage / 'input-proof.json', {'at': now(), 'runtime': package,
     'sourceManifestSha256': sha(stage / 'sources-applied.json'), 'fixture': str(fixture),
     'driverSha256': sha(Path(__file__)),
     'fixtureFiles': fixture_hashes, 'diagnosticOnly': True, 'applicationMaterialAccepted': False,
     'performanceMetrics': None, 'systemAppearanceModified': False, 'samplesRequested': 3})
env = os.environ.copy()
env.update({'TEMP': str(stage), 'TMP': str(stage)})
env['PATH'] = 'C:/Program Files/Git/usr/bin;' + env.get('PATH', '')
env.pop('PDFIUM_LIBRARY_PATH', None)
command = ['node', 'scripts/native-perf-auth-attribution.mjs', '--exe', str(exe),
           '--fixture', str(fixture), '--output', str(output), '--samples', '3']
results = []
began = time.monotonic()

with (capture_stage / 'actual100.stdout.log').open('xb') as stdout, (capture_stage / 'actual100.stderr.log').open('xb') as stderr:
    process = subprocess.Popen(command, cwd=root / 'tauri', env=env, stdout=stdout, stderr=stderr)
    save(capture_stage / 'actual100.live.json', {'at': now(), 'pid': process.pid, 'command': command})
    print('Three-sample surface capture driver live PID ' + str(process.pid), flush=True)

    def wait_file(path, deadline):
        while not path.exists():
            if process.poll() is not None:
                raise RuntimeError('Journey driver exited before ' + path.name)
            if time.monotonic() > deadline:
                raise TimeoutError('Waiting for ' + path.name)
            time.sleep(.01)
        return path

    def watch():
        for index in range(1, 4):
            sample = output / ('sample-' + str(index).zfill(3))
            result = {'index': index, 'root': str(sample), 'success': False,
                      'diagnosticOnly': True, 'performanceMetrics': None}
            results.append(result)
            try:
                deadline = time.monotonic() + 450
                consumed = ordinary(wait_file(sample / 'native-perf-consumed.json', deadline), 262144)
                owned = ordinary(sample / 'native-perf-owned.json', 262144)
                bound = ordinary(wait_file(sample / 'native-perf-sdk-journey-bound.json', deadline), 262144)
                pid, run_id = consumed['pid'], owned['runId']
                assert type(pid) is int and pid > 0 and re.fullmatch('[0-9a-f]{32}', run_id)
                assert consumed['scope'] == 'windows-native-perf-consumed'
                assert bound['scope'] == 'windows-native-sdk-ui-bound'
                assert consumed['runId'] == bound['runId'] == run_id and bound['pid'] == pid
                assert Path(consumed['root']).samefile(sample), 'Consumed root is a different filesystem directory'
                assert Path(bound['root']).samefile(sample), 'Bound root is a different filesystem directory'
                request = {'schemaVersion': 1, 'scope': 'windows-native-surface-request',
                           'runId': run_id, 'pid': pid, 'browserPid': bound['browserPid'], 'token': uuid.uuid4().hex}
                atomic_new(sample / 'native-perf-surface-request.json', request)
                # CIM reads only this consumed, bound application's identity, with no visible console.
                query = f"$taskProcess=Get-CimInstance Win32_Process -Filter 'ProcessId = {pid}' -Property ProcessId,CreationDate,ExecutablePath; if($null -eq $taskProcess -or $null -eq $taskProcess.CreationDate -or [string]::IsNullOrEmpty($taskProcess.ExecutablePath)){{throw 'Incomplete owned process identity'}}; [ordered]@{{pid=[int]$taskProcess.ProcessId;creationMs=([DateTimeOffset]$taskProcess.CreationDate.ToUniversalTime()).ToUnixTimeMilliseconds();exe=[string]$taskProcess.ExecutablePath}} | ConvertTo-Json -Compress"
                identity = subprocess.run([str(pwsh), '-NoLogo', '-NoProfile', '-Command', query],
                                          capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW, timeout=25)
                for name, data in [('stdout', identity.stdout), ('stderr', identity.stderr)]:
                    with (sample / ('surface-identity.' + name + '.log')).open('xb') as log: log.write(data)
                assert identity.returncode == 0, 'Owned identity query failed'
                owner = json.loads(identity.stdout.decode('utf-8-sig'))
                assert owner['pid'] == pid and Path(owner['exe']).samefile(exe), 'Owned process image differs from frozen GUI'
                assert type(owner['creationMs']) is int and owner['creationMs'] > 0
                save(sample / 'surface-identity.json', owner)
                before_path = wait_file(sample / 'native-perf-surface-before.json', deadline)
                before = ordinary(before_path, 262144)
                assert before['request'] == request and before['scope'] == 'windows-native-surface-before'
                state = before['state']
                assert state['theme'] in ['light', 'dark'] and state['platform'] == 'windows'
                tag = state['theme'] + '-visible'
                args = [str(helper), str(sample), str(pid), str(owner['creationMs']), str(exe), tag]
                capture_began = time.monotonic()
                captured = subprocess.run(args, cwd=stage, env=env, capture_output=True,
                                          creationflags=subprocess.CREATE_NO_WINDOW, timeout=25)
                for name, data in [('stdout', captured.stdout), ('stderr', captured.stderr)]:
                    with (sample / ('surface-capture.' + name + '.log')).open('xb') as log: log.write(data)
                receipt = {'at': now(), 'command': args, 'exitCode': captured.returncode,
                           'elapsedSeconds': time.monotonic() - capture_began, 'tagFromActualDomTheme': True}
                save(sample / 'surface-capture.receipt.json', receipt)
                assert captured.returncode == 0, captured.stderr.decode('utf-8', errors='replace')
                proof = ordinary(sample / ('rf121-wgc-' + tag + '.json'), 262144)
                assert proof == json.loads(captured.stdout.decode('utf-8-sig'))
                assert proof['scope'] == 'rf121-owned-window-wgc-frame'
                assert proof['schemaVersion'] == package.get('helperMetadataVersion', 1)
                if package.get('helperMetadataVersion') == 2:
                    assert proof['nativeAppearanceVerified'] is False and proof['dwmAppearanceReadback'] == 'no-documented-getters'
                    assert all(proof[k] is None for k in ['dwmDarkMode', 'dwmCaptionColor', 'dwmSystemBackdropType'])
                assert proof['runId'] == run_id and proof['pid'] == pid and proof['creationMs'] == owner['creationMs']
                assert proof['otherWindowsCaptured'] == 0 and proof['applicationMaterialAccepted'] is False
                pixels = sample / ('rf121-wgc-' + tag + '.bgra')
                assert pixels.stat().st_size == proof['bytes'] == proof['width'] * proof['height'] * 4
                ack = dict(request, scope='windows-native-surface-done', beforeSha256=sha(before_path), pixelSha256=sha(pixels))
                atomic_new(sample / 'native-perf-surface-done.json', ack)
                after = ordinary(wait_file(sample / 'native-perf-surface-after.json', deadline), 262144)
                assert after['scope'] == 'windows-native-surface-after' and after['request'] == request
                assert after['binding'] == before['binding'] == bound['binding']
                assert after['beforeSha256'] == ack['beforeSha256'] and after['pixelSha256'] == ack['pixelSha256']
                assert after['stable'] is True and after['applicationMaterialAccepted'] is False
                assert after['performanceMetrics'] is None
                a, b = dict(before['state']), dict(after['state'])
                ta, tb = a.pop('atMs'), b.pop('atMs')
                assert all(type(v) in [int, float] and math.isfinite(v) for v in [ta, tb]) and tb >= ta
                assert a == b and a['timeOriginMs'] == bound['timeOriginMs']
                result.update({'success': True, 'runId': run_id, 'pid': pid, 'theme': state['theme'],
                               'beforeSha256': ack['beforeSha256'], 'pixelSha256': ack['pixelSha256'],
                               'nativeDwmThemeMatchesDom': None if package.get('helperMetadataVersion') == 2 else proof['dwmDarkMode'] == (state['theme'] == 'dark'),
                               'nativeAppearancePropertiesVerified': package.get('helperMetadataVersion') != 2,
                               'foreground': proof['foregroundBefore'], 'ownedWindowDpi': proof['ownedWindowDpi']})
                print('Sample ' + str(index) + ' captured with stable actual ' + state['theme'] + ' theme', flush=True)
            except Exception as error:
                result.update({'errorCategory': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc()})
                # Do not terminate foreign processes or restart an in-flight original journey.
                print('Sample ' + str(index) + ' capture failed: ' + str(error), flush=True)
            finally:
                save(capture_stage / ('surface-sample-' + str(index).zfill(3) + '.json'), result)

    watcher = threading.Thread(target=watch)
    watcher.start()
    code = process.wait()
    watcher.join()

verify_inputs()
save(capture_stage / 'actual100.receipt.json', {'at': now(), 'command': command, 'pid': process.pid,
     'exitCode': code, 'elapsedSeconds': time.monotonic() - began, 'sourceUnchanged': True,
     'resourcesUnchanged': True, 'originalFixtureUnchanged': True, 'pdfiumOverrideInherited': False})
accepted = code == 0 and len(results) == 3 and all(item['success'] for item in results)
save(capture_stage / 'capture-results.json', {'schemaVersion': 1, 'scope': 'rf121-three-owned-surface-bindings',
     'success': accepted, 'samples': results, 'diagnosticOnly': True,
     'applicationMaterialAccepted': False, 'performanceMetrics': None})
print('Journey exit ' + str(code) + '; all three state/capture bindings accepted: ' + str(accepted), flush=True)
raise SystemExit(0 if accepted else 1)
