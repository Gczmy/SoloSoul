from pathlib import Path
import datetime,json,os,subprocess,time
root=Path('D:/SoloSoul');stage=Path(__file__).parent;helper=stage/'helper-d-root'
cache=root/'build/rf312-maintenance-20261009'
env=os.environ.copy();env.update({'TEMP':str(cache/'tmp'),'TMP':str(cache/'tmp'),
    'CARGO_HOME':str(cache/'cargo-home'),'CARGO_TARGET_DIR':str(stage/'helper-target-d-root'),'CARGO_BUILD_JOBS':'1'})
env.pop('PDFIUM_LIBRARY_PATH',None)
jobs=[('d-root-helper-format-apply',['cargo','fmt','--all']),
      ('d-root-helper-format-check',['cargo','fmt','--all','--check']),
      ('d-root-helper-tests',['cargo','test','--locked','--offline','--bin','rf121-wgc-owned-window']),
      ('d-root-helper-clippy',['cargo','clippy','--locked','--offline','--all-targets','--','-D','warnings']),
      ('d-root-helper-build',['cargo','build','--locked','--offline','--bin','rf121-wgc-owned-window'])]
for name,command in jobs:
    assert not (stage/(name+'.receipt.json')).exists()
    began=time.monotonic()
    with (stage/(name+'.stdout.log')).open('xb') as out,(stage/(name+'.stderr.log')).open('xb') as err:
        process=subprocess.Popen(command,cwd=helper,env=env,stdout=out,stderr=err)
        with (stage/(name+'.live.json')).open('x',encoding='utf-8') as record:
            record.write(json.dumps({'pid':process.pid,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command},indent=2)+'\n')
        print(name+' live PID '+str(process.pid),flush=True);code=process.wait()
    with (stage/(name+'.receipt.json')).open('x',encoding='utf-8') as record:
        record.write(json.dumps({'pid':process.pid,'exitCode':code,'command':command,'elapsedSeconds':time.monotonic()-began},indent=2)+'\n')
    print(name+' terminal exit '+str(code),flush=True)
    if code:raise SystemExit(code)
print('Fixed-D helper format, six tests, strict Clippy and build passed',flush=True)
