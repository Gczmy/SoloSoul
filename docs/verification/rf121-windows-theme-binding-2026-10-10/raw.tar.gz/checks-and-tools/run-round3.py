from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
root=Path('D:/SoloSoul');stage=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,value):
    with (stage/name).open('x',encoding='utf-8',newline='\n') as out:out.write(json.dumps(value,indent=2)+'\n')
assert load(stage/'round2.receipt.json')['exitCode']==1
second=stage/'ss-rf121-composed-window-current-round2'
journey=load(second/'actual100/native-perf-sdk-journey-results.json')
assert len(journey['samples'])==3 and not journey['success']
for sample in journey['samples']:
    assert sample['cleanupIntegrity']['complete']
    assert sample['nativeProof']['reason']=='surface-capture-timeout'
    assert len(sample['nativeProof']['phases'])==6 and all(p['success'] for p in sample['nativeProof']['phases'])
    assert (Path(sample['root'])/'native-perf-surface-before.json').exists()
    assert not list(Path(sample['root']).glob('rf121-wgc-*.bgra'))
for name in ['d-root-helper-format-check','d-root-helper-tests','d-root-helper-clippy','d-root-helper-build']:
    assert load(stage/(name+'.receipt.json'))['exitCode']==0
assert 'test result: ok. 6 passed; 0 failed; 0 ignored;' in (stage/'d-root-helper-tests.stdout.log').read_text(encoding='utf-8')
old=load(stage/'runtime-package.json')
assert sha(Path(old['exe']))==old['sha256'] and sha(Path(old['helperExe']))==old['helperSha256']
for name,digest in load(stage/'sources-applied.json').items():assert sha(root/name)==digest
package=dict(old)
package['helperExe']=str(stage/'helper-target-d-root/debug/rf121-wgc-owned-window.exe')
package['helperSource']=str(stage/'helper-d-root/src/bin/owned-window.rs')
package['helperSha256']=sha(Path(package['helperExe']))
package['helperSourceSha256']=sha(Path(package['helperSource']))
package['fixedStageRoot']=str(stage)
assert package['helperSha256']!=old['helperSha256']
save('runtime-package-d-root.json',package)
save('second-round-rejection.json',{'scope':'rf121-obsolete-c-root-capture-helper-rejection',
     'allSixJourneyPhasesPassed':True,'beforeSnapshotsPublished':3,'captureBindingsAccepted':False,
     'helperRootGuardRejectedDPaths':3,'originalHelperFixedStage':'C:/Users/40299571/AppData/Local/Temp',
     'newHelperFixedStage':str(stage),'originalHelperAndBinaryPreserved':True,
     'newHelperGuardTestsPassed':6,'frozenGuiChanged':False,'productionSourcesChanged':False})
jobs=[('round3-surface-captures',[sys.executable,'-X','utf8',str(stage/'run-surface-captures.py'),'--round','3']),
      ('round3-surface-independent-validation',['node',str(stage/'verify-surface-captures.mjs'),'--round','3']),
      ('round3-surface-render',[sys.executable,'-X','utf8',str(stage/'render-surface-captures.py'),'--round','3'])]
started=time.monotonic();code=0
for name,command in jobs:
    began=time.monotonic()
    with (stage/(name+'.stdout.log')).open('xb') as out,(stage/(name+'.stderr.log')).open('xb') as err:
        process=subprocess.Popen(command,cwd=root,stdout=out,stderr=err)
        save(name+'.live.json',{'pid':process.pid,'at':now(),'command':command})
        print(name+' live PID '+str(process.pid),flush=True);code=process.wait()
    save(name+'.receipt.json',{'pid':process.pid,'at':now(),'command':command,'exitCode':code,'elapsedSeconds':time.monotonic()-began})
    print(name+' terminal exit '+str(code),flush=True)
    if code:break
save('round3.receipt.json',{'at':now(),'exitCode':code,'elapsedSeconds':time.monotonic()-started,
     'bothFailedCaptureRoundsPreserved':True,'applicationMaterialAccepted':False,'performanceMetrics':None})
raise SystemExit(code)
