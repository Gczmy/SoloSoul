from pathlib import Path
stage = Path(__file__).parent
text = (stage.parent / 'rf312-home-memory-20261010/cleanup-owned.ps1').read_text(encoding='utf-8')
changes = [
    (r"'D:\SoloSoul\build\rf312-home-memory-20261010'", r"'D:\SoloSoul\build\rf121-theme-binding-20261010'"),
    ("'validation.json'", "'failed-rounds-validation.json'"),
    ("if (-not $validation.accepted -or $validation.groups.Count -ne 2) { throw 'Complete accepted groups required before cache cleanup' }", "if ($validation.accepted -or -not $validation.evidenceIntegrityVerified -or -not $validation.cacheCleanupEligible -or $validation.rounds.Count -ne 4) { throw 'Four terminal failure groups with verified integrity required' }"),
    ('validation.groups.samples.recordedIdentities', 'validation.rounds.samples.recordedIdentities'),
    ('identities.Count -lt 20', 'identities.Count -lt 60'),
    (r"'D:\SoloSoul\build\rf1104-update-preferences-20261010\bin\solo_soul.exe'", r"'D:\SoloSoul\build\rf121-theme-binding-20261010\ss-rf121-runtime\bin\solo_soul.exe'"),
    ('foreach ($group in $validation.groups)', 'foreach ($group in $validation.rounds)'),
    ("if (-not $group.complete -or $group.samples.Count -ne 5) { throw 'Whole group required' }", "if ($group.accepted -or $group.samples.Count -ne 3 -or $group.round -notin @(1,2,3,4)) { throw 'Whole terminal failure group required' }\n    $suffix = if ($group.round -eq 1) { '' } else { '-round' + $group.round }\n    $expectedRoundRoot = Join-Path $stageRoot ('ss-rf121-composed-window-current' + $suffix)\n    if ((NormalPath $group.root) -ne $expectedRoundRoot) { throw 'Fixed round root mismatch' }"),
    ("$sampleRoot = Join-Path (Join-Path $stageRoot ('samples' + $group.objects)) ('sample-' + $sample.index.ToString('000'))", "$sampleRoot = Join-Path (Join-Path $expectedRoundRoot 'actual100') ('sample-' + $sample.index.ToString('000'))\n        if ((NormalPath $sample.root) -ne $sampleRoot -or -not $sample.cleanupIntegrity.complete) { throw 'Sample path or exit integrity mismatch' }\n        PlainAncestors $sampleRoot"),
    ("'application-logs\\' + $group.objects + '\\sample-'", "'application-logs\\round-' + $group.round + '\\sample-'"),
    ('targets.Count -ne 80 -or @($targets | Sort-Object -Unique).Count -ne 80', 'targets.Count -ne 96 -or @($targets | Sort-Object -Unique).Count -ne 96'),
    ('Exact eighty owned cache paths required', 'Exact ninety-six owned candidate cache paths required'),
    ("task='RF-312'", "task='RF-121';materialAcceptance=$false;evidenceIntegrityVerified=$true"),
]
for before,after in changes:
    assert text.count(before)==1,(before,text.count(before))
    text=text.replace(before,after)
marker='$targets = [Collections.Generic.List[string]]::new()'
guard='''function PlainAncestors([string]$value) {
    $cursor = NormalPath $value
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Root ancestor is a reparse point: $cursor" }
            if ((NormalPath (Resolve-Path -LiteralPath $cursor).ProviderPath) -ne $cursor) { throw 'Resolved ancestor differs' }
        }
        $parent = Split-Path $cursor -Parent
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }
}
PlainAncestors $stageRoot
'''
assert text.count(marker)==1
text=text.replace(marker,guard+marker)
marker="if ($sameExe.Count) { throw 'Frozen test application is still live; defer cache deletion' }"
helperguard='''
$helperPaths = @('helper-target','helper-target-d-root','helper-target-readable') | ForEach-Object { Join-Path $stageRoot ($_ + '\\debug\\rf121-wgc-owned-window.exe') }
$liveHelpers = @(Get-CimInstance Win32_Process -Filter "Name = 'rf121-wgc-owned-window.exe'" | Where-Object { $_.ExecutablePath -in $helperPaths })
if ($liveHelpers.Count) { throw 'Owned capture helper is still live' }
'''
assert text.count(marker)==1
text=text.replace(marker,marker+helperguard)
marker='$targets.Add($expectedPath)'
text=text.replace(marker,'PlainAncestors $expectedPath\n            '+marker)
marker='$preserved.Add([ordered]@{path=$file.FullName;sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()})'
assert text.count(marker)==1
text=text.replace(marker,"if ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Root proof is a link' }\n            "+marker)
with (stage/'cleanup-failed-owned.ps1').open('x',encoding='utf-8',newline='\n') as out: out.write(text)
print('Prepared four-round cleanup with exact 96 candidate paths and independent exit checks; not executed')
