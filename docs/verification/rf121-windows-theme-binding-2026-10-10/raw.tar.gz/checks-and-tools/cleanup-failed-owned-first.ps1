$ErrorActionPreference = 'Stop'
$stageRoot = 'D:\SoloSoul\build\rf121-theme-binding-20261010'
$validation = Get-Content -LiteralPath (Join-Path $stageRoot 'failed-rounds-validation.json') -Raw | ConvertFrom-Json
if ($validation.accepted -or -not $validation.evidenceIntegrityVerified -or -not $validation.cacheCleanupEligible -or $validation.rounds.Count -ne 4) { throw 'Four terminal failure groups with verified integrity required' }
$receiptPath = Join-Path $stageRoot 'cache-cleanup.json'
if (Test-Path -LiteralPath $receiptPath) { throw 'Cleanup evidence already exists' }
function NormalPath([string]$value) {
    if ($value.StartsWith('\\?\')) { $value = $value.Substring(4) }
    return [IO.Path]::GetFullPath($value).TrimEnd('\')
}
function RequireBelow([string]$child, [string]$parent) {
    if (-not (NormalPath $child).StartsWith((NormalPath $parent) + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Path outside intended target: $child" }
}
function RegularTreeFiles([string]$directory) {
    $entry = Get-Item -LiteralPath $directory -Force
    if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Evidence tree is a link: $directory" }
    foreach ($item in Get-ChildItem -LiteralPath $directory -Force) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Evidence link rejected: $($item.FullName)" }
        if ($item.PSIsContainer) { RegularTreeFiles $item.FullName } else { $item }
    }
}
function CacheLinks([string]$directory) {
    foreach ($item in Get-ChildItem -LiteralPath $directory -Force) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { $item }
        elseif ($item.PSIsContainer) { CacheLinks $item.FullName }
    }
}
function PlainAncestors([string]$value) {
    $cursor = NormalPath $value
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Root ancestor is a reparse point: $cursor" }
            if ((NormalPath (Resolve-Path -LiteralPath $cursor).ProviderPath) -ne $cursor) { throw 'Resolved ancestor differs' }
        }
        $parent = Split-Path $cursor -Parent
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }
}
PlainAncestors $stageRoot
$targets = [Collections.Generic.List[string]]::new()
$preserved = [Collections.Generic.List[object]]::new()
$logCopies = [Collections.Generic.List[object]]::new()
$identities = @($validation.rounds.samples.recordedIdentities | Sort-Object pid,creationMs -Unique)
if ($identities.Count -lt 60) { throw 'Insufficient process identity evidence' }
$pidFilter = ($identities | Select-Object -ExpandProperty pid -Unique | ForEach-Object { 'ProcessId = ' + [int]$_ }) -join ' OR '
$current = @(Get-CimInstance Win32_Process -Filter $pidFilter | Select-Object ProcessId,Name,CreationDate)
foreach ($identity in $identities) {
    foreach ($processRow in $current | Where-Object ProcessId -EQ $identity.pid) {
        $birthMs = ([DateTimeOffset]$processRow.CreationDate).ToUnixTimeMilliseconds()
        if ([Math]::Abs($birthMs - $identity.creationMs) -lt 1) { throw "Owned identity is still live: $($identity.pid)" }
    }
}
$sameExe = @(Get-CimInstance Win32_Process -Filter "Name = 'solo_soul.exe'" | Where-Object ExecutablePath -EQ 'D:\SoloSoul\build\rf121-theme-binding-20261010\ss-rf121-runtime\bin\solo_soul.exe')
if ($sameExe.Count) { throw 'Frozen test application is still live; defer cache deletion' }
$helperPaths = @('helper-target','helper-target-d-root','helper-target-readable') | ForEach-Object { Join-Path $stageRoot ($_ + '\debug\rf121-wgc-owned-window.exe') }
$liveHelpers = @(Get-CimInstance Win32_Process -Filter "Name = 'rf121-wgc-owned-window.exe'" | Where-Object { $_.ExecutablePath -in $helperPaths })
if ($liveHelpers.Count) { throw 'Owned capture helper is still live' }

$packageBase = 'C:\Users\40299571\AppData\Local\Packages\OpenAI.Codex_2p2nqsd0c76g0\LocalCache'
foreach ($group in $validation.rounds) {
    if ($group.accepted -or $group.samples.Count -ne 3 -or $group.round -notin @(1,2,3,4)) { throw 'Whole terminal failure group required' }
    $suffix = if ($group.round -eq 1) { '' } else { '-round' + $group.round }
    $expectedRoundRoot = Join-Path $stageRoot ('ss-rf121-composed-window-current' + $suffix)
    if ((NormalPath $group.root) -ne $expectedRoundRoot) { throw 'Fixed round root mismatch' }
    foreach ($sample in $group.samples) {
        $sampleRoot = Join-Path (Join-Path $expectedRoundRoot 'actual100') ('sample-' + $sample.index.ToString('000'))
        if ((NormalPath $sample.root) -ne $sampleRoot -or -not $sample.cleanupIntegrity.complete) { throw 'Sample path or exit integrity mismatch' }
        PlainAncestors $sampleRoot
        RequireBelow $sampleRoot $stageRoot
        $owned = Get-Content -LiteralPath (Join-Path $sampleRoot 'native-perf-owned.json') -Raw | ConvertFrom-Json
        if ($owned.scope -ne 'windows-native-perf-owned' -or $owned.runId -ne $sample.runId -or $owned.runId -notmatch '^[0-9a-f]{32}$' -or (NormalPath $owned.root) -ne $sampleRoot) { throw 'Owned marker mismatch' }
        $identifier = 'com.solosoul.rf312perf.' + $owned.runId
        if ($owned.identifier -ne $identifier) { throw 'Identifier mismatch' }
        foreach ($cacheName in @('app-data','profile','webview','temp','models','plugins')) {
            $cachePath = Join-Path $sampleRoot $cacheName
            RequireBelow $cachePath $sampleRoot
            $targets.Add($cachePath)
        }
        foreach ($nativeDir in @('local','roaming')) {
            $parentName = if ($nativeDir -eq 'local') { 'Local' } else { 'Roaming' }
            $expectedPath = Join-Path (Join-Path $packageBase $parentName) $identifier
            if ((NormalPath $owned.$nativeDir) -ne $expectedPath) { throw 'Known-folder owned cache mismatch' }
            RequireBelow $expectedPath (Join-Path $packageBase $parentName)
            PlainAncestors $expectedPath
            $targets.Add($expectedPath)
        }
        if ((NormalPath $owned.vault) -ne (Join-Path $sampleRoot 'vault')) { throw 'Vault path mismatch' }
        foreach ($file in @(RegularTreeFiles (Join-Path $sampleRoot 'vault')) + @(Get-ChildItem -LiteralPath $sampleRoot -File -Force)) {
            if ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Root proof is a link' }
            $preserved.Add([ordered]@{path=$file.FullName;sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()})
        }
        $logs = Join-Path $sampleRoot 'app-data\logs'
        if (Test-Path -LiteralPath $logs) {
            foreach ($file in RegularTreeFiles $logs) {
                $destination = Join-Path $stageRoot ('application-logs\round-' + $group.round + '\sample-' + $sample.index.ToString('000') + '\' + [IO.Path]::GetRelativePath($logs,$file.FullName))
                RequireBelow $destination $stageRoot
                if (Test-Path -LiteralPath $destination) { throw 'Log copy already exists' }
                New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force | Out-Null
                Copy-Item -LiteralPath $file.FullName -Destination $destination
                $digest = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
                if ((Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash -ne $digest) { throw 'Log copy bytes differ' }
                $logCopies.Add([ordered]@{source=$file.FullName;copy=$destination;sha256=$digest.ToLowerInvariant()})
            }
        }
    }
}
if ($targets.Count -ne 96 -or @($targets | Sort-Object -Unique).Count -ne 96) { throw 'Exact ninety-six owned candidate cache paths required' }
$links = [Collections.Generic.List[object]]::new()
foreach ($target in $targets) {
    if (Test-Path -LiteralPath $target) {
        $entry = Get-Item -LiteralPath $target -Force
        if ($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Cache root is a link: $target" }
        foreach ($link in CacheLinks $target) {
            RequireBelow $link.FullName $target
            $links.Add([ordered]@{path=$link.FullName;target=$link.LinkTarget;container=$target})
        }
    }
}
$preflight = [ordered]@{at=[DateTime]::UtcNow.ToString('o');identitiesChecked=$identities.Count;matchingOwnedIdentitiesLive=0;targets=$targets;links=$links;preserved=$preserved;logs=$logCopies}
$preflight | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $stageRoot 'cache-cleanup-preflight.json') -Encoding utf8
foreach ($link in $links) {
    RequireBelow $link.path $link.container
    Remove-Item -LiteralPath $link.path -Force
    if (Get-Item -LiteralPath $link.path -Force -ErrorAction SilentlyContinue) { throw 'Link was not removed' }
}
$removed = [Collections.Generic.List[string]]::new()
foreach ($target in $targets) {
    # All absolute targets were checked against the exact sample root or explicit Known Folder namespace above.
    if (Test-Path -LiteralPath $target) {
        if (@(CacheLinks $target).Count) { throw 'New reparse point appeared' }
        Remove-Item -LiteralPath $target -Recurse -Force
        if (Test-Path -LiteralPath $target) { throw "Cache remains: $target" }
        $removed.Add($target)
    }
}
foreach ($file in $preserved) {
    if ((Get-FileHash -LiteralPath $file.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $file.sha256) { throw 'Preserved vault/proof bytes changed' }
}
$result = [ordered]@{task='RF-121';materialAcceptance=$false;evidenceIntegrityVerified=$true;at=[DateTime]::UtcNow.ToString('o');identitiesChecked=$identities.Count;matchingOwnedIdentitiesLive=0;processesTerminatedByThisTool=0;removedCachePaths=$removed;linksUnlinked=$links;preservedVaultAndRootFiles=$preserved;applicationLogs=$logCopies;preservedBytesVerified=$true}
$result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $receiptPath -Encoding utf8
Write-Output ('Verified identities: ' + $identities.Count + '; removed caches: ' + $removed.Count + '; unlinked reparse points: ' + $links.Count + '; preserved files: ' + $preserved.Count)
