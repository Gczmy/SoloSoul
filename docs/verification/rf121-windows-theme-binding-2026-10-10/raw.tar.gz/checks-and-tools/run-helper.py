from pathlib import Path
import datetime,json,os,subprocess,time,sys
root=Path('D:/SoloSoul');stage=Path(__file__).parent;helper=stage/'helper'
cache=root/'build/rf312-maintenance-20261009'
env=os.environ.copy();env.update({'TEMP':str(cache/'tmp'),'TMP':str(cache/'tmp'),
    'CARGO_HOME':str(cache/'cargo-home'),'CARGO_TARGET_DIR':str(stage/'helper-target'),
    'CARGO_BUILD_JOBS':'1'})
env.pop('PDFIUM_LIBRARY_PATH',None)
jobs=[('helper-format-apply',['cargo','fmt','--all']),
    ('helper-format-check',['cargo','fmt','--all','--check']),
    ('helper-tests',['cargo','test','--locked','--offline','--bin','rf121-wgc-owned-window']),
    ('helper-clippy',['cargo','clippy','--locked','--offline','--all-targets','--','-D','warnings']),
    ('helper-build',['cargo','build','--locked','--offline','--bin','rf121-wgc-owned-window'])]
assert sys.argv[1:] in ([], ['appearance'])
suffix = '-appearance' if sys.argv[1:] else ''
for name,command in jobs:
    name += suffix
    assert not (stage/(name+'.receipt.json')).exists()
    start=time.monotonic()
    with (stage/(name+'.stdout.log')).open('xb') as out,(stage/(name+'.stderr.log')).open('xb') as err:
        process=subprocess.Popen(command,cwd=helper,env=env,stdout=out,stderr=err)
        (stage/(name+'.live.json')).write_text(json.dumps({'pid':process.pid,'command':command,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n',encoding='utf-8')
        print(name+' live PID '+str(process.pid),flush=True)
        code=process.wait()
    (stage/(name+'.receipt.json')).write_text(json.dumps({'exitCode':code,'command':command,'elapsedSeconds':time.monotonic()-start},indent=2)+'\n',encoding='utf-8',newline='\n')
    print(name+' terminal exit '+str(code),flush=True)
    if code:raise SystemExit(code)
print('Owned helper format, tests, strict Clippy and build passed',flush=True)
