import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile, lstat, readdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {checkBound,checkJourney} from '../../tauri/scripts/native-perf-sdk-journey.mjs';
import {describeAuthAttribution} from '../../tauri/scripts/native-perf-auth-contract.mjs';
import {checkMaintenanceAdmission} from '../../tauri/scripts/native-perf-maintenance-contract.mjs';
const stage=path.dirname(fileURLToPath(import.meta.url)), root=path.resolve(stage,'../..');
assert.equal(process.argv.length,2);
const bytes=async p=>{const s=await lstat(p);assert(s.isFile()&&!s.isSymbolicLink());return readFile(p);};
const load=async p=>JSON.parse((await bytes(p)).toString('utf8').replace(/^\uFEFF/,''));
const hash=async p=>createHash('sha256').update(await bytes(p)).digest('hex');
const normalize=p=>path.resolve(p.replace(/^\\\\\?\\/, '')).toLowerCase();
const exact=(v,keys)=>assert.deepEqual(Object.keys(v).sort(),keys.slice().sort());
const num=(v,a,b)=>assert(Number.isFinite(v)&&v>=a&&v<=b);
const color=v=>{assert(Array.isArray(v)&&v.length===4);v.slice(0,3).forEach(x=>num(x,0,255));num(v[3],0,1);};
const sources=await load(path.join(stage,'sources-applied.json'));
assert.equal(Object.keys(sources).length,1830);
for(const [n,h] of Object.entries(sources))assert.equal(await hash(path.join(root,n)),h,n);
const checks=await load(path.join(stage,'checks-accepted.json'));
assert.equal(await hash(path.join(stage,'sources-applied.json')),checks.sourceManifestSha256);
for(const [name,receipt] of Object.entries(checks.checks)){
  const {testTotals,...rawReceipt}=receipt;
  assert.deepEqual(await load(path.join(stage,name+'.receipt.json')),rawReceipt);
  assert.equal(receipt.exitCode,0);assert.equal(receipt.sourceUnchanged,true);
  if(testTotals){
    const log=(await bytes(path.join(stage,name+'.stdout.log'))).toString('utf8');
    const matches=[...log.matchAll(/test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored/g)];
    assert.equal(matches.length,1);
    assert.deepEqual({passed:+matches[0][1],failed:+matches[0][2],ignored:+matches[0][3]},testTotals);
  }
}
const phases=['startup','password-unlock','workspace','search-needle','application-lock','password-reunlock'];
const rounds=[], runIds=new Set();
for(let round=1;round<=4;round++){
  const dir=path.join(stage,'ss-rf121-composed-window-current'+(round===1?'':'-round'+round));
  const output=path.join(dir,'actual100'), input=await load(path.join(dir,'input-proof.json'));
  const pkg=input.runtime;
  assert.equal(await hash(pkg.exe),pkg.sha256);assert.equal(await hash(pkg.helperExe),pkg.helperSha256);
  assert.equal(await hash(pkg.helperSource??path.join(stage,'helper/src/bin/owned-window.rs')),pkg.helperSourceSha256);
  assert.equal(input.sourceManifestSha256,checks.sourceManifestSha256);
  assert.equal(input.systemAppearanceModified,false);assert.equal(input.performanceMetrics,null);
  for(const resource of pkg.resources){assert.equal(await hash(resource.source),resource.sha256);assert.equal(await hash(resource.copy),resource.sha256);}
  assert.equal(pkg.resources.length,94);
  for(const [n,h] of Object.entries(input.fixtureFiles))assert.equal(await hash(path.join(input.fixture,n)),h);
  if(round>1)assert.equal(await hash(path.join(stage,round===4?'run-surface-captures.py':`round${round}-run-surface-captures.py`)),input.driverSha256);
  const receipt=await load(path.join(dir,'actual100.receipt.json'));
  assert.equal(receipt.exitCode,1);assert.equal(receipt.sourceUnchanged,true);
  assert.equal(receipt.resourcesUnchanged,true);assert.equal(receipt.originalFixtureUnchanged,true);
  assert.equal(receipt.pdfiumOverrideInherited,false);
  const journey=await load(path.join(output,'native-perf-sdk-journey-results.json'));
  assert.equal(journey.exeSha256,pkg.sha256);assert.equal(journey.samplesRequested,3);
  assert.equal(journey.interrupted,false);assert.equal(journey.sourceUnchanged,true);
  assert.equal(journey.memoryIntervalMs,null);assert.equal(journey.success,false);
  assert.deepEqual(journey.samples.map(a=>a.index),[1,2,3]);
  const samples=[];
  for(const a of journey.samples){
    const sampleRoot=path.join(output,`sample-${String(a.index).padStart(3,'0')}`);
    assert.equal(normalize(a.root),normalize(sampleRoot));assert.equal(a.cleanupIntegrity.complete,true);
    assert.deepEqual(await load(path.join(output,`sample-${String(a.index).padStart(3,'0')}.json`)),a);
    const owned=await load(path.join(sampleRoot,'native-perf-owned.json'));
    const bound=await load(path.join(sampleRoot,'native-perf-sdk-journey-bound.json'));
    assert.deepEqual(owned,a.owned);assert.deepEqual(bound,a.bound);checkBound(bound,owned,a.processId,bound.port);
    assert(!runIds.has(owned.runId));runIds.add(owned.runId);
    const native=await load(path.join(sampleRoot,'native-perf-sdk-journey.json'));
    assert.deepEqual(native,a.nativeProof);assert.equal(native.schemaVersion,1);
    assert.equal(native.scope,'windows-native-sdk-ui-journey');assert.equal(native.runId,owned.runId);
    assert.equal(native.pid,bound.pid);assert.equal(native.browserPid,bound.browserPid);
    assert.equal(native.port,bound.port);assert.deepEqual(native.binding,bound.binding);
    assert.equal(native.timeOriginMs,bound.timeOriginMs);assert.equal(native.inputMethod,'SDK-CDP-Input');
    assert.equal(native.objectCount,100);num(native.elapsedMs,0,310000);assert(native.calls.length<=128);
    const auth=await load(path.join(sampleRoot,'native-perf-auth-attribution.json'));
    const attribution=describeAuthAttribution(auth,owned,bound);
    const maintenance=checkMaintenanceAdmission(await load(path.join(sampleRoot,'native-perf-maintenance-admission.json')),auth,owned,bound);
    const expectedSuccess=round===1&&a.index!==1;
    assert.equal(a.success,expectedSuccess);assert.equal(native.success,expectedSuccess);
    assert.deepEqual(native.phases.map(p=>p.name),phases.slice(0,round===1&&a.index===1?5:6));
    assert(native.phases.every(p=>p.success&&p.inputTrust.untrusted===0));
    if(expectedSuccess)checkJourney(native,owned,bound,journey.fixture,false);
    else {assert.equal(native.reason,round===1?'probe-timeout':'surface-capture-timeout');assert.equal(native.failedStep,'home');}
    assert.equal(attribution.frontend.flows.length,2);
    if(round===1&&a.index===1){
      assert.deepEqual(attribution.frontend.flows.map(f=>f.outcome),['finished','failed']);
      assert.equal(maintenance.failures.length,1);assert.equal(maintenance.failures[0].errorClass,'operations-active');
      assert(maintenance.failures[0].witnesses.some(w=>w.kind==='update-source-preferences'));
    }else{assert(attribution.frontend.flows.every(f=>f.outcome==='finished'));assert.equal(maintenance.failures.length,0);}
    const names=await readdir(sampleRoot);
    assert(!names.some(n=>/\.(bgra|png)$/i.test(n)));
    assert(!names.includes('native-perf-surface-done.json'));assert(!names.includes('native-perf-surface-after.json'));
    let state=null,helperError=null;
    if(round===1)assert(!names.includes('native-perf-surface-request.json'));
    else{
      const request=await load(path.join(sampleRoot,'native-perf-surface-request.json'));
      exact(request,['schemaVersion','scope','runId','pid','browserPid','token']);
      assert.equal(request.schemaVersion,1);assert.equal(request.scope,'windows-native-surface-request');
      assert.equal(request.runId,owned.runId);assert.equal(request.pid,bound.pid);assert.equal(request.browserPid,bound.browserPid);
      assert.match(request.token,/^[0-9a-f]{32}$/);
      const before=await load(path.join(sampleRoot,'native-perf-surface-before.json'));
      exact(before,['schemaVersion','scope','request','binding','state']);
      assert.equal(before.schemaVersion,1);assert.equal(before.scope,'windows-native-surface-before');
      assert.deepEqual(before.request,request);assert.deepEqual(before.binding,bound.binding);
      state=before.state;
      exact(state,['schemaVersion','scope','runId','href','timeOriginMs','atMs','theme','platform','material','highContrast','forcedColors','reducedTransparency','focused','visibility','viewport','expanded','palette','surfaces']);
      assert.equal(state.schemaVersion,1);assert.equal(state.scope,'windows-native-surface-state');
      assert.equal(state.runId,owned.runId);assert.equal(state.href,'http://tauri.localhost/');
      assert.equal(state.timeOriginMs,bound.timeOriginMs);num(state.atMs,0,300000);
      assert.equal(state.theme,'light');assert.equal(state.platform,'windows');assert.equal(state.material,'mica');
      assert.equal(state.visibility,'visible');
      for(const k of ['highContrast','forcedColors','reducedTransparency','focused','expanded'])assert.equal(typeof state[k],'boolean');
      assert.equal(state.viewport.length,3);num(state.viewport[0],1,16384);num(state.viewport[1],1,16384);num(state.viewport[2],.25,8);
      exact(state.palette,['base','elevated','text']);Object.values(state.palette).forEach(color);
      exact(state.surfaces,['navigation','appbar','content','card']);
      for(const surface of Object.values(state.surfaces)){
        exact(surface,['rect','background','text','radius']);assert.equal(surface.rect.length,4);
        surface.rect.slice(0,2).forEach(v=>num(v,-16384,16384));surface.rect.slice(2).forEach(v=>num(v,1,16384));
        color(surface.background);color(surface.text);num(surface.radius,0,128);
      }
      const capture=await load(path.join(sampleRoot,'surface-capture.receipt.json'));
      assert.equal(capture.exitCode,1);assert.equal(capture.tagFromActualDomTheme,true);
      assert.equal(capture.command[0],pkg.helperExe);assert.equal(capture.command[1],sampleRoot);
      assert.equal(capture.command[2],String(bound.pid));assert.equal(normalize(capture.command[4]),normalize(pkg.exe));
      const identity=await load(path.join(sampleRoot,'surface-identity.json'));
      assert.equal(identity.pid,bound.pid);assert.equal(normalize(identity.exe),normalize(pkg.exe));
      assert.equal(capture.command[3],String(identity.creationMs));
      helperError=(await bytes(path.join(sampleRoot,'surface-capture.stderr.log'))).toString('utf8');
      assert(helperError.includes(round===2?'StripPrefixError':round===3?'0x80070057':'owned-capture-frame-timeout'));
      if(round>=3){
        const inventory=await load(path.join(sampleRoot,'rf121-window-inventory-light-visible.json'));
        assert.equal(inventory.scope,'rf121-owned-process-window-inventory');assert.equal(inventory.runId,owned.runId);
        assert.equal(inventory.pid,bound.pid);assert.equal(inventory.creationMs,identity.creationMs);
        assert.equal(inventory.otherProcessWindowsInspected,0);assert.equal(inventory.pixelsRead,0);
        assert.equal(inventory.heldProcessIdentityVerifiedBeforeAndAfter,true);
      }
    }
    const recordedIdentities=[...(a.beforeSnapshot?.processes??[]),...(a.afterSnapshot?.processes??[])]
      .map(p=>({pid:p.pid,creationMs:p.creationMs}));
    assert(recordedIdentities.some(p=>p.pid===bound.pid));assert(recordedIdentities.some(p=>p.pid===bound.browserPid));
    assert(recordedIdentities.every(p=>Number.isSafeInteger(p.pid)&&p.pid>0&&Number.isFinite(p.creationMs)&&p.creationMs>0));
    samples.push({index:a.index,root:sampleRoot,runId:owned.runId,pid:bound.pid,browserPid:bound.browserPid,
      nativeSuccess:native.success,nativeReason:native.reason,completedPhases:native.phases.length,
      state,helperError,maintenance,recordedIdentities,cleanupIntegrity:a.cleanupIntegrity,
      captureBindingAccepted:false,pixelsProduced:false});
  }
  rounds.push({round,root:dir,exitCode:receipt.exitCode,accepted:false,samples});
}
assert.equal(runIds.size,12);
const validation={schemaVersion:1,task:'RF-121',scope:'windows-theme-binding-failed-rounds-integrity',
  at:new Date().toISOString(),accepted:false,evidenceIntegrityVerified:true,cacheCleanupEligible:true,
  sourceFiles:1830,rounds,beforeSnapshots:9,pixelBindings:0,diagnosticOnly:true,performanceMetrics:null,
  applicationMaterialAccepted:false,fullMatrixAccepted:false,nativeAppearancePropertiesVerified:false,
  historicalHomeTimeoutRootCauseProven:false,rf121Closed:false};
await writeFile(path.join(stage,'failed-rounds-validation.json'),JSON.stringify(validation,null,2)+'\n',{flag:'wx'});
process.stdout.write('Verified 12 terminal samples, 9 before snapshots, 0 pixel bindings; acceptance remains false\n');
