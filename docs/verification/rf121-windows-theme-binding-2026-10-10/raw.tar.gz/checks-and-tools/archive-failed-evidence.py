"""Archive actual failed runs without manufacturing screenshot acceptance."""
from pathlib import Path
import datetime, gzip, hashlib, io, json, tarfile
root = Path('D:/SoloSoul')
stage = Path(__file__).parent
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
validation = load(stage/'failed-rounds-validation.json')
cleanup = load(stage/'cache-cleanup.json')
assert validation['accepted'] is False and validation['evidenceIntegrityVerified'] is True
assert len(validation['rounds']) == 4 and validation['beforeSnapshots'] == 9 and validation['pixelBindings'] == 0
assert cleanup['matchingOwnedIdentitiesLive'] == 0 and cleanup['processesTerminatedByThisTool'] == 0
assert cleanup['preservedBytesVerified'] is True and len(cleanup['removedCachePaths']) == 96
for item in cleanup['preservedVaultAndRootFiles']:
    assert sha(Path(item['path']).read_bytes()) == item['sha256']
for item in cleanup['applicationLogs']:
    assert sha(Path(item['copy']).read_bytes()) == item['sha256']
sources = load(stage/'sources-applied.json')
for name,digest in sources.items(): assert sha((root/name).read_bytes()) == digest
for package_name in ['runtime-package.json','runtime-package-d-root.json','runtime-package-readable.json']:
    package = load(stage/package_name)
    for filename,digest in [(package['exe'],package['sha256']),(package['helperExe'],package['helperSha256'])]:
        assert sha(Path(filename).read_bytes()) == digest
assert load(stage/'after-build.receipt.json')['exitCode'] == 1
for n in [2,3,4]: assert load(stage/f'round{n}.receipt.json')['exitCode'] == 1
members = {}
allowed = {'.json','.log','.py','.ps1','.toml','.lock','.mjs','.rs','.js'}
def add(source,name):
    assert name not in members and '..' not in Path(name).parts
    assert source.is_file() and not source.is_symlink() and not (source.lstat().st_file_attributes & 0x400)
    assert source.suffix.lower() in allowed
    members[name] = source.read_bytes()
for source in stage.iterdir():
    if source.is_file() and source.suffix.lower() in allowed: add(source,'checks-and-tools/'+source.name)
for helper in ['helper','helper-d-root','helper-d-root-readable']:
    for name in ['Cargo.toml','Cargo.lock','src/bin/owned-window.rs']:
        add(stage/helper/name,helper+'/'+name)
for name in ['tauri/src-tauri/src/native_perf/sdk_surface.rs',
             'tauri/src-tauri/src/native_perf/sdk_surface.js',
             'tauri/src-tauri/src/native_perf/sdk_journey.rs',
             'tauri/scripts/native-perf-surface.node.test.mjs',
             'tauri/scripts/run-node-tests.mjs']:
    add(root/name,'source/'+name)
for group in validation['rounds']:
    d=Path(group['root'])
    for source in d.iterdir():
        if source.is_file(): add(source,f"round-{group['round']}/"+source.name)
    output=d/'actual100'
    for source in output.iterdir():
        if source.is_file(): add(source,f"round-{group['round']}/actual100/"+source.name)
    for sample in group['samples']:
        sd=Path(sample['root'])
        for source in sd.iterdir():
            if source.is_file(): add(source,f"round-{group['round']}/actual100/{sd.name}/"+source.name)
for source in (stage/'application-logs').rglob('*'):
    if source.is_file(): add(source,source.relative_to(stage).as_posix())
archive_dir=root/'docs/verification/rf121-windows-theme-binding-2026-10-10'
archive_dir.mkdir(exist_ok=False)
archive_path=archive_dir/'raw.tar.gz'
with archive_path.open('xb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(mode='w',fileobj=zipped,format=tarfile.PAX_FORMAT) as tar:
            for name,data in sorted(members.items()):
                info=tarfile.TarInfo(name); info.size,info.mtime,info.mode=len(data),0,0o644
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive_path,'r:gz') as tar:
    reread={info.name:tar.extractfile(info).read() for info in tar.getmembers() if info.isfile()}
assert reread==members
index={'schemaVersion':1,'task':'RF-121','scope':'windows-theme-binding-failed-rounds-integrity',
       'archive':'raw.tar.gz','archiveSha256':sha(archive_path.read_bytes()),'archiveBytes':archive_path.stat().st_size,
       'memberCount':len(members),'members':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())],
       'readbackAllMembersVerified':True,'includesPhysicalVaults':False,'includesExecutablesModelsOrCaches':False,
       'applicationMaterialAccepted':False,'fullMatrixAccepted':False,'accepted':False,
       'unusedProposals':['checks-and-tools/archive-surface-evidence.py','checks-and-tools/prepare-cleanup.py','checks-and-tools/cleanup-surface-owned.ps1','checks-and-tools/render-surface-captures.py'],
       'unusedProposalWarning':'Prepared for an accepted capture which never occurred; do not execute these acceptance-gated scripts against failed rounds.'}
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as out: out.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
write(archive_dir/'index.json',index)
record={'schemaVersion':1,'task':'RF-121','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope':index['scope'],'accepted':False,'evidenceIntegrityVerified':True,
        'checks':load(stage/'checks-accepted.json'),'runtime':load(stage/'runtime-package-readable.json'),
        'validation':validation,'cleanup':cleanup,
        'desktopObservation':load(stage/'desktop-session.json'),'sessionObservation':load(stage/'desktop-session-state.json'),
        'archive':{'path':str(archive_dir.relative_to(root)),**{k:index[k] for k in ['archiveSha256','archiveBytes','memberCount','readbackAllMembersVerified']}},
        'diagnosticOnly':True,'performanceMetrics':None,'applicationMaterialAccepted':False,
        'fullMatrixAccepted':False,'nativeAppearancePropertiesVerified':False,'rf121Closed':False,
        'historicalHomeTimeoutRootCauseProven':False,'defaultDependenciesChanged':False,'sdkBudgetsUnchanged':True}
write(root/'docs/verification/rf121-windows-theme-binding-2026-10-10.json',record)
document=f'''# RF-121 Windows 主题快照与窗口绑定诊断入口

2026-10-10。非默认 Windows `native-perf` 入口完成单元与构建检查；四轮共十二个原生样本均已保留和独立核验。实际生成九份截图前主题快照，**零份像素绑定通过**。本阶段不验收应用材质，不关闭 RF-121，也不解除 RF-122～127 的前置。

请求限定固定文件与 run/PID/browser/token；只读脚本不读取业务文本或发送业务 IPC。截图前后绑定同一 frame/loader/timeOrigin、主题、色板、布局、辅助功能和焦点，回执核验实际快照及 BGRA 文件 SHA。没有请求文件时原行程保持；默认应用命令、依赖、Core 许可及 SDK 预算不改。截图后的真实集成路径仍未通过，不以单元测试代替它。

| 轮次 | 样本 | 实际结果 |
| --- | --- | --- |
| 1 | 3 | 路径字符串比较拒绝捕获请求；原生行程两次通过，一次首页超时 |
| 2 | 3 | 六阶段及主题前快照完成；旧工具硬编码 C 盘目录拒绝 D 盘样本 |
| 3 | 3 | 六阶段及主题前快照完成；新增 DWM 属性读取返回 0x80070057 |
| 4 | 3 | 六阶段及主题前快照完成；WGC 到达等待帧阶段，原五秒预算内无帧 |

第一轮首页失败中，第二次认证流程 failed，登录收到 tauri-error；经完整合同核验的维护准入错误为 operations-active，部分活动见证包括 update-source-preferences。该观测没有覆盖全部活动许可，不能认定唯一原因或历史首页超时根因。其余十一份认证诊断均记录两次 finished；后九次因截图回执缺失，最终原生证明为 surface-capture-timeout，不能记作整组通过。

九份实际前快照均为 Windows light/mica。这里的 mica 是 DOM 材质状态，不是原生属性读回或视觉验收。微软 [DWMWINDOWATTRIBUTE 文档](https://learn.microsoft.com/en-us/windows/win32/api/dwmapi/ne-dwmapi-dwmwindowattribute)将深色、标题栏颜色、系统背景类型列为设置属性；当前工具不把未文档化的 getter 当作能力前提。这三项记 null，nativeAppearanceVerified=false。原 PID/birth/EXE、唯一窗口、几何、前台状态、DPI 和像素守卫保留。旧工具、固定 D 盘工具和明确读取能力的工具分别保存。

只读 Win32/WTS 观测记录工具所在会话 1 为 Disconnected，活动控制台为会话 2，输入桌面访问错误 5；未读取用户名或像素、未发送输入或修改系统设置。恢复运行工具的同一会话并解除锁屏后，需重新核验环境再捕获。不把这一条件直接认作所有无帧失败的确定根因。

Rust 格式、默认及非默认严格 Clippy、新 GUI Release 构建通过。原生诊断 121 项（新增八项）、许可 29 项、更新偏好 15 项通过；Node 228 项中 227 通过、0 失败、1 既有 Windows 文件 symlink 权限跳过，含六项固定脚本回归。两个后续独立捕获工具分别六项测试、严格 Clippy 与构建通过。构建仅改写 Cargo.toml 换行，原始 sourceUnchanged=false 回执保留，经规范化字节及 TOML 等价核验后恢复原换行；未改变依赖。

{len(sources)} 个源码/配置、94 资源、公开 100 对象 v1 夹具和三个工具版本的字节核验一致。GUI SHA-256 为 `{record['runtime']['sha256']}`。计时仅为带诊断入口的记录，不提供未插桩性能基线。

清理前 fresh CIM 确认 {cleanup['identitiesChecked']} 个记录身份退出，清理工具未结束进程。仅删除实际存在的 {len(cleanup['removedCachePaths'])} 个本轮缓存、解除 {len(cleanup['linksUnlinked'])} 个联接；{len(cleanup['preservedVaultAndRootFiles'])} 份 Vault/根级原件与 {len(cleanup['applicationLogs'])} 份应用日志逐字保留。清理首次在盘符根目录规范化检查处拒绝，尚未删除文件；原脚本保留，修正比较后完成清理。

见[结构化记录](rf121-windows-theme-binding-2026-10-10.json)和[原件索引](rf121-windows-theme-binding-2026-10-10/index.json)。归档共 {len(members)} 个成员，全部逐字回读校验，不含物理 Vault、二进制、模型或缓存。先前未使用的正向归档/清理/渲染方案仅为历史原件，索引显式标记不可用于本次失败轮次。

恢复会话后使用 `build/rf121-theme-binding-20261010/run-surface-captures.py` 的固定轮次逻辑准备新的独立输出，不能覆盖既有样本。仍需真实截图前后绑定，以及浅深色、折叠、缩放、恢复、减少透明度/高对比、长内容和其他平台矩阵。RF-112、RF-121、RF-312 与后续六项前置保持未完成。
'''
with (root/'docs/verification/RF-121-windows-theme-binding.md').open('x',encoding='utf-8',newline='\n') as out: out.write(document)
print(f'Archived {len(members)} actual originals ({archive_path.stat().st_size} bytes); all read back; native acceptance false')
