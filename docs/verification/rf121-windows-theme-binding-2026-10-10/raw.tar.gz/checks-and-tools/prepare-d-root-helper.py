from pathlib import Path
import hashlib,json

stage = Path(__file__).parent
old = stage / 'helper'
new = stage / 'helper-d-root'
new.mkdir(exist_ok=False)
rows=[]
for name in ['Cargo.toml','Cargo.lock','src/bin/owned-window.rs']:
    data=(old/name).read_bytes()
    target=new/name;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as out:out.write(data)
    rows.append({'relativePath':name,'originalSha256':hashlib.sha256(data).hexdigest()})
source=new/'src/bin/owned-window.rs'
text=source.read_text(encoding='utf-8')
start=text.index('    let temp = PathBuf::from(r"C:\\Users\\40299571\\AppData\\Local\\Temp");')
end=text.index('    let pid: u32 = args[1].parse()?;',start)
block=text[start:end]
newblock=block.replace('r"C:\\Users\\40299571\\AppData\\Local\\Temp"','FIXED_STAGE').replace('root.as_path()','root')
function='const FIXED_STAGE: &str = r"D:\\SoloSoul\\build\\rf121-theme-binding-20261010";\n\nfn owned_stage(root: &Path) -> Outcome<PathBuf> {\n    ordinary(root, true)?;\n'+newblock+'    Ok(temp)\n}\n\n'
text=text[:start]+'    let temp = owned_stage(&root)?;\n'+text[end:]
assert text.count('fn main() -> Outcome<()> {')==1
text=text.replace('fn main() -> Outcome<()> {',function+'fn main() -> Outcome<()> {')
assert 'C:\\Users\\40299571\\AppData\\Local\\Temp' not in text
test='''
    fn guard_test_dir(prefix: &str) -> PathBuf {
        let stamp = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
        let root = Path::new(FIXED_STAGE).join(format!("{prefix}{}-{stamp}",std::process::id()));
        fs::create_dir(&root).unwrap();
        root
    }
    #[test]
    fn actual_d_stage_namespace_accepts_only_its_owned_sample() {
        let root = guard_test_dir("ss-rf121-composed-window-guard-test-");
        let child = root.join("sample-001");
        fs::create_dir(&child).unwrap();
        assert!(same(&owned_stage(&child).unwrap(),Path::new(FIXED_STAGE)).unwrap());
        fs::remove_dir(&child).unwrap();
        fs::remove_dir(&root).unwrap();
    }
    #[test]
    fn actual_d_stage_rejects_parent_other_namespace_and_external_root() {
        let unrelated = guard_test_dir("rf121-not-capture-");
        assert!(owned_stage(&unrelated).is_err());
        assert!(owned_stage(Path::new(FIXED_STAGE)).is_err());
        assert!(owned_stage(Path::new(r"D:\\SoloSoul")).is_err());
        fs::remove_dir(&unrelated).unwrap();
    }
'''
assert text.rstrip().endswith('}')
text=text.rstrip()[:-1]+test+'}\n'
source.write_text(text,encoding='utf-8',newline='\n')
with (stage/'d-root-helper-proposal.json').open('x',encoding='utf-8',newline='\n') as out:
    out.write(json.dumps({'originalFiles':rows,'fixedStage':str(stage),'changedSourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
      'purpose':'Replace obsolete fixed C stage with this one fixed D stage; do not accept arbitrary TEMP or stage paths',
      'originalHelperAndFrozenBinaryUnchanged':True,'otherGuardsUnchanged':True},indent=2)+'\n')
print('Prepared independent fixed-D helper with two actual directory-guard tests')
