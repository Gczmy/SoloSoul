from pathlib import Path
import datetime,hashlib,json,os,re,shutil,struct,subprocess,time,tomllib
root=Path('D:/SoloSoul');stage=Path(__file__).parent;cache=root/'build/rf312-maintenance-20261009'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
    with (stage/name).open('x',encoding='utf-8',newline='\n') as out:out.write(json.dumps(value,indent=2)+'\n')
sources=load(stage/'sources-applied.json')
def verify_sources():
    for file,digest in sources.items():assert sha(root/file)==digest,file
verify_sources()
checks={}
for name in ['rust-format-check','clippy-default','clippy-native','rust-native','rust-rf905','rust-preferences','node-full']:
    receipt=load(stage/(name+'.receipt.json'));assert receipt['exitCode']==0 and receipt['sourceUnchanged'],name
    checks[name]=receipt
for name,expected in [('rust-native',121),('rust-rf905',29),('rust-preferences',15)]:
    raw=(stage/(name+'.stdout.log')).read_text(encoding='utf-8')
    rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)
    assert rows==[(str(expected),'0','0')],(name,rows)
    checks[name]['testTotals']={'passed':expected,'failed':0,'ignored':0}
assert all(f'surface::tests::{name} ... ok' in (stage/'rust-native.stdout.log').read_text() for name in [
    'surface_file_reads_actual_bytes_and_rejects_oversize','surface_file_rejects_directory_and_missing_marker',
    'surface_state_accepts_bounded_palette_geometry_and_actual_identity','surface_state_rejects_payload_unknown_fields_and_invalid_colors',
    'surface_state_rejects_document_clock_mode_and_missing_targets','surface_request_rejects_replay_and_arbitrary_input',
    'surface_acknowledgment_binds_original_request_and_exact_pixel_bytes','surface_stability_rejects_theme_focus_geometry_and_time_changes'])
node=(stage/'node-full.stdout.log').read_text();assert 'tests 228' in node and 'pass 227' in node and 'fail 0' in node and 'skipped 1' in node
for name in ['helper-format-check-appearance','helper-tests-appearance','helper-clippy-appearance','helper-build-appearance']:
    assert load(stage/(name+'.receipt.json'))['exitCode']==0,name
save('checks-accepted.json',{'sourceFiles':len(sources),'sourceManifestSha256':sha(stage/'sources-applied.json'),
    'checks':checks,'node':{'tests':228,'passed':227,'failed':0,'existingSkipped':1},'newNativeContractTests':8})
env=os.environ.copy();env.update({'TEMP':str(cache/'tmp'),'TMP':str(cache/'tmp'),
    'CARGO_HOME':str(cache/'cargo-home'),'CARGO_TARGET_DIR':str(cache/'cargo-target'),
    'CARGO_BUILD_JOBS':'1','ORT_CACHE_DIR':str(cache/'ort-cache'),'npm_config_cache':str(cache/'npm-cache')})
env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','');env.pop('PDFIUM_LIBRARY_PATH',None)
manifest=root/'tauri/src-tauri/Cargo.toml';before=manifest.read_bytes()
with (stage/'build-Cargo-before.toml').open('xb') as out:out.write(before)
name='native-release-build';command=['npm.cmd','run','tauri','--','build','--config','src-tauri/tauri.native-perf.conf.json','--features','native-perf','--no-bundle','--ci']
start=time.monotonic()
with (stage/(name+'.stdout.log')).open('xb') as out,(stage/(name+'.stderr.log')).open('xb') as err:
    process=subprocess.Popen(command,cwd=root/'tauri',env=env,stdout=out,stderr=err)
    save(name+'.live.json',{'pid':process.pid,'command':command,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    print('New GUI build live PID '+str(process.pid),flush=True);code=process.wait()
after=manifest.read_bytes()
with (stage/'build-Cargo-after.toml').open('xb') as out:out.write(after)
changed=[file for file,digest in sources.items() if sha(root/file)!=digest]
save(name+'.receipt.json',{'command':command,'pid':process.pid,'exitCode':code,'elapsedSeconds':time.monotonic()-start,
    'sourceUnchanged':not changed,'changedSourceFiles':changed,'pdfiumOverrideInherited':False})
if changed:
    assert changed==['tauri/src-tauri/Cargo.toml'],changed
    assert before.replace(b'\r\n',b'\n')==after.replace(b'\r\n',b'\n')
    assert tomllib.loads(before.decode('utf-8'))==tomllib.loads(after.decode('utf-8'))
    save('build-manifest-newline-parity.json',{'rawReceiptSourceUnchanged':False,
        'normalizedBytesEqual':True,'parsedTomlEqual':True,'beforeSha256':hashlib.sha256(before).hexdigest(),
        'afterSha256':hashlib.sha256(after).hexdigest(),'action':'Restore original newline bytes only; keep raw receipt'})
    manifest.write_bytes(before)
verify_sources();assert code==0,'Build failed; do not start a native GUI'
runtime=stage/'ss-rf121-runtime/bin';runtime.mkdir(parents=True,exist_ok=False)
exe=runtime/'solo_soul.exe';shutil.copy2(cache/'cargo-target/release/solo_soul.exe',exe)
data=exe.read_bytes();offset=struct.unpack_from('<I',data,0x3c)[0]
assert data[offset:offset+4]==b'PE\0\0' and struct.unpack_from('<H',data,offset+24+68)[0]==2
for marker in [b'windows-native-surface-before',b'windows-native-surface-after',b'windows-native-auth-attribution',b'windows-native-maintenance-admission']:
    assert marker in data,marker
old=load(root/'build/rf1104-update-preferences-20261010/runtime-package.json')
assert sha(exe)!=old['sha256']
rows=[]
for item in old['resources']:
    source=Path(item['source']);relative=Path(item['copy']).relative_to(Path(old['exe']).parent)
    copy=runtime/relative;assert copy.resolve().is_relative_to(runtime.resolve())
    assert sha(source)==item['sha256'];copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,copy)
    assert sha(copy)==item['sha256'];rows.append({'source':str(source),'copy':str(copy),'sha256':item['sha256']})
assert len(rows)==94
helper=stage/'helper-target/debug/rf121-wgc-owned-window.exe'
package={'exe':str(exe),'sha256':sha(exe),'bytes':len(data),'windowsGuiSubsystem':2,'resources':rows,
    'helperExe':str(helper),'helperSha256':sha(helper),'helperSourceSha256':sha(stage/'helper/src/bin/owned-window.rs'),
    'sourceManifestSha256':sha(stage/'sources-applied.json')}
save('runtime-package.json',package);verify_sources()
print('New GUI and helper frozen; 94 resources and all source files verified',flush=True)
