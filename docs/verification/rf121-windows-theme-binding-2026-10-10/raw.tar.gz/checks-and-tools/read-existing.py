from pathlib import Path
import hashlib,json,tarfile
root=Path('D:/SoloSoul');stage=Path(__file__).parent
old=root/'docs/verification/rf121-windows-composed-capture-2026-10-06'
index=json.loads((old/'index.json').read_text())
archive=old/index['archive']
assert hashlib.sha256(archive.read_bytes()).hexdigest()==index['archiveSha256']
records={e['path']:e for e in index['entries']}
names=['tools/Cargo.toml','tools/Cargo.lock','tools/src/bin/owned-window.rs',
    'tools/run-actual-owned-capture-round5.py','tools/prepare-owned-capture.py']
with tarfile.open(archive,'r:gz') as tar:
    for name in names:
        record=records[name];member=tar.getmember(name)
        assert member.isfile() and member.size==record['bytes']
        data=tar.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest()==record['sha256']
        path=stage/'previous'/name
        assert path.resolve().is_relative_to(stage.resolve())
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as out:out.write(data)
print(json.dumps({'rf121OriginalArchiveVerified':True,'readOnlyToolSourcesRecovered':names}))
