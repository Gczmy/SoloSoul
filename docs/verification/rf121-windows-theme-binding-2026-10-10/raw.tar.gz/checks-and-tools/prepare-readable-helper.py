from pathlib import Path
import hashlib,json
stage=Path(__file__).parent;old=stage/'helper-d-root';new=stage/'helper-d-root-readable'
new.mkdir(exist_ok=False)
rows=[]
for name in ['Cargo.toml','Cargo.lock','src/bin/owned-window.rs']:
    data=(old/name).read_bytes();target=new/name;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as out:out.write(data)
    rows.append({'relativePath':name,'originalSha256':hashlib.sha256(data).hexdigest()})
p=new/'src/bin/owned-window.rs';text=p.read_text(encoding='utf-8')
text=text.replace('DwmGetWindowAttribute, DWMWA_CAPTION_COLOR, DWMWA_CLOAKED,','DwmGetWindowAttribute, DWMWA_CLOAKED,')
text=text.replace('DWMWA_EXTENDED_FRAME_BOUNDS, DWMWA_SYSTEMBACKDROP_TYPE,','DWMWA_EXTENDED_FRAME_BOUNDS,')
text=text.replace('                DWMWA_USE_IMMERSIVE_DARK_MODE,\n','')
for line in ['    let mut backdrop = 0u32;\n','    let mut native_dark = 0u32;\n','    let mut caption_color = 0u32;\n']:
    assert text.count(line)==1; text=text.replace(line,'')
begin=text.index('        DwmGetWindowAttribute(\n            hwnd,\n            DWMWA_SYSTEMBACKDROP_TYPE,')
end=text.index('        RoInitialize(RO_INIT_MULTITHREADED)?;',begin)
text=text[:begin]+text[end:]
begin=text.index('    let mut dark_after = 0u32;')
end=text.index('    let foreground_after =',begin)
text=text[:begin]+text[end:]
for old_value,new_value in [
  ('"dwmDarkMode":native_dark==1','"dwmDarkMode":null'),
  ('"dwmCaptionColor":caption_color','"dwmCaptionColor":null'),
  ('"dwmSystemBackdropType":backdrop','"dwmSystemBackdropType":null'),
  ('"schemaVersion":1,"scope":"rf121-owned-window-wgc-frame"','"schemaVersion":2,"scope":"rf121-owned-window-wgc-frame"')]:
    assert text.count(old_value)==1; text=text.replace(old_value,new_value)
text=text.replace('let proof = json!({"dwmDarkMode":null,','let proof = json!({"nativeAppearanceVerified":false,"dwmAppearanceReadback":"no-documented-getters","dwmDarkMode":null,')
assert 'DWMWA_USE_IMMERSIVE_DARK_MODE' not in text
assert 'DWMWA_CAPTION_COLOR' not in text
assert 'DWMWA_SYSTEMBACKDROP_TYPE' not in text
p.write_text(text,encoding='utf-8',newline='\n')
with (stage/'readable-helper-proposal.json').open('x',encoding='utf-8',newline='\n') as out:
    out.write(json.dumps({'originalFiles':rows,'fixedStage':str(stage),
      'changedSourceSha256':hashlib.sha256(p.read_bytes()).hexdigest(),
      'reason':'DWM enum documents dark-mode, caption-color and system-backdrop as setter options, not supported getters',
      'primarySource':'https://learn.microsoft.com/en-us/windows/win32/api/dwmapi/ne-dwmapi-dwmwindowattribute',
      'nativeAppearancePropertiesVerified':False,'noMissingReadCoercedToDefault':True,
      'originalDHelperAndBinaryPreserved':True,'ownedWindowPixelAndGeometryGuardsUnchanged':True},indent=2)+'\n')
print('Prepared read-capability-aware helper; unavailable native properties are explicit null, never defaults')
