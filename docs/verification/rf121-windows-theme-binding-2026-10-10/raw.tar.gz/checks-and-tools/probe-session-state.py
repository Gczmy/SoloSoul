from pathlib import Path
import ctypes,ctypes.wintypes as w,datetime,json
stage=Path(__file__).parent
desktop=json.loads((stage/'desktop-session.json').read_text(encoding='utf-8'))
api=ctypes.WinDLL('wtsapi32',use_last_error=True)
api.WTSQuerySessionInformationW.argtypes=[w.HANDLE,w.DWORD,ctypes.c_int,ctypes.POINTER(w.LPWSTR),ctypes.POINTER(w.DWORD)]
api.WTSQuerySessionInformationW.restype=w.BOOL
api.WTSFreeMemory.argtypes=[w.LPVOID]
buffer=w.LPWSTR();size=w.DWORD()
data={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'queriedSessionId':desktop['callerSessionId'],
      'userNamesRead':False,'pixelsRead':0,'systemSettingsChanged':False}
if api.WTSQuerySessionInformationW(None,desktop['callerSessionId'],8,ctypes.byref(buffer),ctypes.byref(size)):
    try:
        assert size.value==ctypes.sizeof(ctypes.c_int)
        state=ctypes.cast(buffer,ctypes.POINTER(ctypes.c_int)).contents.value
        names=['Active','Connected','ConnectQuery','Shadow','Disconnected','Idle','Listen','Reset','Down','Init']
        assert 0<=state<len(names)
        data.update({'available':True,'connectionState':state,'connectionStateName':names[state]})
    finally:api.WTSFreeMemory(buffer)
else:data.update({'available':False,'win32Error':ctypes.get_last_error()})
with (stage/'desktop-session-state.json').open('x',encoding='utf-8',newline='\n') as out:out.write(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))
