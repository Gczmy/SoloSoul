from pathlib import Path
import json,re
root=Path('D:/SoloSoul');stage=Path(__file__).parent
report=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md'
for name in ['rust-format-check','clippy-default','clippy-native','node-full']:
    receipt=json.loads((stage/(name+'.receipt.json')).read_text())
    assert receipt['exitCode']==0 and receipt['sourceUnchanged']
for name in ['helper-format-check-appearance','helper-tests-appearance','helper-clippy-appearance','helper-build-appearance']:
    assert json.loads((stage/(name+'.receipt.json')).read_text())['exitCode']==0
text=report.read_bytes().decode('utf-8').replace('\r\n','\n')
before_rows=re.findall(r'^\| \d+ \| \[RF-\d+\].*$',text,re.M)
assert len(before_rows)==294
assert '### RF-121 Windows 主题与窗口绑定入口（2026-10-10，进行中）' not in text
old='- 当前处理：**RF-312 当前 Windows 两档完整行程与内存复核已验，下一步补 RF-121 实际主题绑定的窗口矩阵；旧首页超时根因、RF-112/121/312 与 RF-122～127 前置保持**。'
assert old in text
text=text.replace(old,'- 当前处理：**RF-121 Windows只读主题/色板与窗口捕获绑定入口进行中；完整原生回验尚待完成，RF-112/121/312与RF-122～127前置保持**。',1)
text+='\n\n### RF-121 Windows 主题与窗口绑定入口（2026-10-10，进行中）\n\n'
text+='- 仅非默认Windows诊断新增固定只读快照及owned文件握手；没有请求文件时保留原行程，新增入口不接受任意表达式或业务数据。截图前后独立核验原run/PID/browser、文档/frame/loader/timeOrigin及实际主题、色板、视口、布局、辅助功能与焦点；固定截图文件字节SHA绑定回执，变化或超时仍失败。默认应用入口、依赖、Core许可和SDK原预算不改。\n'
text+='- 实际Rust格式、默认与非默认严格Clippy exit0；固定Node入口228项、227通过/0失败/1既有Windows文件symlink权限跳过，新增六项只读脚本检查通过。原生Rust诊断/许可回归仍在编译，未取得终态，不提前记录通过。1830源码/配置输入已冻结。\n'
text+='- 从既有逐字归档恢复窗口捕获工具，仅增加所持HWND的前台状态、DPI、DWM实际深色标志和标题栏颜色前后读取；原临时目录、PID/birth/EXE、HWND筛选及像素守卫保持。独立临时SDK项目四项回归、格式、严格Clippy和构建通过，未改变生产Cargo清单。\n'
text+='- 新GUI构建、实际三样本绑定和完整材质矩阵仍待执行；本阶段尚未提交或推送。285/294、3待验证、6待执行及所有任务卡状态保持，goal active。\n'
assert re.findall(r'^\| \d+ \| \[RF-\d+\].*$',text,re.M)==before_rows
report.write_bytes(text.replace('\n','\r\n').encode('utf-8'))
print('Recorded actual completed checks and remaining native gates; all294 task rows unchanged')
