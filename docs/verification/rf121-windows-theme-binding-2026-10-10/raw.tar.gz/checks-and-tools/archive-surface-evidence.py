"""Archive accepted raw evidence after actual visual review and owned cache cleanup."""
from pathlib import Path
import datetime, gzip, hashlib, io, json, tarfile

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
capture = stage / 'ss-rf121-composed-window-current'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
validation = load(capture / 'validation.json')
review = load(capture / 'visual-review.json')
cleanup = load(capture / 'cache-cleanup.json')
assert validation['accepted'] and len(validation['samples']) == 3
assert review['actualImagesInspected'] == 3 and len(review['images']) == 3
assert review['applicationMaterialAccepted'] is False and review['fullMatrixAccepted'] is False
assert cleanup['matchingOwnedIdentitiesLive'] == 0 and cleanup['processesTerminatedByThisTool'] == 0
assert cleanup['preservedBytesVerified'] is True
assert len(cleanup['removedCachePaths']) == 24
for item in cleanup['preservedVaultAndRootFiles']:
    assert sha(Path(item['path']).read_bytes()) == item['sha256']
for item in review['images']:
    assert sha(Path(item['png']).read_bytes()) == item['pngSha256']
for name, digest in load(stage / 'sources-applied.json').items():
    assert sha((root / name).read_bytes()) == digest, name
package = load(stage / 'runtime-package.json')
assert sha(Path(package['exe']).read_bytes()) == package['sha256']
assert sha(Path(package['helperExe']).read_bytes()) == package['helperSha256']
assert load(stage / 'after-build.receipt.json')['exitCode'] == 0

members = {}
def add(source, name):
    assert name not in members and not source.is_symlink()
    assert source.is_file() and not (source.lstat().st_file_attributes & 0x400)
    assert not name.lower().endswith(('.exe','.dll','.db','.onnx'))
    members[name] = source.read_bytes()

for source in stage.iterdir():
    if source.is_file() and source.suffix in {'.json','.log','.py','.ps1','.toml','.mjs','.rs'}:
        add(source, 'checks-and-tools/' + source.name)
for source in [stage / 'helper/Cargo.toml',stage / 'helper/Cargo.lock',stage / 'helper/src/bin/owned-window.rs']:
    add(source, 'capture-helper/' + source.relative_to(stage / 'helper').as_posix())
for name in ['tauri/src-tauri/src/native_perf/sdk_surface.rs',
             'tauri/src-tauri/src/native_perf/sdk_surface.js',
             'tauri/src-tauri/src/native_perf/sdk_journey.rs',
             'tauri/scripts/native-perf-surface.node.test.mjs',
             'tauri/scripts/run-node-tests.mjs']:
    add(root / name,'source/' + name)
for source in capture.iterdir():
    if source.is_file(): add(source,'capture/' + source.name)
for source in (capture / 'actual100').iterdir():
    if source.is_file(): add(source,'capture/actual100/' + source.name)
    elif source.is_dir() and source.name in {'sample-001','sample-002','sample-003'}:
        # Root-level proofs/pixels only. Physical vault, profile, model and resource directories are omitted.
        for proof in source.iterdir():
            if proof.is_file(): add(proof,'capture/actual100/' + source.name + '/' + proof.name)
for source in (capture / 'application-logs').rglob('*'):
    if source.is_file(): add(source,'capture/' + source.relative_to(capture).as_posix())

archive_dir = root / 'docs/verification/rf121-windows-theme-binding-2026-10-10'
archive_dir.mkdir(exist_ok=False)
archive_path = archive_dir / 'raw.tar.gz'
with archive_path.open('xb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(mode='w',fileobj=zipped,format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mtime, info.mode = len(data), 0, 0o644
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive_path,'r:gz') as tar:
    reread = {info.name:tar.extractfile(info).read() for info in tar.getmembers() if info.isfile()}
assert reread == members
index = {'schemaVersion':1,'task':'RF-121','scope':'windows-theme-state-owned-capture-binding',
         'archive':'raw.tar.gz','archiveSha256':sha(archive_path.read_bytes()),
         'archiveBytes':archive_path.stat().st_size,'memberCount':len(members),
         'members':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())],
         'readbackAllMembersVerified':True,'includesPhysicalVaults':False,
         'includesExecutablesModelsOrCaches':False,'applicationMaterialAccepted':False,'fullMatrixAccepted':False}
with (archive_dir / 'index.json').open('x',encoding='utf-8',newline='\n') as out:
    out.write(json.dumps(index,indent=2)+'\n')
record = {'schemaVersion':1,'task':'RF-121','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope':'windows-theme-state-owned-capture-binding','accepted':True,
          'checks':load(stage / 'checks-accepted.json'),'runtime':package,'validation':validation,
          'visualReview':review,'cleanup':cleanup,
          'archive':{'path':str(archive_dir.relative_to(root)),**{k:index[k] for k in ['archiveSha256','archiveBytes','memberCount','readbackAllMembersVerified']}},
          'diagnosticOnly':True,'performanceMetrics':None,'applicationMaterialAccepted':False,
          'fullMatrixAccepted':False,'rf121Closed':False,
          'defaultDependenciesChanged':False,'sdkBudgetsUnchanged':True}
with (root / 'docs/verification/rf121-windows-theme-binding-2026-10-10.json').open('x',encoding='utf-8',newline='\n') as out:
    out.write(json.dumps(record,indent=2)+'\n')
themes = sorted({sample['state']['theme'] for sample in validation['samples']})
materials = sorted({sample['state']['material'] for sample in validation['samples']})
rows = []
for sample in validation['samples']:
    state, window = sample['state'], sample['capture']
    rows.append(f"| {sample['index']} | `{state['theme']}` | `{window['dwmDarkMode']}` | `{state['material']}` | {window['ownedWindowDpi']} | {window['width']} × {window['height']} |")
document = f'''# RF-121 Windows 主题状态与所属窗口截图绑定

2026-10-10。本阶段完成三个独立公开测试库行程的主题快照与原生窗口截图绑定，主题为 {', '.join(themes)}，材质为 {', '.join(materials)}。这只验收当前入口，不关闭 RF-121，也不解除 RF-122～127 的前置。

仅非默认 `native-perf` 的 Windows SDK 行程新增固定只读快照；没有请求文件时原行程保持。请求限定 run/PID/browser/nonce，截图前后验证同一文档、frame、loader、timeOrigin、主题、RGBA 色板、视口、布局和辅助功能状态。确认回执绑定原快照与原始 BGRA 像素的 SHA-256；状态变化、超时、额外字段或身份变化仍失败。没有新增默认命令、依赖或 SDK 预算。

原生捕获只选择对应 PID/birth/EXE 的唯一合格窗口，持有进程句柄并核对 HWND、样式、几何、前台状态、DPI、DWM 深色标志及标题栏颜色。三个样本均独立通过完整行程、两次认证流程、维护准入合同与截图字节校验。DOM 主题与原生 DWM 深色标志一致；Mica 样本验证原生 backdrop=2、标题栏颜色为默认值。DOM 焦点与 HWND 前台状态分别记录，不将两者强行等同。

| 样本 | DOM 主题 | DWM 深色 | 原生材质 | 所属窗口 DPI | 原始像素尺寸 |
| --- | --- | --- | --- | --- | --- |
{chr(10).join(rows)}

实际查看了三张从原始 premultiplied BGRA 转换的 PNG。观察结果保存在[结构化记录](rf121-windows-theme-binding-2026-10-10.json)；原始像素保留，不用 PNG 替代字节绑定。其他窗口捕获数为零。

Rust 格式、默认/非默认严格 Clippy、新 GUI Release 构建通过。原生诊断 121 项（新增八项绑定回归）、许可 29 项、更新偏好 15 项通过；Node 228 项中 227 通过、0 失败、1 既有 Windows 文件 symlink 权限跳过。独立窗口工具四项回归、严格 Clippy 与构建通过。构建若只改写 Cargo.toml 换行，原始 false 回执保留，经字节规范化及 TOML 等价核验后仅恢复原换行。

使用 100 对象的公开 v1 夹具，生产 KDF 64 MiB/3/4；来源夹具、冻结的 {len(load(stage / 'sources-applied.json'))} 个源码/配置输入、94 个资源及新 EXE 均核验 SHA。GUI SHA-256 为 `{package['sha256']}`。本轮计时只属于带观测器的诊断，不提供未插桩性能基线或性能改进结论。

采样结束后 fresh CIM 复核所记录身份全部退出，未由清理工具结束进程。只清理 24 个确定属于本轮的缓存路径；联接先解除，Vault、根级回执、原始截图和应用日志逐字保留。归档省略物理 Vault、EXE/DLL、模型与缓存；[原件索引](rf121-windows-theme-binding-2026-10-10/index.json)的 {len(members)} 个成员已逐字回读校验。

完整验收仍缺深色实际操作、折叠、缩放、恢复、减少透明度/高对比、长内容及其他平台对应原生场景。v1 夹具严格固定浅色/ocean，不能修改夹具后沿用原合同宣称完整矩阵通过。RF-112/121/312 的整项状态与后续六项前置保持。
'''
with (root / 'docs/verification/RF-121-windows-theme-binding.md').open('x',encoding='utf-8',newline='\n') as out:
    out.write(document)
print('Archived ' + str(len(members)) + ' originals; every member read back byte-for-byte')
