from pathlib import Path
import datetime, hashlib, json, subprocess, sys, time

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
first = stage / 'ss-rf121-composed-window-current'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name, value):
    with (stage / name).open('x', encoding='utf-8', newline='\n') as out:
        out.write(json.dumps(value, indent=2) + '\n')

assert load(stage / 'after-build.receipt.json')['exitCode'] == 1
assert load(stage / 'surface-captures.receipt.json')['exitCode'] == 1
assert load(first / 'actual100.receipt.json')['exitCode'] == 1
journey = load(first / 'actual100/native-perf-sdk-journey-results.json')
auth = load(first / 'actual100/native-perf-auth-attribution-results.json')
assert not journey['success'] and not auth['success'] and len(journey['samples']) == 3
assert [s['success'] for s in journey['samples']] == [False,True,True]
assert all(s['cleanupIntegrity']['complete'] for s in journey['samples'])
failed = journey['samples'][0]['nativeProof']
assert failed['reason'] == 'probe-timeout' and failed['failedStep'] == 'home'
auth_raw = load(first / 'actual100/sample-001/native-perf-auth-attribution.json')
maintenance_raw = load(first / 'actual100/sample-001/native-perf-maintenance-admission.json')
assert auth_raw['frontend']['flows'][1]['events'][-1]['stage'] == 'failed'
assert auth_raw['frontend']['replies'][-1]['command'] == 'login'
assert auth_raw['frontend']['replies'][-1]['status'] == 'tauri-error'
assert len(maintenance_raw['failures']) == 1
assert maintenance_raw['failures'][0]['errorClass'] == 'operations-active'
assert any(w['kind'] == 'update-source-preferences' for w in maintenance_raw['failures'][0]['witnesses'])
captures = load(first / 'capture-results.json')
assert not captures['success'] and len(captures['samples']) == 3
assert all(not s['success'] and s['errorCategory'] == 'AssertionError' for s in captures['samples'])
checks = []
for index in range(1,4):
    sample = first / 'actual100' / ('sample-' + str(index).zfill(3))
    consumed = load(sample / 'native-perf-consumed.json')
    bound = load(sample / 'native-perf-sdk-journey-bound.json')
    assert Path(consumed['root']).samefile(sample) and Path(bound['root']).samefile(sample)
    assert not Path(bound['root']).samefile(stage)
    assert not (sample / 'native-perf-surface-request.json').exists()
    assert not list(sample.glob('rf121-wgc-*.bgra'))
    checks.append({'index':index,'resolvedPathEqual':Path(bound['root']).resolve()==sample.resolve(),
                  'filesystemIdentityEqual':True,'unrelatedDirectoryRejected':True,
                  'captureRequestPublished':False,'pixelsProduced':False})
save('first-round-rejection.json', {'scope':'rf121-capture-driver-path-representation-rejection',
     'nativeJourneysPassed':2,'nativeJourneysFailed':1,'captureBindingsAccepted':False,'capturePathsRejected':3,
     'independentNativeFailure':{'reason':'probe-timeout','failedStep':'home',
       'secondLoginReply':'tauri-error','maintenanceFailure':'operations-active',
       'observedWitness':'update-source-preferences','fullActivityCoverage':False,
       'historicalHomeTimeoutRootCauseProven':False,'rf312Closed':False},
     'reason':'Path.resolve retains Windows extended-length prefixes; compare actual filesystem identity instead',
     'checks':checks,'oldDriverSha256':sha(stage / 'first-run-run-surface-captures.py'),
     'fixedDriverSha256':sha(stage / 'run-surface-captures.py'),
     'productionSourcesChanged':False,'frozenGuiRebuiltForThisFix':False})
pkg = load(stage / 'runtime-package.json')
assert sha(Path(pkg['exe'])) == pkg['sha256']
assert sha(Path(pkg['helperExe'])) == pkg['helperSha256']
for name, digest in load(stage / 'sources-applied.json').items():assert sha(root / name) == digest

jobs = [
    ('round2-surface-captures',[sys.executable,'-X','utf8',str(stage / 'run-surface-captures.py'),'--round','2']),
    ('round2-surface-independent-validation',['node',str(stage / 'verify-surface-captures.mjs'),'--round','2']),
    ('round2-surface-render',[sys.executable,'-X','utf8',str(stage / 'render-surface-captures.py'),'--round','2']),
]
started = time.monotonic()
code = 0
for name, command in jobs:
    began = time.monotonic()
    with (stage / (name + '.stdout.log')).open('xb') as out, (stage / (name + '.stderr.log')).open('xb') as err:
        process = subprocess.Popen(command,cwd=root,stdout=out,stderr=err)
        save(name + '.live.json', {'pid':process.pid,'at':now(),'command':command})
        print(name + ' live PID ' + str(process.pid),flush=True)
        code = process.wait()
    save(name + '.receipt.json', {'pid':process.pid,'at':now(),'command':command,'exitCode':code,'elapsedSeconds':time.monotonic()-began})
    print(name + ' terminal exit ' + str(code),flush=True)
    if code:break
save('round2.receipt.json', {'at':now(),'exitCode':code,'elapsedSeconds':time.monotonic()-started,
     'firstFailedCaptureRoundPreserved':True,'applicationMaterialAccepted':False,'performanceMetrics':None})
raise SystemExit(code)
