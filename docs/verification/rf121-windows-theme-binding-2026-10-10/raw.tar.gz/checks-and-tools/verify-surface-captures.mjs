import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile, lstat, realpath} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {checkJourney, checkBound} from '../../tauri/scripts/native-perf-sdk-journey.mjs';
import {describeAuthAttribution} from '../../tauri/scripts/native-perf-auth-contract.mjs';
import {checkMaintenanceAdmission} from '../../tauri/scripts/native-perf-maintenance-contract.mjs';

const stage=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(stage,'../..');
assert([JSON.stringify([]),JSON.stringify(['--round','2']),JSON.stringify(['--round','3']),JSON.stringify(['--round','4'])].includes(JSON.stringify(process.argv.slice(2))));
const captureStage=path.join(stage,process.argv.length===2?'ss-rf121-composed-window-current':'ss-rf121-composed-window-current-round'+process.argv[3]);
const output=path.join(captureStage,'actual100');
const load=async file=>JSON.parse((await readFile(file,'utf8')).replace(/^\uFEFF/,''));
const sha=async file=>createHash('sha256').update(await readFile(file)).digest('hex');
const regular=async(file,max=262144)=>{
  const stat=await lstat(file); assert(stat.isFile()&&!stat.isSymbolicLink()&&stat.size<=max);
  assert.equal((await realpath(file)).toLowerCase(),file.toLowerCase());
  return load(file);
};
const exact=(value,keys)=>assert.deepEqual(Object.keys(value).sort(),[...keys].sort());
const number=(v,min,max)=>assert(Number.isFinite(v)&&v>=min&&v<=max);
const color=v=>{assert(Array.isArray(v)&&v.length===4);v.slice(0,3).forEach(x=>number(x,0,255));number(v[3],0,1);};
const stateKeys=['schemaVersion','scope','runId','href','timeOriginMs','atMs','theme','platform',
  'material','highContrast','forcedColors','reducedTransparency','focused','visibility',
  'viewport','expanded','palette','surfaces'];
function validateState(s,owned,bound){
  exact(s,stateKeys); assert.equal(s.schemaVersion,1);assert.equal(s.scope,'windows-native-surface-state');
  assert.equal(s.runId,owned.runId);assert.equal(s.href,'http://tauri.localhost/');
  assert.equal(s.timeOriginMs,bound.timeOriginMs);number(s.atMs,0,300000);
  assert(['light','dark'].includes(s.theme));assert.equal(s.platform,'windows');
  assert(['mica','solid'].includes(s.material));assert(['visible','hidden'].includes(s.visibility));
  for(const key of ['highContrast','forcedColors','reducedTransparency','focused','expanded'])assert.equal(typeof s[key],'boolean');
  assert(s.viewport.length===3);number(s.viewport[0],1,16384);number(s.viewport[1],1,16384);number(s.viewport[2],.25,8);
  exact(s.palette,['base','elevated','text']);Object.values(s.palette).forEach(color);
  exact(s.surfaces,['navigation','appbar','content','card']);
  for(const surface of Object.values(s.surfaces)){
    exact(surface,['rect','background','text','radius']);assert.equal(surface.rect.length,4);
    surface.rect.slice(0,2).forEach(v=>number(v,-16384,16384));
    surface.rect.slice(2).forEach(v=>number(v,1,16384));
    color(surface.background);color(surface.text);number(surface.radius,0,128);
  }
}

const inputs=await load(path.join(captureStage,'input-proof.json'));
const pkg=inputs.runtime;
assert.equal(await sha(pkg.exe),pkg.sha256);assert.equal(await sha(pkg.helperExe),pkg.helperSha256);
assert.equal(await sha(pkg.helperSource??path.join(stage,'helper/src/bin/owned-window.rs')),pkg.helperSourceSha256);
assert.equal(await sha(path.join(stage,'sources-applied.json')),inputs.sourceManifestSha256);
for(const [name,digest] of Object.entries(await load(path.join(stage,'sources-applied.json'))))assert.equal(await sha(path.join(root,name)),digest);
for(const item of pkg.resources){assert.equal(await sha(item.source),item.sha256);assert.equal(await sha(item.copy),item.sha256);}
for(const [name,digest] of Object.entries(inputs.fixtureFiles))assert.equal(await sha(path.join(inputs.fixture,name)),digest);
const receipt=await load(path.join(captureStage,'actual100.receipt.json'));
assert.equal(receipt.exitCode,0);assert.equal(receipt.sourceUnchanged,true);
assert.equal(receipt.originalFixtureUnchanged,true);assert.equal(receipt.resourcesUnchanged,true);
assert.equal(receipt.pdfiumOverrideInherited,false);
const journey=await load(path.join(output,'native-perf-sdk-journey-results.json'));
const authGroup=await load(path.join(output,'native-perf-auth-attribution-results.json'));
assert.equal(journey.exeSha256,pkg.sha256);assert.equal(journey.success,true);
assert.equal(journey.samplesRequested,3);assert.equal(journey.interrupted,false);
assert.equal(journey.sourceUnchanged,true);assert.equal(journey.memoryIntervalMs,null);
assert.deepEqual(journey.samples.map(s=>s.index),[1,2,3]);assert.equal(authGroup.success,true);
assert.equal(authGroup.samples.length,3);assert.equal(authGroup.performanceMetrics,null);
const samples=[];
for(const sample of journey.samples){
  const dir=path.join(output,`sample-${String(sample.index).padStart(3,'0')}`);
  assert.equal(sample.root.toLowerCase(),dir.toLowerCase());assert.equal(sample.success,true);
  assert.equal(sample.cleanupIntegrity.complete,true);
  assert.deepEqual(await regular(path.join(output,`sample-${String(sample.index).padStart(3,'0')}.json`),4194304),sample);
  const owned=await regular(path.join(dir,'native-perf-owned.json'));
  const bound=await regular(path.join(dir,'native-perf-sdk-journey-bound.json'));
  assert.deepEqual(owned,sample.owned);assert.deepEqual(bound,sample.bound);
  checkBound(bound,owned,sample.processId,bound.port);
  const native=await regular(path.join(dir,'native-perf-sdk-journey.json'),4194304);
  assert.deepEqual(native,sample.nativeProof);checkJourney(native,owned,bound,journey.fixture,false);
  const auth=await regular(path.join(dir,'native-perf-auth-attribution.json'));
  const attribution=describeAuthAttribution(auth,owned,bound);
  assert.equal(attribution.frontend.flows.length,2);
  assert(attribution.frontend.flows.every(f=>f.outcome==='finished'));
  const maintenance=checkMaintenanceAdmission(await regular(path.join(dir,'native-perf-maintenance-admission.json'),4194304),auth,owned,bound);
  const request=await regular(path.join(dir,'native-perf-surface-request.json'),4096);
  exact(request,['schemaVersion','scope','runId','pid','browserPid','token']);
  assert.equal(request.schemaVersion,1);assert.equal(request.scope,'windows-native-surface-request');
  assert.equal(request.runId,owned.runId);assert.equal(request.pid,bound.pid);
  assert.equal(request.browserPid,bound.browserPid);assert.match(request.token,/^[0-9a-f]{32}$/);
  const beforePath=path.join(dir,'native-perf-surface-before.json');
  const before=await regular(beforePath),after=await regular(path.join(dir,'native-perf-surface-after.json'));
  exact(before,['schemaVersion','scope','request','binding','state']);
  exact(after,['schemaVersion','scope','request','binding','beforeSha256','pixelSha256','state','stable','applicationMaterialAccepted','performanceMetrics']);
  assert.equal(before.schemaVersion,1);assert.equal(after.schemaVersion,1);
  assert.equal(before.scope,'windows-native-surface-before');assert.equal(after.scope,'windows-native-surface-after');
  for(const proof of [before,after]){assert.deepEqual(proof.request,request);assert.deepEqual(proof.binding,bound.binding);validateState(proof.state,owned,bound);}
  const a={...before.state},b={...after.state};delete a.atMs;delete b.atMs;assert.deepEqual(a,b);
  assert(after.state.atMs>=before.state.atMs&&before.state.atMs>=native.lastProbe.atMs);
  assert.equal(after.stable,true);assert.equal(after.applicationMaterialAccepted,false);assert.equal(after.performanceMetrics,null);
  const tag=before.state.theme+'-visible';
  const captured=await regular(path.join(dir,`rf121-wgc-${tag}.json`));
  const inventory=await regular(path.join(dir,`rf121-window-inventory-${tag}.json`));
  const owner=await regular(path.join(dir,'surface-identity.json'));
  assert.equal(owner.pid,bound.pid);assert.equal(owner.exe.toLowerCase(),pkg.exe.replaceAll('/','\\').toLowerCase());
  assert.equal(captured.schemaVersion,pkg.helperMetadataVersion??1);assert.equal(captured.scope,'rf121-owned-window-wgc-frame');
  for(const proof of [captured,inventory]){
    assert.equal(proof.runId,owned.runId);assert.equal(proof.pid,bound.pid);assert.equal(proof.creationMs,owner.creationMs);
  }
  assert.equal(inventory.scope,'rf121-owned-process-window-inventory');
  assert.equal(inventory.heldProcessIdentityVerifiedBeforeAndAfter,true);
  assert.equal(inventory.otherProcessWindowsInspected,0);assert.equal(inventory.pixelsRead,0);
  assert.equal(captured.captureMethod,'Windows.Graphics.Capture.CreateForWindow');
  assert.equal(captured.heldProcessAndWindowIdentityVerifiedBeforeAndAfter,true);
  assert.equal(captured.otherWindowsCaptured,0);assert.equal(captured.applicationMaterialAccepted,false);
  assert.equal(captured.tag,tag);assert.equal(captured.pixelFormat,'BGRA8-premultiplied');
  assert.equal(captured.foregroundBefore,captured.foregroundAfter);assert.equal(typeof captured.foregroundBefore,'boolean');
  number(captured.ownedWindowDpi,48,768);
  if(pkg.helperMetadataVersion===2){
    assert.equal(captured.nativeAppearanceVerified,false);assert.equal(captured.dwmAppearanceReadback,'no-documented-getters');
    for(const key of ['dwmDarkMode','dwmCaptionColor','dwmSystemBackdropType'])assert.equal(captured[key],null);
  }else{
    assert.equal(captured.dwmDarkMode,before.state.theme==='dark');
    if(before.state.material==='mica'){
      assert.equal(captured.dwmSystemBackdropType,2);assert.equal(captured.dwmCaptionColor,4294967295);
    }
  }
  assert.equal(captured.pixelFile,`rf121-wgc-${tag}.bgra`);
  const pixelFile=path.join(dir,captured.pixelFile),stat=await lstat(pixelFile);
  assert(stat.isFile()&&!stat.isSymbolicLink());assert.equal(await realpath(pixelFile),pixelFile);
  assert.equal(stat.size,captured.bytes);assert.equal(stat.size,captured.width*captured.height*4);
  assert(stat.size>0&&stat.size<=32*1024*1024);
  const beforeSha=await sha(beforePath),pixelSha=await sha(pixelFile);
  assert.equal(after.beforeSha256,beforeSha);assert.equal(after.pixelSha256,pixelSha);
  assert.deepEqual(await regular(path.join(dir,'native-perf-surface-done.json'),4096),
    {...request,scope:'windows-native-surface-done',beforeSha256:beforeSha,pixelSha256:pixelSha});
  assert.equal((await regular(path.join(dir,'surface-capture.receipt.json'))).exitCode,0);
  // Cleanup uses the exact identities from both actual process snapshots, never inferred descendants.
  const recordedIdentities=[...sample.beforeSnapshot.processes,...sample.afterSnapshot.processes]
    .map(p=>({pid:p.pid,creationMs:p.creationMs}));
  assert(recordedIdentities.every(p=>Number.isInteger(p.pid)&&Number.isFinite(p.creationMs)));
  samples.push({index:sample.index,runId:owned.runId,pid:bound.pid,browserPid:bound.browserPid,
    state:before.state,afterAtMs:after.state.atMs,beforeSha256:beforeSha,pixelSha256:pixelSha,
    capture:captured,recordedIdentities,maintenance,success:true});
}
assert.equal(new Set(samples.map(s=>s.runId)).size,3);
const validation={schemaVersion:1,task:'RF-121',scope:'windows-owned-theme-state-capture-binding',
  at:new Date().toISOString(),accepted:true,samples,sourceFiles:1830,
  diagnosticOnly:true,performanceMetrics:null,applicationMaterialAccepted:false,
  fullMatrixAccepted:false,otherPlatformAcceptance:false,nativeAppearancePropertiesVerified:pkg.helperMetadataVersion!==2};
await writeFile(path.join(captureStage,'validation.json'),JSON.stringify(validation,null,2)+'\n',{flag:'wx'});
process.stdout.write('Three complete native journeys and three exact state/pixel bindings independently verified\n');
