from pathlib import Path
import subprocess,sys
root=Path('D:/SoloSoul');stage=Path(__file__).parent
jobs=[
    ('rust-format-check',['cargo','fmt','--all','--check']),
    ('clippy-default',['cargo','clippy','--locked','--all-targets','--','-D','warnings']),
    ('clippy-native',['cargo','clippy','--locked','--features','native-perf','--all-targets','--','-D','warnings']),
    ('rust-native',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','native_perf::','--','--nocapture']),
    ('rust-rf905',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','rf905','--','--nocapture']),
    ('rust-preferences',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','commands::update_preferences::tests','--','--nocapture']),
]
for name,command in jobs:
    code=subprocess.call([sys.executable,'-X','utf8',str(stage/'run-check.py'),name,*command],cwd=root)
    if code: raise SystemExit(code)
print('All declared Rust gates reached successful terminal results',flush=True)
