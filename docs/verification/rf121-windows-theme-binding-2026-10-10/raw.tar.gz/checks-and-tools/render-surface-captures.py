"""Render verified owned BGRA captures; preserve raw premultiplied pixels."""
from pathlib import Path
import hashlib, json, sys
from PIL import Image

assert sys.argv[1:] in [[], ['--round', '2'], ['--round', '3'], ['--round', '4']]
stage = Path(__file__).parent / ('ss-rf121-composed-window-current' if not sys.argv[1:] else 'ss-rf121-composed-window-current-round' + sys.argv[2])
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
validation = load(stage / 'validation.json')
assert validation['accepted'] and len(validation['samples']) == 3
rows = []
for sample in validation['samples']:
    proof = sample['capture']
    root = stage / 'actual100' / ('sample-' + str(sample['index']).zfill(3))
    raw = (root / proof['pixelFile']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == sample['pixelSha256']
    assert len(raw) == proof['width'] * proof['height'] * 4 == proof['bytes']
    # Pillow's RGBa mode stores premultiplied components and unpremultiplies on conversion.
    rgba = bytearray(len(raw))
    rgba[0::4], rgba[1::4], rgba[2::4], rgba[3::4] = raw[2::4], raw[1::4], raw[0::4], raw[3::4]
    test = Image.frombytes('RGBa', (1, 1), bytes([50, 25, 0, 128])).convert('RGBA')
    assert test.getpixel((0, 0)) == (99, 49, 0, 128)
    image = Image.frombytes('RGBa', (proof['width'], proof['height']), bytes(rgba)).convert('RGBA')
    png = stage / ('surface-sample-' + str(sample['index']).zfill(3) + '.png')
    with png.open('xb') as out:
        image.save(out, format='PNG')
    rows.append({'index': sample['index'], 'rawSha256': sample['pixelSha256'],
                 'png': str(png), 'pngSha256': hashlib.sha256(png.read_bytes()).hexdigest(),
                 'width': image.width, 'height': image.height,
                 'conversion': 'BGRA8-premultiplied to RGBA via Pillow RGBa; original bytes retained',
                 'otherWindowsIncluded': False, 'visualReviewComplete': False})
with (stage / 'rendered-captures.json').open('x', encoding='utf-8', newline='\n') as out:
    out.write(json.dumps(rows, indent=2) + '\n')
print('Three verified owned screenshots rendered; actual visual inspection still required')
