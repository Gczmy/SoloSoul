from pathlib import Path
stage=Path(__file__).parent
file=stage/'helper/src/bin/owned-window.rs'
before=file.read_bytes();source=before.decode('utf-8').replace('\r\n','\n')
save=stage/'helper-before-native-appearance.rs'
assert not save.exists();save.write_bytes(before)
old='DWMWA_SYSTEMBACKDROP_TYPE,'
assert source.count(old)==2
source=source.replace('DwmGetWindowAttribute, DWMWA_CLOAKED, DWMWA_EXTENDED_FRAME_BOUNDS,',
    'DwmGetWindowAttribute, DWMWA_CLOAKED, DWMWA_EXTENDED_FRAME_BOUNDS, DWMWA_USE_IMMERSIVE_DARK_MODE, DWMWA_CAPTION_COLOR,')
old='let mut backdrop = 0u32;'
assert source.count(old)==1
source=source.replace(old,old+'\n    let mut native_dark = 0u32;\n    let mut caption_color = 0u32;')
old='RoInitialize(RO_INIT_MULTITHREADED)?;'
assert source.count(old)==1
source=source.replace(old,'''DwmGetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, (&mut native_dark as *mut u32).cast(), 4)?;
        DwmGetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, (&mut caption_color as *mut u32).cast(), 4)?;
        require(native_dark <= 1, "native-dark-mode-boolean-required")?;
        RoInitialize(RO_INIT_MULTITHREADED)?;''')
old='let foreground_after = unsafe { GetForegroundWindow() } == hwnd;'
assert source.count(old)==1
source=source.replace(old,'''let mut dark_after = 0u32;
    let mut caption_after = 0u32;
    unsafe {
        DwmGetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, (&mut dark_after as *mut u32).cast(), 4)?;
        DwmGetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, (&mut caption_after as *mut u32).cast(), 4)?;
    }
    require(dark_after == native_dark && caption_after == caption_color, "native-appearance-changed-during-capture")?;
    let foreground_after = unsafe { GetForegroundWindow() } == hwnd;''')
old='let proof = json!({"foregroundBefore":foreground_before'
assert source.count(old)==1
source=source.replace(old,'let proof = json!({"dwmDarkMode":native_dark==1,"dwmCaptionColor":caption_color,"foregroundBefore":foreground_before')
file.write_text(source,encoding='utf-8',newline='\n')
print('Added actual DWM dark-mode and caption-color before/after observations; owned guards preserved')
