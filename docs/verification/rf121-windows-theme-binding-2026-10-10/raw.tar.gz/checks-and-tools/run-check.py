from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
root=Path('D:/SoloSoul');stage=Path(__file__).parent
cache=root/'build/rf312-maintenance-20261009'
name=sys.argv[1];command=sys.argv[2:]
assert command and not (stage/(name+'.receipt.json')).exists()
env=os.environ.copy();env.update({'TEMP':str(cache/'tmp'),'TMP':str(cache/'tmp'),
    'CARGO_HOME':str(cache/'cargo-home'),'CARGO_TARGET_DIR':str(cache/'cargo-target'),
    'CARGO_BUILD_JOBS':'1','ORT_CACHE_DIR':str(cache/'ort-cache'),'npm_config_cache':str(cache/'npm-cache'),
    'PDFIUM_LIBRARY_PATH':str(root/'tauri/src-tauri/resources/pdfium/pdfium.dll')})
env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','')
start=time.monotonic()
with (stage/(name+'.stdout.log')).open('xb') as out,(stage/(name+'.stderr.log')).open('xb') as err:
    process=subprocess.Popen(command,cwd=root/'tauri',env=env,stdout=out,stderr=err)
    (stage/(name+'.live.json')).write_text(json.dumps({'pid':process.pid,'command':command,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n',encoding='utf-8')
    print(name+' live PID '+str(process.pid),flush=True)
    code=process.wait()
proof={'command':command,'pid':process.pid,'exitCode':code,'elapsedSeconds':time.monotonic()-start,
    'temporaryDirectory':env['TEMP'],'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
manifest=stage/'sources-applied.json'
if manifest.exists():
    changed=[p for p,d in json.loads(manifest.read_text()).items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=d]
    proof.update({'sourceUnchanged':not changed,'changedSourceFiles':changed})
(stage/(name+'.receipt.json')).write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
print(name+' terminal exit '+str(code),flush=True)
raise SystemExit(code)
