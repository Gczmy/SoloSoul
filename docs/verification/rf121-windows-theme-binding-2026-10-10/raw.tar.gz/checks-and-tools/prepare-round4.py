from pathlib import Path
stage=Path(__file__).parent
source=(stage/'run-round3.py').read_text(encoding='utf-8')
source=source.replace("assert load(stage/'round2.receipt.json')['exitCode']==1","assert load(stage/'round3.receipt.json')['exitCode']==1")
source=source.replace("second=stage/'ss-rf121-composed-window-current-round2'","second=stage/'ss-rf121-composed-window-current-round3'")
source=source.replace("'d-root-helper-format-check','d-root-helper-tests','d-root-helper-clippy','d-root-helper-build'","'readable-helper-format-check','readable-helper-tests','readable-helper-clippy','readable-helper-build'")
source=source.replace("'d-root-helper-tests.stdout.log'","'readable-helper-tests.stdout.log'")
source=source.replace("helper-target-d-root/debug","helper-target-readable/debug")
source=source.replace("helper-d-root/src/bin","helper-d-root-readable/src/bin")
source=source.replace("package['fixedStageRoot']=str(stage)","package['fixedStageRoot']=str(stage)\npackage['helperMetadataVersion']=2\npackage['nativeAppearancePropertiesVerified']=False")
source=source.replace("runtime-package-d-root.json","runtime-package-readable.json")
start=source.index("save('second-round-rejection.json'")
end=source.index('jobs=[',start)
source=source[:start]+'''save('third-round-rejection.json',{'scope':'rf121-setter-only-dwm-attributes-read-rejection',
     'allSixJourneyPhasesPassed':True,'beforeSnapshotsPublished':3,'captureBindingsAccepted':False,
     'captureErrors':["HRESULT 0x80070057"]*3,'newMetadataVersion':2,
     'nativeAppearancePropertiesVerified':False,'noMissingReadCoercedToDefault':True,
     'originalToolsAndBinaryPreserved':True,'newHelperGuardTestsPassed':6,
     'frozenGuiChanged':False,'productionSourcesChanged':False})
'''+source[end:]
source=source.replace('round3-surface-','round4-surface-').replace("'--round','3'","'--round','4'")
source=source.replace("'round3.receipt.json'","'round4.receipt.json'")
# Preserve the third-round terminal prerequisite after replacing output names.
source=source.replace("assert load(stage/'round4.receipt.json')['exitCode']==1","assert load(stage/'round3.receipt.json')['exitCode']==1")
source=source.replace("'bothFailedCaptureRoundsPreserved':True","'allThreeFailedCaptureRoundsPreserved':True")
with (stage/'run-round4.py').open('x',encoding='utf-8',newline='\n') as out:out.write(source)
print('Prepared fixed fourth capture round; three original failed rounds remain preserved')
