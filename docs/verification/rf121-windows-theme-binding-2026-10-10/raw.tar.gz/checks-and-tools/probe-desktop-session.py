"""Read only desktop/session metadata; no pixels, names of users, or input control."""
from pathlib import Path
import ctypes,ctypes.wintypes as w,datetime,json,os
stage=Path(__file__).parent
u=ctypes.WinDLL('user32',use_last_error=True);k=ctypes.WinDLL('kernel32',use_last_error=True)
u.OpenInputDesktop.argtypes=[w.DWORD,w.BOOL,w.DWORD];u.OpenInputDesktop.restype=w.HANDLE
u.GetThreadDesktop.argtypes=[w.DWORD];u.GetThreadDesktop.restype=w.HANDLE
u.GetUserObjectInformationW.argtypes=[w.HANDLE,ctypes.c_int,w.LPVOID,w.DWORD,ctypes.POINTER(w.DWORD)];u.GetUserObjectInformationW.restype=w.BOOL
u.CloseDesktop.argtypes=[w.HANDLE];u.CloseDesktop.restype=w.BOOL
k.GetCurrentThreadId.restype=w.DWORD;k.WTSGetActiveConsoleSessionId.restype=w.DWORD
k.ProcessIdToSessionId.argtypes=[w.DWORD,ctypes.POINTER(w.DWORD)];k.ProcessIdToSessionId.restype=w.BOOL
def name(handle):
    buf=ctypes.create_unicode_buffer(512);size=w.DWORD()
    if u.GetUserObjectInformationW(handle,2,buf,ctypes.sizeof(buf),ctypes.byref(size)):
        return {'available':True,'name':buf.value}
    return {'available':False,'win32Error':ctypes.get_last_error()}
session=w.DWORD();assert k.ProcessIdToSessionId(os.getpid(),ctypes.byref(session))
thread=u.GetThreadDesktop(k.GetCurrentThreadId());assert thread
data={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'callerPid':os.getpid(),
      'callerSessionId':session.value,'activeConsoleSessionId':k.WTSGetActiveConsoleSessionId(),
      'threadDesktop':name(thread),'pixelsRead':0,'inputEventsSent':0,'systemSettingsChanged':False}
handle=u.OpenInputDesktop(0,False,1)
if handle:
    try:data['inputDesktop']=name(handle)
    finally:assert u.CloseDesktop(handle)
else:data['inputDesktop']={'available':False,'win32Error':ctypes.get_last_error()}
with (stage/'desktop-session.json').open('x',encoding='utf-8',newline='\n') as out:out.write(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))
