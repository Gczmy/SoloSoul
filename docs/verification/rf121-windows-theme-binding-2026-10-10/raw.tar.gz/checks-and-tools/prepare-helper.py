from pathlib import Path
import hashlib,json
stage=Path(__file__).parent
original=stage/'previous/tools'
helper=stage/'helper'
assert not helper.exists()
(helper/'src/bin').mkdir(parents=True)
cargo=(original/'Cargo.toml').read_bytes().decode('utf-8').replace('\r\n','\n')
assert cargo.count('"Win32_UI_WindowsAndMessaging"')==1
cargo=cargo.replace('"Win32_UI_WindowsAndMessaging"','"Win32_UI_WindowsAndMessaging", "Win32_UI_HiDpi"')
(helper/'Cargo.toml').write_text(cargo,encoding='utf-8',newline='\n')
(helper/'Cargo.lock').write_bytes((original/'Cargo.lock').read_bytes())
source=(original/'src/bin/owned-window.rs').read_bytes().decode('utf-8').replace('\r\n','\n')
old='EnumWindows, GetAncestor, GetClientRect, GetWindowLongPtrW, GetWindowRect,'
assert source.count(old)==1
source=source.replace(old,'EnumWindows, GetAncestor, GetClientRect, GetForegroundWindow, GetWindowLongPtrW, GetWindowRect,')
old='UI::WindowsAndMessaging::{'
assert source.count(old)==1
source=source.replace(old,'UI::WindowsAndMessaging::{')
source='use windows::Win32::UI::HiDpi::GetDpiForWindow;\n'+source
old='let mut backdrop = 0u32;'
assert source.count(old)==1
source=source.replace(old,old+'\n    let foreground_before = unsafe { GetForegroundWindow() } == hwnd;\n    let dpi_before = unsafe { GetDpiForWindow(hwnd) };\n    require(dpi_before > 0, "owned-window-dpi-required")?;')
old='let proof = json!({"schemaVersion":1,"scope":"rf121-owned-window-wgc-frame"'
assert source.count(old)==1
source=source.replace(old,'''let foreground_after = unsafe { GetForegroundWindow() } == hwnd;
    let dpi_after = unsafe { GetDpiForWindow(hwnd) };
    require(foreground_after == foreground_before && dpi_after == dpi_before, "window-focus-or-dpi-changed-during-capture")?;
    let proof = json!({"foregroundBefore":foreground_before,"foregroundAfter":foreground_after,"ownedWindowDpi":dpi_before,"schemaVersion":1,"scope":"rf121-owned-window-wgc-frame"''')
(helper/'src/bin/owned-window.rs').write_text(source,encoding='utf-8',newline='\n')
proof={'scope':'existing capture helper + actual owned foreground/DPI observation',
    'baseSourceSha256':hashlib.sha256((original/'src/bin/owned-window.rs').read_bytes()).hexdigest(),
    'changedSourceSha256':hashlib.sha256((helper/'src/bin/owned-window.rs').read_bytes()).hexdigest(),
    'ownedTempNamespaceGuardsPreserved':True,'productionDependenciesChanged':False,
    'exactCachedWindowsVersion':'0.61.3','otherWindowPixelsAllowed':False}
(stage/'helper-change-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(proof))
