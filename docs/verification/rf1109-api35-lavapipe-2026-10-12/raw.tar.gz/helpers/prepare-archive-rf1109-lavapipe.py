from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');B=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=B/'rf1132-card-high-contrast-build-20261012/current-apks.json';j=load(receipt)
assert all(sha(R/n)==h for n,h in j['sourceFiles'].items())
p={'artifactReceiptSha256':sha(receipt),'artifactBuildSourceFiles':j['originalMainBuildSourceFiles'],
   'runtimeValidationSourceFiles':j['sourceFiles'],'changedSourceFiles':j['sourceDifferences'],
   'androidBuildRelevantSourcesEqualCurrent':False,'currentTestApkBuildInputsMatch':True,
   'currentTestApkReceipt':str(receipt),'apkFiles':j['files'],
   'noProductionOrTestCodeChangedThisBackendRun':True,'sourceHead':'391fd0f73'}
(B/'rf1109-lavapipe-source-provenance-20261012.json').write_text(json.dumps(p,indent=2),encoding='utf-8',newline='\n')
s=(B/'archive-rf1109-direct-swiftshader.py').read_text(encoding='utf-8').replace('direct-swiftshader','lavapipe')
s=s.replace("art=load(b/'rf1126-legacy-theme-build-20261011/current-apks.json')","art=load(b/'rf1132-card-high-contrast-build-20261012/current-apks.json')")
s=s.replace('rf1131-source-provenance-20261012.json','rf1109-lavapipe-source-provenance-20261012.json')
s=s.replace("assert provenance['artifactBuildSourceFiles']==art['sourceFiles']","assert provenance['artifactBuildSourceFiles']==art['originalMainBuildSourceFiles']")
s=s.replace("assert len(provenance['changedSourceFiles'])==5 and provenance['androidBuildRelevantSourcesEqualCurrent']","assert len(provenance['changedSourceFiles'])==7 and provenance['currentTestApkBuildInputsMatch']")
s=s.replace("'sourceHead':'8448d87fb'","'sourceHead':'391fd0f73'")
s=s.replace("'surfaceFlingerRenderer':'Android Emulator OpenGL ES Translator (Google SwiftShader)',","'surfaceFlingerRenderer':'Android Emulator OpenGL ES Translator (Google SwiftShader)',\n    'vulkanBackend':'llvmpipe LLVM 21.1.2, Vulkan 1.4.318; auto-selected GLES SwiftShader',")
marker="for n in ['tauri/scripts/android-home-native-regression.py'"
assert marker in s
s=s.replace(marker,"add('build-provenance/current-test-apks.json',b/'rf1132-card-high-contrast-build-20261012/current-apks.json')\nadd('helpers/prepare-rf1109-lavapipe.py',b/'prepare-rf1109-lavapipe.py')\nadd('helpers/prepare-archive-rf1109-lavapipe.py',b/'prepare-archive-rf1109-lavapipe.py')\nadd('source/AndroidCardSurfaceInstrumentedTest.kt',r/'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidCardSurfaceInstrumentedTest.kt')\n"+marker)
s=s.replace("'productionOrTestCodeChanged':False,","'productionOrTestCodeChanged':False,'referenceForUnchangedThisBackendRun':'391fd0f73',")
with (B/'archive-rf1109-lavapipe.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
ps=(B/'cleanup-rf1109-direct-swiftshader.ps1').read_text(encoding='utf-8').replace('direct-swiftshader','lavapipe')
with (B/'cleanup-rf1109-lavapipe.ps1').open('x',encoding='utf-8',newline='\n') as f:f.write(ps)
print('Lavapipe archive and cleanup prepared with separate original main/current test provenance')
