from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');B=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=load(B/'rf1132-card-high-contrast-build-20261012/current-apks.json')
assert all(sha(R/n)==h for n,h in inputs['sourceFiles'].items())
assert all(sha(Path(r['copy']))==r['sha256'] for r in inputs['files'])
for old,new in [('boot-rf1109-api35-direct-swiftshader.py','boot-rf1109-api35-lavapipe.py'),
                ('verify-rf1109-api35-direct-swiftshader.py','verify-rf1109-api35-lavapipe.py'),
                ('stop-rf1109-direct-swiftshader.py','stop-rf1109-lavapipe.py')]:
    s=(B/old).read_text(encoding='utf-8').replace('direct-swiftshader','lavapipe')
    if old.startswith('boot-'):
        assert "'-gpu','swiftshader'" in s
        s=s.replace("'-gpu','swiftshader'","'-gpu','lavapipe'")
        s=s.replace('Fresh owned host-GPU emulator','Fresh owned Lavapipe software-GPU emulator')
    if old.startswith('verify-'):
        start=s.index("artifacts=load(base/")
        end=s.index("files={row['kind']:row for row in artifacts['files']}")
        s=s[:start]+"artifacts=load(base/'rf1132-card-high-contrast-build-20261012/current-apks.json')\nassert artifacts['accepted'] and not artifacts['deviceAcceptance']\nprovenance={'artifactBuildSourceFiles':artifacts['originalMainBuildSourceFiles'], 'runtimeValidationSourceFiles':artifacts['sourceFiles']}\nsources=provenance['runtimeValidationSourceFiles']; assert len(sources)==1837\n"+s[end:]
        s=s.replace("sha(base/'rf1126-legacy-theme-build-20261011/current-apks.json')","sha(base/'rf1132-card-high-contrast-build-20261012/current-apks.json')")
        s=s.replace("sha(base/'rf1131-source-provenance-20261012.json')","sha(base/'rf1132-card-high-contrast-build-20261012/current-apks.json')")
        s=s.replace('env.pop(\'ANDROID_SDK_HOME\',None)',"env.pop('ANDROID_SDK_HOME',None)\nenv['PYTHONUTF8']='1'")
        s=s.replace("'scope':'API35 baseline/cold in both native glass modes'","'scope':'API35 Lavapipe software backend baseline/cold in both native glass modes'")
    target=B/new
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Fresh owned Lavapipe helpers prepared; no original helper rewritten')
