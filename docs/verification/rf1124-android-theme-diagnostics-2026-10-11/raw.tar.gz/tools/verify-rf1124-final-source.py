from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as E
r=Path('D:/SoloSoul');b=Path(__file__).parent
path='tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt'
old=subprocess.check_output(['git','show','HEAD:'+path],cwd=r).decode('utf-8')
new=(r/path).read_text(encoding='utf-8-sig')
def part(s,a,z):return s.split(a,1)[1].split(z,1)[0]
assert part(old,'val expected = if (customSchemes)', '// 等待启动淡出')==part(new,'val expected = if (customSchemes)', '// 等待启动淡出')
assert part(old,'val scenario = ActivityScenario.launch(MainActivity::class.java)','} finally {')==part(new,'val scenario = ActivityScenario.launch(MainActivity::class.java)','} finally {')
assert new.count('TimeUnit.SECONDS.toNanos(45)')==old.count('TimeUnit.SECONDS.toNanos(45)')==1
assert 'setForceDark' not in new and 'setAlgorithmicDarkeningAllowed' not in new
for line in ['if (originalPrefs == null) prefs.delete() else prefs.writeBytes(originalPrefs)', 'setNight(originalNight)']:
    assert new.count(line)==old.count(line)==1
original=b/'rf1124-theme-diagnostic-test-build-20261011';d=b/'rf1124-theme-diagnostic-test-build-retry1-20261011'
rows=[E.parse(f).getroot().attrib for f in (original/'unit-test-xml').glob('*.xml')]
totals={k:sum(int(v[k]) for v in rows) for k in ['tests','failures','errors','skipped']}
assert totals==dict(tests=10,failures=0,errors=0,skipped=0)
receipts={n:json.loads((d/(n+'.receipt.json')).read_text(encoding='utf-8-sig')) for n in ['kotlin-unit-tests','test-build','test-badging','test-signature']}
assert all(x['exitCode']==0 and x['sourceUnchanged'] for x in receipts.values())
art=json.loads((d/'current-apks.json').read_text(encoding='utf-8-sig'));assert len(art['sourceFiles'])==1837
for name,digest in art['sourceFiles'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==digest,name
assert ':app:testX86_64DebugUnitTest UP-TO-DATE' in (d/'kotlin-unit-tests.stdout.log').read_text(encoding='utf-8-sig')
proof=dict(task='RF-1124',base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip(),
    originalThemeAcceptanceBodyUnchanged=True,originalLightDarkLightCommandsAndAssertionsUnchanged=True,budgetSeconds=45,
    productionThemeOrWebViewConfigurationModified=False,sourceCount=1837,
    finalSourceSha256=hashlib.sha256((r/path).read_bytes()).hexdigest(),unit=totals,unitExecutedInFirstBuild=True,
    unitReusedUpToDateInRetry=True,receipts=receipts)
with (d/'final-source-and-checks-proof.json').open('x',encoding='utf-8') as f:json.dump(proof,f,indent=2)
print('Final source: unchanged strict theme contract; 1837 hashes bound; 10 executed unit tests retained; retry Kotlin build green')
