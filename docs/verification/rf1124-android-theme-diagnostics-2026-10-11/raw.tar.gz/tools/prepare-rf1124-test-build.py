from pathlib import Path
import ast, hashlib, json
b = Path(__file__).parent
r = Path('D:/SoloSoul')
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
original = load(b / 'current-apks-rf1121-20261011/current-apks.json')
frozen = load(r / 'build/rf121-theme-binding-20261010/rf1123-checks-retry2-20261011/sources.json')
assert len(frozen) == 1837
test = 'tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt'
assert {name for name, digest in frozen.items() if sha(r / name) != digest} == {test}
changed = {name for name, digest in original['sourceFiles'].items() if sha(r / name) != digest}
windows = {'tauri/scripts/run-node-tests.mjs', 'tauri/src-tauri/src/commands/settings.rs',
    'tauri/src-tauri/src/native_perf.rs', 'tauri/src-tauri/src/native_perf/sdk_surface_appearance.rs',
    'tauri/src-tauri/src/native_perf/preflight_tests.rs'}
assert changed == windows | {test}, changed
assert set(frozen) - set(original['sourceFiles']) == {'tauri/scripts/native-perf-preference-contract.mjs',
    'tauri/scripts/native-perf-preference.node.test.mjs', 'tauri/src-tauri/src/native_perf/preference_trace.rs'}
proof = load(r / 'build/rf121-theme-binding-20261010/rf1123-default-source-proof.json')
assert proof['defaultSettingsCommandBodyAndSignatureUnchanged'] and proof['onlyNativePerfWindowsCfgObservationBlocksAdded']
s = (b / 'rebuild-theme-current-token-test.py').read_text(encoding='utf-8-sig')
s = s.replace("card-visual-state-test-build3/current-apks.json", "current-apks-rf1121-20261011/current-apks.json")
s = s.replace("sources = original['sourceFiles'].copy()", "sources = load(root / 'build/rf121-theme-binding-20261010/rf1123-checks-retry2-20261011/sources.json').copy()")
s = s.replace("assert set(changed) == {test, home}, changed", "assert set(changed) == {test}, changed")
s = s.replace("theme-current-token-test-build1", "rf1124-theme-diagnostic-test-build-20261011")
s = s.replace("'oldTestSha256': original['sourceFiles'][test]", "'oldTestSha256': original['sourceFiles'][test], 'precedingWindowsOnlyChanges': " + repr(sorted(windows)) + ", 'androidProductReuseProof': " + repr(proof))
s = s.replace("current-apks-recovery2/private-packaging-assets.init.gradle", "current-apks-rf1121-20261011/private-packaging-assets.init.gradle")
s = s.replace("run('test-build',", "run('kotlin-unit-tests', ['cmd.exe', '/d', '/c', str(gradle / 'gradlew.bat'), ':app:testX86_64DebugUnitTest', '-x', ':app:rustBuildX86_64Debug', '--init-script', str(base / 'current-apks-rf1121-20261011/private-packaging-assets.init.gradle'), '--offline', '--no-daemon', '--max-workers', '2'], gradle)\nrun('test-build',")
s = s.replace("'--no-daemon', '--max-workers', '2'], gradle)\n\ntest_apk", "'--offline', '--no-daemon', '--max-workers', '2'], gradle)\n\ntest_apk")
s = s.replace("Unchanged full product APK plus rebuilt current neutral-text theme/home instrumentation", "Frozen unchanged RF1121 default Android product APK plus RF1124 native-theme diagnostic instrumentation; current Windows-only changes do not enter Android product")
assert s != (b / 'rebuild-theme-current-token-test.py').read_text(encoding='utf-8-sig')
ast.parse(s)
with (b / 'build-rf1124-theme-diagnostic-test.py').open('x', encoding='utf-8', newline='\n') as f: f.write(s)
print('RF1124 builder prepared; one Android test source changed; default APK reuse explicit')
