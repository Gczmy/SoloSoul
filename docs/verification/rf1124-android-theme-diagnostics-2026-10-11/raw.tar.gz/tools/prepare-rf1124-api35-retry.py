from pathlib import Path
import ast,json
b=Path(__file__).parent
changes=[('boot-rf1124-api35-host.py','boot-rf1124-api35-host-retry1.py',
    'api35-host-rf1124-20261011','api35-host-rf1124-retry1-20261011'),
    ('run-rf1124-theme-diagnostics-retry1.py','run-rf1124-theme-diagnostics-retry1-api35.py',
     "boot_dir = b/f'api{api}-host-rf1124-20261011'",
     "boot_dir = b/(f'api{api}-host-rf1124-20261011' if api==31 else 'api35-host-rf1124-retry1-20261011')"),
    ('stop-rf1124-owned-emulator-retry1.py','stop-rf1124-owned-emulator-retry1-api35.py',
     "s=b/f'api{api}-host-rf1124-20261011'",
     "s=b/(f'api{api}-host-rf1124-20261011' if api==31 else 'api35-host-rf1124-retry1-20261011')")]
for source,target,old,new in changes:
    s=(b/source).read_text(encoding='utf-8-sig');assert old in s;s=s.replace(old,new);ast.parse(s)
    p=b/target
    if p.exists():assert p.read_text(encoding='utf-8-sig')==s
    else:
        with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
with (b/'api35-host-rf1124-20261011/failure.json').open('x',encoding='utf-8') as f:
    json.dump({'exitCode':1,'bootStarted':False,'reason':'Guard rejected SDK-owned 20-second emulator shutdown helper from prior emu kill; no termination or guard weakening',
        'retryInNewDirectory':True,'firstRetryPreparationInlineExitCode':1,'inlineReason':'PowerShell quoting rejected the inline helper command; no product mutations'},f,indent=2)
print('API35 fresh-directory retry prepared; original preflight failure preserved')
