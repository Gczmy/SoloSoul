from pathlib import Path
import datetime,difflib,hashlib,json,subprocess,xml.etree.ElementTree as E
r=Path('D:/SoloSoul'); b=Path(__file__).parent
p='tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt'
old=subprocess.check_output(['git','show','HEAD:'+p],cwd=r).decode('utf-8')
new=(r/p).read_text(encoding='utf-8-sig')
ops=difflib.SequenceMatcher(None,old.splitlines(),new.splitlines(),autojunk=False).get_opcodes()
assert all(op[0] in ['equal','insert'] for op in ops),ops
assert new.count('TimeUnit.SECONDS.toNanos(45)')==old.count('TimeUnit.SECONDS.toNanos(45)')==1
assert 'setForceDark' not in new and 'setAlgorithmicDarkeningAllowed' not in new
d=b/'rf1124-theme-diagnostic-test-build-20261011'
rows=[E.parse(f).getroot().attrib for f in (d/'unit-test-xml').glob('*.xml')]
totals={k:sum(int(v[k]) for v in rows) for k in ['tests','failures','errors','skipped']}
assert totals==dict(tests=10,failures=0,errors=0,skipped=0)
receipts={n:json.loads((d/(n+'.receipt.json')).read_text(encoding='utf-8-sig')) for n in ['kotlin-unit-tests','test-build','test-badging','test-signature']}
assert all(x['exitCode']==0 and x['sourceUnchanged'] for x in receipts.values())
proof=dict(task='RF-1124',base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip(),
    originalTestLinesRetained=True,budgetSeconds=45,themeMediaColorAndNativeBarAssertionsRetained=True,
    productionThemeOrWebViewConfigurationModified=False,oldSourceSha256=hashlib.sha256(old.encode()).hexdigest(),
    newSourceSha256=hashlib.sha256((r/p).read_bytes()).hexdigest(),unit=totals,receipts=receipts,
    at=datetime.datetime.now(datetime.timezone.utc).isoformat())
with (d/'source-and-checks-proof.json').open('x',encoding='utf-8') as f:json.dump(proof,f,indent=2)
with (d/'source-proof-inline-first-failure.json').open('x',encoding='utf-8') as f:
    json.dump({'exitCode':1,'productFailure':False,'scope':'readonly-helper-default-decoding',
        'reason':'Inline reader used locale cp1252 for UTF-8 Kotlin; failed before assertions or mutation',
        'correctedReaderUsesExplicitUtf8':True},f,indent=2)
print(json.dumps({k:v for k,v in proof.items() if k!='receipts'}))
