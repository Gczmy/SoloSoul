from pathlib import Path
import ast, hashlib, json
b = Path(__file__).parent
p = b / 'boot-rf1121-api31-host.py'
s = p.read_text(encoding='utf-8-sig').replace('api31-host-rf1121-20261011', 'api31-host-rf1124-20261011')
assert s != p.read_text(encoding='utf-8-sig')
ast.parse(s)
with (b / 'boot-rf1124-api31-host.py').open('x', encoding='utf-8', newline='\n') as f: f.write(s)
with (b / 'rf1124-preparation-first-failure.json').open('x', encoding='utf-8') as f:
    json.dump({'exitCode': 1, 'productFailure': False, 'buildStarted': False,
        'reason': 'APK source baseline also includes RF1122 Windows-only preflight tests; incomplete helper expected set',
        'originalExecutedSource': 'prepare-rf1124-test-build.first-failed.py',
        'originalExecutedSourceSha256': hashlib.sha256((b / 'prepare-rf1124-test-build.first-failed.py').read_bytes()).hexdigest()}, f, indent=2)
print('Dedicated API31 boot helper prepared without AVD settings changes')
