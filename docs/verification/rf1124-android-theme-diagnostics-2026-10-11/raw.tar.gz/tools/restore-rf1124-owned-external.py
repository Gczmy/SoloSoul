"""Restore only the four proven original public test files, using the actual app UID."""
from pathlib import Path
import base64,hashlib,importlib.util,json,os,re,subprocess,uuid
r=Path('D:/SoloSoul'); b=Path(__file__).parent.resolve(); stage=b/'rf1124-external-owner-recovery-20261011';stage.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
old=b/'api31-theme-rf1124-20261011/supported'; originals=load(old/'external-before.json')
assert set(originals)=={'rf201-system.json','rf201-system-light.png','rf201-system-dark.png','rf201-system-light-again.png'}
v=load(b/'api31-theme-rf1124-20261011/verification.json'); assert all(row['restored'] and row['settingsRestored'] for row in v['results'])
art=load(b/'rf1124-theme-diagnostic-test-build-retry1-20261011/current-apks.json');test=next(x for x in art['files'] if x['kind']=='test')
assert hashlib.sha256(Path(test['copy']).read_bytes()).hexdigest()==test['sha256']
spec=importlib.util.spec_from_file_location('home',r/'tauri/scripts/android-home-native-regression.py');home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
env=os.environ.copy();env.update({'ADB_SERVER_SOCKET':'tcp:localhost:5049','ANDROID_ADB_SERVER_PORT':'5049','TEMP':str(b/'tmp'),'TMP':str(b/'tmp')})
adb=str(b/'sdk/platform-tools/adb.exe');APP='com.solosoul.app';ext=f'/sdcard/Android/data/{APP}/files'
def call(args,**kwargs):return subprocess.run([adb,'-H','localhost','-P','5049','-s','emulator-5586',*args],env=env,check=True,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW,**kwargs)
def read(args):return call(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout.decode().strip()
assert read(['emu','avd','name']).splitlines()[0]=='SoloSoul_RF121_API31_20261010'
assert read(['shell','getprop','ro.build.version.sdk'])=='31'
uid=read(['shell','run-as',APP,'id','-u']);assert re.fullmatch('[0-9]+',uid) and int(uid)>10000
call(['shell','am','force-stop',APP],stdout=subprocess.PIPE)
rootmode=read(['shell','run-as',APP,'stat','-c','%a','.'])
def archive(p):
    with p.open('xb') as f:os.chmod(p,0o600);call(['exec-out','run-as',APP,'tar','-cf','-','.'],stdout=f,stderr=subprocess.PIPE)
backup=stage/'private-data-before.tar';archive(backup);before=home.inventory(backup,require_empty=True)
payload={}
for name,digest in originals.items():
    raw=(old/'external-before'/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest
    actual=call(['exec-out','cat',ext+'/'+name],stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout;assert actual==raw
    assert read(['shell','stat','-c','%u',ext+'/'+name])=='2000'
    payload[name]=base64.b64encode(raw).decode('ascii')
run=uuid.uuid4().hex;manifest=stage/f'rf1124-restore-{run}.json';manifest.write_text(json.dumps(payload),encoding='utf-8')
remote=f'/data/local/tmp/rf1124-restore-{run}.json'
result={'runId':run,'api':31,'appUid':int(uid),'exactOriginalHashes':originals,'beforeEntries':len(before),'restored':False}
try:
    call(['install','-r',test['copy']],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    call(['push',str(manifest),remote],stdout=subprocess.PIPE,stderr=subprocess.PIPE);call(['shell','chmod','644',remote],stdout=subprocess.PIPE)
    call(['shell','run-as',APP,'cp',remote,f'rf1124-restore-{run}.json'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    # These exact four shell-owned files were created by this driver and are verified against the originals above.
    call(['shell','rm','--',*[ext+'/'+name for name in originals]],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    p=call(['shell','am','instrument','-w','-r','-e','waitForActivitiesToComplete','false','-e','privateDataBackedUp','true','-e','themeDiagnosticRun',run,
        '-e','class','com.solosoul.app.AndroidThemeInstrumentedTest#restoreOwnedThemeEvidence','com.solosoul.app.test/androidx.test.runner.AndroidJUnitRunner'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (stage/'instrumentation.stdout.log').write_bytes(p.stdout);(stage/'instrumentation.stderr.log').write_bytes(p.stderr)
    home.verify_native(p.stdout.decode(),'restoreOwnedThemeEvidence');result['nativeRestorePassed']=True
    for name,digest in originals.items():
        actual=call(['exec-out','cat',ext+'/'+name],stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
        assert hashlib.sha256(actual).hexdigest()==digest
        assert read(['shell','stat','-c','%u',ext+'/'+name])==uid
    result['exactExternalBytesAndAppOwnerRestored']=True
finally:
    call(['shell','am','force-stop',APP],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    names=read(['shell','run-as',APP,'ls','-A']).splitlines();assert all(re.fullmatch('[A-Za-z0-9_.-]+',n) and n not in ('.','..') for n in names)
    if names:call(['shell','run-as',APP,'rm','-rf','--',*names],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    private=f'/data/local/tmp/rf1124-owner-private-{run}.tar';call(['push',str(backup),private],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    call(['shell','chmod','644',private],stdout=subprocess.PIPE);call(['shell','run-as',APP,'tar','-xpf',private],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    call(['shell','run-as',APP,'chmod',rootmode,'.'],stdout=subprocess.PIPE)
    restored=stage/'private-data-restored.tar';archive(restored);assert before==home.inventory(restored,require_empty=True)
    assert read(['shell','run-as',APP,'stat','-c','%a','.'])==rootmode
    call(['shell','rm','--',private,remote],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    result['restored']=True
    with (stage/'receipt.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
assert result['nativeRestorePassed'] and result['exactExternalBytesAndAppOwnerRestored'] and result['restored']
print('Four original external files restored byte-exactly with actual app UID; private directory restored',flush=True)
