"""Cold boot the dedicated AVD only when no emulator or its ports are live."""
from pathlib import Path
import datetime, hashlib, json, os, socket, subprocess, time
base=Path(__file__).parent.resolve(); stage=base/'api35-host-rf1124-retry1-20261011'
stage.mkdir(exist_ok=False)
def save(name,v):
    with (stage/name).open('x',encoding='utf8') as f:json.dump(v,f,indent=2)
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
def processes():
    p=subprocess.run([pwsh,'-NoProfile','-Command',"ConvertTo-Json -InputObject @(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(emulator|qemu-system.*)\\.exe$' } | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine) -Depth 3"],check=True,capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    return json.loads(p.stdout)
before=processes(); save('process-preflight.json',before); assert before==[],before
for port in [5586,5587]:
    with socket.socket() as s:s.bind(('127.0.0.1',port))
env=os.environ.copy();env.update({'ANDROID_HOME':str(base/'sdk'),'ANDROID_SDK_ROOT':str(base/'sdk'),'ANDROID_USER_HOME':str(base/'android-user'),'ANDROID_EMULATOR_HOME':str(base/'android-user'),'ANDROID_AVD_HOME':str(base/'avd'),'ANDROID_ADB_SERVER_PORT':'5049','ADB_SERVER_SOCKET':'tcp:localhost:5049','TEMP':str(base/'tmp'),'TMP':str(base/'tmp')});env.pop('ANDROID_SDK_HOME',None)
adb=str(base/'sdk/platform-tools/adb.exe');serial='emulator-5586';avd='SoloSoul_RF121_20261010'
def call(args):
    return subprocess.run([adb,'-H','localhost','-P','5049','-s',serial,*args],env=env,capture_output=True,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
def read(args):
    p=call(args);assert p.returncode==0,(args,p.stderr.decode(errors='replace'));return p.stdout.decode().strip()
config=base/'avd'/f'{avd}.avd'/'config.ini';digest=hashlib.sha256(config.read_bytes()).hexdigest()
command=[str(base/'sdk/emulator/emulator.exe'),'-avd',avd,'-port','5586','-accel','on','-gpu','host','-memory','2048','-cores','2','-no-window','-no-snapshot','-no-audio','-no-boot-anim']
with (stage/'emulator.stdout.log').open('xb') as out,(stage/'emulator.stderr.log').open('xb') as err:
    began=time.monotonic();p=subprocess.Popen(command,cwd=base,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    save('emulator.live.json',{'pid':p.pid,'command':command,'avd':avd,'serial':serial,'appAcceptance':False});print(f'Fresh owned host-GPU emulator PID {p.pid}',flush=True)
    time.sleep(1);save('owned-processes-after-launch.json',processes())
    attempts=[];booted=False
    while time.monotonic()-began<240:
        if p.poll() is not None:break
        a=call(['shell','getprop','sys.boot_completed']);value=a.stdout.decode(errors='replace').strip();attempts.append({'exitCode':a.returncode,'value':value,'elapsed':time.monotonic()-began})
        if a.returncode==0 and value=='1':booted=True;break
        time.sleep(2)
    result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'booted':booted,'pid':p.pid,'command':command,'attempts':attempts,'emulatorExitCode':p.poll(),'appAcceptance':False,'physicalGpuPerformanceAccepted':False,'oldFailuresPreserved':True,'avdConfigUnchanged':hashlib.sha256(config.read_bytes()).hexdigest()==digest}
    if booted:
        assert read(['emu','avd','name']).splitlines()[0]==avd;assert read(['shell','getprop','ro.build.version.sdk'])=='35';assert read(['shell','getprop','ro.product.cpu.abi'])=='x86_64'
        result['settingsBeforeTests']={'blur':read(['shell','settings','get','global','disable_window_blurs']),'night':read(['shell','cmd','uimode','night'])}
        for label,args in [('surfaceflinger',['shell','dumpsys','SurfaceFlinger']),('webview',['shell','dumpsys','webviewupdate'])]:
            a=call(args);(stage/(label+'.log')).write_bytes(a.stdout);assert a.returncode==0
    save('boot.receipt.json',result);print(f'Booted={booted}; application/WebGL acceptance not inferred',flush=True);raise SystemExit(0 if booted else 1)
