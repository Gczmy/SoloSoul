from pathlib import Path
import datetime,hashlib,io,json,os,tarfile
r=Path('D:/SoloSoul');b=Path(__file__).parent.resolve();load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
    return h.hexdigest()
art=load(b/'rf1124-theme-diagnostic-test-build-retry1-20261011/current-apks.json')
assert len(art['sourceFiles'])==1837
for name,digest in art['sourceFiles'].items():assert sha(r/name)==digest,name
proof=load(b/'rf1124-theme-diagnostic-test-build-retry1-20261011/final-source-and-checks-proof.json')
assert proof['unit']==dict(tests=10,failures=0,errors=0,skipped=0) and proof['originalThemeAcceptanceBodyUnchanged']
assert load(b/'rf1124-external-owner-recovery-20261011/receipt.json')['exactExternalBytesAndAppOwnerRestored']
observations=[]
for api in [31,35]:
    c=b/f'api{api}-theme-rf1124-retry1-20261011';v=load(c/'verification.json')
    assert v['diagnosticComplete'] and len(v['results'])==2 and not v['fullRF121Accepted']
    stop=b/('api31-host-rf1124-20261011' if api==31 else 'api35-host-rf1124-retry1-20261011')/'stop.receipt.json'
    s=load(stop);assert s['ownedProcessExited'] and s['settingsRestored'] and s['noForceTermination']
    for row in v['results']:
        assert row['diagnosticEligible'] and row['restored'] and row['settingsRestored'] and row['externalRestored']
        raw=load(c/row['mode']/'theme-diagnostics.json');assert raw['runId']==row['runId']
        records=raw['records'];assert [x['stage'] for x in records]==(['system-light','system-dark'] if api==31 else ['system-light','system-dark','system-light-again'])
        dark=records[1];n=dark['native'];assert n['api']==api and n['nightMode']==2 and n['activityNight']==32 and n['applicationNight']==32
        assert n['androidLightTheme'] is False and n['appCompatLightTheme'] is False
        assert n['forceDark']==1 and dark['colorSchemeMeta']==''
        if api==31:
            assert not row['nativePassed'] and dark['darkMedia'] is False and dark['theme']=='light' and dark['result']=='timeout'
            assert n['providerVersion']=='91.0.4472.114'
        else:
            assert row['nativePassed'] and dark['darkMedia'] is True and dark['theme']=='dark' and n['providerVersion']=='124.0.6367.219'
            assert dark['background']=='#1f1c18' and dark['surface']=='#2a2620' and dark['statusBarLight'] is False and dark['navigationBarLight'] is False
            assert records[0]['theme']==records[2]['theme']=='light' and records[0]['darkMedia'] is records[2]['darkMedia'] is False
        observations.append({'api':api,'mode':row['mode'],'runId':row['runId'],'nativePassed':row['nativePassed'],'darkState':dark,'restored':True})
    visual=load(c/'visual-review.json');assert visual['actualImagesInspected']==(4 if api==31 else 6)
stem='rf1124-android-theme-diagnostics-2026-10-11';dst=r/'docs/verification'/stem;dst.mkdir(exist_ok=False)
with (dst/'.gitattributes').open('x',encoding='ascii',newline='\n') as f:f.write('* -text -diff\n')
entries={}
directories=['rf1124-theme-diagnostic-test-build-20261011','rf1124-theme-diagnostic-test-build-retry1-20261011',
    'api31-theme-rf1124-20261011','api31-theme-rf1124-retry1-20261011','api35-theme-rf1124-retry1-20261011',
    'rf1124-external-owner-recovery-20261011','api31-host-rf1124-20261011','api35-host-rf1124-20261011','api35-host-rf1124-retry1-20261011']
for directory in directories:
    for p in (b/directory).rglob('*'):
        if not p.is_file() or 'external-before' in p.relative_to(b/directory).parts or p.suffix in ('.apk','.tar') or p.name.startswith('rf1124-restore-'):continue
        assert not p.is_symlink() and not (p.lstat().st_file_attributes&0x400)
        entries['raw/'+p.relative_to(b).as_posix()]=p
tools=['prepare-rf1124-test-build.py','prepare-rf1124-test-build.first-failed.py','build-rf1124-theme-diagnostic-test.py',
    'prepare-rf1124-api31-boot.py','boot-rf1124-api31-host.py','rf1124-preparation-first-failure.json',
    'run-rf1124-theme-diagnostics.py','run-rf1124-theme-diagnostics.first-failed.py','stop-rf1124-owned-emulator.py',
    'verify-rf1124-source-and-checks.py','build-rf1124-theme-diagnostic-test-retry1.py','restore-rf1124-owned-external.py',
    'run-rf1124-theme-diagnostics-retry1.py','stop-rf1124-owned-emulator-retry1.py','verify-rf1124-final-source.py',
    'boot-rf1124-api35-host.py','prepare-rf1124-api35-retry.py','boot-rf1124-api35-host-retry1.py',
    'run-rf1124-theme-diagnostics-retry1-api35.py','stop-rf1124-owned-emulator-retry1-api35.py','archive-rf1124-theme-diagnostics.py']
for name in tools:entries['tools/'+name]=b/name
path='tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt'
entries['final-source/'+path]=r/path
entries['references/android-home-native-regression.py']=r/'tauri/scripts/android-home-native-regression.py'
entries['references/default-source-proof.json']=r/'build/rf121-theme-binding-20261010/rf1123-default-source-proof.json'
members=[];archive=dst/'raw.tar.gz'
with archive.open('xb') as out,tarfile.open(fileobj=out,mode='w:gz') as tf:
    for name,p in sorted(entries.items()):
        data=p.read_bytes();digest=hashlib.sha256(data).hexdigest();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tf.addfile(info,io.BytesIO(data))
        members.append(dict(path=name,size=len(data),sha256=digest))
with tarfile.open(archive,'r:gz') as tf:
    assert set(tf.getnames())==set(entries) and len(tf.getmembers())==len(members)
    for row in members:
        member=tf.getmember(row['path']);assert member.isfile() and not member.issym() and not member.islnk()
        data=tf.extractfile(member).read();assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']
index=dict(archiveSha256=sha(archive),members=members,allMembersReread=True,excluded=['APK','JNI','models','private TAR','previous external snapshots','base64 recovery payload'])
with (dst/'index.json').open('x',encoding='utf-8') as f:json.dump(index,f,indent=2)
record=dict(task='RF-1124',base=proof['base'],status='diagnostic-verification-complete',sourceCount=1837,
    checks=proof,artifacts=art['files'],observations=observations,sourcePath=path,finalSourceSha256=sha(r/path),
    nativeThemeTests=dict(api31Passed=0,api31Failed=2,api35Passed=2,api35Failed=0,skipped=0),
    faultBoundaryEstablished=True,uniqueRootCauseEstablished=False,productionBugFixed=False,
    originalFailuresRetained=True,driverExternalOwnerErrorRecovered=True,fullRF121Accepted=False,fullRF312Accepted=False,
    performanceAccepted=False,physicalDeviceAccepted=False,archive=dict(path=(dst/'raw.tar.gz').relative_to(r).as_posix(),sha256=sha(archive),members=len(members)),
    ledgerClosed=False,commitCreated=False,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    officialReference='https://developer.android.com/develop/ui/views/layout/webapps/dark-theme',
    inference='API31 native configuration and isLightTheme switch; provider91 WebView media remains light. API35/provider124 same APK passes. Legacy force-dark strategy and absent meta are candidates, not uniquely established causes.')
with (r/'docs/verification'/f'{stem}.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
print(json.dumps(dict(archiveSha256=sha(archive),members=len(members),observations=len(observations),allMembersVerified=True,productionBugFixed=False)))
