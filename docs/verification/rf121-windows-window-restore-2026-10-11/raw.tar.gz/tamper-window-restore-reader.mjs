import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {checkRestore} from './window-restore-contract.mjs';
const stage=new URL('./ss-rf121-composed-window-restore-baseline-caption-20261011/actual100/sample-001/',import.meta.url);
const raw=await readFile(new URL('rf121-wgc-minimize-restore-owned.json',stage));const proof=JSON.parse(raw);
const cap=JSON.parse(await readFile(new URL('rf121-wgc-light-visible.json',stage),'utf8'));
const context={runId:cap.runId,pid:cap.pid,creationMs:cap.creationMs,hwnd:cap.hwnd,windowRect:cap.windowRect,
  clientRect:cap.clientRect,dpi:cap.ownedWindowDpi,backdrop:cap.dwmSystemBackdropType};
assert(proof.captionActivation.attempted);checkRestore(proof,context);
const mutations=[
  ['minimization-never-observed',p=>p.minimizedObserved=false],
  ['restoration-not-foreground',p=>p.restoredVisibleNormalForeground=false],
  ['different-owned-process',p=>p.pid++],
  ['different-window',p=>p.hwnd++],
  ['different-run',p=>p.runId='0'.repeat(32)],
  ['different-birth',p=>p.creationMs++],
  ['changed-geometry-with-claimed-stable',p=>{p.before.windowRect[0]++;p.after.windowRect[0]++;}],
  ['changed-dpi-with-claimed-stable',p=>{p.before.dpi=144;p.after.dpi=144;}],
  ['changed-backdrop-with-claimed-stable',p=>{p.before.systemBackdrop.value=3;p.after.systemBackdrop.value=3;}],
  ['caption-hit-is-client',p=>p.captionActivation.nativeHitTest=1],
  ['caption-point-outside-owned-window',p=>p.captionActivation.pointScreen[0]=context.windowRect[0]-1],
  ['unexpected-input-count',p=>{p.inputEventsSent=4;p.captionActivation.inputEventsSent=4;}],
  ['cursor-not-restored',p=>p.captionActivation.cursorRestored=false],
  ['extra-release-recovery',p=>p.captionActivation.extraReleaseEventsSent=1],
  ['user-moved-cursor',p=>p.captionActivation.cursorMovedByUser=true],
  ['unbounded-duration',p=>p.elapsedMilliseconds=6000],
  ['foreign-window-modified',p=>p.otherWindowsModified=1],
  ['full-matrix-falsely-accepted',p=>p.fullMaterialMatrixAccepted=true],
];
const results=[];
for(const [name,mutate] of mutations){const changed=structuredClone(proof);mutate(changed);assert.throws(()=>checkRestore(changed,context));results.push({name,rejected:true});}
const result={originalActualProofAccepted:true,originalProofSha256:createHash('sha256').update(raw).digest('hex'),
  chosenSource:'One actual successful capture within a partial cohort; whole partial cohort remains rejected',nativeTestsSimulated:false,actualFilesModified:false,results,all18CorruptionsRejected:true};
await writeFile(new URL('./window-restore-caption-20261011/reader-tamper-proof.json',import.meta.url),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
process.stdout.write('Actual restore proof accepted; 18 event/identity/geometry/backdrop/input/cursor corruptions rejected\n');
