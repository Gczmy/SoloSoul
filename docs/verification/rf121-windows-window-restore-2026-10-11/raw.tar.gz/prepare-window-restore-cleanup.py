from pathlib import Path
import hashlib,json
w=Path(__file__).parent.resolve();s=w/'window-restore-caption-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
groups=[]
names=[('first-foreground-denials','ss-rf121-composed-window-restore-baseline-20261011'),
       ('partial-caption','ss-rf121-composed-window-restore-baseline-caption-20261011')]
names += [(mode,'ss-rf121-composed-window-restore-'+mode+'-caption-round2-20261011') for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']]
for label,name in names:
    c=w/name;receipt=load(c/'actual100.receipt.json');assert receipt['exitCode'] in (0,1) and receipt['sourceUnchanged'] and receipt['resourcesUnchanged']
    journey=load(c/'actual100/native-perf-sdk-journey-results.json');assert not journey['interrupted'] and len(journey['samples'])==3 and journey['sourceUnchanged']
    samples=[]
    for row in journey['samples']:
        root=c/'actual100'/f"sample-{row['index']:03}";owned=load(root/'native-perf-owned.json');consumed=load(root/'native-perf-consumed.json')
        assert owned==row['owned'] and owned['runId']==consumed['runId'] and consumed['pid']==row['processId']
        assert Path(owned['root']).samefile(root) and owned['identifier']=='com.solosoul.rf312perf.'+owned['runId']
        identities=[{'pid':p['pid'],'creationMs':p['creationMs']} for p in row.get('beforeSnapshot',{}).get('processes',[])+row.get('afterSnapshot',{}).get('processes',[])]
        assert len(identities)>=9 and all(type(p['pid']) is int and p['pid']>0 for p in identities)
        samples.append({'index':row['index'],'runId':owned['runId'],'pid':row['processId'],'recordedIdentities':identities,'originalJourneySuccess':row['success']})
    groups.append({'label':label,'captureRoot':str(c),'terminal':True,'samples':samples,'terminalReceiptSha256':sha(c/'actual100.receipt.json'),
        'originalJourneyAccepted':journey['success'],'cleanupOnlyNoAcceptance':True})
assert len(groups)==6
with (w/'window-restore-cache-cleanup-plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'cacheCleanupEligible':True,'failedSamplesAccepted':False,'groups':groups,'plannedExactCacheTargets':144,'freshCimRequired':True},f,indent=2)
text=(w/'rf1123-mixed-cleanup-owned.ps1').read_text(encoding='utf-8')
text=text.replace('rf1123-mixed-cache-cleanup','window-restore-cache-cleanup').replace('groups.Count -ne 4','groups.Count -ne 6').replace('Four terminal SDK-verified owned groups required for cleanup only','Six terminal owned groups required for cleanup only; failures are not accepted')
text=text.replace('targets.Count -ne 96','targets.Count -ne 144').replace('Count -ne 96','Count -ne 144').replace('Exact ninety-six owned cache paths required','Exact 144 owned cache paths required')
text=text.replace('application-logs-rf1123-mixed','application-logs-window-restore')
a="'D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\helper-target-readable\\debug\\rf121-owned-foreground-candidate.exe'"
b=a+",'D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\helper-target-readable\\debug\\rf121-owned-minimize-restore.exe','D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\helper-target-readable\\debug\\rf121-owned-caption-restore.exe','D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\helper-target-readable\\debug\\rf121-owned-caption-foreground.exe'"
assert text.count(a)==1;text=text.replace(a,b)
text=text.replace("Name = 'rf121-owned-foreground-candidate.exe'\"","Name = 'rf121-owned-foreground-candidate.exe' OR Name = 'rf121-owned-minimize-restore.exe' OR Name = 'rf121-owned-caption-restore.exe' OR Name = 'rf121-owned-caption-foreground.exe'\"")
with (w/'window-restore-cleanup-owned.ps1').open('x',encoding='utf-8',newline='\n') as f:f.write(text)
print('Six terminal groups, including retained failures, bound to 144 exact owned cache targets; fresh identity checks required before deletion')
