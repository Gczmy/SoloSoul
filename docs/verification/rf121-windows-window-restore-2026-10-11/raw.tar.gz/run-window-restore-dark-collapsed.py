from pathlib import Path
import datetime,json,os,subprocess,time
w=Path(__file__).parent.resolve();s=w/'window-restore-caption-20261011';r=Path('D:/SoloSoul')
def save(n,v):
    with (s/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2)
env=os.environ.copy();env.update(TEMP=str(s),TMP=str(s));env.pop('PDFIUM_LIBRARY_PATH',None)
def run(n,cmd):
    began=time.monotonic()
    with (s/(n+'.stdout.log')).open('xb') as out,(s/(n+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=r,env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
        save(n+'.live.json',dict(pid=p.pid,command=cmd));print(n,'PID',p.pid,flush=True);code=p.wait()
    save(n+'.receipt.json',dict(command=cmd,pid=p.pid,exitCode=code,elapsedSeconds=time.monotonic()-began));print(n,'terminal',code,flush=True);return code
probe=w/'window-restore-session-before-dark-collapsed.py'
text=(w/'window-restore-session-preflight.py').read_text(encoding='utf-8').replace('window-restore-retry1-20261011/session-before-restore.json','window-restore-caption-20261011/session-before-dark-collapsed.json')
with probe.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
assert run('session-dark-collapsed',['C:/Python314/python.exe',str(probe)])==0
session=json.loads((s/'session-before-dark-collapsed.json').read_text(encoding='utf-8'))
assert session['connectionState']==0 and session['inputDesktopAvailable']
capture=run('capture-dark-collapsed',['C:/Python314/python.exe',str(w/'run-window-restore-caption-round2.py'),'--dark-collapsed'])
reader=run('reader-dark-collapsed',['node',str(w/'verify-window-restore-caption-round2.mjs'),'--dark-collapsed'])
rendered=None
if capture==reader==0:rendered=run('renderer-dark-collapsed',['C:/Python314/python.exe',str(w/'render-window-restore-caption-round2.py'),'--dark-collapsed'])
save('cohort-dark-collapsed.json',dict(mode='dark-collapsed',captureExitCode=capture,readerExitCode=reader,rendererExitCode=rendered,
    priorDarkExpandedFailureRetained=True,fullRF121Accepted=False))
raise SystemExit(0 if capture==reader==rendered==0 else 1)
