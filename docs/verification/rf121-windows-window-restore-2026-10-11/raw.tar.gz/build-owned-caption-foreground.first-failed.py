from pathlib import Path
import hashlib,json,os,subprocess,time
w=Path(__file__).parent.resolve();s=w/'window-restore-caption-20261011';r=Path('D:/SoloSoul');h=s/'helper'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
restore=load(s/'restore-helper.json')
def verify():assert sha(Path(restore['exe']))==restore['sha256'] and sha(Path(restore['source']))==restore['sourceSha256']
verify();cache=r/'build/rf312-maintenance-20261009';env=os.environ.copy()
env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),CARGO_HOME=str(cache/'cargo-home'),CARGO_TARGET_DIR=str(w/'helper-target-readable'),CARGO_BUILD_JOBS='1')
for key in ['PDFIUM_LIBRARY_PATH','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:env.pop(key,None)
def save(n,v):
    with (s/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2)
def run(n,command):
    began=time.monotonic()
    with (s/(n+'.stdout.log')).open('xb') as out,(s/(n+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(command,cwd=h,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(n+'.live.json',dict(pid=p.pid,command=command));print(n,'PID',p.pid,flush=True);code=p.wait()
    verify();save(n+'.receipt.json',dict(pid=p.pid,command=command,exitCode=code,elapsedSeconds=time.monotonic()-began));assert code==0,n
run('activation-format',['rustfmt','--edition','2021','src/activate.rs'])
sources={n:sha(h/n) for n in ['Cargo.toml','Cargo.lock','src/activate.rs','src/restore.rs']};save('activation-sources.json',sources)
for name,verb in [('activation-tests','test'),('activation-clippy','clippy'),('activation-build','build')]:
    command=['cargo',verb,'--offline','--locked','--bin','rf121-owned-caption-foreground']
    if verb=='clippy':command+=['--','-D','warnings']
    run(name,command)
assert all(sha(h/n)==v for n,v in sources.items())
package=load(s/'runtime-package.json');exe=w/'helper-target-readable/debug/rf121-owned-caption-foreground.exe'
package.update(activationExe=str(exe),activationSha256=sha(exe),activationSource=str(h/'src/activate.rs'),activationSourceSha256=sha(h/'src/activate.rs'),activationScope='owned native caption with exact hit/identity guards')
save('caption-runtime-package.json',package)
print('New owned foreground companion passed six guards, strict Clippy and build; production GUI and capture/restore tools unchanged',flush=True)
