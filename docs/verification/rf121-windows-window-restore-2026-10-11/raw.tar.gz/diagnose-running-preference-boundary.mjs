import {readFile,readdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {validateObserver,ipcDelta} from '../../tauri/scripts/native-perf-run.mjs';
import {preferenceWriteDelta,correlatePreferenceInterval,checkPreferenceWrites} from '../../tauri/scripts/native-perf-preference-contract.mjs';
import assert from 'node:assert/strict';
const stage=new URL('./ss-rf121-composed-window-restore-dark-expanded-caption-round2-20261011/actual100/',import.meta.url);
const load=async p=>JSON.parse(await readFile(p,'utf8'));const rows=[];
for(const d of (await readdir(stage,{withFileTypes:true})).filter(x=>x.isDirectory()&&/^sample-\d{3}$/.test(x.name))){
  const base=new URL(d.name+'/',stage),own=await load(new URL('native-perf-owned.json',base));
  const bound=await load(new URL('native-perf-sdk-journey-bound.json',base)),identity={runId:own.runId,pid:bound.pid};
  const prep=await load(new URL('native-perf-surface-appearance-prepared.json',base)),restore=await load(new URL('native-perf-surface-appearance-restored.json',base));
  for(const [a,b] of [[prep.steps[1],prep.steps[2]],[restore.steps.at(-3),restore.steps.at(-2)]]){
    const front=ipcDelta(validateObserver(a.observer,own.runId),validateObserver(b.observer,own.runId));assert.equal(front.reason,null);
    const attempted=front.commands.find(x=>x.command==='user_data_update_preference')?.attempts??0;
    const delta=preferenceWriteDelta(a.preferenceWrites,b.preferenceWrites,identity);
    let strictAccepted=true;try{correlatePreferenceInterval(a.preferenceWrites,b.preferenceWrites,identity,attempted);}catch{strictAccepted=false;}
    const later=restore.steps.at(-1).preferenceWrites;checkPreferenceWrites(later,identity);
    // Read-only facts about the same IDs. This does not rewrite early running observations or accept the original interval.
    const resolved=delta.attempts.map(x=>{
      const found=later.attempts[x.id-1];assert(found);for(const k of ['id','kind','accountVerified','startedAtMs'])assert.deepEqual(found[k],x[k]);
      return {id:x.id,kind:x.kind,originalOutcome:x.outcome,laterOutcome:found.outcome,laterEndedAtMs:found.endedAtMs};
    });
    rows.push({sample:d.name,runId:own.runId,pid:bound.pid,from:a.action,to:b.action,frontendAttempts:attempted,
      originalAggregateAccepted:attempted===1,strictCorrelationAccepted:strictAccepted,backendDelta:delta,
      originalBoundaryAtMs:b.preferenceWrites.atMs,laterBoundaryAtMs:later.atMs,laterSameIdOutcomes:resolved});
  }
}
assert.equal(rows.length,6);const failed=rows.filter(x=>!x.strictCorrelationAccepted);assert.equal(failed.length,1);
assert.equal(failed[0].sample,'sample-002');assert.equal(failed[0].frontendAttempts,2);
assert.equal(failed[0].backendDelta.total,2);assert.equal(failed[0].backendDelta.theme,1);assert.equal(failed[0].backendDelta.backupReminder,1);
assert(failed[0].backendDelta.attempts.find(x=>x.kind==='theme').outcome==='completed');
assert(failed[0].backendDelta.attempts.find(x=>x.kind==='backup-reminder').outcome==='running');
assert(failed[0].laterSameIdOutcomes.every(x=>x.laterOutcome==='completed'));
const value={diagnosticComplete:true,originalAggregateAccepted:false,strictCorrelationAccepted:false,
  failedIntervalFactsVerified:true,nativeRunningObservationPreserved:true,originalNativeFramesUnmodified:true,
  fullRF121Accepted:false,rows};
await writeFile(new URL('./window-restore-caption-20261011/running-preference-boundary-diagnostic.json',import.meta.url),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
process.stdout.write('Actual second sample: one completed theme plus one running backup reminder; same reminder ID completes at a later native checkpoint. Original failures remain rejected.\n');
