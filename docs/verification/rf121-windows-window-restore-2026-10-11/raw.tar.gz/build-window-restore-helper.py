from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
w=Path(__file__).parent.resolve();r=Path('D:/SoloSoul');s=w/'window-restore-retry1-20261011';helper=s/'helper'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):
    with (s/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2)
cache=r/'build/rf312-maintenance-20261009';env=os.environ.copy()
env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),CARGO_HOME=str(cache/'cargo-home'),CARGO_TARGET_DIR=str(w/'helper-target-readable'),CARGO_BUILD_JOBS='1')
env.pop('PDFIUM_LIBRARY_PATH',None)
for key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:env.pop(key,None)
def run(n,cmd):
    began=time.monotonic()
    with (s/(n+'.stdout.log')).open('xb') as out,(s/(n+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=helper,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(n+'.live.json',{'pid':p.pid,'command':cmd});print(n,'PID',p.pid,flush=True);code=p.wait()
    save(n+'.receipt.json',{'command':cmd,'pid':p.pid,'exitCode':code,'elapsedSeconds':time.monotonic()-began})
    assert code==0,n
run('helper-format',['rustfmt','--edition','2021','src/restore.rs'])
sources={n:sha(helper/n) for n in ['src/restore.rs','Cargo.toml','Cargo.lock']};save('helper-sources.json',sources)
run('helper-tests',['cargo','test','--offline','--locked','--bin','rf121-owned-minimize-restore'])
run('helper-clippy',['cargo','clippy','--offline','--locked','--bin','rf121-owned-minimize-restore','--','-D','warnings'])
run('helper-build',['cargo','build','--offline','--locked','--bin','rf121-owned-minimize-restore'])
assert all(sha(helper/n)==h for n,h in sources.items())
binary=w/'helper-target-readable/debug/rf121-owned-minimize-restore.exe'
save('restore-helper.json',{'exe':str(binary),'sha256':sha(binary),'source':str(helper/'src/restore.rs'),
    'sourceSha256':sha(helper/'src/restore.rs'),'compileInputsUnchanged':True,'nativeApplicationExecuted':False,
    'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print('Owned minimize/restore helper checks and build passed; native application verification remains pending',flush=True)
