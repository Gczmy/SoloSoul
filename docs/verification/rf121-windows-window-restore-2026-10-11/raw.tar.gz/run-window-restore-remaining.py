from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
w=Path(__file__).parent.resolve();r=Path('D:/SoloSoul');s=w/'window-restore-caption-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):
    with (s/n).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2)
baseline=w/'ss-rf121-composed-window-restore-baseline-caption-round2-20261011'
assert load(baseline/'actual100.receipt.json')['exitCode']==0 and load(baseline/'capture-results.json')['success']
assert load(baseline/'validation.json')['accepted'] and len(load(baseline/'rendered-captures.json'))==3
rows=[{'mode':'baseline','captureExitCode':0,'readerExitCode':0,'rendererExitCode':0,
    'verification':str(baseline/'validation.json'),'verificationSha256':sha(baseline/'validation.json'),
    'baselineReaderAndRendererExitObservedFromExecCommand':True,'baselineNotReexecuted':True}]
sources=load(s/'sources.json');runtime=load(s/'caption-runtime-package.json');restore=load(s/'restore-helper.json')
def verify():
    for n,h in sources.items():assert sha(r/n)==h,n
    for key,hkey in [('exe','sha256'),('helperExe','helperSha256'),('activationExe','activationSha256'),('helperSource','helperSourceSha256'),('activationSource','activationSourceSha256')]:assert sha(Path(runtime[key]))==runtime[hkey]
    assert sha(Path(restore['exe']))==restore['sha256'] and sha(Path(restore['source']))==restore['sourceSha256']
verify();env=os.environ.copy();env.update(TEMP=str(s),TMP=str(s));env.pop('PDFIUM_LIBRARY_PATH',None)
def run(n,cmd):
    verify();began=time.monotonic()
    with (s/(n+'.stdout.log')).open('xb') as out,(s/(n+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=r,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(n+'.live.json',dict(pid=p.pid,command=cmd));print(n,'PID',p.pid,flush=True);code=p.wait()
    verify();save(n+'.receipt.json',dict(pid=p.pid,command=cmd,exitCode=code,elapsedSeconds=time.monotonic()-began));print(n,'terminal',code,flush=True);return code
for mode in ['light-collapsed','dark-expanded','dark-collapsed']:
    text=(w/'window-restore-session-preflight.py').read_text(encoding='utf-8').replace('window-restore-retry1-20261011/session-before-restore.json','window-restore-caption-20261011/session-before-'+mode+'.json')
    probe=w/('window-restore-session-before-'+mode+'.py')
    with probe.open('x',encoding='utf-8',newline='\n') as f:f.write(text)
    assert run('session-'+mode,['C:/Python314/python.exe',str(probe)])==0
    session=load(s/('session-before-'+mode+'.json'))
    if session.get('connectionState')!=0 or not session.get('inputDesktopAvailable'):raise RuntimeError('Caller desktop unavailable')
    capture=run('capture-'+mode,['C:/Python314/python.exe',str(w/'run-window-restore-caption-round2.py'),'--'+mode])
    reader=run('reader-'+mode,['node',str(w/'verify-window-restore-caption-round2.mjs'),'--'+mode])
    rendered=None
    if capture==reader==0:rendered=run('renderer-'+mode,['C:/Python314/python.exe',str(w/'render-window-restore-caption-round2.py'),'--'+mode])
    c=w/('ss-rf121-composed-window-restore-'+mode+'-caption-round2-20261011')
    row=dict(mode=mode,captureExitCode=capture,readerExitCode=reader,rendererExitCode=rendered,
        verification=str(c/'validation.json') if (c/'validation.json').is_file() else None,
        verificationSha256=sha(c/'validation.json') if (c/'validation.json').is_file() else None)
    rows.append(row);save('cohort-'+mode+'.json',row)
    if not capture==reader==rendered==0:break
accepted=len(rows)==4 and all(v['captureExitCode']==v['readerExitCode']==v['rendererExitCode']==0 for v in rows)
save('cohorts-complete.json',{'windowRestoreSubsetAccepted':accepted,'rows':rows,'fullRF121Accepted':False,
    'performanceAccepted':False,'sourcesUnchanged':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print('Four native restore cohorts accepted:',accepted,flush=True)
raise SystemExit(0 if accepted else 1)
