import hashlib, json, tarfile, io, shutil, os
from pathlib import Path
R = Path('D:/SoloSoul')
W = R/'build/rf121-theme-binding-20261010'
S = W/'window-restore-caption-20261011'
NAME = 'rf121-windows-window-restore-2026-10-11'
OUT = R/'docs/verification'/NAME
if OUT.exists():
 assert {p.name for p in OUT.iterdir()}=={'baseline.png','light-collapsed.png','dark-expanded.png','dark-collapsed.png'}
else: OUT.mkdir()
def sha(data): return hashlib.sha256(data).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def put(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
cleanup=read(W/'window-restore-cache-cleanup.json')
assert cleanup['matchingOwnedIdentitiesLive']==0 and cleanup['processesTerminatedByThisTool']==0
assert len(cleanup['removedCachePaths'])==144 and cleanup['preservedBytesVerified']
for p in cleanup['removedCachePaths']: assert not os.path.lexists(p)
groups=[('baseline','ss-rf121-composed-window-restore-baseline-20261011'),
 ('baseline-caption','ss-rf121-composed-window-restore-baseline-caption-20261011')]
groups += [(m,f'ss-rf121-composed-window-restore-{m}-caption-round2-20261011') for m in ['baseline','light-collapsed','dark-expanded','dark-collapsed']]
visual=[]; results=[]
for m,n in groups[2:]:
 g=W/n; assert read(g/'actual100.receipt.json')['exitCode']==0
 capture=read(g/'capture-results.json'); assert capture['success']
 if m.startswith('dark'):
  endpoint=read(g/'restoration-endpoints.json')
  assert endpoint['accepted']==False and endpoint['windowRestorationEndpointBindingVerified']
  primary=1
 else:
  endpoint=read(g/'validation.json'); assert endpoint['accepted']; primary=0
 assert len(endpoint['samples'])==3
 results.append({'scene':m,'samples':3,'nativeCaptureExitCode':0,'primaryReaderExitCode':primary,
 'endpointBindingVerified':True,'aggregateAppearanceAccepted':primary==0,
 'proof':f'{n}/'+('restoration-endpoints.json' if primary else 'validation.json')})
 p=g/'surface-sample-001.png'; data=p.read_bytes()
 shutil.copyfile(p,OUT/(m+'.png'))
 visual.append({'scene':m,'source':str(p),'sha256':sha(data),'humanReviewed':True,
 'observation':'首页文案、卡片及导航可见，最终帧未空白；仅审阅恢复后端点，不证明过渡无闪烁。'})
put(S/'visual-review.json',{'reviewedFrames':4,'otherFramesHumanReviewed':False,'frames':visual,'fullMaterialMatrixAccepted':False})
members={}
allowed={'.json','.log','.bgra','.png','.py','.mjs','.ps1','.rs','.toml','.lock'}
def add(p, label=None):
 assert p.is_file() and not p.is_symlink() and not (p.stat().st_file_attributes & 0x400)
 assert p.suffix in allowed
 name=label or p.relative_to(W).as_posix()
 if name in members:
  assert members[name]==p
  return
 members[name]=p
def files(d):
 assert d.is_dir() and not (d.stat().st_file_attributes & 0x400)
 for p in d.iterdir():
  if p.is_file() and p.suffix in allowed: add(p)
for m,n in groups:
 g=W/n; files(g); files(g/'actual100')
 for i in range(1,4): files(g/'actual100'/f'sample-{i:03}')
for d in ['window-restore-retry1-20261011','window-restore-caption-20261011']:
 files(W/d)
 for sub in ['helper','helper/src']: files(W/d/sub)
for p in W.iterdir():
 if p.is_file() and p.suffix in allowed and any(t in p.name for t in ['window-restore','owned-caption-foreground','running-preference-boundary']): add(p)
for d in ['helper-backdrop-reader-candidate-20261011','helper-backdrop-reader-candidate-20261011/src']: files(W/d)
for n in ['sources.json','runtime-package.json']:
 add(W/'rf1123-native-build-20261011'/n)
for m,n in groups:
 for i in range(1,4):
  d=W/'application-logs-window-restore'/m/'100'/f'sample-{i:03}'
  if d.exists(): files(d)
for n in ['native-perf-sdk-journey.mjs','native-perf-auth-contract.mjs','native-perf-maintenance-contract.mjs','native-perf-preference-contract.mjs','native-perf-run.mjs']:
 add(R/'tauri/scripts'/n,'repository/tauri/scripts/'+n)
add(Path(__file__))
index=[]
with tarfile.open(OUT/'raw.tar.gz','w:gz',compresslevel=6) as tar:
 for name,p in sorted(members.items()):
  data=p.read_bytes(); info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  tar.addfile(info,io.BytesIO(data));index.append({'member':name,'source':str(p),'bytes':len(data),'sha256':sha(data)})
with tarfile.open(OUT/'raw.tar.gz','r:gz') as tar:
 assert len(tar.getmembers())==len(index)
 for row in index:
  data=tar.extractfile(row['member']).read();assert len(data)==row['bytes'] and sha(data)==row['sha256']
put(OUT/'index.json',{'task':'RF-121','members':index,'allMembersReadbackVerified':True,
 'excluded':['physical Vault contents','EXE/DLL/APK/JNI','models','WebView/profile/cache directories'],
 'originalFailedObservationsRetained':True,'fullRF121Accepted':False})
shutil.copyfile(W/'window-restore-cache-cleanup.json',OUT/'cleanup.json')
(OUT/'.gitattributes').write_text('raw.tar.gz -text\n*.png -text\n',encoding='utf-8')
summary={'task':'RF-121','accepted':False,'status':'partial-window-restoration-endpoints; aggregate-dark-gate-rejected',
 'sourceHead':'63f66d8abb16f005152db361226eed84e63be1b1','productionCodeChanged':False,
 'windowsGuiReused':True,'guiSha256':'d77e575287c7d18f6124a7aa42cfa56f0ba20625d8b00309c1e7d2c07355da74',
 'sourceFiles':1837,'resourceFiles':94,'sourceDifferencesFromBuild':['Android MainActivity.kt','AndroidThemeInstrumentedTest.kt'],
 'dpi':96,'nativeEndpointCaptures':12,'aggregateAppearancePassed':6,'aggregateAppearanceFailedSamplesInRejectedGroups':6,
 'groups':results,'earlierRejectedCohortsRetained':[n for m,n in groups[:2]],
 'themeWriteFinding':'dark-expanded sample002 has one completed theme and one running backup-reminder at original checkpoint; same reminder ID completed at later native checkpoint',
 'originalStrictCorrelationAccepted':False,'originalRunningObservationUnmodified':True,
 'restoreGuardTamperCasesRejected':18,'helperExistingTestsExecuted':18,'helperUniqueGuardTests':6,
 'visualReview':visual,'otherEightFramesHumanReviewed':False,
 'nativeGetter':{'attribute':38,'SystemBackdropType':2,'stable':True,'fullMaterialAccepted':False},
 'cleanup':{'pathsRemoved':144,'liveOwnedIdentities':0,'processesTerminated':0,'preservedBytesVerified':True},
 'userApplicationControlled':False,'transientFlickerVerified':False,'scalingAccessibilityOtherPlatformsAccepted':False,
 'performanceAccepted':False,'fullRF121Accepted':False,'nextTask':'RF-1127',
 'archive':{'path':NAME+'/raw.tar.gz','members':len(index),'bytes':(OUT/'raw.tar.gz').stat().st_size,'sha256':sha((OUT/'raw.tar.gz').read_bytes()),'allMembersReadbackVerified':True},
 'ledgerClosed':False,'commitCreated':False}
put(R/'docs/verification'/(NAME+'.json'),summary)
print(json.dumps({'members':len(index),'archiveBytes':summary['archive']['bytes'],'captures':12,'fullAccepted':False}))
