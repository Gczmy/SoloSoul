from pathlib import Path
import ast,json,shutil
w=Path(__file__).parent.resolve();old=w/'window-restore-retry1-20261011';s=w/'window-restore-caption-20261011';s.mkdir(exist_ok=False)
(s/'helper/src').mkdir(parents=True)
for n in ['sources.json','runtime-package.json','windows-build-reuse-proof.json']:shutil.copy2(old/n,s/n)
shutil.copy2(old/'helper/Cargo.lock',s/'helper/Cargo.lock')
manifest=(old/'helper/Cargo.toml').read_text(encoding='utf-8').replace('"Win32_UI_HiDpi"','"Win32_UI_HiDpi", "Win32_UI_Input_KeyboardAndMouse"').replace('rf121-owned-minimize-restore','rf121-owned-caption-restore')
(s/'helper/Cargo.toml').write_text(manifest,encoding='utf-8',newline='\n')
src=(old/'helper/src/restore.rs').read_text(encoding='utf-8')
def once(a,b):
    global src
    assert src.count(a)==1,a
    src=src.replace(a,b)
once('    core::{factory, Interface, BOOL, PWSTR},','    core::{factory, Interface, BOOL, PWSTR},')
insert='''use windows::Win32::Foundation::WPARAM;
use windows::Win32::UI::Input::KeyboardAndMouse::{SendInput,INPUT,INPUT_0,INPUT_MOUSE,MOUSEINPUT,MOUSEEVENTF_LEFTDOWN,MOUSEEVENTF_LEFTUP};
use windows::Win32::UI::WindowsAndMessaging::{GetCursorPos,SetCursorPos,SetWindowPos,WindowFromPoint,SendMessageTimeoutW,HTCAPTION,SMTO_ABORTIFHUNG,HWND_TOP,SWP_NOMOVE,SWP_NOSIZE,SWP_NOACTIVATE,WM_NCHITTEST};
'''
src=insert+src
anchor='        let restored = verify_hwnd(hwnd, pid).is_ok()'
assert src.count(anchor)==1
branch='''        let mut caption = json!({"attempted":false,"inputEventsSent":0,"extraReleaseEventsSent":0,"cursorRestored":null,"error":null});
        if unsafe { GetForegroundWindow() } != hwnd {
            caption["attempted"] = json!(true);
            let caption_result: Outcome<()> = (|| {
                verify_process(handle.0,&exe,birth_ms)?;
                verify_hwnd(hwnd,pid)?;
                // Raise only this owned HWND, without activation, so the real hit test can safely refuse any overlap.
                unsafe { SetWindowPos(hwnd,Some(HWND_TOP),0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE)?; }
                let mut outer = RECT::default();
                unsafe { GetWindowRect(hwnd,&mut outer)?; }
                require(outer.right-outer.left>200 && outer.bottom-outer.top>50,"bounded-caption-window-required")?;
                let point = POINT {x:outer.left+(outer.right-outer.left)/2,y:outer.top+18};
                let packed = LPARAM((((point.x as u32)&0xffff)|(((point.y as u32)&0xffff)<<16)) as isize);
                let hit = || -> Outcome<usize> {
                    verify_process(handle.0,&exe,birth_ms)?;
                    verify_hwnd(hwnd,pid)?;
                    require(unsafe { WindowFromPoint(point) }==hwnd,"caption-point-hits-other-window")?;
                    let mut value=0usize;
                    let result=unsafe { SendMessageTimeoutW(hwnd,WM_NCHITTEST,WPARAM(0),packed,SMTO_ABORTIFHUNG,100,Some(&mut value)) };
                    require(result.0!=0 && value==HTCAPTION as usize,"real-native-caption-hit-required")?;
                    Ok(value)
                };
                caption["nativeHitTest"] = json!(hit()?);
                caption["pointScreen"] = json!([point.x,point.y]);
                let mut original = POINT::default();
                unsafe { GetCursorPos(&mut original)?; SetCursorPos(point.x,point.y)?; }
                let input_result: Outcome<()> = (|| {
                    hit()?;
                    let make = |flags| INPUT {r#type:INPUT_MOUSE,Anonymous:INPUT_0 {mi:MOUSEINPUT {dwFlags:flags,..Default::default()}}};
                    let events=[make(MOUSEEVENTF_LEFTDOWN),make(MOUSEEVENTF_LEFTUP)];
                    let sent=unsafe { SendInput(&events,std::mem::size_of::<INPUT>() as i32) };
                    caption["inputEventsSent"] = json!(sent);
                    if sent==1 {
                        let released=unsafe { SendInput(&[make(MOUSEEVENTF_LEFTUP)],std::mem::size_of::<INPUT>() as i32) };
                        caption["extraReleaseEventsSent"] = json!(released);
                    }
                    require(sent==2,"caption-input-not-fully-inserted")?;
                    let wait=Instant::now();
                    while unsafe { GetForegroundWindow() }!=hwnd && wait.elapsed()<Duration::from_secs(1) {
                        verify_process(handle.0,&exe,birth_ms)?;
                        verify_hwnd(hwnd,pid)?;
                        std::thread::sleep(Duration::from_millis(10));
                    }
                    require(unsafe { GetForegroundWindow() }==hwnd,"owned-caption-did-not-activate")
                })();
                let mut actual=POINT::default();
                unsafe { GetCursorPos(&mut actual)?; }
                let cursor_untouched = actual.x==point.x && actual.y==point.y;
                caption["cursorMovedByUser"] = json!(!cursor_untouched);
                if cursor_untouched {
                    let restored_cursor=unsafe { SetCursorPos(original.x,original.y) }.is_ok();
                    caption["cursorRestored"] = json!(restored_cursor);
                    require(restored_cursor,"own-caption-cursor-restoration-failed")?;
                }
                input_result
            })();
            if let Err(error)=caption_result {caption["error"]=json!(error.to_string());}
        }
'''
src=src.replace(anchor,branch+anchor)
once('"pixelsRead":0,"inputEventsSent":0,"systemSettingsChanged":false,"otherWindowsModified":0,','"pixelsRead":0,"inputEventsSent":caption["inputEventsSent"],"captionActivation":caption,"systemSettingsChanged":false,"otherWindowsModified":0,')
(s/'helper/src/restore.rs').write_text(src,encoding='utf-8',newline='\n')
build=(w/'build-window-restore-helper.py').read_text(encoding='utf-8').replace('window-restore-retry1-20261011','window-restore-caption-20261011').replace('rf121-owned-minimize-restore','rf121-owned-caption-restore')
ast.parse(build)
with (w/'build-window-restore-caption-helper.py').open('x',encoding='utf-8',newline='\n') as f:f.write(build)
driver=(w/'run-window-restore.py').read_text(encoding='utf-8').replace('window-restore-retry1-20261011','window-restore-caption-20261011').replace("'-20261011')","'-caption-20261011')")
anchor="                assert restore_proof['pixelsRead']==restore_proof['inputEventsSent']==restore_proof['otherWindowsModified']==0"
assert driver.count(anchor)==1
driver=driver.replace(anchor,"""                assert restore_proof['pixelsRead']==restore_proof['otherWindowsModified']==0
                caption=restore_proof['captionActivation']; assert caption['error'] is None
                assert restore_proof['inputEventsSent']==caption['inputEventsSent'] in (0,2)
                assert caption['extraReleaseEventsSent']==0
                if caption['attempted']: assert caption['nativeHitTest']==2 and caption['inputEventsSent']==2 and caption['cursorRestored'] and not caption['cursorMovedByUser']
""")
ast.parse(driver)
with (w/'run-window-restore-caption.py').open('x',encoding='utf-8',newline='\n') as f:f.write(driver)
print('Guarded caption fallback prepared: held PID/birth/EXE, same HWND, actual WindowFromPoint+HTCAPTION twice, two mouse events only, cursor restore, foreign overlap refused')
