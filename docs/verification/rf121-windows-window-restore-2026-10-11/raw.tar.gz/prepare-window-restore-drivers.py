from pathlib import Path
import ast,hashlib,json,subprocess
w=Path(__file__).parent.resolve();s=w/'window-restore-retry1-20261011'
def write(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:f.write(v)
origin=(w/'run-rf1123-backdrop.py').read_text(encoding='utf-8')
text=origin.replace("('ss-rf121-composed-window-backdrop-' + mode + '-rf1123-20261011')","('ss-rf121-composed-window-restore-' + mode + '-20261011')")
text=text.replace("'rf1123-native-build-20261011/runtime-package.json'","'window-restore-retry1-20261011/runtime-package.json'").replace("'rf1123-native-build-20261011/sources.json'","'window-restore-retry1-20261011/sources.json'")
anchor="activation_helper = Path(package['activationExe'])"
assert text.count(anchor)==1
text=text.replace(anchor,anchor+"\nrestore_package = load(stage / 'window-restore-retry1-20261011/restore-helper.json')\nrestore_helper = Path(restore_package['exe'])")
anchor="def verify_inputs():\n"
assert text.count(anchor)==1
text=text.replace(anchor,anchor+"    assert sha(restore_helper) == restore_package['sha256']\n    assert sha(Path(restore_package['source'])) == restore_package['sourceSha256']\n")
anchor="                capture_began = time.monotonic()"
assert text.count(anchor)==1
branch='''                restore_args = [str(restore_helper),str(sample),str(pid),str(owner['creationMs']),str(exe),'minimize-restore-owned']
                restore_began = time.monotonic()
                lifecycle = subprocess.run(restore_args,cwd=stage,env=env,capture_output=True,
                                           creationflags=subprocess.CREATE_NO_WINDOW,timeout=6)
                for name,data in [('stdout',lifecycle.stdout),('stderr',lifecycle.stderr)]:
                    with (sample / ('surface-minimize-restore.'+name+'.log')).open('xb') as log:log.write(data)
                save(sample / 'surface-minimize-restore.receipt.json',{'command':restore_args,'exitCode':lifecycle.returncode,
                    'elapsedSeconds':time.monotonic()-restore_began,'originalSurfaceBudgetUnchanged':True})
                assert lifecycle.returncode == 0,lifecycle.stderr.decode('utf-8',errors='replace')
                restore_proof = ordinary(sample / 'rf121-wgc-minimize-restore-owned.json',262144)
                assert restore_proof == json.loads(lifecycle.stdout.decode('utf-8-sig'))
                assert restore_proof['schemaVersion']==1 and restore_proof['scope']=='rf121-owned-window-minimize-restore'
                assert restore_proof['runId']==run_id and restore_proof['pid']==pid and restore_proof['creationMs']==owner['creationMs']
                assert restore_proof['hwnd']==foreground['hwnd'] and restore_proof['tag']=='minimize-restore-owned'
                assert restore_proof['minimizedObserved'] and restore_proof['minimizeError'] is None
                assert restore_proof['restoredVisibleNormalForeground'] and restore_proof['heldProcessAndWindowIdentityVerifiedBeforeAndAfter']
                assert restore_proof['geometryAndDpiPreserved'] and restore_proof['stylesPreserved'] and restore_proof['backdropPreserved']
                assert restore_proof['before']==restore_proof['after']
                assert restore_proof['before']['systemBackdrop']['ok'] and restore_proof['before']['systemBackdrop']['value']==(2 if state['material']=='mica' else 1)
                assert restore_proof['pixelsRead']==restore_proof['inputEventsSent']==restore_proof['otherWindowsModified']==0
                assert restore_proof['systemSettingsChanged'] is False and restore_proof['fullMaterialMatrixAccepted'] is False
'''
text=text.replace(anchor,branch+anchor)
ast.parse(text);write(w/'run-window-restore.py',text)
for origin_name,name in [('verify-rf1123-backdrop.mjs','verify-window-restore.mjs'),('render-rf1123-backdrop.py','render-window-restore.py')]:
    text=(w/origin_name).read_text(encoding='utf-8').replace('ss-rf121-composed-window-backdrop-','ss-rf121-composed-window-restore-').replace('-rf1123-20261011','-20261011').replace('rf1123-native-build-20261011','window-restore-retry1-20261011')
    if name.endswith('.py'):ast.parse(text)
    write(w/name,text)
    if name.endswith('.mjs'):subprocess.run(['node','--check',str(w/name)],check=True,capture_output=True)
text=(w/'rf1123-backdrop-session-before-baseline.py').read_text(encoding='utf-8').replace("rf1123-native-build-20261011/session-before-baseline.json","window-restore-retry1-20261011/session-before-restore.json")
ast.parse(text);write(w/'window-restore-session-preflight.py',text)
print('Native lifecycle inserted between existing bound DOM snapshot and WGC; original 10-second capture budget and all original guards retained')
