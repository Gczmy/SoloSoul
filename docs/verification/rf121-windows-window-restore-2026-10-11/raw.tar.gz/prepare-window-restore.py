from pathlib import Path
import ast,datetime,hashlib,json,shutil
w=Path(__file__).parent.resolve();r=Path('D:/SoloSoul')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stage=w/'window-restore-retry1-20261011';stage.mkdir(exist_ok=False)
helper=stage/'helper';(helper/'src').mkdir(parents=True)
origin=w/'helper-backdrop-reader-candidate-20261011'
source=(origin/'src/activate.rs').read_text(encoding='utf-8')
def once(a,b):
    global source
    assert source.count(a)==1,a
    source=source.replace(a,b)
once('SetForegroundWindow, GA_ROOTOWNER,','SetForegroundWindow, ShowWindow, IsZoomed, SW_MINIMIZE, SW_RESTORE, GA_ROOTOWNER,')
once('            "activate-owned",','            "minimize-restore-owned",')
once('tag == "activate-owned",','tag == "minimize-restore-owned",')
once('"only-owned-foreground-activation-tag-allowed",','"only-owned-minimize-restore-tag-allowed",')
start=source.index('    if tag == "activate-owned" {')
end=source.index('    let (mut outer, mut client, mut bounds)',start)
branch='''    if tag == "minimize-restore-owned" {
        verify_process(handle.0, &exe, birth_ms)?;
        verify_hwnd(hwnd, pid)?;
        require(unsafe { GetForegroundWindow() } == hwnd, "owned-window-must-start-foreground")?;
        require(!unsafe { IsZoomed(hwnd) }.as_bool(), "only-initial-normal-window-allowed")?;
        let (mut before_outer, mut before_client) = (RECT::default(), RECT::default());
        unsafe { GetWindowRect(hwnd,&mut before_outer)?; GetClientRect(hwnd,&mut before_client)?; }
        let dpi = unsafe { GetDpiForWindow(hwnd) };
        require(dpi > 0,"owned-window-dpi-required")?;
        let backdrop_before = read_system_backdrop(hwnd)?;
        require(backdrop_before["ok"] == true,"documented-backdrop-getter-required")?;
        let began = Instant::now();
        let minimized_api = unsafe { ShowWindow(hwnd, SW_MINIMIZE) }.as_bool();
        let mut minimized_observed = false;
        let minimized_result: Outcome<()> = (|| {
            while began.elapsed() < Duration::from_secs(1) {
                verify_process(handle.0, &exe, birth_ms)?;
                let mut actual = 0;
                unsafe { GetWindowThreadProcessId(hwnd,Some(&mut actual)); }
                require(actual == pid,"held-window-owner-changed")?;
                if unsafe { IsIconic(hwnd) }.as_bool() {
                    minimized_observed = true;
                    // Keep one real minimized interval; no page state or synthetic lifecycle events.
                    std::thread::sleep(Duration::from_millis(150));
                    return Ok(());
                }
                std::thread::sleep(Duration::from_millis(10));
            }
            Err("owned-window-did-not-minimize".into())
        })();
        // Always attempt to restore the same held owned HWND, including a failed minimize observation.
        verify_process(handle.0, &exe, birth_ms)?;
        let mut actual = 0;
        unsafe { GetWindowThreadProcessId(hwnd,Some(&mut actual)); }
        require(actual == pid,"held-window-owner-changed-before-restore")?;
        let restore_api = unsafe { ShowWindow(hwnd, SW_RESTORE) }.as_bool();
        let foreground_api = unsafe { SetForegroundWindow(hwnd) }.as_bool();
        let restore_began = Instant::now();
        while restore_began.elapsed() < Duration::from_secs(2) {
            verify_process(handle.0, &exe, birth_ms)?;
            let mut actual = 0;
            unsafe { GetWindowThreadProcessId(hwnd,Some(&mut actual)); }
            require(actual == pid,"held-window-owner-changed-after-restore")?;
            if !unsafe { IsIconic(hwnd) }.as_bool() && unsafe { GetForegroundWindow() } == hwnd { break; }
            std::thread::sleep(Duration::from_millis(10));
        }
        let restored = verify_hwnd(hwnd,pid).is_ok() && unsafe { GetForegroundWindow() } == hwnd && !unsafe { IsZoomed(hwnd) }.as_bool();
        let (mut after_outer,mut after_client) = (RECT::default(),RECT::default());
        unsafe { GetWindowRect(hwnd,&mut after_outer)?; GetClientRect(hwnd,&mut after_client)?; }
        let dpi_after = unsafe { GetDpiForWindow(hwnd) };
        let backdrop_after = read_system_backdrop(hwnd)?;
        verify_process(handle.0, &exe, birth_ms)?;
        let geometry_same = rect(before_outer)==rect(after_outer) && rect(before_client)==rect(after_client) && dpi==dpi_after;
        let styles_same = unsafe { GetWindowLongPtrW(hwnd,GWL_STYLE) }==selected_style && unsafe { GetWindowLongPtrW(hwnd,GWL_EXSTYLE) }==selected_ex_style;
        let backdrop_same = backdrop_before == backdrop_after;
        let proof = json!({"schemaVersion":1,"scope":"rf121-owned-window-minimize-restore","runId":run,"pid":pid,"creationMs":birth_ms,"hwnd":hwnd.0 as usize,"tag":tag,
            "minimizedObserved":minimized_observed,"minimizeError":minimized_result.as_ref().err().map(|e|e.to_string()),"restoredVisibleNormalForeground":restored,
            "minimizeApiReturnedPreviousVisibility":minimized_api,"restoreApiReturnedPreviousVisibility":restore_api,"foregroundApiReturned":foreground_api,
            "before":{"windowRect":rect(before_outer),"clientRect":rect(before_client),"dpi":dpi,"systemBackdrop":backdrop_before},
            "after":{"windowRect":rect(after_outer),"clientRect":rect(after_client),"dpi":dpi_after,"systemBackdrop":backdrop_after},
            "geometryAndDpiPreserved":geometry_same,"stylesPreserved":styles_same,"backdropPreserved":backdrop_same,
            "elapsedMilliseconds":began.elapsed().as_secs_f64()*1000.0,"heldProcessAndWindowIdentityVerifiedBeforeAndAfter":true,
            "pixelsRead":0,"inputEventsSent":0,"systemSettingsChanged":false,"otherWindowsModified":0,"fullMaterialMatrixAccepted":false});
        save_new(&json_path,&serde_json::to_vec_pretty(&proof)?)?;
        println!("{}",proof);
        minimized_result?;
        require(restored && geometry_same && styles_same && backdrop_same,"owned-window-restoration-incomplete")?;
        return Ok(());
    }
'''
source=source[:start]+branch+source[end:]
(helper/'src/restore.rs').write_text(source,encoding='utf-8',newline='\n')
manifest=(origin/'Cargo.toml').read_text(encoding='utf-8').split('[[bin]]')[0]
manifest+='[[bin]]\nname = "rf121-owned-minimize-restore"\npath = "src/restore.rs"\n'
(helper/'Cargo.toml').write_text(manifest,encoding='utf-8',newline='\n')
shutil.copy2(origin/'Cargo.lock',helper/'Cargo.lock')
original=w/'rf1123-native-build-20261011';sources=load(original/'sources.json');changed=[]
for n,h in sources.items():
    if sha(r/n)!=h:changed.append(n)
allowed=['tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt','tauri/src-tauri/gen/android/app/src/main/java/com/solosoul/app/MainActivity.kt']
assert sorted(changed)==sorted(allowed)
current={n:sha(r/n) for n in sources}
assert len(current)==1837
def save(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2)
save(stage/'sources.json',current)
package=load(original/'runtime-package.json')
for key,hkey in [('exe','sha256'),('helperExe','helperSha256'),('activationExe','activationSha256')]:assert sha(Path(package[key]))==package[hkey]
for row in package['resources']:assert sha(Path(row['copy']))==sha(Path(row['source']))==row['sha256']
save(stage/'runtime-package.json',package)
save(stage/'windows-build-reuse-proof.json',{'originalManifest':str(original/'sources.json'),'originalManifestSha256':sha(original/'sources.json'),
    'currentManifest':str(stage/'sources.json'),'currentManifestSha256':sha(stage/'sources.json'),'allWindowsInputsUnchanged':True,
    'exactDifferences':[{'path':n,'originalSha256':sources[n],'currentSha256':current[n],'platform':'Android only'} for n in allowed],
    'windowsBuildReused':True,'windowsRecompiled':False,'originalGuiSha256':package['sha256'],'currentHead':'63f66d8abb16f005152db361226eed84e63be1b1',
    'nativeMaterialAccepted':False,'foreignApplicationWillNotBeControlled':True})
print('Standalone owned minimize/restore helper prepared; Windows build reuse bound to exactly two Android-only differences')
