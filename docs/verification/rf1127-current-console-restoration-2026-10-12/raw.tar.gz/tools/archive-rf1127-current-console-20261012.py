from pathlib import Path
import datetime,hashlib,io,json,tarfile
R=Path('D:/SoloSoul');W=Path(__file__).parent
N='rf1127-current-console-restoration-2026-10-12';O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
B=W/'rf1127-current-skill-build-20261012';sources=load(B/'sources.json')
assert len(sources)==1843 and all(sha(R/n)==h for n,h in sources.items())
assert load(B/'build.receipt.json')['exitCode']==0
assert load(B/'native-test-counts.json')=={'passed':137,'failed':0,'ignored':0,'currentSources':True}
assert load(B/'manifest-newline-parity.json')['normalizedBytesEqual']
assert load(B/'dist-input-stability.json')['allGeneratedFrontendInputsUnchangedDuringRustBuild']
package=load(B/'runtime-package.json');assert sha(Path(package['exe']))==package['sha256']
members={};rounds=[]
for flavor in ['current-skill','current-hitmeta']:
 M=W/f'rf1127-{flavor}-matrix-20261012';C=W/f'ss-rf121-composed-window-restore-baseline-{flavor}-20261012'
 matrix=load(M/'cohorts-complete.json');assert not matrix['accepted'] and len(matrix['rows'])==1
 receipt=load(C/'actual100.receipt.json');assert receipt['exitCode']==1 and all(receipt[k] for k in ['sourceUnchanged','resourcesUnchanged','originalFixtureUnchanged'])
 journey=load(C/'actual100/native-perf-sdk-journey-results.json');assert not journey['interrupted'] and len(journey['samples'])==3 and all(row['cleanupIntegrity']['complete'] for row in journey['samples'])
 capture=load(C/'capture-results.json');assert len(capture['samples'])==3
 cleanup=load(W/f'rf1127-{flavor}-cache-cleanup.json')
 assert cleanup['preservedBytesVerified'] and cleanup['identitiesChecked']==27 and cleanup['processesTerminatedByThisTool']==0
 assert len(cleanup['removedCachePaths'])==24 and len(cleanup['linksUnlinked'])==3
 assert all(not Path(p).exists() for p in cleanup['removedCachePaths'])
 for row in cleanup['preservedVaultAndRootFiles']:assert sha(Path(row['path']))==row['sha256']
 rounds.append({'flavor':flavor,'requestedCohorts':4,'executedCohorts':1,'samplesRequested':3,
  'wholeMatrixAccepted':False,'captureAccepted':sum(x['success'] for x in capture['samples']),
  'sdkJourneysPassed':sum(x['success'] for x in journey['samples']),
  'captureFailures':[{'index':x['index'],'error':x.get('error')} for x in capture['samples'] if not x['success']],
  'readerRuns':0,'rendererRuns':0,'cleanup':{k:len(v) if isinstance(v,list) else v for k,v in cleanup.items()}})
 for p in M.iterdir():
  if p.is_file():members[flavor+'/matrix/'+p.name]=p
 excluded={'vault','app-data','profile','webview','temp','models','plugins'}
 for p in C.rglob('*'):
  rel=p.relative_to(C)
  if any(x in excluded for x in rel.parts):continue
  if p.is_file() and p.suffix in ['.json','.log','.bgra']:members[flavor+'/capture/'+rel.as_posix()]=p
 logroot=W/f'application-logs-rf1127-{flavor}'
 for p in logroot.rglob('*'):
  if p.is_file():members[flavor+'/application-logs/'+p.relative_to(logroot).as_posix()]=p
 for p in W.glob(f'*rf1127-{flavor}*'):
  if p.is_file():members['tools/'+p.name]=p
 for p in W.glob(f'*rf1127-{"current" if flavor=="current-skill" else "hitmeta"}-terminal-cleanup-20261012.py'):
  members['tools/'+p.name]=p
first=load(W/'ss-rf121-composed-window-restore-baseline-current-hitmeta-20261012/actual100/sample-001/rf121-wgc-minimize-restore-owned.json')
refused=first['captionActivation']['refusedHitMetadata']
assert refused['hit']['pid']==17856 and not refused['hitRootEqualsTarget'] and refused['inputEventsSentByDiagnostic']==refused['pixelsRead']==0
process=load(W/'rf1127-current-hitmeta-matrix-20261012/recorded-hit-process-readonly.json')
assert process['recordedHitPid']==17856 and process['process']['Name']=='ChatGPT.exe'
assert 'OpenAI.Codex_' in process['process']['ExecutablePath']
for p in B.iterdir():
 if p.is_file():members['build/'+p.name]=p
for n in ['build-rf1127-current-skill-native-20261012.py','freeze-rf1127-current-skill-dist-20261012.py','prepare-rf1127-current-skill-matrix-20261012.py','prepare-rf1127-current-hitmeta-matrix-20261012.py','archive-rf1127-current-console-20261012.py','window-restore-contract.mjs']:
 members['tools/'+n]=W/n
for n in ['native-perf-owned-json.py','test_native_perf_owned_json.py','native-perf-caption-hit-diagnostic.rs']:
 members['sources/'+n]=R/'tauri/scripts'/n
D=W/'rf1130-caption-hit-20261012'
for n in ['activate.rs','restore.rs','caption_hit_diagnostic.rs']:members['sources/diagnostic-'+n]=D/'helper/src'/n
for n in ['sources-after-api-fix.json','final-source-audit.json']:members['helper-checks/'+n]=D/n
for p in (D/'checks-retry1').iterdir():
 if p.is_file():members['helper-checks/'+p.name]=p
for n in ['activate.rs','restore.rs']:members['sources/original-'+n]=W/'window-restore-caption-20261011/helper/src'/n
assert not O.exists();O.mkdir();rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as archive:
 for name,p in sorted(members.items()):
  assert not p.stat().st_file_attributes&0x400
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  archive.addfile(info,io.BytesIO(data));rows.append({'member':name,'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(O/'raw.tar.gz') as archive:
 assert len(archive.getmembers())==len(rows)
 for row in rows:
  data=archive.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',{'task':'RF-1127','allMembersReadbackVerified':True,'members':rows,'physicalVaultExecutablesModelsCachesExcluded':True})
(O/'.gitattributes').write_text('raw.tar.gz -text\n',encoding='utf-8',newline='\n')
put(R/'docs/verification'/(N+'.json'),{'task':'RF-1127','sourceHead':package['gitHead'],'accepted':False,
 'scope':'same current-source diagnostic GUI after real calculator screenshot/click/key recovery; full four-cohort window matrix still rejected',
 'currentNativeTests':137,'sourceCount':1843,'exeSha256':package['sha256'],'resourceCount':94,
 'cargoRawBytesRestored':True,'frontendBuildInputsUnchanged':True,'rounds':rounds,
 'refusedRestorePoint':refused,'postTerminalProcessLookup':process,'lookupIsNotAtomicFailurePointIdentity':True,
 'sharedReaderTests':{'run':11,'passed':10,'failed':0,'skipped':1,'skipReason':'missing SeCreateSymbolicLinkPrivilege'},
 'noBudgetsRelaxed':True,'noExtraInputRetries':True,'successfulSamplesNotSpliced':True,'otherWindowsNotModified':True,
 'RF1127Closed':False,'RF1128Closed':False,'fullRF121Accepted':False,'performanceAccepted':False,
 'archive':{'path':N+'/raw.tar.gz','members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha(O/'raw.tar.gz'),'allMembersReadbackVerified':True}})
print(json.dumps({'rounds':rounds,'archiveMembers':len(rows),'accepted':False}))
