import assert from 'node:assert/strict';
export function checkRestore(proof,context){
  const keys=['schemaVersion','scope','runId','pid','creationMs','hwnd','tag','minimizedObserved','minimizeError','restoredVisibleNormalForeground',
    'minimizeApiReturnedPreviousVisibility','restoreApiReturnedPreviousVisibility','foregroundApiReturned','before','after','geometryAndDpiPreserved',
    'stylesPreserved','backdropPreserved','elapsedMilliseconds','heldProcessAndWindowIdentityVerifiedBeforeAndAfter','pixelsRead','inputEventsSent',
    'captionActivation','systemSettingsChanged','otherWindowsModified','fullMaterialMatrixAccepted'];
  assert.deepEqual(Object.keys(proof).sort(),keys.sort());
  assert.equal(proof.schemaVersion,1);assert.equal(proof.scope,'rf121-owned-window-minimize-restore');
  for(const key of ['runId','pid','creationMs','hwnd'])assert.equal(proof[key],context[key]);
  assert.equal(proof.tag,'minimize-restore-owned');assert.equal(proof.minimizeError,null);
  for(const key of ['minimizedObserved','restoredVisibleNormalForeground','geometryAndDpiPreserved','stylesPreserved','backdropPreserved','heldProcessAndWindowIdentityVerifiedBeforeAndAfter'])assert.equal(proof[key],true);
  for(const key of ['minimizeApiReturnedPreviousVisibility','restoreApiReturnedPreviousVisibility','foregroundApiReturned'])assert.equal(typeof proof[key],'boolean');
  assert.deepEqual(proof.before,proof.after);
  assert.deepEqual(Object.keys(proof.before).sort(),['windowRect','clientRect','dpi','systemBackdrop'].sort());
  assert.deepEqual(proof.after.windowRect,context.windowRect);assert.deepEqual(proof.after.clientRect,context.clientRect);
  assert.equal(proof.after.dpi,context.dpi);
  assert.deepEqual(proof.after.systemBackdrop,{ok:true,value:context.backdrop,errorHresult:null});
  assert(Number.isFinite(proof.elapsedMilliseconds)&&proof.elapsedMilliseconds>=150&&proof.elapsedMilliseconds<6000);
  for(const key of ['pixelsRead','otherWindowsModified'])assert.equal(proof[key],0);
  for(const key of ['systemSettingsChanged','fullMaterialMatrixAccepted'])assert.equal(proof[key],false);
  const caption=proof.captionActivation;assert.equal(caption.error,null);assert.equal(caption.extraReleaseEventsSent,0);
  assert.equal(proof.inputEventsSent,caption.inputEventsSent);
  if(caption.attempted){
    assert.deepEqual(Object.keys(caption).sort(),['attempted','inputEventsSent','extraReleaseEventsSent','cursorRestored','error','nativeHitTest','pointScreen','cursorMovedByUser'].sort());
    assert.equal(caption.inputEventsSent,2);assert.equal(caption.nativeHitTest,2);assert.equal(caption.cursorRestored,true);assert.equal(caption.cursorMovedByUser,false);
    const [x,y]=caption.pointScreen,r=context.windowRect;assert(Number.isInteger(x)&&Number.isInteger(y));
    assert(x>r[0]&&x<r[2]&&y>r[1]&&y<r[3]);
  }else{
    assert.deepEqual(Object.keys(caption).sort(),['attempted','inputEventsSent','extraReleaseEventsSent','cursorRestored','error'].sort());
    assert.equal(caption.inputEventsSent,0);assert.equal(caption.cursorRestored,null);
  }
  return true;
}
