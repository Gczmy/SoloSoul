from pathlib import Path
import datetime,hashlib,json,os,re,shutil,struct,subprocess,time,tomllib
R=Path('D:/SoloSoul');W=Path(__file__).parent;S=W/'rf1127-current-skill-build-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head.startswith('016667e35')
sources=load(R/'docs/performance/rf312-android-early-observer-2026-10-12.json')['sourceProof']['currentSourceFiles']
assert len(sources)==1843 and all(sha(R/n)==h for n,h in sources.items())
S.mkdir(exist_ok=False)
def save(n,v):
    with (S/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
save('sources.json',sources);save('starting-state.json',{'head':head,'sourceCount':1843,
    'scope':'current native-perf Windows diagnostic build after verified calculator capture/input recovery',
    'runtimeOrFullMatrixAccepted':False,'oldFailuresRetained':True})
cache=R/'build/rf312-maintenance-20261009';env=os.environ.copy()
env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),CARGO_HOME=str(cache/'cargo-home'),
    CARGO_TARGET_DIR=str(cache/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(cache/'ort-cache'),
    npm_config_cache=str(cache/'npm-cache'),PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','')
for n in ['PDFIUM_LIBRARY_PATH','TAURI_CONFIG','TAURI_ANDROID_PROJECT_PATH','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS']:
    env.pop(n,None)
def frozen():assert all(sha(R/n)==h for n,h in sources.items())
def run(label,command,allow_manifest_eol=False):
    frozen();began=time.monotonic()
    with (S/(label+'.stdout.log')).open('xb') as out,(S/(label+'.stderr.log')).open('xb') as err:
        child=subprocess.Popen(command,cwd=R/'tauri',env=env,stdout=out,stderr=err,
            stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
        save(label+'.live.json',{'pid':child.pid,'command':command,
            'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
        print(label,'live PID',child.pid,flush=True);code=child.wait()
    changed=[n for n,h in sources.items() if sha(R/n)!=h]
    save(label+'.receipt.json',{'command':command,'pid':child.pid,'exitCode':code,
        'elapsedSeconds':time.monotonic()-began,'sourceUnchanged':not changed,'changedSources':changed})
    if changed:
        assert allow_manifest_eol and changed==['tauri/src-tauri/Cargo.toml']
        after=manifest.read_bytes();(S/'Cargo.after.toml').write_bytes(after)
        assert before.replace(b'\r\n',b'\n')==after.replace(b'\r\n',b'\n')
        assert tomllib.loads(before.decode())==tomllib.loads(after.decode())
        save('manifest-newline-parity.json',{'normalizedBytesEqual':True,'parsedTomlEqual':True,
            'action':'restore exact original bytes only; retain actual changed-source receipt'})
        manifest.write_bytes(before)
    frozen();print(label,'terminal exit',code,flush=True);assert code==0,label
run('native-tests',['cargo','test','--locked','--offline','-p','solo_soul','--lib','--features',
    'native-perf','native_perf::','--','--nocapture'])
text=(S/'native-tests.stdout.log').read_text(encoding='utf-8')
counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
assert len(counts)==1 and int(counts[0][0])==137 and counts[0][1:]==('0','0'),counts
save('native-test-counts.json',{'passed':137,'failed':0,'ignored':0,'currentSources':True})
freeze=(W/'freeze-rf1129-dist.py').read_text(encoding='utf-8')
assert freeze.count('rf1129-native-build-20261011/dist-build-inputs.json')==1
freeze=freeze.replace('rf1129-native-build-20261011/dist-build-inputs.json',S.name+'/dist-build-inputs.json')
freeze=freeze.replace('generatedOutputsAreSeparateFrom1839SourceManifest','generatedOutputsAreSeparateFrom1843SourceManifest')
script=W/'freeze-rf1127-current-skill-dist-20261012.py';assert not script.exists()
script.write_text(freeze,encoding='utf-8',newline='\n')
configuration=load(R/'tauri/src-tauri/tauri.native-perf.conf.json')
configuration['build']['beforeBuildCommand']+=' && C:/Python314/python.exe '+script.as_posix()
save('native-build.conf.json',configuration)
manifest=R/'tauri/src-tauri/Cargo.toml';before=manifest.read_bytes();(S/'Cargo.before.toml').write_bytes(before)
run('build',['npm.cmd','run','tauri','--','build','--config',str(S/'native-build.conf.json'),
    '--features','native-perf','--no-bundle','--ci'],True)
dist=load(S/'dist-build-inputs.json');root=R/'tauri/dist'
assert {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}=={row['path'] for row in dist['files']}
for row in dist['files']:
    path=root/row['path'];assert not(path.stat().st_file_attributes&0x400)
    assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
save('dist-input-stability.json',{'allGeneratedFrontendInputsUnchangedDuringRustBuild':True,
    'files':len(dist['files']),'manifestSha256':sha(S/'dist-build-inputs.json')})
runtime=W/'ss-rf1127-current-skill-runtime-20261012/bin';runtime.mkdir(parents=True,exist_ok=False)
exe=runtime/'solo_soul.exe';shutil.copy2(cache/'cargo-target/release/solo_soul.exe',exe)
data=exe.read_bytes();offset=struct.unpack_from('<I',data,0x3c)[0]
assert data[offset:offset+4]==b'PE\0\0' and struct.unpack_from('<H',data,offset+24+68)[0]==2
assert b'rejectedTransitions' in data and b'windows-native-appearance-result' in data
package=load(W/'rf1129-native-build-20261011/runtime-package.json');oldExe=Path(package['exe']);rows=[]
for item in package['resources']:
    source=Path(item['source']);copy=runtime/Path(item['copy']).relative_to(oldExe.parent)
    assert copy.resolve().is_relative_to(runtime.resolve()) and sha(source)==item['sha256']
    copy.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,copy)
    assert sha(copy)==item['sha256'];rows.append({'source':str(source),'copy':str(copy),'sha256':item['sha256']})
assert len(rows)==94
package.update(exe=str(exe),sha256=sha(exe),bytes=len(data),resources=rows,
    sourceManifestSha256=sha(S/'sources.json'),gitHead=head,currentNativeTests=137,guiExecuted=False,
    applicationMaterialAccepted=False,previousGuiSha256=sha(oldExe))
save('runtime-package.json',package);frozen()
print('Fresh current-head Windows diagnostic GUI compiled with137 native tests and94 frozen resources; four-cohort runtime still required',flush=True)
