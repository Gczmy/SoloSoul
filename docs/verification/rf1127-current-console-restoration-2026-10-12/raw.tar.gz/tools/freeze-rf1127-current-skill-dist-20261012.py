from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul'); W=Path(__file__).parent; root=R/'tauri/dist'; output=W/'rf1127-current-skill-build-20261012/dist-build-inputs.json'
def ordinary_files(directory):
 assert directory.is_dir() and not(directory.stat().st_file_attributes&0x400)
 for path in sorted(directory.iterdir()):
  assert not(path.lstat().st_file_attributes&0x400)
  if path.is_dir():yield from ordinary_files(path)
  else:yield path
rows=[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in ordinary_files(root)]
assert rows and any(row['path']=='index.html' for row in rows)
with output.open('x',encoding='utf-8') as file:json.dump({'stage':'after frontend build, before Rust compilation','generatedOutputsAreSeparateFrom1843SourceManifest':True,'root':str(root),'files':rows},file,indent=2)
print('Frozen actual frontend build outputs before Rust compilation:',len(rows))
