from pathlib import Path
import hashlib,json
W=Path(__file__).parent;S=W/'rf1127-current-hitmeta-matrix-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
done=load(S/'cohorts-complete.json')
assert not done['accepted'] and len(done['rows'])==1
C=W/'ss-rf121-composed-window-restore-baseline-current-hitmeta-20261012'
receipt=load(C/'actual100.receipt.json')
assert receipt['exitCode']==1 and all(receipt[k] for k in ['sourceUnchanged','resourcesUnchanged','originalFixtureUnchanged'])
j=load(C/'actual100/native-perf-sdk-journey-results.json')
assert not j['interrupted'] and len(j['samples'])==3
samples=[]
for row in j['samples']:
 assert row['cleanupIntegrity']['complete']
 root=C/'actual100'/f"sample-{row['index']:03}"
 owned=load(root/'native-perf-owned.json');consumed=load(root/'native-perf-consumed.json')
 assert owned==row['owned'] and owned['runId']==consumed['runId'] and row['processId']==consumed['pid']
 assert Path(owned['root']).samefile(root)
 processes=row.get('beforeSnapshot',{}).get('processes',[])+row.get('afterSnapshot',{}).get('processes',[])
 identities=[{'pid':p['pid'],'creationMs':p['creationMs']} for p in processes]
 assert len(identities)>=9
 samples.append({'index':row['index'],'runId':owned['runId'],'pid':row['processId'],'recordedIdentities':identities})
prefix='rf1127-current-hitmeta'
plan={'cacheCleanupEligible':True,'failedSamplesAccepted':False,'plannedExactCacheTargets':24,'freshCimRequired':True,
 'groups':[{'label':'baseline','captureRoot':str(C),'terminal':True,'samples':samples,'terminalReceiptSha256':sha(C/'actual100.receipt.json'),'acceptanceEvidencePresent':False}]}
with (W/(prefix+'-cache-cleanup-plan.json')).open('x',encoding='utf-8') as f:json.dump(plan,f,indent=2)
text=(W/'rf1128-cleanup-owned.ps1').read_text(encoding='utf-8')
for a,b in [('rf1128-cache-cleanup',prefix+'-cache-cleanup'),('groups.Count -ne 4','groups.Count -ne 1'),
 ('Four terminal owned groups required','One terminal owned group required'),('Count -ne 96','Count -ne 24'),
 ('Exact 96 owned cache paths required','Exact 24 owned cache paths required'),
 ('ss-rf1123-backdrop-runtime-20261011','ss-rf1127-current-skill-runtime-20261012'),
 ('application-logs-rf1128-shared','application-logs-'+prefix),("task='RF-1128'","task='RF-1127'")]:text=text.replace(a,b)
text=text.replace("$liveHelpers = @(", "$taskHelperExecutables += @('D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\rf1130-caption-hit-20261012\\bin\\rf1130-owned-caption-foreground.exe','D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\rf1130-caption-hit-20261012\\bin\\rf1130-owned-caption-restore.exe')\n$liveHelpers = @(")
text=text.replace("Name = 'rf121-owned-caption-foreground.exe'\"", "Name = 'rf121-owned-caption-foreground.exe' OR Name = 'rf1130-owned-caption-foreground.exe' OR Name = 'rf1130-owned-caption-restore.exe'\"")
with (W/(prefix+'-cleanup-owned.ps1')).open('x',encoding='utf-8') as f:f.write(text)
print('Terminal failed group retained; exact 24 cache targets prepared for fresh identity checks')
