from pathlib import Path
import hashlib,json,shutil,subprocess
R=Path('D:/SoloSoul');W=Path(__file__).parent
B=W/'rf1127-current-skill-build-20261012';S=W/'rf1127-current-skill-matrix-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()
assert load(B/'build.receipt.json')['exitCode']==0
assert load(B/'native-test-counts.json')=={'passed':137,'failed':0,'ignored':0,'currentSources':True}
assert load(B/'dist-input-stability.json')['allGeneratedFrontendInputsUnchangedDuringRustBuild']
sources=load(B/'sources.json');assert len(sources)==1843 and all(sha(R/n)==h for n,h in sources.items())
package=load(B/'runtime-package.json');assert package['currentNativeTests']==137
assert sha(Path(package['exe']))==package['sha256'] and not package['guiExecuted']
S.mkdir(exist_ok=False)
def save(n,v):(S/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
save('sources.json',sources);save('caption-runtime-package.json',package)
old=W/'rf1129-native-matrix-console-20261012'
shutil.copyfile(old/'restore-helper.json',S/'restore-helper.json')
names=[('run-rf1129-diagnostic-console.py','run-rf1127-current-skill.py'),
       ('verify-rf1129-diagnostic-console.mjs','verify-rf1127-current-skill.mjs'),
       ('render-rf1129-diagnostic-console.py','render-rf1127-current-skill.py'),
       ('run-rf1129-cohorts-console.py','run-rf1127-current-skill-cohorts.py'),
       ('rf1129-session-preflight-console.py','rf1127-current-skill-session-preflight.py')]
mapping=[('rf1129-native-matrix-console-20261012',S.name),
    ('-diagnostic-console-20261012','-current-skill-20261012'),
    ("'rf1129-session-console-'+mode+'.py'","'rf1127-current-skill-session-'+mode+'.py'"),*names]
tools={};rows=[]
for before,after in names:
    text=(W/before).read_text(encoding='utf-8');changed=text
    for a,b in mapping:changed=changed.replace(a,b)
    target=W/after;assert not target.exists()
    if target.suffix=='.py':compile(changed,str(target),'exec')
    target.write_text(changed,encoding='utf-8',newline='\n')
    assert target.read_text(encoding='utf-8')==changed
    tools[target.relative_to(R).as_posix()]=sha(target)
    rows.append({'before':str(W/before),'beforeSha256':sha(W/before),
        'after':str(target),'afterSha256':sha(target),'changes':'only exclusive paths/tool names; all budgets and guards unchanged'})
for p in [W/'window-restore-contract.mjs',Path(__file__),R/'tauri/scripts/native-perf-owned-json.py',
          R/'tauri/scripts/test_native_perf_owned_json.py']:
    tools[p.relative_to(R).as_posix()]=sha(p)
save('tools.json',tools)
save('preparation.json',{'sourceCount':1843,'nativeTests':137,'currentGuiSha256':package['sha256'],
    'derivation':rows,'replacements':mapping,'originalGuardsAndBudgetsUnchanged':True,
    'extraInputRetries':0,'wholeMatrixAccepted':False,'oldFailedRoundsPreserved':True,
    'generatedFrontendBuildInputs':load(B/'dist-input-stability.json')})
save('previous-failures-retained.json',{'archives':['docs/verification/rf1127-console-foreground-denials-2026-10-12.json',
    'docs/verification/rf1130-caption-hit-diagnostics-2026-10-12.json'],
    'externalStateChange':'Fresh current skill calculator activation/correct screenshot/click/keyboard actually pass',
    'proof':'build/console-computer-use-recheck-20261012-current-skill/result.json',
    'currentGuiRebuilt':True,'scopeReduced':False,'extraInputRetries':0})
print('Prepared exact new current-source four-cohort matrix; no native runtime acceptance yet',flush=True)
