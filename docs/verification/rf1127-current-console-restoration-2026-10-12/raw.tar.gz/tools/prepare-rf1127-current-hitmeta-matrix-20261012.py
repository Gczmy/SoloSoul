from pathlib import Path
import hashlib,json,subprocess
R=Path('D:/SoloSoul');W=Path(__file__).parent
B=W/'rf1127-current-skill-build-20261012';S=W/'rf1127-current-hitmeta-matrix-20261012'
D=W/'rf1130-caption-hit-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()
assert load(B/'build.receipt.json')['exitCode']==0
sources=load(B/'sources.json');assert len(sources)==1843 and all(sha(R/n)==h for n,h in sources.items())
helper_sources=load(D/'sources-after-api-fix.json')
assert all(sha(R/n)==h for n,h in helper_sources.items())
assert load(D/'checks-retry1/checks-complete.json')['accepted']
assert load(W/'rf1127-current-skill-matrix-20261012/cohorts-complete.json')['accepted'] is False
assert load(W/'rf1127-current-skill-cache-cleanup.json')['preservedBytesVerified']
old_checked=load(W/'rf1130-native-matrix-20261012/caption-runtime-package.json')
old_restore=load(W/'rf1130-native-matrix-20261012/restore-helper.json')
for p,h in [(old_checked['activationExe'],old_checked['activationSha256']),(old_restore['exe'],old_restore['sha256'])]:assert sha(Path(p))==h
package=load(B/'runtime-package.json');assert sha(Path(package['exe']))==package['sha256']
for k in ['activationExe','activationSha256','activationSource','activationSourceSha256','captionDiagnosticSource','captionDiagnosticSourceSha256']:package[k]=old_checked[k]
package['applicationPreviouslyExecuted']=True
S.mkdir(exist_ok=False)
def save(n,v):
 with (S/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
save('sources.json',sources);save('caption-runtime-package.json',package);save('restore-helper.json',old_restore)
names=[('run-rf1127-current-skill.py','run-rf1127-current-hitmeta.py'),
 ('verify-rf1127-current-skill.mjs','verify-rf1127-current-hitmeta.mjs'),
 ('render-rf1127-current-skill.py','render-rf1127-current-hitmeta.py'),
 ('run-rf1127-current-skill-cohorts.py','run-rf1127-current-hitmeta-cohorts.py'),
 ('rf1127-current-skill-session-preflight.py','rf1127-current-hitmeta-session-preflight.py')]
mapping=[('rf1127-current-skill-matrix-20261012',S.name),('-current-skill-20261012','-current-hitmeta-20261012'),
 ("'rf1127-current-skill-session-'+mode+'.py'","'rf1127-current-hitmeta-session-'+mode+'.py'"),*names]
tools={};rows=[]
for a,b in names:
 before=(W/a).read_text(encoding='utf-8');after=before
 for x,y in mapping:after=after.replace(x,y)
 p=W/b;assert not p.exists()
 if p.suffix=='.py':compile(after,str(p),'exec')
 p.write_text(after,encoding='utf-8',newline='\n');assert p.read_text(encoding='utf-8')==after
 tools[p.relative_to(R).as_posix()]=sha(p)
 rows.append({'before':str(W/a),'beforeSha256':sha(W/a),'after':str(p),'afterSha256':sha(p),'changes':'only exclusive paths and tool names'})
for n,h in helper_sources.items():tools[n]=h
for p in [W/'window-restore-contract.mjs',Path(__file__),R/'tauri/scripts/native-perf-owned-json.py']:
 tools[p.relative_to(R).as_posix()]=sha(p)
save('tools.json',tools)
save('preparation.json',{'sourceCount':1843,'nativeTests':137,'currentGuiSha256':package['sha256'],
 'helperChecksUnchanged':True,'sameCurrentGui':True,'originalGuardsAndBudgetsUnchanged':True,'extraInputRetries':0,
 'previousFailedMatrixRetained':True,'scopeReduced':False,'reason':'original first sample restored geometry/backdrop but refused caption hit; use already verified RF-1130 metadata at exact refusal',
 'derivation':rows,'replacements':mapping})
print('Same current GUI with already verified refused-hit metadata; complete four-cohort matrix prepared')
