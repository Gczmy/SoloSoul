import pathlib,json,subprocess,time,datetime,sys,os
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf1094-ocr-general-20261005')
env=os.environ.copy();env['PDFIUM_LIBRARY_PATH']=r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-ocr-20261005\bin\pdfium\pdfium.dll'
def run(name,args):
 started=time.time()
 with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
  c=subprocess.Popen(args,cwd=r/'tauri',env=env,stdout=out,stderr=err)
  (s/(name+'.live.json')).write_text(json.dumps({'pid':c.pid,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}),encoding='utf-8')
  print('Started '+name+' PID '+str(c.pid),flush=True);rc=c.wait()
 receipt={'command':args,'pid':c.pid,'exitCode':rc,'elapsedSeconds':time.time()-started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (s/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt),flush=True)
 if rc:raise SystemExit(rc)
run('green-fmt-write',['cargo','+1.99.0','fmt','--all'])
run('green-core-tests',['cargo','test','--locked','-p','solosoul-core','--lib'])
run('green-core-clippy',['cargo','clippy','--locked','-p','solosoul-core','--all-targets','--','-D','warnings'])
run('green-fmt-check',['cargo','+1.99.0','fmt','--all','--','--check'])
run('green-diff-check',['git','-c','safe.directory='+r.as_posix(),'-c','core.safecrlf=false','diff','--check'])
