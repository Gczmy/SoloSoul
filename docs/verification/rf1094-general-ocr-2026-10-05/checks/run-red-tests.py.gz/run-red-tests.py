import pathlib,json,subprocess,time,datetime,sys,os
sys.stdout.reconfigure(encoding='utf-8')
r=pathlib.Path(r'C:\Users\40299571\SoloSoul');s=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf1094-ocr-general-20261005')
env=os.environ.copy();env['PDFIUM_LIBRARY_PATH']=r'C:\Users\40299571\AppData\Local\Temp\ss-rf312-ocr-20261005\bin\pdfium\pdfium.dll'
def run(name,args):
 started=time.time()
 with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
  c=subprocess.Popen(args,cwd=r/'tauri',env=env,stdout=out,stderr=err)
  (s/(name+'.live.json')).write_text(json.dumps({'pid':c.pid,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}),encoding='utf-8')
  print('Started '+name+' PID '+str(c.pid),flush=True);rc=c.wait()
 receipt={'command':args,'pid':c.pid,'exitCode':rc,'elapsedSeconds':time.time()-started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (s/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt),flush=True)
 if rc!=101:raise SystemExit('Expected actual red test failure; inspect before repair')
run('red-general-ctc',['cargo','test','--locked','-p','solosoul-core','--lib','general_decode_preserves_letters_and_repeated_ce','--','--nocapture','--test-threads=1'])
run('red-public-image',['cargo','test','--locked','-p','solosoul-core','--lib','test_ocr_end_to_end','--','--nocapture','--test-threads=1'])
