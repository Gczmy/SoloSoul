from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path('D:/SoloSoul'); base=Path(__file__).parent.resolve()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
artifacts=load(base/'rf1126-legacy-theme-build-20261011/current-apks.json')
assert artifacts['accepted'] and not artifacts['deviceAcceptance']
provenance=load(base/'rf1109-console-source-provenance-20261012.json')
assert provenance['artifactReceiptSha256']==sha(base/'rf1126-legacy-theme-build-20261011/current-apks.json')
assert provenance['artifactBuildSourceFiles']==artifacts['sourceFiles']
sources=provenance['runtimeValidationSourceFiles']; assert len(sources)==1837
files={row['kind']:row for row in artifacts['files']}
def verify():
    for name,digest in sources.items():assert sha(root/name)==digest,name
    for row in files.values():assert sha(Path(row['copy']))==row['sha256']
verify()
stage=base/'api31-home-console-full-20261012'; stage.mkdir(exist_ok=False)
def save(name,value):
    with (stage/name).open('x',encoding='utf-8') as out:json.dump(value,out,indent=2)
env=os.environ.copy()
env.update({'ANDROID_HOME':str(base/'sdk'),'ANDROID_SDK_ROOT':str(base/'sdk'),
    'ANDROID_USER_HOME':str(base/'android-user'),'ANDROID_EMULATOR_HOME':str(base/'android-user'),
    'ANDROID_AVD_HOME':str(base/'avd'),'ANDROID_ADB_SERVER_PORT':'5049','ADB_SERVER_SOCKET':'tcp:localhost:5049',
    'TEMP':str(base/'tmp'),'TMP':str(base/'tmp')})
env.pop('ANDROID_SDK_HOME',None)
adb=str(base/'sdk/platform-tools/adb.exe'); serial='emulator-5586'; avd='SoloSoul_RF121_API31_20261010'
def read(args):
    return subprocess.run([adb,'-H','localhost','-P','5049','-s',serial,*args],env=env,
        check=True,capture_output=True,text=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW).stdout.strip()
boot = load(base/'api31-host-console-20261012/boot.receipt.json')
assert boot['booted'] and boot['avdConfigUnchanged']
owned = [x for x in load(base/'api31-host-console-20261012/owned-processes-after-launch.json') if x['ProcessId']==boot['pid']]
assert len(owned)==1 and owned[0]['ProcessId']==boot['pid']
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
probe=subprocess.run([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {boot['pid']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3"],check=True,capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
live=json.loads(probe.stdout)
for key in ['Name','ProcessId','ExecutablePath','CommandLine']:assert live[key]==owned[0][key],key
assert datetime.datetime.fromisoformat(live['CreationDate'])==datetime.datetime.fromisoformat(owned[0]['CreationDate'])
save('owned-emulator-preflight.json',{'live':live,'exactBirthExecutableCommandVerified':True})


assert read(['get-state'])=='device' and read(['shell','getprop','sys.boot_completed'])=='1'
assert read(['emu','avd','name']).splitlines()[0]==avd
assert read(['shell','getprop','ro.build.version.sdk'])=='31'
save('input-proof.json',{'artifactReceiptSha256':sha(base/'rf1126-legacy-theme-build-20261011/current-apks.json'),
    'serial':serial,'avd':avd,'runtimeValidationSourceFiles':sources,'artifactBuildSourceFiles':provenance['artifactBuildSourceFiles'],'sourceProvenanceSha256':sha(base/'rf1109-console-source-provenance-20261012.json'),'artifactBuildSourcesEqualCurrent':False,'files':artifacts['files'],
    'allBackupsLocalOnly':True,'physicalDeviceAcceptance':False})
rows=[]
cases=[{'scenario':scenario,'mode':mode,'fontScale':None}
       for scenario in ['baseline','overlays','keyboard','accounts','insets','lifecycle','cold','previews','rendering']
       for mode in ['supported','fallback']]
cases += [{'scenario':'baseline','mode':mode,'fontScale':scale} for scale in [1.3,2.0] for mode in ['supported','fallback']]
assert len(cases)==22
save('requested-case-catalog.json',{'api':31,'cases':cases,'allNewSamplesRequired':True,'initialFourResultsNotUsedForAcceptance':True})
for case in cases:
    scenario,mode,font_scale=case['scenario'],case['mode'],case['fontScale']
    verify(); label=f'{scenario}-{mode}'+(f'-font-{font_scale}' if font_scale is not None else '')
    settings_before={'blur':read(['shell','settings','get','global','disable_window_blurs']),
        'night':read(['shell','cmd','uimode','night']),'fontScale':read(['shell','settings','get','system','font_scale'])}
    command=['C:/Python314/python.exe','scripts/android-home-native-regression.py','--adb',adb,'--serial',serial,'--avd',avd,
        '--apk',files['main']['copy'],'--test-apk',files['test']['copy'],'--output',str(stage/label),
        '--mode',mode,'--scenario',scenario]
    if scenario=='cold':command+=['--motion-preferences']
    if font_scale is not None:command+=['--font-scale',str(font_scale)]
    began=time.monotonic()
    with (stage/(label+'.stdout.log')).open('xb') as out,(stage/(label+'.stderr.log')).open('xb') as err:
        process=subprocess.Popen(command,cwd=root/'tauri',env=env,stdin=subprocess.DEVNULL,
            stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(label+'.live.json',{'pid':process.pid,'command':command})
        print(f'API31 home {label} live PID {process.pid}',flush=True)
        code=process.wait()
    verify()
    report=load(stage/label/'report.json') if (stage/label/'report.json').is_file() else {}
    settings_after={'blur':read(['shell','settings','get','global','disable_window_blurs']),
        'night':read(['shell','cmd','uimode','night']),'fontScale':read(['shell','settings','get','system','font_scale'])}
    identity_after=read(['emu','avd','name']).splitlines()[0]==avd
    restored=bool(report.get('restored') and report.get('blurRestored') and
        settings_before==settings_after and identity_after and
        not any(report.get(k) for k in ['restoreError','blurRestoreError','notificationRestoreError','nightModeRestoreError','fontScaleRestoreError']))
    passed=bool(code==0 and report.get('passed') and restored and report.get('mode')==mode and
        report.get('scenario')==scenario and report.get('api')==31 and report.get('requestedFontScale')==font_scale)
    row={'mode':mode,'scenario':scenario,'requestedFontScale':font_scale,'caseLabel':label,'exitCode':code,'accepted':passed,'elapsedSeconds':time.monotonic()-began,
        'restored':restored,'settingsBefore':settings_before,'settingsAfter':settings_after,
        'sourceAndApkHashesUnchanged':True,'dedicatedAvdIdentityConfirmedAfter':identity_after,'notificationPermissionApplicable':False,
        'reportSha256':sha(stage/label/'report.json') if report else None}
    save(label+'.receipt.json',row);rows.append(row)
    print(f'API31 home {label} terminal exit {code}; accepted={passed}; restored={restored}',flush=True)
    if not restored:
        save('verification.json',{'accepted':False,'results':rows,'stoppedForIncompleteRestoration':True})
        raise SystemExit(1)
accepted=len(rows)==22 and all(row['accepted'] for row in rows)
save('verification.json',{'accepted':accepted,'results':rows,'scope':'API31 all nine home scenarios in both modes plus 1.3/2.0 baseline font scale in both modes','requestedContexts':22,'initialFourResultsNotUsedForAcceptance':True,
    'fullHomeMatrixAccepted':accepted,'api35Accepted':False,'RF121Complete':False,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
raise SystemExit(0 if accepted else 1)
