from pathlib import Path
import hashlib,importlib.util,io,json,tarfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;I=B/'api31-home-console-20261012';S=B/'api31-home-console-full-20261012';H=B/'api31-host-console-20261012'
N='rf121-api31-console-font-restore-stop-2026-10-12';O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
spec=importlib.util.spec_from_file_location('home',R/'tauri/scripts/android-home-native-regression.py');home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
prov=load(B/'rf1109-console-source-provenance-20261012.json')
assert all(sha(R/n)==h for n,h in prov['runtimeValidationSourceFiles'].items())
assert all(sha(Path(x['copy']))==x['sha256'] for x in prov['apkFiles'])
initial=load(I/'verification.json');full=load(S/'verification.json')
assert initial['accepted'] and len(initial['results'])==4
assert not full['accepted'] and full['stoppedForIncompleteRestoration'] and len(full['results'])==19
assert all(x['accepted'] and x['restored'] for x in full['results'][:-1])
assert not full['results'][-1]['accepted'] and not full['results'][-1]['restored']
rows=[];backups=[];native=0
for label,parent,result in [('initial',I,initial),('full-stopped',S,full)]:
 for receipt in result['results']:
  name=receipt.get('caseLabel',receipt['scenario']+'-'+receipt['mode']);C=parent/name;report=load(C/'report.json')
  assert receipt['reportSha256']==sha(C/'report.json') and report['restored'] and report['blurRestored']
  for file,method in [('native.log',home.METHOD),('cold-native.log',home.COLD_METHOD)]:
   if (C/file).exists():home.verify_native((C/file).read_text(encoding='utf-8'),method);native+=1
  before=C/'private-data-before.tar';after=C/'private-data-restored.tar'
  inventory=home.inventory(before,require_empty=True);assert inventory==home.inventory(after,require_empty=True)
  assert len(inventory)==216==report['restoreVerification']['entries']
  for p in [before,after]:backups.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
  rows.append({'phase':label,'case':name,'nativePassed':True,'originalContextAccepted':receipt['accepted'],'originalCompleteRestoreAccepted':receipt['restored'],'privateEntriesPreserved':216})
C=S/'baseline-supported-font-1.3';report=load(C/'report.json');assert report['fontScaleRestoreError']=='System font scale differs from original state'
comp=load(H/'font-restoration-compensation.json');assert comp['originalRawValue']==comp['afterDelete']==comp['afterConfigurationRead']=='null'
late=load(C/'compensation-private-verification.json');assert late['fontRawValue']=='null' and late['allPrivateContentsLinksAndModesMatch']
third=Path(late['thirdSnapshot']['path']);assert home.inventory(third,require_empty=True)==home.inventory(C/'private-data-before.tar',require_empty=True)
backups.append(late['thirdSnapshot']);assert len(backups)==47 and native==27
put(B/'rf121-api31-font-stop-cleanup-plan.json',{'files':backups,'archiveBeforeDeletionRequired':True,'originalFailedContextNotAccepted':True})
assert not O.exists();O.mkdir();members={}
for label,parent in [('initial',I),('full-stopped',S),('boot',H)]:
 for p in parent.rglob('*'):
  if p.is_file() and p.suffix in ['.json','.log','.png','.xml']:
   assert not(p.stat().st_file_attributes&0x400);members[label+'/'+p.relative_to(parent).as_posix()]=p
for n in ['boot-rf121-api31-console.py','verify-rf121-api31-home-console.py','verify-rf121-api31-home-console-full.py','verify-rf121-api31-font-normal-console.py','validate-rf121-api31-console-full.py','stop-rf121-console-api31.py','archive-rf121-api31-font-stop.py','rf1109-console-source-provenance-20261012.json','rf121-api31-font-stop-cleanup-plan.json']:
 members['tools/'+n]=B/n
for n in ['tauri/scripts/android-home-native-regression.py','tauri/scripts/test_android_home_native_regression.py','tauri/src-tauri/src/lib.rs','tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidHomeInstrumentedTest.kt']:
 members['sources/'+n]=R/n
members['build/current-apks.json']=B/'rf1126-legacy-theme-build-20261011/current-apks.json'
index=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as archive:
 for name,p in sorted(members.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
  index.append({'member':name,'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(O/'raw.tar.gz') as archive:
 assert len(archive.getmembers())==len(index)
 for row in index:
  data=archive.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',{'task':'RF-121','members':index,'allMembersReadbackVerified':True,'privateTarsAndApksExcluded':True,'unusedPreparedTools':['verify-rf121-api31-font-normal-console.py','validate-rf121-api31-console-full.py','stop-rf121-console-api31.py']})
(O/'.gitattributes').write_text('raw.tar.gz -text\n',encoding='utf-8',newline='\n')
put(R/'docs/verification'/(N+'.json'),{'task':'RF-121','sourceHead':'7dd88e610','accepted':False,'initialContextsPassed':4,'fullContextsRequested':22,'fullContextsExecuted':19,'fullContextsAccepted':18,'nativeMethodsPassedIncludingInitial':native,'nativeMethodsFailed':0,'nativeSkipped':0,'originalRestoreFailurePreserved':True,'failedCase':'baseline-supported-font-1.3','rawFontBefore':'null','rawFontAfterOriginalRestore':'1.0','fontRecovery':comp,'privateRecovery':late,'currentSources':1837,'artifactBuildSourcesEqualCurrent':False,'sourceProvenance':prov,'fullRF121Accepted':False,'RF312Accepted':False,'emulatorStillOwnedAndRunningForNextRestorationTask':True,'preparedFontReferencesExecuted':0,'humanReviewedPngs':['full-stopped/baseline-supported/device-files/enhanced-light.png','full-stopped/baseline-supported/device-files/enhanced-dark-after-unlock.png'],'allPngsHumanReviewed':False,'results':rows,'archive':{'path':N+'/raw.tar.gz','members':len(index),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha(O/'raw.tar.gz'),'allMembersReadbackVerified':True}})
print(json.dumps({'accepted':False,'members':len(index),'nativePassed':native,'fullContextsAccepted':18,'privateBackupsEligibleForExactCleanup':47}))
