from pathlib import Path
import hashlib,importlib.util,json
R=Path('D:/SoloSoul');B=Path(__file__).parent
S=B/'api31-home-console-full-20261012';F=B/'api31-font-normal-console-20261012';I=B/'api31-home-console-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('home',R/'tauri/scripts/android-home-native-regression.py')
home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
provenance=load(B/'rf1109-console-source-provenance-20261012.json')
assert all(sha(R/n)==h for n,h in provenance['runtimeValidationSourceFiles'].items())
assert all(sha(Path(row['copy']))==row['sha256'] for row in provenance['apkFiles'])
assert len(load(S/'verification.json')['results'])==22 and len(load(F/'verification.json')['results'])==2
rows=[];backups=[];native_passed=0;native_failed=0;errors=[]
for label,parent in [('initial',I),('full',S),('font-reference',F)]:
 verification=load(parent/'verification.json')
 for receipt in verification['results']:
  name=receipt.get('caseLabel',receipt['scenario']+'-'+receipt['mode']);C=parent/name
  report=load(C/'report.json');assert receipt['restored'] and receipt['settingsBefore']==receipt['settingsAfter']
  assert receipt['reportSha256']==sha(C/'report.json')
  before=C/'private-data-before.tar';after=C/'private-data-restored.tar'
  inventory=home.inventory(before,require_empty=True);assert inventory==home.inventory(after,require_empty=True)
  assert len(inventory)==report['restoreVerification']['entries'] and report['restored'] and report['blurRestored']
  for p in [before,after]:backups.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
  accepted=True
  for file,method in [('native.log',home.METHOD),('cold-native.log',home.COLD_METHOD)]:
   if not (C/file).exists():continue
   try:home.verify_native((C/file).read_text(encoding='utf-8'),method);native_passed+=1
   except RuntimeError as e:native_failed+=1;accepted=False;errors.append({'phase':label,'case':name,'file':file,'error':str(e)})
  try:
   evidence=load(C/'device-files/report.json');scenario=receipt['scenario'];motion=scenario=='cold'
   stages=home.verify_evidence(evidence,'accounts' if motion else scenario,motion,
    require_preview_bars=scenario=='previews',require_preview_ink=scenario=='previews',
    require_safe_notifications=scenario=='insets',requested_font_scale=receipt.get('requestedFontScale'),
    require_typography_header=receipt.get('requestedFontScale') is not None,require_keyboard_cancel=scenario=='keyboard')
   assert stages==report['stages']
   if motion:
    cold=load(C/'cold-device-files/report.json');assert home.verify_evidence(cold,'cold',True)==report['coldStages']
    assert cold['records'][0]['previousProcessId']==evidence['processId']==report['previousProcessId']
    assert cold['processId']==report['coldProcessId'] and cold['processId']!=evidence['processId']
    ids=lambda e:{r['accountId'] for r in e['records'] if r['stage'].startswith(('account-a-','account-b-'))}
    assert len(ids(evidence))==2 and ids(evidence)==ids(cold)
   assert home.verification_passed(report,False)==receipt['accepted']
  except (RuntimeError,AssertionError,KeyError) as e:
   accepted=False;errors.append({'phase':label,'case':name,'error':str(e)})
  rows.append({'phase':label,'case':name,'accepted':accepted and receipt['accepted'],'restoredEntries':len(inventory),'settingsRestored':True})
pairs=[]
for mode in ['supported','fallback']:
 normal=load(F/f'baseline-{mode}-font-1.0/device-files/report.json')
 for scale in [1.3,2.0]:
  enlarged=load(S/f'baseline-{mode}-font-{scale}/device-files/report.json')
  try:
   comparisons=home.verify_font_scale_pair(normal,enlarged)
   pairs.append({'mode':mode,'scale':scale,'accepted':True,'comparisons':comparisons})
  except RuntimeError as e:pairs.append({'mode':mode,'scale':scale,'accepted':False,'error':str(e)})
assert len(backups)==56 and len(rows)==28
full_accepted=all(row['accepted'] for row in rows if row['phase']!='initial') and all(p['accepted'] for p in pairs)
result={'task':'RF-121','accepted':full_accepted,'allPrivateDataAndSettingsRestored':True,'initialContexts':4,'fullContexts':22,'fontReferenceContexts':2,'initialResultsNotUsedForFullAcceptance':True,'nativeMethodsPassedIncludingInitial':native_passed,'nativeMethodsFailedIncludingInitial':native_failed,'results':rows,'fontPairs':pairs,'errors':errors,'currentSourceCount':1837,'artifactBuildSourcesEqualCurrent':False,'cleanupEligibleExactFiles':backups,'fullRF121Accepted':False,'RF312Accepted':False,'physicalDevicePerformanceAccepted':False}
with (S/'independent-validation.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(result,f,indent=2)
with (B/'rf121-api31-console-cleanup-plan.json').open('x',encoding='utf-8',newline='\n') as f:json.dump({'files':backups,'archiveBeforeDeletionRequired':True},f,indent=2)
print(json.dumps({k:v for k,v in result.items() if k not in ['results','fontPairs','errors','cleanupEligibleExactFiles']},indent=2))
print(json.dumps({'fontPairs':[{k:v for k,v in p.items() if k!='comparisons'} for p in pairs],'errors':errors},indent=2))
