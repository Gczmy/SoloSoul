from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time,zipfile
r=Path('D:/SoloSoul');b=Path(__file__).parent.resolve();s=b/'rf1126-legacy-theme-build-20261011';s.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=load(b/'rf1125-theme-render-test-build-20261011/current-apks.json');sources=old['sourceFiles'].copy()
changed=[n for n,h in sources.items() if sha(r/n)!=h]
expected={'tauri/src-tauri/gen/android/app/src/main/java/com/solosoul/app/MainActivity.kt','tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt'}
assert set(changed)==expected,changed
for n in changed:sources[n]=sha(r/n)
def save(name,v):
 with (s/name).open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2)
def verify():
 assert all(sha(r/n)==h for n,h in sources.items())
 assert all(sha(Path(v['copy']))==v['sha256'] for v in old['files'])
verify();save('input-proof.json',dict(base='7c8518740cf55930614244f4b1308c392c0384d5',sourceFiles=sources,changedFiles=changed,oldFiles=old['files'],rustSourcesChanged=False,originalNativeFailuresRetained=True))
jdk=Path('C:/Users/40299571/ss-android/jdk');sdk=b/'sdk';g=r/'tauri/src-tauri/gen/android'
env=os.environ.copy();env.update(JAVA_HOME=str(jdk),ANDROID_HOME=str(sdk),ANDROID_SDK_ROOT=str(sdk),NDK_HOME=str(sdk/'ndk/27.0.12077973'),ANDROID_NDK_HOME=str(sdk/'ndk/27.0.12077973'),ANDROID_USER_HOME=str(b/'android-user'),ANDROID_EMULATOR_HOME=str(b/'android-user'),ANDROID_AVD_HOME=str(b/'avd'),ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',RUSTUP_HOME=str(b/'rustup'),RUSTUP_TOOLCHAIN='1.96.0',CARGO_HOME=str(b/'cargo-home'),CARGO_TARGET_DIR=str(b/'cargo-target'),CARGO_BUILD_JOBS='1',GRADLE_USER_HOME=str(b/'gradle-home'),ORT_CACHE_DIR=str(b/'ort-cache'),TEMP=str(b/'tmp'),TMP=str(b/'tmp'),JAVA_TOOL_OPTIONS=f'-Duser.home={b/"java-home"} -Djava.io.tmpdir={b/"tmp"}')
for key in ['ANDROID_SDK_HOME','PDFIUM_LIBRARY_PATH','SOLOSOUL_KEYSTORE_PATH','SOLOSOUL_KEYSTORE_PASSWORD','SOLOSOUL_KEY_ALIAS','SOLOSOUL_KEY_PASSWORD','SOLOSOUL_REGISTRY_PUBKEY']:env.pop(key,None)
env['PATH']=str(jdk/'bin')+';'+env.get('PATH','')
def run(name,cmd,cwd=g):
 verify();start=time.monotonic()
 with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  save(name+'.live.json',dict(pid=p.pid,command=cmd));print(name,'live',p.pid,flush=True);code=p.wait()
 verify();save(name+'.receipt.json',dict(exitCode=code,elapsedSeconds=time.monotonic()-start,sourceUnchanged=True,command=cmd));print(name,'terminal',code,flush=True);assert code==0
def gradle(task):return ['cmd.exe','/d','/c',str(g/'gradlew.bat'),task,'-x',':app:rustBuildX86_64Debug','--init-script',str(b/'current-apks-rf1121-20261011/private-packaging-assets.init.gradle'),'--offline','--no-daemon','--max-workers','2']
run('kotlin-unit-tests',gradle(':app:testX86_64DebugUnitTest'))
unit=s/'unit-test-xml';unit.mkdir()
for p in (g/'app/build/test-results/testX86_64DebugUnitTest').glob('*.xml'):shutil.copy2(p,unit/p.name)
run('product-build',gradle(':app:assembleX86_64Debug'))
run('test-build',gradle(':app:assembleX86_64DebugAndroidTest'))
files=[]
for kind,path,package in [('main',g/'app/build/outputs/apk/x86_64/debug/app-x86_64-debug.apk','com.solosoul.app'),('test',g/'app/build/outputs/apk/androidTest/x86_64/debug/app-x86_64-debug-androidTest.apk','com.solosoul.app.test')]:
 copy=s/path.name;shutil.copy2(path,copy)
 run(kind+'-badging',[str(sdk/'build-tools/35.0.0/aapt2.exe'),'dump','badging',str(copy)],s)
 assert f"package: name='{package}'" in (s/(kind+'-badging.stdout.log')).read_text()
 run(kind+'-signature',[str(jdk/'bin/java.exe'),'-jar',str(sdk/'build-tools/35.0.0/lib/apksigner.jar'),'verify','--verbose',str(copy)],s)
 files.append(dict(kind=kind,source=str(path),copy=str(copy),sha256=sha(copy),bytes=copy.stat().st_size))
with zipfile.ZipFile(old['files'][0]['copy']) as previous,zipfile.ZipFile(files[0]['copy']) as current:
 names=sorted(n for n in previous.namelist() if n.startswith(('assets/','lib/')) and not n.endswith('/'))
 assert names==sorted(n for n in current.namelist() if n.startswith(('assets/','lib/')) and not n.endswith('/'))
 payloads={n:hashlib.sha256(current.read(n)).hexdigest() for n in names}
 assert all(hashlib.sha256(previous.read(n)).hexdigest()==h for n,h in payloads.items())
 assert payloads['lib/x86_64/libsolo_soul.so']==old['librarySha256']
 save('unchanged-native-assets.json',dict(members=payloads,allPreviousBytesMatched=True,librarySha256=old['librarySha256'],rustRebuildRequired=False,kotlinProductRebuilt=True))
save('current-apks.json',dict(accepted=True,librarySha256=old['librarySha256'],files=files,sourceFiles=sources,changedFiles=changed,scope='RF1126 production Kotlin legacy WebView theme compatibility and read-only native diagnostics',defaultAndroidProductCodeChanged=True,rustBuildRepeated=False,appAcceptance=False,deviceAcceptance=False,at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
print('Product and test APKs rebuilt; every original asset and native library byte preserved',flush=True)
