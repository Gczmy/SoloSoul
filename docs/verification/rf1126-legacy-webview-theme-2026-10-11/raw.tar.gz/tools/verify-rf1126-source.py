from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as E
r=Path('D:/SoloSoul');b=Path(__file__).parent.resolve();s=b/'rf1126-legacy-theme-build-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
art=load(s/'current-apks.json');path='tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt'
old=subprocess.run(['git','show','HEAD:'+path],cwd=r,capture_output=True,check=True).stdout.decode('utf-8').replace('\r\n','\n');new=(r/path).read_text(encoding='utf-8').replace('\r\n','\n')
def tail(text):return text[text.index('    private fun captureThemeFrame'):]
assert tail(old)==tail(new)
for n,h in art['sourceFiles'].items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h
counts={k:0 for k in ['tests','failures','errors','skipped']}
for p in (s/'unit-test-xml').glob('*.xml'):
 root=E.parse(p).getroot()
 for k in counts:counts[k]+=int(root.get(k,'0'))
assert counts==dict(tests=10,failures=0,errors=0,skipped=0)
receipts={n:load(s/(n+'.receipt.json')) for n in ['kotlin-unit-tests','product-build','test-build','main-badging','main-signature','test-badging','test-signature']}
assert all(x['exitCode']==0 and x['sourceUnchanged'] for x in receipts.values())
assert '> Task :app:testX86_64DebugUnitTest UP-TO-DATE' not in (s/'kotlin-unit-tests.stdout.log').read_text(encoding='utf-8')
proof=dict(task='RF-1126',base='7c8518740cf55930614244f4b1308c392c0384d5',sourceCount=len(art['sourceFiles']),changedFiles=art['changedFiles'],instrumentationOnlyReadOnlyNativeFeatureKeysAdded=True,originalCaptureAndAllThemeMethodsUnchanged=True,themeBudgetSeconds=45,renderBudgetSeconds=10,pixelTolerance=6,unit=counts,unitExecuted=True,receipts=receipts,frontendAndRustSourcesUnchanged=True,allNativeLibraryAndAssetBytesMatched=True)
with (s/'source-and-checks-proof.json').open('x',encoding='utf-8') as f:json.dump(proof,f,indent=2)
print('1837 sources frozen; real ten unit tests passed; original methods/draw/pixel guards unchanged; rebuilt product assets/JNI bytes preserved')
