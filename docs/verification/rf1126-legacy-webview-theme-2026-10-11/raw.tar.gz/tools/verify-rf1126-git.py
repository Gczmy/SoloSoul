from pathlib import Path
import hashlib,importlib.util,io,json,re,subprocess,sys,tarfile
from PIL import Image
r=Path('D:/SoloSoul');b=Path(__file__).parent.resolve()
mode=sys.argv[1];assert mode in ['staged','HEAD']
def git(*args):
 return subprocess.run(['git',*args],cwd=r,capture_output=True,check=True).stdout
def read(path):return git('show',(':'+path) if mode=='staged' else ('HEAD:'+path))
stem='rf1126-legacy-webview-theme-2026-10-11';folder='docs/verification/'+stem
source='tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidThemeInstrumentedTest.kt'
main='tauri/src-tauri/gen/android/app/src/main/java/com/solosoul/app/MainActivity.kt'
expected={source,main,'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md','docs/performance/RF-121-android-theme-diagnostics.md',folder+'.json',folder+'/.gitattributes',folder+'/index.json',folder+'/raw.tar.gz',folder+'/cleanup.json'}
names=set(git('diff','--cached','--name-only').decode().splitlines()) if mode=='staged' else set(git('diff-tree','--no-commit-id','--name-only','-r','HEAD').decode().splitlines())
assert names==expected,(names-expected,expected-names)
meta=json.loads(read(folder+'.json'));index=json.loads(read(folder+'/index.json'));cleanup=json.loads(read(folder+'/cleanup.json'))
data=read(folder+'/raw.tar.gz');digest=hashlib.sha256(data).hexdigest()
assert digest==meta['archive']['sha256']==index['archiveSha256']==cleanup['archiveSha256']
assert read(folder+'/.gitattributes').replace(b'\r\n',b'\n')==b'* -text -diff\n'
assert meta['nativeThemeTests']==dict(api35Passed=8,api35Failed=0,api31Passed=8,api31Failed=0,skipped=0)
assert meta['verifiedFrames']==48 and meta['verifiedPixels']==96
assert meta['productionThemeFixed'] is True and meta['fullRF121Accepted'] is meta['fullRF312Accepted'] is False
assert meta['actualStrategyGetterClaimed'] is False
assert cleanup['removedFiles']==97 and not cleanup['recursiveRemoval'] and cleanup['userProcessesTerminated']==0
assert len(cleanup['privatePairs'])==16 and all(v['contentsLinksAndModesMatched'] for v in cleanup['privatePairs'])
spec=importlib.util.spec_from_file_location('home',r/'tauri/scripts/android-home-native-regression.py');home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tf:
 assert len(tf.getmembers())==len(index['members'])==meta['archive']['members']
 assert set(tf.getnames())=={v['path'] for v in index['members']}
 def raw(path):return tf.extractfile(path).read()
 for v in index['members']:
  m=tf.getmember(v['path']);assert m.isfile() and not m.issym() and not m.islnk()
  payload=raw(v['path']);assert len(payload)==v['size'] and hashlib.sha256(payload).hexdigest()==v['sha256']
 staged=read(source).replace(b'\r\n',b'\n');archived=raw('final-source/'+source)
 assert staged==archived.replace(b'\r\n',b'\n') and hashlib.sha256(archived).hexdigest()==meta['finalSourceSha256']
 assert read(main).replace(b'\r\n',b'\n')==raw('final-source/'+main).replace(b'\r\n',b'\n')
 frames=0
 for api in [31,35]:
  prefix=f'raw/api{api}-legacy-theme-rf1126-20261011/'
  verification=json.loads(raw(prefix+'verification.json'));pixels=json.loads(raw(prefix+'pixel-verification.json'))
  assert verification['diagnosticComplete'] and pixels['adversarialRejected']==6
  assert pixels['accepted'] is True
  stop=json.loads(raw(f'raw/api{api}-host-rf1126-20261011/stop.receipt.json'))
  assert stop['ownedProcessExited'] and stop['settingsRestored'] and stop['noForceTermination']
  for row in verification['results']:
   assert row['restored'] and row['settingsRestored'] and row['externalRestored'] and row['sourcesAndApksUnchanged']
   assert row['nativePassed'] is True
   records=json.loads(raw(prefix+row['mode']+'/'+row['method']+'/theme-diagnostics.json'))['records']
   home.verify_native(raw(prefix+row['mode']+'/'+row['method']+'/instrumentation.stdout.log').decode('utf-8-sig'),row['method'])
   assert len(records)==3 and [v['darkMedia'] for v in records]==[False,True,False]
   for record in records:
    if record.get('result')=='timeout':continue
    f=record['renderCapture'];assert f['visualCallback'] and f['nextDrawCompleted'] and f['pixelMatched']
    assert f['requestId']==f['callbackRequestId'] and f['requestId']<=f['callbackAtNs']<=f['drawAtNs']<=f['captureAtNs']
    with Image.open(io.BytesIO(raw(prefix+row['mode']+'/'+row['method']+'/'+record['stage']+'.png'))) as png:
     assert png.format=='PNG' and png.size==(f['imageWidth'],f['imageHeight'])
     rgba=png.convert('RGBA')
     for p in f['pixels']:
      actual=list(rgba.getpixel((p['x'],p['y'])));assert actual[3]==255 and actual[:3]==p['actualRgb'] and p['matched']
      assert all(abs(a-e)<=6 for a,e in zip(actual[:3],p['expectedRgb']))
    frames+=1
 assert frames==48
ledger=read('docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md').decode('utf-8-sig')
assert '**306 / 316**' in ledger and '进行中：0' in ledger
rows=re.findall(r'^\| \d+ \| \[RF-[^\n]+$',ledger,re.M);assert len(rows)==316
assert any('[RF-1126]' in v and '[x] 完成' in v for v in rows)
assert all('[!] ' in next(v for v in rows if f'[RF-{n}]' in v) for n in ['112','121','312','1109'])
assert all('[ ] 待执行' in next(v for v in rows if f'[RF-{n}]' in v) for n in range(122,128))
receipt=dict(mode=mode,verifiedPaths=len(names),archiveMembers=len(index['members']),archiveSha256=digest,verifiedFrames=frames,goalComplete=False,commit=git('rev-parse','HEAD').decode().strip())
with (b/f'rf1126-{mode}-readback.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt))
