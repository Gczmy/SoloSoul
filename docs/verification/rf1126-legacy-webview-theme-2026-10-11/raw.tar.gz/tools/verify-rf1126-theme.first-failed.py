from pathlib import Path
import copy,importlib.util,json,sys
b=Path(__file__).parent.resolve();r=Path('D:/SoloSoul')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
spec=importlib.util.spec_from_file_location('pixels',b/'verify-rf1125-rendered-pixels.py');pixels=importlib.util.module_from_spec(spec);spec.loader.exec_module(pixels)
api=int(sys.argv[1]);assert api in [31,35]
c=b/f'api{api}-legacy-theme-rf1126-20261011';v=load(c/'verification.json')
assert v['diagnosticComplete'] and v['nativePassed'] and len(v['results'])==8
cases={'systemThemeFollowsLightDarkLight':('system','system'), 'explicitLightSurvivesSystemChanges':('light','light'), 'explicitDarkSurvivesSystemChanges':('dark','dark'), 'savedSchemesAndCustomAccentSurviveColdStartup':('system','custom-schemes')}
assert {(x['mode'],x['method']) for x in v['results']}=={(mode,method) for mode in ['supported','fallback'] for method in cases}
groups=[];first=None;first_image=None
for row in v['results']:
 assert row['nativePassed'] and row['restored'] and row['externalRestored'] and row['settingsRestored'] and row['sourcesAndApksUnchanged']
 d=c/row['mode']/row['method'];preset,prefix=cases[row['method']]
 pixels.home.verify_native((d/'instrumentation.stdout.log').read_text(encoding='utf-8-sig'),row['method'])
 raw=load(d/'theme-diagnostics.json');assert raw['runId']==row['runId'] and raw['preset']==preset
 records=raw['records'];assert [x['stage'] for x in records]==[prefix+'-light',prefix+'-dark',prefix+'-light-again']
 samples=[]
 for index,record in enumerate(records):
  dark=index==1;theme=('dark' if dark else 'light') if preset=='system' else preset
  assert record['theme']==theme and record['darkMedia'] is dark
  expected={'light':dict(background='#fafaf6',surface='#fdfcf9',foreground='#111111',accent='#5b7c99',materialInk='#000000'), 'dark':dict(background='#1f1c18',surface='#2a2620',foreground='#ffffff',accent='#7a9ab5',materialInk='#000000')}
  if prefix=='custom-schemes':expected={'light':dict(background='#f6f8fa',surface='#ffffff',foreground='#111111',accent='#112233',materialInk='#ffffff'), 'dark':dict(background='#1a211d',surface='#242d28',foreground='#ffffff',accent='#112233',materialInk='#ffffff')}
  assert all(record[k]==value for k,value in expected[theme].items())
  assert record['statusBarLight'] is record['navigationBarLight'] is (theme=='light')
  n=record['native'];assert n['api']==api and n['activityNight']==(32 if dark else 16)
  if api==31:
   assert n['supportsAlgorithmicDarkening'] is False and n['supportsForceDark'] is n['supportsForceDarkStrategy'] is True
   assert n['forceDarkStrategy']==1 and n['forceDark']==(2 if dark else 0)
  else:assert n['supportsAlgorithmicDarkening'] is True and n['forceDark']==1
  image=d/(record['stage']+'.png');samples.append(pixels.verify_record(record,image))
  if first is None:first=record;first_image=image
 groups.append(dict(mode=row['mode'],method=row['method'],nativePassed=True,samples=samples))
mutations=[lambda x:x['renderCapture'].__setitem__('callbackRequestId',0),lambda x:x['renderCapture'].__setitem__('nextDrawCompleted',False),lambda x:x['renderCapture']['stateAtCapture']['native'].__setitem__('webViewIdentity',0),lambda x:x['renderCapture']['pixels'][0].__setitem__('actualRgb',[0,0,0]),lambda x:x['renderCapture']['stateAtCapture']['render']['points'][0].__setitem__('x',1e6),lambda x:x.__setitem__('surface','#000000')]
for mutate in mutations:
 changed=copy.deepcopy(first);mutate(changed)
 try:pixels.verify_record(changed,first_image)
 except (AssertionError,KeyError,ValueError):pass
 else:raise AssertionError('Tampered actual frame incorrectly accepted')
result=dict(api=api,accepted=True,nativePassed=8,nativeFailed=0,skipped=0,verifiedFrames=24,verifiedPixels=48,adversarialRejected=6,groups=groups,fullRF121Accepted=False,fullRF312Accepted=False,physicalDeviceAccepted=False,performanceAccepted=False)
with (c/'pixel-verification.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
print(json.dumps(dict(api=api,accepted=True,nativePassed=8,verifiedFrames=24,verifiedPixels=48)))
