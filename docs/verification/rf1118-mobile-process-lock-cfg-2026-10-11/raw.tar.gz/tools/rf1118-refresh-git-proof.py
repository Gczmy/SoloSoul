from pathlib import Path
import hashlib,io,json,subprocess,tarfile
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1118-checks-20261011';fix=checks/'git-line-ending-review';stem='rf1118-mobile-process-lock-cfg-2026-10-11';out=root/'docs/verification'/stem
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
source=root/'tauri/crates/solosoul-core/src/process_lock.rs';compiled=source.read_bytes();git=subprocess.check_output(['git','show',':tauri/crates/solosoul-core/src/process_lock.rs'],cwd=root)
assert compiled!=git and compiled.replace(b'\r\n',b'\n')==git
assert sha(compiled)==load(checks/'checks-complete.json')['sourceSha256']
note={'action':'Initial staged verification stopped before commit on strict raw-byte comparison','actualWorkingBytes':len(compiled),'actualStagedBytes':len(git),'actualCRLFCount':compiled.count(b'\r\n'),'rawEquality':False,'LFNormalizedEquality':True,'compiledSourceChanged':False,'testsRerun':False,'oldVerifierAndArchivePreserved':True,'repair':'Keep exact compiled bytes in executed-source archive; compare Git canonical LF bytes after only CRLF normalization. No other byte differences accepted.'}
(fix/'failure-review.json').write_text(json.dumps(note,indent=2)+'\n',encoding='utf8')
files={}
def add(p,n):
    assert p.is_file() and not p.is_symlink() and not(p.lstat().st_file_attributes&0x400) and n not in files
    files[n]=p
for p in checks.rglob('*'):
    if p.is_file():add(p,'checks/'+p.relative_to(checks).as_posix())
for n in ['rf1118-register.py','rf1118-run-checks.py','rf1118-archive-close.py','rf1118-refresh-git-proof.py','rf1118-verify-git.py']:add(w/n,'tools/'+n)
add(root/'build/android-native-feasibility-20261010/android-process-lock-unused-warning.json','original-warning/android-process-lock-unused-warning.json')
add(source,'executed-source/process_lock.rs')
members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as t:
    for n,p in sorted(files.items()):
        b=p.read_bytes();m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b));members.append({'path':n,'bytes':len(b),'sha256':sha(b)})
with tarfile.open(out/'raw.tar.gz','r:gz') as t:
    assert t.getnames()==[v['path'] for v in members]
    for v in members:
        b=t.extractfile(v['path']).read();assert len(b)==v['bytes'] and sha(b)==v['sha256']
index={'task':'RF-1118','archiveSha256':sha((out/'raw.tar.gz').read_bytes()),'archiveBytes':(out/'raw.tar.gz').stat().st_size,'members':members,'allMembersReadbackVerified':True}
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf8')
p=root/'docs/verification'/(stem+'.json');summary=load(p);summary['archive']=index;summary['gitLineEndingReview']=note;p.write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
p=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=p.read_text(encoding='utf8');assert s.count('[35份原件索引](verification/'+stem+'/index.json)')==1
s=s.replace('[35份原件索引](verification/'+stem+'/index.json)','['+str(len(members))+'份原件索引](verification/'+stem+'/index.json)')
s+='\n- RF-1118提交前第一次源码raw字节校验停止：已编译Rust文件2759字节、76个CRLF，Git暂存为2683字节LF。完整CRLF→LF归一后逐字节相同，未修改或重编执行源码；保留首次校验工具、原35成员归档/索引/摘要及失败说明。新的校验分别要求working与编译原件raw相同、Git仅按LF规范化后相同，不把raw相等声明为true。重新归档全部原件并回读核验后才提交。\n'
p.write_text(s,encoding='utf8',newline='\n')
print('Refreshed',len(members),'members; exact compiled bytes preserved; canonical Git LF parity verified')
