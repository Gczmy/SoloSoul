from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1118-checks-20261011';android=root/'build/android-native-feasibility-20261010';desktop=root/'build/rf312-maintenance-20261009'
phase=sys.argv[1];assert phase in ['red','green']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,v):
    with (checks/name).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
source=root/'tauri/crates/solosoul-core/src/process_lock.rs';before=source.read_bytes()
env=os.environ.copy();env.update(TEMP=str(android/'tmp'),TMP=str(android/'tmp'),CARGO_HOME=str(android/'cargo-home'),CARGO_TARGET_DIR=str(android/'cargo-target'),CARGO_BUILD_JOBS='1',RUSTUP_HOME=str(android/'rustup'),RUSTUP_TOOLCHAIN='1.96.0')
toolchain=android/'rustup/toolchains/1.96.0-x86_64-pc-windows-msvc/bin';ndk=android/'sdk/ndk/27.0.12077973/toolchains/llvm/prebuilt/windows-x86_64/bin'
env['PATH']=str(toolchain)+';'+env.get('PATH','')
env['CARGO_TARGET_X86_64_LINUX_ANDROID_LINKER']=str(ndk/'x86_64-linux-android28-clang.cmd')
env['CC_x86_64_linux_android']=str(ndk/'x86_64-linux-android28-clang.cmd')
env['AR_x86_64_linux_android']=str(ndk/'llvm-ar.exe')
env['RUSTC']=str(toolchain/'rustc.exe');env.pop('PDFIUM_LIBRARY_PATH',None)
def run(name,cmd,e):
    start=time.monotonic()
    with (checks/(name+'.stdout.log')).open('xb') as out,(checks/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=root/'tauri',env=e,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',{'pid':p.pid,'command':cmd});print(name,'PID',p.pid,flush=True);code=p.wait()
    assert source.read_bytes()==before,'Product source changed during checks'
    save(name+'.receipt.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code,'pid':p.pid,'command':cmd,'elapsedSeconds':time.monotonic()-start,'sourceSha256':sha(source),'sourceUnchanged':True,'cargoHome':e['CARGO_HOME'],'targetDirectory':e['CARGO_TARGET_DIR'],'temp':e['TEMP'],'target': 'x86_64-linux-android' if 'android' in name else 'x86_64-pc-windows-msvc'})
    return code
save(phase+'-toolchain.json',{'androidRustc':str(toolchain/'rustc.exe'),'rustcSha256':sha(toolchain/'rustc.exe'),'androidCargo':str(toolchain/'cargo.exe'),'cargoSha256':sha(toolchain/'cargo.exe'),'linker':str(ndk/'x86_64-linux-android28-clang.cmd'),'linkerSha256':sha(ndk/'x86_64-linux-android28-clang.cmd'),'privateAndroidClippyAvailable':(toolchain/'cargo-clippy.exe').exists(),'validation':'Real Android rustc -D warnings; Windows Clippy remains separate','sourceSha256':sha(source)})
cmd=[str(toolchain/'cargo.exe'),'rustc','--locked','--offline','-p','solosoul-core','--lib','--target','x86_64-linux-android','--','-D','warnings']
code=run(phase+'-android',cmd,env)
if phase=='red':
    text=(checks/'red-android.stderr.log').read_text(encoding='utf8');assert code!=0 and 'unused variable: `lock_path`' in text,text[-5000:]
    print('Actual Android strict compiler reproduces lock_path failure',flush=True)
else:
    assert code==0
    denv=os.environ.copy();denv.update(TEMP=str(desktop/'tmp'),TMP=str(desktop/'tmp'),CARGO_HOME=str(desktop/'cargo-home'),CARGO_TARGET_DIR=str(desktop/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(desktop/'ort-cache'))
    denv['PDFIUM_LIBRARY_PATH']=str(root/'tauri/src-tauri/resources/pdfium/pdfium.dll')
    assert run('format',['cargo','fmt','--all','--','--check'],denv)==0
    assert run('windows-clippy',['cargo','clippy','--locked','-p','solosoul-core','--lib','--','-D','warnings'],denv)==0
    assert run('windows-lock-tests',['cargo','test','--locked','-p','solosoul-core','--lib','process_lock::','--','--nocapture'],denv)==0
    save('checks-complete.json',{'success':True,'sourceSha256':sha(source),'androidTarget':'x86_64-linux-android','iosCompilerExecuted':False,'defaultLockPolicyUnchanged':True})
    print('Android strict compilation and Windows lock regression terminal',flush=True)
