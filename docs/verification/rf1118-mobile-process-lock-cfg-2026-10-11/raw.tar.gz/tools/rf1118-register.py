from pathlib import Path
import datetime,hashlib,json
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1118-checks-20261011';checks.mkdir(exist_ok=False)
p=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=p.read_text(encoding='utf8');(checks/'ledger-before.md').write_bytes(p.read_bytes())
source=root/'tauri/crates/solosoul-core/src/process_lock.rs';(checks/'process_lock-before.rs').write_bytes(source.read_bytes())
assert '55 项' in s or '| P1 |' in s
assert s.count('已关闭：**297 / 307**；实际修复（已关闭）：297；')==1
s=s.replace('已关闭：**297 / 307**','已关闭：**297 / 308**').replace('暂缓：0；进行中：0；待执行：6。','暂缓：0；进行中：1；待执行：6。')
start=s.index('- 当前处理：');end=s.index('\n',start);s=s[:start]+'- 当前处理：**RF-1118：ProcessLock的桌面锁路径声明与桌面实现使用一致cfg，消除Android unused variable警告**。'+s[end:]
s=s.replace('RF-1116、RF-1117（','RF-1116、RF-1117、RF-1118（')
old='| 307 | [RF-1117](#rf-1117) | P2 | 排除历史父PID复用下不可读旧子进程的快照误判 | 无（RF-1116启动门禁失败归因） | [x] 完成 |';assert s.count(old)==1
s=s.replace(old,old+'\n| 308 | [RF-1118](#rf-1118) | P2 | 移动端不再构造仅桌面消费的进程锁路径 | 无（Android实编译unused variable警告） | [~] 进行中 |')
marker='\n## 7. 每项执行记录模板';assert s.count(marker)==1
card='''
### RF-1118

**移动端不再构造仅桌面消费的进程锁路径** · P2 · 来源：实际Android编译警告

- **入口：**`tauri/crates/solosoul-core/src/process_lock.rs`的acquire局部变量。
- **现状：**lock_path在共同路径构造，仅桌面cfg块使用；实际Android编译已报告unused_variables。共享create_dir_all及移动端占位锁不应改变。
- **执行：**仅给局部lock_path声明增加与现有桌面锁实现相同的cfg；不改跨进程排他策略或任何依赖。
- **验收：**当前Android x86_64真目标编译`-D warnings`红/绿，Windows严格Core Clippy、现有锁互斥/Drop释放测试及格式检查。无新增复述实现测试，无APK/界面行为声明；iOS仅源级同cfg，不声称本机iOS编译。保留源码/工具链/日志证据，独立本地提交不推送。
'''
s=s.replace(marker,'\n'+card+marker)
# Count summary is a separate explicit table row.
lines=s.splitlines();print('\n'.join(line for line in lines if ('总计' in line or '| P2 ' in line) and len(line)<180))
p.write_text(s,encoding='utf8',newline='\n')
(checks/'registration.json').write_text(json.dumps({'task':'RF-1118','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':'bc5c531a7','source':str(source),'beforeSha256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2),encoding='utf8')
print('Registered RF-1118: one active issue')
