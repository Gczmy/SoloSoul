from pathlib import Path
import datetime,hashlib,io,json,re,tarfile
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1118-checks-20261011';source=root/'tauri/crates/solosoul-core/src/process_lock.rs'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(checks/'checks-complete.json')['success']
red=load(checks/'red-android.receipt.json');assert red['exitCode']!=0
assert 'unused variable: `lock_path`' in (checks/'red-android.stderr.log').read_text()
names=['green-android','format','windows-clippy','windows-lock-tests'];receipts={n:load(checks/(n+'.receipt.json')) for n in names}
assert all(v['exitCode']==0 and v['sourceUnchanged'] for v in receipts.values())
assert 'unused variable: `lock_path`' not in (checks/'green-android.stderr.log').read_text()
tests=(checks/'windows-lock-tests.stdout.log').read_text();assert 'test process_lock::tests::test_acquire_and_drop_releases_lock ... ok' in tests
counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',tests);assert counts==[('1','0','0')]
before=(checks/'process_lock-before.rs').read_bytes();after=source.read_bytes()
expected=before.replace(b'        let lock_path = base_path.join(".lock");',b'        #[cfg(not(any(target_os = "android", target_os = "ios")))]\r\n        let lock_path = base_path.join(".lock");')
assert expected.replace(b'\r\n',b'\n')==after.replace(b'\r\n',b'\n'),'Only cfg attribute may change'
parent=load(w/'rf1117-checks-20261011/sources.json');current={p:sha(root/p) for p in parent}
changed=[p for p,h in parent.items() if current[p]!=h];assert changed==['tauri/crates/solosoul-core/src/process_lock.rs'],changed
save(checks/'source-provenance.json',{'base':'bc5c531a7','sourceCount':len(parent),'changedSources':changed,'allOtherSourcesUnchanged':True,'beforeSha256':hashlib.sha256(before).hexdigest(),'afterSha256':sha(source)})
save(checks/'sources.json',current)
stem='rf1118-mobile-process-lock-cfg-2026-10-11';out=root/'docs/verification'/stem;out.mkdir(exist_ok=False)
(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf8')
files={}
def add(p,name):
    assert p.is_file() and not p.is_symlink() and not(p.lstat().st_file_attributes&0x400) and name not in files
    files[name]=p
for p in checks.iterdir():
    if p.is_file():add(p,'checks/'+p.name)
for n in ['rf1118-register.py','rf1118-run-checks.py','rf1118-archive-close.py']:add(w/n,'tools/'+n)
add(root/'build/android-native-feasibility-20261010/android-process-lock-unused-warning.json','original-warning/android-process-lock-unused-warning.json')
add(source,'executed-source/process_lock.rs')
members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as tar:
    for n,p in sorted(files.items()):
        b=p.read_bytes();m=tarfile.TarInfo(n);m.size=len(b);tar.addfile(m,io.BytesIO(b));members.append({'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with tarfile.open(out/'raw.tar.gz','r:gz') as tar:
    assert tar.getnames()==[v['path'] for v in members]
    for v in members:
        b=tar.extractfile(v['path']).read();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
index={'task':'RF-1118','archiveSha256':sha(out/'raw.tar.gz'),'archiveBytes':(out/'raw.tar.gz').stat().st_size,'members':members,'allMembersReadbackVerified':True}
save(out/'index.json',index)
summary={'task':'RF-1118','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'accepted':True,'baseCommit':'bc5c531a7','sourceChanges':changed,'sourceCount':len(current),'afterSha256':sha(source),'androidCompilerTarget':'x86_64-linux-android','strictAndroidCompiler':'rustc -D warnings','androidClippyExecuted':False,'androidPrivateClippyAvailable':False,'windowsClippyExecuted':True,'windowsExistingLockTests':{'passed':1,'failed':0,'ignored':0},'red':red,'checks':receipts,'iosCompilerExecuted':False,'mobileSingleInstancePolicyUnchanged':True,'sharedCreateDirectoryUnchanged':True,'dependenciesChanged':False,'apkBuiltOrInstalled':False,'nativeUiAcceptance':False,'fullRF121Accepted':False,'fullRF312Accepted':False,'archive':index}
save(root/'docs/verification'/(stem+'.json'),summary)
p=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=p.read_text(encoding='utf8')
assert s.count('已关闭：**297 / 308**；实际修复（已关闭）：297；')==1
s=s.replace('已关闭：**297 / 308**；实际修复（已关闭）：297；','已关闭：**298 / 308**；实际修复（已关闭）：298；').replace('暂缓：0；进行中：1；待执行：6。','暂缓：0；进行中：0；待执行：6。')
start=s.index('- 当前处理：');end=s.index('\n',start);s=s[:start]+'- 当前处理：无；RF-1118已独立完成，完整RF-121/312及其他平台前置保持未完成。'+s[end:]
start=s.index('> 最后更新：');end=s.index('\n',start);s=s[:start]+'> 最后更新：2026-10-11（RF-1117启动归属修复与RF-1118移动端锁cfg完成；完整跨平台矩阵仍待验证）'+s[end:]
line='| 308 | [RF-1118](#rf-1118) | P2 | 移动端不再构造仅桌面消费的进程锁路径 | 无（Android实编译unused variable警告） | [~] 进行中 |';assert s.count(line)==1;s=s.replace(line,line.replace('[~] 进行中','[x] 完成'))
position=s.index('\n## 7. 每项执行记录模板',s.index('### RF-1118'));s=s[:position]+'\n- **结果：**真Android x86_64目标严格rustc编译修复前unused lock_path失败、增加同桌面cfg后通过；Windows Core Clippy、格式及现有排他/Drop释放测试通过。仅一个cfg属性改动，无新测试/依赖/锁策略改动；未声明iOS编译或Android APK/UI验收。\n'+s[position:]
s+=f'''

### RF-1118 移动端进程锁路径条件编译执行记录（2026-10-11，完成）

- 当前源码Android严格编译实际复现`unused variable: lock_path`，修复只给声明增加原桌面实现相同的`cfg(not(any(target_os = "android", target_os = "ios")))`。共享create_dir_all、移动端单实例占位、桌面打开锁文件/排他/Drop释放逻辑和所有依赖未变。
- 使用D盘既有Rust1.96.0与NDK27工具链，对真实x86_64-linux-android目标运行Core `cargo rustc --locked --offline ... -- -D warnings`，修复前失败、修复后通过。该私有Android工具链未装Clippy，使用严格rustc编译覆盖已确认unused_variables，不把它称为Android Clippy；Windows Core严格Clippy及workspace格式检查通过，现有process_lock排他/释放测试1项通过、0失败/忽略，无新增复述实现测试。
- 1834份源码相对bc5c531a7仅process_lock.rs变更；before/after回读归一换行证明仅新增cfg属性。编译缓存、TEMP与工具记录均写D盘，无APK构建/安装或界面验收，iOS仅相同cfg源级覆盖，本机未编译。完整RF-121/312、其他平台与既有阻塞保持。
- [结构化证据](verification/{stem}.json)、[{len(members)}份原件索引](verification/{stem}/index.json)及源码/编译器与linker SHA/红绿日志已归档，全成员回读长度/SHA通过。仅本项独立本地提交（以RF-1118检索），不推送。298/308关闭、4待验证、6待执行；整体goal active，后续可推进Android桌面专用同步方法及入口cfg警告。
'''
p.write_text(s,encoding='utf8',newline='\n')
print('RF-1118 closed; archived',len(members),'raw members;',index['archiveBytes'],'bytes')
