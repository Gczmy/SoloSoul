from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile
root=Path('D:/SoloSoul');w=Path(__file__).parent;ref=sys.argv[1];assert ref in ['staged','HEAD']
stem='docs/verification/rf1118-mobile-process-lock-cfg-2026-10-11';sha=lambda b:hashlib.sha256(b).hexdigest()
def blob(p):return subprocess.check_output(['git','show',(':'+p if ref=='staged' else 'HEAD:'+p)],cwd=root)
index=json.loads(blob(stem+'/index.json'));archive=blob(stem+'/raw.tar.gz')
assert sha(archive)==index['archiveSha256'] and len(archive)==index['archiveBytes']
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as t:
    assert t.getnames()==[v['path'] for v in index['members']]
    for v in index['members']:
        b=t.extractfile(v['path']).read();assert len(b)==v['bytes'] and sha(b)==v['sha256']
    p='tauri/crates/solosoul-core/src/process_lock.rs'
    assert blob(p)==t.extractfile('executed-source/process_lock.rs').read()==(root/p).read_bytes()
    manifest=json.loads(t.extractfile('checks/sources.json').read())
    assert all(sha((root/p).read_bytes())==h for p,h in manifest.items())
summary=json.loads(blob(stem+'.json'));assert summary['accepted'] and summary['archive']==index
report=blob('docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md').decode();assert '已关闭：**298 / 308**' in report
v={'ref':ref,'membersVerified':len(index['members']),'sourceEqualsExecuted':True,'allSourceHashesCurrent':True,'archiveSha256':index['archiveSha256'],'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()}
with (w/('rf1118-'+ref+'-verification.json')).open('x',encoding='utf8') as f:json.dump(v,f,indent=2)
print(json.dumps(v,indent=2))
