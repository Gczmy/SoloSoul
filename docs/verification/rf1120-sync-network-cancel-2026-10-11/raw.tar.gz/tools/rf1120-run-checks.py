from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1120-checks-20261011'; desktop=root/'build/rf312-maintenance-20261009';android=root/'build/android-native-feasibility-20261010'
phase=sys.argv[1];assert phase in ['red','green'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=['workers.rs','workers_tests.rs','transport.rs','manager.rs','mobile.rs','session.rs']; frozen={n:sha(root/'tauri/crates/solosoul-sync/src'/n) for n in paths}
env=os.environ.copy();env.update(TEMP=str(desktop/'tmp'),TMP=str(desktop/'tmp'),CARGO_HOME=str(desktop/'cargo-home'),CARGO_TARGET_DIR=str(desktop/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(desktop/'ort-cache'),PDFIUM_LIBRARY_PATH=str(root/'tauri/src-tauri/resources/pdfium/pdfium.dll'))
def save(n,v):
    with (checks/n).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def run(name,cmd,e):
    start=time.monotonic()
    with (checks/(name+'.stdout.log')).open('xb') as out,(checks/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=root/'tauri',env=e,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()));print(name,'PID',p.pid,flush=True);code=p.wait()
    assert all(sha(root/'tauri/crates/solosoul-sync/src'/n)==h for n,h in frozen.items())
    save(name+'.receipt.json',dict(exitCode=code,elapsedSeconds=time.monotonic()-start,pid=p.pid,command=cmd,sourceUnchanged=True,sources=frozen))
    return code
if phase=='red':
    cmd=['cargo','test','--locked','-p','solosoul-sync','--lib','workers::tests::network_interrupt_unblocks_real_socket_but_wait_still_joins_worker','--','--exact','--nocapture']
    code=run('red-network',cmd,env)
    assert code!=0 and 'Network read did not stop within 2s' in (checks/'red-network.stderr.log').read_text(encoding='utf8')
    print('Actual current network interruption violates bounded existing regression',flush=True)
else:
    assert run('format',['cargo','fmt','--all','--','--check'],env)==0
    assert run('windows-clippy',['cargo','clippy','--locked','-p','solosoul-sync','--lib','--','-D','warnings'],env)==0
    assert run('windows-sync-tests',['cargo','test','--locked','-p','solosoul-sync','--lib','--','--nocapture'],env)==0
    tool=android/'rustup/toolchains/1.96.0-x86_64-pc-windows-msvc/bin';ndk=android/'sdk/ndk/27.0.12077973/toolchains/llvm/prebuilt/windows-x86_64/bin'
    aenv=os.environ.copy();aenv.update(TEMP=str(android/'tmp'),TMP=str(android/'tmp'),CARGO_HOME=str(android/'cargo-home'),CARGO_TARGET_DIR=str(android/'cargo-target'),CARGO_BUILD_JOBS='1',RUSTUP_HOME=str(android/'rustup'),RUSTUP_TOOLCHAIN='1.96.0',RUSTC=str(tool/'rustc.exe'),CARGO_TARGET_X86_64_LINUX_ANDROID_LINKER=str(ndk/'x86_64-linux-android28-clang.cmd'),CC_x86_64_linux_android=str(ndk/'x86_64-linux-android28-clang.cmd'),AR_x86_64_linux_android=str(ndk/'llvm-ar.exe'))
    aenv['PATH']=str(tool)+';'+aenv.get('PATH','');aenv.pop('PDFIUM_LIBRARY_PATH',None)
    save('android-toolchain.json',dict(rustc=str(tool/'rustc.exe'),rustcSha256=sha(tool/'rustc.exe'),cargoSha256=sha(tool/'cargo.exe'),linkerSha256=sha(ndk/'x86_64-linux-android28-clang.cmd'),clippyAvailable=(tool/'cargo-clippy.exe').exists()))
    assert run('android-strict',[''+str(tool/'cargo.exe'),'rustc','--locked','--offline','-p','solosoul-sync','--lib','--target','x86_64-linux-android','--','-D','warnings'],aenv)==0
    save('checks-complete.json',dict(success=True,sources=frozen,iosCompilerExecuted=False,androidDeviceRun=False,nativeUiAccepted=False))
    print('RF1120 check queue terminal',flush=True)
