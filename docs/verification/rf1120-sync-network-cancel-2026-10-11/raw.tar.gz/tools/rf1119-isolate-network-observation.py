from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path('D:/SoloSoul');w=Path(__file__).parent;stage=w/'rf1119-network-observation-20261011';stage.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=load(w/'rf1119-checks-20261011/sources.json');exe=root/'build/rf312-maintenance-20261009/cargo-target/debug/deps/solosoul_sync-2e37b90faa6b7f05.exe'
assert all(sha(root/p)==h for p,h in sources.items())
assert exe.is_file() and not exe.is_symlink() and not(exe.lstat().st_file_attributes&0x400)
binaryHash=sha(exe)
def save(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
save(stage/'inputs.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':'5828b385f','sourceManifestSha256':sha(w/'rf1119-checks-20261011/sources.json'),'binary':str(exe),'binarySha256':binaryHash,'scope':'Existing exact loopback network interruption test; no source or UI changes','samplesRequested':3,'timeoutSeconds':240,'timeoutTermination':'Only retained Popen process handle; never process-name or reused-PID termination','originalParallelGroupDurationSeconds':186.92,'originalCaseReportedOver60Seconds':True})
results=[]
for i in range(1,4):
    sample=stage/f'sample-{i:03}';sample.mkdir();tmp=sample/'tmp';tmp.mkdir()
    env=os.environ.copy();env.update(TEMP=str(tmp),TMP=str(tmp));env.pop('PDFIUM_LIBRARY_PATH',None)
    cmd=[str(exe),'workers::tests::network_interrupt_unblocks_real_socket_but_wait_still_joins_worker','--exact','--nocapture','--test-threads=1']
    start=time.monotonic();timedOut=False
    with (sample/'stdout.log').open('xb') as out,(sample/'stderr.log').open('xb') as err:
        p=subprocess.Popen(cmd,cwd=root/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(sample/'live.json',{'pid':p.pid,'command':cmd,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()});print('Isolated loopback sample',i,'PID',p.pid,flush=True)
        try:code=p.wait(timeout=240)
        except subprocess.TimeoutExpired:
            timedOut=True;p.kill();code=p.wait()
    text=(sample/'stdout.log').read_text(encoding='utf8')
    success=not timedOut and code==0 and '1 passed; 0 failed; 0 ignored; 0 measured; 89 filtered out' in text
    assert sha(exe)==binaryHash and all(sha(root/n)==h for n,h in sources.items())
    result={'index':i,'pid':p.pid,'command':cmd,'exitCode':code,'elapsedSeconds':time.monotonic()-start,'timedOut':timedOut,'success':success,'sourceUnchanged':True,'binaryUnchanged':True,'terminatedUsingRetainedHandleOnly':timedOut}
    save(sample/'receipt.json',result);results.append(result);print(json.dumps(result),flush=True)
    if not success:break
save(stage/'results.json',{'samples':results,'samplesRequested':3,'allCompleted':len(results)==3,'allPassed':len(results)==3 and all(v['success'] for v in results),'sourceChanged':False,'uiChanged':False,'newDefectConfirmed':False,'scope':'Timing evidence only; original parallel slowdown remains un-attributed'})
print('Isolated existing-test observation terminal',flush=True)
