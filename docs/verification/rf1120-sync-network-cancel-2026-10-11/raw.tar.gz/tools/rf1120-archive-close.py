from pathlib import Path
import datetime,hashlib,io,json,re,tarfile
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1120-checks-20261011';final=checks/'retry1'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert load(final/'checks-complete.json')['success']
receipts={n:load(final/(n+'.receipt.json')) for n in ['format','windows-clippy','windows-sync-tests','android-strict']}
assert all(r['exitCode']==0 and r['sourceUnchanged'] for r in receipts.values())
red=load(checks/'red-network.receipt.json');assert red['exitCode']==101
assert 'Network read did not stop within 2s' in (checks/'red-network.stderr.log').read_text(encoding='utf8')
assert load(checks/'windows-sync-tests.receipt.json')['exitCode']==101
for name in ['write-detail','write-fixed-buffer','write-fixed-both-buffers']:
    assert load(checks/(name+'.receipt.json'))['exitCode']==101
    assert 'got Ok(Ok(()))' in (checks/(name+'.stderr.log')).read_text(encoding='utf8')
assert load(checks/'write-bounded-chunks.receipt.json')['exitCode']==0
text=(final/'windows-sync-tests.stdout.log').read_text(encoding='utf8')
assert re.search(r'test result: ok\. 93 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out',text)
required=['network_interrupt_unblocks_real_socket_but_wait_still_joins_worker','cancellation_interrupts_write_to_nonreading_peer','cancellable_receive_preserves_partial_frame_across_poll_timeouts','cancellable_receive_keeps_thirty_second_idle_limit','completed_stop_releases_listener_before_same_manager_restart','cancelled_direct_manager_stop_keeps_independent_join_and_restart_waits_for_it','disable_waits_real_worker_while_status_queries_remain_reachable','cancelled_disable_awaiter_keeps_independent_cleanup_and_next_wait_joins_it','reenable_cannot_overtake_cancelled_old_disable_cleanup','service_drop_after_cancelled_disable_keeps_root_until_actual_worker_and_cleanup_exit']
for n in required:assert re.search(r'(?m)^test [\w:]*'+re.escape(n)+r' \.\.\. ok\s*$',text),n
sourceHashes=load(final/'checks-complete.json')['sources']
for n,h in sourceHashes.items():
    p=root/'tauri/crates/solosoul-sync/src'/n
    assert sha(p)==h and sha(final/(n+'.executed'))==h
parent=load(w/'rf1119-checks-20261011/sources.json');current={p:sha(root/p) for p in parent}
changed=sorted(p for p,h in parent.items() if current[p]!=h)
expected=sorted('tauri/crates/solosoul-sync/src/'+n for n in sourceHashes)
assert changed==expected,(changed,expected)
save(checks/'sources.json',current)
save(checks/'source-provenance.json',dict(base=load(checks/'registration.json')['base'],sourceCount=len(current),changedSources=changed,allOtherProductionSourcesUnchanged=True,finalExecutedBytesVerified=True))
save(checks/'preparation-notes.json',dict(redSourceSnapshot='Original six baseline sources and actual red frozen SHA retained; exact strengthened red test bytes were not saved before green edits. Reconstruction attempts did not match and are not asserted as executed source.',intermediateSnapshots='First full green six files retained and SHA matched; subsequent isolated diagnostic phases retained actual frozen SHA and logs, without claiming all intermediate source byte captures.',partialGreen='91 passed / 1 failed; blocked-write fixture actually completed before cancellation; preserved as failure.',writeDiagnostics='Three early writes actually returned Ok; send and receive buffer changes alone were insufficient. Final 64KiB bounded writes passed true pending-write gate.',driverOrdering='All running tool sessions reached terminal before dependent product source edits.',preparationFailures='Read-only red source recovery rejected SHA matches; one relative Get-Content path and Python default encoding observations failed; no validation passes inferred from these.',scope='Windows shared data IO cancellation and Android compilation; no native UI/iOS/macOS device acceptance'))
stem='rf1120-sync-network-cancel-2026-10-11';out=root/'docs/verification'/stem;out.mkdir(exist_ok=False)
(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf8')
files={}
def add(p,n):
    assert p.is_file() and not p.is_symlink() and not(p.lstat().st_file_attributes&0x400) and n not in files
    files[n]=p
for p in checks.rglob('*'):
    if p.is_file():add(p,'checks/'+p.relative_to(checks).as_posix())
for name in ['rf1119-network-observation-20261011','network-phase-probe-20261011','network-shared-handle-probe-20261011']:
    for p in (w/name).rglob('*'):
        if p.is_file() and p.suffix in ['.json','.log']:add(p,'observations/'+name+'/'+p.relative_to(w/name).as_posix())
for p in sorted(w.glob('rf1120-*.py')):add(p,'tools/'+p.name)
for name in ['network-phase-probe.rs','network-phase-probe.py','network-shared-handle-probe.rs','network-shared-handle-probe.py','rf1119-isolate-network-observation.py','session-recheck-20261011-network.json']:add(w/name,'tools/'+name)
members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as t:
    for n,p in sorted(files.items()):
        data=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data));members.append(dict(path=n,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
save(out/'index.json',dict(task='RF-1120',archiveSha256=sha(out/'raw.tar.gz'),members=members))
with tarfile.open(out/'raw.tar.gz','r:gz') as t:
    assert set(t.getnames())==set(m['path'] for m in members)
    for m in members:
        data=t.extractfile(m['path']).read();assert len(data)==m['size'] and hashlib.sha256(data).hexdigest()==m['sha256']
summary=dict(task='RF-1120',status='complete',baseCommit=load(checks/'registration.json')['base'],at=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceCount=len(current),changedSources=changed,validation=dict(actualRedExitCode=101,finalReceipts=receipts,unitTestsPassed=93,unitTestsFailed=0,unitTestsIgnored=0,unitTestsFiltered=0,androidStrictCompiler=True,androidClippy=False,requiredCases=required),observedTimings=[line for line in text.splitlines() if line.startswith('RF1120 ')],archive=dict(path=stem+'/raw.tar.gz',sha256=sha(out/'raw.tar.gz'),memberCount=len(members),allMembersReadBackVerified=True),limits=['No native UI acceptance','No iOS/macOS runtime validation','No Android device/APK acceptance','No whole-stop 100ms promise; connection establishment and DB/attachment completion unchanged','Strengthened red test exact bytes were not captured; actual receipt SHA/logs and baseline preserved'],primaryReferences=['https://doc.rust-lang.org/std/net/struct.TcpStream.html','https://learn.microsoft.com/en-us/windows/win32/api/winsock/nf-winsock-shutdown'])
save(root/'docs/verification'/(stem+'.json'),summary)
ledger=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=ledger.read_text(encoding='utf8')
s=s.replace('> 最后更新：2026-10-11（RF-1119移动端同步worker条件编译完成；完整跨平台矩阵仍待验证）','> 最后更新：2026-10-11（RF-1120受管同步网络取消完成；完整跨平台矩阵仍待验证）')
s=s.replace('已关闭：**299 / 310**；实际修复（已关闭）：299；','已关闭：**300 / 310**；实际修复（已关闭）：300；').replace('暂缓：0；进行中：1；待执行：6。','暂缓：0；进行中：0；待执行：6。').replace('RF-1118、RF-1119（','RF-1118、RF-1119、RF-1120（')
start=s.index('- 当前处理：');end=s.index('\n',start);s=s[:start]+'- 当前处理：无；RF-1120已独立完成，完整RF-121/312及其他平台前置保持未完成。'+s[end:]
s=s.replace('| 无（独立回环计时实测） | [~] 进行中 |','| 无（独立回环计时实测） | [x] 完成 |')
s+='''

### RF-1120 受管同步网络取消执行记录（2026-10-11，完成）

- fresh桌面探针确认用户已解锁的调用者会话1为Active、InputDesktop可访问；console2不是本次验证前置。上项慢用例同一冻结测试程序独立三次各约123秒、全部通过，但只看最终通过不能验收中断时延。独立std::net探针的connect/accept均毫秒完成，shutdown返回Ok后read仍等5秒；Arc共享同一handle也三次复现，故没有进行无效的socket所有权改造。现有回归按2秒停止上限加强后实际exit101，失败清理仍等待真实worker退出。
- worker和受管transport共享取消信号，宽限结束时设置取消并请求shutdown。系统读写等待100毫秒、受管写入每次最多64KiB；轮询超时保留偏移，30秒无实际进展才报告通信超时。桌面/移动端入站及出站路径均接入，默认非受管transport、帧格式/Noise/SAS/信任、30秒停机宽限和真实worker/join/目录许可保持，未新增依赖。连接建立和数据库/附件收尾仍使用原规则，不承诺整体停止100毫秒完成。
- 首次完整回归91通过/1失败；真实非读取对端的整块32MB写入在取消前返回Ok。增加日志及分别限制发送/双端缓冲的三轮定向回归均真实exit101、仍返回Ok，不将其算通过。受管写入按64KiB分段后真实pending门禁与取消回归通过；最终完整93项全部通过、0失败/忽略/过滤，包括真实阻塞读/写及时取消、分段帧跨轮询超时、实际30秒空闲期限、网络返回后worker仍保留activity且wait待真实退出，以及全部既有停止/重启竞态。
- 最终Windows严格Sync Clippy、workspace格式及真实Android x86_64严格rustc编译全部exit0。私有Android工具链无Clippy，本项不称Android Clippy，无APK或设备验收。1834来源仅6份Sync Rust文件改变，其余来源保持；最终6份执行源码raw SHA冻结并回读。加强后的red测试文件未在green改动前另存原字节，保留其真实冻结SHA/日志与原始baseline；回建尝试SHA不匹配，明确不称其为执行原件。首轮完整green6文件已逐字保存，后续诊断保存实际SHA/日志，不声称全部中间源码快照存在。
- [结构化证据](verification/rf1120-sync-network-cancel-2026-10-11.json)及[原件索引](verification/rf1120-sync-network-cancel-2026-10-11/index.json)已归档，全成员回读长度/SHA。只本项独立本地提交（以RF-1120检索），不推送；300/310关闭、4待验证及6待执行，goal active。RF-112/121/312/1109、RF-122～127、其他平台运行和Windows完整原生矩阵仍未完成，后续可推进Android应用入口cfg警告与受控窗口补验。
'''
ledger.write_text(s,encoding='utf8',newline='\n')
print(json.dumps(dict(task='RF-1120',members=len(members),tests=93,archiveSha256=sha(out/'raw.tar.gz'),changedSources=changed)))
