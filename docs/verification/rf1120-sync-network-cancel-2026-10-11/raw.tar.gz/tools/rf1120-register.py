from pathlib import Path
import datetime, hashlib, json, subprocess
root=Path('D:/SoloSoul'); w=Path(__file__).parent; stage=w/'rf1120-checks-20261011';stage.mkdir(exist_ok=False)
paths=['workers.rs','workers_tests.rs','transport.rs','manager.rs','mobile.rs','session.rs']
for name in paths:
    p=root/'tauri/crates/solosoul-sync/src'/name
    (stage/(name+'.before')).write_bytes(p.read_bytes())
ledger=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md'; s=ledger.read_text(encoding='utf8');(stage/'ledger-before.md').write_bytes(ledger.read_bytes())
assert s.count('- 任务总数：**309**（P1：55；P2：253；P3：1）。')==1
s=s.replace('- 任务总数：**309**（P1：55；P2：253；P3：1）。','- 任务总数：**310**（P1：56；P2：253；P3：1）。').replace('已关闭：**299 / 309**','已关闭：**299 / 310**').replace('暂缓：0；进行中：0；待执行：6。','暂缓：0；进行中：1；待执行：6。')
start=s.index('- 当前处理：'); end=s.index('\n',start);s=s[:start]+'- 当前处理：**RF-1120：同步阻塞读写定期检查取消状态，保留30秒通信超时与真实worker join/目录许可**。'+s[end:]
line='| 309 | [RF-1119](#rf-1119) | P2 | 移动端不编译桌面worker重新开放与收尾等待方法 | 无（实际Android dead_code警告） | [x] 完成 |'; assert s.count(line)==1
s=s.replace(line,line+'\n| 310 | [RF-1120](#rf-1120) | P1 | Windows同步网络中断及时退出阻塞读写 | 无（独立回环计时实测） | [~] 进行中 |')
marker='\n## 7. 每项执行记录模板';assert s.count(marker)==1
s=s.replace(marker,'''
### RF-1120

**Windows同步网络中断及时退出阻塞读写** · P1 · 来源：RF-1119完整测试中的慢用例与独立socket分阶段复测

- **现状：**既有network_interrupt用例三次独立运行均通过，但各约123秒。另两种独立std::net探针的连接/accept均毫秒完成，shutdown返回Ok后阻塞read仍等5秒超时；同一handle的Arc共享也无法解决。本机现象不推断为所有Windows配置普遍行为。
- **执行：**worker共享取消信号，受管同步transport用短读写等待定期检查该信号；保留30秒无进展通信超时、完整帧偏移、默认非受管transport、网络shutdown及真实worker join。不得提前释放许可、abort worker、改协议或加入新依赖。
- **验收：**既有真实socket回归先按2秒停止上限失败，再验证实际transport在取消后及时返回，同时阻塞worker尾部证明许可仍持有且wait仍待真实退出；完整Sync现有回归、格式和Windows严格Clippy、真实Android严格编译通过。记录实测红绿、原探针/失败、全部来源与退出码；本项独立本地提交，不推送。无原生UI/其他OS设备验收声明。
'''+marker)
ledger.write_text(s,encoding='utf8',newline='\n')
(stage/'registration.json').write_text(json.dumps({'task':'RF-1120','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'paths':paths},indent=2)+'\n',encoding='utf8')
print('RF-1120 registered; 299/310; one active')
