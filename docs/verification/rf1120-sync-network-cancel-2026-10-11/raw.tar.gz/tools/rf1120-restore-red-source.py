from pathlib import Path
import hashlib,json
root=Path('D:/SoloSoul');stage=Path(__file__).parent/'rf1120-checks-20261011'
receipt=json.loads((stage/'red-network.receipt.json').read_text())
for name,expected in receipt['sources'].items():
    if name!='workers_tests.rs':
        data=(stage/(name+'.before')).read_bytes()
    else:
        s=(root/'tauri/crates/solosoul-sync/src'/name).read_text(encoding='utf8')
        s=s.replace('use std::net::TcpListener;','use std::io::Read;\nuse std::net::TcpListener;')
        prefix,s=s.split('async fn network_interrupt_unblocks_real_socket_but_wait_still_joins_worker() {',1)
        s,suffix=s.split('\n#[tokio::test]',1)
        s=s.replace('    let (server, _) = listener.accept().unwrap();','    let (mut server, _) = listener.accept().unwrap();\n    server\n        .set_read_timeout(Some(Duration::from_secs(5)))\n        .unwrap();')
        s=s.replace('            let mut transport = permit.transport(server).unwrap();','            permit.track_stream(&server).unwrap();')
        s=s.replace('            let result = transport.receive_message().map(|_| 0);','            let mut byte = [0u8; 1];\n            let result = server.read(&mut byte);')
        s=s.replace('    let waiting_workers = workers.clone();\n    let waiter = tokio::spawn(async move { waiting_workers.wait().await });\n    tokio::time::sleep(Duration::from_millis(20)).await;\n    let wait_returned_before_worker = waiter.is_finished();\n','')
        s=s.replace('    waiter.await.unwrap().unwrap();','    workers.wait().await.unwrap();')
        s=s.replace('    assert!(!wait_returned_before_worker, "wait released a live worker");\n','')
        s=s.replace('    assert!(interrupted\n        .unwrap()\n        .unwrap()\n        .unwrap_err()\n        .contains("Sync cancelled"));','    assert!(matches!(interrupted.unwrap().unwrap(), Ok(0) | Err(_)));')
        s=prefix+'async fn network_interrupt_unblocks_real_socket_but_wait_still_joins_worker() {'+s+'\n#[tokio::test]'+suffix
        data=s.encode()
        if hashlib.sha256(data).hexdigest()!=expected:
            data=s.replace('\n','\r\n').encode()
    if hashlib.sha256(data).hexdigest()!=expected:
        (stage/(name+'.reconstruction-candidate')).write_bytes(data)
    assert hashlib.sha256(data).hexdigest()==expected,(name,'Red source byte reconstruction mismatch')
    (stage/(name+'.red-executed')).write_bytes(data)
(stage/'red-source-reconstruction.json').write_text(json.dumps(dict(scope='Exact hash checked against actual red receipt; recovered after green edit, not captured before red execution',allSixMatched=True,productSourceModified=False),indent=2)+'\n',encoding='utf8')
print('All six red executed source bytes recovered and SHA matched actual receipt')
