use std::io::Read;
use std::net::{Shutdown, TcpListener, TcpStream};
use std::sync::{mpsc, Arc};
use std::time::{Duration, Instant};

fn main() {
    let start = Instant::now();
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let client = TcpStream::connect(listener.local_addr().unwrap()).unwrap();
    let (server, _) = listener.accept().unwrap();
    server.set_read_timeout(Some(Duration::from_secs(5))).unwrap();
    let server = Arc::new(server);
    let copy = Arc::clone(&server);
    let (entered_tx, entered_rx) = mpsc::channel();
    let worker = std::thread::spawn(move || {
        entered_tx.send(()).unwrap();
        let mut stream = server.as_ref();
        let mut byte = [0; 1];
        let result = stream.read(&mut byte);
        println!("read_result {:?} {:.6}", result, start.elapsed().as_secs_f64());
    });
    entered_rx.recv_timeout(Duration::from_secs(5)).unwrap();
    std::thread::sleep(Duration::from_millis(100));
    println!("before_shutdown {:.6}", start.elapsed().as_secs_f64());
    println!("shutdown_result {:?}", copy.shutdown(Shutdown::Both));
    worker.join().unwrap();
    println!("joined {:.6}", start.elapsed().as_secs_f64());
    drop(client);
}
