use std::io::Read;
use std::net::{Shutdown, TcpListener, TcpStream};
use std::sync::mpsc;
use std::time::{Duration, Instant};

fn phase(start: Instant, label: &str) {
    println!("{} {:.6}", label, start.elapsed().as_secs_f64());
}
fn main() {
    let start = Instant::now();
    phase(start, "start");
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    phase(start, "bound");
    let client = TcpStream::connect(listener.local_addr().unwrap()).unwrap();
    phase(start, "connected");
    let (mut server, _) = listener.accept().unwrap();
    phase(start, "accepted");
    server.set_read_timeout(Some(Duration::from_secs(5))).unwrap();
    let copy = server.try_clone().unwrap();
    let (entered_tx, entered_rx) = mpsc::channel();
    let worker = std::thread::spawn(move || {
        entered_tx.send(()).unwrap();
        phase(start, "reading");
        let mut byte = [0; 1];
        let result = server.read(&mut byte);
        println!("read_result {:?} {:.6}", result, start.elapsed().as_secs_f64());
    });
    entered_rx.recv_timeout(Duration::from_secs(5)).unwrap();
    std::thread::sleep(Duration::from_millis(100));
    phase(start, "before_shutdown");
    println!("shutdown_result {:?}", copy.shutdown(Shutdown::Both));
    phase(start, "after_shutdown");
    worker.join().unwrap();
    phase(start, "joined");
    drop(client);
    phase(start, "client_dropped");
}
