from pathlib import Path
import hashlib, json, os, subprocess, time
root = Path('D:/SoloSoul')
stage = Path(__file__).parent / 'network-shared-handle-probe-20261011'
stage.mkdir(exist_ok=False)
source = Path('D:/SoloSoul/build/rf121-theme-binding-20261010/network-shared-handle-probe.rs')
exe = stage / 'network-phase-probe.exe'
env = os.environ.copy()
env.update(TEMP=str(stage), TMP=str(stage))
results = []
commands = [('compile', ['rustc', '--edition=2021', str(source), '-o', str(exe)])]
for name, cmd in commands:
    with (stage / (name + '.stdout.log')).open('xb') as out, (stage / (name + '.stderr.log')).open('xb') as err:
        p = subprocess.Popen(cmd, cwd=root, env=env, stdout=out, stderr=err, stdin=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)
        code = p.wait()
    assert code == 0
for i in range(1, 4):
    start = time.monotonic()
    with (stage / f'sample-{i}.stdout.log').open('xb') as out, (stage / f'sample-{i}.stderr.log').open('xb') as err:
        p = subprocess.Popen([str(exe)], cwd=root, env=env, stdout=out, stderr=err, stdin=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)
        print('sample', i, 'PID', p.pid, flush=True)
        timeout = False
        try:
            code = p.wait(timeout=150)
        except subprocess.TimeoutExpired:
            timeout = True
            p.kill()
            code = p.wait()
    result = dict(index=i, pid=p.pid, exitCode=code, timedOut=timeout, elapsedSeconds=time.monotonic()-start)
    results.append(result)
    print(json.dumps(result), flush=True)
    print((stage / f'sample-{i}.stdout.log').read_text(), flush=True)
    if code != 0 or timeout:
        break
record = dict(scope='Isolated std::net phase probe; not product acceptance', productSourceModified=False, sourceSha256=hashlib.sha256(source.read_bytes()).hexdigest(), binarySha256=hashlib.sha256(exe.read_bytes()).hexdigest(), samples=results)
with (stage / 'results.json').open('x', encoding='utf8') as f:
    json.dump(record, f, indent=2)

