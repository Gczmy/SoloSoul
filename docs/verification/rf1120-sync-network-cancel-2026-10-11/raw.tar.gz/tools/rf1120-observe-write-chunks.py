from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
root=Path('D:/SoloSoul');w=Path(__file__).parent;checks=w/'rf1120-checks-20261011'; desktop=root/'build/rf312-maintenance-20261009';android=root/'build/android-native-feasibility-20261010'
phase='observe-write';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=['workers.rs','workers_tests.rs','transport.rs','manager.rs','mobile.rs','session.rs']; frozen={n:sha(root/'tauri/crates/solosoul-sync/src'/n) for n in paths}
env=os.environ.copy();env.update(TEMP=str(desktop/'tmp'),TMP=str(desktop/'tmp'),CARGO_HOME=str(desktop/'cargo-home'),CARGO_TARGET_DIR=str(desktop/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(desktop/'ort-cache'),PDFIUM_LIBRARY_PATH=str(root/'tauri/src-tauri/resources/pdfium/pdfium.dll'))
def save(n,v):
    with (checks/n).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
def run(name,cmd,e):
    start=time.monotonic()
    with (checks/(name+'.stdout.log')).open('xb') as out,(checks/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=root/'tauri',env=e,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()));print(name,'PID',p.pid,flush=True);code=p.wait()
    assert all(sha(root/'tauri/crates/solosoul-sync/src'/n)==h for n,h in frozen.items())
    save(name+'.receipt.json',dict(exitCode=code,elapsedSeconds=time.monotonic()-start,pid=p.pid,command=cmd,sourceUnchanged=True,sources=frozen))
    return code
code=run('write-bounded-chunks',['cargo','test','--locked','-p','solosoul-sync','--lib','transport::tests::cancellation_interrupts_write_to_nonreading_peer','--','--exact','--nocapture'],env)
print('Actual detail exit',code,flush=True)


