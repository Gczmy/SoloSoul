from pathlib import Path
import ctypes,hashlib,importlib.util,json,os,subprocess,time
from unittest.mock import patch
R=Path('D:/SoloSoul');W=Path(__file__).parent;S=W/'rf1128-wsl-link-probe-20261012';S.mkdir(exist_ok=False)
target=S/'published.json';target.write_bytes(b'{"publicSynthetic":true}\n');alias=S/'alias.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof={'task':'RF-1128','scope':'owned local fixture creation capability only; actual native NTFS file-symlink gate remains mandatory',
 'expectedNativeSymlinkTag':'0xa000000c','systemSettingsChanged':False,'privilegesChanged':False,'accepted':False}
try:
 command=['wsl.exe','-d','Ubuntu-22.04','--exec','/usr/bin/ln','-s','published.json','/mnt/d/SoloSoul/'+alias.relative_to(R).as_posix()]
 started=time.monotonic()
 with (S/'wsl.stdout.log').open('xb') as out,(S/'wsl.stderr.log').open('xb') as err:
  process=subprocess.Popen(command,cwd=R,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
  (S/'live.json').write_text(json.dumps({'pid':process.pid,'command':command})+'\n',encoding='utf-8')
  print('Owned WSL fixture creator live PID',process.pid,flush=True);code=process.wait()
 proof.update(command=command,exitCode=code,elapsedSeconds=time.monotonic()-started)
 assert code==0,'Existing WSL fixture creator failed'
 info=alias.lstat();tag=info.st_reparse_tag
 proof.update(reparseTag=hex(tag),attributes=info.st_file_attributes,windowsIsSymlink=alias.is_symlink())
 # A Linux-specific reparse tag would be additional coverage only, never a
 # substitute for the missing actual Windows file-symlink regression.
 assert tag==0xA000000C and alias.is_symlink(),'Not an actual standard Windows file symlink'
 assert alias.read_bytes()==target.read_bytes()
 proof['defaultWindowsReadFollowsSamePublicTarget']=True
 spec=importlib.util.spec_from_file_location('owned_json',R/'tauri/scripts/native-perf-owned-json.py')
 reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader)
 api=reader._api()
 with patch.object(api,'ReadFile',side_effect=AssertionError('Symbolic link content must not be read')) as read_file,patch.object(reader,'_api',return_value=api):
  try:reader.read_owned_json(alias)
  except (OSError,ValueError) as error:proof['readerRejected']={'class':type(error).__name__,'reason':str(error)}
  else:raise AssertionError('Owned reader followed a symbolic link')
  assert read_file.call_count==0;proof['readerContentReadCalls']=0
 proof['accepted']=True
except Exception as error:
 proof['errorClass']=type(error).__name__;proof['error']=str(error)
finally:
 # Unlink only this exact newly created alias; never follow it or recurse.
 if alias.is_symlink() or os.path.lexists(alias):
  assert alias.parent.resolve()==S.resolve();alias.unlink();proof['ownedAliasUnlinked']=True
 proof['publicTargetUnchanged']=target.read_bytes()==b'{"publicSynthetic":true}\n'
 (S/'result.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(proof),flush=True)
raise SystemExit(0 if proof['accepted'] else 1)
