from pathlib import Path
import datetime,hashlib,importlib.util,json,os,re,subprocess,time
R=Path('D:/SoloSoul');S=Path(__file__).parent;B=S.parent;O=S/'native';O.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
spec=importlib.util.spec_from_file_location('restore',R/'tauri/scripts/android-home-native-regression.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
sourceSha=m.digest(R/'tauri/scripts/android-home-native-regression.py')
inputs=load(B/'rf312-fixed-vault-owned-server-cohort-20261012/inputs.json');env=os.environ.copy();env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',PYTHONUTF8='1')
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
for expected in [load(B/'owned-adb-nodaemon-20261012/live.json')['identity'],next(x for x in load(B/'api31-software-rf312-fixed-vault-20261012/owned-processes-after-launch.json') if x['ProcessId']==7560)]:
 current=json.loads(subprocess.check_output([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {expected['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json"],text=True))
 for key in ['Name','ProcessId','ExecutablePath','CommandLine']:assert current[key]==expected[key]
 assert datetime.datetime.fromisoformat(current['CreationDate'])==datetime.datetime.fromisoformat(expected['CreationDate'])
ledger=[]
def adb(*args,**kwargs):
 p=subprocess.run([str(B/'sdk/platform-tools/adb.exe'),'-H','localhost','-P','5049','-s','emulator-5586',*args],capture_output=True,timeout=45,env=env)
 ledger.append({'command':list(args),'exitCode':p.returncode,'stdoutSha256':sha(p.stdout),'stderrSha256':sha(p.stderr)})
 (O/'commands.json').write_text(json.dumps(ledger,indent=2)+'\n',encoding='utf-8')
 if p.returncode:(O/f'failed-{len(ledger)}.stderr.log').write_bytes(p.stderr)
 p.check_returncode();return p
read=lambda *args:adb(*args).stdout.decode().strip()
def archive(path):
 assert not path.exists();path.write_bytes(adb('exec-out','run-as',m.APP,'tar','-cf','-','.').stdout)
 os.chmod(path,0o600)
def package(pkg):
 path=read('shell','pm','path',pkg);assert re.fullmatch(r'package:/data/app/(?:[A-Za-z0-9_~+=.-]+/){1,2}base\.apk',path)
 data=adb('exec-out','cat',path.removeprefix('package:')).stdout
 dump=read('shell','dumpsys','package',pkg)
 uid=re.findall(r'^\s*userId=(\d+)\s*$',dump,re.M);flags=re.findall(r'^\s*pkgFlags=\[([^\]]*)\]',dump,re.M);assert len(uid)==len(flags)==1
 return {'sha256':sha(data),'bytes':len(data),'uid':int(uid[0]),'debuggable':'DEBUGGABLE' in flags[0].split()}
assert read('get-state')=='device' and read('emu','avd','name').splitlines()[0]=='SoloSoul_RF121_API31_20261010'
packages={'main':package(m.APP),'test':package(m.APP+'.test')}
assert packages['main']['sha256']==inputs['originalDebug']['sha256'] and packages['test']['sha256']==inputs['originalTest']['sha256'] and packages['main']['debuggable']
adb('shell','am','force-stop',m.APP)
assert not any(x.split() and (x.split()[-1]==m.APP or x.split()[-1].startswith(m.APP+':')) for x in read('shell','ps','-A','-o','PID,NAME').splitlines())
backup=O/'private-data-before.tar';archive(backup);before=m.inventory(backup,require_empty=True);rootmode=read('shell','run-as',m.APP,'stat','-c','%a','.');blur=read('shell','settings','get','global','disable_window_blurs')
assert len(before)==216
sentinel='.rf1134-staging-'+__import__('uuid').uuid4().hex+'.txt'
assert not read('shell','run-as',m.APP,'ls','-A').splitlines().count(sentinel)
adb('shell','run-as',m.APP,'touch',sentinel)
active=O/'private-data-active.tar';archive(active);activeInventory=m.inventory(active,require_empty=True);assert len(activeInventory)==217
rows=[];owned={};recovered=False
try:
 for case in ['push-disconnect','chmod-disconnect','corrupt-staged-tar']:
  C=O/case;C.mkdir();report={'backup':{'sha256':m.digest(backup)},'restored':False};events=[]
  def fault_adb(*args,**kwargs):
   events.append(list(args))
   if args[0]=='push':
    assert Path(args[1]).resolve()==backup.resolve() and re.fullmatch(r'/data/local/tmp/fe2-private-backup-[a-f0-9]{32}\.tar',args[2])
    owned[args[2]]=m.digest(backup)
    if case=='push-disconnect':raise ConnectionError('controlled transport failure before upload; no ADB service stop')
   if args[:2]==('shell','chmod') and case=='chmod-disconnect':raise ConnectionError('controlled transport failure before chmod; no ADB service stop')
   result=adb(*args,**kwargs)
   if args[:2]==('shell','chmod') and case=='corrupt-staged-tar':
    remote=args[3];assert remote in owned and read('shell','sha256sum',remote).split()[0]==owned[remote]
    corrupt=C/'public-corrupt-staging-byte.bin';corrupt.write_bytes(b'x')
    adb('push',str(corrupt),remote);owned[remote]=sha(b'x')
   return result
  error=None
  try:m.restore_private_data(fault_adb,read,archive,backup,before,rootmode,C,report)
  except (ConnectionError,RuntimeError) as e:error=str(e)
  assert error and not report['restored'] and not report['restoreStaging']['ready'] and not report['restoreStaging']['privateRootClearAttempted']
  assert not any(x[:5]==['shell','run-as',m.APP,'rm','-rf'] for x in events)
  snapshot=C/'private-data-unchanged.tar';archive(snapshot);assert m.inventory(snapshot,require_empty=True)==activeInventory
  remote=report['restoreStaging']['remotePath']
  if case!='push-disconnect':
   assert read('shell','sha256sum',remote).split()[0]==owned[remote];adb('shell','rm','--',remote)
  rows.append({'case':case,'error':error,'directoryInventoryExactlyUnchanged':True,'privateClearCommandIssued':False,'localBackupUnchanged':m.digest(backup)==report['backup']['sha256'],'staging':report['restoreStaging'],'faultInjectionExplicit':True})
 C=O/'success';C.mkdir();report={'backup':{'sha256':m.digest(backup)},'restored':False}
 m.restore_private_data(adb,read,archive,backup,before,rootmode,C,report)
 assert report['restored'] and m.inventory(C/'private-data-restored.tar',require_empty=True)==before
 recovered=True;rows.append({'case':'success','report':report,'all216EntriesExactlyRestored':True})
 assert package(m.APP)==packages['main'] and package(m.APP+'.test')==packages['test']
 assert read('shell','settings','get','global','disable_window_blurs')==blur
 assert m.digest(R/'tauri/scripts/android-home-native-regression.py')==sourceSha
 result={'accepted':True,'currentRepositoryHelperExecuted':True,'sourceSha256':sourceSha,'cases':rows,'originalPackages':packages,'privateOriginalEntries':216,'activeOwnedFixtureEntries':217,
 'originalPrivateContentsLinksModesAndRootModeRestored':True,'systemBlurAndPackageBytesUidUnchanged':True,'controlledFaultsDoNotClaimRealServerDisconnect':True,'originalActualDisconnectFailureRetainedInRF312Archive':True,'noApkOrRustRebuildRequiredForHostOnlyChange':True,'performanceOrFullPlatformAccepted':False}
 (O/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'nativeCases':4,'stageFaultsPreservedRoot':3,'all216OriginalEntriesRestored':True,'accepted':True}),flush=True)
finally:
 if not recovered:
  # Stop this script without any next mutation; original full backup and uploaded
  # staging are retained for the same exact recovery procedure if needed.
  (O/'recovery-required.json').write_text(json.dumps({'originalBackup':str(backup),'originalBackupSha256':m.digest(backup),'ownedRemoteFiles':owned,'sentinel':sentinel,'noFurtherTestAuthorizedByThisScript':True})+'\n',encoding='utf-8')
