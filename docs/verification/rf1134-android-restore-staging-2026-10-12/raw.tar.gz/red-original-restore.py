from pathlib import Path
import importlib.util,textwrap,unittest
S=Path(__file__).parent
spec=importlib.util.spec_from_file_location('old',S/'driver.before.py');old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
body=(S/'original-restore-body.py').read_text(encoding='utf-8')
exec('def restore_private_data(adb, read, archive, backup, before, root_mode, output, report):\n'+textwrap.indent(body,'    '),old.__dict__)
spec=importlib.util.spec_from_file_location('currenttests',Path('D:/SoloSoul/tauri/scripts/test_android_home_native_regression.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.runner=old
suite=unittest.TestSuite(m.PrivateRestoreStagingTests(n) for n in ['test_stage_faults_preserve_current_private_contents','test_changed_local_backup_is_rejected_before_upload_or_clear'])
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
