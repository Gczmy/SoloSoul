from pathlib import Path
import json,os,subprocess,time
S=Path(__file__).parent
command=json.loads((S/'full-home-inputs.json').read_text(encoding='utf-8'))['command']
env=os.environ.copy();env.update(ANDROID_ADB_SERVER_PORT='5049',ADB_SERVER_SOCKET='tcp:localhost:5049',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',TEMP=str(S/'tmp'),TMP=str(S/'tmp'))
began=time.monotonic()
with (S/'full-home.stdout.log').open('xb') as out,(S/'full-home.stderr.log').open('xb') as err:
 p=subprocess.Popen(command,env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
 (S/'full-home.live.json').write_text(json.dumps({'pid':p.pid,'command':command})+'\n',encoding='utf-8')
 print('Current repository full-home caller live PID',p.pid,flush=True);code=p.wait()
r=json.loads((S/'full-home/report.json').read_text(encoding='utf-8'))
receipt={'exitCode':code,'elapsedSeconds':time.monotonic()-began,'passed':r['passed'],'restored':r['restored'],'stages':r.get('stages',[]),'restoreStaging':r.get('restoreStaging'),'source':'current repository default caller','mainAndNativeHomeTestApksReusedWithExactSourceProvenance':True,'wholePerformanceOrPlatformAccepted':False}
(S/'full-home.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:receipt[k] for k in ['exitCode','elapsedSeconds','passed','restored']}),flush=True)
raise SystemExit(code)
