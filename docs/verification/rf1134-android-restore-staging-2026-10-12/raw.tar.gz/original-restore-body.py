# 只移除专用应用私有根下的成员，拒绝不符合单一文件名的输出。
names = read("shell", "run-as", APP, "ls", "-A").splitlines()
if any(not re.fullmatch(r"[A-Za-z0-9_.-]+", name) or name in (".", "..") for name in names):
    raise RuntimeError("Unsafe private root entry; keep backup for manual recovery")
if names:
    adb("shell", "run-as", APP, "rm", "-rf", "--", *names, stdout=subprocess.PIPE)
# adb exec-in 的 stdin 在部分版本会提前结束，toybox tar 对截断
# 归档仍可能退出 0；使用完整落盘归档并保持权限，最终逐文件校验。
remote_backup = f"/data/local/tmp/fe2-private-backup-{uuid.uuid4().hex}.tar"
adb("push", str(backup), remote_backup, stdout=subprocess.PIPE)
adb("shell", "chmod", "644", remote_backup, stdout=subprocess.PIPE)
adb("shell", "run-as", APP, "tar", "-xpf", remote_backup,
    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
adb("shell", "run-as", APP, "chmod", root_mode, ".", stdout=subprocess.PIPE)
restored = output / "private-data-restored.tar"
archive(restored)
after = inventory(restored, require_empty=True)
if before != after:
    changed = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
    report["restoreChangedPaths"] = changed
    raise RuntimeError("Private data does not match backup")
report["restoreVerification"] = {"entries": len(after), "allFileContentsLinksAndModesMatch": True}
if read("shell", "run-as", APP, "stat", "-c", "%a", ".") != root_mode:
    raise RuntimeError("Private root mode differs from backup")
adb("shell", "rm", remote_backup, stdout=subprocess.PIPE)
report["restored"] = True
