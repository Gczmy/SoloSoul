# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: plugin-quick-panel.spec.ts >> windows 侧栏安装显示进度，重新打开后可取消，失败后可重试
- Location: e2e\plugin-quick-panel.spec.ts:165:3

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('dialog', { name: 'Plugins', exact: true }).getByRole('alert')
Expected substring: "Download timed out"
Received string:    "Plugin operation failed: Plugin installation did not complete. Check installed plugins first."
Timeout: 5000ms

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for getByRole('dialog', { name: 'Plugins', exact: true }).getByRole('alert')
    14 × locator resolved to <div role="alert" class="_error_1msbl_581">Plugin operation failed: Plugin installation did …</div>
       - unexpected value "Plugin operation failed: Plugin installation did not complete. Check installed plugins first."

```

```yaml
- alert: "Plugin operation failed: Plugin installation did not complete. Check installed plugins first."
```

# Test source

```ts
  102 |             if (pending?.rid === rid) {
  103 |               const operation = pending;
  104 |               pending = undefined;
  105 |               operation.reject('PLUGIN_INSTALL_CANCELLED');
  106 |             }
  107 |           },
  108 |           plugin_uninstall: ({ pluginId }: { pluginId: string }) => {
  109 |             (
  110 |               window as unknown as { __E2E_UNINSTALL_CALLS__: string[] }
  111 |             ).__E2E_UNINSTALL_CALLS__.push(pluginId);
  112 |             installed = false;
  113 |           },
  114 |         },
  115 |       });
  116 |       localStorage.setItem('i18nextLng', 'en-US');
  117 |     },
  118 |     { platform, initiallyInstalled },
  119 |   );
  120 |   await login(page);
  121 |   await openPluginPanel(page);
  122 | }
  123 | 
  124 | async function expectInstallCalls(page: Page, count: number) {
  125 |   await expect
  126 |     .poll(() =>
  127 |       page.evaluate(
  128 |         () =>
  129 |           (window as unknown as { __E2E_INSTALL_CALLS__: string[] }).__E2E_INSTALL_CALLS__.length,
  130 |       ),
  131 |     )
  132 |     .toBe(count);
  133 | }
  134 | 
  135 | async function finishInstall(page: Page, error?: string) {
  136 |   await page.evaluate(
  137 |     (error) =>
  138 |       (
  139 |         window as unknown as { __E2E_FINISH_INSTALL__: (error?: string) => void }
  140 |       ).__E2E_FINISH_INSTALL__(error),
  141 |     error,
  142 |   );
  143 | }
  144 | 
  145 | async function reportInstallProgress(
  146 |   page: Page,
  147 |   percent: number,
  148 |   phase: PluginInstallProgress['phase'] = 'downloading',
  149 | ) {
  150 |   await page.evaluate(
  151 |     ({ percent, phase }) =>
  152 |       (
  153 |         window as unknown as {
  154 |           __E2E_INSTALL_PROGRESS__: (
  155 |             percent: number,
  156 |             phase: PluginInstallProgress['phase'],
  157 |           ) => void;
  158 |         }
  159 |       ).__E2E_INSTALL_PROGRESS__(percent, phase),
  160 |     { percent, phase },
  161 |   );
  162 | }
  163 | 
  164 | for (const platform of ['macos', 'windows'] as const) {
  165 |   test(`${platform} 侧栏安装显示进度，重新打开后可取消，失败后可重试`, async ({ page }) => {
  166 |     await setupPlugin(page, platform, false);
  167 |     const panel = page.getByRole('dialog', { name: 'Plugins', exact: true });
  168 |     const install = panel.getByRole('button', { name: 'Install', exact: true });
  169 |     const cancel = panel.getByRole('button', { name: 'Cancel installation', exact: true });
  170 |     await install.click();
  171 |     await expectInstallCalls(page, 1);
  172 |     await expect(cancel).toBeVisible();
  173 |     await expect(install).toHaveCount(0);
  174 |     const ring = panel.getByRole('progressbar');
  175 |     await expect(ring).toHaveAttribute('aria-valuenow', '0');
  176 |     for (const percent of [25, 50]) {
  177 |       await reportInstallProgress(page, percent);
  178 |       await expect(ring).toHaveAttribute('aria-valuenow', String(percent));
  179 |       await expect(ring.locator('circle').last()).toHaveAttribute(
  180 |         'stroke-dashoffset',
  181 |         String(100 - percent),
  182 |       );
  183 |       await expect(ring.locator('circle').last()).toHaveCSS(
  184 |         'stroke-dashoffset',
  185 |         `${100 - percent}px`,
  186 |       );
  187 |       await expect(ring.locator('circle').last()).toHaveCSS('animation-name', 'none');
  188 |     }
  189 |     await page.screenshot({ path: test.info().outputPath('install-progress-50.png') });
  190 |     await page.keyboard.press('Escape');
  191 |     await expect(panel).toHaveCount(0);
  192 |     await openPluginPanel(page);
  193 |     await expect(cancel).toBeVisible();
  194 |     await expect(ring).toHaveAttribute('aria-valuenow', '50');
  195 |     await expectInstallCalls(page, 1);
  196 |     await cancel.click();
  197 |     await expect(install).toBeVisible();
  198 |     await expect(panel.getByRole('alert')).toHaveCount(0);
  199 |     await install.click();
  200 |     await expectInstallCalls(page, 2);
  201 |     await finishInstall(page, 'Download timed out');
> 202 |     await expect(panel.getByRole('alert')).toContainText('Download timed out');
      |                                            ^ Error: expect(locator).toContainText(expected) failed
  203 |     await expect(install).toBeVisible();
  204 |     await install.click();
  205 |     await expectInstallCalls(page, 3);
  206 |     await expect(panel.getByRole('alert')).toHaveCount(0);
  207 |     await reportInstallProgress(page, 98, 'finalizing');
  208 |     await expect(ring).toHaveAttribute('aria-valuenow', '98');
  209 |     await finishInstall(page);
  210 |     await expect(ring).toHaveAttribute('aria-valuenow', '100');
  211 |     await expect(
  212 |       panel.getByRole('button', { name: 'Installation complete', exact: true }),
  213 |     ).toBeDisabled();
  214 |     await expect(ring).toHaveCount(0);
  215 |     await expect(cancel).toHaveCount(0);
  216 |     await expect(panel.getByRole('button', { name: 'Uninstall', exact: true })).toBeVisible();
  217 |     await panel.getByRole('button', { name: 'Installed 1', exact: true }).click();
  218 |     await expect(panel.getByText('Address Formatter', { exact: true })).toBeVisible();
  219 |   });
  220 | 
  221 |   test(`${platform} 侧栏卸载确认执行一次，列表与重新打开后的状态同步`, async ({ page }) => {
  222 |     await setupPlugin(page, platform);
  223 |     const panel = page.getByRole('dialog', { name: 'Plugins', exact: true });
  224 |     const uninstall = panel.getByRole('button', { name: 'Uninstall', exact: true });
  225 |     await expect(uninstall).toBeVisible();
  226 |     await uninstall.click();
  227 |     // 必须使用真实的 mousedown → mouseup → click，才能覆盖 Portal 被父面板提前卸载的故障。
  228 |     await page.getByRole('button', { name: 'Confirm', exact: true }).click();
  229 |     await expect
  230 |       .poll(() =>
  231 |         page.evaluate(
  232 |           () =>
  233 |             (window as unknown as { __E2E_UNINSTALL_CALLS__: string[] }).__E2E_UNINSTALL_CALLS__,
  234 |         ),
  235 |       )
  236 |       .toEqual(['com.solosoul.official.address-fmt']);
  237 |     await expect(panel).toBeVisible();
  238 |     await expect(panel.getByRole('button', { name: 'Install', exact: true })).toBeVisible();
  239 |     await expect(uninstall).toHaveCount(0);
  240 |     await panel.getByRole('button', { name: 'Installed', exact: true }).click();
  241 |     await expect(panel.getByText('Address Formatter', { exact: true })).toHaveCount(0);
  242 |     await panel.getByRole('button', { name: 'All', exact: true }).click();
  243 |     await page.getByRole('heading', { name: 'Home', exact: true }).click();
  244 |     await expect(panel).toHaveCount(0);
  245 |     await page
  246 |       .locator('#desktop-navigation')
  247 |       .getByRole('button', { name: 'Tools', exact: true })
  248 |       .hover();
  249 |     await page
  250 |       .locator('#desktop-navigation')
  251 |       .getByRole('button', { name: 'Plugins', exact: true })
  252 |       .click();
  253 |     await expect(panel.getByRole('button', { name: 'Install', exact: true })).toBeVisible();
  254 |   });
  255 | 
  256 |   test(`${platform} 取消和 Escape 只关闭卸载确认，不关闭侧栏卡片`, async ({ page }) => {
  257 |     await setupPlugin(page, platform);
  258 |     const panel = page.getByRole('dialog', { name: 'Plugins', exact: true });
  259 |     const uninstall = panel.getByRole('button', { name: 'Uninstall', exact: true });
  260 |     for (const cancel of ['button', 'escape', 'backdrop']) {
  261 |       await uninstall.click();
  262 |       await expect(
  263 |         page.getByRole('heading', { name: 'Uninstall plugin', exact: true }),
  264 |       ).toBeVisible();
  265 |       if (cancel === 'button')
  266 |         await page.getByRole('button', { name: 'Cancel', exact: true }).click();
  267 |       else if (cancel === 'escape') await page.keyboard.press('Escape');
  268 |       else await page.locator('[data-macos-glass-backdrop]').click({ position: { x: 5, y: 5 } });
  269 |       await expect(
  270 |         page.getByRole('heading', { name: 'Uninstall plugin', exact: true }),
  271 |       ).toHaveCount(0);
  272 |       await expect(uninstall).toBeVisible();
  273 |     }
  274 |     expect(
  275 |       await page.evaluate(
  276 |         () => (window as unknown as { __E2E_UNINSTALL_CALLS__: string[] }).__E2E_UNINSTALL_CALLS__,
  277 |       ),
  278 |     ).toEqual([]);
  279 |     // 没有子确认框时，原本的 Escape 关闭仍然有效。
  280 |     await page.keyboard.press('Escape');
  281 |     await expect(panel).toHaveCount(0);
  282 |   });
  283 | }
  284 | 
  285 | test('安装进度从侧栏同步到完整页面，减少动态效果不影响真实进度', async ({ page }) => {
  286 |   await page.emulateMedia({ reducedMotion: 'reduce' });
  287 |   await setupPlugin(page, 'macos', false);
  288 |   const panel = page.getByRole('dialog', { name: 'Plugins', exact: true });
  289 |   await panel.getByRole('button', { name: 'Install', exact: true }).click();
  290 |   await expectInstallCalls(page, 1);
  291 |   await reportInstallProgress(page, 50);
  292 |   await panel.getByRole('button', { name: 'View All', exact: true }).click();
  293 |   await expect(page).toHaveURL('/plugins');
  294 |   const ring = page.getByRole('progressbar', { name: 'Installation progress', exact: true });
  295 |   await expect(ring).toHaveAttribute('aria-valuenow', '50');
  296 |   await reportInstallProgress(page, 75);
  297 |   await expect(ring).toHaveAttribute('aria-valuenow', '75');
  298 |   // 全局减少动态效果规则允许 0.01ms 的兼容值，同样应立即到达真实进度。
  299 |   expect(
  300 |     await ring
  301 |       .locator('circle')
  302 |       .last()
```