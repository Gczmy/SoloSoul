from pathlib import Path
import json

root=Path('D:/SoloSoul')
load=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
base='docs/verification/rf1106-preference-write-checkpoint-2026-10-10'
r=load(root/(base+'.json'))
assert r['accepted'] and not r['rf1105Closed']
assert r['archive']['readbackAllMembersVerified']
p=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md'
s=p.read_text(encoding='utf-8-sig')
counter='- 已关闭：**285 / 296**；实际修复（已关闭）：285；排除：0；待验证/阻塞：3（RF-112、RF-121、RF-312）；暂缓：0；进行中：2；待执行：6。'
assert s.count(counter)==1
s=s.replace(counter,counter.replace('285 / 296','286 / 296').replace('实际修复（已关闭）：285','实际修复（已关闭）：286').replace('进行中：2','进行中：1'))
row='| 296 | [RF-1106](#rf-1106) | P2 | 缓存写入租约回归等待实际 worker 准入 | 无（RF-1105默认全量检查发现） | [~] 进行中 |'
assert s.count(row)==1
s=s.replace(row,row.replace('[~] 进行中','[x] 完成'))
lines=s.splitlines(keepends=True)
lines[2]='> 最后更新：2026-10-10（RF-1106实际worker准入同步回归关闭；RF-1105待新GUI和两档重启，RF-112/121/312保持待验证）\n'
lines=[('- 当前处理：**RF-1106已完成并独立提交；RF-1105四文件门禁修复保留，默认完整检查通过后继续新GUI Release和两档各五组同目录重启。Windows完整材质矩阵、Android当前包原生回归及RF-112/121/312与后续前置保持未完成**。\n' if line.startswith('- 当前处理：') else line) for line in lines]
s=''.join(lines)
default=r['checks']['rf1106-default-workspace']['testTotals']
s+=f'''\n### RF-1106 实际缓存写入回归的准入同步（2026-10-10）

- RF-1105默认workspace实际退出101，Tauri lib 789通过/1失败；失败原文、源码与所有结果保留。旧测试在worker升级owner引用后用10ms等待推测许可取得；此时序不能保证真实准入完成。
- 通知只存在于cfg(test)，由真实许可取得后的worker发送；测试保留五秒有界等待，收到通知才查询维护准入，不靠引用计数、睡眠、增加重试或延长预算。原文件锁下缓存字节不变、写后正确及最终维护许可释放断言保持。剥离三个新增测试专用代码块后，产品实现前缀的规范化文本与原版完全一致。
- 格式、默认/非默认严格Clippy通过；更新偏好默认15、非默认15均通过；非默认原生诊断121通过；完整默认workspace {default['passed']}通过、0失败、{default['ignored']}既有ignored。检查绑定1830项当前来源及五个当前修改文件，RF-1105原四文件字节保持，不重跑未受影响的Node结果。
- [结构化证据](verification/rf1106-preference-write-checkpoint-2026-10-10.json)及[逐字原件索引](verification/rf1106-preference-write-checkpoint-2026-10-10/index.json)保留实际失败与全部通过日志。本项一修复一提交，累计286/296、RF-1105一项进行中、3待验证、6待执行。未推送，整体goal保持active。
'''
p.write_text(s,encoding='utf-8',newline='\n')
doc=f'''# RF-1106 缓存写入回归的实际准入通知

默认完整检查曾实际失败：Tauri lib 789通过、1失败，exit101；失败为缓存写入期间维护准入断言。旧owner引用升级与10ms等待不能证明worker已取得活动许可。

改为cfg(test)专用通知，实际许可取得后发送；收到通知才观察被文件锁阻塞的worker。五秒等待上限、阻塞时原缓存逐字不变、写后内容正确及维护可准入均保持。剥离新增测试专用代码后，产品实现前缀规范化文本与原版完全一致；没有改业务许可或默认重试。

默认/非默认严格Clippy和格式通过；两配置偏好各15项通过，非默认原生诊断121项通过；完整workspace {default['passed']}通过、0失败、{default['ignored']}既有ignored。原失败仍保留；这是测试时序修复，不作为历史首页失败根因，也不关闭RF-1105的构建和原生采样验收。

见[结构化证据](rf1106-preference-write-checkpoint-2026-10-10.json)与[全部原件索引](rf1106-preference-write-checkpoint-2026-10-10/index.json)。按RF-1106独立提交，不推送。
'''
with (root/'docs/verification/RF-1106-preference-write-checkpoint.md').open('x',encoding='utf-8',newline='\n') as out: out.write(doc)
print('RF-1106 closed after actual green and archive; 286/296, RF-1105 remains in progress')
