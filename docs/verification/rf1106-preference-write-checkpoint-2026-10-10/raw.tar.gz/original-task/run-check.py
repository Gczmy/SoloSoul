from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
cache = root/'build/rf312-maintenance-20261009'
name, command = sys.argv[1], sys.argv[2:]
assert command
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources = ['tauri/scripts/native-perf-startup.mjs','tauri/scripts/native-perf-startup.test.mjs',
    'tauri/src-tauri/src/native_perf/startup.rs','tauri/src-tauri/src/native_perf/preflight_tests.rs',
    'tauri/src-tauri/src/commands/update_preferences.rs']
before = {p:sha(root/p) for p in sources}
env = os.environ.copy()
env.update({'TEMP':str(cache/'tmp'),'TMP':str(cache/'tmp'),'CARGO_HOME':str(cache/'cargo-home'),
    'CARGO_TARGET_DIR':str(cache/'cargo-target'),'CARGO_BUILD_JOBS':'1','ORT_CACHE_DIR':str(cache/'ort-cache'),
    'npm_config_cache':str(cache/'npm-cache'),'PDFIUM_LIBRARY_PATH':str(root/'tauri/src-tauri/resources/pdfium/pdfium.dll')})
env['PATH'] = 'C:/Program Files/Git/usr/bin;'+env.get('PATH','')
began = time.monotonic()
with (stage/(name+'.stdout.log')).open('xb') as out,(stage/(name+'.stderr.log')).open('xb') as err:
    p = subprocess.Popen(command,cwd=root/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,
        creationflags=subprocess.CREATE_NO_WINDOW)
    with (stage/(name+'.live.json')).open('x',encoding='utf-8') as live:
        json.dump({'pid':p.pid,'command':command,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},live,indent=2)
    print(f'{name} live PID {p.pid}',flush=True)
    code = p.wait()
after = {p:sha(root/p) for p in sources}
with (stage/(name+'.receipt.json')).open('x',encoding='utf-8',newline='\n') as receipt:
    receipt.write(json.dumps({'pid':p.pid,'command':command,'exitCode':code,'elapsedSeconds':time.monotonic()-began,
        'sourceFiles':before,'sourceUnchanged':before==after,'sourceFilesAfter':after,
        'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print(f'{name} terminal exit {code}',flush=True)
raise SystemExit(code)
