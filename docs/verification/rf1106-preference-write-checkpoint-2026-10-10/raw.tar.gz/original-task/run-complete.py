from pathlib import Path
import hashlib, json, subprocess, sys

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,command):
    code = subprocess.call([sys.executable,'-X','utf8',str(stage/'run-check.py'),name,*command],cwd=root)
    assert code==0,(name,code)
initial = load(stage/'sources-current.json')
run('rf1106-format-write',['cargo','fmt','--all'])
sources = {name:sha(root/name) for name in initial}
assert all(sources[name]==digest for name,digest in initial.items() if name!='tauri/src-tauri/src/commands/update_preferences.rs')
with (stage/'sources-final.json').open('x',encoding='utf-8') as out: json.dump(sources,out,indent=2)
before = (stage/'update_preferences.before.rs').read_text()
after = (root/'tauri/src-tauri/src/commands/update_preferences.rs').read_text()
removed = []
for block in [
    '    #[cfg(test)]\n    activity_started: Option<std::sync::mpsc::Sender<()>>,\n',
    '            #[cfg(test)]\n            activity_started: None,\n',
    '        #[cfg(test)]\n        if let Some(started) = &self.activity_started {\n            let _ = started.send(());\n        }\n',
]:
    assert after.count(block)==1
    removed.append(block)
    after=after.replace(block,'')
marker='#[cfg(test)]\nmod tests {'
assert after.split(marker)[0]==before.split(marker)[0]
with (stage/'production-parity.json').open('x',encoding='utf-8') as out:
    json.dump({'task':'RF-1106','productPrefixEqualAfterExcludingTestOnlyInsertions':True,
        'removedBlocks':removed,'testWaitSeconds':5,'sleepAndReferenceCountInferenceRemoved':True,
        'sourceAfterSha256':sources['tauri/src-tauri/src/commands/update_preferences.rs']},out,indent=2)
jobs = [
    ('rf1106-format-check',['cargo','fmt','--all','--check']),
    ('rf1106-clippy-default',['cargo','clippy','--locked','--all-targets','--','-D','warnings']),
    ('rf1106-clippy-native',['cargo','clippy','--locked','--features','native-perf','--all-targets','--','-D','warnings']),
    ('rf1106-default-preferences',['cargo','test','--locked','-p','solo_soul','--lib','commands::update_preferences::tests','--','--nocapture']),
    ('rf1106-default-workspace',['cargo','test','--locked','--workspace']),
    ('rf1106-native-regression',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','native_perf::','--','--nocapture']),
    ('rf1106-native-preferences',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','commands::update_preferences::tests','--','--nocapture']),
]
for name,command in jobs:
    assert all(sha(root/file)==digest for file,digest in sources.items())
    run(name,command)
    assert all(sha(root/file)==digest for file,digest in sources.items())
print('RF-1106 all checks complete; archive, independent commit, then resume RF-1105 build remain',flush=True)
