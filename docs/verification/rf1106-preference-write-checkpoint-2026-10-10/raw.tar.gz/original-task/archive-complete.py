from pathlib import Path
import datetime, gzip, hashlib, io, json, re, tarfile

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
sources = load(stage/'sources-final.json')
assert len(sources)==1830
for name,digest in sources.items(): assert sha((root/name).read_bytes())==digest,name
parity = load(stage/'production-parity.json')
assert parity['productPrefixEqualAfterExcludingTestOnlyInsertions'] and parity['testWaitSeconds']==5
checks = {}
for name in ['rf1106-format-check','rf1106-clippy-default','rf1106-clippy-native',
    'rf1106-default-preferences','rf1106-default-workspace','rf1106-native-regression','rf1106-native-preferences']:
    receipt = load(stage/(name+'.receipt.json'))
    assert receipt['exitCode']==0 and receipt['sourceUnchanged'],name
    for file,digest in receipt['sourceFiles'].items(): assert sources[file]==digest,file
    totals = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
        (stage/(name+'.stdout.log')).read_text(encoding='utf-8'))
    if totals:
        assert all(failed=='0' for _,failed,_ in totals)
        receipt['testTotals']={'passed':sum(int(p) for p,_,_ in totals),'failed':0,'ignored':sum(int(i) for _,_,i in totals)}
    checks[name]=receipt
assert checks['rf1106-default-preferences']['testTotals']['passed']==15
assert checks['rf1106-native-preferences']['testTotals']['passed']==15
assert checks['rf1106-native-regression']['testTotals']['passed']==121
failed = load(stage/'original-default-failure.receipt.json')
assert failed['exitCode']==101 and failed['sourceUnchanged']
initial = load(stage/'initial-evidence.json')
source='tauri/src-tauri/src/commands/update_preferences.rs'
assert sha((stage/'update_preferences.before.rs').read_bytes())==initial['sourceBeforeSha256']
assert sources[source]==parity['sourceAfterSha256']
for file,digest in failed['sourceFiles'].items(): assert sources[file.replace('\\','/')]==digest
members={}
for file in stage.iterdir():
    if file.is_file() and file.suffix in {'.py','.json','.log','.rs'}:
        assert not file.is_symlink()
        members['checks-and-tools/'+file.name]=file.read_bytes()
members['source-after/'+source]=(root/source).read_bytes().replace(b'\r\n',b'\n')
members['source-before/'+source]=(stage/'update_preferences.before.rs').read_bytes().replace(b'\r\n',b'\n')
dest=root/'docs/verification/rf1106-preference-write-checkpoint-2026-10-10'
dest.mkdir(exist_ok=False)
archive=dest/'raw.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(mode='w',fileobj=zipped,format=tarfile.PAX_FORMAT) as tar:
            for name,data in sorted(members.items()):
                info=tarfile.TarInfo(name); info.size=len(data); info.mtime=0; info.mode=0o644
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    actual={i.name:tar.extractfile(i).read() for i in tar.getmembers() if i.isfile()}
assert actual==members
index={'task':'RF-1106','archiveSha256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,
    'memberCount':len(members),'readbackAllMembersVerified':True,'includesPhysicalVaults':False,
    'includesExecutablesModelsOrCaches':False,
    'members':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())]}
with (dest/'index.json').open('x',encoding='utf-8',newline='\n') as out: out.write(json.dumps(index,indent=2)+'\n')
with (dest/'.gitattributes').open('x',encoding='utf-8') as out: out.write('* -text\n')
record={'schemaVersion':1,'task':'RF-1106','accepted':True,'initialEvidence':initial,
    'checks':checks,'productionParity':parity,'sourceManifestSha256':sha((stage/'sources-final.json').read_bytes()),
    'sourceBeforeSha256':initial['sourceBeforeSha256'],'sourceAfterSha256':sources[source],
    'archive':{'path':dest.relative_to(root).as_posix(),**{k:index[k] for k in ['archiveSha256','archiveBytes','memberCount','readbackAllMembersVerified']}},
    'rf1105SourceFilesPreserved':True,'rf1105Closed':False,'rf112Closed':False,'rf121Closed':False,'rf312Closed':False,
    'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with dest.with_suffix('.json').open('x',encoding='utf-8',newline='\n') as out: out.write(json.dumps(record,indent=2)+'\n')
print(f'RF-1106 actual green checks and original red archived; {len(members)} members read back')
