from pathlib import Path
import collections, hashlib, io, json, re, subprocess, tarfile

root=Path('D:/SoloSoul')
base='docs/verification/rf1106-preference-write-checkpoint-2026-10-10'
sha=lambda b: hashlib.sha256(b).hexdigest()
def staged(name):
    return subprocess.run(['git','show',':'+name],cwd=root,check=True,capture_output=True).stdout
expected={'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md',
    'tauri/src-tauri/src/commands/update_preferences.rs','docs/verification/RF-1106-preference-write-checkpoint.md',
    base+'.json',base+'/.gitattributes',base+'/index.json',base+'/raw.tar.gz'}
actual=set(subprocess.run(['git','diff','--cached','--name-only'],cwd=root,check=True,capture_output=True,text=True).stdout.splitlines())
assert actual==expected,actual
index=json.loads(staged(base+'/index.json'))
archive=staged(base+'/raw.tar.gz')
assert sha(archive)==index['archiveSha256']
assert archive==(root/base/'raw.tar.gz').read_bytes()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
    members={i.name:tar.extractfile(i).read() for i in tar.getmembers() if i.isfile()}
assert len(members)==index['memberCount']
for entry in index['members']:
    assert len(members[entry['path']])==entry['bytes']
    assert sha(members[entry['path']])==entry['sha256']
source='tauri/src-tauri/src/commands/update_preferences.rs'
assert members['source-after/'+source]==staged(source)
record=json.loads(staged(base+'.json'))
assert record['accepted'] and not record['rf1105Closed']
for name,receipt in record['checks'].items():
    assert receipt['exitCode']==0 and receipt['sourceUnchanged']
report=staged('docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md').decode('utf-8-sig')
rows=re.findall(r'^\| \d+ \| \[(RF-\d+)\].*$',report,re.M)
cards=re.findall(r'^### (RF-\d+)\s*$',report,re.M)
assert len(rows)==len(set(rows))==len(cards)==len(set(cards))==296
assert set(rows)==set(cards)
statuses=collections.Counter()
for line in report.splitlines():
    if re.match(r'^\| \d+ \| \[RF-\d+\]',line): statuses[re.search(r'\[([x!~ ])\]',line)[1]]+=1
assert statuses=={'x':286,'!':3,'~':1,' ':6},statuses
print(f'RF-1106 staged exact seven files, {len(members)} archive members, 296 task cards; RF-1105 not staged')
