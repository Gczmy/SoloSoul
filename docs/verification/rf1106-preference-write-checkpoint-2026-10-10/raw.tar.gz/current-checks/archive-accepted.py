from pathlib import Path
import datetime, gzip, hashlib, io, json, re, sys, tarfile

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
task = sys.argv[1]
assert task in {'RF-1107', 'RF-1106'}
sources = load(stage/'sources-final.json')
assert len(sources) == 1830
for name,digest in sources.items(): assert sha((root/name).read_bytes()) == digest, name
checks = {}
names = ['rf1107-format-check','rf1107-download-tests','rf1107-default-workspace',
    'rf1107-clippy-default','rf1107-clippy-native','rf1107-native-regression','rf1107-native-preferences']
for name in names:
    receipt = load(stage/(name+'.receipt.json'))
    assert receipt['exitCode'] == 0 and receipt['sourceUnchanged'], name
    assert len(receipt['sourceFiles']) == 6
    for file,digest in receipt['sourceFiles'].items(): assert sources[file] == digest, file
    totals = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
        (stage/(name+'.stdout.log')).read_text(encoding='utf-8'))
    if totals:
        assert all(f == '0' for _,f,_ in totals)
        receipt['testTotals'] = {'passed':sum(int(p) for p,_,_ in totals), 'failed':0,
            'ignored':sum(int(i) for _,_,i in totals)}
    receipt['originalCheck'] = name
    receipt['executedAgainForArchive'] = False
    checks[name] = receipt
assert checks['rf1107-native-regression']['testTotals']['passed'] == 121
assert checks['rf1107-native-preferences']['testTotals']['passed'] == 15
assert checks['rf1107-default-workspace']['testTotals']['passed'] > 790
failed = load(stage/'original-default-failure.receipt.json')
assert failed['exitCode'] == 101 and failed['sourceUnchanged']
origin = stage if task == 'RF-1107' else root/'build/rf1106-preference-write-checkpoint-20261010'
source = 'tauri/src-tauri/src/commands/'+('update_download.rs' if task == 'RF-1107' else 'update_preferences.rs')
initial = load(origin/'initial-evidence.json')
parity = load(origin/'production-parity.json')
assert sources[source] == parity['sourceAfterSha256']
assert parity['productPrefixUnchanged' if task == 'RF-1107' else 'productPrefixEqualAfterExcludingTestOnlyInsertions']
before = origin/Path(source).name.replace('.rs', '.before.rs')
assert sha(before.read_bytes()) == initial['sourceBeforeSha256']
members = {}
for folder,label in [(stage,'current-checks'),(origin,'original-task')]:
    if folder == stage and label == 'original-task': continue
    for file in folder.iterdir():
        if file.is_file() and file.suffix in {'.py','.json','.log','.rs'}:
            assert not file.is_symlink()
            members[label+'/'+file.name] = file.read_bytes()
members['source-before/'+source] = before.read_bytes().replace(b'\r\n',b'\n')
members['source-after/'+source] = (root/source).read_bytes().replace(b'\r\n',b'\n')
if task == 'RF-1106':
    prefs = load(origin/'rf1106-default-preferences.receipt.json')
    assert prefs['exitCode'] == 0 and prefs['sourceUnchanged']
    for file,digest in prefs['sourceFiles'].items(): assert sources[file] == digest, file
    assert '15 passed; 0 failed; 0 ignored;' in (origin/'rf1106-default-preferences.stdout.log').read_text(encoding='utf-8')
    checks['rf1106-default-preferences'] = {**prefs, 'testTotals':{'passed':15,'failed':0,'ignored':0},
        'executedAgainForArchive':False, 'reuseScope':'Same five source hashes; the additional RF-1107 change is confined to a separate test module. Current full workspace also exercises all preferences tests.'}
    original = load(origin/'original-default-failure.receipt.json')
    assert original['exitCode'] == 101 and original['sourceUnchanged']
    assert 'actual file work must retain its own root activity permit' in (origin/'original-default-failure.stdout.log').read_text(encoding='utf-8')
slug = 'rf1107-download-low-speed-cause-2026-10-10' if task == 'RF-1107' else 'rf1106-preference-write-checkpoint-2026-10-10'
dest = root/'docs/verification'/slug
dest.mkdir(exist_ok=False)
archive = dest/'raw.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(mode='w', fileobj=zipped, format=tarfile.PAX_FORMAT) as tar:
            for name,data in sorted(members.items()):
                info = tarfile.TarInfo(name); info.size = len(data); info.mtime = 0; info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    actual = {i.name:tar.extractfile(i).read() for i in tar.getmembers() if i.isfile()}
assert actual == members
index = {'task':task, 'archiveSha256':sha(archive.read_bytes()), 'archiveBytes':archive.stat().st_size,
    'memberCount':len(members), 'readbackAllMembersVerified':True, 'includesPhysicalVaults':False,
    'includesExecutablesModelsOrCaches':False,
    'members':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())]}
with (dest/'index.json').open('x',encoding='utf-8',newline='\n') as out: out.write(json.dumps(index,indent=2)+'\n')
with (dest/'.gitattributes').open('x',encoding='utf-8',newline='\n') as out: out.write('* -text\n')
record = {'schemaVersion':1, 'task':task, 'accepted':True, 'initialEvidence':initial,
    'checks':checks, 'productionParity':parity, 'sourceManifestSha256':sha((stage/'sources-final.json').read_bytes()),
    'sourceBeforeSha256':initial['sourceBeforeSha256'], 'sourceAfterSha256':sources[source],
    'archive':{'path':dest.relative_to(root).as_posix(),**{k:index[k] for k in ['archiveSha256','archiveBytes','memberCount','readbackAllMembersVerified']}},
    'failedChecksPreserved':True, 'checksBoundToCurrentSixSources':True,
    'otherFixesCommittedTogether':False, 'rf1105Closed':False, 'rf112Closed':False,'rf121Closed':False,'rf312Closed':False,
    'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with dest.with_suffix('.json').open('x',encoding='utf-8',newline='\n') as out: out.write(json.dumps(record,indent=2)+'\n')
print(f'{task} actual current checks archived; {len(members)} members all read back')
