from pathlib import Path
import json
w=Path(__file__).parent;p=w/'cleanup-rf121-backdrop-after-picker-mixed-owned.ps1';text=p.read_text(encoding='utf8')
assert text.count('-ne 96')==1
text=text.replace('-ne 96','-ne 72').replace('Exact ninety-six owned cache paths required','Exact seventy-two owned cache paths required')
old="""                if (Test-Path -LiteralPath $destination) { throw 'Log copy already exists' }
                New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force | Out-Null
                Copy-Item -LiteralPath $file.FullName -Destination $destination"""
new="""                if (Test-Path -LiteralPath $destination) {
                    PlainAncestors $destination
                    $existing = Get-Item -LiteralPath $destination -Force
                    if ($existing.PSIsContainer -or ($existing.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Existing log copy is not an ordinary file' }
                } else {
                    New-Item -ItemType Directory -Path (Split-Path $destination -Parent) -Force | Out-Null
                    Copy-Item -LiteralPath $file.FullName -Destination $destination
                }"""
assert text.count(old)==1;text=text.replace(old,new)
with (w/'cleanup-rf121-backdrop-after-picker-mixed-retry1-owned.ps1').open('x',encoding='utf8') as f:f.write(text)
with (w/'rf121-backdrop-checks-after-picker-20261011/mixed-cleanup-first-failure.json').open('x',encoding='utf8') as f:json.dump({'exitCode':1,'failure':'Exact ninety-six owned cache paths required','plannedTargets':72,'filesDeleted':0,'applicationLogsCopiedBeforeGuard':9,'originalScriptPreserved':True,'retryReusesOnlyShaVerifiedOrdinaryLogCopies':True},f,indent=2)
