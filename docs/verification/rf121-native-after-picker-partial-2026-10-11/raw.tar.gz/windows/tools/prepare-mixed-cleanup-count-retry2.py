from pathlib import Path
import ast
w=Path(__file__).parent;original=w/'prepare-mixed-cleanup-count-retry.py';s=original.read_text(encoding='utf8')
assert s.count("text.count('-ne 96')==1")==1
s=s.replace("text.count('-ne 96')==1","text.count('-ne 96')==2")
ast.parse(s)
with (w/'prepare-mixed-cleanup-count-retry2-generated.py').open('x',encoding='utf8') as f:f.write(s)
exec(compile(s,str(w/'prepare-mixed-cleanup-count-retry2-generated.py'),'exec'))
