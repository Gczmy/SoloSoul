from pathlib import Path
import ast,json,subprocess
w=Path(__file__).parent;s=w/'rf121-backdrop-checks-after-picker-20261011'
original=(w/'verify-backdrop-foreground-denial-for-cleanup.mjs').read_text(encoding='utf8')
start=original.index(" const identity=await regular(path.join(dir,'surface-identity.json'));")
end=original.index(' // The public snapshot',start)
text=original[:start]+original[end:]
text=text.replace('rf121-backdrop-checks-20261011','rf121-backdrop-checks-after-picker-20261011').replace('${mode}-20261011','${mode}-after-picker-20261011')
text=text.replace('journeys-only-cleanup-validation.json','sdk-only-mixed-cleanup-validation.json').replace('Three actual default journeys and foreground-denial diagnostics verified for cleanup only; no requested appearance scene or material accepted:','Three SDK journeys verified for mixed-phase cleanup only; appearances require separate bindings:')
text=text.replace('foregroundActivationAccepted:false,materialAccepted:false,requestedAppearanceScenesExecuted:false,pixelsRead:0,','appearanceAcceptanceNotEvaluated:true,')
with (w/'verify-after-picker-sdk-only-cleanup.mjs').open('x',encoding='utf8') as f:f.write(text)
text=(w/'verify-rf121-backdrop-after-picker.mjs').read_text(encoding='utf8')
anchor='for(const sample of journey.samples){';assert text.count(anchor)==1
text=text.replace(anchor,"assert.equal(mode,'dark-expanded');\nconst failure=await load(path.join(captureStage,'surface-sample-002.json'));assert.equal(failure.success,false);assert.equal(failure.errorCategory,'JSONDecodeError');assert(failure.traceback.includes('native-perf-consumed.json'));\nfor(const sample of journey.samples.filter(s=>s.index!==2)){")
text=text.replace('size,3);','size,2);').replace('accepted:true,samples,sourceFiles','accepted:false,bindingSubsetVerified:true,samples,sourceFiles').replace("'validation.json'","'partial-two-bindings.json'").replace('Three complete native journeys and three exact state/pixel bindings independently verified','Only sample 1/3 state/pixel bindings independently verified; complete group remains failed')
with (w/'verify-after-picker-dark-two-bindings.mjs').open('x',encoding='utf8') as f:f.write(text)
text=(w/'render-rf121-backdrop-after-picker.py').read_text(encoding='utf8').replace("'validation.json'","'partial-two-bindings.json'").replace("validation['accepted'] and len(validation['samples']) == 3","not validation['accepted'] and validation['bindingSubsetVerified'] and len(validation['samples']) == 2").replace('Three verified owned screenshots rendered','Two verified owned screenshots rendered; full cohort remains failed')
ast.parse(text)
with (w/'render-after-picker-dark-two-bindings.py').open('x',encoding='utf8') as f:f.write(text)
text=(w/'cleanup-rf121-backdrop-after-picker-owned.ps1').read_text(encoding='utf8').replace('rf121-backdrop-after-picker-cache-cleanup','rf121-backdrop-after-picker-mixed-cache-cleanup').replace('$validation.groups.Count -ne 4','$validation.groups.Count -ne 3').replace('Four terminal independently verified owned groups','Three terminal SDK-verified owned groups')
with (w/'cleanup-rf121-backdrop-after-picker-mixed-owned.ps1').open('x',encoding='utf8') as f:f.write(text)
for n in ['verify-after-picker-sdk-only-cleanup.mjs','verify-after-picker-dark-two-bindings.mjs']:
    p=subprocess.run(['node','--check',str(w/n)],capture_output=True);assert p.returncode==0
with (s/'mixed-reader-preparation.json').open('x',encoding='utf8') as f:json.dump({'sdkOnlyReaderDoesNotAcceptAppearance':True,'partialDarkReaderPreservesAllBindingGuards':True,'onlyIndices1And3Selected':True,'wholeDarkCohortRemainsFailed':True,'originalFailedVerifierPreserved':True,'cleanupRequiresAllNineSdkJourneys':True,'executed':False},f,indent=2)
