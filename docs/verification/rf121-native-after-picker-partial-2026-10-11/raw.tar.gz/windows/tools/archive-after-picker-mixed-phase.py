from pathlib import Path
import datetime, hashlib, io, json, tarfile
r=Path('D:/SoloSoul'); w=Path(__file__).parent; a=r/'build/android-native-feasibility-20261010'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
s=w/'rf121-backdrop-checks-after-picker-20261011'; sources=load(s/'sources.json')
assert len(sources)==1834 and all(sha(r/n)==h for n,h in sources.items())
pkg=load(s/'runtime-package.json');assert sha(Path(pkg['exe']))==pkg['sha256']
assert len(pkg['resources'])==94
for v in pkg['resources']:assert sha(Path(v['source']))==sha(Path(v['copy']))==v['sha256']
cleanup=load(w/'rf121-backdrop-after-picker-mixed-cache-cleanup.json')
assert len(cleanup['removedCachePaths'])==72 and all(not Path(p).exists() for p in cleanup['removedCachePaths'])
assert cleanup['preservedBytesVerified'] and cleanup['matchingOwnedIdentitiesLive']==cleanup['processesTerminatedByThisTool']==0
for v in cleanup['preservedVaultAndRootFiles']:assert sha(Path(v['path']))==v['sha256']
assert len(cleanup['applicationLogs'])==9
for v in cleanup['applicationLogs']:assert sha(Path(v['copy']))==v['sha256']
queue=load(s/'cohorts-complete.json');assert not queue['success'] and len(queue['rows'])==3
for mode in ['baseline','light-collapsed']:
    cap=w/f'ss-rf121-composed-window-backdrop-{mode}-after-picker-20261011'
    v=load(cap/'validation.json');assert v['accepted'] and v['nativeSystemBackdropVerified'] and len(v['samples'])==3
    assert load(cap/'visual-review.json')['actualImagesInspected']==3
dark=w/'ss-rf121-composed-window-backdrop-dark-expanded-after-picker-20261011'
dv=load(dark/'partial-two-bindings.json');assert dv['bindingSubsetVerified'] and not dv['accepted']
assert load(dark/'partial-visual-review.json')['actualImagesInspected']==2
for api,stage in [('31','api31-host-rf1121-20261011'),('35','api35-host-rf1121-retry1-20261011')]:
    v=load(a/stage/'stop.receipt.json')
    assert v['settingsRestored'] and v['noForceTermination'] and v['stopExitCode']==0 and v['ownedProcessExited'] and v['dedicatedPortsFree']
home=load(a/'api31-home-rf1121-current-20261011/verification.json');assert not home['accepted'] and [v['exitCode'] for v in home['results']]==[0,0,0,1]
retry=load(a/'api31-home-rf1121-cold-fallback-retry1-20261011/verification.json');assert retry['accepted']
assert load(a/'api35-native-rf1121-tail-20261011/verification.json')['accepted']
files={}; allowed={'.json','.log','.py','.mjs','.ps1','.rs','.toml','.lock','.png','.bgra','.html','.txt','.xml','.gradle','.kt','.md','.csv'}
def add(p,n):
    assert p.is_file() and not p.is_symlink() and not (p.lstat().st_file_attributes&0x400) and n not in files,n
    files[n]=p
def tree(base,prefix,shallow=False):
    for p in base.iterdir() if shallow else base.rglob('*'):
        if p.is_file() and p.suffix in allowed:add(p,prefix+'/'+p.relative_to(base).as_posix())
tree(s,'windows/checks')
for mode in ['baseline','light-collapsed','dark-expanded']:
    cap=w/f'ss-rf121-composed-window-backdrop-{mode}-after-picker-20261011'
    tree(cap,'windows/'+mode,True);tree(cap/'actual100','windows/'+mode+'/actual100',True)
    for i in range(1,4):tree(cap/'actual100'/f'sample-{i:03}','windows/'+mode+f'/actual100/sample-{i:03}',True)
tree(w/'application-logs-rf121-backdrop-after-picker','windows/application-logs')
for p in w.iterdir():
    if p.is_file() and p.suffix in allowed and ('after-picker' in p.name or 'mixed-cleanup' in p.name or p.name=='record-after-picker-visual-review.py'):add(p,'windows/tools/'+p.name)
stages=['current-apks-rf1121-20261011','api35-host-rf1121-20261011','api35-host-rf1121-retry1-20261011','api35-native-rf1121-current-20261011','api35-native-rf1121-tail-20261011','api31-host-rf1121-20261011','api31-native-rf1121-current-20261011','api31-home-rf1121-current-20261011','api31-home-rf1121-blur-compensation-20261011','api31-home-rf1121-cold-fallback-retry1-20261011']
for name in stages:
    # Private backup TAR, APK, JNI and model assets are never included.
    base=a/name
    for p in base.rglob('*'):
        if p.is_file() and p.suffix in allowed and not any(x in p.relative_to(base).parts for x in ['assets','jniLibs','models','private-assets','private-jni']):add(p,'android/'+name+'/'+p.relative_to(base).as_posix())
for p in a.iterdir():
    if p.is_file() and p.suffix in allowed and ('rf1121' in p.name or p.name=='native-remaining-seven.mjs' or 'api31-native-preparation' in p.name):add(p,'android/tools/'+p.name)
stem='rf121-native-after-picker-partial-2026-10-11';out=r/'docs/verification'/stem;out.mkdir(exist_ok=False)
(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf8')
members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as t:
    for n,p in sorted(files.items()):
        b=p.read_bytes();info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(b));members.append(dict(path=n,size=len(b),sha256=hashlib.sha256(b).hexdigest()))
with tarfile.open(out/'raw.tar.gz','r:gz') as t:
    assert set(t.getnames())=={v['path'] for v in members}
    for v in members:
        b=t.extractfile(v['path']).read();assert len(b)==v['size'] and hashlib.sha256(b).hexdigest()==v['sha256']
save(out/'index.json',dict(task='RF-121',archiveSha256=sha(out/'raw.tar.gz'),members=members,allMembersVerified=True,excluded=['private backup TAR','APKs','JNI binaries','executables','models','physical Vault','caches']))
save(r/'docs/verification'/(stem+'.json'),dict(task='RF-121',at=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceCount=1834,sourceManifestSha256=sha(s/'sources.json'),runtimeSha256=pkg['sha256'],fullRF121Accepted=False,fullRF312Accepted=False,applicationMaterialAccepted=False,windows=dict(queue=queue,normalSdkJourneysPassed=9,foregroundWindowBindingsVerified=8,completeCohorts=['baseline','light-collapsed'],partialDarkBindings=[1,3],darkCollapsedExecuted=False,producerRace='native-perf-consumed.json published before serialization completes; RF-1122',cleanupRemovedPaths=72,logsPreserved=9,baselineAuxiliaryReaderExitCode=1,historicalMemoryReadingsAccepted=False),android=dict(apk=load(a/'current-apks-rf1121-20261011/current-apks.json'),api35FullNativeAccepted=False,api35TailPassed=14,api35Failure='WebGL1 blocklisted',api31FullNativeAccepted=False,api31WebGLTestsPassed=2,api31Failure='follow-system dark theme remains light; cause not established',originalHome=home,coldFallbackRetry=retry,settingsRestored=True,ownedEmulatorsStopped=True,privateFilesRestored=True),archive=dict(path=stem+'/raw.tar.gz',sha256=sha(out/'raw.tar.gz'),members=len(members),allMembersVerified=True)))
print(json.dumps(dict(members=len(members),archiveBytes=(out/'raw.tar.gz').stat().st_size,allMembersVerified=True,fullRF121Accepted=False)))
