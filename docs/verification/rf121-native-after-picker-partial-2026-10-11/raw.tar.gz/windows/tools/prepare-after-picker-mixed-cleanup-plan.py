from pathlib import Path
import datetime,hashlib,json
w=Path(__file__).parent;load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert not load(w/'rf121-backdrop-checks-after-picker-20261011/cohorts-complete.json')['success']
groups=[]
for mode in ['baseline','light-collapsed','dark-expanded']:
    c=w/('ss-rf121-composed-window-backdrop-'+mode+'-after-picker-20261011');assert load(c/'actual100.receipt.json')['exitCode']==0
    p=c/('validation.json' if mode=='baseline' else 'sdk-only-mixed-cleanup-validation.json');v=load(p);assert len(v['samples'])==3
    if mode=='baseline':assert v['accepted'] and v['nativeSystemBackdropVerified']
    else:assert not v['accepted'] and v['cleanupOnly'] and v['journeysOnlyAccepted']
    groups.append({'label':mode,'captureRoot':str(c),'terminal':True,'samples':v['samples'],'readerPath':str(p),'readerSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'readerScope':'full owned state/pixel and SDK binding' if mode=='baseline' else 'SDK-only cleanup; no appearance acceptance'})
result={'cacheCleanupEligible':True,'failedSamplesAccepted':False,'fullMaterialMatrixAccepted':False,'groups':groups,'scope':'Nine completed SDK journeys; complete appearance queue remains failed','historicalMemoryReadingsAccepted':False,'baselineAuxiliarySdkReaderExitCode':1,'baselineAuxiliaryReaderReason':'At least one verified process memory reading is unavailable','baselineOriginalBindingReaderExitCode':0,'baselineHistoricalMemoryFailurePreserved':True,'freshCimRequiredBeforeDeletion':True,'plannedExactCacheTargets':72}
with (w/'rf121-backdrop-after-picker-mixed-cache-cleanup-plan.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2)
c=w/'ss-rf121-composed-window-backdrop-dark-expanded-after-picker-20261011';v=load(c/'partial-two-bindings.json');images=load(c/'rendered-captures.json');assert not v['accepted'] and v['bindingSubsetVerified'] and [x['index'] for x in images]==[1,3]
for x in images:assert hashlib.sha256(Path(x['png']).read_bytes()).hexdigest()==x['pngSha256']
with (c/'partial-visual-review.json').open('x',encoding='utf8') as f:json.dump({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actualImagesInspected':2,'indices':[1,3],'images':images,'notes':'实际检查深色展开两张：文字、卡片、导航与顶部栏可见；OCR及备份提示保留。样本2无像素，整组仍失败。','fullMatrixAccepted':False,'wholeCohortAccepted':False},f,indent=2,ensure_ascii=False)
print('72 exact owned cache targets planned; original memory/JSON failures and whole-cohort failure preserved',flush=True)
