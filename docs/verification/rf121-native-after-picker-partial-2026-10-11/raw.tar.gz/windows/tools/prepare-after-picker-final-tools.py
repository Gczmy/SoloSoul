from pathlib import Path
import ast,hashlib,json,shutil
w=Path(__file__).parent;old='rf121-backdrop-checks-20261011';new='rf121-backdrop-checks-after-picker-20261011';s=w/new
for p in (w/old).iterdir():
    if p.is_file() and (p.name.startswith('native-') or p.name.startswith('build-')) and not (s/p.name).exists():shutil.copy2(p,s/p.name)
changes={
'prepare-backdrop-cleanup-plan.py':'prepare-after-picker-cleanup-plan.py',
'cleanup-rf121-backdrop-owned.ps1':'cleanup-rf121-backdrop-after-picker-owned.ps1',
'archive-backdrop-foreground.py':'archive-backdrop-after-picker-foreground.py'}
records={}
for original,target in changes.items():
    text=(w/original).read_text(encoding='utf8')
    text=text.replace(old,new).replace("mode+'-20261011'","mode+'-after-picker-20261011'")
    text=text.replace('rf121-backdrop-cache-cleanup','rf121-backdrop-after-picker-cache-cleanup').replace('application-logs-rf121-backdrop','application-logs-rf121-backdrop-after-picker')
    text=text.replace('rf121-windows-backdrop-foreground-2026-10-11','rf121-windows-backdrop-foreground-retry-2026-10-11').replace('cleanup-rf121-backdrop-owned.ps1','cleanup-rf121-backdrop-after-picker-owned.ps1')
    if target.endswith('.py'):ast.parse(text)
    with (w/target).open('x',encoding='utf8') as f:f.write(text)
    records[target]={'from':original,'sha256':hashlib.sha256((w/target).read_bytes()).hexdigest()}
with (s/'success-only-final-tools-prepared.json').open('x',encoding='utf8') as f:json.dump({'files':records,'notExecuted':True,'requiresFourAcceptedCohorts':True,'requiresActualVisualInspection':True,'uses96ExactTargets':True,'guardsUnchanged':True},f,indent=2)
