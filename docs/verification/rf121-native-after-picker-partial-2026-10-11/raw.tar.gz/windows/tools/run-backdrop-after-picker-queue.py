"""Run separate current-source cohorts, preserving failed receipts and full guards."""
from pathlib import Path
import ast,datetime,hashlib,json,os,subprocess,time
root=Path('D:/SoloSoul');w=Path(__file__).parent;s=w/'rf121-backdrop-checks-after-picker-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):
    with (s/n).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
sources=load(s/'sources.json');package=load(s/'runtime-package.json')
assert len(sources)==1834
for n in ['native-clippy','native-release-build']:assert load(s/(n+'.receipt.json'))['exitCode']==0
assert load(s/package['nativeContractTestsReceipt'])['exitCode']==0
assert package['priorFailedNativeTestsPreserved'] and load(s/'native-contract-tests.receipt.json')['exitCode']==101
def verify():
    assert all(sha(root/n)==h for n,h in sources.items())
    for key,digest in [('exe','sha256'),('helperExe','helperSha256'),('activationExe','activationSha256'),('helperSource','helperSourceSha256'),('activationSource','activationSourceSha256')]:assert sha(Path(package[key]))==package[digest]
    for v in package['resources']:assert sha(Path(v['source']))==sha(Path(v['copy']))==v['sha256']
verify();env=os.environ.copy();env.update(TEMP=str(s),TMP=str(s));env.pop('PDFIUM_LIBRARY_PATH',None)
def run(n,cmd):
    verify();start=time.monotonic()
    with (s/(n+'.stdout.log')).open('xb') as out,(s/(n+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(n+'.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()));print(n,'PID',p.pid,flush=True);code=p.wait()
    verify();save(n+'.receipt.json',dict(exitCode=code,pid=p.pid,command=cmd,elapsedSeconds=time.monotonic()-start,sourceUnchanged=True,resourcesUnchanged=True))
    print(n,'terminal',code,flush=True);return code
rows=[]
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
    text=(w/'rf1117-session-before-journeys.py').read_text(encoding='utf8')
    old="stage/'rf1117-session-before-journeys.json'";new="stage/'rf121-backdrop-checks-after-picker-20261011/session-before-"+mode+".json'"
    assert text.count(old)==1;text=text.replace(old,new);ast.parse(text)
    probe=w/('rf121-backdrop-after-picker-session-before-'+mode+'.py')
    with probe.open('x',encoding='utf8',newline='\n') as f:f.write(text)
    assert run('session-'+mode,['C:/Python314/python.exe',str(probe)])==0
    session=load(s/('session-before-'+mode+'.json'))
    if session.get('connectionState')!=0 or not session.get('inputDesktopAvailable'):
        rows.append(dict(mode=mode,executed=False,reason='caller-desktop-unavailable',session=session));break
    capture=run('capture-'+mode,['C:/Python314/python.exe',str(w/'run-rf121-backdrop-after-picker.py'),'--'+mode])
    independent=run('verify-'+mode,['node',str(w/'verify-rf121-backdrop-after-picker.mjs'),'--'+mode])
    rendered=None
    if independent==0:
        assert capture==0
        rendered=run('render-'+mode,['C:/Python314/python.exe',str(w/'render-rf121-backdrop-after-picker.py'),'--'+mode]);assert rendered==0
    rows.append(dict(mode=mode,executed=True,captureExitCode=capture,independentVerifierExitCode=independent,rendererExitCode=rendered))
    save('cohort-'+mode+'.json',rows[-1])
    if independent!=0:break  # Full acceptance still requires all four cohorts.
success=len(rows)==4 and all(v.get('executed') and v.get('captureExitCode')==v.get('independentVerifierExitCode')==v.get('rendererExitCode')==0 for v in rows)
save('cohorts-complete.json',dict(success=success,rows=rows,sourceUnchanged=True,fullMatrixAccepted=False,applicationMaterialAccepted=False,systemSettingsChanged=False))
print('Four-cohort queue terminal; actual all-cohort acceptance: '+str(success),flush=True)
raise SystemExit(0 if success else 1)
