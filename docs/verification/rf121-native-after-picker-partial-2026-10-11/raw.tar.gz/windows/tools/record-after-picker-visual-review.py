from pathlib import Path
import datetime,hashlib,json,sys
w=Path(__file__).parent;mode=sys.argv[1];assert mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']
c=w/('ss-rf121-composed-window-backdrop-'+mode+'-after-picker-20261011');load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
v=load(c/'validation.json');images=load(c/'rendered-captures.json');assert v['accepted'] and v['nativeSystemBackdropVerified'] and len(images)==3
for x in images:assert hashlib.sha256(Path(x['png']).read_bytes()).hexdigest()==x['pngSha256']
notes={'baseline':'三张浅色展开侧栏截图均实际检查；内容文字清晰不受材质遮挡，导航和内容区分可见；样本2/3含OCR完成提示条，保持为实际场景差异。','light-collapsed':'三张浅色折叠侧栏截图实际检查，图标/标签与轨道宽度及内容边界可见。','dark-expanded':'三张深色展开侧栏截图实际检查，文字与卡片层级、顶部栏及导航区域可见。','dark-collapsed':'三张深色折叠侧栏截图实际检查，图标标签、主题背景和卡片边界可见。'}
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actualImagesInspected':3,'images':[{'path':x['png'],'sha256':x['pngSha256']} for x in images],'notes':notes[mode],'scope':'Own foreground window in this specific theme/sidebar cohort only','fullMatrixAccepted':False,'darkModeAndCaptionNativeGetterClaimed':False,'systemSettingsChanged':False}
with (c/'visual-review.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2,ensure_ascii=False)
print('Actual visual review saved for '+mode,flush=True)
