from pathlib import Path
import ast,hashlib,json,shutil,subprocess
w=Path(__file__).parent;old='rf121-backdrop-checks-20261011';new='rf121-backdrop-checks-after-picker-20261011';s=w/new;s.mkdir(exist_ok=False)
for name in ['sources.json','runtime-package.json','native-clippy.receipt.json','native-release-build.receipt.json','native-contract-tests.receipt.json','native-contract-tests-retry1.receipt.json']:
    shutil.copy2(w/old/name,s/name)
changes={
'run-rf121-backdrop-native-surfaces-candidate.py':'run-rf121-backdrop-after-picker.py',
'verify-rf121-backdrop-native-surfaces-candidate.mjs':'verify-rf121-backdrop-after-picker.mjs',
'render-rf121-backdrop-captures.py':'render-rf121-backdrop-after-picker.py',
'run-backdrop-captures.py':'run-backdrop-after-picker-queue.py'}
hashes={}
for original,target in changes.items():
    text=(w/original).read_text(encoding='utf8');original_sha=hashlib.sha256((w/original).read_bytes()).hexdigest()
    text=text.replace(old,new).replace("mode + '-20261011'","mode + '-after-picker-20261011'").replace('${mode}-20261011','${mode}-after-picker-20261011').replace("sys.argv[1][2:] + '-20261011'","sys.argv[1][2:] + '-after-picker-20261011'")
    if original=='run-backdrop-captures.py':
        for a,b in changes.items():text=text.replace(a,b)
        text=text.replace("'rf121-backdrop-session-before-'","'rf121-backdrop-after-picker-session-before-'")
        anchor="    save('cohort-'+mode+'.json',rows[-1])";assert text.count(anchor)==1
        text=text.replace(anchor,anchor+'\n    if independent!=0:break  # Full acceptance still requires all four cohorts.')
    if target.endswith('.py'):ast.parse(text)
    with (w/target).open('x',encoding='utf8') as f:f.write(text)
    hashes[target]={'original':original,'originalSha256':original_sha,'retrySha256':hashlib.sha256((w/target).read_bytes()).hexdigest()}
p=subprocess.run(['node','--check',str(w/changes['verify-rf121-backdrop-native-surfaces-candidate.mjs'])],capture_output=True);assert p.returncode==0
with (s/'retry-preparation.json').open('x',encoding='utf8') as f:json.dump({'sources':hashes,'freshOutputSuffix':'after-picker-20261011','originalEvidencePreserved':True,'guardLogicChanged':False,'allFourRequiredForSuccess':True,'stopAfterFailedFirstCohort':True,'nodeSyntaxExitCode':p.returncode,'applicationExecuted':False},f,indent=2)
print('Exclusive retry prepared; same frozen runtime/source/resources and full guards',flush=True)
