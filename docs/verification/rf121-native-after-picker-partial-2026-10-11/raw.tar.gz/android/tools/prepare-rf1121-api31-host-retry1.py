from pathlib import Path
import ast,json
b=Path(__file__).parent;s=(b/'boot-rf1121-current-host-retry1.py').read_text(encoding='utf8')
assert s.count("=='35'")==1
s=s.replace('api35-host-rf1121-retry1-20261011','api31-host-rf1121-20261011').replace('SoloSoul_RF121_20261010','SoloSoul_RF121_API31_20261010').replace("=='35'","=='31'")
ast.parse(s)
with (b/'boot-rf1121-api31-host.py').open('x',encoding='utf8') as f:f.write(s)
with (b/'api31-host-preparation-first-failure.json').open('x',encoding='utf8') as f:json.dump({'exitCode':1,'reason':'Generator assertion: API replacement omitted closing parenthesis in old anchor','bootScriptWritten':False,'deviceStartedByFailedGenerator':False},f,indent=2)
