from pathlib import Path
import ast,json
b=Path(__file__).parent;s=(b/'verify-rf1121-current-api35-native.py').read_text(encoding='utf8')
assert s.count('35')==10
s=s.replace('35','31').replace('api31-host-rf1121-retry1-20261011','api31-host-rf1121-20261011').replace('SoloSoul_RF121_20261010','SoloSoul_RF121_API31_20261010')
s=s.replace("owned = load(base/'api31-host-rf1121-20261011/owned-processes-after-launch.json')","owned = [x for x in load(base/'api31-host-rf1121-20261011/owned-processes-after-launch.json') if x['ProcessId']==boot['pid']]")
assert '35' not in s;ast.parse(s)
with (b/'verify-rf1121-current-api31-native.py').open('x',encoding='utf8') as f:f.write(s)
with (b/'api31-native-preparation-first-failure.json').open('x',encoding='utf8') as f:json.dump({'generatorExitCode':1,'subsequentNonexistentScriptExitCode':2,'reason':'API replacement anchor omitted closing parenthesis; generator assertion stopped before writing','deviceMutated':False},f,indent=2)
