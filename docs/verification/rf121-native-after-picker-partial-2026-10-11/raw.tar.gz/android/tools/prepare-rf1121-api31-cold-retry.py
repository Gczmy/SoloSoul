from pathlib import Path
import ast,json
b=Path(__file__).parent
v=json.loads((b/'api31-home-rf1121-blur-compensation-20261011/restoration.json').read_text(encoding='utf8'));assert v['deviceRestorationComplete'] and v['all216FileContentsLinksModesMatch']
s=(b/'verify-rf1121-current-api31-home.py').read_text(encoding='utf8')
s=s.replace('api31-home-rf1121-current-20261011','api31-home-rf1121-cold-fallback-retry1-20261011').replace("for scenario in ['baseline','cold']:","for scenario in ['cold']:").replace(" for mode in ['supported','fallback']:"," for mode in ['fallback']:").replace('accepted=len(rows)==4','accepted=len(rows)==1').replace('API31 baseline/cold in both native glass modes','Single cold fallback retry after independently completed ADB/blur restoration; original four-row group remains failed')
ast.parse(s)
with (b/'verify-rf1121-api31-cold-fallback-retry1.py').open('x',encoding='utf8') as f:f.write(s)
