from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess
b=Path(__file__).parent;r=Path('D:/SoloSoul');stage=b/'api31-home-rf1121-blur-compensation-20261011';stage.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
last=load(b/'api31-home-rf1121-current-20261011/verification.json')['results'][-1]
assert last['scenario']=='cold' and last['mode']=='fallback' and not last['restored'] and last['settingsAfter']['blur']=='1' and last['settingsBefore']['blur']=='null'
native=load(b/'api31-home-rf1121-current-20261011/cold-fallback/report.json');assert native['restored'] and native['restoreVerification']['allFileContentsLinksAndModesMatch'] and native['blurRestoreError']
owned=next(x for x in load(b/'api31-host-rf1121-20261011/owned-processes-after-launch.json') if x['Name']=='emulator.exe')
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
p=subprocess.run([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {owned['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json"],check=True,capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW);live=json.loads(p.stdout)
for key in ['Name','ProcessId','ExecutablePath','CommandLine']:assert live[key]==owned[key]
assert datetime.datetime.fromisoformat(live['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
env=os.environ.copy();env.update({'ANDROID_ADB_SERVER_PORT':'5049','ADB_SERVER_SOCKET':'tcp:localhost:5049','TEMP':str(b/'tmp'),'TMP':str(b/'tmp')})
def call(args):return subprocess.run([str(b/'sdk/platform-tools/adb.exe'),'-H','localhost','-P','5049','-s','emulator-5586',*args],env=env,capture_output=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW)
def read(args):
    a=call(args);assert a.returncode==0,(args,a.stderr);return a.stdout.decode().strip()
assert read(['emu','avd','name']).splitlines()[0]=='SoloSoul_RF121_API31_20261010'
state=lambda:{'blur':read(['shell','settings','get','global','disable_window_blurs']),'night':read(['shell','cmd','uimode','night']),'fontScale':read(['shell','settings','get','system','font_scale'])}
before=state();assert before==last['settingsAfter']
pid=call(['shell','pidof','com.solosoul.app']);assert pid.returncode in [0,1] and not pid.stdout.strip()
backup=Path(native['backup']['path']);assert hashlib.sha256(backup.read_bytes()).hexdigest()==native['backup']['sha256']
command=['shell','settings','delete','global','disable_window_blurs'];a=call(command)
with (stage/'restore.stdout.log').open('xb') as f:f.write(a.stdout)
with (stage/'restore.stderr.log').open('xb') as f:f.write(a.stderr)
assert a.returncode==0
after=state();assert after==last['settingsBefore']
a=call(['exec-out','run-as','com.solosoul.app','tar','-cf','-','.']);assert a.returncode==0
fresh=stage/'private-data-readback.tar'
with fresh.open('xb') as f:f.write(a.stdout)
spec=importlib.util.spec_from_file_location('native_home_inventory',r/'tauri/scripts/android-home-native-regression.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
original=module.inventory(backup,require_empty=True);observed=module.inventory(fresh,require_empty=True);assert original==observed and len(observed)==216
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exactOwnedIdentity':live,'settingsBefore':before,'settingsAfter':after,'actualRestoreExitCode':a.returncode,'all216FileContentsLinksModesMatch':True,'freshPrivateReadbackSha256':hashlib.sha256(fresh.read_bytes()).hexdigest(),'backupSha256':native['backup']['sha256'],'originalFailedCaseRemainsFailed':True,'deviceRestorationComplete':True,'testsRetried':False}
with (stage/'restoration.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2)
print('Exact blur restored; all216 private files/links/modes independently match; original failure preserved',flush=True)
