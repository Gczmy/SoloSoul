from pathlib import Path
import ast
b=Path(__file__).parent;s=(b/'verify-api35-native-current.py').read_text(encoding='utf8')
s=s.replace('current-apks-recovery2/current-apks.json','current-apks-rf1121-20261011/current-apks.json').replace('len(sources) == 1830','len(sources) == 1834').replace("stage = base / 'api35-native-current-round1'","stage = base / 'api35-native-rf1121-current-20261011'")
gate='''
boot = load(base/'api35-host-rf1121-retry1-20261011/boot.receipt.json')
assert boot['booted'] and boot['avdConfigUnchanged']
owned = load(base/'api35-host-rf1121-retry1-20261011/owned-processes-after-launch.json')
assert len(owned)==1 and owned[0]['ProcessId']==boot['pid']
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
probe=subprocess.run([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {boot['pid']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3"],check=True,capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
live=json.loads(probe.stdout)
for key in ['Name','ProcessId','ExecutablePath','CommandLine']:assert live[key]==owned[0][key],key
assert datetime.datetime.fromisoformat(live['CreationDate'])==datetime.datetime.fromisoformat(owned[0]['CreationDate'])
save('owned-emulator-preflight.json',{'live':live,'exactBirthExecutableCommandVerified':True})
'''
anchor="assert read(['get-state']) == 'device'";assert s.count(anchor)==1;s=s.replace(anchor,gate+'\n'+anchor)
ast.parse(s)
with (b/'verify-rf1121-current-api35-native.py').open('x',encoding='utf8') as f:f.write(s)
