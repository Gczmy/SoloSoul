from pathlib import Path
import ast
b=Path(__file__).parent;r=Path('D:/SoloSoul');w=r/'build/rf121-theme-binding-20261010'
t=(b/'package-current-apks-with-copied-jni.py').read_text(encoding='utf8')
start=t.index("terminal = load(base / 'build-wrapper-terminal.json')");end=t.index('\ndef verify():',start)
t=t[:start]+'''current_checks = root / 'build/rf121-theme-binding-20261010/rf1121-checks-20261011'
strict = load(current_checks / 'green-android.receipt.json')
assert strict['exitCode'] == 0 and strict['sourceUnchanged']
assert strict['command'][-2:] == ['-D', 'warnings'] and 'x86_64-linux-android' in strict['command']
sources = load(current_checks / 'green-sources.json')
assert len(sources) == 1834
assert sources == load(root / 'build/rf121-theme-binding-20261010/rf121-backdrop-checks-20261011/sources.json')
main_failure = load(base / 'android-current-main-apk.receipt.json')
assert main_failure['exitCode'] == 1
''' + t[end:]
def once(a,c):
    global t
    assert t.count(a)==1,a;t=t.replace(a,c)
once("stage = base / 'current-apks-recovery2'","stage = base / 'current-apks-rf1121-20261011'")
once("jni = gradle / 'app/src/main/jniLibs/x86_64/libsolo_soul.so'\nphysical(jni.parent)\nassert not jni.exists()", "jni = stage / 'packaging-jni/x86_64/libsolo_soul.so'\njni.parent.mkdir(parents=True, exist_ok=False)\nphysical(jni.parent)\nassert not jni.exists()")
once("assets.as_posix() + \"')])\\n  }\\n}\\n\")", "assets.as_posix() + \"')])\\n\" +\n        \"    project.extensions.getByName('android').sourceSets.getByName('main').jniLibs.setSrcDirs([project.file('\" +\n        (stage / 'packaging-jni').as_posix() + \"')])\\n  }\\n}\\n\")")
once("'sourceRestorationReceiptSha256': sha(base / 'post-build-source-restoration.json'),", "'actualCurrentAndroidStrictReceiptSha256': sha(current_checks / 'green-android.receipt.json'),\n    'actualCurrentAndroidStrictReceipt': strict, 'historicalFailureOnly': True,")
once("'scope': 'Full current default Debug x86_64 APK pair packaged by Gradle; Tauri symlink failure remains visible',", "'scope': 'Current RF1121 default strict-compiled JNI; full Debug x86_64 APK pair built by Gradle with private assets/JNI directories; historical Tauri symlink failure preserved',")
once("'sourceProductCodeChanged': False,", "'sourceProductCodeChanged': False, 'privateJniSourceLocationOverride': True, 'trackedOrExistingJniFilesOverwritten': 0,")
ast.parse(t)
p=b/'package-rf1121-current-apks.py'
with p.open('x',encoding='utf8',newline='\n') as f:f.write(t)
print('Current-source strict JNI APK packaging prepared; private JNI/assets only, not executed')
