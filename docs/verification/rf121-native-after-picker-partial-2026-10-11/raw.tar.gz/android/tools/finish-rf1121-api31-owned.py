"""Freeze diagnostics and gracefully stop only the proven owned AVD."""
from pathlib import Path
import datetime,json,os,socket,subprocess,time
b=Path(__file__).parent;s=b/'api31-host-rf1121-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
owned=load(s/'owned-processes-after-launch.json')[0];boot=load(s/'boot.receipt.json')
v=load(b/'api31-native-rf1121-current-20261011/verification.json');assert len(v['results'])==2 and all(x['restorationErrorsAbsent'] for x in v['results'])
v=load(b/'api31-home-rf1121-cold-fallback-retry1-20261011/verification.json');assert v['accepted'] and len(v['results'])==1 and v['results'][0]['restored']
v=load(b/'api31-home-rf1121-blur-compensation-20261011/restoration.json');assert v['deviceRestorationComplete']
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
def identity():
    p=subprocess.run([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {owned['ProcessId']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json"],check=True,capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
    return json.loads(p.stdout) if p.stdout.strip() else None
live=identity();assert live
for key in ['Name','ProcessId','ExecutablePath','CommandLine']:assert live[key]==owned[key],key
assert datetime.datetime.fromisoformat(live['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
env=os.environ.copy();env.update({'ANDROID_ADB_SERVER_PORT':'5049','ADB_SERVER_SOCKET':'tcp:localhost:5049','TEMP':str(b/'tmp'),'TMP':str(b/'tmp')})
def call(args):return subprocess.run([str(b/'sdk/platform-tools/adb.exe'),'-H','localhost','-P','5049','-s','emulator-5586',*args],env=env,capture_output=True,timeout=30,creationflags=subprocess.CREATE_NO_WINDOW)
def read(args):
    p=call(args);assert p.returncode==0;return p.stdout.decode().strip()
assert read(['emu','avd','name']).splitlines()[0]=='SoloSoul_RF121_API31_20261010'
settings={'blur':read(['shell','settings','get','global','disable_window_blurs']),'night':read(['shell','cmd','uimode','night'])};assert settings==boot['settingsBeforeTests']
p=call(['logcat','-d','-s','chromium:W']);assert p.returncode==0
with (s/'chromium-readonly-final.log').open('xb') as f:f.write(p.stdout)
result={'liveIdentity':live,'exactIdentityVerified':True,'settingsRestored':True,'settings':settings,'noForceTermination':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
p=call(['emu','kill']);result.update({'stopExitCode':p.returncode,'stopStdout':p.stdout.decode(errors='replace'),'stopStderr':p.stderr.decode(errors='replace')});assert p.returncode==0
deadline=time.monotonic()+40
while identity() is not None:
    assert time.monotonic()<deadline,'Owned AVD did not exit';time.sleep(1)
for port in [5586,5587]:
    with socket.socket() as sock:sock.bind(('127.0.0.1',port))
result['ownedProcessExited']=True;result['dedicatedPortsFree']=True
with (s/'stop.receipt.json').open('x',encoding='utf8') as f:json.dump(result,f,indent=2)
print('API31 diagnostics frozen; exact owned AVD gracefully exited',flush=True)
