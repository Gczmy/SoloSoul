from pathlib import Path
import ast,json
b=Path(__file__).parent;r=Path('D:/SoloSoul')
main=(r/'tauri/scripts/android-native-regression.mjs').read_text(encoding='utf8')
tail=(b/'native-remaining-seven.mjs').read_text(encoding='utf8')
assert tail.replace('casesFor(options.mode).slice(-7)','casesFor(options.mode)')==main
v=json.loads((b/'api35-native-rf1121-current-20261011/verification.json').read_text(encoding='utf8'));assert not v['accepted'] and all(x['restorationErrorsAbsent'] for x in v['results'])
s=(b/'verify-rf1121-current-api35-native.py').read_text(encoding='utf8')
s=s.replace('api35-native-rf1121-current-20261011','api35-native-rf1121-tail-20261011').replace("[('supported', 13), ('fallback', 11)]","[('supported', 7), ('fallback', 7)]").replace("'scripts/android-native-regression.mjs'","str(base/'native-remaining-seven.mjs')").replace('API35 existing 13 supported and 11 fallback native instrumentation methods','Independent last seven methods per mode; full groups remain failed on WebGL')
ast.parse(s)
with (b/'verify-rf1121-current-api35-tail.py').open('x',encoding='utf8') as f:f.write(s)
