from pathlib import Path
import ast
b=Path(__file__).parent;s=(b/'finish-rf1121-api35-owned.py').read_text(encoding='utf8')
s=s.replace('api35-host-rf1121-retry1-20261011','api31-host-rf1121-20261011').replace('SoloSoul_RF121_20261010','SoloSoul_RF121_API31_20261010').replace('API35','API31')
old="""for name in ['api35-native-rf1121-current-20261011','api35-native-rf1121-tail-20261011']:
    v=load(b/name/'verification.json');assert len(v['results'])==2 and all(x['restorationErrorsAbsent'] for x in v['results'])"""
new="""v=load(b/'api31-native-rf1121-current-20261011/verification.json');assert len(v['results'])==2 and all(x['restorationErrorsAbsent'] for x in v['results'])
v=load(b/'api31-home-rf1121-cold-fallback-retry1-20261011/verification.json');assert v['accepted'] and len(v['results'])==1 and v['results'][0]['restored']
v=load(b/'api31-home-rf1121-blur-compensation-20261011/restoration.json');assert v['deviceRestorationComplete']"""
assert s.count(old)==1;s=s.replace(old,new)
ast.parse(s)
with (b/'finish-rf1121-api31-owned.py').open('x',encoding='utf8') as f:f.write(s)
