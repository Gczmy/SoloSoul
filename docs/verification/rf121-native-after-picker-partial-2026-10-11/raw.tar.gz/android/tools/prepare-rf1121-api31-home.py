from pathlib import Path
import ast
b=Path(__file__).parent
s=(b/'verify-api31-home-current-original.py').read_text(encoding='utf8')
s=s.replace('rf1112-preview-fresh-reminder-test-build5/current-apks.json','current-apks-rf1121-20261011/current-apks.json').replace('len(sources)==1830','len(sources)==1834').replace('api31-home-current-round1','api31-home-rf1121-current-20261011')
gate=(b/'verify-rf1121-current-api31-native.py').read_text(encoding='utf8').split("boot = load(base/")[1].split("assert read(['get-state'])")[0]
gate="boot = load(base/"+gate
assert 'exactBirthExecutableCommandVerified' in gate
anchor="assert read(['get-state'])=='device'";assert s.count(anchor)==1
s=s.replace(anchor,gate+'\n'+anchor)
ast.parse(s)
with (b/'verify-rf1121-current-api31-home.py').open('x',encoding='utf8') as f:f.write(s)
