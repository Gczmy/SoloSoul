"""Package the actual compiled default Android product without host symlinks.

The failed Tauri command remains failed. Only its completed Rust output and
configuration-defined resources are copied; Gradle still compiles all Java,
Kotlin, application and instrumentation code and signs the Debug APKs.
"""
from pathlib import Path
import datetime, hashlib, json, os, re, shutil, struct, subprocess, time, zipfile

root = Path('D:/SoloSoul')
base = Path(__file__).parent.resolve()
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()

current_checks = root / 'build/rf121-theme-binding-20261010/rf1121-checks-20261011'
strict = load(current_checks / 'green-android.receipt.json')
assert strict['exitCode'] == 0 and strict['sourceUnchanged']
assert strict['command'][-2:] == ['-D', 'warnings'] and 'x86_64-linux-android' in strict['command']
sources = load(current_checks / 'green-sources.json')
assert len(sources) == 1834
assert sources == load(root / 'build/rf121-theme-binding-20261010/rf121-backdrop-checks-20261011/sources.json')
main_failure = load(base / 'android-current-main-apk.receipt.json')
assert main_failure['exitCode'] == 1

def verify():
    for name, digest in sources.items(): assert sha(root / name) == digest, name

def physical(path):
    assert path.resolve().is_relative_to(root.resolve()), path
    cursor = path if path.exists() else path.parent
    while cursor != root.parent:
        try:
            info = cursor.lstat()
        except FileNotFoundError:
            cursor = cursor.parent
            continue
        assert not cursor.is_symlink() and not (info.st_file_attributes & 0x400), cursor
        cursor = cursor.parent

verify()
stage = base / 'current-apks-rf1121-20261011'
stage.mkdir(exist_ok=False)
def save(name, data):
    with (stage / name).open('x', encoding='utf-8', newline='\n') as out:
        out.write(json.dumps(data, indent=2) + '\n')

gradle = root / 'tauri/src-tauri/gen/android'
sdk = base / 'sdk'
jdk = Path('C:/Users/40299571/ss-android/jdk')
library = base / 'cargo-target/x86_64-linux-android/debug/libsolo_soul.so'
physical(library)
with library.open('rb') as stream: header = stream.read(64)
assert header[:6] == b'\x7fELF\x02\x01'
assert struct.unpack_from('<HH', header, 16) == (3, 62)
library_sha = sha(library)
fingerprints = []
for path in (base / 'cargo-target/x86_64-linux-android/debug/.fingerprint').glob('solo_soul-*/lib-solo_soul.json'):
    value = load(path)
    assert 'native-perf' not in value['features'] and 'custom-protocol' in value['features']
    fingerprints.append({'path': str(path), 'sha256': sha(path), 'features': value['features']})
assert fingerprints
settings = gradle / 'tauri.settings.gradle'
module_dirs = [Path(json.loads('"' + value + '"')) for value in re.findall(r'new File\("([^"]+)"\)', settings.read_text())]
assert module_dirs and all(path.resolve().is_relative_to((base / 'cargo-home').resolve()) for path in module_dirs)

source_assets = gradle / 'app/src/main/assets'
physical(source_assets)
assets = stage / 'packaging-assets'
assets.mkdir(exist_ok=False)
manifest_source = root / 'tauri/src-tauri/resources-mobile/bundled-resource-manifest.json'
manifest = load(manifest_source)
entries = manifest['files']
assert manifest['schema'] == 1 and entries and len({row['path'] for row in entries}) == len(entries)
ordered = sorted(entries, key=lambda row: row['path'].encode('utf-16-be'))
version_text = ''.join(f"{row['path']}\0{row['size']}\0{row['sha256']}\n" for row in ordered)
assert hashlib.sha256(version_text.encode()).hexdigest() == manifest['version']
resources = dict(load(root / 'tauri/src-tauri/tauri.conf.json')['bundle']['resources'])
resources.update(load(root / 'tauri/src-tauri/tauri.android.conf.json')['bundle']['resources'])
assert resources == {'resources/docs': 'docs',
    'resources-mobile/bundled-resource-manifest.json': 'bundled-resource-manifest.json',
    'resources-mobile/SoloSoul_plugin_market/plugins': 'SoloSoul_plugin_market/plugins',
    'resources-mobile/SoloSoul_plugin_market/registry.json': 'SoloSoul_plugin_market/registry.json'}
expected_assets = {row['path'] for row in entries} | {'bundled-resource-manifest.json'}
existing_assets = {path.relative_to(source_assets).as_posix() for path in source_assets.rglob('*') if path.is_file()}
stale_assets = existing_assets - expected_assets
known_stale = {f'docs/guides/{language}/{name}' for language in ['en', 'zh'] for name in
    ['PRIVACY_POLICY.md', 'TERMS_OF_SERVICE.md', 'device-sync.md', 'sync-smoke-test.md']}
assert stale_assets == known_stale, stale_assets
source_asset_hashes = {}
for name in sorted(existing_assets):
    source = source_assets / name
    physical(source)
    digest = sha(source)
    copy = assets / name
    copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, copy)
    assert sha(copy) == digest
    source_asset_hashes[name] = digest
save('original-source-assets.json', {'scope': 'Complete original assets preserved; private packaging copies only',
    'sourceFiles': source_asset_hashes, 'additionalTrackedAssetPaths': sorted(stale_assets),
    'trackedSourceFilesRemoved': 0, 'trackedSourceFilesOverwritten': 0})
copied_resources = []
for row in entries:
    name = row['path']
    assert name.startswith(('docs/', 'SoloSoul_plugin_market/'))
    assert all(part not in ('', '.', '..') for part in name.split('/')) and not any(c in name for c in '\\\t\r\n\0')
    if name.startswith('docs/'):
        source = root / 'tauri/src-tauri/resources' / name
    else:
        source = root / 'tauri/src-tauri/resources-mobile' / name
    snapshot_used = False
    if sha(source) != row['sha256']:
        assert name == 'docs/guides/search-index.json'
        snapshot = base / 'generated-build-effects/after/tauri/src-tauri/resources/docs/guides/search-index.json'
        assert sha(snapshot) == row['sha256'] and load(snapshot) == load(source)
        assert sha(source) == sources['tauri/src-tauri/resources/docs/guides/search-index.json']
        source = snapshot
        snapshot_used = True
    assert sha(source) == row['sha256'] and source.stat().st_size == row['size']
    target = assets / name
    physical(source)
    physical(target.parent)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists(): physical(target)
    if not target.exists() or sha(target) != row['sha256']: shutil.copy2(source, target)
    assert sha(target) == row['sha256']
    copied_resources.append({'path': name, 'source': str(source), 'sha256': row['sha256'],
        'bytes': row['size'], 'buildTimeSnapshotUsed': snapshot_used})
manifest_target = assets / 'bundled-resource-manifest.json'
assert not manifest_target.exists()  # Original CLI stopped before this file was staged.
shutil.copy2(manifest_source, manifest_target)
assert sha(manifest_target) == sha(manifest_source)
jni = stage / 'packaging-jni/x86_64/libsolo_soul.so'
jni.parent.mkdir(parents=True, exist_ok=False)
physical(jni.parent)
assert not jni.exists()
shutil.copy2(library, jni)
assert sha(jni) == library_sha and not jni.is_symlink()
verify()
assert all(sha(source_assets / name) == digest for name, digest in source_asset_hashes.items())
init_script = stage / 'private-packaging-assets.init.gradle'
with init_script.open('x', encoding='utf-8', newline='\n') as out:
    out.write("gradle.beforeProject { project ->\n" +
        "  project.pluginManager.withPlugin('com.android.application') {\n" +
        "    project.extensions.getByName('android').sourceSets.getByName('main').assets.setSrcDirs([project.file('" +
        assets.as_posix() + "')])\n" +
        "    project.extensions.getByName('android').sourceSets.getByName('main').jniLibs.setSrcDirs([project.file('" +
        (stage / 'packaging-jni').as_posix() + "')])\n  }\n}\n")
save('input-proof.json', {'originalTauriCommandExitCode': 1, 'originalFailurePreserved': True,
    'originalFailureReceiptSha256': sha(base / 'android-current-main-apk.receipt.json'),
    'actualCurrentAndroidStrictReceiptSha256': sha(current_checks / 'green-android.receipt.json'),
    'actualCurrentAndroidStrictReceipt': strict, 'historicalFailureOnly': True,
    'sourceFiles': sources, 'rustCompilationFinishedObserved': True,
    'library': str(library), 'librarySha256': library_sha, 'libraryBytes': library.stat().st_size,
    'elfClassBits': 64, 'elfType': 3, 'elfMachine': 62, 'jniCopy': str(jni),
    'fingerprints': fingerprints, 'tauriSettingsSha256': sha(settings),
    'dependencyModuleDirectories': [str(path) for path in module_dirs],
    'resourceConfig': resources, 'resourceManifestSha256': sha(manifest_source),
    'resourceVersion': manifest['version'], 'resourceFiles': copied_resources,
    'originalSourceAssetHashes': source_asset_hashes, 'additionalTrackedAssetPaths': sorted(stale_assets),
    'packagingAssetsDirectory': str(assets), 'gradleInitScriptSha256': sha(init_script),
    'assetSourceLocationOverrideOnly': True, 'allOriginalAssetsRetained': True,
    'systemSettingsChanged': False, 'developerModeChanged': False, 'sourceProductCodeChanged': False, 'privateJniSourceLocationOverride': True, 'trackedOrExistingJniFilesOverwritten': 0,
    'scope': 'Full default Debug x86_64 product packaging from the actual compiled JNI library; no device acceptance'})

env = os.environ.copy()
env.update({'JAVA_HOME': str(jdk), 'ANDROID_HOME': str(sdk), 'ANDROID_SDK_ROOT': str(sdk),
    'NDK_HOME': str(sdk / 'ndk/27.0.12077973'), 'ANDROID_NDK_HOME': str(sdk / 'ndk/27.0.12077973'),
    'ANDROID_USER_HOME': str(base / 'android-user'), 'ANDROID_EMULATOR_HOME': str(base / 'android-user'),
    'ANDROID_AVD_HOME': str(base / 'avd'), 'ANDROID_ADB_SERVER_PORT': '5049',
    'ADB_SERVER_SOCKET': 'tcp:localhost:5049', 'RUSTUP_HOME': str(base / 'rustup'),
    'RUSTUP_TOOLCHAIN': '1.96.0', 'CARGO_HOME': str(base / 'cargo-home'),
    'CARGO_TARGET_DIR': str(base / 'cargo-target'), 'CARGO_BUILD_JOBS': '1',
    'GRADLE_USER_HOME': str(base / 'gradle-home'), 'ORT_CACHE_DIR': str(base / 'ort-cache'),
    'TEMP': str(base / 'tmp'), 'TMP': str(base / 'tmp'),
    'JAVA_TOOL_OPTIONS': f'-Duser.home={base / "java-home"} -Djava.io.tmpdir={base / "tmp"}'})
for key in ['ANDROID_SDK_HOME', 'PDFIUM_LIBRARY_PATH', 'SOLOSOUL_KEYSTORE_PATH',
    'SOLOSOUL_KEYSTORE_PASSWORD', 'SOLOSOUL_KEY_ALIAS', 'SOLOSOUL_KEY_PASSWORD', 'SOLOSOUL_REGISTRY_PUBKEY']:
    env.pop(key, None)
env['PATH'] = str(base / 'cargo-home/bin') + ';' + str(jdk / 'bin') + ';' + env.get('PATH', '')

def run(name, command, cwd):
    began = time.monotonic()
    with (stage / (name + '.stdout.log')).open('xb') as out, (stage / (name + '.stderr.log')).open('xb') as err:
        p = subprocess.Popen(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
            stdout=out, stderr=err, creationflags=subprocess.CREATE_NO_WINDOW)
        save(name + '.live.json', {'pid': p.pid, 'command': command})
        print(f'{name} live PID {p.pid}', flush=True)
        code = p.wait()
    changed = [name for name, digest in sources.items() if sha(root / name) != digest]
    source_assets_equal = all(sha(source_assets / name) == digest for name, digest in source_asset_hashes.items())
    save(name + '.receipt.json', {'command': command, 'exitCode': code,
        'elapsedSeconds': time.monotonic() - began, 'changedSourceFiles': changed,
        'sourceUnchanged': not changed, 'jniCopySha256': sha(jni),
        'originalSourceAssetsUnchanged': source_assets_equal,
        'originalLibrarySha256': sha(library), 'at': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    print(f'{name} terminal exit {code}', flush=True)
    assert code == 0 and not changed and source_assets_equal and sha(jni) == sha(library) == library_sha, (name, code, changed)

for kind, task in [('main-build', ':app:assembleX86_64Debug'), ('test-build', ':app:assembleX86_64DebugAndroidTest')]:
    run(kind, ['cmd.exe', '/d', '/c', str(gradle / 'gradlew.bat'), task,
        '-x', ':app:rustBuildX86_64Debug', '--init-script', str(init_script),
        '--no-daemon', '--max-workers', '2'], gradle)

files = []
apkroot = gradle / 'app/build/outputs/apk'
for kind, source, package in [('main', apkroot / 'x86_64/debug/app-x86_64-debug.apk', 'com.solosoul.app'),
    ('test', apkroot / 'androidTest/x86_64/debug/app-x86_64-debug-androidTest.apk', 'com.solosoul.app.test')]:
    copy = stage / source.name
    shutil.copy2(source, copy)
    assert sha(copy) == sha(source)
    run(kind + '-badging', [str(sdk / 'build-tools/35.0.0/aapt2.exe'), 'dump', 'badging', str(copy)], stage)
    badging = (stage / (kind + '-badging.stdout.log')).read_text(encoding='utf-8')
    assert re.search(r"^package: name='" + re.escape(package) + r"'", badging, re.M)
    if kind == 'main': assert "versionName='2.13.2'" in badging and 'application-debuggable' in badging
    run(kind + '-signature', [str(jdk / 'bin/java.exe'), '-jar',
        str(sdk / 'build-tools/35.0.0/lib/apksigner.jar'), 'verify', '--verbose', str(copy)], stage)
    with zipfile.ZipFile(copy) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        libraries = [name for name in names if name.startswith('lib/') and name.endswith('.so')]
        assert not any(Path(name).name in {'header-install.bmp', 'header-uninstall.bmp', 'welcome-sidebar.bmp'} for name in names)
        if kind == 'main':
            assert libraries and all(name.startswith('lib/x86_64/') for name in libraries)
            h = hashlib.sha256()
            with archive.open('lib/x86_64/libsolo_soul.so') as stream:
                for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''): h.update(chunk)
            assert h.hexdigest() == library_sha
            assert hashlib.sha256(archive.read('assets/bundled-resource-manifest.json')).hexdigest() == sha(manifest_source)
            for row in entries:
                data = archive.read('assets/' + row['path'])
                assert len(data) == row['size'] and hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
            for name in stale_assets:
                assert hashlib.sha256(archive.read('assets/' + name)).hexdigest() == source_asset_hashes[name], name
    files.append({'kind': kind, 'source': str(source), 'copy': str(copy), 'sha256': sha(copy),
        'bytes': copy.stat().st_size, 'package': package, 'zipEntries': len(names),
        'nativeLibraries': libraries, 'signatureVerified': True})
verify()
assert all(sha(source_assets / name) == digest for name, digest in source_asset_hashes.items())
save('current-apks.json', {'accepted': True, 'files': files, 'sourceFiles': sources,
    'librarySha256': library_sha, 'originalTauriCommandExitCode': 1,
    'originalFailurePreserved': True, 'rustBuildRepeated': False, 'systemSettingsChanged': False,
    'scope': 'Current RF1121 default strict-compiled JNI; full Debug x86_64 APK pair built by Gradle with private assets/JNI directories; historical Tauri symlink failure preserved',
    'defaultAndroidProductCodeChanged': False, 'appAcceptance': False, 'deviceAcceptance': False,
    'at': datetime.datetime.now(datetime.timezone.utc).isoformat()})
print('Current APK pair frozen; compiled JNI and every packaged resource match; device regression required', flush=True)
