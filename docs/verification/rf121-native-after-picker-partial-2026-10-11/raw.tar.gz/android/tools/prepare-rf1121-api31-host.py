from pathlib import Path
import ast
b=Path(__file__).parent;s=(b/'boot-rf1121-current-host-retry1.py').read_text(encoding='utf8')
s=s.replace('api35-host-rf1121-retry1-20261011','api31-host-rf1121-20261011').replace('SoloSoul_RF121_20261010','SoloSoul_RF121_API31_20261010').replace("]=='35'","]=='31'")
assert "=='35'" not in s
ast.parse(s)
with (b/'boot-rf1121-api31-host.py').open('x',encoding='utf8') as f:f.write(s)
