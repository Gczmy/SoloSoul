from pathlib import Path
import ast
b=Path(__file__).parent;s=(b/'verify-rf1121-current-api35-native.py').read_text(encoding='utf8')
s=s.replace('api35-native-rf1121-current-20261011','api31-native-rf1121-current-20261011').replace('api35-host-rf1121-retry1-20261011','api31-host-rf1121-20261011').replace('SoloSoul_RF121_20261010','SoloSoul_RF121_API31_20261010').replace('API35','API31').replace("] == '35'","] == '31'").replace("report.get('api') == 35","report.get('api') == 31")
assert "== '35'" not in s
s=s.replace("owned = load(base/'api31-host-rf1121-20261011/owned-processes-after-launch.json')","owned = [x for x in load(base/'api31-host-rf1121-20261011/owned-processes-after-launch.json') if x['ProcessId']==boot['pid']]")
ast.parse(s)
with (b/'verify-rf1121-current-api31-native.py').open('x',encoding='utf8') as f:f.write(s)
