from pathlib import Path
import hashlib,json
W=Path(__file__).parent;S=W/'rf1127-current-minimized-matrix-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
done=load(S/'cohorts-complete.json');assert not done['accepted'] and [r['scene'] for r in done['rows']]==['baseline','light-collapsed','dark-expanded']
groups=[]
for cohort in done['rows']:
 mode=cohort['scene'];C=W/f'ss-rf121-composed-window-restore-{mode}-current-minimized-20261012'
 receipt=load(C/'actual100.receipt.json')
 assert receipt['exitCode'] in [0,1] and all(receipt[k] for k in ['sourceUnchanged','resourcesUnchanged','originalFixtureUnchanged'])
 journey=load(C/'actual100/native-perf-sdk-journey-results.json');assert not journey['interrupted'] and len(journey['samples'])==3
 samples=[]
 for row in journey['samples']:
  assert row['cleanupIntegrity']['complete']
  P=C/'actual100'/f"sample-{row['index']:03}"
  owned=load(P/'native-perf-owned.json');consumed=load(P/'native-perf-consumed.json')
  assert owned==row['owned'] and consumed['pid']==row['processId'] and consumed['runId']==owned['runId']
  assert Path(owned['root']).samefile(P)
  processes=row.get('beforeSnapshot',{}).get('processes',[])+row.get('afterSnapshot',{}).get('processes',[])
  identities=[{'pid':p['pid'],'creationMs':p['creationMs']} for p in processes];assert len(identities)>=9
  samples.append({'index':row['index'],'runId':owned['runId'],'pid':row['processId'],'recordedIdentities':identities})
 groups.append({'label':mode,'captureRoot':str(C),'terminal':True,'samples':samples,'terminalReceiptSha256':sha(C/'actual100.receipt.json'),'acceptanceEvidencePresent':cohort['captureExitCode']==0})
prefix='rf1127-current-minimized'
plan={'cacheCleanupEligible':True,'failedSamplesAccepted':False,'plannedExactCacheTargets':72,'freshCimRequired':True,'groups':groups}
with (W/(prefix+'-cache-cleanup-plan.json')).open('x',encoding='utf-8') as f:json.dump(plan,f,indent=2)
text=(W/'rf1127-current-hitmeta-cleanup-owned.ps1').read_text(encoding='utf-8')
for a,b in [('rf1127-current-hitmeta-cache-cleanup',prefix+'-cache-cleanup'),('groups.Count -ne 1','groups.Count -ne 3'),
 ('One terminal owned group required','Three terminal owned groups required'),('Count -ne 24','Count -ne 72'),
 ('Exact 24 owned cache paths required','Exact 72 owned cache paths required'),('application-logs-rf1127-current-hitmeta','application-logs-'+prefix)]:text=text.replace(a,b)
with (W/(prefix+'-cleanup-owned.ps1')).open('x',encoding='utf-8') as f:f.write(text)
print('Three terminal groups; exact 72 owned cache targets; all nine cleanup identities must be verified fresh')
