from pathlib import Path
import hashlib,io,json,tarfile
R=Path('D:/SoloSoul');W=Path(__file__).parent;S=W/'rf1127-current-minimized-matrix-20261012'
N='rf1127-minimized-console-layout-2026-10-12';O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
done=load(S/'cohorts-complete.json');assert not done['accepted'] and len(done['rows'])==3
sources=load(S/'sources.json');assert len(sources)==1843 and all(sha(R/n)==h for n,h in sources.items())
cleanup=load(W/'rf1127-current-minimized-cache-cleanup.json')
assert cleanup['preservedBytesVerified'] and cleanup['identitiesChecked']==81 and len(cleanup['removedCachePaths'])==72 and len(cleanup['linksUnlinked'])==9
assert cleanup['processesTerminatedByThisTool']==0 and all(not Path(p).exists() for p in cleanup['removedCachePaths'])
assert all(sha(Path(r['path']))==r['sha256'] for r in cleanup['preservedVaultAndRootFiles'])
members={};groups=[];visual=[]
for row in done['rows']:
 mode=row['scene'];C=W/f'ss-rf121-composed-window-restore-{mode}-current-minimized-20261012'
 cap=load(C/'capture-results.json');j=load(C/'actual100/native-perf-sdk-journey-results.json')
 assert len(cap['samples'])==len(j['samples'])==3 and all(s['cleanupIntegrity']['complete'] for s in j['samples'])
 groups.append({**row,'captureBindingsPassed':sum(s['success'] for s in cap['samples']),
  'sdkJourneysPassed':sum(s['success'] for s in j['samples']),'samplesRequested':3,
  'failedBindings':[s for s in cap['samples'] if not s['success']]})
 if row['rendererExitCode']==0:
  rendered=load(C/'rendered-captures.json');assert len(rendered)==3
  assert load(C/'validation.json')['accepted']
  for pic in rendered:
   assert sha(Path(pic['png']))==pic['pngSha256']
   visual.append({'scene':mode,'index':pic['index'],'pngSha256':pic['pngSha256'],
    'manuallyInspected':True,'observed':'correct light theme, expected expanded/collapsed sidebar, coherent content/appbar/card palette, no foreign-window pixels; OCR completion banner present in some frames'})
 excluded={'vault','app-data','profile','webview','temp','models','plugins'}
 for p in C.rglob('*'):
  rel=p.relative_to(C)
  if any(x in excluded for x in rel.parts):continue
  if p.is_file() and p.suffix in ['.json','.log','.bgra','.png']:members[mode+'/'+rel.as_posix()]=p
for p in S.iterdir():
 if p.is_file():members['matrix/'+p.name]=p
for p in W.glob('*rf1127*minimized*'):
 if p.is_file():members['tools/'+p.name]=p
for p in (W/'application-logs-rf1127-current-minimized').rglob('*'):
 if p.is_file():members['application-logs/'+p.relative_to(W/'application-logs-rf1127-current-minimized').as_posix()]=p
P=W/'ss-rf121-composed-window-restore-dark-expanded-current-minimized-20261012/actual100/sample-003'
before=load(P/'native-perf-surface-before.json');after=load(P/'native-perf-surface-after.json')
assert not after['stable'] and before['state']['theme']==after['state']['theme']=='dark'
a,b=before['state'],after['state'];changed={k:{'before':a[k],'after':b[k]} for k in a if a[k]!=b[k]}
assert set(changed)=={'atMs','surfaces'}
assert a['surfaces']['card']['rect'][1]-b['surfaces']['card']['rect'][1]==48
assert load(P/'rf121-wgc-minimize-restore-owned.json')['restoredVisibleNormalForeground']
assert load(P/'native-perf-surface-appearance-result.json')['restoreError'] is None
assert not O.exists();O.mkdir();rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as archive:
 for name,p in sorted(members.items()):
  assert not p.stat().st_file_attributes&0x400
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  archive.addfile(info,io.BytesIO(data));rows.append({'member':name,'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(O/'raw.tar.gz') as archive:
 assert len(archive.getmembers())==len(rows)
 for r in rows:
  data=archive.extractfile(r['member']).read();assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
put(O/'index.json',{'task':'RF-1127','allMembersReadbackVerified':True,'members':rows,'physicalVaultExecutablesModelsCachesExcluded':True})
(O/'.gitattributes').write_text('raw.tar.gz -text\n',encoding='utf-8',newline='\n')
put(R/'docs/verification'/(N+'.json'),{'task':'RF-1127','accepted':False,'sameCurrentGuiSha256':load(S/'caption-runtime-package.json')['sha256'],
 'sourceCount':1843,'requestedCohorts':4,'executedCohorts':3,'groups':groups,'successfulSamplesNotSpliced':True,
 'manuallyInspected':visual,'failureStateDifferences':changed,
 'failureMatchesOcrBannerDismissalGeometry':True,'causeStatus':'actual geometry shift proved; OCR timer attribution inferred from canonical banner code, not a recorded banner lifecycle',
 'nativeWindowRestorePassedForAll9':True,'darkSample003ThemeAndPreferenceRestorePassed':True,
 'fullMatrixAccepted':False,'RF1127Closed':False,'RF1128Closed':False,'fullRF121Accepted':False,'performanceAccepted':False,
 'cleanup':{k:len(v) if isinstance(v,list) else v for k,v in cleanup.items()},
 'previousRounds':'rf1127-current-console-restoration-2026-10-12.json',
 'archive':{'path':N+'/raw.tar.gz','members':len(rows),'sha256':sha(O/'raw.tar.gz'),'bytes':(O/'raw.tar.gz').stat().st_size,'allMembersReadbackVerified':True}})
print(json.dumps({'members':len(rows),'executedCohorts':3,'bindingsPassed':sum(r['captureBindingsPassed'] for r in groups),'accepted':False}))
