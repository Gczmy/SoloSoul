from pathlib import Path
import hashlib,json,shutil,subprocess

R=Path('D:/SoloSoul'); W=Path(__file__).parent.resolve()
B=W/'rf1129-native-build-20261011'; S=W/'rf1130-native-matrix-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def save(n,v):
    with (S/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')

dirty=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).splitlines()
assert set(dirty)=={' M docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md','?? tauri/scripts/native-perf-caption-hit-diagnostic.rs'},dirty
D=W/'rf1130-caption-hit-20261012'
assert load(D/'checks-retry1/checks-complete.json')['accepted']
assert load(B/'build.receipt.json')['exitCode']==0
assert load(B/'dist-input-stability.json')['allGeneratedFrontendInputsUnchangedDuringRustBuild']
sources=load(B/'sources.json'); assert len(sources)==1839
assert all(sha(R/n)==h for n,h in sources.items())
package=load(B/'runtime-package.json'); assert package['currentNativeTests']==137
assert sha(Path(package['exe']))==package['sha256'] and not package['guiExecuted']
package['activationExe']=str(D/'bin/rf1130-owned-caption-foreground.exe')
package['activationSha256']=sha(Path(package['activationExe']))
package['activationSource']=str(D/'helper/src/activate.rs')
package['activationSourceSha256']=sha(Path(package['activationSource']))
package['captionDiagnosticSource']=str(R/'tauri/scripts/native-perf-caption-hit-diagnostic.rs')
package['captionDiagnosticSourceSha256']=sha(Path(package['captionDiagnosticSource']))
package['applicationPreviouslyExecuted']=True
S.mkdir(exist_ok=False)
save('sources.json',sources);save('caption-runtime-package.json',package)
old=W/'rf1128-shared-reader-20261011'
save('restore-helper.json',{'exe':str(D/'bin/rf1130-owned-caption-restore.exe'),'sha256':sha(D/'bin/rf1130-owned-caption-restore.exe'),'source':str(D/'helper/src/restore.rs'),'sourceSha256':sha(D/'helper/src/restore.rs'),'compileInputsUnchanged':True,'captionDiagnosticSourceSha256':sha(R/'tauri/scripts/native-perf-caption-hit-diagnostic.rs')})
names=[('run-rf1128-shared.py','run-rf1130-diagnostic.py'),
       ('verify-rf1128-shared.mjs','verify-rf1130-diagnostic.mjs'),
       ('render-rf1128-shared.py','render-rf1130-diagnostic.py'),
       ('run-rf1128-cohorts.py','run-rf1130-cohorts.py'),
       ('rf1128-session-preflight.py','rf1130-session-preflight.py')]
mapping=[('rf1128-shared-reader-20261011',S.name),
         ('-shared-20261011','-diagnostic-hitmeta-20261012'),
         ("'rf1128-session-'+mode+'.py'","'rf1130-session-'+mode+'.py'"),*names]
tools={}; rows=[]
for a,b in names:
    text=(W/a).read_text(encoding='utf-8')
    changed=text
    for x,y in mapping:changed=changed.replace(x,y)
    p=W/b
    with p.open('x',encoding='utf-8') as f:f.write(changed)
    assert p.read_text(encoding='utf-8')==changed
    tools[str(p.relative_to(R))]=sha(p)
    rows.append({'before':str(W/a),'beforeSha256':sha(W/a),
                 'after':str(p),'afterSha256':sha(p),
                 'changes':'only exclusive output/package paths and tool names'})
for p in [W/'window-restore-contract.mjs',Path(__file__),
          R/'tauri/scripts/native-perf-owned-json.py',
          R/'tauri/scripts/test_native_perf_owned_json.py', R/'tauri/scripts/native-perf-caption-hit-diagnostic.rs', D/'helper/src/caption_hit_diagnostic.rs']:
    tools[str(p.relative_to(R))]=sha(p)
save('tools.json',tools)
save('preparation.json',{'sourceCount':len(sources),'nativeTests':137,
     'currentGuiSha256':package['sha256'],'derivation':rows,'replacements':mapping,
     'originalGuardsAndBudgetsUnchanged':True,'extraInputRetries':0,
     'wholeMatrixAccepted':False,'oldFailedRoundsPreserved':True,
     'generatedFrontendBuildInputs':load(B/'dist-input-stability.json')})
save('first-failure-retained.json',{'previousFailureArchive':'docs/verification/rf1127-current-gui-restore-retry1-2026-10-12.json','wholeMatrixRetry':3,'diagnosticOnlyHelpersRebuilt':True,'newEvidencePlan':'original rejected hit now records HWND/PID/root metadata; same console; no new activation fallback','perSampleInputRetriesAdded':0,'guiRebuilt':False,'scopeReduced':False})
print('Current diagnostic GUI: four new groups prepared; original guards unchanged')
