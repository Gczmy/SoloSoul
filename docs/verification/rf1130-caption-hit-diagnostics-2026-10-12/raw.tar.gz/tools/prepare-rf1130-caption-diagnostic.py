from pathlib import Path
import hashlib,json,shutil
R=Path('D:/SoloSoul');W=Path(__file__).parent;S=W/'rf1130-caption-hit-20261012'
old=W/'window-restore-caption-20261011/helper';helper=S/'helper'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not S.exists();(helper/'src').mkdir(parents=True)
module=R/'tauri/scripts/native-perf-caption-hit-diagnostic.rs'
shutil.copyfile(module,helper/'src/caption_hit_diagnostic.rs')
for n in ['Cargo.toml','Cargo.lock']:shutil.copyfile(old/n,helper/n)
toml=(helper/'Cargo.toml').read_text(encoding='utf-8').replace('name = "rf121-owned-caption-restore"','name = "rf1130-owned-caption-restore"').replace('name = "rf121-owned-caption-foreground"','name = "rf1130-owned-caption-foreground"')
(helper/'Cargo.toml').write_text(toml,encoding='utf-8',newline='\n')
rows=[]
for n in ['activate.rs','restore.rs']:
 before=(old/'src'/n).read_text(encoding='utf-8')
 prefix='mod caption_hit_diagnostic;\n\n'
 x='''                    require(
                        unsafe { WindowFromPoint(point) } == hwnd,
                        "caption-point-hits-other-window",
                    )?;'''
 y='''                    let observed_hit = unsafe { WindowFromPoint(point) };
                    if observed_hit != hwnd {
                        *refused_hit.borrow_mut() = Some(
                            caption_hit_diagnostic::rejected_caption_hit(hwnd, point, observed_hit),
                        );
                    }
                    require(observed_hit == hwnd, "caption-point-hits-other-window")?;'''
 assert before.count(x)==1
 a='            let caption_result: Outcome<()> = (|| {'
 b='            let refused_hit = std::cell::RefCell::new(None);\n'+a
 c='            if let Err(error) = caption_result {'
 d='''            if let Some(metadata) = refused_hit.into_inner() {
                caption["refusedHitMetadata"] = metadata;
            }
'''+c
 assert before.count(a)==1 and before.count(c)==1
 after=prefix+before.replace(x,y).replace(a,b).replace(c,d)
 p=helper/'src'/n;p.write_text(after,encoding='utf-8',newline='\n')
 # Reverse every permitted edit, then compare the entire original body.
 assert after.removeprefix(prefix).replace(y,x).replace(b,a).replace(d,c)==before
 rows.append({'name':n,'beforeSource':str(old/'src'/n),'beforeSha256':sha(old/'src'/n),'afterSource':str(p),'afterSha256':sha(p),'reverseExactTextEqual':True})
sources={str(p.relative_to(R)):sha(p) for p in helper.rglob('*') if p.is_file()}
sources[str(module.relative_to(R))]=sha(module)
for name,value in [('preparation.json',{'task':'RF-1130','helpers':rows,'moduleSourceSha256':sha(module),'dependenciesUnchanged':True,'inputAndBudgetGuardsUnchanged':True,'guiRebuilt':False,'nativeExecuted':False}),('sources-before-checks.json',sources)]:
 (S/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Two isolated helpers prepared; original bodies verified after reversing diagnostic-only edits')
