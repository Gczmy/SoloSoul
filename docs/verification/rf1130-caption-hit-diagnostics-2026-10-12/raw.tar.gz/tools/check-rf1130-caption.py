from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('D:/SoloSoul');W=Path(__file__).parent;S=W/'rf1130-caption-hit-20261012'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((S/'sources-before-checks.json').read_text(encoding='utf-8'))
def verify():
 for n,h in sources.items():assert sha(R/n)==h,n
env=os.environ.copy();env.update(CARGO_HOME=str(R/'build/rf312-maintenance-20261009/cargo-home'),CARGO_TARGET_DIR=str(W/'helper-target-readable'),TEMP=str(S),TMP=str(S))
manifest=str(S/'helper/Cargo.toml');rows=[]
commands=[('fmt',['cargo','fmt','--manifest-path',manifest,'--','--check']),('module-fmt',['rustfmt','--edition','2021','--check',str(R/'tauri/scripts/native-perf-caption-hit-diagnostic.rs')]),('tests',['cargo','test','--manifest-path',manifest,'--locked','--offline']),('clippy',['cargo','clippy','--manifest-path',manifest,'--locked','--offline','--all-targets','--','-D','warnings']),('build',['cargo','build','--manifest-path',manifest,'--locked','--offline'])]
for name,cmd in commands:
 verify();start=time.monotonic()
 with (S/(name+'.stdout.log')).open('xb') as out,(S/(name+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  (S/(name+'.live.json')).write_text(json.dumps({'pid':p.pid,'command':cmd}),encoding='utf-8',newline='\n')
  print(name,'PID',p.pid,flush=True);code=p.wait()
 verify();row={'name':name,'pid':p.pid,'command':cmd,'exitCode':code,'elapsedSeconds':time.monotonic()-start};rows.append(row)
 (S/(name+'.receipt.json')).write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8',newline='\n');print(name,'exit',code,flush=True)
 if code:break
(S/'checks-complete.json').write_text(json.dumps({'accepted':len(rows)==len(commands) and all(r['exitCode']==0 for r in rows),'rows':rows,'sourcesUnchanged':True},indent=2)+'\n',encoding='utf-8',newline='\n')
raise SystemExit(0 if len(rows)==len(commands) and all(r['exitCode']==0 for r in rows) else 1)
