from pathlib import Path
import hashlib, io, json, tarfile
R=Path('D:/SoloSoul');W=Path(__file__).parent;S=W/'rf1130-native-matrix-20261012'
C=W/'ss-rf121-composed-window-restore-baseline-diagnostic-hitmeta-20261012'
N='rf1130-caption-hit-diagnostics-2026-10-12';O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
matrix=load(S/'cohorts-complete.json');assert not matrix['accepted'] and len(matrix['rows'])==1
j=load(C/'actual100/native-perf-sdk-journey-results.json');assert len(j['samples'])==3 and all(x['success'] and x['cleanupIntegrity']['complete'] for x in j['samples'])
receipt=load(C/'actual100.receipt.json');assert receipt['exitCode']==0 and receipt['sourceUnchanged'] and receipt['resourcesUnchanged'] and receipt['originalFixtureUnchanged']
denials=[load(C/f'actual100/sample-{i:03}/rf121-wgc-activate-owned.json') for i in range(1,4)]
assert all(not x['foregroundAfter'] and x['captionActivation']['error']=='caption-point-hits-other-window' and x['inputEventsSent']==0 for x in denials)
cleanup=load(W/'rf1130-cache-cleanup.json');assert cleanup['preservedBytesVerified'] and cleanup['identitiesChecked']==27 and cleanup['processesTerminatedByThisTool']==0
assert len(cleanup['removedCachePaths'])==24 and len(cleanup['linksUnlinked'])==3 and len(cleanup['preservedVaultAndRootFiles'])==96 and len(cleanup['applicationLogs'])==3
assert all(not Path(p).exists() for p in cleanup['removedCachePaths'])
sources=load(S/'sources.json');assert len(sources)==1839 and all(sha(R/n)==h for n,h in sources.items())
assert not O.exists();O.mkdir();members={}
for p in S.iterdir():
 if p.is_file() and p.suffix in ['.json','.log']:members['matrix/'+p.name]=p
excluded={'vault','app-data','profile','webview','temp','models','plugins'}
for p in C.rglob('*'):
 rel=p.relative_to(C)
 if any(x in excluded for x in rel.parts):continue
 if p.is_file() and p.suffix in ['.json','.log','.bgra']:members['capture/'+rel.as_posix()]=p
assert not any(p.suffix=='.bgra' for p in members.values())
for p in (W/'application-logs-rf1130-hitmeta').rglob('*'):
 if p.is_file():members['application-logs/'+p.relative_to(W/'application-logs-rf1130-hitmeta').as_posix()]=p
for n in ['prepare-rf1130-native-matrix.py','run-rf1130-diagnostic.py','verify-rf1130-diagnostic.mjs','render-rf1130-diagnostic.py','run-rf1130-cohorts.py','rf1130-session-preflight.py','rf1130-session-baseline.py','prepare-rf1130-terminal-cleanup.py','rf1130-cleanup-owned.ps1','rf1130-cache-cleanup-plan.json','rf1130-cache-cleanup-preflight.json','rf1130-cache-cleanup.json','archive-rf1130-caption-diagnostics.py']:
 members['tools/'+n]=W/n
package=load(S/'caption-runtime-package.json');members['sources/activate.rs']=Path(package['activationSource'])
assert sha(Path(package['activationSource']))==package['activationSourceSha256']
D=W/'rf1130-caption-hit-20261012'
assert load(D/'checks-retry1/checks-complete.json')['accepted']
for x in denials:
 m=x['captionActivation']['refusedHitMetadata']
 assert m['hit']['pid']==20684 and m['hitRoot']['hwnd']==852170 and m['hitRootOwner']['hwnd']==852170
 assert m['pointScreen']==[522,18] and not m['hitRootEqualsTarget'] and not m['authorizesInput']
 assert m['inputEventsSentByDiagnostic']==m['pixelsRead']==0 and not m['windowTextRead']
for p in D.rglob('*'):
 if 'bin' in p.relative_to(D).parts:continue
 if p.is_file() and p.suffix in ['.json','.log','.rs','.toml','.lock']:
  members['diagnostic-build/'+p.relative_to(D).as_posix()]=p
for n in ['prepare-rf1130-caption-diagnostic.py','check-rf1130-caption.py','check-rf1130-caption-retry1.py']:
 members['tools/'+n]=W/n
members['sources/diagnostic.rs']=R/'tauri/scripts/native-perf-caption-hit-diagnostic.rs'
for n in ['restore.rs','activate.rs']:members['sources/original-'+n]=W/'window-restore-caption-20261011/helper/src'/n
rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as archive:
 for name,p in sorted(members.items()):
  assert not(p.stat().st_file_attributes&0x400)
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  archive.addfile(info,io.BytesIO(data));rows.append({'member':name,'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(O/'raw.tar.gz') as archive:
 assert len(archive.getmembers())==len(rows)
 for row in rows:
  data=archive.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',{'task':'RF-1130','allMembersReadbackVerified':True,'members':rows,'unusedPreparedTools':['verify-rf1130-diagnostic.mjs','render-rf1130-diagnostic.py'],'physicalVaultExecutablesModelsAndCachesExcluded':True})
(O/'.gitattributes').write_text('raw.tar.gz -text\n',encoding='utf-8',newline='\n')
put(R/'docs/verification'/(N+'.json'),{'task':'RF-1130','sourceHead':'782d7b012','accepted':True,'acceptanceScope':'refused-hit diagnostic only; original native matrix rejected','exeSha256':package['sha256'],'sources':len(sources),'requestedCohorts':4,'executedCohorts':1,'sdkJourneysPassed':3,'sdkJourneysFailed':0,'windowCapturesAccepted':0,'readerRuns':0,'rendererRuns':0,'denials':denials,'atFailureOccupyingWindowOwnerRecorded':True,'newDiagnosticProvenAtActualRefusal':True,'failureCauseResolved':False,'diagnosticChecks':load(D/'final-source-audit.json'),'recordedHitProcessReadOnly':load(S/'recorded-hit-process-readonly.json'),'postTerminalObservationIsNotFailurePointEvidence':True,'cleanup':{k:len(v) if isinstance(v,list) else v for k,v in cleanup.items()},'fullRF121Accepted':False,'RF1128Accepted':False,'performanceAccepted':False,'archive':{'path':N+'/raw.tar.gz','members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha(O/'raw.tar.gz'),'allMembersReadbackVerified':True}})
print(json.dumps({'members':len(rows),'sdkPassed':3,'windowCapturesAccepted':0,'diagnosticAccepted':True,'nativeMatrixAccepted':False}))
