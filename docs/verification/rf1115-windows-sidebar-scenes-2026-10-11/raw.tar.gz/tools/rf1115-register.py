from pathlib import Path
import hashlib, json
root = Path('D:/SoloSoul')
stage = Path(__file__).parent / 'rf1115-checks-20261011'
stage.mkdir(exist_ok=False)
p = root / 'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md'
original = p.read_bytes()
(stage / 'ledger-before.md').write_bytes(original)
s = original.decode('utf-8').replace('\r\n','\n')
assert '**304**（P1：55；P2：248；P3：1）' in s
s = s.replace('**304**（P1：55；P2：248；P3：1）','**305**（P1：55；P2：249；P3：1）',1)
s = s.replace('**294 / 304**','**294 / 305**',1).replace('进行中：0；待执行：6','进行中：1；待执行：6',1)
s = s.replace('RF-1113、RF-1114（RF-904','RF-1113、RF-1114、RF-1115（RF-904',1)
start=s.index('- 当前处理：'); end=s.index('\n',start)
s=s[:start]+'- 当前处理：**RF-1115 Windows真实侧栏折叠、原生截图与恢复验证入口；RF-121完整矩阵保持未完成**。'+s[end:]
row='| 305 | [RF-1115](#rf-1115) | P2 | 补齐真实侧栏折叠截图与恢复验证入口 | 无（RF-121当前完整原生行程验证发现） | [~] 进行中 |\n'
mark='\n## 5. 原报告到执行任务的映射'
assert s.count(mark)==1
s=s.replace(mark,'\n'+row+mark,1)
card='''### RF-1115

**补齐真实侧栏折叠截图与恢复验证入口** · P2 · 来源：RF-121当前原生完整行程只能采集浅色展开侧栏

- **入口：**仅Windows非默认`native-perf`构建的`sdk_surface`可选握手；固定公开合成账户。
- **现状：**当前程序三次真实浅色展开窗口截图已通过。已有脚本只读DOM，无法实际折叠侧栏；直接改DOM或账户fixture不能作为原生场景证据。
- **执行：**新增严格绑定当前runId/PID/browserPid/token的独立请求，仅允许`light-collapsed`。完整解锁/搜索/锁定/再解锁之后，读取固定Home按钮几何，通过真实SDK输入折叠侧栏；验证可信指针、相同文档/时钟/主题及稳定布局，沿用原窗口/像素握手；成功或失败均尝试真实点击恢复。不改变默认构建、生产命令、fixture、允许路由、调用/时间预算或既有身份/像素验收。
- **验收：**新增有意义的请求拒绝、探针和输入转换回归；必要Rust和格式检查；新程序无scene的浅色展开及有scene的浅色折叠各三次完整真实原生行程，WGC实际像素和恢复状态全部绑定。归档原失败/成功及来源哈希、隔离缓存清理，独立提交不推送。深色、缩放、恢复、辅助功能及多平台仍归RF-121。

'''
assert s.count('## 7. 每项执行记录模板')==1
s=s.replace('## 7. 每项执行记录模板',card+'## 7. 每项执行记录模板',1)
newline='\r\n' if b'\r\n' in original else '\n'
p.write_bytes(s.replace('\n',newline).encode('utf-8'))
load=lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
old=load(stage.parent/'sources-current-20261011.json')
changes=[name for name,digest in old.items() if sha(root/name)!=digest]
assert changes==['tauri/src-tauri/src/native_perf/sdk_surface.rs'],changes
sources={name:sha(root/name) for name in old}
for name in ['tauri/src-tauri/src/native_perf/sdk_surface_sidebar.rs','tauri/src-tauri/src/native_perf/sdk_surface_sidebar.js']:
    assert name not in sources; sources[name]=sha(root/name)
for name,value in [('sources.json',sources),('source-provenance.json',{'parent':'sources-current-20261011.json','changed':changes,'added':sorted(set(sources)-set(old)),'sourceCount':len(sources)})]:
    with (stage/name).open('x',encoding='utf-8') as f: json.dump(value,f,indent=2)
print('RF-1115 registered; source count',len(sources))
