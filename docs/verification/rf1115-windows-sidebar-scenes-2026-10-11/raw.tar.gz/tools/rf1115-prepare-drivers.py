from pathlib import Path
stage=Path(__file__).parent
def change(s, old, new, count=1):
    assert s.count(old)==count,(old[:80],s.count(old),count)
    return s.replace(old,new)
def save(name,s):
    with (stage/name).open('x',encoding='utf-8',newline='\n') as f: f.write(s)
s=(stage/'run-current-light-bindings-20261011-round2.py').read_text()
s=change(s,"assert sys.argv[1:] == ['--current'], 'Only the fixed current light capture round is allowed'",
    "assert sys.argv[1:] in [['--baseline'], ['--scene']]\nscene = sys.argv[1] == '--scene'\nmode = 'collapsed' if scene else 'baseline'")
s=change(s,"capture_stage = stage / 'ss-rf121-composed-window-current-20261011-round2'",
    "capture_stage = stage / ('ss-rf121-composed-window-rf1115-' + mode + '-20261011')")
s=change(s,"package = load(stage / 'runtime-package-current-20261011-round2.json')",
    "package = load(stage / 'rf1115-checks-20261011/runtime-package.json')")
s=change(s,"sources-current-20261011.json","rf1115-checks-20261011/sources.json",2)
s=change(s,"atomic_new(sample / 'native-perf-surface-request.json', request)",
    "if scene:\n                    atomic_new(sample / 'native-perf-surface-scene-request.json', dict(request, scope='windows-native-sidebar-scene-request', scene='light-collapsed'))\n                atomic_new(sample / 'native-perf-surface-request.json', request)")
s=change(s,"assert state['theme'] in ['light', 'dark'] and state['platform'] == 'windows'",
    "assert state['theme'] == 'light' and state['platform'] == 'windows'\n                assert state['expanded'] is (not scene)")
old="result.update({'success': True, 'runId': run_id, 'pid': pid, 'theme': state['theme'],"
new="""if scene:
                    restored = ordinary(wait_file(sample / 'native-perf-surface-scene-restored.json', deadline), 262144)
                    complete = ordinary(wait_file(sample / 'native-perf-surface-scene-result.json', deadline), 262144)
                    assert complete['success'] and complete['captureError'] is None and complete['restoreError'] is None
                    assert restored['restored']['expanded'] and restored['restored']['theme'] == 'light'
                result.update({'success': True, 'runId': run_id, 'pid': pid, 'theme': state['theme'],"""
s=change(s,old,new)
save('run-rf1115-native-surfaces.py',s)

s=(stage/'verify-current-light-bindings-20261011.mjs').read_text()
s=change(s,"assert.deepEqual(process.argv.slice(2),['--current']);",
    "assert(['--baseline','--scene'].includes(process.argv[2])&&process.argv.length===3);\nconst scene=process.argv[2]==='--scene';\nconst mode=scene?'collapsed':'baseline';")
s=change(s,"const captureStage=path.join(stage,'ss-rf121-composed-window-current-20261011-round2');",
    "const captureStage=path.join(stage,`ss-rf121-composed-window-rf1115-${mode}-20261011`);")
s=change(s,'sources-current-20261011.json','rf1115-checks-20261011/sources.json',2)
s=change(s,'sourceFiles:1830','sourceFiles:1832')
marker="  const tag=before.state.theme+'-visible';"
insert="""  assert.equal(before.state.theme,'light');assert.equal(before.state.expanded,!scene);
  assert.equal(before.state.focused,true);assert.equal(before.state.visibility,'visible');
  if(scene){
    const sceneRequest=await regular(path.join(dir,'native-perf-surface-scene-request.json'),4096);
    assert.deepEqual(sceneRequest,{...request,scope:'windows-native-sidebar-scene-request',scene:'light-collapsed'});
    const prepared=await regular(path.join(dir,'native-perf-surface-scene-prepared.json'));
    const restored=await regular(path.join(dir,'native-perf-surface-scene-restored.json'));
    const complete=await regular(path.join(dir,'native-perf-surface-scene-result.json'));
    exact(prepared,['schemaVersion','scope','request','binding','initial','prepared','performanceMetrics']);
    exact(restored,['schemaVersion','scope','request','binding','before','restored','performanceMetrics']);
    exact(complete,['schemaVersion','scope','request','captureError','restoreError','success','performanceMetrics']);
    for(const [proof,scope] of [[prepared,'prepared'],[restored,'restored'],[complete,'result']]){
      assert.equal(proof.schemaVersion,1);assert.equal(proof.scope,'windows-native-sidebar-scene-'+scope);
      assert.deepEqual(proof.request,sceneRequest);assert.equal(proof.performanceMetrics,null);
    }
    assert.deepEqual(prepared.binding,bound.binding);assert.deepEqual(restored.binding,bound.binding);
    assert.equal(complete.success,true);assert.equal(complete.captureError,null);assert.equal(complete.restoreError,null);
    const states=[prepared.initial,prepared.prepared,restored.before,restored.restored];
    states.forEach((p,i)=>{
      exact(p,['schemaVersion','scope','href','timeOriginMs','atMs','theme','platform','expanded','viewport','focused','visibility','layout','settled','target','inputTrust']);
      assert.equal(p.schemaVersion,1);assert.equal(p.scope,'windows-native-sidebar-probe');
      assert.equal(p.href,'http://tauri.localhost/');assert.equal(p.timeOriginMs,bound.timeOriginMs);
      number(p.atMs,i?states[i-1].atMs:native.lastProbe.atMs,300000);
      assert.equal(p.theme,'light');assert.equal(p.platform,'windows');assert.equal(p.focused,true);
      assert.equal(p.visibility,'visible');assert.equal(p.settled,true);assert.deepEqual(p.viewport,before.state.viewport);
      assert.equal(p.expanded,i===0||i===3);assert.equal(p.layout.length,3);
      p.layout.forEach(r=>{assert.equal(r.length,4);r.slice(0,2).forEach(n=>number(n,-16384,16384));r.slice(2).forEach(n=>number(n,1,16384));});
      exact(p.target,['x','y','actionable']);assert.equal(p.target.actionable,true);
      number(p.target.x,0,p.viewport[0]-1);number(p.target.y,0,p.viewport[1]-1);
      exact(p.inputTrust,['pointer','text','untrusted']);assert.equal(p.inputTrust.text,3);assert.equal(p.inputTrust.untrusted,0);
      assert.equal(p.inputTrust.pointer,native.lastProbe.inputTrust.pointer+[0,1,1,2][i]);
    });
    assert(prepared.prepared.atMs<=before.state.atMs&&restored.before.atMs>=after.state.atMs);
    assert.deepEqual(prepared.initial.inputTrust,native.lastProbe.inputTrust);
    assert.deepEqual(prepared.initial.layout[0],restored.restored.layout[0]);
    assert.equal(before.state.surfaces.navigation.rect[2],96);
  }else{
    await assert.rejects(lstat(path.join(dir,'native-perf-surface-scene-request.json')),{code:'ENOENT'});
  }
"""
s=change(s,marker,insert+marker)
s=change(s,"applicationMaterialAccepted:false,\n  fullMatrixAccepted:false", "applicationMaterialAccepted:false,scene:mode,\n  fullMatrixAccepted:false")
save('verify-rf1115-native-surfaces.mjs',s)
s=(stage/'render-current-light-bindings-20261011.py').read_text()
s=change(s,"assert sys.argv[1:] == ['--current']", "assert sys.argv[1:] in [['--baseline'],['--scene']]\nmode='collapsed' if sys.argv[1]=='--scene' else 'baseline'")
s=change(s,"stage = Path(__file__).parent / 'ss-rf121-composed-window-current-20261011-round2'",
    "stage = Path(__file__).parent / ('ss-rf121-composed-window-rf1115-'+mode+'-20261011')")
save('render-rf1115-native-surfaces.py',s)
print('Finite baseline/collapsed real native drivers prepared')
