from pathlib import Path
import datetime, hashlib, io, json, re, shutil, tarfile
root=Path('D:/SoloSoul')
stage=Path(__file__).parent
checks=stage/'rf1115-checks-20261011'
out=root/'docs/verification/rf1115-windows-sidebar-scenes-2026-10-11'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
complete=load(checks/'checks-complete.json')
assert complete['success'] and complete['sourceUnchanged'] and complete['sourceCount']==1832
sources=load(checks/'sources.json')
assert len(sources)==1832
for name,digest in sources.items():assert sha(root/name)==digest,name
package=load(checks/'runtime-package.json')
assert sha(Path(package['exe']))==package['sha256']
assert len(package['resources'])==94
for item in package['resources']:assert sha(Path(item['source']))==sha(Path(item['copy']))==item['sha256']
cleanup=load(stage/'rf1115-cache-cleanup.json')
assert cleanup['preservedBytesVerified'] and cleanup['matchingOwnedIdentitiesLive']==0
assert cleanup['processesTerminatedByThisTool']==0 and len(cleanup['removedCachePaths'])==48
for item in cleanup['preservedVaultAndRootFiles']:assert sha(Path(item['path']))==item['sha256']
names=['format','prettier','node-native-unsandboxed','clippy-native','tests-native-repeat','clippy-default','tests-default-remaining','tests-default-gui-doc','native-release-build']
receipts={name:load(checks/(name+'.receipt.json')) for name in names}
for name,receipt in receipts.items():assert receipt['exitCode']==0,name
assert load(checks/'node-native.receipt.json')['exitCode']==1
test_counts={name:[{'passed':int(a),'failed':int(b),'ignored':int(c),'measured':int(d),'filtered':int(e)}
    for a,b,c,d,e in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',
        (checks/(name+'.stdout.log')).read_text(encoding='utf-8'))] for name in ['tests-native-repeat','tests-default','tests-default-remaining','tests-default-gui-doc']}
assert all(test_counts.values())
for values in test_counts.values():assert all(item['failed']==0 for item in values)
files={}
def add(path,name):
    assert name not in files and path.is_file() and not path.is_symlink()
    assert not (path.lstat().st_file_attributes & 0x400)
    files[name]=path
for path in checks.iterdir():
    if path.is_file() and path.suffix in ['.json','.log','.md','.toml']:add(path,'checks/'+path.name)
for name in ['rf1115-register.py','rf1115-run-checks.py','rf1115-session-preflight.py','rf1115-session-preflight.json',
    'rf1115-session-before-capture.py','rf1115-session-before-capture.json','rf1115-session-user-reply.py','rf1115-session-user-reply.json','rf1115-run-captures.py',
    'rf1115-prepare-drivers.py','run-rf1115-native-surfaces.py','verify-rf1115-native-surfaces.mjs',
    'render-rf1115-native-surfaces.py','rf1115-prepare-cleanup.py','cleanup-rf1115-owned.ps1',
    'rf1115-cache-cleanup-plan.json','rf1115-cache-cleanup-preflight.json','rf1115-cache-cleanup.json','rf1115-archive.py']:
    add(stage/name,'tools/'+name)
for name in ['sdk_surface.rs','sdk_surface_sidebar.rs','sdk_surface_sidebar.js']:
    add(root/'tauri/src-tauri/src/native_perf'/name,'executed-source/'+name)
add(Path(package['helperSource']),'executed-helper/owned-window.rs')
groups=[]
for mode in ['baseline','collapsed']:
    capture=stage/('ss-rf121-composed-window-rf1115-'+mode+'-20261011')
    validation=load(capture/'validation.json')
    review=load(capture/'visual-review.json')
    assert validation['accepted'] and len(validation['samples'])==3
    assert review['actualImagesInspected']==3 and review['fullMatrixAccepted'] is False
    assert load(capture/'actual100.receipt.json')['exitCode']==0
    for sample in validation['samples']:
        assert sample['state']['expanded'] is (mode=='baseline')
        assert sample['state']['theme']=='light'
    groups.append({'mode':mode,'actualCompleteJourneys':3,'actualCaptures':3,'validation':validation,
        'visualReview':review})
    for path in capture.iterdir():
        if path.is_file():add(path,mode+'/'+path.name)
    actual=capture/'actual100'
    for path in actual.iterdir():
        if path.is_file():add(path,mode+'/actual100/'+path.name)
        elif path.name in ['sample-001','sample-002','sample-003']:
            # Root evidence only; neither synthetic Vault copies nor caches are archived.
            for leaf in path.iterdir():
                if leaf.is_file():add(leaf,mode+'/actual100/'+path.name+'/'+leaf.name)
logs=stage/'application-logs-rf1115'
for path in logs.rglob('*'):
    if path.is_file():add(path,'application-logs/'+path.relative_to(logs).as_posix())
out.mkdir(exist_ok=False)
(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf-8')
standalone=[]
for mode in ['baseline','collapsed']:
    capture=stage/('ss-rf121-composed-window-rf1115-'+mode+'-20261011')
    for row in load(capture/'rendered-captures.json'):
        source=Path(row['png']); assert sha(source)==row['pngSha256']
        target=out/(mode+'-sample-'+str(row['index']).zfill(3)+'.png')
        assert not target.exists(); shutil.copy2(source,target); assert sha(target)==row['pngSha256']
        standalone.append({'path':target.relative_to(root).as_posix(),'sha256':row['pngSha256'],'mode':mode,'index':row['index']})

members=[]
with tarfile.open(out/'raw.tar.gz','w:gz') as archive:
    for name,path in sorted(files.items()):
        data=path.read_bytes()
        member=tarfile.TarInfo(name);member.size=len(data);member.mtime=int(path.stat().st_mtime)
        archive.addfile(member,io.BytesIO(data))
        members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(out/'raw.tar.gz','r:gz') as archive:
    assert archive.getnames()==[item['path'] for item in members]
    for item in members:
        data=archive.extractfile(item['path']).read()
        assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
index={'schemaVersion':1,'task':'RF-1115','archiveSha256':sha(out/'raw.tar.gz'),'archiveBytes':(out/'raw.tar.gz').stat().st_size,
    'members':members,'allMembersExtractedAndVerified':True,'excluded':['executables','DLLs','models','Vault entities','caches']}
with (out/'index.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(index,f,indent=2);f.write('\n')
report={'schemaVersion':1,'task':'RF-1115','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'accepted':True,
    'scope':'Windows real owned homepage sidebar input, stable frame capture and restore',
    'defaultProductionBuildChanged':False,'systemAppearanceModified':False,'sourceManifest':str(checks/'sources.json'),
    'sourceManifestSha256':sha(checks/'sources.json'),'sourceCount':1832,'runtime':package,
    'checks':receipts,'rustTestCounts':test_counts,'nodeTests':112,'originalSandboxJunctionFailurePreserved':True,
    'defaultInitialRun':load(checks/'tests-default.receipt.json'),
    'defaultWorkspaceCompletion':'Initial GUI unit/binary/integration targets passed; initial Core failed for missing PDFium. Complete remaining workspace packages and GUI doc tests then passed with exact bundled PDFium and unchanged source. No claim that the initial whole command passed.',
    'groups':groups,'standalonePngs':standalone,'cleanup':cleanup,'rawArchive':out.relative_to(root).as_posix()+'/raw.tar.gz',
    'rawArchiveSha256':index['archiveSha256'],'rawMembers':len(members),'allRawMembersVerified':True,
    'nativeDwmAppearancePropertiesVerified':False,'performanceMetrics':None,'rf121Closed':False,
    'remaining':['dark','DPI/resize','minimize/restore','transition sequences','accessibility','other platforms']}
with (out.with_suffix('.json')).open('x',encoding='utf-8',newline='\n') as f:json.dump(report,f,indent=2);f.write('\n')
print('Actual evidence archived and verified:',len(members),'members')
