from pathlib import Path
import datetime, hashlib, json, os, shutil, struct, subprocess, sys, time
root=Path('D:/SoloSoul')
stage=Path(__file__).parent/'rf1115-checks-20261011'
cache=root/'build/rf312-maintenance-20261009'
load=lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sources=load(stage/'sources.json')
env=os.environ.copy()
env.update({'TEMP':str(cache/'tmp'),'TMP':str(cache/'tmp'),'CARGO_HOME':str(cache/'cargo-home'),
    'CARGO_TARGET_DIR':str(cache/'cargo-target'),'CARGO_BUILD_JOBS':'1','ORT_CACHE_DIR':str(cache/'ort-cache'),
    'npm_config_cache':str(cache/'npm-cache')})
env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','')
env.pop('PDFIUM_LIBRARY_PATH',None)
now=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,value):
    with (stage/name).open('x',encoding='utf-8',newline='\n') as f: json.dump(value,f,indent=2); f.write('\n')
def verify():
    changed=[name for name,digest in sources.items() if sha(root/name)!=digest]
    assert not changed,changed
def run(name,command,build=False):
    verify()
    original=(root/'tauri/src-tauri/Cargo.toml').read_bytes()
    start=time.monotonic()
    command_env=env.copy()
    pdfium=None
    if command[:2]==['cargo','test']:
        dll=root/'tauri/src-tauri/resources/pdfium/pdfium.dll'
        command_env['PDFIUM_LIBRARY_PATH']=str(dll)
        pdfium={'path':str(dll),'sha256':sha(dll)}
    with (stage/(name+'.stdout.log')).open('xb') as out,(stage/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(command,cwd=root/'tauri',env=command_env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',{'at':now(),'pid':p.pid,'command':command})
        print(name,'PID',p.pid,flush=True)
        code=p.wait()
    changed=[name for name,digest in sources.items() if sha(root/name)!=digest]
    save(name+'.receipt.json',{'at':now(),'pid':p.pid,'command':command,'exitCode':code,'elapsedSeconds':time.monotonic()-start,
        'sourceManifestSha256':sha(stage/'sources.json'),'changedSourceFiles':changed,'sourceUnchanged':not changed,
        'pdfiumTestLibrary':pdfium,'pdfiumLibraryUnchanged':None if pdfium is None else sha(Path(pdfium['path']))==pdfium['sha256']})
    if build and changed:
        assert changed==['tauri/src-tauri/Cargo.toml'],changed
        current=(root/changed[0]).read_bytes()
        assert current.replace(b'\r\n',b'\n')==original.replace(b'\r\n',b'\n')
        (stage/'build-Cargo-original.toml').write_bytes(original)
        (stage/'build-Cargo-generated.toml').write_bytes(current)
        save('build-newline-parity.json',{'rawSourceUnchanged':False,'normalizedBytesEqual':True,
            'originalSha256':hashlib.sha256(original).hexdigest(),'generatedSha256':hashlib.sha256(current).hexdigest()})
        (root/changed[0]).write_bytes(original)
    verify()
    assert code==0,(name,code)
resume_native = sys.argv[1:] == ['--resume-native-file-failure']
resume_pdfium = sys.argv[1:] == ['--resume-default-pdfium']
if resume_pdfium:
    for check in ['format','prettier','node-native-unsandboxed','clippy-native','tests-native-repeat','clippy-default']:
        assert load(stage/(check+'.receipt.json'))['exitCode']==0
    assert load(stage/'tests-default.receipt.json')['exitCode']==101
    failed=(stage/'tests-default.stdout.log').read_text(encoding='utf-8')
    assert 'RF028 requires real PDFium' in failed and '428 passed; 18 failed' in failed
elif resume_native:
    for check in ['format','prettier','node-native-unsandboxed','clippy-native']:
        assert load(stage/(check+'.receipt.json'))['exitCode']==0
    assert load(stage/'tests-native.receipt.json')['exitCode']==101
    assert 'failed to persist temporary file: Access is denied' in (stage/'tests-native.stderr.log').read_text()
elif sys.argv[1:] == ['--resume-node-permissions']:
    assert load(stage/'format.receipt.json')['exitCode']==0
    assert load(stage/'prettier.receipt.json')['exitCode']==0
    assert load(stage/'node-native.receipt.json')['exitCode']==1
    assert 'EPERM' in ((stage/'node-native.stderr.log').read_text()+(stage/'node-native.stdout.log').read_text())
    run('node-native-unsandboxed',['npm.cmd','run','test:native-perf'])
else:
    assert not sys.argv[1:]
    run('format',['cargo','fmt','--all','--','--check'])
    run('prettier',['node','node_modules/prettier/bin/prettier.cjs','--check','src-tauri/src/native_perf/sdk_surface_sidebar.js'])
    run('node-native',['npm.cmd','run','test:native-perf'])
if not resume_pdfium:
    if not resume_native:
        run('clippy-native',['cargo','clippy','--locked','-p','solo_soul','--features','native-perf','--','-D','warnings'])
    run('tests-native-repeat' if resume_native else 'tests-native',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','native_perf::','--','--nocapture'])
    run('clippy-default',['cargo','clippy','--locked','--','-D','warnings'])
    run('tests-default',['cargo','test','--locked','--verbose'])
else:
    run('tests-default-remaining',['cargo','test','--locked','--workspace','--exclude','solo_soul','--verbose'])
    run('tests-default-gui-doc',['cargo','test','--locked','-p','solo_soul','--doc','--verbose'])
run('native-release-build',['npm.cmd','run','tauri','--','build','--config','src-tauri/tauri.native-perf.conf.json','--features','native-perf','--no-bundle','--ci'],build=True)
runtime=stage.parent/'ss-rf1115-runtime-20261011/bin'
runtime.mkdir(parents=True,exist_ok=False)
exe=runtime/'solo_soul.exe'
shutil.copy2(cache/'cargo-target/release/solo_soul.exe',exe)
data=exe.read_bytes(); offset=struct.unpack_from('<I',data,0x3c)[0]
assert data[offset:offset+4]==b'PE\0\0' and struct.unpack_from('<H',data,offset+24+68)[0]==2
old=load(stage.parent/'runtime-package-current-20261011-round2.json')
assert sha(exe)!=old['sha256']
resources=[]
for item in old['resources']:
    source=Path(item['source']); relative=Path(item['copy']).relative_to(Path(old['exe']).parent)
    copy=runtime/relative; assert copy.resolve().is_relative_to(runtime.resolve())
    assert sha(source)==item['sha256']; copy.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(source,copy)
    assert sha(copy)==item['sha256']; resources.append({'source':str(source),'copy':str(copy),'sha256':item['sha256']})
verify()
package=dict(old,exe=str(exe),sha256=sha(exe),bytes=len(data),resources=resources,
    sourceManifestSha256=sha(stage/'sources.json'),windowsGuiSubsystem=2)
save('runtime-package.json',package)
save('checks-complete.json',{'at':now(),'success':True,'sourceCount':len(sources),'sourceUnchanged':True,
    'sourceManifestSha256':sha(stage/'sources.json'),'exeSha256':sha(exe)})
print('All checks and new native release build terminal',flush=True)
