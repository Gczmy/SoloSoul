from pathlib import Path
import json
stage=Path(__file__).parent
groups=[]
for label in ['baseline','collapsed']:
    capture=stage/('ss-rf121-composed-window-rf1115-'+label+'-20261011')
    load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
    actual=load(capture/'actual100.receipt.json')
    validation=load(capture/'validation.json')
    assert actual['exitCode']==0 and validation['accepted'] and len(validation['samples'])==3
    groups.append({'label':label,'captureRoot':str(capture),'terminal':True,'samples':validation['samples']})
plan={'cacheCleanupEligible':True,'failedSamplesAccepted':False,'fullMaterialMatrixAccepted':False,'groups':groups}
with (stage/'rf1115-cache-cleanup-plan.json').open('x',encoding='utf-8') as f:json.dump(plan,f,indent=2)
s=(stage/'cleanup-current-owned-20261011.ps1').read_text()
for old,new,count in [
    ('current-cache-cleanup-plan-20261011.json','rf1115-cache-cleanup-plan.json',1),
    ('current-cache-cleanup-20261011.json','rf1115-cache-cleanup.json',1),
    ('current-cache-cleanup-20261011-preflight.json','rf1115-cache-cleanup-preflight.json',1),
    ('application-logs-current-20261011','application-logs-rf1115',1),
    ("$taskExecutables = @('D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\ss-rf121-runtime-current-20261011\\bin\\solo_soul.exe','D:\\SoloSoul\\build\\rf312-warm-current-20261010\\after-rf1106\\ss-rf1105-runtime\\bin\\solo_soul.exe')",
     "$taskExecutables = @('D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\ss-rf1115-runtime-20261011\\bin\\solo_soul.exe')",1),
    ("task='RF-121'","task='RF-1115'",1),
]:
    assert s.count(old)==count,(old,s.count(old),count);s=s.replace(old,new)
with (stage/'cleanup-rf1115-owned.ps1').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
print('Six terminal samples verified; exact owned cache cleanup prepared, not executed')
