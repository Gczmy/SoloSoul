import pathlib,subprocess,json,os,time
T=pathlib.Path(__file__).parent;R=T/'checkout';N=pathlib.Path(r'C:\Users\40299571\AppData\Local\Temp\ss-rf1088-related-target-20261004\node22\node-v22.23.3-win-x64');env=dict(os.environ);env['PATH']=str(N)+os.pathsep+env['PATH'];env['CI']='1';env['npm_config_cache']=str(T/'npm-cache');env['npm_config_audit']='false';env['npm_config_fund']='false'
checks=[]
for name,args in [('npm-ci',[str(N/'node.exe'),str(N/'node_modules/npm/bin/npm-cli.js'),'ci']),('real-build',[str(N/'node.exe'),str(N/'node_modules/npm/bin/npm-cli.js'),'run','build'])]:
 start=time.monotonic()
 with (T/(name+'.log')).open('wb') as out:p=subprocess.Popen(args,cwd=R/'tauri',env=env,stdout=out,stderr=subprocess.STDOUT);rc=p.wait()
 checks.append({'name':name,'args':args,'exit':rc,'seconds':time.monotonic()-start,'owned_pid':p.pid});(T/'build-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8');print(name,rc,round(time.monotonic()-start,2),flush=True)
 if rc:raise SystemExit(rc)
