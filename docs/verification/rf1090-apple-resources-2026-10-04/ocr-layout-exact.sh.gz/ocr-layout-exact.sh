fixture_directory='src-tauri/resources/models/pp-ocr-v6-small'
if [[ -e "$fixture_directory" || -L "$fixture_directory" ]]; then
  echo 'Expected a fresh unit-test resource directory; refusing to overwrite real models' >&2
  exit 1
fi
mkdir -p -- "$fixture_directory"
printf '%s\n' 'CI unit-test resource layout only. No OCR model. Never package this fixture.' > "$fixture_directory/UNIT_TEST_FIXTURE.txt"
