from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,time
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf1131-font-restore-20261012';H=B/'api31-host-console-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={n:sha(R/n) for n in ['tauri/scripts/android-home-native-regression.py','tauri/scripts/test_android_home_native_regression.py']}
spec=importlib.util.spec_from_file_location('home',R/'tauri/scripts/android-home-native-regression.py');home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
boot=load(H/'boot.receipt.json');owned=[x for x in load(H/'owned-processes-after-launch.json') if x['ProcessId']==boot['pid']];assert len(owned)==1;owned=owned[0]
pwsh='C:/Users/40299571/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
p=subprocess.run([pwsh,'-NoProfile','-Command',f"Get-CimInstance Win32_Process -Filter 'ProcessId = {boot['pid']}' | Select-Object Name,ProcessId,CreationDate,ExecutablePath,CommandLine | ConvertTo-Json -Depth 3"],check=True,capture_output=True,text=True,creationflags=subprocess.CREATE_NO_WINDOW)
live=json.loads(p.stdout);assert all(live[k]==owned[k] for k in ['Name','ProcessId','ExecutablePath','CommandLine'])
assert datetime.datetime.fromisoformat(live['CreationDate'])==datetime.datetime.fromisoformat(owned['CreationDate'])
cmd=[str(B/'sdk/platform-tools/adb.exe'),'-H','localhost','-P','5049','-s','emulator-5586'];calls=[]
def call(args,remaining):
 p=subprocess.run(cmd+args,capture_output=True,timeout=remaining,creationflags=subprocess.CREATE_NO_WINDOW)
 calls.append({'arguments':args,'timeout':remaining,'exitCode':p.returncode,'stdout':p.stdout.decode('utf-8'),'stderr':p.stderr.decode('utf-8')})
 assert p.returncode==0,calls[-1]
 return calls[-1]['stdout']
assert call(['emu','avd','name'],10).splitlines()[0]=='SoloSoul_RF121_API31_20261010'
def raw(remaining):return call(['shell','settings','get','system','font_scale'],remaining)
def effective(remaining):return home.activity_font_scale(call(['shell','dumpsys','activity','processes'],remaining))
def write(action,value,remaining):call(['shell','settings',action,'system','font_scale']+([] if value is None else [value]),remaining)
original,original_effective=home.capture_font_scale(raw,effective);assert original=='null' and original_effective==1.0
rows=[];outer_trace={}
try:
 for seed,scale in [('null',1.0),('1.0',1.0),('1.30',1.3)]:
  home.restore_font_scale(seed,scale,write,raw,effective)
  before,before_effective=home.capture_font_scale(raw,effective);assert before==seed and before_effective==scale
  write('put','2.0',10)
  deadline=time.monotonic()+10
  while True:
   remaining=deadline-time.monotonic();assert remaining>0,'Fixture font mutation did not become effective'
   if effective(remaining)==2.0 and home.font_scale(raw(remaining))=='2.0':break
   time.sleep(min(0.05,remaining))
  mutated,mutated_effective=home.capture_font_scale(raw,effective);assert mutated=='2.0' and mutated_effective==2.0
  trace={};home.restore_font_scale(before,before_effective,write,raw,effective,trace=trace)
  after,after_effective=home.capture_font_scale(raw,effective);assert after==before and after_effective==before_effective
  rows.append({'originalRaw':before,'originalEffective':before_effective,'mutatedTo':mutated,'mutatedEffectiveBeforeRestore':mutated_effective,'finalRaw':after,'finalEffective':after_effective,'accepted':True,'trace':trace})
finally:
 home.restore_font_scale(original,original_effective,write,raw,effective,trace=outer_trace)
 final,final_effective=home.capture_font_scale(raw,effective)
 result={'task':'RF-1131','accepted':len(rows)==3 and all(r['accepted'] for r in rows),'rows':rows,'exactOwnedEmulator':live,'originalRaw':original,'finalRaw':final,'originalEffective':original_effective,'finalEffective':final_effective,'outerRestorationTrace':outer_trace,'calls':calls,'sources':sources,'sourceUnchanged':all(sha(R/n)==h for n,h in sources.items()),'otherDevicesOrHostSettingsModified':False}
 (S/'actual-font-restoration-settled.json').open('x',encoding='utf-8',newline='\n').write(json.dumps(result,indent=2)+'\n')
assert result['accepted'] and final==original and final_effective==original_effective and result['sourceUnchanged']
print(json.dumps({k:v for k,v in result.items() if k not in ['calls','rows','sources']},indent=2))
