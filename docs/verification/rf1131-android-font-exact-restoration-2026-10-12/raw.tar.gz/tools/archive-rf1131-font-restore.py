from pathlib import Path
import hashlib,io,json,tarfile
R=Path('D:/SoloSoul');B=Path(__file__).parent;S=B/'rf1131-font-restore-20261012';NATIVE=B/'rf1131-api31-home-full-20261012';H=B/'api31-host-console-20261012'
N='rf1131-android-font-exact-restoration-2026-10-12';O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
validation=load(NATIVE/'independent-validation.json');assert validation['accepted'] and len(validation['results'])==24
assert validation['nativeMethodsPassedIncludingInitial']==26 and validation['nativeMethodsFailedIncludingInitial']==0
assert len(validation['cleanupEligibleExactFiles'])==48 and all(p['accepted'] and len(p['comparisons'])==12 for p in validation['fontPairs'])
checks=load(S/'checks-summary.json');assert checks['finalAccepted']
probe=load(S/'actual-font-restoration-settled.json');assert probe['accepted'] and probe['finalRaw']==probe['originalRaw']=='null'
stop=load(H/'rf1131-stop.receipt.json');assert stop['ownedProcessExited'] and stop['settingsRestored'] and stop['fontScaleRestored'] and stop['dedicatedPortsFree']
prov=load(B/'rf1131-source-provenance-20261012.json');assert all(sha(R/n)==h for n,h in prov['runtimeValidationSourceFiles'].items())
assert all(sha(Path(x['copy']))==x['sha256'] for x in prov['apkFiles'])
assert not O.exists();O.mkdir();members={}
for prefix,parent in [('checks-and-probes',S),('native',NATIVE)]:
 for p in parent.rglob('*'):
  if p.is_file() and p.suffix in ['.json','.log','.py','.png','.xml','.before','.red']:
   assert not(p.stat().st_file_attributes&0x400);members[prefix+'/'+p.relative_to(parent).as_posix()]=p
for name in ['boot.receipt.json','emulator.live.json','owned-processes-after-launch.json','surfaceflinger.log','webview.log','rf1131-stop.receipt.json','rf1131-processes-after-owned-exit.json']:
 members['boot/'+name]=H/name
for n in ['probe-rf1131-font-restore.py','probe-rf1131-font-restore-settled.py','verify-rf1131-api31-home-full.py','validate-rf1131-api31-full.py','stop-rf1131-console-api31.py','archive-rf1131-font-restore.py','rf1131-source-provenance-20261012.json','rf1131-api31-cleanup-plan.json','cleanup-rf1131-api31.ps1']:
 members['tools/'+n]=B/n
for n in ['tauri/scripts/android-home-native-regression.py','tauri/scripts/test_android_home_native_regression.py']:
 members['sources/'+n]=R/n
members['build/current-apks.json']=B/'rf1126-legacy-theme-build-20261011/current-apks.json'
rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as a:
 for name,p in sorted(members.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;a.addfile(info,io.BytesIO(data))
  rows.append({'member':name,'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(O/'raw.tar.gz') as a:
 assert len(a.getmembers())==len(rows)
 for row in rows:
  data=a.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',{'task':'RF-1131','members':rows,'allMembersReadbackVerified':True,'privateTarsAndApksExcluded':True})
(O/'.gitattributes').write_text('raw.tar.gz -text\n',encoding='utf-8',newline='\n')
put(R/'docs/verification'/(N+'.json'),{'task':'RF-1131','sourceHead':'d5bb01fd5','accepted':True,'acceptanceScope':'external exact font restoration plus complete API31 home regression; other platforms remain incomplete','checks':checks,'actualRestorationProbe':{k:v for k,v in probe.items() if k!='calls'},'originalProbeFailureRetained':True,'nativeContexts':24,'nativeMethodsPassed':26,'nativeFailed':0,'nativeSkipped':0,'fontPairs':validation['fontPairs'],'allPrivateDataAndSettingsRestored':True,'privateEntriesPerContext':216,'sourceProvenanceScopeClarification':load(S/'evidence-scope-and-failures.json'),'sourceAudit':load(S/'behavior-boundary-audit.json'),'currentValidationSources':1837,'artifactBuildSourcesEqualCurrent':False,'apkBytesUnchanged':True,'ownedEmulatorGracefullyExited':True,'exactPrivateSnapshotsEligibleForCleanup':48,'fullRF121Accepted':False,'RF312Accepted':False,'allPngsHumanReviewed':False,'archive':{'path':N+'/raw.tar.gz','members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha(O/'raw.tar.gz'),'allMembersReadbackVerified':True}})
print(json.dumps({'accepted':True,'members':len(rows),'nativeContexts':24,'nativeMethodsPassed':26,'glyphComparisons':48}))
