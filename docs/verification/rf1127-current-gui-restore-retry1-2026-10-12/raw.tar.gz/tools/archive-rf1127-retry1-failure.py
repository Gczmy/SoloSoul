from pathlib import Path
import hashlib, io, json, tarfile
R=Path('D:/SoloSoul'); W=Path(__file__).parent
S=W/'rf1129-native-matrix-retry1-20261011'
N='rf1127-current-gui-restore-retry1-2026-10-12'; O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
matrix=load(S/'cohorts-complete.json')
assert not matrix['accepted'] and len(matrix['rows'])==2
assert matrix['rows'][0]=={'scene':'baseline','captureExitCode':0,'readerExitCode':0,'rendererExitCode':0}
assert matrix['rows'][1]=={'scene':'light-collapsed','captureExitCode':1,'readerExitCode':None,'rendererExitCode':None}
sources=load(S/'sources.json');assert len(sources)==1839 and all(sha(R/n)==h for n,h in sources.items())
cleanup=load(W/'rf1129-retry1-cache-cleanup.json')
assert cleanup['preservedBytesVerified'] and cleanup['processesTerminatedByThisTool']==0
assert cleanup['identitiesChecked']==54 and len(cleanup['removedCachePaths'])==48 and len(cleanup['linksUnlinked'])==6
assert len(cleanup['preservedVaultAndRootFiles'])==286 and len(cleanup['applicationLogs'])==6
assert all(not Path(p).exists() for p in cleanup['removedCachePaths'])
assert not O.exists(); O.mkdir(); members={}; outcomes=[]; raw_frames=0
for p in S.iterdir():
 if p.is_file() and p.suffix in ['.json','.log']:members['matrix/'+p.name]=p
excluded={'vault','app-data','profile','webview','temp','models','plugins'}
for mode in ['baseline','light-collapsed']:
 C=W/f'ss-rf121-composed-window-restore-{mode}-diagnostic-retry1-20261011'
 j=load(C/'actual100/native-perf-sdk-journey-results.json');assert len(j['samples'])==3
 assert all(x['cleanupIntegrity']['complete'] for x in j['samples'])
 outcomes.extend(x['success'] for x in j['samples'])
 for p in C.rglob('*'):
  rel=p.relative_to(C)
  if any(part in excluded for part in rel.parts):continue
  if p.is_file() and p.suffix in ['.json','.log','.bgra','.png']:
   members['capture/'+mode+'/'+rel.as_posix()]=p
   if p.suffix=='.bgra':raw_frames+=1
assert outcomes==[True,True,True,False,True,True] and raw_frames==5
failure_root=W/'ss-rf121-composed-window-restore-light-collapsed-diagnostic-retry1-20261011/actual100/sample-001'
failure=load(failure_root/'rf121-wgc-minimize-restore-owned.json')
assert failure['captionActivation']['error']=='caption-point-hits-other-window'
assert failure['captionActivation']['inputEventsSent']==0
for p in (W/'application-logs-rf1129-diagnostic-retry1').rglob('*'):
 if p.is_file():members['application-logs/'+p.relative_to(W/'application-logs-rf1129-diagnostic-retry1').as_posix()]=p
for n in ['prepare-rf1129-native-matrix-retry1.py','run-rf1129-diagnostic-retry1.py','verify-rf1129-diagnostic-retry1.mjs','render-rf1129-diagnostic-retry1.py','run-rf1129-cohorts-retry1.py','rf1129-session-preflight-retry1.py','rf1129-session-retry1-baseline.py','rf1129-session-retry1-light-collapsed.py','prepare-rf1129-retry1-terminal-cleanup.py','rf1129-retry1-cleanup-owned.ps1','rf1129-retry1-cache-cleanup-plan.json','rf1129-retry1-cache-cleanup-preflight.json','rf1129-retry1-cache-cleanup.json','archive-rf1127-retry1-failure.py','window-restore-contract.mjs']:
 members['tools/'+n]=W/n
restore=load(S/'restore-helper.json');members['sources/restore.rs']=Path(restore['source'])
assert sha(Path(restore['source']))==restore['sourceSha256'] and sha(Path(restore['exe']))==restore['sha256']
for n in ['tauri/scripts/native-perf-owned-json.py','tauri/scripts/native-perf-preference-contract.mjs','tauri/scripts/native-perf-sdk-journey.mjs','tauri/src-tauri/src/native_perf/sdk_surface_appearance.rs']:
 members['sources/'+n]=R/n
members['console-capability/capability-result.json']=W/'console-computer-use-20261012/capability-result.json'
rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as archive:
 for name,p in sorted(members.items()):
  assert not(p.stat().st_file_attributes&0x400)
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  archive.addfile(info,io.BytesIO(data));rows.append({'member':name,'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(O/'raw.tar.gz') as archive:
 assert len(archive.getmembers())==len(rows)
 for row in rows:
  data=archive.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',{'task':'RF-1127','allMembersReadbackVerified':True,'members':rows,'physicalVaultExecutablesModelsAndCachesExcluded':True})
(O/'.gitattributes').write_text('raw.tar.gz -text\n',encoding='utf-8',newline='\n')
put(R/'docs/verification'/(N+'.json'),{'task':'RF-1127','sourceHead':'067fe8c7adc58ce4fe210d96c794934e81b8f213','accepted':False,'exeSha256':load(S/'caption-runtime-package.json')['sha256'],'sources':len(sources),'requestedCohorts':4,'executedCohorts':2,'sdkJourneysPassed':5,'sdkJourneysFailed':1,'rawWindowFrames':5,'independentlyAcceptedFrames':3,'humanReviewedFrames':1,'failureReason':'owned-window-restoration-incomplete','captionError':'caption-point-hits-other-window','captionInputEventsSent':0,'occupyingWindowOwnerRecorded':False,'failureCauseResolved':False,'failure':failure,'cleanup':{k:len(v) if isinstance(v,list) else v for k,v in cleanup.items()},'fullRF121Accepted':False,'RF1128Accepted':False,'performanceAccepted':False,'consoleComputerUse':load(W/'console-computer-use-20261012/capability-result.json'),'archive':{'path':N+'/raw.tar.gz','members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha(O/'raw.tar.gz'),'allMembersReadbackVerified':True}})
print(json.dumps({'accepted':False,'members':len(rows),'sdkPassed':5,'sdkFailed':1,'independentlyAcceptedFrames':3,'rawFrames':5}))
