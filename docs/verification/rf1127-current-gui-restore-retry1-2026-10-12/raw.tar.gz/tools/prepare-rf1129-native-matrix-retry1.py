from pathlib import Path
import hashlib,json,shutil,subprocess

R=Path('D:/SoloSoul'); W=Path(__file__).parent.resolve()
B=W/'rf1129-native-build-20261011'; S=W/'rf1129-native-matrix-retry1-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def save(n,v):
    with (S/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')

assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()
assert load(B/'build.receipt.json')['exitCode']==0
assert load(B/'dist-input-stability.json')['allGeneratedFrontendInputsUnchangedDuringRustBuild']
sources=load(B/'sources.json'); assert len(sources)==1839
assert all(sha(R/n)==h for n,h in sources.items())
package=load(B/'runtime-package.json'); assert package['currentNativeTests']==137
assert sha(Path(package['exe']))==package['sha256'] and not package['guiExecuted']
S.mkdir(exist_ok=False)
save('sources.json',sources);save('caption-runtime-package.json',package)
old=W/'rf1128-shared-reader-20261011'
shutil.copyfile(old/'restore-helper.json',S/'restore-helper.json')
assert sha(old/'restore-helper.json')==sha(S/'restore-helper.json')
names=[('run-rf1128-shared.py','run-rf1129-diagnostic-retry1.py'),
       ('verify-rf1128-shared.mjs','verify-rf1129-diagnostic-retry1.mjs'),
       ('render-rf1128-shared.py','render-rf1129-diagnostic-retry1.py'),
       ('run-rf1128-cohorts.py','run-rf1129-cohorts-retry1.py'),
       ('rf1128-session-preflight.py','rf1129-session-preflight-retry1.py')]
mapping=[('rf1128-shared-reader-20261011',S.name),
         ('-shared-20261011','-diagnostic-retry1-20261011'),
         ("'rf1128-session-'+mode+'.py'","'rf1129-session-retry1-'+mode+'.py'"),*names]
tools={}; rows=[]
for a,b in names:
    text=(W/a).read_text(encoding='utf-8')
    changed=text
    for x,y in mapping:changed=changed.replace(x,y)
    p=W/b
    with p.open('x',encoding='utf-8') as f:f.write(changed)
    assert p.read_text(encoding='utf-8')==changed
    tools[str(p.relative_to(R))]=sha(p)
    rows.append({'before':str(W/a),'beforeSha256':sha(W/a),
                 'after':str(p),'afterSha256':sha(p),
                 'changes':'only exclusive output/package paths and tool names'})
for p in [W/'window-restore-contract.mjs',Path(__file__),
          R/'tauri/scripts/native-perf-owned-json.py',
          R/'tauri/scripts/test_native_perf_owned_json.py']:
    tools[str(p.relative_to(R))]=sha(p)
save('tools.json',tools)
save('preparation.json',{'sourceCount':len(sources),'nativeTests':137,
     'currentGuiSha256':package['sha256'],'derivation':rows,'replacements':mapping,
     'originalGuardsAndBudgetsUnchanged':True,'extraInputRetries':0,
     'wholeMatrixAccepted':False,'oldFailedRoundsPreserved':True,
     'generatedFrontendBuildInputs':load(B/'dist-input-stability.json')})
save('first-failure-retained.json',{'previousFailureArchive':'docs/verification/rf1127-current-gui-home-timeout-2026-10-11.json','wholeMatrixRetry':1,'perSampleInputRetriesAdded':0,'guiRebuilt':False,'scopeReduced':False})
print('Current diagnostic GUI: four new groups prepared; original guards unchanged')
