import {checkRestore} from './window-restore-contract.mjs';
import {checkPreferenceWrites,preferenceWriteDelta,correlateSettledThemeInterval} from '../../tauri/scripts/native-perf-preference-contract.mjs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile, lstat, realpath} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {validateObserver,ipcDelta} from '../../tauri/scripts/native-perf-run.mjs';
import {checkJourney, checkBound} from '../../tauri/scripts/native-perf-sdk-journey.mjs';
import {describeAuthAttribution} from '../../tauri/scripts/native-perf-auth-contract.mjs';
import {checkMaintenanceAdmission} from '../../tauri/scripts/native-perf-maintenance-contract.mjs';

const stage=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(stage,'../..');
assert(['--baseline','--light-collapsed','--dark-expanded','--dark-collapsed'].includes(process.argv[2])&&process.argv.length===3);
const mode=process.argv[2].slice(2);
const scene=mode==='light-collapsed',dark=mode.startsWith('dark-'),collapsed=mode.endsWith('collapsed');
const captureStage=path.join(stage,`ss-rf121-composed-window-restore-${mode}-diagnostic-retry1-20261011`);
const output=path.join(captureStage,'actual100');
const load=async file=>JSON.parse((await readFile(file,'utf8')).replace(/^\uFEFF/,''));
const sha=async file=>createHash('sha256').update(await readFile(file)).digest('hex');
const regular=async(file,max=262144)=>{
  const stat=await lstat(file); assert(stat.isFile()&&!stat.isSymbolicLink()&&stat.size<=max);
  assert.equal((await realpath(file)).toLowerCase(),file.toLowerCase());
  return load(file);
};
const exact=(value,keys)=>assert.deepEqual(Object.keys(value).sort(),[...keys].sort());
const number=(v,min,max)=>assert(Number.isFinite(v)&&v>=min&&v<=max);
const color=v=>{assert(Array.isArray(v)&&v.length===4);v.slice(0,3).forEach(x=>number(x,0,255));number(v[3],0,1);};
const stateKeys=['schemaVersion','scope','runId','href','timeOriginMs','atMs','theme','platform',
  'material','highContrast','forcedColors','reducedTransparency','focused','visibility',
  'viewport','expanded','palette','surfaces'];
function validateState(s,owned,bound){
  exact(s,stateKeys); assert.equal(s.schemaVersion,1);assert.equal(s.scope,'windows-native-surface-state');
  assert.equal(s.runId,owned.runId);assert.equal(s.href,'http://tauri.localhost/');
  assert.equal(s.timeOriginMs,bound.timeOriginMs);number(s.atMs,0,300000);
  assert(['light','dark'].includes(s.theme));assert.equal(s.platform,'windows');
  assert(['mica','solid'].includes(s.material));assert(['visible','hidden'].includes(s.visibility));
  for(const key of ['highContrast','forcedColors','reducedTransparency','focused','expanded'])assert.equal(typeof s[key],'boolean');
  assert(s.viewport.length===3);number(s.viewport[0],1,16384);number(s.viewport[1],1,16384);number(s.viewport[2],.25,8);
  exact(s.palette,['base','elevated','text']);Object.values(s.palette).forEach(color);
  exact(s.surfaces,['navigation','appbar','content','card']);
  for(const surface of Object.values(s.surfaces)){
    exact(surface,['rect','background','text','radius']);assert.equal(surface.rect.length,4);
    surface.rect.slice(0,2).forEach(v=>number(v,-16384,16384));
    surface.rect.slice(2).forEach(v=>number(v,1,16384));
    color(surface.background);color(surface.text);number(surface.radius,0,128);
  }
}

const inputs=await load(path.join(captureStage,'input-proof.json'));
const pkg=inputs.runtime;
const restorePackage=await load(path.join(stage,'rf1129-native-matrix-retry1-20261011/restore-helper.json'));
assert.equal(await sha(restorePackage.exe),restorePackage.sha256);assert.equal(await sha(restorePackage.source),restorePackage.sourceSha256);
assert.equal(pkg.helperMetadataVersion,3);
assert.equal(await sha(pkg.exe),pkg.sha256);assert.equal(await sha(pkg.helperExe),pkg.helperSha256);
assert.equal(await sha(pkg.activationExe),pkg.activationSha256);
assert.equal(await sha(pkg.activationSource),pkg.activationSourceSha256);
assert.equal(await sha(pkg.helperSource??path.join(stage,'helper/src/bin/owned-window.rs')),pkg.helperSourceSha256);
assert.equal(await sha(path.join(stage,'rf1129-native-matrix-retry1-20261011/sources.json')),inputs.sourceManifestSha256);
for(const [name,digest] of Object.entries(await load(path.join(stage,'rf1129-native-matrix-retry1-20261011/sources.json'))))assert.equal(await sha(path.join(root,name)),digest);
for(const item of pkg.resources){assert.equal(await sha(item.source),item.sha256);assert.equal(await sha(item.copy),item.sha256);}
for(const [name,digest] of Object.entries(inputs.fixtureFiles))assert.equal(await sha(path.join(inputs.fixture,name)),digest);
const receipt=await load(path.join(captureStage,'actual100.receipt.json'));
assert.equal(receipt.exitCode,0);assert.equal(receipt.sourceUnchanged,true);
assert.equal(receipt.originalFixtureUnchanged,true);assert.equal(receipt.resourcesUnchanged,true);
assert.equal(receipt.pdfiumOverrideInherited,false);
const journey=await load(path.join(output,'native-perf-sdk-journey-results.json'));
const authGroup=await load(path.join(output,'native-perf-auth-attribution-results.json'));
assert.equal(journey.exeSha256,pkg.sha256);assert.equal(journey.success,true);
assert.equal(journey.samplesRequested,3);assert.equal(journey.interrupted,false);
assert.equal(journey.sourceUnchanged,true);assert.equal(journey.memoryIntervalMs,null);
assert.deepEqual(journey.samples.map(s=>s.index),[1,2,3]);assert.equal(authGroup.success,true);
assert.equal(authGroup.samples.length,3);assert.equal(authGroup.performanceMetrics,null);
const preferenceIntervals=[];const samples=[];
for(const sample of journey.samples){
  const dir=path.join(output,`sample-${String(sample.index).padStart(3,'0')}`);
  assert.equal(sample.root.toLowerCase(),dir.toLowerCase());assert.equal(sample.success,true);
  assert.equal(sample.cleanupIntegrity.complete,true);
  assert.deepEqual(await regular(path.join(output,`sample-${String(sample.index).padStart(3,'0')}.json`),4194304),sample);
  const owned=await regular(path.join(dir,'native-perf-owned.json'));
  const bound=await regular(path.join(dir,'native-perf-sdk-journey-bound.json'));
  assert.deepEqual(owned,sample.owned);assert.deepEqual(bound,sample.bound);
  checkBound(bound,owned,sample.processId,bound.port);
  const native=await regular(path.join(dir,'native-perf-sdk-journey.json'),4194304);
  assert.deepEqual(native,sample.nativeProof);checkJourney(native,owned,bound,journey.fixture,false);
  const auth=await regular(path.join(dir,'native-perf-auth-attribution.json'));
  const attribution=describeAuthAttribution(auth,owned,bound);
  assert.equal(attribution.frontend.flows.length,2);
  assert(attribution.frontend.flows.every(f=>f.outcome==='finished'));
  const maintenance=checkMaintenanceAdmission(await regular(path.join(dir,'native-perf-maintenance-admission.json'),4194304),auth,owned,bound);
  const request=await regular(path.join(dir,'native-perf-surface-request.json'),4096);
  exact(request,['schemaVersion','scope','runId','pid','browserPid','token']);
  assert.equal(request.schemaVersion,1);assert.equal(request.scope,'windows-native-surface-request');
  assert.equal(request.runId,owned.runId);assert.equal(request.pid,bound.pid);
  assert.equal(request.browserPid,bound.browserPid);assert.match(request.token,/^[0-9a-f]{32}$/);
  const beforePath=path.join(dir,'native-perf-surface-before.json');
  const before=await regular(beforePath),after=await regular(path.join(dir,'native-perf-surface-after.json'));
  exact(before,['schemaVersion','scope','request','binding','state']);
  exact(after,['schemaVersion','scope','request','binding','beforeSha256','pixelSha256','state','stable','applicationMaterialAccepted','performanceMetrics']);
  assert.equal(before.schemaVersion,1);assert.equal(after.schemaVersion,1);
  assert.equal(before.scope,'windows-native-surface-before');assert.equal(after.scope,'windows-native-surface-after');
  for(const proof of [before,after]){assert.deepEqual(proof.request,request);assert.deepEqual(proof.binding,bound.binding);validateState(proof.state,owned,bound);}
  const a={...before.state},b={...after.state};delete a.atMs;delete b.atMs;assert.deepEqual(a,b);
  assert(after.state.atMs>=before.state.atMs&&before.state.atMs>=native.lastProbe.atMs);
  assert.equal(after.stable,true);assert.equal(after.applicationMaterialAccepted,false);assert.equal(after.performanceMetrics,null);
  assert.equal(before.state.theme,dark?'dark':'light');assert.equal(before.state.expanded,!collapsed);
  assert.equal(before.state.focused,true);assert.equal(before.state.visibility,'visible');
  if(scene){
    const sceneRequest=await regular(path.join(dir,'native-perf-surface-scene-request.json'),4096);
    assert.deepEqual(sceneRequest,{...request,scope:'windows-native-sidebar-scene-request',scene:'light-collapsed'});
    const prepared=await regular(path.join(dir,'native-perf-surface-scene-prepared.json'));
    const restored=await regular(path.join(dir,'native-perf-surface-scene-restored.json'));
    const complete=await regular(path.join(dir,'native-perf-surface-scene-result.json'));
    exact(prepared,['schemaVersion','scope','request','binding','initial','prepared','performanceMetrics']);
    exact(restored,['schemaVersion','scope','request','binding','before','restored','performanceMetrics']);
    exact(complete,['schemaVersion','scope','request','captureError','restoreError','success','performanceMetrics']);
    for(const [proof,scope] of [[prepared,'prepared'],[restored,'restored'],[complete,'result']]){
      assert.equal(proof.schemaVersion,1);assert.equal(proof.scope,'windows-native-sidebar-scene-'+scope);
      assert.deepEqual(proof.request,sceneRequest);assert.equal(proof.performanceMetrics,null);
    }
    assert.deepEqual(prepared.binding,bound.binding);assert.deepEqual(restored.binding,bound.binding);
    assert.equal(complete.success,true);assert.equal(complete.captureError,null);assert.equal(complete.restoreError,null);
    const states=[prepared.initial,prepared.prepared,restored.before,restored.restored];
    states.forEach((p,i)=>{
      exact(p,['schemaVersion','scope','href','timeOriginMs','atMs','theme','platform','expanded','viewport','focused','visibility','layout','settled','target','inputTrust']);
      assert.equal(p.schemaVersion,1);assert.equal(p.scope,'windows-native-sidebar-probe');
      assert.equal(p.href,'http://tauri.localhost/');assert.equal(p.timeOriginMs,bound.timeOriginMs);
      number(p.atMs,i?states[i-1].atMs:native.lastProbe.atMs,300000);
      assert.equal(p.theme,'light');assert.equal(p.platform,'windows');assert.equal(p.focused,true);
      assert.equal(p.visibility,'visible');assert.equal(p.settled,true);assert.deepEqual(p.viewport,before.state.viewport);
      assert.equal(p.expanded,i===0||i===3);assert.equal(p.layout.length,3);
      p.layout.forEach(r=>{assert.equal(r.length,4);r.slice(0,2).forEach(n=>number(n,-16384,16384));r.slice(2).forEach(n=>number(n,1,16384));});
      exact(p.target,['x','y','actionable']);assert.equal(p.target.actionable,true);
      number(p.target.x,0,p.viewport[0]-1);number(p.target.y,0,p.viewport[1]-1);
      exact(p.inputTrust,['pointer','text','untrusted']);assert.equal(p.inputTrust.text,3);assert.equal(p.inputTrust.untrusted,0);
      assert.equal(p.inputTrust.pointer,native.lastProbe.inputTrust.pointer+[0,1,1,2][i]);
    });
    assert(prepared.prepared.atMs<=before.state.atMs&&restored.before.atMs>=after.state.atMs);
    assert.deepEqual(prepared.initial.inputTrust,native.lastProbe.inputTrust);
    assert.deepEqual(prepared.initial.layout[0],restored.restored.layout[0]);
    assert.equal(before.state.surfaces.navigation.rect[2],96);
  }else{
    await assert.rejects(lstat(path.join(dir,'native-perf-surface-scene-request.json')),{code:'ENOENT'});
  }

  if(dark){
    const req=await regular(path.join(dir,'native-perf-surface-appearance-request.json'),4096);
    assert.deepEqual(req,{...request,scope:'windows-native-appearance-scene-request',scene:mode});
    const prep=await regular(path.join(dir,'native-perf-surface-appearance-prepared.json'),4194304);
    const restore=await regular(path.join(dir,'native-perf-surface-appearance-restored.json'),4194304);
    const result=await regular(path.join(dir,'native-perf-surface-appearance-result.json'));
    exact(prep,['schemaVersion','scope','request','binding','initial','steps','originalPreference','performanceMetrics']);
    exact(restore,['schemaVersion','scope','request','binding','steps','originalPreference','preferenceVerified','performanceMetrics']);
    exact(result,['schemaVersion','scope','request','captureError','restoreError','success','callsBefore','callsAfter','performanceMetrics']);
    for(const [p,suffix] of [[prep,'prepared'],[restore,'restored'],[result,'result']]){
      assert.equal(p.schemaVersion,1);assert.equal(p.scope,'windows-native-appearance-'+suffix);
      assert.deepEqual(p.request,req);assert.equal(p.performanceMetrics,null);
    }
    assert.deepEqual(prep.binding,bound.binding);assert.deepEqual(restore.binding,bound.binding);
    assert(['light','system'].includes(prep.originalPreference));
    assert.equal(restore.originalPreference,prep.originalPreference);assert.equal(restore.preferenceVerified,true);
    assert.equal(result.success,true);assert.equal(result.captureError,null);assert.equal(result.restoreError,null);
    assert.deepEqual(native.lastProbe.inputTrust,{pointer:10,text:3,untrusted:0});
    const observers=new Map();let previousAt=native.lastProbe.atMs;
    const origin='http://tauri.localhost/';
    function appearance(p,action,theme,expanded,pointer,text,checked=null){
      exact(p,['schemaVersion','scope','action','href','timeOriginMs','atMs','theme','platform','expanded','viewport','focused','visibility','layout','settled','target','checked','radios','inputTrust','observer','preferenceWrites']);
      assert.equal(p.schemaVersion,1);assert.equal(p.scope,'windows-native-appearance-probe');
      checkPreferenceWrites(p.preferenceWrites,{runId:owned.runId,pid:bound.pid});
      assert.equal(p.action,action);
      assert.equal(p.href,['settings','toggle','done'].includes(action)?origin:action==='appearance'?origin+'settings':origin+'settings/appearance');
      assert.equal(p.timeOriginMs,bound.timeOriginMs);number(p.atMs,previousAt,300000);previousAt=p.atMs;
      assert.equal(p.theme,theme);assert.equal(p.platform,'windows');assert.equal(p.expanded,expanded);
      assert.deepEqual(p.viewport,before.state.viewport);assert.equal(p.focused,true);
      assert.equal(p.visibility,'visible');assert.equal(p.settled,true);
      assert(Array.isArray(p.layout)&&p.layout.length===3);
      p.layout.forEach(r=>{assert(Array.isArray(r)&&r.length===4);r.slice(0,2).forEach(v=>number(v,-16384,16384));r.slice(2).forEach(v=>number(v,1,16384));});
      if(action==='done')assert.equal(p.target,null);
      else{exact(p.target,['x','y','actionable']);assert.equal(p.target.actionable,true);number(p.target.x,0,p.viewport[0]-1);number(p.target.y,0,p.viewport[1]-1);}
      assert.deepEqual(p.inputTrust,{pointer,text,untrusted:0});assert.equal(p.checked,checked);
      assert.deepEqual(p.radios,checked===null?[]:['light','dark','system'].map(x=>x===checked));
      const o=p.observer;
      exact(o,['schemaVersion','scope','runId','valid','invalidReasons','total','observedCount','maxEvents','timeOriginMs','installedAtMs','commands']);
      assert.equal(o.schemaVersion,1);assert.equal(o.scope,'windows-native-tauri-invoke-observer');
      assert.equal(o.runId,owned.runId);assert.equal(o.valid,true);assert.deepEqual(o.invalidReasons,[]);
      assert.equal(o.maxEvents,16384);assert.equal(o.timeOriginMs,bound.timeOriginMs);
      number(o.installedAtMs,0,p.atMs);assert.equal(o.total,o.commands.length);assert.equal(o.observedCount,o.total);
      o.commands.forEach(c=>{exact(c,['command','atMs']);number(c.atMs,o.installedAtMs,p.atMs);});
      const n=validateObserver(o,owned.runId);assert.equal(n.valid,true);observers.set(p,n);
    }
    appearance(prep.initial,'settings','light',true,10,3);
    assert.equal(ipcDelta(validateObserver(native.lastProbe.observer,owned.runId),observers.get(prep.initial)).reason,null);
    assert.equal(prep.steps.length,collapsed?5:4);
    appearance(prep.steps[0],'appearance','light',true,11,3);
    appearance(prep.steps[1],'dark','light',true,12,3,prep.originalPreference);
    appearance(prep.steps[2],'home','dark',true,13,4,'dark');
    appearance(prep.steps[3],'toggle','dark',true,14,4);
    if(collapsed)appearance(prep.steps[4],'toggle','dark',false,15,4);
    assert.equal(restore.steps.length,collapsed?6:5);
    let offset=0,pointer=collapsed?15:14;
    if(collapsed){appearance(restore.steps[0],'toggle','dark',false,pointer++,4);offset=1;}
    appearance(restore.steps[offset],'settings','dark',true,pointer++,4);
    appearance(restore.steps[offset+1],'appearance','dark',true,pointer++,4);
    appearance(restore.steps[offset+2],'original','dark',true,pointer++,4,'dark');
    appearance(restore.steps[offset+3],'home','light',true,pointer++,5,prep.originalPreference);
    appearance(restore.steps[offset+4],'done','light',true,pointer,5);
    assert.deepEqual(restore.steps.at(-1).layout[0],prep.initial.layout[0]);
    assert.deepEqual(restore.steps.at(-1).viewport,prep.initial.viewport);
    assert(prep.steps.at(-1).atMs<=before.state.atMs&&restore.steps[0].atMs>=after.state.atMs);
    const sequence=[prep.initial,...prep.steps,...restore.steps];
    for(let i=1;i<sequence.length;i++){assert.equal(ipcDelta(observers.get(sequence[i-1]),observers.get(sequence[i])).reason,null);preferenceWriteDelta(sequence[i-1].preferenceWrites,sequence[i].preferenceWrites,{runId:owned.runId,pid:bound.pid});}
    for(const [a,b] of [[prep.steps[1],prep.steps[2]],[restore.steps.at(-3),restore.steps.at(-2)]]){
      const delta=ipcDelta(observers.get(a),observers.get(b));
      const transportAttempts=delta.commands.find(c=>c.command==='user_data_update_preference')?.attempts??0;
      const categories=correlateSettledThemeInterval(a.preferenceWrites,b.preferenceWrites,restore.steps.at(-1).preferenceWrites,{runId:owned.runId,pid:bound.pid},transportAttempts);
      preferenceIntervals.push({index:sample.index,runId:owned.runId,pid:bound.pid,from:a.action,to:b.action,transportAttempts,backend:categories});
    }
    assert.equal(result.callsAfter,native.calls.length);assert.equal(result.callsAfter-result.callsBefore,collapsed?48:40);
    assert(result.callsAfter<=128);
    if(collapsed)assert.equal(before.state.surfaces.navigation.rect[2],96);
  }else{
    await assert.rejects(lstat(path.join(dir,'native-perf-surface-appearance-request.json')),{code:'ENOENT'});
  }
  const tag=before.state.theme+'-visible';
  const captured=await regular(path.join(dir,`rf121-wgc-${tag}.json`));
  const inventory=await regular(path.join(dir,`rf121-window-inventory-${tag}.json`));
  const owner=await regular(path.join(dir,'surface-identity.json'));
  assert.equal(owner.pid,bound.pid);assert.equal(owner.exe.toLowerCase(),pkg.exe.replaceAll('/','\\').toLowerCase());
  const activation=await regular(path.join(dir,'rf121-wgc-activate-owned.json'));
  const activationReceipt=await regular(path.join(dir,'surface-activation.receipt.json'));
  exact(activation,['schemaVersion','scope','runId','pid','creationMs','hwnd','tag','foregroundBefore','foregroundAfter','requested','apiReturned','elapsedMilliseconds','heldProcessAndWindowIdentityVerifiedBeforeAndAfter','pixelsRead','inputEventsSent','systemSettingsChanged','applicationMaterialAccepted','otherWindowsActivated','captionActivation']);
  assert.equal(activationReceipt.exitCode,0);
  assert.deepEqual(activationReceipt.command,[pkg.activationExe,dir,String(bound.pid),String(owner.creationMs),pkg.exe,'activate-owned']);
  assert.deepEqual(await regular(path.join(dir,'surface-activation.stdout.log')),activation);
  assert.equal(activation.schemaVersion,1);assert.equal(activation.scope,'rf121-owned-window-foreground-with-caption');
  assert.equal(activation.runId,owned.runId);assert.equal(activation.pid,bound.pid);
  assert.equal(activation.creationMs,owner.creationMs);assert.equal(activation.hwnd,captured.hwnd);
  assert.equal(activation.tag,'activate-owned');assert.equal(activation.foregroundAfter,true);
  assert.equal(typeof activation.foregroundBefore,'boolean');assert.equal(activation.requested,!activation.foregroundBefore);
  if(activation.requested)assert.equal(typeof activation.apiReturned,'boolean');else assert.equal(activation.apiReturned,null);
  number(activation.elapsedMilliseconds,0,25000);
  assert.equal(activation.heldProcessAndWindowIdentityVerifiedBeforeAndAfter,true);
  for(const key of ['pixelsRead','otherWindowsActivated'])assert.equal(activation[key],0);
  for(const key of ['systemSettingsChanged','applicationMaterialAccepted'])assert.equal(activation[key],false);
  const initialCaption=activation.captionActivation;
  assert.equal(initialCaption.error,null);assert.equal(initialCaption.extraReleaseEventsSent,0);
  assert.equal(activation.inputEventsSent,initialCaption.inputEventsSent);
  if(initialCaption.attempted){assert.equal(initialCaption.nativeHitTest,2);assert.equal(initialCaption.inputEventsSent,2);assert.equal(initialCaption.cursorRestored,true);assert.equal(initialCaption.cursorMovedByUser,false);}
  else assert.equal(initialCaption.inputEventsSent,0);
  assert.equal(captured.schemaVersion,pkg.helperMetadataVersion??1);assert.equal(captured.scope,'rf121-owned-window-wgc-frame');
  for(const proof of [captured,inventory]){
    assert.equal(proof.runId,owned.runId);assert.equal(proof.pid,bound.pid);assert.equal(proof.creationMs,owner.creationMs);
  }
  assert.equal(inventory.scope,'rf121-owned-process-window-inventory');
  assert.equal(inventory.heldProcessIdentityVerifiedBeforeAndAfter,true);
  assert.equal(inventory.otherProcessWindowsInspected,0);assert.equal(inventory.pixelsRead,0);
  assert.equal(captured.captureMethod,'Windows.Graphics.Capture.CreateForWindow');
  assert.equal(captured.heldProcessAndWindowIdentityVerifiedBeforeAndAfter,true);
  assert.equal(captured.otherWindowsCaptured,0);assert.equal(captured.applicationMaterialAccepted,false);
  assert.equal(captured.tag,tag);assert.equal(captured.pixelFormat,'BGRA8-premultiplied');
  assert.equal(captured.foregroundBefore,captured.foregroundAfter);assert.equal(typeof captured.foregroundBefore,'boolean');
  assert.equal(captured.foregroundBefore,before.state.focused);
  assert.equal(captured.foregroundAfter,after.state.focused);
  number(captured.ownedWindowDpi,48,768);
  assert.equal(captured.nativeAppearanceVerified,false);
  assert.equal(captured.dwmAppearanceReadback,'documented-system-backdrop-only');
  assert.equal(captured.dwmDarkMode,null);assert.equal(captured.dwmCaptionColor,null);
  const readback=captured.dwmSystemBackdropReadback;
  exact(readback,['attribute','before','after','stable']);assert.equal(readback.attribute,38);
  assert.equal(readback.stable,true);assert.deepEqual(readback.before,readback.after);
  const expectedBackdrop=before.state.material==='mica'?2:1;
  for(const observed of [readback.before,readback.after]){
    exact(observed,['ok','value','errorHresult']);assert.equal(observed.ok,true);
    assert.equal(observed.errorHresult,null);assert.equal(observed.value,expectedBackdrop);
  }
  assert.equal(captured.dwmSystemBackdropType,expectedBackdrop);
  assert.equal(captured.pixelFile,`rf121-wgc-${tag}.bgra`);
  const pixelFile=path.join(dir,captured.pixelFile),stat=await lstat(pixelFile);
  assert(stat.isFile()&&!stat.isSymbolicLink());assert.equal(await realpath(pixelFile),pixelFile);
  assert.equal(stat.size,captured.bytes);assert.equal(stat.size,captured.width*captured.height*4);
  assert(stat.size>0&&stat.size<=32*1024*1024);
  const beforeSha=await sha(beforePath),pixelSha=await sha(pixelFile);
  assert.equal(after.beforeSha256,beforeSha);assert.equal(after.pixelSha256,pixelSha);
  assert.deepEqual(await regular(path.join(dir,'native-perf-surface-done.json'),4096),
    {...request,scope:'windows-native-surface-done',beforeSha256:beforeSha,pixelSha256:pixelSha});
  assert.equal((await regular(path.join(dir,'surface-capture.receipt.json'))).exitCode,0);
  const restore=await regular(path.join(dir,'rf121-wgc-minimize-restore-owned.json'));
  const restoreReceipt=await regular(path.join(dir,'surface-minimize-restore.receipt.json'));
  assert.equal(restoreReceipt.exitCode,0);assert.equal(restoreReceipt.originalSurfaceBudgetUnchanged,true);
  assert.deepEqual(restoreReceipt.command,[restorePackage.exe,dir,String(bound.pid),String(owner.creationMs),pkg.exe,'minimize-restore-owned']);
  assert.deepEqual(await regular(path.join(dir,'surface-minimize-restore.stdout.log')),restore);
  checkRestore(restore,{runId:owned.runId,pid:bound.pid,creationMs:owner.creationMs,hwnd:captured.hwnd,
    windowRect:captured.windowRect,clientRect:captured.clientRect,dpi:captured.ownedWindowDpi,backdrop:expectedBackdrop});
  // Cleanup uses the exact identities from both actual process snapshots, never inferred descendants.
  const recordedIdentities=[...sample.beforeSnapshot.processes,...sample.afterSnapshot.processes]
    .map(p=>({pid:p.pid,creationMs:p.creationMs}));
  assert(recordedIdentities.every(p=>Number.isInteger(p.pid)&&Number.isFinite(p.creationMs)));
  samples.push({index:sample.index,runId:owned.runId,pid:bound.pid,browserPid:bound.browserPid,
    state:before.state,afterAtMs:after.state.atMs,beforeSha256:beforeSha,pixelSha256:pixelSha,
    capture:captured,restore,recordedIdentities,maintenance,success:true});
}
assert.equal(new Set(samples.map(s=>s.runId)).size,3);
const validation={schemaVersion:1,task:'RF-121',scope:'windows-owned-restoration-preference-classification-binding',
  at:new Date().toISOString(),accepted:true,windowRestoreBindingVerified:true,preferenceClassificationVerified:true,preferenceIntervals,samples,sourceFiles:1839,
  diagnosticOnly:true,performanceMetrics:null,applicationMaterialAccepted:false,scene:mode,
  fullMatrixAccepted:false,otherPlatformAcceptance:false,nativeAppearancePropertiesVerified:false,nativeSystemBackdropVerified:true};
await writeFile(path.join(captureStage,'validation.json'),JSON.stringify(validation,null,2)+'\n',{flag:'wx'});
process.stdout.write('Three actual restorations and state/pixel bindings verified with fixed preference classes; fixed target interval and later settlement verified; full material/performance matrix remains unaccepted\n');
