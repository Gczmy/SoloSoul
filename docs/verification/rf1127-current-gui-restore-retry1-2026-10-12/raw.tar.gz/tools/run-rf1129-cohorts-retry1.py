from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
W=Path(__file__).parent.resolve();R=Path('D:/SoloSoul');S=W/'rf1129-native-matrix-retry1-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):
 with (S/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
sources=load(S/'sources.json');tools=load(S/'tools.json');rows=[]
env=os.environ.copy();env.update(TEMP=str(S),TMP=str(S));env.pop('PDFIUM_LIBRARY_PATH',None)
def verify():
 for n,h in sources.items():assert sha(R/n)==h,n
 for n,h in tools.items():assert sha(R/n)==h,n
def run(name,cmd):
 verify();start=time.monotonic()
 with (S/(name+'.stdout.log')).open('xb') as out,(S/(name+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  save(name+'.live.json',{'pid':p.pid,'command':cmd});print(name,'PID',p.pid,flush=True);code=p.wait()
 verify();save(name+'.receipt.json',{'pid':p.pid,'command':cmd,'exitCode':code,'elapsedSeconds':time.monotonic()-start});print(name,'exit',code,flush=True)
 return code
assert not (S/'cohorts-complete.json').exists()
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
 # Never start a cohort on stale session state. Each probe writes a new owned receipt.
 text=(W/'rf1129-session-preflight-retry1.py').read_text(encoding='utf-8').replace('session-before-native.json','session-before-'+mode+'.json')
 probe=W/('rf1129-session-retry1-'+mode+'.py')
 with probe.open('x',encoding='utf-8') as f:f.write(text)
 assert run('session-'+mode,['C:/Python314/python.exe',str(probe)])==0
 session=load(S/('session-before-'+mode+'.json'))
 if session.get('connectionState')!=0 or not session.get('inputDesktopAvailable'):
  save('desktop-denial-'+mode+'.json',{'nativeTestsStarted':0,'session':session,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
  print('desktop gate rejected; native cohort not started',flush=True);raise SystemExit(1)
 capture=run('capture-'+mode,['C:/Python314/python.exe',str(W/'run-rf1129-diagnostic-retry1.py'),'--'+mode])
 reader=render=None
 if capture==0:reader=run('reader-'+mode,['node',str(W/'verify-rf1129-diagnostic-retry1.mjs'),'--'+mode])
 if reader==0:render=run('renderer-'+mode,['C:/Python314/python.exe',str(W/'render-rf1129-diagnostic-retry1.py'),'--'+mode])
 row={'scene':mode,'captureExitCode':capture,'readerExitCode':reader,'rendererExitCode':render};rows.append(row);save('cohort-'+mode+'.json',row)
 if not capture==reader==render==0:break
accepted=len(rows)==4 and all(x['captureExitCode']==x['readerExitCode']==x['rendererExitCode']==0 for x in rows)
save('cohorts-complete.json',{'accepted':accepted,'rows':rows,'fullRF121Accepted':False,'performanceAccepted':False})
raise SystemExit(0 if accepted else 1)
