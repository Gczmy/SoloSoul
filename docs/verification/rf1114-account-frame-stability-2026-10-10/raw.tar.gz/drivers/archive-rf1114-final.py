from pathlib import Path
import collections,datetime,difflib,hashlib,io,json,re,subprocess,tarfile

root=Path('D:/SoloSoul');base=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
slug='rf1114-account-frame-stability-2026-10-10'
out=root/'docs/verification'/slug
proof=load(base/'rf1114-account-stable-frame-test-build2/current-apks.json')
home='tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidHomeInstrumentedTest.kt'
assert sha(root/home)==proof['sourceFiles'][home]
v=load(base/'rf1114-account-stable-frame-native-round2/verification.json')
assert v['accepted'] and len(v['results'])==2
for row in v['results']:assert row['exitCode']==0 and row['accepted'] and row['restored']
for name in ['test-build','test-badging','test-signature']:
 assert load(base/'rf1114-account-stable-frame-test-build2'/(name+'.receipt.json'))['exitCode']==0
diag=load(base/'rf1114-account-diagnostic-native-round1/accounts-supported/device-files/report.json')
d=next(x for x in diag['records'] if x['stage']=='failure-account-action-pixels')
assert d['actionInkPixels']==0 and d['afterScreenshot']['action']['textRect']['y']-d['action']['textRect']['y']==151.5
assert not d['afterScreenshot']['action']['hittable']
out.mkdir(exist_ok=False)
(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf-8',newline='\n')
blobs={}
folders=['rf1113-cold-login-red-native-round1','rf1113-cold-login-red-native-round2',
 'rf1114-account-diagnostic-test-build1','rf1114-account-diagnostic-native-round1',
 'rf1114-account-stable-frame-test-build2','rf1114-account-stable-frame-native-round2']
for folder in folders:
 for p in (base/folder).rglob('*'):
  if p.is_file() and p.suffix in {'.json','.log','.png','.xml'}:
   blobs[(Path(folder)/p.relative_to(base/folder)).as_posix()]=p.read_bytes()
for p in base.glob('*rf1114*.py'):blobs['drivers/'+p.name]=p.read_bytes()
blobs['drivers/verify-session-reconnected.json']=(base/'verify-session-20261010-reconnected-final.json').read_bytes()
blobs['sources/before-home.kt']=(base/'rf1114-before-home.kt').read_bytes()
blobs['sources/diagnostic-home.kt']=(base/'rf1114-diagnostic-home.kt').read_bytes()
blobs['sources/after-home.kt']=(root/home).read_bytes()
blobs['sources/pending-rf1113-external-runner.py']=(root/'tauri/scripts/android-home-native-regression.py').read_bytes()
native=[]
for mode in ['supported','fallback']:
 run=base/'rf1114-account-stable-frame-native-round2'/('accounts-'+mode)
 raw=load(run/'device-files/report.json')
 account=[x for x in raw['records'] if x['stage'].startswith('account-') and 'action' in x]
 assert len(account)==5
 for x in account:
  assert x['action']['inkPixels']>=20 and x['action']['visible'] and x['action']['hittable']
  assert x['framePreparations'][-1]['stable']
  assert x['framePreparations'][-1]['beforeCopy']==x['framePreparations'][-1]['afterCopy']
 native.append({'mode':mode,'stages':len(raw['records']),'accounts':[
  {k:x[k] for k in ['stage','accountName','copyInkPixels','action','framePreparations']} for x in account]})
 for name in ['device-files/report.json','report.json']:
  p=out/'current-native'/('accounts-'+mode)/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((run/name).read_bytes())
archive=out/'raw.tar.gz';members=[]
with tarfile.open(archive,'w:gz',compresslevel=9) as tf:
 for name,data in sorted(blobs.items()):
  assert '..' not in Path(name).parts and not name.startswith('/')
  info=tarfile.TarInfo(name);info.size=len(data);tf.addfile(info,io.BytesIO(data))
  members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive) as tf:
 assert len(tf.getmembers())==len(members)
 for row in members:assert hashlib.sha256(tf.extractfile(row['path']).read()).hexdigest()==row['sha256']
index={'members':members,'count':len(members),'archiveSha256':sha(archive),
 'readBackVerified':True,'privateBackupTarFilesIncluded':False,'apkFilesIncluded':False}
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
record={'task':'RF-1114','accepted':True,'productUnchanged':True,'actualApi31AccountFrames':native,
 'finalNativeResults':v['results'],'cause':{'actionShiftCssPx':151.5,'oldRegionInkPixels':0,'newPositionBlockedByFab':True},
 'sourceFiles':proof['sourceFiles'],'apkFiles':proof['files'],'archiveIndexSha256':sha(out/'index.json'),
 'pendingExternalRunnerChangeBelongsTo':'RF-1113','RF1113Complete':False,'RF121Complete':False,
 'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'docs/verification'/(slug+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=p.read_text(encoding='utf-8')
s=s.replace('**292 / 304**；实际修复（已关闭）：292','**293 / 304**；实际修复（已关闭）：293').replace('暂缓：0；进行中：1；待执行：6。','暂缓：0；进行中：0；待执行：6。')
s=s.replace('| 304 | [RF-1114](#rf-1114) | P2 | 排查账户切换后原生操作采样时序 | 无（RF-1113完整冷启动红测发现） | [~] 进行中 |','| 304 | [RF-1114](#rf-1114) | P2 | 排查账户切换后原生操作采样时序 | 无（RF-1113完整冷启动红测发现） | [x] 完成 |')
s=re.sub(r'^- 当前处理：.*$', '- 当前处理：**RF-1114已完成：API31双模糊环境完整账户场景严格通过，原生触屏滚动、稳定帧、像素与命中检查保持。继续RF-1113完整冷启动及Windows剩余原生验证**。',s,flags=re.M)
s+='''
### RF-1114 账户操作原生采样绑定稳定布局（2026-10-10）

- 冻结输入两次完整冷启动在原生准备阶段失败；独立诊断账户支持组实测操作文字Y从440.5移至592 CSS px，旧采样区像素为0，真正位置被FAB覆盖。失败截图含生产备份提醒，降级诊断组完整通过，所有失败与恢复记录保留。
- 测试沿既有真实触屏手势将操作滚至FAB上方；仅在截图前后主题、正文及操作几何一致时取样。几何变化重新绘制，45秒等待上限保持，文字像素断言只执行一次；产品通知不关闭、不改定时器，不降低20像素、4.5对比度或点击命中要求。原手势默认路径保持。
- 最终专用API31/WebView91支持及降级完整accounts均原生OK(1 test)、严格外层exit0；各5次账户操作采样的像素、命中和稳定几何达标。两轮测试APK编译/badging/签名exit0，主APK逐字保持，完整私有内容/权限/链接及模糊、夜间、字体设置恢复。
- [结构化证据](verification/rf1114-account-frame-stability-2026-10-10.json)与原件索引保留实际来源、全部失败和当前账户快照；归档不含私有备份TAR或APK。外层正文色改动仍属于RF-1113，不随本项提交；RF-1113及完整平台矩阵保持未完成。
'''
p.write_text(s,encoding='utf-8',newline='\n')
start='### Android私有设备就绪与生成文件核对（2026-10-10）';end='### RF-1108 Android卡片截图等待原生绘制（2026-10-10）'
assert s.count(start)==s.count(end)==1
desired=s[:s.index(start)]+s[s.index(end):]
rows=[r for r in desired.splitlines() if re.match(r'^\| \d+ \| \[RF-\d+\]',r)]
assert len(rows)==304 and collections.Counter(re.search(r'\[([x!~ ])\]',r).group(1) for r in rows)=={'x':293,'!':5,' ':6}
name=p.relative_to(root).as_posix();head=subprocess.run(['git','show','HEAD:'+name],cwd=root,capture_output=True,check=True).stdout.decode()
assert subprocess.run(['git','diff','--cached','--name-only'],cwd=root,capture_output=True,check=True).stdout==b''
patch=''.join(difflib.unified_diff(head.splitlines(True),desired.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(base/'rf1114-report-stage.patch').write_text(patch,encoding='utf-8',newline='\n')
subprocess.run(['git','apply','--cached','--whitespace=error','-'],cwd=root,input=patch.encode(),check=True)
subprocess.run(['git','add','--',home,f'docs/verification/{slug}.json'],cwd=root,check=True)
subprocess.run(['git','add','-f','--',str(out.relative_to(root))],cwd=root,check=True)
expected={str(p.relative_to(root)).replace('\\','/'):sha(p) for p in out.rglob('*') if p.is_file()}
expected[home]=sha(root/home);expected[f'docs/verification/{slug}.json']=sha(root/'docs/verification'/(slug+'.json'))
names=subprocess.run(['git','diff','--cached','--name-only','-z'],cwd=root,capture_output=True,check=True).stdout.decode().strip('\0').split('\0')
assert set(names)==set(expected)|{name}
for n,d in expected.items():assert hashlib.sha256(subprocess.run(['git','show',':'+n],cwd=root,capture_output=True,check=True).stdout).hexdigest()==d,n
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
print(json.dumps({'accepted':True,'rawMembers':len(members),'stagedFiles':len(names),'scope':'RF-1114 only'}))
