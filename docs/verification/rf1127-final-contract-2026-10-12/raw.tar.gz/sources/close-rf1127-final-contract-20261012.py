from pathlib import Path
import hashlib,io,json,subprocess,tarfile
R=Path('D:/SoloSoul');W=Path(__file__).parent;S=W/'rf1127-final-closure-20261012'
N='rf1127-final-contract-2026-10-12';O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head.startswith('2ae69abc2')
new=load(R/'docs/verification/rf1133-surface-readiness-2026-10-12.json');assert new['accepted'] and len(new['matrix'])==4
assert all(g['samples']==3 and g['captureExitCode']==g['readerExitCode']==g['rendererExitCode']==0 for g in new['matrix'])
assert new['manuallyInspectedScreenshots']==12 and all(sha(R/n)==h for n,h in new['currentSourceFiles'].items())
assert new['cleanup']['preservedBytesVerified'] and new['cleanup']['identitiesChecked']==108
idx=load(R/'docs/verification/rf1133-surface-readiness-2026-10-12/index.json')
archive=R/'docs/verification'/new['archive']['path'];assert sha(archive)==new['archive']['sha256']
with tarfile.open(archive) as a:
 assert len(a.getmembers())==len(idx['members'])==741
 for row in idx['members']:
  data=a.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
historical=load(S/'historical-intervals.json');assert historical['newNativeRun'] is False and len(historical['rows'])==12
rejected=[r for r in historical['rows'] if not r['originalStrictAccepted']];assert len(rejected)==2
intervals=[row for g in new['matrix'] for row in g['preferenceIntervals']];assert len(intervals)==12
for row in intervals:
 interval=row['backend']['interval'];assert interval['theme']==1 and interval['allCompleted']
 assert interval['total']==row['transportAttempts'] and row['backend']['performanceMetrics'] is None
 assert row['backend']['laterAdded']['allCompleted']
assert not O.exists();O.mkdir();members={}
for p in S.iterdir():
 if p.is_file():members['historical-recheck/'+p.name]=p
for p in [Path(__file__),W/'rf1127-final-historical-intervals.mjs',R/'tauri/scripts/native-perf-preference-contract.mjs',R/'tauri/scripts/native-perf-preference.node.test.mjs']:
 members['sources/'+p.name]=p
rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz') as a:
 for name,p in sorted(members.items()):
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  a.addfile(info,io.BytesIO(data));rows.append({'member':name,'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(O/'raw.tar.gz') as a:
 for row in rows:
  data=a.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
put(O/'index.json',{'task':'RF-1127','allMembersReadbackVerified':True,'members':rows})
(O/'.gitattributes').write_text('raw.tar.gz -text\n',encoding='utf-8',newline='\n')
put(R/'docs/verification'/(N+'.json'),{'task':'RF-1127','accepted':True,'taskClosed':True,'commitCreated':False,'sourceHead':head,
 'acceptanceScope':'original strict theme interval plus finite later completion contract, actual same-GUI full four-cohort native journeys with complete window/pixel/theme/preference restoration',
 'contractAndTestsUnchangedSinceOriginalImplementation':True,'historicalNativeIntervalsReverified':12,
 'historicalStrictContractStillRejectsEarlyRunning':2,'historicalEvidenceIsNotNewNativeRun':True,
 'historicalOriginalFailuresUnmodified':True,'currentNativeThemeIntervals':intervals,
 'nativeReference':{'result':'rf1133-surface-readiness-2026-10-12.json','archivePath':new['archive']['path'],'sha256':new['archive']['sha256'],'membersReadbackVerified':741,
 'guiSha256':new['guiSha256'],'sameFrozenSourceInputs':1843,'cohorts':4,'samplesPerCohort':3,'manuallyInspected':12,'cleanup':new['cleanup']},
 'noNativeReRunOrSuccessSplicing':True,'RF1128Closed':False,'fullRF121Accepted':False,'performanceAccepted':False,
 'remaining':{'RF1128':'actual Windows file symlink regression remains unavailable in original token; full native reader matrix now passed'},
 'archive':{'path':N+'/raw.tar.gz','sha256':sha(O/'raw.tar.gz'),'members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'allMembersReadbackVerified':True}})
p=R/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';t=p.read_text(encoding='utf-8');assert '**311 / 323**' in t
row=next(x for x in t.splitlines() if x.startswith('| 317 |'));assert '[RF-1127]' in row
t=t.replace(row,row.replace('[!] 待原生验证','[x] 完成'),1)
line=next(x for x in t.splitlines() if x.startswith('- 已关闭：'))
t=t.replace(line,line.replace('311 / 323','312 / 323').replace('实际修复（已关闭）：311','实际修复（已关闭）：312')
 .replace('待验证/阻塞：6（RF-112、RF-121、RF-312、RF-1109、RF-1127、RF-1128）','待验证/阻塞：5（RF-112、RF-121、RF-312、RF-1109、RF-1128）'),1)
line=next(x for x in t.splitlines() if x.startswith('- 当前处理：'))
t=t.replace(line,'- 当前处理：RF-1133及RF-1127已按独立合同完成并分别提交。继续核对RF-1128真实文件符号链接的本地可执行路径，再推进RF-312 Android固定100/5000性能；完整多端/性能范围不缩小。',1)
line=next(x for x in t.splitlines() if x.startswith('| 318 |'));assert '[RF-1128]' in line
t=t.replace(line,line.replace('[!] 待符号链接及完整原生验证','[!] 待Windows文件符号链接回归（完整12次原生已验）'),1)
t+='''\n\n### RF-1127 后续完成合同独立关闭核验（2026-10-12，完成）\n\n- 基线 `2ae69abc2`。原实现合同与测试自2026-10-11逐字保持，当前Node回归已覆盖相关正反例；重新读取并核验历史真实12区间原始长度/SHA，再执行当前有限后续完成合同。原严格合同仍拒绝2个早期running区间，新合同对同一原件全部通过；历史证据不称新原生运行，失败原件不改写。\n- 同一新GUI `56d50e60abfeeee01be5e7cdb060e7906a6015cb9bea0ee6eeb56ab4d2fc2857` 的四组各3次完整native/capture/reader/renderer全部通过；6个深色样本共12个目标主题切换/恢复区间逐一核验目标theme恰好一次且完成、原前端总数与后端增量相同、不可变前缀/后续完成及背景类别独立保留。12张像素人工检查、原偏好/主题/侧栏和窗口恢复、108身份与96缓存/12联接精确清理已由RF-1133原件证明；独立再次回读全部741成员，不拼接旧成功子集或重跑已通过同一矩阵。\n- [独立关闭记录](verification/rf1127-final-contract-2026-10-12.json)与其原件包含历史合同重验/源及完整新矩阵引用；原严格合同、时钟、身份、预算保持。仅关闭RF-1127，独立本地提交、不推送；**312/323关闭、5待验证、6待执行**。RF-1128真实Windows文件symlink仍未验，RF-112/121/312/1109及RF-122～127前置范围保持，goal active。\n'''
p.write_text(t,encoding='utf-8',newline='\n')
print(json.dumps({'task':'RF-1127','accepted':True,'historicalIntervals':12,'strictRejected':2,'currentNativeThemeIntervals':12,'closureArchiveMembers':len(rows)}))
