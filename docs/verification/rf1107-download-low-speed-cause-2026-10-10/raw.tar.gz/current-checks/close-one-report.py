from pathlib import Path
import json, sys

root = Path('D:/SoloSoul')
task = sys.argv[1]
assert task in {'RF-1107','RF-1106'}
is_download = task == 'RF-1107'
slug = 'rf1107-download-low-speed-cause-2026-10-10' if is_download else 'rf1106-preference-write-checkpoint-2026-10-10'
record = json.loads((root/'docs/verification'/f'{slug}.json').read_text(encoding='utf-8'))
assert record['accepted'] and record['archive']['readbackAllMembersVerified'] and not record['rf1105Closed']
old_closed,old_progress = (285,3) if is_download else (286,2)
closed,progress = old_closed+1,old_progress-1
p = root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md'
s = p.read_text(encoding='utf-8-sig')
counter = f'- 已关闭：**{old_closed} / 297**；实际修复（已关闭）：{old_closed}；排除：0；待验证/阻塞：3（RF-112、RF-121、RF-312）；暂缓：0；进行中：{old_progress}；待执行：6。'
assert s.count(counter) == 1
s = s.replace(counter,counter.replace(f'{old_closed} / 297',f'{closed} / 297').replace(f'实际修复（已关闭）：{old_closed}',f'实际修复（已关闭）：{closed}').replace(f'进行中：{old_progress}',f'进行中：{progress}'))
lines = s.splitlines(keepends=True)
row_count = 0
for i,line in enumerate(lines):
    if f'[{task}](#' in line and line.startswith('| '):
        assert '[~] 进行中' in line
        lines[i] = line.replace('[~] 进行中','[x] 完成'); row_count += 1
assert row_count == 1
lines[2] = f'> 最后更新：2026-10-10（{task}实际回归验证关闭；RF-1105待新GUI和重启采样，RF-112/121/312保持待验证）\n'
status = ('RF-1107已验证并按独立提交处理；RF-1106缓存准入回归完整检查通过、待单独归档提交；RF-1105保留，后续继续新构建与两档重启采样。' if is_download else 'RF-1107/1106均已验证并分项提交；RF-1105继续新GUI Release和两档各五组同目录重启。')
lines = [f'- 当前处理：**{status}Windows完整材质矩阵、Android当前包原生回归及RF-112/121/312与后续前置保持未完成**。\n' if line.startswith('- 当前处理：') else line for line in lines]
s = ''.join(lines)
totals = record['checks']['rf1107-default-workspace']['testTotals']
description = ('更新下载回归直接验证低速拒绝原因' if is_download else '实际缓存写入回归等待 worker 准入')
details = ('原完整默认检查退出101，Tauri lib 789通过/1失败；下载已返回成功，失败仅发生在完整耗时小于1秒的断言。旧失败原文和对应来源完整保留。既有真实本机测试先直接调用实际流式传输，精确断言“下载源持续低速”而非停流，检查非空且未完成的正确缓存前缀；随后保留原自动换源、备用源从非零Range续传和完整包内容断言。生产代码前缀逐字保持，超时、速度阈值、安装和验签行为未改。' if is_download else 'RF-1105原完整默认检查退出101，Tauri lib 789通过/1失败；owner引用升级和10ms等待不能证明worker已经取得活动许可。只在cfg(test)加入实际准入后的通知，原五秒等待上限、文件锁阻塞时缓存逐字不变、实际写后内容正确和最终维护可准入均保持；剥离三个测试专用代码块后，产品代码前缀规范化文本一致。第二次完整检查中该回归已通过，但遇到另一个下载计时断言失败；两次完整失败都保留，RF-1107独立修复后再以当前来源运行整轮检查。')
targeted = record['checks']['rf1107-download-tests']['testTotals']['passed']
checks_text = f'格式、默认/非默认严格Clippy均通过；真实更新下载{targeted}项、非默认原生诊断121项及偏好15项通过。完整默认workspace实际为{totals["passed"]}通过、0失败、{totals["ignored"]}既有ignored。当前整轮结果绑定六个修改文件与1830项来源；RF-1105四文件修复保持，仍等待新构建和原生采样，不把当前测试通过当作历史首页根因证明。'
if not is_download:
    checks_text += '默认偏好定向15项沿用本阶段已执行的相同五文件SHA结果，明确标记未重新执行；当前完整默认检查也覆盖这些用例。'
s += f'\n### {task} {description}（2026-10-10）\n\n- {details}\n- {checks_text}\n- [结构化证据](verification/{slug}.json)及[原件索引](verification/{slug}/index.json)归档并逐成员回读验证。本项一修复一提交，累计{closed}/297、{progress}项进行中、3待验证、6待执行。未推送，整体goal保持active。\n'
p.write_text(s,encoding='utf-8',newline='\n')
readme_name = 'RF-1107-download-low-speed-cause.md' if is_download else 'RF-1106-preference-write-checkpoint.md'
with (root/'docs/verification'/readme_name).open('x',encoding='utf-8',newline='\n') as out:
    out.write(f'# {task} {description}\n\n{details}\n\n{checks_text}\n\n见[结构化证据]({slug}.json)和[全部原件索引]({slug}/index.json)。本项独立提交，不推送；RF-1105与RF-112/121/312保持未完成。\n')
print(f'{task} report closed only after real checks and archive: {closed}/297; {progress} remain in progress')
