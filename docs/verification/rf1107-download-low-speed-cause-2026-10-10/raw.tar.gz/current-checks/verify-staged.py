from pathlib import Path
import collections, hashlib, io, json, re, subprocess, sys, tarfile

root = Path('D:/SoloSoul')
task = sys.argv[1]
assert task in {'RF-1107','RF-1106'}
is_download = task == 'RF-1107'
slug = 'rf1107-download-low-speed-cause-2026-10-10' if is_download else 'rf1106-preference-write-checkpoint-2026-10-10'
base = 'docs/verification/'+slug
source = 'tauri/src-tauri/src/commands/'+('update_download.rs' if is_download else 'update_preferences.rs')
readme = 'RF-1107-download-low-speed-cause.md' if is_download else 'RF-1106-preference-write-checkpoint.md'
sha = lambda b: hashlib.sha256(b).hexdigest()
def staged(name): return subprocess.run(['git','show',':'+name],cwd=root,check=True,capture_output=True).stdout
expected = {'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md', source,
    'docs/verification/'+readme, base+'.json',base+'/.gitattributes',base+'/index.json',base+'/raw.tar.gz'}
actual = set(subprocess.run(['git','diff','--cached','--name-only'],cwd=root,check=True,capture_output=True,text=True).stdout.splitlines())
assert actual == expected, actual
index = json.loads(staged(base+'/index.json'))
archive = staged(base+'/raw.tar.gz')
assert sha(archive) == index['archiveSha256']
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
    members = {i.name:tar.extractfile(i).read() for i in tar.getmembers() if i.isfile()}
assert len(members) == index['memberCount']
for entry in index['members']:
    assert len(members[entry['path']]) == entry['bytes']
    assert sha(members[entry['path']]) == entry['sha256']
assert members['source-after/'+source] == staged(source)
record = json.loads(staged(base+'.json'))
assert record['accepted'] and not record['rf1105Closed']
for receipt in record['checks'].values(): assert receipt['exitCode'] == 0 and receipt['sourceUnchanged']
report = staged('docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md').decode('utf-8-sig')
rows = re.findall(r'^\| \d+ \| \[(RF-\d+)\].*$',report,re.M)
cards = re.findall(r'^### (RF-\d+)\s*$',report,re.M)
assert len(rows) == len(set(rows)) == len(cards) == len(set(cards)) == 297
assert set(rows) == set(cards)
statuses = collections.Counter()
for line in report.splitlines():
    if re.match(r'^\| \d+ \| \[RF-\d+\]',line): statuses[re.search(r'\[([x!~ ])\]',line)[1]] += 1
assert statuses == {'x':286 if is_download else 287, '!':3, '~':2 if is_download else 1, ' ':6}, statuses
print(f'{task}: exact seven staged files, {len(members)} archive members and 297 task cards verified; separate fixes not staged')
