from pathlib import Path
import hashlib, json

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
s = (root/'build/rf1106-preference-write-checkpoint-20261010/run-check.py').read_text()
old = "'tauri/src-tauri/src/commands/update_preferences.rs']"
assert s.count(old) == 1
s = s.replace(old, "'tauri/src-tauri/src/commands/update_preferences.rs','tauri/src-tauri/src/commands/update_download.rs']")
helper = stage/'run-check.py'
if helper.exists(): assert helper.read_text(encoding='utf-8') == s
else:
    with helper.open('x', encoding='utf-8') as out: out.write(s)
before = (stage/'update_download.before.rs').read_text(encoding='utf-8')
after = (root/'tauri/src-tauri/src/commands/update_download.rs').read_text(encoding='utf-8')
marker = '#[cfg(test)]\nmod tests {'
assert before.split(marker)[0] == after.split(marker)[0]
with (stage/'production-parity.json').open('x', encoding='utf-8') as out:
    json.dump({'task':'RF-1107', 'productPrefixUnchanged':True,
        'existingIntegrationAssertionsPreserved':True, 'exactRejectionCause':'下载源持续低速',
        'timeoutsAndSpeedThresholdsUnchanged':True,
        'sourceAfterSha256':hashlib.sha256((root/'tauri/src-tauri/src/commands/update_download.rs').read_bytes()).hexdigest()},out,indent=2)
