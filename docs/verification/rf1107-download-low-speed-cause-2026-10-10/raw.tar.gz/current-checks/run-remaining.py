from pathlib import Path
import hashlib, json, subprocess, sys, time

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = load(stage/'sources-before.json')
sources = {name:sha(root/name) for name in before}
assert {name for name in before if before[name] != sources[name]} == {'tauri/src-tauri/src/commands/update_download.rs'}
with (stage/'sources-final.json').open('x', encoding='utf-8') as out: json.dump(sources, out, indent=2)
deadline = time.monotonic()+1800
receipt_path = stage/'rf1107-download-tests.receipt.json'
while not receipt_path.exists():
    assert time.monotonic()<deadline, 'targeted check receipt not available'
    time.sleep(5)
targeted = load(receipt_path)
assert targeted['exitCode'] == 0 and targeted['sourceUnchanged'], targeted
tracked = targeted['sourceFiles']
def verify():
    for name,digest in tracked.items(): assert sha(root/name) == digest, name

jobs = [
    ('rf1107-default-workspace', ['cargo','test','--locked','--workspace']),
    ('rf1107-clippy-default', ['cargo','clippy','--locked','--all-targets','--','-D','warnings']),
    ('rf1107-clippy-native', ['cargo','clippy','--locked','--features','native-perf','--all-targets','--','-D','warnings']),
    ('rf1107-native-regression', ['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','native_perf::','--','--nocapture']),
    ('rf1107-native-preferences', ['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','commands::update_preferences::tests','--','--nocapture']),
]
for name,command in jobs:
    verify()
    code = subprocess.call([sys.executable,'-X','utf8',str(stage/'run-check.py'),name,*command],cwd=root)
    assert code == 0, (name,code)
    verify()
for name,digest in sources.items(): assert sha(root/name) == digest, name
print('Current source full default, strict checks, native regression and preferences all passed',flush=True)
