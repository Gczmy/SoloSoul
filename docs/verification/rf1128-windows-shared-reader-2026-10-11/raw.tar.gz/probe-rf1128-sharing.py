from pathlib import Path
import ctypes,json,hashlib
from ctypes import wintypes as t
B=Path('D:/SoloSoul/build/rf1128-owned-json-sharing-20261011');B.mkdir(exist_ok=False)
p=B/'published.json';raw=b'{"publicSynthetic":true}\n';p.write_bytes(raw)
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.CreateFileW.argtypes=[t.LPCWSTR,t.DWORD,t.DWORD,t.LPVOID,t.DWORD,t.DWORD,t.HANDLE];k.CreateFileW.restype=t.HANDLE
k.ReadFile.argtypes=[t.HANDLE,t.LPVOID,t.DWORD,ctypes.POINTER(t.DWORD),t.LPVOID];k.ReadFile.restype=t.BOOL
k.CloseHandle.argtypes=[t.HANDLE];k.CloseHandle.restype=t.BOOL
INVALID=ctypes.c_void_p(-1).value
holder=k.CreateFileW(str(p),0x80000000|0x10000,7,None,3,0x80,None)
assert holder!=INVALID,ctypes.get_last_error()
facts={'probeOnly':True,'originalNativeCauseProven':False,'fixtureSha256':hashlib.sha256(raw).hexdigest(),'holderRequestsReadAndDelete':True,'holderSharesReadWriteDelete':True}
try:
 try:
  p.read_bytes();facts['pythonDefaultReadSucceeded']=True
 except OSError as e:
  facts.update(pythonDefaultReadSucceeded=False,pythonErrno=e.errno,pythonWinerror=getattr(e,'winerror',None))
 reader=k.CreateFileW(str(p),0x80000000,7,None,3,0x80,None);assert reader!=INVALID,ctypes.get_last_error()
 try:
  buf=ctypes.create_string_buffer(256);length=t.DWORD()
  assert k.ReadFile(reader,buf,256,ctypes.byref(length),None),ctypes.get_last_error()
  assert buf.raw[:length.value]==raw;facts['sharedReadVerifiedBytes']=True
 finally:assert k.CloseHandle(reader)
finally:assert k.CloseHandle(holder)
assert p.read_bytes()==raw
facts['afterHolderClosedDefaultReadSucceeded']=True
(B/'probe.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8')
p.unlink()
facts['privateProbeFixtureRemoved']=not p.exists()
(B/'probe.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8')
print(json.dumps(facts))
