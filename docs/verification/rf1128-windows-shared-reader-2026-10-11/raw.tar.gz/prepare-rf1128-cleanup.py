from pathlib import Path
import json,hashlib
W=Path(__file__).parent.resolve();S=W/'rf1128-shared-reader-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
done=load(S/'cohorts-complete.json');assert done['accepted'] and len(done['rows'])==4
groups=[]
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
 c=W/('ss-rf121-composed-window-restore-'+mode+'-shared-20261011')
 receipt=load(c/'actual100.receipt.json');assert receipt['exitCode']==0 and receipt['sourceUnchanged'] and receipt['resourcesUnchanged']
 journey=load(c/'actual100/native-perf-sdk-journey-results.json');assert journey['success'] and not journey['interrupted'] and len(journey['samples'])==3
 verification=load(c/'validation.json');assert verification['accepted'] and len(verification['samples'])==3
 samples=[]
 for row in journey['samples']:
  root=c/'actual100'/f"sample-{row['index']:03}";owned=load(root/'native-perf-owned.json');consumed=load(root/'native-perf-consumed.json')
  assert owned==row['owned'] and owned['runId']==consumed['runId'] and consumed['pid']==row['processId']
  assert Path(owned['root']).samefile(root) and owned['identifier']=='com.solosoul.rf312perf.'+owned['runId']
  identities=[{'pid':p['pid'],'creationMs':p['creationMs']} for p in row['beforeSnapshot']['processes']+row['afterSnapshot']['processes']]
  assert len(identities)>=9
  samples.append({'index':row['index'],'runId':owned['runId'],'pid':row['processId'],'recordedIdentities':identities})
 groups.append({'label':mode,'captureRoot':str(c),'terminal':True,'samples':samples,'terminalReceiptSha256':sha(c/'actual100.receipt.json')})
with (W/'rf1128-cache-cleanup-plan.json').open('x',encoding='utf-8') as f:json.dump({'cacheCleanupEligible':True,'failedSamplesAccepted':False,'groups':groups,'plannedExactCacheTargets':96,'freshCimRequired':True},f,indent=2)
text=(W/'window-restore-cleanup-owned.ps1').read_text(encoding='utf-8')
text=text.replace('window-restore-cache-cleanup','rf1128-cache-cleanup').replace('groups.Count -ne 6','groups.Count -ne 4')
text=text.replace('Six terminal owned groups required for cleanup only; failures are not accepted','Four terminal independently verified groups required')
text=text.replace('targets.Count -ne 144','targets.Count -ne 96').replace('Count -ne 144','Count -ne 96').replace('Exact 144 owned cache paths required','Exact 96 owned cache paths required')
text=text.replace('application-logs-window-restore','application-logs-rf1128-shared').replace("task='RF-121'","task='RF-1128'")
with (W/'rf1128-cleanup-owned.ps1').open('x',encoding='utf-8') as f:f.write(text)
print('Four terminal verified groups bound to96 exact cache paths; cleanup still requires fresh identities')
