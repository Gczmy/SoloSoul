from pathlib import Path
import hashlib, io, json, os, shutil, tarfile
R=Path('D:/SoloSoul'); W=Path(__file__).parent.resolve(); S=W/'rf1128-shared-reader-20261011'; B=R/'build/rf1128-owned-json-sharing-20261011'
N='rf1128-windows-shared-reader-2026-10-11'; O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
assert not O.exists()
cleanup=load(W/'rf1128-cache-cleanup.json')
assert cleanup['matchingOwnedIdentitiesLive']==cleanup['processesTerminatedByThisTool']==0
assert len(cleanup['removedCachePaths'])==96 and cleanup['preservedBytesVerified']
assert all(not os.path.lexists(p) for p in cleanup['removedCachePaths'])
assert not load(S/'cohorts-complete.json')['accepted']
for name,digest in load(S/'sources.json').items():assert sha((R/name).read_bytes())==digest
for name,digest in load(S/'tools.json').items():assert sha((R/name).read_bytes())==digest
old=load(W/'rf1123-native-build-20261011/sources.json'); previous=load(W/'rf1127-settlement-retry1-20261011/sources.json'); current=load(S/'sources.json')
changed=[name for name,digest in old.items() if current.get(name)!=digest]
added=[name for name in current if name not in previous]
assert len(old)==len(previous)==1837 and len(current)==1839 and len(changed)==4 and len(added)==2
assert all(current[name]==digest for name,digest in previous.items())
put(S/'reuse-manifest-clarification.json',{'originalGuiBuildManifest':str(W/'rf1123-native-build-20261011/sources.json'),'previousRF1127Manifest':str(W/'rf1127-settlement-retry1-20261011/sources.json'),'currentManifest':str(S/'sources.json'),'originalAndPreviousCountsBoth1837ButBytesDiffer':True,'fourHistoricalNonGuiDifferences':changed,'twoAddedExternalPythonSources':added,'applicationRecompiled':False,'allPreviouslyFrozenInputsUnchanged':True})
O.mkdir(); members={}; allowed={'.json','.log','.py','.mjs','.ps1','.png','.bgra'}
def add(p,n=None):
 assert p.is_file() and not(p.stat().st_file_attributes&0x400) and p.suffix in allowed
 n=n or p.relative_to(W).as_posix(); assert n not in members; members[n]=p
def files(d):
 assert d.is_dir() and not(d.stat().st_file_attributes&0x400)
 for p in d.iterdir():
  if p.is_file() and p.suffix in allowed:add(p)
groups=[]; visuals=[]; nativePassed=0; capturePassed=0
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
 g=W/('ss-rf121-composed-window-restore-'+mode+'-shared-20261011'); files(g); files(g/'actual100')
 journey=load(g/'actual100/native-perf-sdk-journey-results.json'); capture=load(g/'capture-results.json')
 nativePassed+=sum(x['success'] for x in journey['samples']); capturePassed+=sum(x['success'] for x in capture['samples'])
 groups.append({'scene':mode,'nativeJourneyExitCode':load(g/'actual100.receipt.json')['exitCode'],'nativeSuccessfulSamples':sum(x['success'] for x in journey['samples']),'captureAccepted':capture['success'],'captureSuccessfulSamples':sum(x['success'] for x in capture['samples']),'readerAccepted':load(g/'validation.json')['accepted'] if (g/'validation.json').exists() else None,'captureFailures':[{'index':x['index'],'category':x.get('errorCategory'),'error':x.get('error'),'errno':x.get('errno'),'winerror':x.get('winerror')} for x in capture['samples'] if not x['success']]})
 for i in range(1,4):
  files(g/'actual100'/f'sample-{i:03}'); files(W/'application-logs-rf1128-shared'/mode/'100'/f'sample-{i:03}')
 if mode!='dark-collapsed':
  p=g/'surface-sample-001.png'; shutil.copyfile(p,O/(mode+'.png'))
  visuals.append({'source':str(p),'sha256':sha(p.read_bytes()),'humanReviewed':True,'scope':'one frame from a complete accepted group; no full material approval'})
assert nativePassed==11 and capturePassed==9
failure=load(W/'ss-rf121-composed-window-restore-dark-collapsed-shared-20261011/actual100/sample-001/native-perf-surface-appearance-result.json')
assert failure['captureError'] is None and failure['restoreError']=='appearance-scene-transition-invalid' and not failure['success']
put(S/'visual-review.json',{'frames':visuals,'allOtherFramesHumanReviewClaimed':False,'darkCollapsedReviewed':False})
files(S)
for p in W.iterdir():
 if p.is_file() and p.suffix in allowed and ('rf1128' in p.name or p.name=='window-restore-contract.mjs'):add(p)
for p in [B/'probe.json',*list((B/'checks').glob('*.log')),*list((B/'checks').glob('*.json'))]:add(p,'rf1128-isolated/'+p.relative_to(B).as_posix())
for n in ['native-perf-owned-json.py','test_native_perf_owned_json.py','native-perf-preference-contract.mjs','native-perf-preference.node.test.mjs','native-perf-run.mjs','native-perf-sdk-journey.mjs','native-perf-auth-contract.mjs','native-perf-maintenance-contract.mjs']:
 add(R/'tauri/scripts'/n,'repository/tauri/scripts/'+n)
for n in ['sources.json','runtime-package.json']:add(W/'rf1123-native-build-20261011'/n)
add(W/'rf1127-settlement-retry1-20261011/sources.json')
rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as archive:
 for n,p in sorted(members.items()):
  data=p.read_bytes(); info=tarfile.TarInfo(n); info.size=len(data); info.mode=0o644
  archive.addfile(info,io.BytesIO(data)); rows.append({'member':n,'source':str(p),'bytes':len(data),'sha256':sha(data)})
with tarfile.open(O/'raw.tar.gz') as archive:
 assert len(archive.getmembers())==len(rows)
 for row in rows:
  data=archive.extractfile(row['member']).read(); assert len(data)==row['bytes'] and sha(data)==row['sha256']
put(O/'index.json',{'task':'RF-1128','members':rows,'allMembersReadbackVerified':True,'wholeMatrixAccepted':False,'excluded':['physical Vault','EXE/DLL/models','cache trees'],'unusedPositiveCleanupPreparer':'prepare-rf1128-cleanup.py'})
shutil.copyfile(W/'rf1128-cache-cleanup.json',O/'cleanup.json')
(O/'.gitattributes').write_text('raw.tar.gz -text\n*.png -text\n',encoding='utf-8')
put(R/'docs/verification'/(N+'.json'),{'task':'RF-1128','sourceHead':'a5d59af12','status':'implementation-validated-partially-awaiting-file-symlink-and-full-native-matrix','closed':False,'applicationChanged':False,'applicationRecompiled':False,'sourceFiles':1839,'resources':94,'guiSha256':load(S/'windows-build-reuse-proof.json')['guiSha256'],'unit':{'cases':11,'passed':10,'failed':0,'skipped':1,'newSkip':'actual file symlink fixture: WinError1314; missing privilege; not counted as passed','initialFailedRunPreserved':True,'actualExclusiveError':32,'actualEmptyDaclError':5,'fixtureAclRestoredExactly':True},'native':{'requestedSamples':12,'journeysPassed':11,'captureSamplesAccepted':9,'completeGroupsAccepted':3,'wholeMatrixAccepted':False,'groups':groups,'darkCollapsedFirstSample':failure,'restoreFailurePairAvailable':False,'uniqueRestoreCauseProven':False,'failedSubsetAccepted':False,'noReadErrorRetries':True,'budgetsUnchanged':True},'oldFailuresUnmodified':True,'originalSharingErrorsUniqueCauseProven':False,'visualReview':visuals,'fullRF121Accepted':False,'performanceAccepted':False,'cleanup':{'identitiesChecked':cleanup['identitiesChecked'],'pathsRemoved':96,'linksUnlinked':len(cleanup['linksUnlinked']),'preservedFiles':len(cleanup['preservedVaultAndRootFiles']),'processesTerminated':0,'preservedBytesVerified':True},'archive':{'path':N+'/raw.tar.gz','members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha((O/'raw.tar.gz').read_bytes()),'allMembersReadbackVerified':True}})
print(json.dumps({'members':len(rows),'nativeJourneysPassed':nativePassed,'captureSamplesAccepted':capturePassed,'closed':False}))
