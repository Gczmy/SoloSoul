from pathlib import Path
import json,hashlib,shutil
R=Path('D:/SoloSoul');W=Path(__file__).parent.resolve();S=W/'rf1128-shared-reader-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not S.exists();S.mkdir()
old=load(W/'rf1127-settlement-retry1-20261011/sources.json')
assert all(sha(R/n)==h for n,h in old.items())
source=dict(old)
for n in ['tauri/scripts/native-perf-owned-json.py','tauri/scripts/test_native_perf_owned_json.py']:source[n]=sha(R/n)
(S/'sources.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
for n in ['caption-runtime-package.json','restore-helper.json']:shutil.copyfile(W/'rf1127-settlement-retry1-20261011'/n,S/n)
(S/'windows-build-reuse-proof.json').write_text(json.dumps({'applicationRecompiled':False,'originalSourceFiles':1837,'currentSourceFiles':1839,
 'oldInputsUnchanged':True,'onlyAddedSources':['external Python reader','external Python tests'],'guiCompiledInputsUnchanged':True,
 'guiSha256':'d77e575287c7d18f6124a7aa42cfa56f0ba20625d8b00309c1e7d2c07355da74'},indent=2)+'\n',encoding='utf-8')
names=[('run-rf1127-retry1.py','run-rf1128-shared.py'),('verify-rf1127-retry1.mjs','verify-rf1128-shared.mjs'),('render-rf1127-retry1.py','render-rf1128-shared.py'),('run-rf1127-cohorts-retry1.py','run-rf1128-cohorts.py')]
tools={}
for a,b in names:
 text=(W/a).read_text(encoding='utf-8').replace('rf1127-settlement-retry1-20261011','rf1128-shared-reader-20261011').replace('-settled-retry1-20261011','-shared-20261011')
 for x,y in names:text=text.replace(x,y)
 if a=='run-rf1127-retry1.py':
  text=text.replace('import datetime,','import importlib.util\nimport datetime,',1)
  needle="root = Path('D:/SoloSoul')"
  assert needle in text
  text=text.replace(needle,needle+"\nreader_spec=importlib.util.spec_from_file_location('owned_json',root/'tauri/scripts/native-perf-owned-json.py')\nowned_json=importlib.util.module_from_spec(reader_spec)\nreader_spec.loader.exec_module(owned_json)",1)
  needle='    return load(path)'
  assert text.count(needle)==1;text=text.replace(needle,'    return owned_json.read_owned_json(path, maximum)',1)
 if a=='verify-rf1127-retry1.mjs':text=text.replace('sourceFiles:1837','sourceFiles:1839')
 if a=='run-rf1127-cohorts-retry1.py':
  text=text.replace('rf1127-session-preflight-retry1.py','rf1128-session-preflight.py').replace("'rf1127-session-retry1-'+mode+'.py'","'rf1128-session-'+mode+'.py'")
 p=W/b;p.write_text(text,encoding='utf-8');tools[str(p.relative_to(R))]=sha(p)
p=W/'rf1128-session-preflight.py';p.write_text((W/'rf1127-session-preflight-retry1.py').read_text(encoding='utf-8').replace('rf1127-settlement-retry1-20261011','rf1128-shared-reader-20261011'),encoding='utf-8')
for p in [p,W/'window-restore-contract.mjs',Path(__file__),R/'tauri/scripts/native-perf-owned-json.py',R/'tauri/scripts/test_native_perf_owned_json.py']:tools[str(p.relative_to(R))]=sha(p)
(S/'tools.json').write_text(json.dumps(tools,indent=2)+'\n',encoding='utf-8')
print('1839 sources frozen; no GUI change, no JSON retries; four fresh groups prepared')
