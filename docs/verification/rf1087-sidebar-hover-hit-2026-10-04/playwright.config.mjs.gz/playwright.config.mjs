import { defineConfig, devices } from "file:///C:/Users/40299571/SoloSoul/tauri/node_modules/%40playwright/test/index.mjs";

export default defineConfig({
  testDir: "C:/Users/40299571/SoloSoul/tauri/e2e",
  outputDir: "C:/Users/40299571/AppData/Local/Temp/ss-rf1087-hover-hit-20261003/test-results",
  testIgnore: ['**/production-startup.spec.ts', '**/*.production.spec.ts'],
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'list',
  use: {
    baseURL: 'http://localhost:20091',
    // 本机可复用已安装的 Chrome/Edge；CI 默认仍使用 Playwright Chromium。
    channel: process.env.SOLOSOUL_E2E_CHANNEL || undefined,
    trace: 'on-first-retry',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'mobile',
      use: {
        viewport: { width: 390, height: 844 },
        hasTouch: true,
        isMobile: true,
      },
    },
  ],
  webServer: {
    command: 'npm run dev -- --port 20091 --strictPort',
    cwd: "C:/Users/40299571/SoloSoul/tauri",
    url: 'http://localhost:20091',
    reuseExistingServer: false,
    timeout: 120 * 1000,
  },
});
