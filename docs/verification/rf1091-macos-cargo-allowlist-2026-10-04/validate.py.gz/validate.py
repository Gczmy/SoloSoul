import json,os,platform,subprocess,time,tomllib,zipfile,copy,hashlib
from pathlib import Path
ROOT=Path(r'C:\Users\40299571\SoloSoul');T=Path(__file__).parent;cases=[]
code=(T/'prepare-exact.py').read_text();original=(T/'manifest-before.toml').read_bytes();config=(ROOT/'tauri/src-tauri/tauri.macos.conf.json').read_bytes()
runner='import platform;platform.system=lambda:"Darwin"\n'+code
base=tomllib.loads(original.decode());features_before=set(base['dependencies']['tauri']['features'])|set(base['target']['cfg(target_os = "macos")']['dependencies']['tauri']['features'])
assert base['dependencies']['tauri']['features']==[] and 'macos-private-api' in features_before
for name,source,cfg,script,should_pass in [
 ('real-manifest',original,config,runner,True),
 ('off-platform-refused',original,config,code,False),
 ('disabled-platform-config-refused',original,json.dumps({'app':{'macOSPrivateApi':False}}).encode(),runner,False),
 ('version-drift-refused',original.replace(b'tauri = { version = "2", features = [] }',b'tauri = { version = "3", features = [] }',1),config,runner,False),
 ('target-feature-missing-refused',original.replace(b'features = ["macos-private-api"]',b'features = []',1),config,runner,False),
 ('declaration-drift-refused',original.replace(b'tauri = { version = "2", features = [] }',b'tauri = { version = "2",\nfeatures = [] }',1),config,runner,False),
 ('other-common-features-preserved',original.replace(b'tauri = { version = "2", features = [] }',b'tauri = { version = "2", features = ["tray-icon"] }',1),config,runner,True),
 ]:
 folder=T/name;(folder/'src-tauri').mkdir(parents=True);p=folder/'src-tauri/Cargo.toml';p.write_bytes(source);(folder/'src-tauri/tauri.macos.conf.json').write_bytes(cfg)
 c=subprocess.run(['python','-X','utf8','-c',script],cwd=folder,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(T/(name+'.log')).write_bytes(c.stdout)
 assert (c.returncode==0)==should_pass
 if not should_pass:assert p.read_bytes()==source
 else:
  before=tomllib.loads(source.decode());after=tomllib.loads(p.read_text());expected=copy.deepcopy(before);expected['dependencies']['tauri']['features']=list(dict.fromkeys([*before['dependencies']['tauri']['features'],'macos-private-api']));assert after==expected
  assert set(before['dependencies']['tauri']['features'])|set(before['target']['cfg(target_os = "macos")']['dependencies']['tauri']['features'])==set(after['dependencies']['tauri']['features'])|set(after['target']['cfg(target_os = "macos")']['dependencies']['tauri']['features'])
  prepared=p.read_bytes();again=subprocess.run(['python','-X','utf8','-c',runner],cwd=folder,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert again.returncode==0 and p.read_bytes()==prepared
 cases.append({'name':name,'exit':c.returncode,'expected_pass':should_pass,'bytes_unchanged_when_refused':not should_pass,'enabled_features_unchanged_when_prepared':should_pass,'idempotent_when_prepared':should_pass})
result={'cases':cases,'original_upstream_global_feature_check':'fails: macos-private-api missing','prepared_upstream_global_feature_check':'passes: existing target feature mirrored','before_enabled_macos_features':sorted(features_before),'after_enabled_macos_features':sorted(features_before),'limits':['Windows structural cases impersonate Darwin only within isolated Python process, not actual Mac Cargo compilation.']}
(T/'isolation-cases.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
# Real Cargo resolver comparison for the same Mac target, no compilation or target SDK claim.
git=['git','-c','safe.directory='+ROOT.as_posix()];archive=T/'source.zip';subprocess.run(git+['archive','--format=zip','--output='+str(archive),'HEAD','tauri'],cwd=ROOT,check=True)
checkout=T/'checkout';checkout.mkdir()
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for i in z.infolist():
  p=(checkout/i.filename).resolve();assert p.is_relative_to(checkout.resolve()) and not i.filename.startswith(('/','\\'))
 z.extractall(checkout)
wd=checkout/'tauri';results=[];metadata=[]
for stage in ['before','after']:
 if stage=='after':
  c=subprocess.run(['python','-X','utf8','-c',runner],cwd=wd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(T/'prepare-checkout.log').write_bytes(c.stdout);assert c.returncode==0
 with (T/(stage+'-metadata.json')).open('wb') as out,(T/(stage+'-metadata.log')).open('wb') as err:
  start=time.monotonic();c=subprocess.run(['cargo','+1.99.0','metadata','--locked','--format-version','1','--filter-platform','aarch64-apple-darwin'],cwd=wd,stdout=out,stderr=err);results.append({'stage':stage,'exit':c.returncode,'seconds':time.monotonic()-start})
 (T/'metadata-checks.json').write_text(json.dumps(results,indent=2)+'\n');assert c.returncode==0
 metadata.append(json.loads((T/(stage+'-metadata.json')).read_text()))
assert metadata[0]['resolve']==metadata[1]['resolve']
assert (wd/'Cargo.lock').read_bytes()==(ROOT/'tauri/Cargo.lock').read_bytes()
resolved={'actual_cargo_version':'1.99.0','target':'aarch64-apple-darwin','resolved_dependency_graph_identical':True,'tauri_nodes':[{'id':n['id'],'features':n['features']} for n in metadata[0]['resolve']['nodes'] if n['id'].split('#')[-1].startswith('tauri@')],'locked_file_unchanged':True,'commands':results,'limits':'Resolver proof is not Mac SDK compilation.'}
(T/'resolved-feature-graph.json').write_text(json.dumps(resolved,indent=2)+'\n');print(json.dumps(resolved),flush=True)
