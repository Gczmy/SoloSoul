from pathlib import Path
import subprocess,json,time,hashlib,zipfile
T=Path(__file__).parent;wd=T/'checkout/tauri';lock=wd/'Cargo.lock';baseline_lock=lock.read_bytes();raw_archive=zipfile.ZipFile(T/'source.zip').read('tauri/Cargo.lock');assert baseline_lock.decode().splitlines()==raw_archive.decode().splitlines()
(wd/'src-tauri/Cargo.toml').write_bytes((T/'manifest-before.toml').read_bytes());code='import platform;platform.system=lambda:"Darwin"\n'+(T/'prepare-exact.py').read_text();results=[];metadata=[]
for name in ['before-repeat','after-repeat']:
 if name=='after-repeat':
  c=subprocess.run(['python','-X','utf8','-c',code],cwd=wd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert c.returncode==0
 with (T/(name+'-metadata.json')).open('wb') as out,(T/(name+'-metadata.log')).open('wb') as err:
  start=time.monotonic();c=subprocess.run(['cargo','+1.99.0','metadata','--locked','--format-version','1','--filter-platform','aarch64-apple-darwin'],cwd=wd,stdout=out,stderr=err);results.append({'stage':name,'exit':c.returncode,'seconds':time.monotonic()-start})
 assert c.returncode==0 and lock.read_bytes()==baseline_lock;metadata.append(json.loads((T/(name+'-metadata.json')).read_text()))
assert metadata[0]['resolve']==metadata[1]['resolve']
res={'actual_cargo_version':'1.99.0','target':'aarch64-apple-darwin','resolved_dependency_graph_identical':True,'tauri_nodes':[{'id':n['id'],'features':n['features']} for n in metadata[0]['resolve']['nodes'] if n['id'].split('#')[-1].startswith('tauri@')],'isolated_lock_bytes_frozen_across_both_repeat_calls':hashlib.sha256(baseline_lock).hexdigest(),'lock_semantics_identical_to_archive':True,'original_commands':json.loads((T/'metadata-checks.json').read_text()),'repeat_commands':results,'probe_corrections':['First graph equality succeeded; lock raw equality failed due Cargo-normalized LF versus CRLF archived source.','Second expected raw Git equality also failed for same reason; no version/dependency change.','Repeated both calls after initial normalization; lock bytes frozen and resolved graph equal.'],'tracked_lock_unchanged':True,'limits':['Cargo metadata resolution on Windows does not provide Mac SDK compilation.']}
(T/'resolved-feature-graph.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res),flush=True)
