from pathlib import Path
import collections,datetime,difflib,hashlib,io,json,os,re,subprocess,sys,tarfile,time

root=Path('D:/SoloSoul');base=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
slug='rf1113-account-cold-text-2026-10-10';out=root/'docs/verification'/slug
proof=load(base/'rf1113-account-cold-text-test-build1/current-apks.json')
for name,digest in proof['sourceFiles'].items():assert sha(root/name)==digest,name
for row in proof['files']:assert sha(Path(row['copy']))==row['sha256']
v=load(base/'rf1113-account-cold-text-native-round1/verification.json')
assert v['accepted'] and len(v['results'])==4
for row in v['results']:assert row['exitCode']==0 and row['accepted'] and row['restored']
for name in ['test-build','test-badging','test-signature']:
 assert load(base/'rf1113-account-cold-text-test-build1'/(name+'.receipt.json'))['exitCode']==0
home='tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidHomeInstrumentedTest.kt'
unit='tauri/scripts/test_android_home_native_regression.py';runner='tauri/scripts/android-home-native-regression.py'
before=(base/'rf1113-before-cold-home.kt').read_bytes();after=(root/home).read_bytes()
assert before.replace(b'it.optString("foreground") == "#d6ddd8"',b'it.optString("foreground") == "#ffffff"')==after
red=base/'rf1113-cold-login-red-native-round3/cold-supported'
assert 'OK (1 test)' in (red/'native.log').read_text(encoding='utf-8')
assert '"foreground":"#ffffff"' in (red/'cold-native.log').read_text(encoding='utf-8')
assert load(red/'report.json')['oldProcessStopped'] and load(red/'report.json')['restored']
assert not load(base/'rf1113-cold-login-red-native-round3/verification.json')['accepted']
out.mkdir(exist_ok=False);(out/'.gitattributes').write_text('* -text -diff\n',encoding='utf-8',newline='\n')
native=[]
for row in v['results']:
 run=base/'rf1113-account-cold-text-native-round1'/row['label']
 reports=['report.json','device-files/report.json']
 if row['scenario']=='cold':reports.append('cold-device-files/report.json')
 for name in reports:
  p=out/'current-native'/row['label']/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((run/name).read_bytes())
 raw=load(run/('cold-device-files/report.json' if row['scenario']=='cold' else 'device-files/report.json'))
 item={'label':row['label'],'stages':len(raw['records']),'motionPreferenceChecks':raw.get('motionPreferenceChecks')}
 if row['scenario']=='cold':
  login=next(x for x in raw['records'] if x['stage']=='cold-login')
  assert login['foreground']=='#ffffff' and login['processId']!=login['previousProcessId'] and login['locked']
  item['processId']=login['processId'];item['previousProcessId']=login['previousProcessId']
 native.append(item)
checks=base/'rf1113-offline-regression';checks.mkdir(exist_ok=False)
env=os.environ.copy();env.update({'PYTHONUTF8':'1','PYTHONDONTWRITEBYTECODE':'1','TEMP':str(base/'tmp'),'TMP':str(base/'tmp')})
command=[sys.executable,'-m','unittest','discover','-s','scripts','-p','test_android_home_native_regression.py','-v']
began=time.monotonic()
with (checks/'tests.stdout.log').open('xb') as stdout,(checks/'tests.stderr.log').open('xb') as stderr:
 result=subprocess.run(command,cwd=root/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=120,creationflags=subprocess.CREATE_NO_WINDOW)
receipt={'exitCode':result.returncode,'command':command,'elapsedSeconds':time.monotonic()-began}
(checks/'tests.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
assert result.returncode==0
assert 'Ran 34 tests' in (checks/'tests.stderr.log').read_text(encoding='utf-8')
blobs={}
for folder in ['api31-home-current-round1','rf1113-cold-login-red-round1','rf1113-cold-login-red-native-round3',
 'rf1113-account-cold-text-test-build1','rf1113-account-cold-text-native-round1','rf1113-offline-regression']:
 for p in (base/folder).rglob('*'):
  if p.is_file() and p.suffix in {'.json','.log','.xml','.png','.py'}:
   blobs[(Path(folder)/p.relative_to(base/folder)).as_posix()]=p.read_bytes()
for p in base.glob('*rf1113*.py'):blobs['drivers/'+p.name]=p.read_bytes()
blobs['sources/before-cold-home.kt']=before;blobs['sources/after-cold-home.kt']=after
blobs['sources/before-offline-tests.py']=(base/'rf1113-before-python-tests.py').read_bytes()
blobs['sources/after-offline-tests.py']=(root/unit).read_bytes()
blobs['sources/after-external-runner.py']=(root/runner).read_bytes()
blobs['sources/before-external-runner.py']=(base/'rf1113-cold-login-red-round1/external-runner-before.py').read_bytes()
archive=out/'raw.tar.gz';members=[]
with tarfile.open(archive,'w:gz',compresslevel=9) as tf:
 for name,data in sorted(blobs.items()):
  assert '..' not in Path(name).parts and not name.startswith('/')
  info=tarfile.TarInfo(name);info.size=len(data);tf.addfile(info,io.BytesIO(data))
  members.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(archive) as tf:
 assert len(tf.getmembers())==len(members)
 for row in members:assert hashlib.sha256(tf.extractfile(row['path']).read()).hexdigest()==row['sha256']
index={'members':members,'count':len(members),'archiveSha256':sha(archive),
 'readBackVerified':True,'privateBackupTarFilesIncluded':False,'apkFilesIncluded':False}
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8',newline='\n')
record={'task':'RF-1113','accepted':True,'productUnchanged':True,'nativeResults':v['results'],'nativeStages':native,
 'offlineRegression':receipt,'offlineTests':34,'sourceFiles':proof['sourceFiles'],'apkFiles':proof['files'],
 'accountFixtureFrom':'rf1114-account-frame-stability-2026-10-10/current-native/accounts-supported',
 'accountFixtureSha256':sha(root/'docs/verification/rf1114-account-frame-stability-2026-10-10/current-native/accounts-supported/device-files/report.json'),
 'oldHistoricalReportsUnchanged':True,'archiveIndexSha256':sha(out/'index.json'),
 'api35Accepted':False,'RF121Complete':False,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(root/'docs/verification'/(slug+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
p=root/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md';s=p.read_text(encoding='utf-8')
s=s.replace('**293 / 304**；实际修复（已关闭）：293','**294 / 304**；实际修复（已关闭）：294').replace('暂缓：0；进行中：1；待执行：6。','暂缓：0；进行中：0；待执行：6。')
s=s.replace('| 303 | [RF-1113](#rf-1113) | P2 | 同步账户与冷启动原生验收的正文色预期 | [RF-1114](#rf-1114) | [~] 进行中 |','| 303 | [RF-1113](#rf-1113) | P2 | 同步账户与冷启动原生验收的正文色预期 | [RF-1114](#rf-1114) | [x] 完成 |')
s=re.sub(r'^- 当前处理：.*$', '- 当前处理：**RF-1113/1114已完成：API31双环境完整冷启动与减少动画、生命周期重建、无减少动画冷启动通过，34项离线回归通过。继续核对RF-1109余项和Windows剩余原生场景**。',s,flags=re.M)
s+='''
### RF-1113 账户与冷启动正文预期同步当前主题（2026-10-10）

- 最初双环境账户原生准备通过，但外层仍要求历史正文色而拒绝；修正外层后发现独立账户截图时序问题，已由RF-1114单独修复并提交。随后真正冷启动红测进入新进程锁定页，实际白色正文正确，旧Kotlin预期导致45秒超时；原生准备OK、旧进程确已退出、失败后完整恢复，均保留原件。
- 仅更新外层账户深/浅及冷启动正文色、Kotlin锁定页正文色四处旧预期；统一为canonical深色#ffffff、浅色#111111。背景、强调色、账号及保存偏好隔离、进程身份、像素/对比度、系统模式和减少动画检查保持，产品源码与完整主APK逐字不变。
- 最终API31/WebView91支持/降级完整cold均严格exit0，均含真实终止旧进程、新进程锁定页和真实主密码解锁、两账户reduceMotion true/false交付；另完整lifecycle与无减少动画cold通过。4轮场景共7项真实原生方法均OK(1 test)，完整私有数据/链接/权限及模糊、夜间、字体设置恢复，1830项来源和APK哈希核验。
- 原离线回归改用当前真实冷启动/生命周期快照以及RF-1114真实账户快照，34项全部通过；错误颜色、动画交付、原生系统模式、Activity/WebView重建、操作像素/命中与缺失冷启动阶段仍拒绝。API31无通知权限适用性，相关快照验收明确使用false；历史记录不改写。
- [结构化证据](verification/rf1113-account-cold-text-2026-10-10.json)及原件索引保存完整失败与通过、编译/签名/身份、离线回归及实际来源；不归档私有备份TAR或APK。不据此关闭API35/WebGL或完整跨平台RF-121；一项独立提交，不推送。
'''
p.write_text(s,encoding='utf-8',newline='\n')
start='### Android私有设备就绪与生成文件核对（2026-10-10）';end='### RF-1108 Android卡片截图等待原生绘制（2026-10-10）'
assert s.count(start)==s.count(end)==1;desired=s[:s.index(start)]+s[s.index(end):]
rows=[r for r in desired.splitlines() if re.match(r'^\| \d+ \| \[RF-\d+\]',r)]
assert len(rows)==304 and collections.Counter(re.search(r'\[([x!~ ])\]',r).group(1) for r in rows)=={'x':294,'!':4,' ':6}
name=p.relative_to(root).as_posix();head=subprocess.run(['git','show','HEAD:'+name],cwd=root,capture_output=True,check=True).stdout.decode()
assert subprocess.run(['git','diff','--cached','--name-only'],cwd=root,capture_output=True,check=True).stdout==b''
patch=''.join(difflib.unified_diff(head.splitlines(True),desired.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(base/'rf1113-report-stage.patch').write_text(patch,encoding='utf-8',newline='\n');subprocess.run(['git','apply','--cached','--whitespace=error','-'],cwd=root,input=patch.encode(),check=True)
subprocess.run(['git','add','--',home,unit,runner,f'docs/verification/{slug}.json'],cwd=root,check=True)
subprocess.run(['git','add','-f','--',str(out.relative_to(root))],cwd=root,check=True)
expected={str(p.relative_to(root)).replace('\\','/'):sha(p) for p in out.rglob('*') if p.is_file()}
for n in [home,unit,runner,f'docs/verification/{slug}.json']:expected[n]=sha(root/n)
names=subprocess.run(['git','diff','--cached','--name-only','-z'],cwd=root,capture_output=True,check=True).stdout.decode().strip('\0').split('\0')
assert set(names)==set(expected)|{name}
for n,d in expected.items():assert hashlib.sha256(subprocess.run(['git','show',':'+n],cwd=root,capture_output=True,check=True).stdout).hexdigest()==d,n
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
print(json.dumps({'accepted':True,'rawMembers':len(members),'stagedFiles':len(names),'offlineTests':34,'scope':'RF-1113 only'}))
