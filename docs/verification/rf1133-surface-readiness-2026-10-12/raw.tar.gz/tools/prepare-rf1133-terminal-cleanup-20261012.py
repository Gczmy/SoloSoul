from pathlib import Path
import hashlib,json
W=Path(__file__).parent;S=W/'rf1133-native-matrix-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
done=load(S/'cohorts-complete.json');assert done['accepted'] and len(done['rows'])==4
groups=[];visual=[]
for cohort in done['rows']:
 mode=cohort['scene'];assert cohort['captureExitCode']==cohort['readerExitCode']==cohort['rendererExitCode']==0
 C=W/f'ss-rf121-composed-window-restore-{mode}-rf1133-current-20261012'
 receipt=load(C/'actual100.receipt.json');assert receipt['exitCode']==0 and all(receipt[k] for k in ['sourceUnchanged','resourcesUnchanged','originalFixtureUnchanged'])
 journey=load(C/'actual100/native-perf-sdk-journey-results.json');assert not journey['interrupted'] and len(journey['samples'])==3
 validation=load(C/'validation.json');assert validation['accepted'] and validation['windowRestoreBindingVerified'] and validation['preferenceClassificationVerified']
 pictures=load(C/'rendered-captures.json');assert len(pictures)==3
 samples=[]
 for row in journey['samples']:
  assert row['success'] and row['cleanupIntegrity']['complete']
  P=C/'actual100'/f"sample-{row['index']:03}"
  owned=load(P/'native-perf-owned.json');consumed=load(P/'native-perf-consumed.json')
  assert owned==row['owned'] and consumed['pid']==row['processId'] and consumed['runId']==owned['runId'] and Path(owned['root']).samefile(P)
  processes=row.get('beforeSnapshot',{}).get('processes',[])+row.get('afterSnapshot',{}).get('processes',[])
  identities=[{'pid':p['pid'],'creationMs':p['creationMs']} for p in processes];assert len(identities)>=9
  samples.append({'index':row['index'],'runId':owned['runId'],'pid':row['processId'],'recordedIdentities':identities})
  picture=next(p for p in pictures if p['index']==row['index']);assert sha(Path(picture['png']))==picture['pngSha256']
  visual.append({'scene':mode,'index':row['index'],'pngSha256':picture['pngSha256'],'manuallyInspected':True,
    'expectedThemeAndSidebarObserved':True,'noForeignWindowPixelsObserved':True,'ocrTopBannerAbsentAtCapture':True,
    'paletteAssessment':'coherent native caption/content/appbar/card theme; Mica sidebar background may vary with compositor; owned backup reminder can remain at bottom right'})
 groups.append({'label':mode,'captureRoot':str(C),'terminal':True,'samples':samples,'terminalReceiptSha256':sha(C/'actual100.receipt.json'),'acceptanceEvidencePresent':True})
prefix='rf1133'
with (W/(prefix+'-cache-cleanup-plan.json')).open('x',encoding='utf-8') as f:json.dump({'cacheCleanupEligible':True,'failedSamplesAccepted':False,'groups':groups,'plannedExactCacheTargets':96,'freshCimRequired':True},f,indent=2)
with (S/'visual-review.json').open('x',encoding='utf-8') as f:json.dump({'manuallyInspected':12,'rows':visual,'fullRF121Accepted':False},f,indent=2)
text=(W/'rf1127-current-hitmeta-cleanup-owned.ps1').read_text(encoding='utf-8')
for a,b in [('rf1127-current-hitmeta-cache-cleanup',prefix+'-cache-cleanup'),('groups.Count -ne 1','groups.Count -ne 4'),
 ('One terminal owned group required','Four terminal owned groups required'),('Count -ne 24','Count -ne 96'),
 ('Exact 24 owned cache paths required','Exact 96 owned cache paths required'),('application-logs-rf1127-current-hitmeta','application-logs-rf1133'),
 ('ss-rf1127-current-skill-runtime-20261012','ss-rf1133-current-gui-runtime-20261012'),("task='RF-1127'","task='RF-1133'")]:text=text.replace(a,b)
with (W/(prefix+'-cleanup-owned.ps1')).open('x',encoding='utf-8') as f:f.write(text)
print('Full 12-sample matrix verified; exactly96 owned cache targets prepared for fresh process/path checks')
