from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('D:/SoloSoul');S=Path(__file__).parent/'rf1133-surface-readiness-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sources=load(S/'sources.json');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify():assert all(sha(R/n)==h for n,h in sources.items())
def save(n,v):
 with (S/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
env=os.environ.copy();cache=R/'build/rf312-maintenance-20261009'
env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),CARGO_HOME=str(cache/'cargo-home'),
 CARGO_TARGET_DIR=str(cache/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(cache/'ort-cache'),
 PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
for n in ['PDFIUM_LIBRARY_PATH','TAURI_CONFIG','TAURI_ANDROID_PROJECT_PATH','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:env.pop(n,None)
tests=sorted(p.relative_to(R/'tauri').as_posix() for p in (R/'tauri/scripts').glob('native-perf*.test.mjs'))
assert 'scripts/native-perf-surface.node.test.mjs' in tests
tests+=['src-tauri/src/native_perf/observer.node.test.mjs']
commands=[('fmt',['cargo','fmt','--all','--','--check']),
 ('prettier',['node','node_modules/prettier/bin/prettier.cjs','--check','scripts/native-perf-surface.node.test.mjs','src-tauri/src/native_perf/sdk_surface.js']),
 ('node-regressions',['node','--test',*tests]),
 ('native-clippy',['cargo','clippy','--locked','--offline','-p','solo_soul','--all-targets','--features','native-perf','--','-D','warnings']),
 ('native-tests',['cargo','test','--locked','--offline','-p','solo_soul','--lib','--features','native-perf','native_perf::','--','--nocapture'])]
rows=[]
for name,cmd in commands:
 verify();began=time.monotonic()
 with (S/(name+'.stdout.log')).open('xb') as out,(S/(name+'.stderr.log')).open('xb') as err:
  p=subprocess.Popen(cmd,cwd=R/'tauri',env=env,stdout=out,stderr=err,stdin=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW)
  save(name+'.live.json',{'pid':p.pid,'command':cmd});print(name,'live PID',p.pid,flush=True);code=p.wait()
 verify();row={'name':name,'pid':p.pid,'command':cmd,'exitCode':code,'elapsedSeconds':time.monotonic()-began,'sourcesUnchanged':True}
 rows.append(row);save(name+'.receipt.json',row);print(name,'terminal exit',code,flush=True)
 if code:break
accepted=len(rows)==len(commands) and all(x['exitCode']==0 for x in rows)
save('checks-complete.json',{'accepted':accepted,'rows':rows,'sourceCount':1843,'nativeGuiExecuted':False})
raise SystemExit(0 if accepted else 1)
