from pathlib import Path
import hashlib,json,subprocess
R=Path('D:/SoloSoul');W=Path(__file__).parent
B=W/'rf1133-current-gui-build-20261012';S=W/'rf1133-native-matrix-20261012'
D=W/'rf1130-caption-hit-20261012';F=W/'rf1133-surface-readiness-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
dirty=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).splitlines()
assert set(dirty)=={' M docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md',' M tauri/scripts/native-perf-surface.node.test.mjs',
 ' M tauri/src-tauri/src/native_perf/sdk_surface.js',' M tauri/src-tauri/src/native_perf/sdk_surface.rs'},dirty
assert load(F/'checks-complete.json')['accepted'] and load(B/'build.receipt.json')['exitCode']==0
assert load(B/'native-test-counts.json')=={'passed':137,'failed':0,'ignored':0,'currentSources':True}
assert load(B/'dist-input-stability.json')['allGeneratedFrontendInputsUnchangedDuringRustBuild']
sources=load(B/'sources.json');assert len(sources)==1843 and sources==load(F/'sources.json')
assert all(sha(R/n)==h for n,h in sources.items())
helper_sources=load(D/'sources-after-api-fix.json');assert all(sha(R/n)==h for n,h in helper_sources.items())
assert load(D/'checks-retry1/checks-complete.json')['accepted']
package=load(B/'runtime-package.json');assert sha(Path(package['exe']))==package['sha256']
old_checked=load(W/'rf1130-native-matrix-20261012/caption-runtime-package.json')
restore=load(W/'rf1130-native-matrix-20261012/restore-helper.json')
for p,h in [(old_checked['activationExe'],old_checked['activationSha256']),(restore['exe'],restore['sha256'])]:assert sha(Path(p))==h
for k in ['activationExe','activationSha256','activationSource','activationSourceSha256','captionDiagnosticSource','captionDiagnosticSourceSha256']:package[k]=old_checked[k]
S.mkdir(exist_ok=False)
def save(n,v):
 with (S/n).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
save('sources.json',sources);save('caption-runtime-package.json',package);save('restore-helper.json',restore)
names=[('run-rf1127-current-minimized.py','run-rf1133-current.py'),
 ('verify-rf1127-current-minimized.mjs','verify-rf1133-current.mjs'),
 ('render-rf1127-current-minimized.py','render-rf1133-current.py'),
 ('run-rf1127-current-minimized-cohorts.py','run-rf1133-current-cohorts.py'),
 ('rf1127-current-minimized-session-preflight.py','rf1133-current-session-preflight.py')]
mapping=[('rf1127-current-minimized-matrix-20261012',S.name),('-current-minimized-20261012','-rf1133-current-20261012'),
 ("'rf1127-current-minimized-session-'+mode+'.py'","'rf1133-current-session-'+mode+'.py'"),*names]
tools={};rows=[]
for a,b in names:
 before=(W/a).read_text(encoding='utf-8');after=before
 for x,y in mapping:after=after.replace(x,y)
 p=W/b;assert not p.exists()
 if p.suffix=='.py':compile(after,str(p),'exec')
 p.write_text(after,encoding='utf-8',newline='\n');assert p.read_text(encoding='utf-8')==after
 tools[p.relative_to(R).as_posix()]=sha(p)
 rows.append({'before':str(W/a),'beforeSha256':sha(W/a),'after':str(p),'afterSha256':sha(p),'changes':'only exclusive paths and tool names; original strict guards and per-sample budgets retained'})
for n,h in helper_sources.items():tools[n]=h
for p in [W/'window-restore-contract.mjs',Path(__file__),R/'tauri/scripts/native-perf-owned-json.py',R/'tauri/scripts/native-perf-preference-contract.mjs']:
 tools[p.relative_to(R).as_posix()]=sha(p)
save('tools.json',tools)
save('preparation.json',{'task':'RF-1133','sourceCount':1843,'nativeTests':137,'currentGuiSha256':package['sha256'],
 'derivation':rows,'replacements':mapping,'originalStrictGuardsUnchanged':True,'extraInputRetries':0,
 'scopeReduced':False,'wholeMatrixAccepted':False,'uncommittedSourceInputsExplicitlyFrozen':True,
 'previousFailedMatrix':'docs/verification/rf1127-minimized-console-layout-2026-10-12.json',
 'actualSourceFix':'before waits for existing OCR banner to disappear and geometry to settle; uses original 10-second acknowledgment wait budget; after remains immediate and strictly equal'})
print('Prepared new RF-1133 GUI full four-cohort matrix; previous three failed rounds retained')
