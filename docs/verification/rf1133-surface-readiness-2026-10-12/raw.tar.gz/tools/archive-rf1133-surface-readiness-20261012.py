from pathlib import Path
import hashlib,io,json,re,tarfile
R=Path('D:/SoloSoul');W=Path(__file__).parent;F=W/'rf1133-surface-readiness-20261012'
B=W/'rf1133-current-gui-build-20261012';S=W/'rf1133-native-matrix-20261012'
N='rf1133-surface-readiness-2026-10-12';O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
sources=load(F/'sources.json');assert len(sources)==1843 and sources==load(B/'sources.json')==load(S/'sources.json')
assert all(sha(R/n)==h for n,h in sources.items())
checks=load(F/'checks-complete.json');assert checks['accepted'] and all(r['exitCode']==0 for r in checks['rows'])
assert load(B/'build.receipt.json')['exitCode']==0
assert load(B/'native-test-counts.json')=={'passed':137,'failed':0,'ignored':0,'currentSources':True}
assert load(B/'manifest-newline-parity.json')['normalizedBytesEqual'] and load(B/'manifest-newline-parity.json')['parsedTomlEqual']
assert load(B/'dist-input-stability.json')['allGeneratedFrontendInputsUnchangedDuringRustBuild']
package=load(S/'caption-runtime-package.json');assert sha(Path(package['exe']))==package['sha256']
assert len(package['resources'])==94 and all(sha(Path(r['copy']))==sha(Path(r['source']))==r['sha256'] for r in package['resources'])
matrix=load(S/'cohorts-complete.json');assert matrix['accepted'] and len(matrix['rows'])==4
review=load(S/'visual-review.json');assert review['manuallyInspected']==12 and all(r['manuallyInspected'] for r in review['rows'])
cleanup=load(W/'rf1133-cache-cleanup.json')
assert cleanup['preservedBytesVerified'] and cleanup['identitiesChecked']==108 and len(cleanup['removedCachePaths'])==96 and len(cleanup['linksUnlinked'])==12
assert cleanup['processesTerminatedByThisTool']==0 and all(not Path(p).exists() for p in cleanup['removedCachePaths'])
assert all(sha(Path(r['path']))==r['sha256'] for r in cleanup['preservedVaultAndRootFiles'])
members={};groups=[]
for row in matrix['rows']:
 assert row['captureExitCode']==row['readerExitCode']==row['rendererExitCode']==0
 C=W/f"ss-rf121-composed-window-restore-{row['scene']}-rf1133-current-20261012"
 validation=load(C/'validation.json');assert validation['accepted'] and len(validation['samples'])==3
 j=load(C/'actual100/native-perf-sdk-journey-results.json');assert len(j['samples'])==3 and all(s['success'] and s['cleanupIntegrity']['complete'] for s in j['samples'])
 groups.append({**row,'samples':3,'windowRestoreBindingVerified':validation['windowRestoreBindingVerified'],
  'preferenceClassificationVerified':validation['preferenceClassificationVerified'],'preferenceIntervals':validation['preferenceIntervals']})
 excluded={'vault','app-data','profile','webview','temp','models','plugins'}
 for p in C.rglob('*'):
  rel=p.relative_to(C)
  if any(x in excluded for x in rel.parts):continue
  if p.is_file() and p.suffix in ['.json','.log','.bgra','.png']:members[row['scene']+'/'+rel.as_posix()]=p
for label,directory in [('checks',F),('build',B),('matrix',S)]:
 for p in directory.iterdir():
  if p.is_file() and p.suffix in ['.json','.log','.js','.rs','.mjs','.toml']:members[label+'/'+p.name]=p
for p in W.glob('*rf1133*'):
 if p.is_file() and p.suffix in ['.py','.mjs','.ps1','.json']:members['tools/'+p.name]=p
for p in (W/'application-logs-rf1133').rglob('*'):
 if p.is_file():members['application-logs/'+p.relative_to(W/'application-logs-rf1133').as_posix()]=p
for n in ['tauri/src-tauri/src/native_perf/sdk_surface.js','tauri/src-tauri/src/native_perf/sdk_surface.rs','tauri/scripts/native-perf-surface.node.test.mjs',
 'tauri/scripts/native-perf-owned-json.py','tauri/scripts/native-perf-preference-contract.mjs','tauri/scripts/native-perf-caption-hit-diagnostic.rs']:
 members['sources/'+Path(n).name]=R/n
for p in [W/'window-restore-contract.mjs',Path(package['helperSource']),Path(package['activationSource']),Path(load(S/'restore-helper.json')['source'])]:members['sources/'+p.name]=p
node=(F/'node-regressions.stdout.log').read_text(encoding='utf-8');assert 'tests 223' in node and 'pass 223' in node and 'fail 0' in node and 'skipped 0' in node
native=(F/'native-tests.stdout.log').read_text(encoding='utf-8');assert '137 passed; 0 failed; 0 ignored;' in native
red=load(F/'red-formatted.receipt.json');assert red['exitCode']==1 and red['oldProbeFailedNewReadinessCases']==5 and red['existingCasesPassed']==6
assert load(F/'source-boundary-audit.json')['original8StrictFunctionsByteEqual']
assert not O.exists();O.mkdir();rows=[]
with tarfile.open(O/'raw.tar.gz','w:gz',compresslevel=6) as archive:
 for name,p in sorted(members.items()):
  assert not p.stat().st_file_attributes&0x400
  data=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  archive.addfile(info,io.BytesIO(data));rows.append({'member':name,'source':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with tarfile.open(O/'raw.tar.gz') as archive:
 assert len(archive.getmembers())==len(rows)
 for r in rows:
  data=archive.extractfile(r['member']).read();assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
put(O/'index.json',{'task':'RF-1133','allMembersReadbackVerified':True,'members':rows,'physicalVaultExecutablesModelsCachesExcluded':True})
(O/'.gitattributes').write_text('raw.tar.gz -text\n',encoding='utf-8',newline='\n')
put(R/'docs/verification'/(N+'.json'),{'task':'RF-1133','accepted':True,'taskClosed':True,'commitCreated':False,
 'acceptanceScope':'non-default Windows owned material-capture readiness only; same newly compiled GUI full four-cohort matrix',
 'sourceHeadBeforeFix':package['gitHead'],'currentSourceFiles':sources,'sourceCount':1843,
 'changedRuntimeInputs':load(F/'implementation.json')['changed'],'defaultProductAndDependenciesUnchanged':True,
 'guiSha256':package['sha256'],'resourceCount':94,'frontendBuildInputs':38,'checks':{'nodePassed':223,'nodeFailed':0,'nodeSkipped':0,'nativePassed':137,'nativeFailed':0,'nativeIgnored':0,'nativeClippyExitCode':0},
 'redGate':red,'sourceBoundaryAudit':load(F/'source-boundary-audit.json'),'matrix':groups,'manuallyInspectedScreenshots':12,
 'original10SecondWaitBudgetSharedWithReadiness':True,'afterStateEqualityUnchanged':True,'noBannerDismissalOrExtraInputRetries':True,
 'oldFailedRoundsRetained':['rf1127-current-console-restoration-2026-10-12.json','rf1127-minimized-console-layout-2026-10-12.json'],
 'cleanup':{k:len(v) if isinstance(v,list) else v for k,v in cleanup.items()},
 'RF1127ClosedByThisCommit':False,'RF1128Closed':False,'fullRF121Accepted':False,'performanceAccepted':False,
 'archive':{'path':N+'/raw.tar.gz','members':len(rows),'bytes':(O/'raw.tar.gz').stat().st_size,'sha256':sha(O/'raw.tar.gz'),'allMembersReadbackVerified':True}})
print(json.dumps({'task':'RF-1133','accepted':True,'members':len(rows),'screenshots':12,'nodePassed':223,'nativePassed':137}))
