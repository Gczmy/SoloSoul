from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('D:/SoloSoul');S=Path(__file__).parent
F=R/'build/android-native-feasibility-20261010/rf1136-nonblank-scanned-fixture-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
g=load(F/'generator.json');exe=Path(g['path']);assert sha(exe)==g['sha256']
diff=[n for n,h in g['sourceHashes'].items() if sha(R/n)!=h]
# This historical verifier is not a current full-source build. Its media contract
# remains byte-identical after newline normalization; the current GUI must verify
# the copied fixture again, including the newer process-lock implementation.
media='tauri/crates/solosoul-core/examples/perf_baseline/media.rs'
assert hashlib.sha256((R/media).read_bytes().replace(b'\r\n',b'\n')).hexdigest()==g['sourceHashes'][media]
assert [n for n in diff if n.startswith('tauri/crates/solosoul-core/') and n!=media]==['tauri/crates/solosoul-core/src/process_lock.rs']
temp=S/'fixture-compatibility-temp';temp.mkdir(exist_ok=False)
env=os.environ.copy();env.update(TEMP=str(temp),TMP=str(temp),SOLOSOUL_SECURE='1')
rows=[]
inputs=[('legacy100',R/'build/android-native-feasibility-20261010/rf312-media-fixtures-d-20261012/vault100',1),
        ('current100',F/'host-vault100',0),('current5000',F/'host-vault5000',0)]
for label,p,expected in inputs:
    before={f.relative_to(p).as_posix():sha(f) for f in p.rglob('*') if f.is_file()}
    cmd=[str(exe),'--verify-media-fixture',str(p)];began=time.monotonic()
    with (S/(label+'.verify.stdout.log')).open('xb') as out,(S/(label+'.verify.stderr.log')).open('xb') as err:
        code=subprocess.run(cmd,cwd=R,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW).returncode
    assert before=={f.relative_to(p).as_posix():sha(f) for f in p.rglob('*') if f.is_file()}
    row=dict(label=label,fixture=str(p),command=cmd,exitCode=code,expected=expected,sourceFixtureBytesUnchanged=True,elapsedSeconds=time.monotonic()-began)
    rows.append(row);print(label,'actual exit',code,flush=True)
    assert code==expected
with (S/'fixture-compatibility.json').open('x',encoding='utf-8') as out:json.dump(dict(generator=g,sourceDifferences=diff,
    generatorIsCurrentFullSourceBuild=False,mediaContractNormalizedBytesMatch=True,currentGuiReverificationRequired=True,rows=rows),out,indent=2)
print('Historical contract verifier refused old marker and verified both new host fixtures; current GUI must independently reverify')
