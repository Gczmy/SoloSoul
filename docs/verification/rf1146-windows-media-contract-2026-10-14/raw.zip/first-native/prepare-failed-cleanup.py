from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');S=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
groups=[]
for size in [100,5000]:
    report=load(S/f'samples{size}'/'native-perf-sdk-journey-results.json')
    assert len(report['samples'])==5
    samples=[]
    for s in report['samples']:
        assert s['cleanupIntegrity']['complete']
        snapshots=[s[n] for n in ['beforeSnapshot','afterSnapshot'] if n in s]
        snapshots += [p['snapshot'] for p in s.get('memorySeries',{}).get('samples',[])]
        ids={(p['pid'],p['creationMs']) for snap in snapshots for p in snap.get('processes',[])+snap.get('exitedProcesses',[])}
        assert len(ids)>=9
        samples.append(dict(index=s['index'],runId=s['owned']['runId'],pid=s['processId'],
            recordedIdentities=[dict(pid=p,creationMs=t) for p,t in sorted(ids)]))
    groups.append(dict(objects=size,terminal=True,samples=samples))
plan=dict(terminalOwnedSamplesCleanupEligible=True,nativeMatrixAccepted=False,failedSamplesAccepted=False,groups=groups)
with (S/'failed-cleanup-plan.json').open('x',encoding='utf-8') as out:json.dump(plan,out,indent=2)
text=(S/'cleanup-owned.ps1').read_text(encoding='utf-8')
text=text.replace("'validation.json'", "'failed-cleanup-plan.json'")
text=text.replace("if (-not $validation.accepted -or $validation.groups.Count -ne 2)",
    "if (-not $validation.terminalOwnedSamplesCleanupEligible -or $validation.nativeMatrixAccepted -or $validation.failedSamplesAccepted -or $validation.groups.Count -ne 2)")
text=text.replace('cache-cleanup','failed-cache-cleanup')
with (S/'cleanup-failed-owned.ps1').open('x',encoding='utf-8',newline='\n') as out:out.write(text)
print('Ten terminal owned samples eligible for exact80 cache cleanup; incomplete media matrix remains rejected')
