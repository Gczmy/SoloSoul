from pathlib import Path
import hashlib,json,subprocess
R=Path('D:/SoloSoul');T=R/'build';B=T/'rf121-theme-binding-20261010/current-windows-native-retry1-20261014'
M=T/'android-native-feasibility-20261010/rf1136-nonblank-scanned-fixture-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
package=load(B/'runtime-package.json');sources=load(B/'sources.json')
assert len(sources)==1983
compiled_source_differences={n:dict(compiled=h,current=sha(R/n)) for n,h in sources.items() if sha(R/n)!=h}
assert set(compiled_source_differences)=={'tauri/scripts/native-perf-media-contract.mjs','tauri/scripts/native-perf-media.test.mjs'}
sources={n:sha(R/n) for n in sources}

assert sha(Path(package['exe']))==package['sha256']=='446e6221baa45285607fa594ba4dd7ea151edf8de83ce281c6fcd80aad3734a1'
assert all(sha(Path(x['source']))==sha(Path(x['copy']))==x['sha256'] for x in package['resources'])
fixtures=[]
for size in [100,5000]:
    p=M/f'host-vault{size}';meta=load(p/'rf312-media-fixture.json')
    assert meta['schemaVersion']==2
    assert all(meta['baseFixture']['kdf'][k]==v for k,v in [('memoryKiB',65536),('iterations',3),('parallelism',4)])
    files={}
    for f in p.rglob('*'):
        assert not f.is_symlink() and not f.stat().st_file_attributes&0x400
        if f.is_file():files[f.relative_to(p).as_posix()]=sha(f)
    fixtures.append(dict(objects=size,path=str(p),files=files))
for mode,samples in [('media',5),('ocr',3)]:
    S=T/f'rf1146-native-{mode}-20261014';S.mkdir(exist_ok=False)
    proof=dict(task='RF-312',mode=mode,samplesPerDataset=samples,memoryIntervalMs=2000 if mode=='media' else None,
        validationHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        runtime=package,sources=sources,fixtures=fixtures,publicMediaFixtureSource=str(M),compiledSourceDifferences=compiled_source_differences,onlyExternalNodeConsumerAndTestChanged=True,
        originalNativeSdkBudgetAndInputAndReadinessContractsPreserved=True,fullRF312Accepted=False,goal='active')
    with (S/'input-proof.json').open('x',encoding='utf-8',newline='\n') as out:json.dump(proof,out,indent=2);out.write('\n')
print('Same-source media5+OCR3 cohorts per size prepared; fixed D-drive schema2 public media sources retained')
