from pathlib import Path
R=Path('D:/SoloSoul');T=R/'build'
original=T/'prepare-rf312-integrated-windows-media-ocr-20261014.py'
text=original.read_text(encoding='utf-8')
text=text.replace('rf312-media-fixtures-d-20261012','rf1136-nonblank-scanned-fixture-20261012')
text=text.replace("p=M/f'vault{size}'", "p=M/f'host-vault{size}'")
text=text.replace('rf312-integrated-windows-{mode}-20261014','rf1146-native-{mode}-20261014')
old="assert len(sources)==1983 and all(sha(R/n)==h for n,h in sources.items())"
assert text.count(old)==1
new="""assert len(sources)==1983
compiled_source_differences={n:dict(compiled=h,current=sha(R/n)) for n,h in sources.items() if sha(R/n)!=h}
assert set(compiled_source_differences)=={'tauri/scripts/native-perf-media-contract.mjs','tauri/scripts/native-perf-media.test.mjs'}
sources={n:sha(R/n) for n in sources}
"""
text=text.replace(old,new)
text=text.replace('runtime=package,sources=sources,fixtures=fixtures,publicMediaFixtureSource=str(M),',
    'runtime=package,sources=sources,fixtures=fixtures,publicMediaFixtureSource=str(M),compiledSourceDifferences=compiled_source_differences,onlyExternalNodeConsumerAndTestChanged=True,')
generated=T/'prepare-rf1146-native-media-generated-20261014.py'
compile(text,str(generated),'exec')
with generated.open('x',encoding='utf-8',newline='\n') as out:out.write(text)
exec(compile(text,str(generated),'exec'),{'__file__':str(generated),'__name__':'__main__'})
runner=(T/'run-rf312-integrated-windows-media-ocr-20261014.py').read_text(encoding='utf-8')
runner=runner.replace('rf312-integrated-windows-{mode}-20261014','rf1146-native-{mode}-20261014')
runner=runner.replace('rf312-integrated-windows-{mode}-session-{size}-20261014','rf1146-native-{mode}-session-{size}-20261014')
generated=T/'run-rf1146-native-media-ocr-20261014.py'
compile(runner,str(generated),'exec')
with generated.open('x',encoding='utf-8',newline='\n') as out:out.write(runner)
print('Same GUI/resources/38 frontend outputs; exactly2 external Node inputs changed; original native media5/OCR3 cohorts retained')
