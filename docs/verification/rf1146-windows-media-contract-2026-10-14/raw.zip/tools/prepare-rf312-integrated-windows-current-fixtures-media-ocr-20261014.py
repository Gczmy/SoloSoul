from pathlib import Path
R=Path('D:/SoloSoul');T=R/'build'
before=(T/'prepare-rf312-integrated-windows-media-ocr-20261014.py').read_text(encoding='utf-8')
after=before.replace('rf312-media-fixtures-d-20261012','rf1136-nonblank-scanned-fixture-20261012')
after=after.replace("p=M/f'vault{size}'", "p=M/f'host-vault{size}'")
after=after.replace('rf312-integrated-windows-{mode}-20261014','rf312-integrated-windows-current-fixtures-{mode}-20261014')
after=after.replace('Same-source media5+OCR3 cohorts per size prepared; fixed D-drive schema2 public media sources retained',
    'Matching nonblank schema2 host fixtures frozen; old failed queue remains unchanged; current GUI revalidation required')
generated=T/'prepare-rf312-integrated-windows-current-fixtures-generated-20261014.py'
compile(after,str(generated),'exec')
with generated.open('x',encoding='utf-8',newline='\n') as out:out.write(after)
exec(compile(after,str(generated),'exec'),{'__file__':str(generated),'__name__':'__main__'})
runner=(T/'run-rf312-integrated-windows-media-ocr-20261014.py').read_text(encoding='utf-8')
runner=runner.replace('rf312-integrated-windows-{mode}-20261014','rf312-integrated-windows-current-fixtures-{mode}-20261014')
runner=runner.replace('rf312-integrated-windows-{mode}-session-{size}-20261014','rf312-integrated-windows-current-fixtures-{mode}-session-{size}-20261014')
path=T/'run-rf312-integrated-windows-current-fixtures-media-ocr-20261014.py'
compile(runner,str(path),'exec')
with path.open('x',encoding='utf-8',newline='\n') as out:out.write(runner)
print('Only fixture source/evidence namespace changed; runtime, UI actions, strict guards and budgets unchanged')
