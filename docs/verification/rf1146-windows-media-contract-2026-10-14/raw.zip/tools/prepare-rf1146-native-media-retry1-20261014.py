from pathlib import Path
import shutil
R=Path('D:/SoloSoul');T=R/'build';S=T/'rf1146-native-media-retry1-20261014'
S.mkdir(exist_ok=False)
shutil.copyfile(T/'rf1146-native-media-20261014/input-proof.json',S/'input-proof.json')
text=(T/'run-rf1146-native-media-ocr-20261014.py').read_text(encoding='utf-8')
text=text.replace('rf1146-native-{mode}-20261014','rf1146-native-{mode}-retry1-20261014')
text=text.replace('rf1146-native-{mode}-session-{size}-20261014','rf1146-native-{mode}-retry1-session-{size}-20261014')
p=T/'run-rf1146-native-media-retry1-20261014.py';compile(text,str(p),'exec')
with p.open('x',encoding='utf-8',newline='\n') as out:out.write(text)
shutil.copyfile(T/'rf1146-native-media-20261014/prepare-independent.py',S/'prepare-independent.py')
print('Original full two-cohort retry prepared; prior failed matrix and cleanup evidence remain unchanged')
