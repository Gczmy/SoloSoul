from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
R=Path('D:/SoloSoul');T=R/'build'
assert len(sys.argv)==2 and sys.argv[1] in ['media','ocr'];mode=sys.argv[1]
S=T/f'rf312-integrated-windows-{mode}-20261014'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=load(S/'input-proof.json');package=proof['runtime']
def save(n,v):
    with (S/n).open('x',encoding='utf-8',newline='\n') as out:json.dump(v,out,indent=2);out.write('\n')
def verify():
    assert all(sha(R/n)==h for n,h in proof['sources'].items())
    assert sha(Path(package['exe']))==package['sha256']
    assert all(sha(Path(x['source']))==sha(Path(x['copy']))==x['sha256'] for x in package['resources'])
    for fixture in proof['fixtures']:
        p=Path(fixture['path']);assert {f.relative_to(p).as_posix():sha(f) for f in p.rglob('*') if f.is_file()}==fixture['files']
env=os.environ.copy();env.update(TEMP=str(S),TMP=str(S),PYTHONUTF8='1')
for key in ['PDFIUM_LIBRARY_PATH','SOLOSOUL_REGISTRY_PUBKEY','WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS','WEBVIEW2_USER_DATA_FOLDER','SOLOSOUL_NATIVE_PERF_ROOT','SOLOSOUL_NATIVE_PERF_PORT']:env.pop(key,None)
rows=[]
for fixture in proof['fixtures']:
    verify();size=fixture['objects']
    source=(T/'rf121-theme-binding-20261010/rf1133-current-session-preflight.py').read_text(encoding='utf-8')
    source=source.replace('rf1133-native-matrix-20261012/session-before-native.json',f'rf312-integrated-windows-{mode}-20261014/session-before-{size}.json')
    probe=T/f'rf312-integrated-windows-{mode}-session-{size}-20261014.py'
    with probe.open('x',encoding='utf-8') as out:out.write(source)
    subprocess.run(['C:/Python314/python.exe',str(probe)],cwd=R,check=True)
    session=load(S/f'session-before-{size}.json')
    assert session.get('connectionState')==0 and session.get('inputDesktopAvailable')
    output=S/f'samples{size}'
    cmd=['node',f'scripts/native-perf-{mode}.mjs','--exe',package['exe'],'--fixture',fixture['path'],'--output',str(output),'--samples',str(proof['samplesPerDataset'])]
    if proof['memoryIntervalMs'] is not None:cmd+=['--memory-interval-ms',str(proof['memoryIntervalMs'])]
    began=time.monotonic()
    with (S/f'{size}.stdout.log').open('xb') as out,(S/f'{size}.stderr.log').open('xb') as err:
        p=subprocess.Popen(cmd,cwd=R/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(f'{size}.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        print(mode,size,'live PID',p.pid,flush=True);code=p.wait()
    verify()
    result=load(output/'native-perf-sdk-journey-results.json') if (output/'native-perf-sdk-journey-results.json').is_file() else None
    accepted=bool(code==0 and result and result.get('success') and len(result['samples'])==proof['samplesPerDataset'])
    row=dict(objects=size,exitCode=code,accepted=accepted,elapsedSeconds=time.monotonic()-began,command=cmd,sourceAndRuntimeAndFixturesUnchanged=True)
    save(f'{size}.receipt.json',row);rows.append(row);print(mode,size,'exit',code,'accepted',accepted,flush=True)
    if not accepted:
        save('terminal.json',dict(accepted=False,rows=rows,remainingCohortsNotStarted=True,fullRF312Accepted=False,goal='active'))
        raise SystemExit(code or 1)
save('terminal.json',dict(accepted=True,rows=rows,fullRF312Accepted=False,goal='active'))
