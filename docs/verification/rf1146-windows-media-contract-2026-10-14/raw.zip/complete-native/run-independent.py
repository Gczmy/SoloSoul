from pathlib import Path
import json,subprocess,time
S=Path(__file__).parent;R=Path('D:/SoloSoul')
for n in [100,5000]:assert json.loads((S/f'{n}.receipt.json').read_text(encoding='utf-8'))['exitCode']==0
cmd=['node',str(S/'verify-current.mjs')];began=time.monotonic()
with (S/'independent.stdout.log').open('xb') as out,(S/'independent.stderr.log').open('xb') as err:
    p=subprocess.Popen(cmd,cwd=R,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    print('independent full-journey verifier live',p.pid,flush=True);code=p.wait()
with (S/'independent.receipt.json').open('x',encoding='utf-8') as out:json.dump(dict(command=cmd,pid=p.pid,exitCode=code,elapsedSeconds=time.monotonic()-began),out,indent=2)
print('independent full-journey verifier exit',code,flush=True)
raise SystemExit(code)
