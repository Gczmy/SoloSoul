from pathlib import Path
import hashlib,json
R=Path('D:/SoloSoul');S=Path(__file__).parent;O=R/'build/rf312-home-memory-20261010'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
p=load(S/'input-proof.json');pkg=p['runtime']
with (S/'reader-input-proof.json').open('x',encoding='utf-8') as out:json.dump(dict(exe=pkg['exe'],exeSha256=pkg['sha256'],
    resources=pkg['resources'],sourceFiles=p['sources'],baseCommit=pkg['gitHead'],
    sourceManifestSha256=hashlib.sha256((S/'input-proof.json').read_bytes()).hexdigest(),
    fixtureHashes={str(x['objects']):x['files'] for x in p['fixtures']}),out,indent=2)
text=(O/'verify-current.mjs').read_text(encoding='utf-8')
text=text.replace('summarizeJourneys, PHASES','summarizeMediaJourneys, MEDIA_PHASES as PHASES')
text=text.replace("load(path.join(stage,'input-proof.json'))", "load(path.join(stage,'reader-input-proof.json'))")
text=text.replace('`journey-${size}.receipt.json`','`${size}.receipt.json`')
text=text.replace('receipt.sourceUnchanged','receipt.sourceAndRuntimeAndFixturesUnchanged')
text=text.replace('  assert.equal(receipt.pdfiumOverrideInherited,false);',
    "  // Current native configure_runtime refuses inherited PDFium overrides before publishing consumed.\n"
    "  assert(report.samples.every(s=>s.consumed?.scope==='windows-native-perf-consumed'&&s.consumed.pid===s.processId&&s.consumed.runId===s.owned.runId));")
text=text.replace('receipt.resourcesUnchanged','receipt.sourceAndRuntimeAndFixturesUnchanged')
text=text.replace('receipt.originalFixtureUnchanged','receipt.sourceAndRuntimeAndFixturesUnchanged')
text=text.replace('report.fixture,false','report.fixture,true')
text=text.replace('summarizeJourneys(report.samples','summarizeMediaJourneys(report.samples')
with (S/'verify-current.mjs').open('x',encoding='utf-8',newline='\n') as out:out.write(text)
text=(R/'build/rf312-integrated-windows-home-memory-20261014/run-independent.py').read_text(encoding='utf-8')
text=text.replace("f'journey-{n}.receipt.json'", "f'{n}.receipt.json'")
compile(text,str(S/'run-independent.py'),'exec')
with (S/'run-independent.py').open('x',encoding='utf-8',newline='\n') as out:out.write(text)
text=(O/'cleanup-owned.ps1').read_text(encoding='utf-8')
text=text.replace('rf312-home-memory-20261010','rf1146-native-media-20261014')
text=text.replace('rf1104-update-preferences-20261010\\bin\\solo_soul.exe','rf121-theme-binding-20261010\\current-windows-native-retry1-20261014\\runtime\\bin\\solo_soul.exe')
with (S/'cleanup-owned.ps1').open('x',encoding='utf-8',newline='\n') as out:out.write(text)
print('Original nine-phase native/media, auth/maintenance, memory and exact-owned cleanup contracts prepared; no native proof conditions weakened')
