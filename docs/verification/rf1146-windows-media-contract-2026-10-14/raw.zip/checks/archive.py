from pathlib import Path
import hashlib,json,re,zipfile
R=Path('D:/SoloSoul');T=R/'build';F=Path(__file__).parent
C=T/'rf1146-native-media-retry1-20261014';A=T/'rf1146-native-media-20261014'
N='rf1146-windows-media-contract-2026-10-14';O=R/'docs/verification'/N
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as out:json.dump(v,out,indent=2);out.write('\n')
def counts(name):
    raw=(F/(name+'.stdout.log')).read_text(encoding='utf-8')
    return {k:int(re.findall(r'^ℹ '+k+r' (\d+)$',raw,re.MULTILINE)[0]) for k in ['tests','pass','fail','skipped']}
assert counts('red')==dict(tests=11,**{'pass':9,'fail':2,'skipped':0})
assert counts('green')==dict(tests=41,**{'pass':41,'fail':0,'skipped':0})
assert counts('node-all')==dict(tests=260,**{'pass':254,'fail':5,'skipped':1})
assert counts('node-all-escalated')==dict(tests=260,**{'pass':259,'fail':0,'skipped':1})
assert load(F/'format.receipt.json')['exitCode']==0 and load(F/'node-all-escalated.receipt.json')['exitCode']==0
final_sources=load(F/'node-all-escalated.receipt.json')['sources'];assert all(sha(R/'tauri'/n)==h for n,h in final_sources.items())
assert load(F/'frontend-unchanged.json')['allBytesUnchanged'] and load(F/'frontend-unchanged.json')['count']==38
before=load(T/'rf121-theme-binding-20261010/current-windows-native-retry1-20261014/sources.json')
diff={n:dict(before=h,after=sha(R/n)) for n,h in before.items() if sha(R/n)!=h}
assert set(diff)=={'tauri/scripts/native-perf-media-contract.mjs','tauri/scripts/native-perf-media.test.mjs'}
assert load(C/'terminal.json')['accepted'] and load(C/'independent.receipt.json')['exitCode']==0
v=load(C/'validation.json');assert v['accepted'] and [g['accepted'] for g in v['groups']]==[5,5]
assert sum(g['samplePoints'] for g in v['groups'])==sum(g['validSamplePoints'] for g in v['groups'])==91
assert all(len(s['phases'])==9 for g in v['groups'] for s in g['samples'])
assert not load(A/'terminal.json')['accepted']
first=load(A/'samples5000/native-perf-sdk-journey-results.json');assert sum(s['success'] for s in first['samples'])==4
failed=first['samples'][4];assert failed['nativeProof']['failedStep']=='home' and failed['nativeProof']['reason']=='probe-timeout'
assert all(x['command']!='login' for x in failed['nativeProof']['timeoutDiagnostic']['probe']['observer']['commands'])
cleanups=[]
for stage,name,expected_files in [(A,'failed-cache-cleanup.json',300),(C,'cache-cleanup.json',310)]:
    x=load(stage/name);assert x['identitiesChecked']==90 and len(x['removedCachePaths'])==80 and x['preservedBytesVerified']
    assert x['processesTerminatedByThisTool']==0 and all(not Path(p).exists() for p in x['removedCachePaths'])
    assert len(x['preservedVaultAndRootFiles'])==expected_files
    assert all(sha(Path(p['path']))==p['sha256'] for p in x['preservedVaultAndRootFiles'])
    cleanups.append(dict(stage=str(stage),identitiesChecked=90,cachePathsRemoved=80,preservedFiles=expected_files,linksUnlinked=len(x['linksUnlinked']),bytesVerified=True))
members={};excluded={'vault','app-data','profile','webview','temp','tmp','models','plugins','fixture-compatibility-temp'}
def add(label,root,recursive=True):
    paths=root.rglob('*') if recursive else root.iterdir()
    for p in paths:
        rel=p.relative_to(root)
        if any(s in excluded for s in rel.parts):continue
        if p.is_file() and p.suffix in ['.json','.log','.py','.mjs','.ps1']:
            assert not p.is_symlink() and not p.stat().st_file_attributes&0x400
            members[label+'/'+rel.as_posix()]=p
add('checks',F,False);add('first-native',A);add('complete-native',C)
add('old-fixture-refusal',T/'rf312-integrated-windows-media-20261014')
add('current-fixture-node-refusal',T/'rf312-integrated-windows-current-fixtures-media-20261014')
for p in T.iterdir():
    if p.is_file() and p.suffix=='.py' and ('rf1146' in p.name or 'integrated-windows' in p.name and 'media' in p.name):members['tools/'+p.name]=p
for n in final_sources:members['sources/'+Path(n).name]=R/'tauri'/n
for p in [R/'tauri/crates/solosoul-core/examples/perf_baseline/media.rs',R/'tauri/src-tauri/src/native_perf/media_fixture.rs']:
    members['sources/'+p.name]=p
O.mkdir(exist_ok=False);rows=[]
with zipfile.ZipFile(O/'raw.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in sorted(members.items()):
        b=p.read_bytes();z.writestr(n,b);rows.append(dict(member=n,source=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with zipfile.ZipFile(O/'raw.zip') as z:
    assert z.testzip() is None and len(z.infolist())==len(rows)
    for r in rows:
        b=z.read(r['member']);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
put(O/'index.json',dict(task='RF-1146',members=rows,allLengthsSha256AndCrcVerified=True,executablesPrivateDataAssetsAndCachesExcluded=True))
(O/'.gitattributes').write_text('raw.zip -text\n',encoding='utf-8',newline='\n')
put(R/'docs/verification'/(N+'.json'),dict(task='RF-1146',accepted=True,taskClosed=True,goal='active',
    sourceHeadBeforeFix='114b3dcc4',changedSources=diff,defaultClientRustFrontendAndDependenciesUnchanged=True,
    oldDescriptor=dict(bytes=1921,sha256='8fda928a9940813a4a245a2db1e943c64b4e717d20274f9b4f27ee5b9b3fc4a1'),
    currentDescriptor=dict(bytes=5082,sha256='0a3cab3b67ca5390d4ca0b468b50b1c3c2a8b9c8220335356675f62df3a9d525'),
    checks=dict(red=counts('red'),targeted=counts('green'),initialSandbox=counts('node-all'),fullNativePermissions=counts('node-all-escalated'),formatExitCode=0),
    runtimeSha256=v['exeSha256'],runtimeNotRebuilt=True,resourceCount=94,frontendOutputsByteUnchanged=38,
    successfulCompleteMatrix=dict(groups=2,samplesPerGroup=5,nativePhases=90,memoryPoints=91,independentVerifierExitCode=0),
    priorWholeMediaMatrixRejected=True,prior5000HomeTimeoutBeforeLoginPreserved=True,timeoutRootCauseUnestablished=True,
    cleanups=cleanups,fullRF312Accepted=False,fullRF121Accepted=False,pushPendingExplicitApproval=True,
    archive=dict(path=N+'/raw.zip',members=len(rows),bytes=(O/'raw.zip').stat().st_size,sha256=sha(O/'raw.zip'),allLengthsSha256AndCrcVerified=True)))
print(json.dumps(dict(task='RF-1146',accepted=True,members=len(rows),nativePhases=90,memoryPoints=91,originalFailurePreserved=True)))
