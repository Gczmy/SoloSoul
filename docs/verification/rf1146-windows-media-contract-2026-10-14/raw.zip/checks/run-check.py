from pathlib import Path
import hashlib,json,os,subprocess,sys,time
R=Path('D:/SoloSoul');S=Path(__file__).parent
assert len(sys.argv)==2 and sys.argv[1] in ['red','green','node-all','node-all-escalated','format']
name=sys.argv[1]
commands={'red':['node','--test','scripts/native-perf-media.test.mjs'],
          'green':['node','--test','scripts/native-perf-media.test.mjs','scripts/native-perf-ocr.test.mjs','scripts/native-perf-pdf.test.mjs','scripts/native-perf-pdf-preview.test.mjs'],
          'node-all':['node','scripts/run-node-tests.mjs'],
          'node-all-escalated':['node','scripts/run-node-tests.mjs'],
          'format':['node','node_modules/prettier/bin/prettier.cjs','--check','scripts/native-perf-media-contract.mjs','scripts/native-perf-media.test.mjs']}
env=os.environ.copy();temp=S/'tmp';temp.mkdir(exist_ok=True);env.update(TEMP=str(temp),TMP=str(temp),PYTHONUTF8='1')
began=time.monotonic();cmd=commands[name]
with (S/(name+'.stdout.log')).open('xb') as out,(S/(name+'.stderr.log')).open('xb') as err:
    p=subprocess.Popen(cmd,cwd=R/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
    print(name,'live',p.pid,flush=True);code=p.wait()
hashes={n:hashlib.sha256((R/'tauri'/n).read_bytes()).hexdigest() for n in ['scripts/native-perf-media-contract.mjs','scripts/native-perf-media.test.mjs']}
with (S/(name+'.receipt.json')).open('x',encoding='utf-8') as out:json.dump(dict(command=cmd,exitCode=code,elapsedSeconds=time.monotonic()-began,sources=hashes),out,indent=2)
print(name,'exit',code,flush=True)
raise SystemExit(code)
