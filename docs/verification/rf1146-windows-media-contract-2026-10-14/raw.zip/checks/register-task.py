from pathlib import Path
R=Path('D:/SoloSoul');p=R/'docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md'
t=p.read_text(encoding='utf-8')
old='- 已关闭：**324 / 335**；实际修复（已关闭）：324；排除：0；待验证/阻塞：5（RF-112、RF-121、RF-312、RF-1109、RF-1128）；暂缓：0；进行中：0；待执行：6。'
new=old.replace('324 / 335','324 / 336').replace('进行中：0','进行中：1')
assert t.count(old)==1;t=t.replace(old,new)
assert t.count('、RF-1145（RF-904')==1;t=t.replace('、RF-1145（RF-904','、RF-1145、RF-1146（RF-904',1)
start=t.index('- 当前处理：');end=t.index('\n',start)
t=t[:start]+'- 当前处理：RF-1146 Windows Node/Rust媒体固定素材合同对齐；已修复、等待完整Node与当前GUI验收，证据推送等待授权，goal active。'+t[end:]
t+='''

### RF-1146

**Windows媒体消费入口与Rust固定扫描素材合同一致** · P2 · 来源：当前Windows媒体/OCR入口两侧分别拒绝。

- **前置：**RF-1136。
- **入口：**`tauri/scripts/native-perf-media-contract.mjs`、`tauri/scripts/native-perf-media.test.mjs`；公开素材由`tauri/crates/solosoul-core/examples/perf_baseline/media.rs`固定。
- **证据：**旧夹具在当前GUI原生准备阶段退出1、未创建owned样本目录，后续样本停止；非空新夹具在Node预检被“Media fixture differs from exact public contract”拒绝。Rust使用5082字节／SHA `0a3cab…9d525`的非空PDF，Node仍使用1921字节／SHA `8fda92…fc4a1`的旧空白PDF。独立历史合同验证明确拒绝旧夹具并接受两档新host夹具；其process_lock源已有变化，故不称当前全源生成器验证，当前GUI仍需完整复验。
- **执行：**仅对齐外部Node固定PDF描述，保持schema、附件UUID/路径、密文/闭合集、生产KDF、全部输入/身份/预算门禁；以实际仓库素材字节建立回归，明确拒绝旧描述。不修改默认客户端或放宽兼容。
- **验收：**两条旧实现回归红灯；定向与完整Node检查通过；相同新GUI/资源、匹配新夹具的100/5000原生媒体完整组通过。保留两次原生/预检拒绝、沙箱目录联接拒绝和所有源/退出码；清理精确自有缓存。一项一修复一提交，推送等待具体授权。
'''
p.write_text(t,encoding='utf-8',newline='\n')
print('RF-1146 uniquely registered: total336/P2=275/closed324/in-progress1; original historical counts retained')
