from pathlib import Path
import ast,hashlib,json,subprocess
w=Path(__file__).parent;outputs={}
def save(n,text):
    with (w/n).open('x',encoding='utf8',newline='\n') as f:f.write(text)
    outputs[n]=hashlib.sha256((w/n).read_bytes()).hexdigest()
for old,new in [('run-rf1122-backdrop.py','run-rf1123-backdrop.py'),('render-rf1122-backdrop.py','render-rf1123-backdrop.py')]:
    text=(w/old).read_text(encoding='utf8').replace('rf1122','rf1123');ast.parse(text);save(new,text)
text=(w/'verify-rf1122-backdrop.mjs').read_text(encoding='utf8').replace('rf1122','rf1123').replace('sourceFiles:1834','sourceFiles:1837')
text="import {checkPreferenceWrites,preferenceWriteDelta,correlatePreferenceInterval} from '../../tauri/scripts/native-perf-preference-contract.mjs';\n"+text
keys="'checked','radios','inputTrust','observer']";assert text.count(keys)==1
text=text.replace(keys,"'checked','radios','inputTrust','observer','preferenceWrites']")
anchor="assert.equal(p.schemaVersion,1);assert.equal(p.scope,'windows-native-appearance-probe');";assert text.count(anchor)==1
text=text.replace(anchor,anchor+"\n      checkPreferenceWrites(p.preferenceWrites,{runId:owned.runId,pid:bound.pid});")
anchor="for(let i=1;i<sequence.length;i++)assert.equal(ipcDelta(observers.get(sequence[i-1]),observers.get(sequence[i])).reason,null);";assert text.count(anchor)==1
text=text.replace(anchor,"for(let i=1;i<sequence.length;i++){assert.equal(ipcDelta(observers.get(sequence[i-1]),observers.get(sequence[i])).reason,null);preferenceWriteDelta(sequence[i-1].preferenceWrites,sequence[i].preferenceWrites,{runId:owned.runId,pid:bound.pid});}")
anchor="assert.equal(delta.commands.find(c=>c.command==='user_data_update_preference')?.attempts,1);";assert text.count(anchor)==1
strengthened=anchor+"\n      const categories=correlatePreferenceInterval(a.preferenceWrites,b.preferenceWrites,{runId:owned.runId,pid:bound.pid},delta.commands.find(c=>c.command==='user_data_update_preference')?.attempts??0);assert.equal(categories.theme,1);assert.equal(categories.other,0);"
text=text.replace(anchor,strengthened);save('verify-rf1123-backdrop.mjs',text)
# A separately named classification proof retains all other guards and never accepts the appearance cohort.
classified=text.replace(strengthened,"const transportAttempts=delta.commands.find(c=>c.command==='user_data_update_preference')?.attempts??0;\n      const categories=correlatePreferenceInterval(a.preferenceWrites,b.preferenceWrites,{runId:owned.runId,pid:bound.pid},transportAttempts);assert.equal(categories.theme,1);assert.equal(categories.other,0);\n      preferenceIntervals.push({index:sample.index,runId:owned.runId,pid:bound.pid,from:a.action,to:b.action,transportAttempts,backend:categories});")
assert classified!=text
classified=classified.replace('const samples=[];','assert(dark);const preferenceIntervals=[];const samples=[];').replace("scope:'windows-owned-backdrop-state-capture-binding'","scope:'windows-owned-preference-classification-binding'").replace('accepted:true,samples,sourceFiles','accepted:false,preferenceClassificationVerified:true,preferenceIntervals,samples,sourceFiles').replace("'validation.json'","'preference-classification.json'").replace('Three complete native journeys and three exact state/pixel bindings independently verified','Three state/pixel bindings plus fixed backend classifications verified; original aggregate appearance rule not accepted by this diagnostic')
save('verify-rf1123-preference-bindings.mjs',classified)
renderer=(w/'render-rf1123-backdrop.py').read_text(encoding='utf8').replace("'validation.json'","'preference-classification.json'").replace("validation['accepted'] and len(validation['samples']) == 3","not validation['accepted'] and validation['preferenceClassificationVerified'] and len(validation['samples']) == 3").replace('Three verified owned screenshots rendered','Three classified owned screenshots rendered; appearance acceptance requires its separate original verifier')
ast.parse(renderer);save('render-rf1123-preference-bindings.py',renderer)
for n in ['verify-rf1123-backdrop.mjs','verify-rf1123-preference-bindings.mjs']:
    p=subprocess.run(['node','--check',str(w/n)],capture_output=True);assert p.returncode==0,p.stderr
with (w/'rf1123-cohorts-prepared.json').open('x',encoding='utf8') as f:json.dump(dict(outputs=outputs,originalAggregateExactlyOneGuardRetained=True,originalGuardsStrengthenedWithBackendPrefixAndCounts=True,separateClassificationScopeNeverAcceptsAppearance=True,oldFailuresRetained=True,executed=False),f,indent=2)
print('Current capture/readers syntax checked; original aggregate rule retained; classification proof cannot accept appearance matrix')
