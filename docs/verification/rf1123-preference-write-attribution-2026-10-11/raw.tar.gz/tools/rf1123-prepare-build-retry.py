from pathlib import Path
import ast,hashlib,json
w=Path(__file__).parent;p=w/'rf1123-run-build.py';text=p.read_text(encoding='utf8')
assert text.count('rf1123-checks-retry1-20261011')==2
text=text.replace('rf1123-checks-retry1-20261011','rf1123-checks-retry2-20261011');ast.parse(text)
out=w/'rf1123-run-build-retry1.py'
with out.open('x',encoding='utf8') as f:f.write(text)
with (w/'rf1123-build-retry-prepared.json').open('x',encoding='utf8') as f:json.dump(dict(originalSha256=hashlib.sha256(p.read_bytes()).hexdigest(),newSha256=hashlib.sha256(out.read_bytes()).hexdigest(),onlyGreenReceiptStageChanged=True,fullSuccessfulCheckQueueStillRequired=True,executed=False),f,indent=2)
print('Build retry prepared; original unexecuted candidate retained; complete successful current checks still required')
