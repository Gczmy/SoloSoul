"""Invoke only after actually viewing all three PNGs from the requested cohort."""
from pathlib import Path
import datetime, hashlib, json, sys

w = Path(__file__).parent
mode = sys.argv[1]
assert mode in ['baseline', 'light-collapsed', 'dark-expanded', 'dark-collapsed']
c = w / f'ss-rf121-composed-window-backdrop-{mode}-rf1123-20261011'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
dark = mode.startswith('dark-')
value = load(c / ('preference-classification.json' if dark else 'validation.json'))
assert value['nativeSystemBackdropVerified'] and not value['fullMatrixAccepted']
if dark:
    assert not value['accepted'] and value['preferenceClassificationVerified']
else:
    assert value['accepted']
images = load(c / 'rendered-captures.json')
assert len(images) == 3 and [x['index'] for x in images] == [1, 2, 3]
for x in images:
    assert sha(Path(x['png'])) == x['pngSha256']
result = dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    actualImagesInspected=3, images=images,
    notes='实际逐图检查本组内容、侧栏、顶部栏及卡片边界；通知叠层按原截图保留。',
    classificationOnly=dark, wholeAppearanceAccepted=value['accepted'],
    fullMatrixAccepted=False, darkModeAndCaptionNativeGetterClaimed=False,
    systemSettingsChanged=False)
with (c / 'visual-review.json').open('x', encoding='utf8', newline='\n') as stream:
    json.dump(result, stream, indent=2, ensure_ascii=False)
    stream.write('\n')
print('Actual visual review recorded for ' + mode, flush=True)
