import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkPreferenceWrites } from '../../tauri/scripts/native-perf-preference-contract.mjs';

const w = path.dirname(fileURLToPath(import.meta.url));
const load = async (p) => JSON.parse(await readFile(p, 'utf8'));
assert((await load(path.join(w, 'rf1123-native-build-20261011/cohorts-complete.json'))).rf1123DiagnosticEligible);
const observations = [];
for (const mode of ['baseline', 'light-collapsed', 'dark-expanded', 'dark-collapsed']) {
  for (const index of [1, 2, 3]) {
    const dir = path.join(w, `ss-rf121-composed-window-backdrop-${mode}-rf1123-20261011/actual100/sample-${String(index).padStart(3, '0')}`);
    const p = path.join(dir, 'native-perf-consumed.json');
    const raw = await readFile(p);
    const marker = JSON.parse(raw);
    const identity = { runId: marker.runId, pid: marker.pid };
    const found = [];
    function walk(value) {
      if (!value || typeof value !== 'object') return;
      if (value.scope === 'windows-native-preference-writes') {
        found.push(checkPreferenceWrites(value, identity));
        return;
      }
      for (const next of Object.values(value)) walk(next);
    }
    const inputs = [];
    if (mode.startsWith('dark-')) {
      for (const filename of ['native-perf-surface-appearance-prepared.json', 'native-perf-surface-appearance-restored.json']) {
        const input = path.join(dir, filename);
        const data = await readFile(input);
        walk(JSON.parse(data));
        inputs.push({path: input, sha256: createHash('sha256').update(data).digest('hex')});
      }
    }
    found.sort((a, b) => a.atMs - b.atMs);
    const last = found.at(-1);
    observations.push({ mode, index, ...identity, source: p,
      sourceSha256: createHash('sha256').update(raw).digest('hex'), inputs, snapshotsSeen: found.length,
      lastObservedBackendAtMs: last?.atMs ?? null, rows: last?.attempts ?? [],
      counts: Object.fromEntries(['theme', 'backup-reminder', 'other'].map((kind) =>
        [kind, (last?.attempts ?? []).filter((row) => row.kind === kind).length])),
      wholeProcessFinalCountClaimed: false });
  }
}
assert.equal(new Set(observations.map((x) => x.runId)).size, 12);
assert(observations.filter((x) => x.mode.startsWith('dark-')).every((x) => x.snapshotsSeen > 0));
const result = { schemaVersion: 1, task: 'RF-1123',
  scope: 'current-owned-sdk-checkpoint-preference-observations', at: new Date().toISOString(),
  observations, oldExtraIntervalWriterEstablished: false, performanceMetrics: null,
  fullMatrixAccepted: false, originalFailuresRetained: true };
await writeFile(path.join(w, 'rf1123-real-preference-observations.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify(observations.map(({ mode, index, snapshotsSeen, counts }) =>
  ({ mode, index, snapshotsSeen, counts }))) + '\n');
