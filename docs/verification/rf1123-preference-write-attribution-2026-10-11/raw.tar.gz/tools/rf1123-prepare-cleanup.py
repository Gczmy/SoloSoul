"""Prepare exact owned cleanup only after all current diagnostic groups finish."""
from pathlib import Path
import ast, hashlib, json

w = Path(__file__).parent
s = w / 'rf1123-native-build-20261011'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def save(path, value):
    with path.open('x', encoding='utf8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

queue = load(s / 'cohorts-complete.json')
assert queue['rf1123DiagnosticEligible'] and len(queue['rows']) == 4
assert not queue['fullMatrixAccepted'] and not queue['applicationMaterialAccepted']
groups = []
for mode in ['baseline', 'light-collapsed', 'dark-expanded', 'dark-collapsed']:
    capture = w / f'ss-rf121-composed-window-backdrop-{mode}-rf1123-20261011'
    assert load(capture / 'actual100.receipt.json')['exitCode'] == 0
    filename = 'preference-classification.json' if mode.startswith('dark-') else 'validation.json'
    path = capture / filename
    value = load(path)
    assert len(value['samples']) == 3 and not value['fullMatrixAccepted']
    if mode.startswith('dark-'):
        assert value['accepted'] is False and value['preferenceClassificationVerified']
    else:
        assert value['accepted'] and value['nativeSystemBackdropVerified']
    groups.append(dict(label=mode, captureRoot=str(capture), terminal=True,
                       samples=value['samples'], readerPath=str(path), readerSha256=sha(path),
                       appearanceAccepted=not mode.startswith('dark-'),
                       readerScope=value.get('scope', 'complete independent binding')))
save(w / 'rf1123-mixed-cache-cleanup-plan.json', dict(
    cacheCleanupEligible=True, failedSamplesAccepted=False, groups=groups,
    plannedExactCacheTargets=96, fullMaterialMatrixAccepted=False,
    originalFourQueueAccepted=queue['originalFourCohortAggregateAccepted'],
    freshCimRequiredBeforeDeletion=True))
origin = w / 'rf1122-mixed-cleanup-owned.ps1'
text = origin.read_text(encoding='utf8').replace('rf1122', 'rf1123')
target = w / 'rf1123-mixed-cleanup-owned.ps1'
with target.open('x', encoding='utf8', newline='\n') as stream:
    stream.write(text)
save(w / 'rf1123-cleanup-tools-prepared.json', dict(
    origin=str(origin), originSha256=sha(origin), output=str(target), outputSha256=sha(target),
    exactScopeReplacementOnly=True, deletionExecuted=False,
    appearanceFailureAcceptanceChanged=False))
print('Prepared 96 exact owned cache paths; no deletion performed', flush=True)
