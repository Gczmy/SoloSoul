from pathlib import Path
import ast,hashlib,json
w=Path(__file__).parent;p=w/'rf1123-run-checks.py';text=p.read_text(encoding='utf8')
text=text.replace("s=w/'rf1123-checks-20261011'","s=w/'rf1123-checks-retry1-20261011'")
text=text.replace("'scripts/native-perf-preference.node.test.mjs'])==0","'scripts/native-perf-preference.node.test.mjs','scripts/run-node-tests.mjs'])==0")
ast.parse(text);out=w/'rf1123-run-checks-retry1.py'
with out.open('x',encoding='utf8') as f:f.write(text)
with (w/'rf1123-check-retry-prepared.json').open('x',encoding='utf8') as f:json.dump(dict(originalDriverSha256=hashlib.sha256(p.read_bytes()).hexdigest(),retryDriverSha256=hashlib.sha256(out.read_bytes()).hexdigest(),originalFailureRetained=True,fullCheckQueueRetained=True),f,indent=2)
print('Retry driver syntax checked; original failure and full check queue retained')
