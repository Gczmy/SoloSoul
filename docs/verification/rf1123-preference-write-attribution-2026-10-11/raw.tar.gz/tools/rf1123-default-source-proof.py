from pathlib import Path
import hashlib,json,subprocess
r=Path('D:/SoloSoul');w=Path(__file__).parent;load=lambda p:json.loads(p.read_text(encoding='utf8'))
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert base.startswith('0e7059c8e')
n='tauri/src-tauri/src/commands/settings.rs'
old=subprocess.check_output(['git','show',base+':'+n],cwd=r).decode('utf8').replace('\r\n','\n')
text=(r/n).read_text(encoding='utf8')
start='''    #[cfg(all(feature = "native-perf", target_os = "windows"))]
    let perf_attempt = crate::native_perf::preference_trace::begin(
        &payload.account_id,
        payload.preferences.keys().map(String::as_str),
    );
'''
end='''    #[cfg(all(feature = "native-perf", target_os = "windows"))]
    if let Some(attempt) = perf_attempt {
        attempt.complete();
    }
'''
assert text.count(start)==text.count(end)==1
assert text.replace(start,'',1).replace(end,'',1)==old
parent=load(w/'rf1122-native-build-20261011/sources.json')
assert all(hashlib.sha256((r/n).read_bytes()).hexdigest()==h for n,h in parent.items() if n.startswith('tauri/src/') or n in ['tauri/Cargo.toml','tauri/Cargo.lock','tauri/src-tauri/Cargo.toml','tauri/src-tauri/Cargo.lock','tauri/package.json','tauri/package-lock.json'])
with (w/'rf1123-default-source-proof.json').open('x',encoding='utf8') as f:json.dump(dict(base=base,defaultSettingsCommandBodyAndSignatureUnchanged=True,onlyNativePerfWindowsCfgObservationBlocksAdded=True,frontendSourceAndDependencyManifestsUnchanged=True,defaultBinaryByteEqualityClaimed=False),f,indent=2)
print('Default command source unchanged after removing only the two native-perf Windows observation blocks; frontend/manifests unchanged')
