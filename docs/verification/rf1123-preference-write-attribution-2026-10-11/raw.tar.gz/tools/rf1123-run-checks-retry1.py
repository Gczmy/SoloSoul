from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,time
r=Path('D:/SoloSoul');w=Path(__file__).parent;s=w/'rf1123-checks-retry1-20261011';s.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cache=r/'build/rf312-maintenance-20261009';env=os.environ.copy();env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),CARGO_HOME=str(cache/'cargo-home'),CARGO_TARGET_DIR=str(cache/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(cache/'ort-cache'),npm_config_cache=str(cache/'npm-cache'),PDFIUM_LIBRARY_PATH=str(r/'tauri/src-tauri/resources/pdfium/pdfium.dll'))
env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','')
for n in ['TAURI_CONFIG','TAURI_ANDROID_PROJECT_PATH','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS']:env.pop(n,None)
def save(n,v):
    with (s/n).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
sources=None
def run(name,cmd):
    start=time.monotonic()
    with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=r/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',dict(pid=p.pid,command=cmd));print(name,'live',p.pid,flush=True);code=p.wait()
    changes=[] if sources is None else [n for n,h in sources.items() if sha(r/n)!=h]
    save(name+'.receipt.json',dict(command=cmd,exitCode=code,elapsedSeconds=time.monotonic()-start,sourceFreezeApplicable=sources is not None,sourceUnchanged=not changes,changedSources=changes,at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    print(name,'terminal',code,flush=True);assert not changes;return code
assert run('format-rust',['cargo','fmt','--all'])==0
assert run('format-node',['npx.cmd','--no-install','prettier','--write','scripts/native-perf-preference-contract.mjs','scripts/native-perf-preference.node.test.mjs','scripts/run-node-tests.mjs'])==0
names=list(load(w/'rf1122-native-build-20261011/sources.json'))
new=['tauri/src-tauri/src/native_perf/preference_trace.rs','tauri/scripts/native-perf-preference-contract.mjs','tauri/scripts/native-perf-preference.node.test.mjs']
assert all(n not in names for n in new);names.extend(new)
sources={n:sha(r/n) for n in names};assert len(sources)==1837;save('sources.json',sources)
for n in new+['tauri/src-tauri/src/commands/settings.rs','tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/src/native_perf/sdk_surface_appearance.rs']:
    target=s/'executed-sources'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((r/n).read_bytes())
checks=[
 ('workspace-fmt',['cargo','fmt','--all','--check']),
 ('node-target',['node','--test','scripts/native-perf-preference.node.test.mjs']),
 ('native-clippy',['cargo','clippy','--locked','-p','solo_soul','--all-targets','--features','native-perf','--','-D','warnings']),
 ('native-tests',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','native_perf::','--','--nocapture']),
 ('workspace-clippy',['cargo','clippy','--locked','--','-D','warnings']),
 ('workspace-tests',['cargo','test','--locked','--verbose']),
 ('node-all',['npm.cmd','run','test:node']),
]
for name,cmd in checks:assert run(name,cmd)==0,name
native=(s/'native-tests.stdout.log').read_text(encoding='utf8');assert '136 passed; 0 failed; 0 ignored;' in native
text=(s/'workspace-tests.stdout.log').read_text(encoding='utf8');counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)
assert counts and all(int(b)==int(e)==0 for a,b,c,d,e in counts)
totals=dict(passed=sum(int(a) for a,b,c,d,e in counts),failed=sum(int(b) for a,b,c,d,e in counts),ignored=sum(int(c) for a,b,c,d,e in counts),ignoredNames=re.findall(r'^test (.*?) \.\.\. ignored.*$',text,re.M))
assert totals['passed']==1874 and totals['ignored']==3
assert totals['ignoredNames']==load(w/'rf1122-green-checks-20261011/workspace-totals.json')['ignoredNames']
save('workspace-totals.json',totals);save('checks-complete.json',dict(success=True,sourceCount=1837,nativeTests=136,workspace=totals,frontendProductionSourceChanged=False,defaultObserverIncluded=False))
print('RF-1123 complete checks successful',flush=True)
