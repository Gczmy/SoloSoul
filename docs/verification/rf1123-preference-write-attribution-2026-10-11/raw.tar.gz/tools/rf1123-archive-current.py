"""Archive actual terminal RF-1123 results only; never close or commit the ledger."""
from pathlib import Path
import datetime, hashlib, io, json, subprocess, tarfile

r = Path('D:/SoloSoul')
w = Path(__file__).parent
green = w / 'rf1123-checks-retry2-20261011'
s = w / 'rf1123-native-build-20261011'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def save(path, value):
    with path.open('x', encoding='utf8', newline='\n') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')

checks = load(green / 'checks-complete.json')
assert checks['success'] and checks['sourceCount'] == 1837 and checks['nativeTests'] == 136
assert checks['workspace']['passed'] == 1874 and checks['workspace']['failed'] == 0
assert checks['workspace']['ignored'] == 3 and checks['node']['fail'] == 0
sources = load(s / 'sources.json')
assert sources == load(green / 'sources.json') and len(sources) == 1837
assert all(sha(r / n) == h for n, h in sources.items())
base = '0e7059c8ee8df5856c049be33e161728e3f5404d'
assert load(s / 'starting-state.json')['head'] == base
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=r, text=True).strip() == base
proof = load(w / 'rf1123-default-source-proof.json')
assert proof['base'] == base and proof['defaultSettingsCommandBodyAndSignatureUnchanged']
assert proof['frontendSourceAndDependencyManifestsUnchanged'] and not proof['defaultBinaryByteEqualityClaimed']
first = w / 'rf1123-checks-20261011'
restricted = w / 'rf1123-checks-retry1-20261011'
assert load(first / 'native-clippy.receipt.json')['exitCode'] == 101
assert 'E0433' in (first / 'native-clippy.stderr.log').read_text(encoding='utf8')
assert load(restricted / 'native-tests.receipt.json')['exitCode'] == 101
assert '123 passed; 13 failed; 0 ignored;' in (restricted / 'native-tests.stdout.log').read_text(encoding='utf8')
assert load(s / 'native-release-build.receipt.json')['exitCode'] == 0
pkg = load(s / 'runtime-package.json')
assert pkg['currentNativeTests'] == 136 and pkg['windowsGuiSubsystem'] == 2
assert sha(Path(pkg['exe'])) == pkg['sha256'] and len(pkg['resources']) == 94
for resource in pkg['resources']:
    assert sha(Path(resource['source'])) == sha(Path(resource['copy'])) == resource['sha256']
queue = load(s / 'cohorts-complete.json')
assert queue['rf1123DiagnosticEligible'] and len(queue['rows']) == 4
assert not queue['fullMatrixAccepted'] and not queue['applicationMaterialAccepted']
groups = []
for mode in ['baseline', 'light-collapsed', 'dark-expanded', 'dark-collapsed']:
    c = w / f'ss-rf121-composed-window-backdrop-{mode}-rf1123-20261011'
    assert load(c / 'actual100.receipt.json')['exitCode'] == 0
    dark = mode.startswith('dark-')
    value = load(c / ('preference-classification.json' if dark else 'validation.json'))
    assert len(value['samples']) == 3 and value['nativeSystemBackdropVerified']
    assert not value['fullMatrixAccepted']
    correction = c / 'visual-review-after-actual-inspection.json'
    visual = load(correction if correction.exists() else c / 'visual-review.json')
    assert visual['actualImagesInspected'] == 3
    for image in visual['images']:
        assert sha(Path(image['png'])) == image['pngSha256']
    if dark:
        assert not value['accepted'] and value['preferenceClassificationVerified']
        assert len(value['preferenceIntervals']) == 6
        for interval in value['preferenceIntervals']:
            delta = interval['backend']
            assert delta['allCompleted'] and delta['theme'] == 1 and delta['other'] == 0
            assert delta['total'] == interval['transportAttempts'] == len(delta['attempts'])
            assert delta['total'] == delta['theme'] + delta['backupReminder']
    else:
        assert value['accepted']
    groups.append(dict(mode=mode, samples=3, actualPngsInspected=3,
        originalAggregateExitCode=load(s / f'verify-{mode}.receipt.json')['exitCode'],
        classificationOnly=dark, intervals=value.get('preferenceIntervals')))
cleanup = load(w / 'rf1123-mixed-cache-cleanup.json')
assert len(cleanup['removedCachePaths']) == 96 and len(cleanup['applicationLogs']) == 12
assert len(cleanup['linksUnlinked']) == 12 and cleanup['preservedBytesVerified']
assert cleanup['matchingOwnedIdentitiesLive'] == cleanup['processesTerminatedByThisTool'] == 0
assert all(not Path(p).exists() for p in cleanup['removedCachePaths'])
for item in cleanup['preservedVaultAndRootFiles']:
    assert sha(Path(item['path'])) == item['sha256']
for item in cleanup['applicationLogs']:
    assert sha(Path(item['copy'])) == item['sha256']

files = {}
allowed = {'.json', '.log', '.py', '.mjs', '.ps1', '.rs', '.toml', '.lock', '.png', '.bgra', '.md', '.txt'}
def add(path, name):
    assert path.is_file() and not path.is_symlink() and not (path.lstat().st_file_attributes & 0x400)
    assert name not in files
    files[name] = path
def shallow(directory, prefix):
    for path in directory.iterdir():
        if path.is_file() and path.suffix in allowed:
            add(path, prefix + '/' + path.name)
for directory, prefix in [(first, 'initial-checks'), (restricted, 'restricted-checks'), (green, 'green-checks'), (s, 'current-build')]:
    shallow(directory, prefix)
    executed = directory / 'executed-sources'
    if executed.exists():
        for path in executed.rglob('*'):
            if path.is_file() and path.suffix in allowed:
                add(path, prefix + '/executed-sources/' + path.relative_to(executed).as_posix())
for mode in ['baseline', 'light-collapsed', 'dark-expanded', 'dark-collapsed']:
    c = w / f'ss-rf121-composed-window-backdrop-{mode}-rf1123-20261011'
    shallow(c, 'windows/' + mode)
    shallow(c / 'actual100', 'windows/' + mode + '/actual100')
    for index in [1, 2, 3]:
        shallow(c / 'actual100' / f'sample-{index:03}', f'windows/{mode}/actual100/sample-{index:03}')
logs = w / 'application-logs-rf1123-mixed'
for path in logs.rglob('*'):
    if path.is_file():
        add(path, 'application-logs/' + path.relative_to(logs).as_posix())
for path in w.iterdir():
    if path.is_file() and path.suffix in allowed and 'rf1123' in path.name:
        add(path, 'tools/' + path.name)
for name in ['tauri/src-tauri/src/native_perf/preference_trace.rs', 'tauri/scripts/native-perf-preference-contract.mjs', 'tauri/scripts/native-perf-preference.node.test.mjs', 'tauri/src-tauri/src/commands/settings.rs', 'tauri/src-tauri/src/native_perf.rs', 'tauri/src-tauri/src/native_perf/sdk_surface_appearance.rs', 'tauri/scripts/run-node-tests.mjs']:
    add(r / name, 'final-sources/' + name)
stem = 'rf1123-preference-write-attribution-2026-10-11'
out = r / 'docs/verification' / stem
out.mkdir(exist_ok=False)
(out / '.gitattributes').write_text('* -text -diff\n', encoding='utf8')
members = []
with tarfile.open(out / 'raw.tar.gz', 'w:gz') as archive:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
        members.append(dict(path=name, size=len(data), sha256=hashlib.sha256(data).hexdigest()))
assert (out / 'raw.tar.gz').stat().st_size < 50_000_000
with tarfile.open(out / 'raw.tar.gz', 'r:gz') as archive:
    assert set(archive.getnames()) == {item['path'] for item in members}
    for item in members:
        data = archive.extractfile(item['path']).read()
        assert len(data) == item['size'] and hashlib.sha256(data).hexdigest() == item['sha256']
save(out / 'index.json', dict(task='RF-1123', archiveSha256=sha(out / 'raw.tar.gz'),
    members=members, allMembersVerified=True,
    excluded=['executables', 'private Vault', 'models', 'caches', 'APK', 'JNI', 'private Android backup']))
save(r / 'docs/verification' / (stem + '.json'), dict(task='RF-1123', status='verification-complete',
    base=base, at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Optional Windows native preference fixed categories; appearance aggregate rule retained',
    sourceCount=1837, checks=checks, originalFailuresRetained=True, defaultSourceProof=proof,
    runtime=dict(sha256=pkg['sha256'], resources=94, subsystem=2), groups=groups,
    queue=queue, cleanup=cleanup, fullRF121Accepted=False, fullRF312Accepted=False,
    systemSettingsChanged=False, ledgerClosed=False, commitCreated=False,
    archive=dict(path=stem + '/raw.tar.gz', sha256=sha(out / 'raw.tar.gz'),
                 members=len(members), allMembersVerified=True)))
print('Terminal evidence archived and reread; ledger and Git remain separate required steps', flush=True)
