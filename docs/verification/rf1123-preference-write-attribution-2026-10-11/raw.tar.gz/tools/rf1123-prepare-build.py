from pathlib import Path
import ast,hashlib,json
w=Path(__file__).parent;p=w/'rf1122-run-build.py';text=p.read_text(encoding='utf8')
text=text.replace('rf1122-native-build-20261011','rf1123-native-build-20261011').replace('ss-rf1122-backdrop-runtime-20261011','ss-rf1123-backdrop-runtime-20261011')
start=text.index("parent=load(w/'rf1121-checks-20261011/green-sources.json')")
end=text.index("save('sources.json',sources)",start)
text=text[:start]+'''parent=load(w/'rf1122-native-build-20261011/sources.json')
green=w/'rf1123-checks-retry1-20261011'
assert load(green/'checks-complete.json')['success']
sources=load(green/'sources.json')
assert len(sources)==1837 and all(sha(root/n)==h for n,h in sources.items())
assert set(sources)-set(parent)=={'tauri/src-tauri/src/native_perf/preference_trace.rs','tauri/scripts/native-perf-preference-contract.mjs','tauri/scripts/native-perf-preference.node.test.mjs'}
assert {n for n,h in parent.items() if h!=sources[n]}=={'tauri/src-tauri/src/commands/settings.rs','tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/src/native_perf/sdk_surface_appearance.rs','tauri/scripts/run-node-tests.mjs'}
'''+text[end:]
text=text.replace("green=w/'rf1122-green-checks-20261011'","green=w/'rf1123-checks-retry1-20261011'").replace('132 passed; 0 failed; 0 ignored;','136 passed; 0 failed; 0 ignored;').replace('currentNativeTests=132','currentNativeTests=136').replace('source1834','source1837')
text=text.replace("old=load(w/'rf121-backdrop-checks-after-picker-20261011/runtime-package.json')","old=load(w/'rf1122-native-build-20261011/runtime-package.json')")
needle="b'windows-native-maintenance-admission']:assert marker in data,marker"
assert text.count(needle)==1;text=text.replace(needle,"b'windows-native-maintenance-admission',b'windows-native-preference-writes']:assert marker in data,marker")
ast.parse(text);target=w/'rf1123-run-build.py'
with target.open('x',encoding='utf8') as f:f.write(text)
with (w/'rf1123-build-prepared.json').open('x',encoding='utf8') as f:json.dump(dict(originalDriverSha256=hashlib.sha256(p.read_bytes()).hexdigest(),newDriverSha256=hashlib.sha256(target.read_bytes()).hexdigest(),sourceCount=1837,requiresFullCurrentSuccessfulCheckQueue=True,executed=False),f,indent=2)
print('Build prepared; requires current full successful checks; no build executed')
