from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,time
r=Path('D:/SoloSoul');w=Path(__file__).parent;old=w/'rf1123-checks-retry1-20261011';s=w/'rf1123-checks-retry2-20261011';s.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):
    with (s/n).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
sources=load(old/'sources.json');assert len(sources)==1837 and all(sha(r/n)==h for n,h in sources.items())
assert load(old/'native-tests.receipt.json')['exitCode']==101
save('sources.json',sources)
reused=[]
for name in ['workspace-fmt','node-target','native-clippy']:
    v=load(old/(name+'.receipt.json'));assert v['exitCode']==0 and v['sourceUnchanged']
    for suffix in ['receipt.json','stdout.log','stderr.log']:
        origin=old/(name+'.'+suffix);copy=s/origin.name;shutil.copy2(origin,copy);assert sha(origin)==sha(copy)
        reused.append(dict(source=str(origin),copy=str(copy),sha256=sha(copy),notReexecuted=True))
save('reused-green-receipts.json',dict(sourceUnchanged=True,entries=reused,originalFullNativeFailureRetained=True,originalFailedNativePassed=123,originalFailedNativeFailed=13))
cache=r/'build/rf312-maintenance-20261009';env=os.environ.copy();env.update(TEMP=str(cache/'tmp'),TMP=str(cache/'tmp'),CARGO_HOME=str(cache/'cargo-home'),CARGO_TARGET_DIR=str(cache/'cargo-target'),CARGO_BUILD_JOBS='1',ORT_CACHE_DIR=str(cache/'ort-cache'),npm_config_cache=str(cache/'npm-cache'),PDFIUM_LIBRARY_PATH=str(r/'tauri/src-tauri/resources/pdfium/pdfium.dll'))
env['PATH']='C:/Program Files/Git/usr/bin;'+env.get('PATH','')
for n in ['TAURI_CONFIG','TAURI_ANDROID_PROJECT_PATH','CARGO_ENCODED_RUSTFLAGS','RUSTFLAGS']:env.pop(n,None)
def run(name,cmd):
    assert all(sha(r/n)==h for n,h in sources.items());start=time.monotonic()
    with (s/(name+'.stdout.log')).open('xb') as out,(s/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=r/'tauri',env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',dict(pid=p.pid,command=cmd));print(name,'live',p.pid,flush=True);code=p.wait()
    changes=[n for n,h in sources.items() if sha(r/n)!=h]
    save(name+'.receipt.json',dict(command=cmd,exitCode=code,elapsedSeconds=time.monotonic()-start,sourceUnchanged=not changes,changedSources=changes,at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    print(name,'terminal',code,flush=True);assert not changes;return code
for name,cmd in [
 ('native-tests',['cargo','test','--locked','-p','solo_soul','--lib','--features','native-perf','native_perf::','--','--nocapture']),
 ('workspace-clippy',['cargo','clippy','--locked','--','-D','warnings']),
 ('workspace-tests',['cargo','test','--locked','--verbose']),
 ('node-all',['npm.cmd','run','test:node']),
]:assert run(name,cmd)==0,name
assert '136 passed; 0 failed; 0 ignored;' in (s/'native-tests.stdout.log').read_text(encoding='utf8')
text=(s/'workspace-tests.stdout.log').read_text(encoding='utf8');counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)
assert counts and all(int(b)==int(e)==0 for a,b,c,d,e in counts)
totals=dict(passed=sum(int(a) for a,b,c,d,e in counts),failed=sum(int(b) for a,b,c,d,e in counts),ignored=sum(int(c) for a,b,c,d,e in counts),ignoredNames=re.findall(r'^test (.*?) \.\.\. ignored.*$',text,re.M))
assert totals['passed']==1874 and totals['ignored']==3
assert totals['ignoredNames']==load(w/'rf1122-green-checks-20261011/workspace-totals.json')['ignoredNames']
save('workspace-totals.json',totals)
node=(s/'node-all.stdout.log').read_text(encoding='utf8');nodeTotals={k:int(re.search('ℹ '+k+r' (\d+)',node).group(1)) for k in ['tests','pass','fail','skipped','cancelled','todo']}
assert nodeTotals['fail']==nodeTotals['cancelled']==nodeTotals['todo']==0
assert 'concurrent theme and reminder writes remain two transport calls and separate categories' in node
save('node-totals.json',nodeTotals);save('checks-complete.json',dict(success=True,sourceCount=1837,nativeTests=136,workspace=totals,node=nodeTotals,reusedSuccessfulChecksOnly=True,originalFailuresRetained=True,frontendProductionSourceChanged=False,defaultObserverIncluded=False))
print('RF-1123 full checks successful; original restricted execution failure retained',flush=True)
