from pathlib import Path
import ast,datetime,hashlib,json,os,subprocess,time
w=Path(__file__).parent;r=w.parent.parent;s=w/'rf1123-native-build-20261011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v):
    with (s/n).open('x',encoding='utf8',newline='\n') as f:json.dump(v,f,indent=2);f.write('\n')
sources=load(s/'sources.json');package=load(s/'runtime-package.json')
assert len(sources)==1837 and package['currentNativeTests']==136
for n in ['native-clippy','native-tests','native-release-build']:assert load(s/(n+'.receipt.json'))['exitCode']==0
def verify():
    assert all(sha(r/n)==h for n,h in sources.items())
    for key,digest in [('exe','sha256'),('helperExe','helperSha256'),('activationExe','activationSha256'),('helperSource','helperSourceSha256'),('activationSource','activationSourceSha256')]:assert sha(Path(package[key]))==package[digest]
    for v in package['resources']:assert sha(Path(v['source']))==sha(Path(v['copy']))==v['sha256']
verify();env=os.environ.copy();env.update(TEMP=str(s),TMP=str(s));env.pop('PDFIUM_LIBRARY_PATH',None)
def run(n,cmd):
    verify();start=time.monotonic()
    with (s/(n+'.stdout.log')).open('xb') as out,(s/(n+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(cmd,cwd=r,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(n+'.live.json',dict(pid=p.pid,command=cmd,at=datetime.datetime.now(datetime.timezone.utc).isoformat()));print(n,'PID',p.pid,flush=True);code=p.wait()
    verify();save(n+'.receipt.json',dict(exitCode=code,pid=p.pid,command=cmd,elapsedSeconds=time.monotonic()-start,sourceUnchanged=True,resourcesUnchanged=True))
    print(n,'terminal',code,flush=True);return code
rows=[]
for mode in ['baseline','light-collapsed','dark-expanded','dark-collapsed']:
    text=(w/'rf1117-session-before-journeys.py').read_text(encoding='utf8');old="stage/'rf1117-session-before-journeys.json'"
    assert text.count(old)==1;text=text.replace(old,"stage/'rf1123-native-build-20261011/session-before-"+mode+".json'");ast.parse(text)
    probe=w/('rf1123-backdrop-session-before-'+mode+'.py')
    with probe.open('x',encoding='utf8',newline='\n') as f:f.write(text)
    assert run('session-'+mode,['C:/Python314/python.exe',str(probe)])==0
    session=load(s/('session-before-'+mode+'.json'))
    if session.get('connectionState')!=0 or not session.get('inputDesktopAvailable'):
        rows.append(dict(mode=mode,executed=False,reason='caller-desktop-unavailable',session=session));break
    capture=run('capture-'+mode,['C:/Python314/python.exe',str(w/'run-rf1123-backdrop.py'),'--'+mode])
    primary=run('verify-'+mode,['node',str(w/'verify-rf1123-backdrop.mjs'),'--'+mode])
    classified=None;rendered=None;diagnostic=False
    if mode.startswith('dark-') and capture==0:
        classified=run('classify-'+mode,['node',str(w/'verify-rf1123-preference-bindings.mjs'),'--'+mode])
        if classified==0:
            rendered=run('render-classified-'+mode,['C:/Python314/python.exe',str(w/'render-rf1123-preference-bindings.py'),'--'+mode])
            # Only this separately scoped task is eligible. The original appearance result is retained.
            originalFailureKnown=primary==0 or (primary==1 and '!== 1' in (s/('verify-'+mode+'.stderr.log')).read_text(encoding='utf8'))
            diagnostic=rendered==0 and originalFailureKnown
    elif capture==0 and primary==0:
        rendered=run('render-'+mode,['C:/Python314/python.exe',str(w/'render-rf1123-backdrop.py'),'--'+mode]);diagnostic=rendered==0
    row=dict(mode=mode,executed=True,captureExitCode=capture,originalAggregateVerifierExitCode=primary,classificationVerifierExitCode=classified,rendererExitCode=rendered,rf1123DiagnosticEligible=diagnostic)
    rows.append(row);save('cohort-'+mode+'.json',row)
    if not diagnostic:break
success=len(rows)==4 and all(v.get('rf1123DiagnosticEligible') for v in rows)
originalAccepted=len(rows)==4 and all(v.get('captureExitCode')==v.get('originalAggregateVerifierExitCode')==0 for v in rows)
save('cohorts-complete.json',dict(rf1123DiagnosticEligible=success,originalFourCohortAggregateAccepted=originalAccepted,rows=rows,sourceUnchanged=True,fullMatrixAccepted=False,applicationMaterialAccepted=False,systemSettingsChanged=False))
print('RF-1123 diagnostic queue terminal: '+str(success)+'; original four-cohort aggregate acceptance: '+str(originalAccepted),flush=True)
raise SystemExit(0 if success else 1)
