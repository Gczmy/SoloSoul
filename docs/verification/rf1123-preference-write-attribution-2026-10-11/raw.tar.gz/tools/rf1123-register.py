from pathlib import Path
p=Path('D:/SoloSoul/docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md');s=p.read_text(encoding='utf8')
assert s.count('任务总数：**312**（P1：56；P2：255；P3：1）')==1
s=s.replace('任务总数：**312**（P1：56；P2：255；P3：1）','任务总数：**313**（P1：56；P2：256；P3：1）',1)
s=s.replace('已关闭：**302 / 312**；','已关闭：**302 / 313**；',1).replace('暂缓：0；进行中：0；待执行：6。','暂缓：0；进行中：1；待执行：6。',1).replace('RF-1121、RF-1122（','RF-1121、RF-1122、RF-1123（',1)
start=s.index('- 当前处理：');end=s.index('\n',start)
s=s[:start]+'- 当前处理：RF-1123非默认原生偏好写入固定类别归因；保留RF-121深色两组的聚合计数失败，完整平台前置不解除。'+s[end:]
row='| 312 | [RF-1122](#rf-1122) | P2 | 原生验证 consumed 标记完整后独占发布 | 无（Windows实际补验发现） | [x] 完成 |'
assert s.count(row)==1;s=s.replace(row,row+'\n| 313 | [RF-1123](#rf-1123) | P2 | 原生偏好写入按固定类别独立归因 | 无（RF-121额外写入来源未明） | [~] 进行中 |',1)
card='''### RF-1123

**原生偏好写入按固定类别独立归因** · P2 · 来源：RF-121两组深色聚合计数失败

- **入口：**仅Windows非默认native-perf模块与user_data_update_preference条件观测点；固定外观SDK检查点。
- **现状：**IPC计数只记录命令名；主题保存和备份提醒共用该命令。现有证据无法唯一归因2次写入，不修改业务行为或原失败。
- **执行：**在后端入口将单键theme、单键lastBackupReminderAt和其余请求归为固定枚举；只保留类别、序号、单调时间、完成状态和隔离账户匹配布尔值，禁止保存账户/键字符串/值/错误文本。默认构建不含观察器。原fetch计数合同不变，未知/混合载荷归other，边界、并发或不足证据保持不可接受。
- **验收：**实际类别/失败/并发/溢出和独立严格解析回归，默认R及native格式/Clippy/全量检查；新GUI及原完整行程真实补验，独立类别计数和前端总调用数相互核对。原聚合校验及失败保持，不能按本项提前关闭RF-121/312；原件归档，一项一提交，不推送。

'''
assert s.count('## 7. 每项执行记录模板')==1;s=s.replace('## 7. 每项执行记录模板',card+'## 7. 每项执行记录模板',1)
p.write_text(s,encoding='utf8',newline='\n')
print('RF-1123 registered as active; 302/313 closed; full native matrix and original failures unchanged')
