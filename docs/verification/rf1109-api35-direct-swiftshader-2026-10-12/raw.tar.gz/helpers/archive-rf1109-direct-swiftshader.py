from pathlib import Path
import datetime, hashlib, importlib.util, json, tarfile

r=Path('D:/SoloSoul'); b=Path(__file__).parent.resolve()
s=b/'api35-home-direct-swiftshader-20261012'; boot=b/'api35-direct-swiftshader-20261012'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(v,f,indent=2)
spec=importlib.util.spec_from_file_location('home',r/'tauri/scripts/android-home-native-regression.py')
home=importlib.util.module_from_spec(spec);spec.loader.exec_module(home)
v=load(s/'verification.json'); assert not v['accepted'] and len(v['results'])==4
gpu=(boot/'logcat-after-baseline-supported.log').read_text(encoding='utf-8');assert 'WebGL1 blocklisted' in gpu and 'EGL_BAD_CONFIG' in gpu
art=load(b/'rf1126-legacy-theme-build-20261011/current-apks.json')
assert len(art['sourceFiles'])==1837
provenance=load(b/'rf1131-source-provenance-20261012.json')
assert provenance['artifactBuildSourceFiles']==art['sourceFiles']
assert len(provenance['changedSourceFiles'])==5 and provenance['androidBuildRelevantSourcesEqualCurrent']
for name,digest in provenance['runtimeValidationSourceFiles'].items():assert sha(r/name)==digest,name
for row in art['files']:assert sha(Path(row['copy']))==row['sha256']
stop=load(boot/'stop.receipt.json'); assert stop['ownedProcessExited'] and stop['settingsRestored'] and stop['dedicatedPortsFree']
rows=[]; backups=[]
for receipt in v['results']:
    c=s/(receipt['scenario']+'-'+receipt['mode']); report=load(c/'report.json')
    assert receipt['exitCode']==1 and not receipt['accepted'] and receipt['restored']
    assert receipt['settingsBefore']==receipt['settingsAfter'] and receipt['reportSha256']==sha(c/'report.json')
    assert not report['passed'] and report['restored'] and report['blurRestored'] and report['notificationPermissionRestored']
    assert not any(report.get(k) for k in ['restoreError','blurRestoreError','notificationRestoreError','nightModeRestoreError','fontScaleRestoreError'])
    raw=(c/'native.log').read_text(encoding='utf-8'); assert 'INSTRUMENTATION_STATUS_CODE: -2' in raw and 'FAILURES!!!' in raw
    assert 'enhanced-light:' in raw and '\"ready\":false' in raw and '\"canvasVisible\":false' in raw and 'OK (1 test)' not in raw
    try: home.verify_native(raw,home.METHOD)
    except RuntimeError: pass
    else: raise AssertionError('Original strict reader accepted a failed test')
    assert not (c/'cold-native.log').exists() and not report.get('coldPassed')
    original=c/'private-data-before.tar'; restored=c/'private-data-restored.tar'
    inv=home.inventory(original,require_empty=True); assert inv==home.inventory(restored,require_empty=True)
    assert len(inv)==249==report['restoreVerification']['entries']
    for p in [original,restored]:backups.append({'path':str(p.resolve()),'sha256':sha(p),'bytes':p.stat().st_size})
    inventory_digest=hashlib.sha256(json.dumps(inv,sort_keys=True,default=str).encode()).hexdigest()
    rows.append({'scenario':receipt['scenario'],'mode':receipt['mode'],'nativeTestsAttempted':1,'nativePassed':False,
        'nativeFailure':'enhanced-light actual canvas not ready/visible','coldSecondPhaseExecuted':False,
        'restoredEntries':len(inv),'beforeAndAfterInventorySha256':inventory_digest,'privateContentsLinksModesMatch':True,
        'settingsRestored':True,'notificationPermissionRestored':True,'elapsedSeconds':receipt['elapsedSeconds'],
        'nativeLogSha256':sha(c/'native.log'),'reportSha256':sha(c/'report.json')})
assert len(backups)==8
save(s/'independent-validation.json',{'accepted':False,'independentValidationSucceeded':True,'results':rows,
    'nativeTestsAttempted':4,'nativePassed':0,'nativeFailed':4,'coldSecondPhasesExecuted':0,
    'sourcesVerified':1837,'apks':art['files'],'cleanupEligibleExactFiles':backups})
save(b/'rf1109-direct-swiftshader-cleanup-plan.json',{'files':backups,'archiveBeforeDeletionRequired':True})
review=['baseline-supported/device-files/local-light.png','baseline-supported/device-files/failure.png']
save(s/'visual-review.json',{'imagesActuallyInspected':[{'path':n,'sha256':sha(s/n)} for n in review],
    'observation':'Local light home text is visible. Enhanced failure frame shows shield fallback, not a ready liquid canvas.',
    'allEightImagesHumanReviewed':False,'nativeAcceptance':False})
name='rf1109-api35-direct-swiftshader-2026-10-12'; target=r/'docs/verification'/name;target.mkdir(exist_ok=False)
(target/'.gitattributes').write_text('raw.tar.gz binary\n',encoding='utf-8')
members={}
def add(prefix,p):
    assert p.is_file() and p.suffix!='.tar' and not p.is_symlink()
    members[prefix]={'source':p,'bytes':p.stat().st_size,'sha256':sha(p)}
for prefix,parent in [('native',s),('boot',boot)]:
    for p in sorted(parent.rglob('*')):
        if p.is_file() and p.suffix!='.tar':add(prefix+'/'+p.relative_to(parent).as_posix(),p)
for n in ['boot-rf1109-api35-direct-swiftshader.py','verify-rf1109-api35-direct-swiftshader.py','stop-rf1109-direct-swiftshader.py','archive-rf1109-direct-swiftshader.py']:
    add('helpers/'+n,b/n)
add('build-provenance/rf1131-source-provenance-20261012.json',b/'rf1131-source-provenance-20261012.json')
for n in ['current-apks.json','source-and-checks-proof.json','unchanged-native-assets.json']:
    add('build-provenance/'+n,b/'rf1126-legacy-theme-build-20261011'/n)
for n in ['tauri/scripts/android-home-native-regression.py','tauri/src-tauri/src/lib.rs','tauri/src-tauri/src/native_perf.rs','tauri/src-tauri/gen/android/app/src/androidTest/java/com/solosoul/app/AndroidHomeInstrumentedTest.kt']:
    add('source/'+n,r/n)
archive=target/'raw.tar.gz'
with tarfile.open(archive,'x:gz') as f:
    for n,row in sorted(members.items()):f.add(row['source'],arcname=n,recursive=False)
with tarfile.open(archive,'r:gz') as f:
    assert set(f.getnames())==set(members)
    for m in f.getmembers():
        row=members[m.name]; data=f.extractfile(m).read(); assert m.isfile() and len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
save(target/'index.json',{'archive':archive.name,'archiveSha256':sha(archive),'memberCount':len(members),
    'members':[{k:v for k,v in dict(path=n,**row).items() if k!='source'} for n,row in sorted(members.items())],
    'allMembersReadBackVerified':True,'privateBackupsAndApksExcluded':True})
save(r/'docs/verification'/f'{name}.json',{'task':'RF-1109','accepted':False,'status':'waiting-for-API35-WebGL-capability',
    'productionOrTestCodeChanged':False,'sourceHead':'8448d87fb','softwareRendering':True,'hardwareAppearanceAccepted':False,'inheritedHostGpuBootLogLabelIsNotAcceptance':True,'artifactBuildSourcesEqualCurrent':False,'sourceProvenance':provenance,
    'nativeTestsAttempted':4,'nativeFailed':4,'nativePassed':0,'nativeSkipped':0,'coldSecondPhasesExecuted':0,
    'results':rows,'provider':'com.android.webview 124.0.6367.219','api':35,'abi':'x86_64',
    'surfaceFlingerRenderer':'Android Emulator OpenGL ES Translator (Google SwiftShader)',
    'actualLogcat':'WebGL1 blocklisted; EGL_BAD_CONFIG for ES3.1/3.2 requests',
    'uniqueCausalAttributionEstablished':False,'allSourceAndApkHashesVerified':True,
    'sourcesVerified':1837,'allPrivateDataAndSettingsRestored':True,'ownedEmulatorGracefullyExited':True,
    'fullRF121Accepted':False,'RF312Accepted':False,'goalStillActive':True,
    'archiveSha256':sha(archive),'rawMembers':len(members),'index':name+'/index.json',
    'priorFailuresUnmodified':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print('Four native failures and complete restoration independently verified; archived',len(members),'raw members')
