from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path('D:/SoloSoul');base=Path(__file__).parent.resolve()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=base/'rf1111-home-pixel-test-build2/current-apks.json'
artifacts=load(parent);sources=artifacts['sourceFiles'];assert len(sources)==1830
files={row['kind']:row for row in artifacts['files']}
def verify():
 for name,digest in sources.items():assert sha(root/name)==digest,name
 for row in files.values():assert sha(Path(row['copy']))==row['sha256']
verify()
stage=base/'rf1111-api31-home-previews-round2';stage.mkdir(exist_ok=False)
def save(name,value):(stage/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env.update({'ANDROID_HOME':str(base/'sdk'),'ANDROID_SDK_ROOT':str(base/'sdk'),
 'ANDROID_USER_HOME':str(base/'android-user'),'ANDROID_EMULATOR_HOME':str(base/'android-user'),
 'ANDROID_AVD_HOME':str(base/'avd'),'ANDROID_ADB_SERVER_PORT':'5049','ADB_SERVER_SOCKET':'tcp:localhost:5049',
 'TEMP':str(base/'tmp'),'TMP':str(base/'tmp')});env.pop('ANDROID_SDK_HOME',None)
adb=str(base/'sdk/platform-tools/adb.exe');serial='emulator-5586';avd='SoloSoul_RF121_API31_20261010'
def call(args,timeout=60):
 return subprocess.run([adb,'-H','localhost','-P','5049','-s',serial,*args],env=env,
  capture_output=True,timeout=timeout,creationflags=subprocess.CREATE_NO_WINDOW)
def read(args):
 result=call(args);assert result.returncode==0,(args,result.stderr.decode(errors='replace'))
 return result.stdout.decode().strip()
assert load(base/'api31-swangle-round2/boot.receipt.json')['booted']
assert read(['get-state'])=='device' and read(['shell','getprop','sys.boot_completed'])=='1'
assert read(['emu','avd','name']).splitlines()[0]==avd
assert read(['shell','getprop','ro.build.version.sdk'])=='31'
installed=read(['shell','pm','list','packages','com.solosoul.app'])
assert set(installed.splitlines())=={'package:com.solosoul.app','package:com.solosoul.app.test'},installed
save('input-proof.json',dict(parentReceiptSha256=sha(parent),sourceFiles=sources,files=artifacts['files'],
 serial=serial,avd=avd,api=31,allBackupsLocalOnly=True,physicalDeviceAcceptance=False,
 existingPackagesIdentityConfirmed=True,externalRunnerBacksUpBeforeEveryInstall=True))
rows=[]
def settings():return dict(blur=read(['shell','settings','get','global','disable_window_blurs']),
 night=read(['shell','cmd','uimode','night']),fontScale=read(['shell','settings','get','system','font_scale']))
for mode in ['supported','fallback']:
 verify();label=f'previews-{mode}';before=settings()
 command=['python','scripts/android-home-native-regression.py','--adb',adb,'--serial',serial,'--avd',avd,
  '--apk',files['main']['copy'],'--test-apk',files['test']['copy'],'--output',str(stage/label),
  '--mode',mode,'--scenario','previews']
 start=time.monotonic()
 with (stage/(label+'.stdout.log')).open('xb') as out,(stage/(label+'.stderr.log')).open('xb') as err:
  process=subprocess.Popen(command,cwd=root/'tauri',env=env,stdin=subprocess.DEVNULL,
   stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
  save(label+'.live.json',dict(pid=process.pid,command=command))
  print(f'API31 previews {mode} PID {process.pid}',flush=True);code=process.wait()
 verify();report=load(stage/label/'report.json');after=settings()
 identity=read(['emu','avd','name']).splitlines()[0]==avd
 restored=bool(report.get('restored') and report.get('blurRestored') and before==after and identity and
  not any(report.get(k) for k in ['restoreError','blurRestoreError','nightModeRestoreError','fontScaleRestoreError']))
 # API31 does not have Android13 POST_NOTIFICATIONS permission; no claim of testing that permission.
 passed=bool(code==0 and report.get('passed') and restored and report.get('mode')==mode and
  report.get('scenario')=='previews' and report.get('api')==31)
 row=dict(mode=mode,scenario='previews',exitCode=code,accepted=passed,restored=restored,
  api=31,elapsedSeconds=time.monotonic()-start,settingsBefore=before,settingsAfter=after,
  sourceAndApkHashesUnchanged=True,dedicatedIdentityConfirmedAfter=identity,
  notificationPermissionApplicable=False,reportSha256=sha(stage/label/'report.json'))
 save(label+'.receipt.json',row);rows.append(row)
 print(f'API31 previews {mode} exit {code}; accepted={passed}; restored={restored}',flush=True)
 if not restored:
  save('verification.json',dict(accepted=False,results=rows,stoppedForIncompleteRestoration=True));raise SystemExit(1)
accepted=len(rows)==2 and all(r['accepted'] for r in rows)
save('verification.json',dict(accepted=accepted,results=rows,scope='API31 previews in both native blur modes',
 fullHomeMatrixAccepted=False,RF121Complete=False,api35Accepted=False,
 at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
raise SystemExit(0 if accepted else 1)
