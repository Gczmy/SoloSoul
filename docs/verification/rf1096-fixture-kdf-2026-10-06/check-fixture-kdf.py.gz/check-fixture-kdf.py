import pathlib,subprocess,sys,json,datetime,hashlib
s=pathlib.Path(__file__).parent;r=pathlib.Path(r"C:\Users\40299571\SoloSoul")
commands=[
 ("fixture-kdf-green",["cargo","test","--locked","-p","solo_soul","--features","native-perf","--lib","completion_marker_uses_persisted_kdf_after_environment_change"]),
 ("fixture-native-tests",["cargo","test","--locked","-p","solo_soul","--features","native-perf","--lib","native_perf"]),
 ("fixture-core-example",["cargo","test","--locked","-p","solosoul-core","--example","perf_baseline"]),
 ("fixture-native-clippy",["cargo","clippy","--locked","--workspace","--all-targets","--features","native-perf","--","-D","warnings"]),
 ("fixture-default-tests",["cargo","test","--locked","--workspace","--verbose","--no-fail-fast"]),
 ("fixture-default-clippy",["cargo","clippy","--locked","--workspace","--all-targets","--","-D","warnings"]),
 ("fixture-rust-fmt",["cargo","+1.99.0","fmt","--all","--","--check"]),
]
for name,args in commands:
 rc=subprocess.call([sys.executable,"-X","utf8",str(s/"run-check.py"),name,*args])
 if rc:raise SystemExit(rc)
b=json.loads((s/"baseline.json").read_text(encoding="utf-8"))
assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in b["preservedAccountWork"].items())
checks={name:json.loads((s/(name+".receipt.json")).read_text(encoding="utf-8")) for name,args in commands}
(s/"required-checks.json").write_text(json.dumps({"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"success":True,"checks":checks,"pendingAccountCodeUnchanged":True,"priorFailurePreserved":True},indent=2)+"\n",encoding="utf-8",newline="\n")
print("RF-1096 required Rust checks complete; original failures and pending account changes preserved",flush=True)
