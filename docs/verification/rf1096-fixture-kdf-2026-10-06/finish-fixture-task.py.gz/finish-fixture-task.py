from pathlib import Path
import hashlib,json,gzip,re,datetime,subprocess
r=Path(r"C:\Users\40299571\SoloSoul");s=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=load(s/"required-checks.json");assert checks["success"]
b=load(s/"baseline.json");assert all(sha(r/p)==h for p,h in b["preservedAccountWork"].items())
freeze=load(s/"check-source-freeze.json");assert all(sha(r/p)==h for p,h in freeze["sourceFiles"].items())
def counts(name):
 text=(s/(name+".stdout.log")).read_text(encoding="utf-8",errors="replace")
 values=re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;",text)
 assert values,name
 return dict(zip(("passed","failed","ignored"),(sum(int(v[i]) for v in values) for i in range(3))))
totals={name:counts(name) for name in ("fixture-kdf-green","fixture-native-tests","fixture-core-example","fixture-default-tests")}
assert totals["fixture-kdf-green"]["passed"]==1
assert totals["fixture-native-tests"]["passed"]==100
assert all(t["failed"]==0 for t in totals.values())
assert load(s/"fixture-kdf-red.receipt.json")["exitCode"]==101
prior=Path(r"C:\Users\40299571\AppData\Local\Temp\ss-rf312-account-write-20261006")
assert load(prior/"account-native-tests.receipt.json")["exitCode"]==101
assert load(prior/"account-native-media-isolated.receipt.json")["exitCode"]==0
archive=r/"docs/verification/rf1096-fixture-kdf-2026-10-06";archive.mkdir(exist_ok=False)
records=[]
inputs={p.name:p for p in s.iterdir() if p.is_file() and (p.suffix in (".py",".json",".log")) and not p.name.endswith(".live.json")}
for label in ("account-native-tests","account-native-media-isolated"):
 for suffix in (".stdout.log",".stderr.log",".receipt.json"):
  inputs["original-"+label+suffix]=prior/(label+suffix)
for p in (s/"before").rglob("*"):
 if p.is_file():inputs["before/"+p.relative_to(s/"before").as_posix()]=p
for name,source in sorted(inputs.items()):
 raw=source.read_bytes();out=archive/(name+".gz");out.parent.mkdir(parents=True,exist_ok=True)
 out.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));assert gzip.decompress(out.read_bytes())==raw
 records.append({"originalPath":str(source),"archivePath":out.relative_to(archive).as_posix(),"rawBytes":len(raw),"rawSha256":hashlib.sha256(raw).hexdigest(),"gzipBytes":out.stat().st_size,"gzipSha256":sha(out)})
index={"schemaVersion":1,"taskId":"RF-1096","encoding":"gzip with mtime=0; exact original bytes","records":records}
(archive/"index.json").write_text(json.dumps(index,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
evidence={"schemaVersion":1,"taskId":"RF-1096","at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"baseCommit":b["baseCommit"],"success":True,"problem":"fixture marker reread environment after account selected and persisted its KDF","deterministicRegression":{"oldExitCode":101,"directions":["development to production environment","production to development environment"],"green":totals["fixture-kdf-green"],"configurationBytesPreserved":True,"reopenVerification":True},"originalFailure":{"passed":94,"failed":5,"exitCode":101,"isolatedMediaPassed":7},"checks":checks["checks"],"testTotals":totals,"fixedSourceHashes":{p:sha(r/p) for p in b["beforeFiles"] if p.endswith(".rs")},"pendingAccountSourceHashes":b["preservedAccountWork"],"pendingAccountInstrumentationExcludedFromCommit":True,"checkedSourceInputs":len(freeze["sourceFiles"]),"productionKdfAndReleaseGatesUnchanged":True,"frontendAndCliProductionUnchanged":True,"toolchain":{"cargo":"1.96.0","rustc":"1.96.0","rustfmt":"1.99.0","node":"24.16.0","git":"2.54.0.windows.1"},"originalBudgetsAndAssertionsPreserved":True,"rawArchive":{"index":"rf1096-fixture-kdf-2026-10-06/index.json","records":len(records),"indexSha256":sha(archive/"index.json")},"unclosed":["RF-112","RF-121","RF-312","RF-122 through RF-127"]}
(r/"docs/verification/rf1096-fixture-kdf-2026-10-06.json").write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
p=r/"docs/performance/RF-312-media-fixture-contract.md";t=p.read_text(encoding="utf-8-sig")
needle="- 完成标记为 `rf312-media-fixture.json`（schemaVersion 2），明确包含附件与 OCR 样例。旧原生启动工具继续只接纳 v1，不会误将本数据集算入旧基线。"
assert t.count(needle)==1
t=t.replace(needle,needle+"完成标记的 `baseFixture.kdf` 从新建账户 `config.json` 读取实际参数，不因创建后的环境变化而改写；[RF-1096 红绿验证](../verification/rf1096-fixture-kdf-2026-10-06.json)覆盖两个变化方向及独立重开。")
p.write_text(t,encoding="utf-8",newline="\n")
p=r/"docs/performance/RF-312-native-vault-baseline.md";t=p.read_text(encoding="utf-8-sig")
needle="生成使用原子目录创建，已有目录、文件或链接都拒绝。"
assert t.count(needle)==1
t=t.replace(needle,"完成标记的 KDF 取自新建账户 config.json 的实际参数，不重新读取环境推测，详见 [RF-1096 验证](../verification/rf1096-fixture-kdf-2026-10-06.json)。"+needle)
p.write_text(t,encoding="utf-8",newline="\n")
p=r/"docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md";t=p.read_text(encoding="utf-8-sig")
assert "已关闭：**276 / 286**" in t
original_current=next(x for x in (s/"before/docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md").read_text(encoding="utf-8-sig").splitlines() if x.startswith("- 当前处理："))
current=next(x for x in t.splitlines() if x.startswith("- 当前处理："));t=t.replace(current,original_current)
t=t.replace("已关闭：**276 / 286**；实际修复（已关闭）：276","已关闭：**277 / 286**；实际修复（已关闭）：277",1).replace("暂缓：0；进行中：1；待执行：6","暂缓：0；进行中：0；待执行：6",1)
t=t.replace("| 286 | [RF-1096](#rf-1096) | P2 | 夹具完成标记使用账户实际 KDF | 无（RF-312 媒体准备失败） | [~] 进行中 |","| 286 | [RF-1096](#rf-1096) | P2 | 夹具完成标记使用账户实际 KDF | 无（RF-312 媒体准备失败） | [x] 完成 |",1)
t=t.replace("- **状态：**进行中，保留原始失败及独立对照，验收后回填。","- **状态：**已关闭；见[确定性红绿与完整检查](verification/rf1096-fixture-kdf-2026-10-06.json)。",1)
t += f"""

### RF-1096 完整验收与关闭（2026-10-06）

- 账户完成标记改为读取已持久化的 KDF；创建账户、实际派生、安全参数、Release 生产门禁和严格合同不变。确定性红测 0 passed / 1 failed、exit101 保留；绿色用例覆盖开发→生产与生产→开发，配置字节未变且真实重开通过。
- 完整 native-perf {totals['fixture-native-tests']['passed']} passed / 0 failed / 0 ignored；Core 示例 {totals['fixture-core-example']['passed']} passed / 0 failed；默认 workspace {totals['fixture-default-tests']['passed']} passed / 0 failed / {totals['fixture-default-tests']['ignored']} 既有 ignored。默认/非默认 all-target 严格 Clippy 与 fmt 全通过；没有前端或 CLI 生产输入变化，不重复未受影响检查。
- [全部证据](verification/rf1096-fixture-kdf-2026-10-06.json)与[逐字节原件](verification/rf1096-fixture-kdf-2026-10-06/index.json)保存原 94/5 失败、独立媒体 7/7、确定性红绿、检查命令/退出码和源码 SHA。RF-312 五个未提交源码文件保持原字节，本提交只包含 RF-1096。
- 本项关闭并独立本地提交（本提交，以 RF-1096 检索），不推送；累计 277/286、3 待验证、6 待执行。恢复 RF-312 账户写入归因；RF-112/121/122～127 前置及整体 goal 继续未完成。
"""
p.write_text(t,encoding="utf-8",newline="\n")
rows=re.findall(r"^\| \d+ \| \[RF-(\d+)\]",t,re.M)
assert len(rows)==286 and len(set(rows))==286
for entry in index["records"]:
 compressed=archive/entry["archivePath"];assert sha(compressed)==entry["gzipSha256"]
 assert hashlib.sha256(gzip.decompress(compressed.read_bytes())).hexdigest()==entry["rawSha256"]
print(json.dumps({"testTotals":totals,"archivedOriginals":len(records),"reportClosed":277,"reportTotal":286,"pendingAccountSourcePreserved":True},ensure_ascii=False))
