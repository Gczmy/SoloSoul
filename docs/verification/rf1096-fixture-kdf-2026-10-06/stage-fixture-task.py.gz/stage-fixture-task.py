from pathlib import Path
import json,hashlib,subprocess,os
r=Path(r"C:\Users\40299571\SoloSoul");s=Path(__file__).parent
load=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert load(s/"required-checks.json")["success"]
assert load(s/"doc-archive-check.json")["success"]
assert load(s/"fixture-markdown-boundary.receipt.json")["exitCode"]==0
assert load(s/"fixture-diff-check.receipt.json")["exitCode"]==0
b=load(s/"baseline.json");assert all(sha(r/p)==h for p,h in b["preservedAccountWork"].items())
env=os.environ.copy();env["PATH"]=r"C:\Program Files\Git\usr\bin;"+env.get("PATH","")
a=["git","-c","safe.directory=C:/Users/40299571/SoloSoul","-c","core.safecrlf=false","-c","core.autocrlf=false"]
def out(args):return subprocess.check_output(a+args,cwd=r,env=env)
assert out(["diff","--cached","--name-only"]).strip()==b""
assert out(["branch","--show-current"]).decode().strip()=="codex/rf312-warm-start"
assert out(["rev-parse","HEAD"]).decode().strip()==b["baseCommit"]
assert out(["rev-parse","refs/stash"]).decode().strip()=="dd695bba03ce1ea274185d4cc9ed0e69501b3d90"
paths=["tauri/crates/solosoul-core/examples/perf_baseline/fixture.rs","tauri/src-tauri/src/native_perf/media_fixture.rs","docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md","docs/performance/RF-312-media-fixture-contract.md","docs/performance/RF-312-native-vault-baseline.md","docs/verification/rf1096-fixture-kdf-2026-10-06.json"]
archive=r/"docs/verification/rf1096-fixture-kdf-2026-10-06"
paths+=sorted(p.relative_to(r).as_posix() for p in archive.rglob("*") if p.is_file())
subprocess.check_call(a+["add","--",*paths],cwd=r,env=env)
staged=out(["diff","--cached","--name-only"]).decode().splitlines();assert set(staged)==set(paths)
assert not set(staged)&set(b["preservedAccountWork"])
for p in paths:
 data=out(["show",":"+p]);assert hashlib.sha256(data).hexdigest()==sha(r/p),p
subprocess.check_call(a+["diff","--cached","--check"],cwd=r,env=env)
(s/"staged-review.json").write_text(json.dumps({"success":True,"baseCommit":b["baseCommit"],"paths":paths,"stagedBytesMatchWorking":True,"pendingAccountCodeExcluded":True,"stashPreserved":True},indent=2)+"\n",encoding="utf-8",newline="\n")
print(out(["diff","--cached","--stat"]).decode(),end="")
print("Every staged blob matches the reviewed file; RF-312 code excluded")
