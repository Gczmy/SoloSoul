from pathlib import Path
import json,re,hashlib,gzip
r=Path(r"C:\Users\40299571\SoloSoul");s=Path(__file__).parent
p=r/"docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md";t=p.read_text(encoding="utf-8-sig")
rows=[l for l in t.splitlines() if re.match(r"^\| \d+ \| \[RF-\d+\]",l)]
assert len(rows)==286
assert sum("[x]" in l for l in rows)==277
assert sum("[!]" in l for l in rows)==3
assert sum("[ ]" in l for l in rows)==6
assert sum("[~]" in l for l in rows)==0
for l in rows:
 task=re.search(r"\[RF-(\d+)\]",l).group(1)
 assert re.search(r"^### RF-"+task+r"$",t,re.M),task
priorities={q:sum("| "+q+" |" in l for l in rows) for q in ("P1","P2","P3")}
assert priorities=={"P1":51,"P2":234,"P3":1},priorities
links=[]
for relative in ("docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md","docs/performance/RF-312-media-fixture-contract.md","docs/performance/RF-312-native-vault-baseline.md"):
 doc=r/relative
 for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)",doc.read_text(encoding="utf-8-sig")):
  if target.startswith(("http:","https:","#","codex:")):continue
  file=target.split("#",1)[0]
  if not file:continue
  destination=(doc.parent/file).resolve()
  assert destination.exists(),(relative,target)
  links.append((relative,target))
archive=r/"docs/verification/rf1096-fixture-kdf-2026-10-06"
index=json.loads((archive/"index.json").read_text(encoding="utf-8"))
for record in index["records"]:
 data=(archive/record["archivePath"]).read_bytes()
 assert hashlib.sha256(data).hexdigest()==record["gzipSha256"]
 assert hashlib.sha256(gzip.decompress(data)).hexdigest()==record["rawSha256"]
result={"success":True,"taskRows":len(rows),"closed":277,"waiting":3,"pending":6,"priorities":priorities,"relativeLinksChecked":len(links),"originalArchivesVerified":len(index["records"])}
(s/"doc-archive-check.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(result))
