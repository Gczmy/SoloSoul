from pathlib import Path
import re,json
r=Path(r"C:\Users\40299571\SoloSoul");s=Path(__file__).parent
red=json.loads((s/"fixture-kdf-red.receipt.json").read_text(encoding="utf-8"));assert red["exitCode"]==101
log=(s/"fixture-kdf-red.stdout.log").read_text(encoding="utf-8",errors="replace")
assert "KDF environment changed 0 -> 1" in log and "1 failed" in log
p=r/"docs/REFACTOR_EXECUTION_REPORT_2026-09-25.md";t=p.read_text(encoding="utf-8-sig")
assert "任务总数：**285**（P1：51；P2：233；P3：1）" in t
assert "已关闭：**276 / 285**" in t
assert "RF-1096" not in t
old=next(x for x in t.splitlines() if x.startswith("- 当前处理："))
t=t.replace(old,"- 当前处理：**RF-1096：修复媒体夹具完成标记重新读取 KDF 环境变量的问题；RF-312 的五个账户写入子阶段改动保留，原生检查失败先独立修复**。")
t=t.replace("任务总数：**285**（P1：51；P2：233；P3：1）","任务总数：**286**（P1：51；P2：234；P3：1）")
t=t.replace("已关闭：**276 / 285**","已关闭：**276 / 286**",1).replace("暂缓：0；进行中：0；待执行：6","暂缓：0；进行中：1；待执行：6",1)
t=t.replace("RF-1094、RF-1095（RF-904","RF-1094、RF-1095、RF-1096（RF-904",1)
row=next(x for x in t.splitlines() if x.startswith("| 285 |"))
t=t.replace(row,row+"\n| 286 | [RF-1096](#rf-1096) | P2 | 夹具完成标记使用账户实际 KDF | 无（RF-312 媒体准备失败） | [~] 进行中 |",1)
card="""### RF-1096

**夹具完成标记使用账户实际 KDF** · P2 · 来源：RF-312 原生检查失败

- **前置：**无；与未提交的 RF-312 账户写入观测分开提交。
- **现状证据：**完整 native-perf 99 项为 94 passed / 5 failed，五个媒体用例均在生成时因完成标记与合同不匹配而失败；同源码媒体独立组 7 passed。账户创建和完成标记先后两次读取 SOLOSOUL_SECURE，并行原生测试会临时修改该变量。显式创建开发档账户后切换生产档环境的确定性红测复现标记不一致。
- **入口：**`tauri/crates/solosoul-core/examples/perf_baseline/fixture.rs`；`tauri/src-tauri/src/native_perf/media_fixture.rs`。
- **执行：**完成标记从已经落盘的合成账户 config.json 读取实际 KDF，不再次用环境推测；实际创建账户、密钥派生、Release 生产参数门禁和严格合同保持。
- **验收：**开发→生产及生产→开发两个环境变化均保持标记等于实际账户参数，配置字节不变，独立重开通过；原五项媒体校验及完整 native-perf 组不再失败。
- **验证配置：**定向红绿回归、Core 示例测试、完整 native-perf、R、DOC；无前端或 CLI 生产改动，不重复未受影响的 F/CLI。
- **建议提交：**`fix(perf): bind fixture marker to persisted KDF [RF-1096]`。
- **状态：**进行中，保留原始失败及独立对照，验收后回填。

"""
t=t.replace("## 7. 每项执行记录模板",card+"## 7. 每项执行记录模板",1)
t += """

### RF-1096 执行记录（2026-10-06，进行中）

- RF-312 账户写入观测未提交，完整非默认原生检查出现媒体准备 5 failed；原日志和退出码 101 保留。独立媒体同源码 7 passed，随后建立显式环境切换的确定性红测，确认标记再次读取环境会偏离已保存账户参数。
- 本项限定夹具生成/验证设施，不改账户创建、KDF、安全参数或生产权限行为；RF-312 五个源码改动保持原字节。目标与 RF-112/121/122～127 前置继续未完成。
"""
p.write_text(t,encoding="utf-8",newline="\n")
print("Registered RF-1096 as independent in-progress task; original RF-312 work preserved")
