from pathlib import Path
import json,hashlib
r=Path(r"C:\Users\40299571\SoloSoul");s=Path(__file__).parent
assert json.loads((s/"fixture-kdf-red.receipt.json").read_text(encoding="utf-8"))["exitCode"]==101
p=r/"tauri/crates/solosoul-core/examples/perf_baseline/fixture.rs"
t=p.read_text(encoding="utf-8-sig")
old="""pub(super) fn completed_manifest(_base: &Path, count: usize) -> Result<Value, String> {
    Ok(manifest(
        count,
        KdfConfig::from_env(),"""
new="""pub(super) fn completed_manifest(base: &Path, count: usize) -> Result<Value, String> {
    // 账户创建已决定实际 KDF；环境在后续写入期间变化不能改写完成标记。
    let config: AccountConfig = serde_json::from_value(read_json(
        &base.join(format!("acc_rf312_{count}")).join("config.json"),
    )?)
    .map_err(|e| format!("invalid fixture account config: {e}"))?;
    Ok(manifest(
        count,
        config.kdf_config(),"""
assert t.count(old)==1
p.write_text(t.replace(old,new),encoding="utf-8",newline="\n")
b=json.loads((s/"baseline.json").read_text(encoding="utf-8"))
assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in b["preservedAccountWork"].items())
print("Fixture marker now reads actual persisted KDF; pending account instrumentation unchanged")
