from pathlib import Path
import datetime,json,subprocess,sys,time
stage=Path(__file__).parent;root=stage.parent.parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,data):
    with (stage/name).open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(data,indent=2)+'\n')
assert not (stage/'ss-rf121-composed-window-current-round5').exists()
assert load(stage/'round4.receipt.json')['exitCode']==1
assert load(stage/'cache-cleanup.json')['preservedBytesVerified'] is True
preflight=subprocess.run([sys.executable,'-X','utf8',str(stage/'round5-recheck-session.py')],cwd=root,
                         capture_output=True,creationflags=subprocess.CREATE_NO_WINDOW,timeout=10)
save('round5-preflight.receipt.json',{'at':now(),'exitCode':preflight.returncode,
     'stdout':preflight.stdout.decode('utf-8'),'stderr':preflight.stderr.decode('utf-8')})
assert preflight.returncode==0
session=load(stage/'round5-session-preflight.json')
assert session['connectionStateName']=='Active' and session['inputDesktopAvailable'] is True
# Physical console and RDP session IDs need not match. Access in this caller's active session is required.
for name in ['readable-helper-format-check','readable-helper-tests','readable-helper-clippy','readable-helper-build']:
    assert load(stage/(name+'.receipt.json'))['exitCode']==0
jobs=[('round5-surface-captures',[sys.executable,'-X','utf8',str(stage/'round5-run-surface-captures.py'),'--round','5']),
      ('round5-surface-independent-validation',['node',str(stage/'round5-verify-surface-captures.mjs'),'--round','5']),
      ('round5-surface-render',[sys.executable,'-X','utf8',str(stage/'round5-render-surface-captures.py'),'--round','5'])]
began=time.monotonic();code=0
for name,command in jobs:
    started=time.monotonic()
    with (stage/(name+'.stdout.log')).open('xb') as out,(stage/(name+'.stderr.log')).open('xb') as err:
        p=subprocess.Popen(command,cwd=root,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
        save(name+'.live.json',{'pid':p.pid,'at':now(),'command':command})
        print(name+' live PID '+str(p.pid),flush=True);code=p.wait()
    save(name+'.receipt.json',{'pid':p.pid,'at':now(),'command':command,'exitCode':code,'elapsedSeconds':time.monotonic()-started})
    print(name+' terminal exit '+str(code),flush=True)
    if code:break
save('round5.receipt.json',{'at':now(),'exitCode':code,'elapsedSeconds':time.monotonic()-began,
     'previousFourFailedRoundsPreserved':True,'applicationMaterialAccepted':False,'performanceMetrics':None})
raise SystemExit(code)
