"""Prepare a new fixed round after reconnecting the same interactive RDP session."""
from pathlib import Path
import ast
stage=Path(__file__).parent
allowed="[[], ['--round', '2'], ['--round', '3'], ['--round', '4']]"
driver=(stage/'run-surface-captures.py').read_text(encoding='utf-8')
assert driver.count(allowed)==1
driver=driver.replace(allowed,"[['--round', '5']]").replace('Only the four fixed capture rounds are allowed','Only the fixed fifth capture round is allowed')
selector="'runtime-package-readable.json' if sys.argv[1:] == ['--round', '4']"
assert driver.count(selector)==1
driver=driver.replace(selector,"'runtime-package-readable.json' if sys.argv[1:] == ['--round', '5']")
ast.parse(driver)
with (stage/'round5-run-surface-captures.py').open('x',encoding='utf-8',newline='\n') as f:f.write(driver)
verifier=(stage/'verify-surface-captures.mjs').read_text(encoding='utf-8')
old="[JSON.stringify([]),JSON.stringify(['--round','2']),JSON.stringify(['--round','3']),JSON.stringify(['--round','4'])]"
assert verifier.count(old)==1
verifier=verifier.replace(old,"[JSON.stringify(['--round','5'])]")
with (stage/'round5-verify-surface-captures.mjs').open('x',encoding='utf-8',newline='\n') as f:f.write(verifier)
renderer=(stage/'render-surface-captures.py').read_text(encoding='utf-8')
assert renderer.count(allowed)==1
renderer=renderer.replace(allowed,"[['--round', '5']]")
ast.parse(renderer)
with (stage/'round5-render-surface-captures.py').open('x',encoding='utf-8',newline='\n') as f:f.write(renderer)
probe=(stage/'recheck-session.py').read_text(encoding='utf-8')
old="stage/'session-recheck-after-commit.json'"
assert probe.count(old)==1
probe=probe.replace(old,"stage/'round5-session-preflight.json'")
ast.parse(probe)
with (stage/'round5-recheck-session.py').open('x',encoding='utf-8',newline='\n') as f:f.write(probe)
print('Prepared fifth fixed round without overwriting any previous scripts or samples')
