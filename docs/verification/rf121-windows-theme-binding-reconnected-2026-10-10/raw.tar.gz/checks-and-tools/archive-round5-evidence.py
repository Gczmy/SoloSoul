from pathlib import Path
import datetime, gzip, hashlib, io, json, tarfile

root = Path('D:/SoloSoul')
stage = Path(__file__).parent
capture = stage / 'ss-rf121-composed-window-current-round5'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
validation = load(capture / 'validation.json')
review = load(capture / 'visual-review.json')
cleanup = load(capture / 'cache-cleanup.json')
session = load(stage / 'round5-session-preflight.json')
assert validation['accepted'] and len(validation['samples']) == 3
assert review['actualImagesInspected'] == 3 and len(review['images']) == 3
assert not review['applicationMaterialAccepted'] and not review['fullMatrixAccepted']
assert cleanup['matchingOwnedIdentitiesLive'] == cleanup['processesTerminatedByThisTool'] == 0
assert cleanup['preservedBytesVerified'] and len(cleanup['removedCachePaths']) == 24
for item in cleanup['preservedVaultAndRootFiles']:
    assert sha(Path(item['path']).read_bytes()) == item['sha256']
for item in cleanup['applicationLogs']:
    assert sha(Path(item['copy']).read_bytes()) == item['sha256']
for item in review['images']:
    assert sha(Path(item['png']).read_bytes()) == item['pngSha256']
for name, digest in load(stage / 'sources-applied.json').items():
    assert sha((root / name).read_bytes()) == digest, name
package = load(stage / 'runtime-package-readable.json')
assert sha(Path(package['exe']).read_bytes()) == package['sha256']
assert sha(Path(package['helperExe']).read_bytes()) == package['helperSha256']
assert load(stage / 'round5.receipt.json')['exitCode'] == 0
for name in ['round5-preflight','round5-surface-captures','round5-surface-independent-validation','round5-surface-render']:
    assert load(stage / (name + '.receipt.json'))['exitCode'] == 0

members = {}
def add(source, name):
    assert name not in members and source.is_file() and not source.is_symlink()
    assert not (source.lstat().st_file_attributes & 0x400)
    assert not name.lower().endswith(('.exe','.dll','.db','.onnx'))
    members[name] = source.read_bytes()

for source in stage.iterdir():
    if source.is_file() and ('round5' in source.name or source.name in {
        'sources-applied.json','runtime-package-readable.json','checks-accepted.json',
        'native-release-build.receipt.json','build-manifest-newline-parity.json'}):
        add(source, 'checks-and-tools/' + source.name)
for name in ['Cargo.toml','Cargo.lock','src/bin/owned-window.rs']:
    add(stage / 'helper-d-root-readable' / name, 'capture-helper/' + name)
for source in capture.iterdir():
    if source.is_file(): add(source, 'round5/' + source.name)
for source in (capture / 'actual100').iterdir():
    if source.is_file(): add(source, 'round5/actual100/' + source.name)
    elif source.name in {'sample-001','sample-002','sample-003'}:
        for proof in source.iterdir():
            if proof.is_file(): add(proof, 'round5/actual100/' + source.name + '/' + proof.name)
for source in (capture / 'application-logs').rglob('*'):
    if source.is_file(): add(source, 'round5/' + source.relative_to(capture).as_posix())

destination = root / 'docs/verification/rf121-windows-theme-binding-reconnected-2026-10-10'
destination.mkdir(exist_ok=False)
archive_path = destination / 'raw.tar.gz'
with archive_path.open('xb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(mode='w',fileobj=zipped,format=tarfile.PAX_FORMAT) as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mtime, info.mode = len(data), 0, 0o644
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive_path,'r:gz') as tar:
    reread = {info.name:tar.extractfile(info).read() for info in tar.getmembers() if info.isfile()}
assert reread == members
def write(path, value):
    with path.open('x',encoding='utf-8',newline='\n') as out:
        out.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
index = {'schemaVersion':1,'task':'RF-121','scope':'windows-reconnected-owned-capture-binding',
    'archive':'raw.tar.gz','archiveSha256':sha(archive_path.read_bytes()),
    'archiveBytes':archive_path.stat().st_size,'memberCount':len(members),
    'members':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())],
    'readbackAllMembersVerified':True,'includesPhysicalVaults':False,
    'includesExecutablesModelsOrCaches':False,'applicationMaterialAccepted':False,'fullMatrixAccepted':False}
write(destination / 'index.json', index)
for item in review['images']:
    with (destination / Path(item['png']).name).open('xb') as out:
        out.write(Path(item['png']).read_bytes())
record = {'schemaVersion':1,'task':'RF-121','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope':index['scope'],'captureBindingAccepted':True,'nativeJourneysPassed':3,
    'previousFailedRoundsPreserved':True,
    'previousEvidence':'rf121-windows-theme-binding-2026-10-10.json',
    'checksReusedFromUnchangedSources':load(stage / 'checks-accepted.json'),
    'runtime':package,'session':session,'validation':validation,'visualReview':review,'cleanup':cleanup,
    'archive':{'path':destination.relative_to(root).as_posix(),**{k:index[k] for k in ['archiveSha256','archiveBytes','memberCount','readbackAllMembersVerified']}},
    'diagnosticOnly':True,'performanceMetrics':None,'applicationMaterialAccepted':False,
    'fullMatrixAccepted':False,'nativeAppearancePropertiesVerified':False,'rf121Closed':False,
    'defaultDependenciesChanged':False,'sdkBudgetsUnchanged':True,
    'historicalWgcTimeoutRootCauseProven':False}
write(destination.parent / 'rf121-windows-theme-binding-reconnected-2026-10-10.json', record)
print(f'Archived {len(members)} actual originals, {archive_path.stat().st_size} bytes; all read back; three bindings accepted, full matrix false')
