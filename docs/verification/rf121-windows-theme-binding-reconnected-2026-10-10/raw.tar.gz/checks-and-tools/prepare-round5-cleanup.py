from pathlib import Path
import datetime, json, hashlib

stage = Path(__file__).parent
capture = stage / 'ss-rf121-composed-window-current-round5'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
validation = load(capture / 'validation.json')
rendered = load(capture / 'rendered-captures.json')
assert validation['accepted'] and len(validation['samples']) == len(rendered) == 3
images = []
for item in rendered:
    assert hashlib.sha256(Path(item['png']).read_bytes()).hexdigest() == item['pngSha256']
    images.append({**item, 'visualReviewComplete': True,
        'observed': 'Readable light home; distinct navigation, header, content and cards; no blank or whole-window black frame.',
        'ocrCompleteBannerVisible': item['index'] in (2, 3),
        'selectedSurfaceBindingOnly': True})
review = {'schemaVersion': 1, 'task': 'RF-121',
    'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'actualImagesInspected': 3, 'method': 'view_image, all three actual converted frames',
    'images': images, 'applicationMaterialAccepted': False, 'fullMatrixAccepted': False,
    'nativeAppearancePropertiesVerified': False,
    'transientOrRecoveryBehaviorAccepted': False,
    'limitations': ['Light theme, expanded navigation, 96 DPI, one RDP desktop only.',
        'OCR-completion banner differs between samples; fixed surface state is not full-page visual stability.',
        'Mica DOM state does not prove DWM backdrop or transparency fidelity.']}
with (capture / 'visual-review.json').open('x', encoding='utf-8', newline='\n') as out:
    out.write(json.dumps(review, indent=2) + '\n')

text = (stage / 'cleanup-surface-owned.ps1').read_text()
old_root = r"'D:\SoloSoul\build\rf121-theme-binding-20261010\ss-rf121-composed-window-current'"
assert text.count(old_root) == 1
text = text.replace(old_root, r"'D:\SoloSoul\build\rf121-theme-binding-20261010\ss-rf121-composed-window-current-round5'")
old = "    return [IO.Path]::GetFullPath($value).TrimEnd('\\')"
new = "    $full = [IO.Path]::GetFullPath($value)\n    if ($full -eq [IO.Path]::GetPathRoot($full)) { return $full }\n    return $full.TrimEnd('\\')"
assert text.count(old) == 1
text = text.replace(old, new)
failed = (stage / 'cleanup-failed-owned.ps1').read_text()
plain = failed[failed.index('function PlainAncestors'):failed.index('PlainAncestors $stageRoot')]
text = text.replace('$targets = [Collections.Generic.List[string]]::new()', plain + "PlainAncestors $stageRoot\n$targets = [Collections.Generic.List[string]]::new()")
text = text.replace('        RequireBelow $sampleRoot $stageRoot', '        PlainAncestors $sampleRoot\n        RequireBelow $sampleRoot $stageRoot')
text = text.replace('            RequireBelow $expectedPath (Join-Path $packageBase $parentName)', '            PlainAncestors $expectedPath\n            RequireBelow $expectedPath (Join-Path $packageBase $parentName)')
helper_check = """$liveHelpers = @(Get-CimInstance Win32_Process -Filter \"Name = 'rf121-wgc-owned-window.exe'\" | Where-Object ExecutablePath -EQ 'D:\\SoloSoul\\build\\rf121-theme-binding-20261010\\helper-target-readable\\debug\\rf121-wgc-owned-window.exe')
if ($liveHelpers.Count) { throw 'Owned capture helper is still live' }
"""
text = text.replace('$packageBase = ', helper_check + '$packageBase = ')
text = text.replace("            $preserved.Add([ordered]@", "            if ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Root proof is a link' }\n            $preserved.Add([ordered]@")
with (stage / 'round5-cleanup-owned.ps1').open('x', encoding='utf-8', newline='\n') as out:
    out.write(text)
print('Recorded actual three-image review; prepared guarded round5-only cleanup')
